//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath2    = "homeos.olang"
const layerIdxEnd2 = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath2)
	if err != nil { log.Fatal(err) }
	fmt.Printf("▶ start: %d nodes\n", be322(raw[12:16]))
	ex := readNames2(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		{"STOICISM",            3,`label=chủ nghĩa khắc kỷ|desc=Stoicism Epictetus Marcus Aurelius Seneca virtue logos dichotomy control indifference externals eudaimonia|vi=chủ nghĩa khắc kỷ,stoicism|en=stoicism`},
		{"EPICUREANISM",        3,`label=triết học Epicurus|desc=Epicureanism pleasure ataraxia aponia absence pain simple pleasures friendship tranquility death|vi=triết học Epicurus,epicureanism|en=epicureanism`},
		{"NIHILISM",            3,`label=chủ nghĩa hư vô|desc=nihilism Nietzsche God is dead value collapse existential nihilism moral nihilism cosmic meaninglessness|vi=chủ nghĩa hư vô,nihilism|en=nihilism`},
		{"ABSURDISM",           3,`label=chủ nghĩa phi lý|desc=absurdism Camus Sisyphus revolt acceptance embrace meaningless universe rebel create|vi=chủ nghĩa phi lý,absurdism|en=absurdism`},
		{"HUMANISM",            3,`label=chủ nghĩa nhân văn|desc=humanism human dignity reason science secular Renaissance Erasmus Pico della Mirandola modern|vi=chủ nghĩa nhân văn,humanism|en=humanism`},
		{"MATERIALISM_PHIL",    3,`label=chủ nghĩa duy vật|desc=materialism physicalism everything is matter Marx dialectical Hobbes eliminative reductive non-reductive|vi=chủ nghĩa duy vật,materialism|en=materialism`},
		{"IDEALISM_PHIL",       3,`label=chủ nghĩa duy tâm|desc=idealism Berkeley everything is mind Kant transcendental Hegel absolute German idealism perception|vi=chủ nghĩa duy tâm,idealism|en=idealism`},
		{"DIALECTIC",           3,`label=biện chứng pháp|desc=dialectic Hegel thesis antithesis synthesis Aufhebung Marx material contradiction negation sublation|vi=biện chứng pháp,dialectic|en=dialectic`},
		{"DECONSTRUCTION",      3,`label=giải cấu trúc|desc=deconstruction Derrida trace différance binary opposition logocentrism supplement undecidability close reading|vi=giải cấu trúc,deconstruction|en=deconstruction`},
		{"STRUCTURALISM",       3,`label=cấu trúc luận|desc=structuralism Saussure sign signifier signified Lévi-Strauss binary myths language system langue parole|vi=cấu trúc luận,structuralism|en=structuralism`},
		{"PHILOSOPHY_VIET",     3,`label=triết học cổ điển Việt|desc=triết học Việt cổ điển thiên địa nhân tam tài âm dương ngũ hành trời đất người hòa hợp|vi=triết học cổ điển Việt,classical Vietnamese philosophy|en=classical Vietnamese philosophy`},
		{"MORAL_RELATIVISM",    3,`label=thuyết tương đối đạo đức|desc=moral relativism cultural subjectivism objectivism universal values cross-cultural Mackie Harman|vi=thuyết tương đối đạo đức,moral relativism|en=moral relativism`},
		{"BIOETHICS",           3,`label=đạo đức sinh học|desc=bioethics autonomy beneficence non-maleficence justice principlism Beauchamp Childress informed consent|vi=đạo đức sinh học,bioethics|en=bioethics`},
		{"PHILOSOPHY_LAW",      3,`label=triết học pháp luật|desc=philosophy of law jurisprudence natural law positivism Hart Fuller Dworkin integrity law morality|vi=triết học pháp luật,philosophy of law|en=philosophy of law`},
	}
	added := 0
	for _, n := range nodes {
		if ex[n.name] { continue }
		raw = appendNode2(raw, n.name, n.layer, n.dna)
		added++
	}
	if err := os.WriteFile(filePath2, raw, 0644); err != nil { log.Fatal(err) }
	total := be322(raw[12:16])
	fmt.Printf(" +%d\n✓ %d nodes\n", added, total)
	if total >= 5500 { fmt.Println("🎉 MILESTONE 5500! Philosophy/Ethics/Logic complete") }
}

func appendNode2(raw []byte, name string, layer uint8, dna string) []byte {
	nameB := []byte(name); dnaB := []byte(dna)
	nd := make([]byte, 2+1+8+4+4+1+len(dnaB)+len(nameB))
	nd[0], nd[1] = 'N', 'D'; nd[2] = layer
	copy(nd[3:11], make([]byte, 8))
	binary.BigEndian.PutUint32(nd[11:15], uint32(len(dnaB)))
	nd[15] = byte(len(nameB))
	copy(nd[16:], dnaB); copy(nd[16+len(dnaB):], nameB)
	raw = append(raw[:len(raw)-32], nd...)
	n := be322(raw[12:16]) + 1
	binary.BigEndian.PutUint32(raw[12:16], n)
	h := sha256.Sum256(raw[:len(raw)-32])
	return append(raw, h[:]...)
}
func readNames2(raw []byte) map[string]bool {
	m := make(map[string]bool); i := layerIdxEnd2
	for i < len(raw)-32 {
		if i+2 > len(raw)-32 || raw[i] != 'N' || raw[i+1] != 'D' { break }
		dnaLen := int(binary.BigEndian.Uint32(raw[i+11:i+15]))
		nameLen := int(raw[i+15])
		start := i + 16 + dnaLen
		if start+nameLen > len(raw)-32 { break }
		m[string(raw[start:start+nameLen])] = true
		i += 16 + dnaLen + nameLen
	}
	return m
}
func be322(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
