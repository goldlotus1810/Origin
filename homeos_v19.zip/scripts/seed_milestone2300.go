//go:build ignore
// go run scripts/seed_milestone2300.go
// Mục tiêu: vượt 2300 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes, %d edges\n", be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── CÔNG NGHỆ THÊM (TECH2_) ──────────────────────────────
		{"TECH2_ROBOTICS",   3, `label=robot|desc=máy móc tự động hóa thực hiện nhiệm vụ thay thế con người nhà máy phẫu thuật khám phá không gian|vi=robot,robotics|en=robot,robotics|zh=机器人`},
		{"TECH2_QUANTUM",    3, `label=máy tính lượng tử|desc=máy tính dùng qubit thay bit tốc độ tính toán vượt trội mã hóa mô phỏng hóa học|vi=máy tính lượng tử,quantum computing|en=quantum computing|zh=量子计算`},
		{"TECH2_DRONE2",     3, `label=drone thương mại|desc=thiết bị bay không người lái dân sự nhiếp ảnh giao hàng khảo sát nông nghiệp|vi=drone,máy bay không người lái|en=drone,UAV|zh=无人机`},
		{"TECH2_3DPRINT",    3, `label=in 3D|desc=sản xuất vật thể từ mô hình số bằng cách đắp lớp vật liệu y tế hàng không ô tô|vi=in 3D,3D printing|en=3D printing|zh=3D打印`},
		{"TECH2_WEARABLE",   3, `label=thiết bị đeo|desc=điện tử đeo trên người đồng hồ thông minh kính VR theo dõi sức khỏe nhịp tim|vi=thiết bị đeo,wearable,smartwatch|en=wearable,smartwatch|zh=可穿戴设备`},

		// ── VŨ TRỤ THÊM (SPACE2_) ────────────────────────────────
		{"SPACE2_BLACKHOLE",  3, `label=hố đen|desc=vùng không-thời gian có trọng lực cực mạnh không gì thoát được kể cả ánh sáng Hawking M87|vi=hố đen,black hole|en=black hole|zh=黑洞`},
		{"SPACE2_ASTEROID",   3, `label=tiểu hành tinh|desc=thiên thể đá nhỏ quay quanh Mặt Trời vành đai tiểu hành tinh NASA khai thác tài nguyên|vi=tiểu hành tinh,asteroid|en=asteroid|zh=小行星`},
		{"SPACE2_SOLAR_WIND", 3, `label=gió Mặt Trời|desc=dòng hạt tích điện phát ra từ Mặt Trời aurora cực quang ảnh hưởng vệ tinh|vi=gió Mặt Trời,solar wind|en=solar wind|zh=太阳风`},

		// ── NÔNG NGHIỆP THÊM (AGR2_) ─────────────────────────────
		{"AGR2_PRECISION",   3, `label=nông nghiệp chính xác|desc=ứng dụng công nghệ GPS drone cảm biến AI tối ưu hóa sản lượng giảm lãng phí|vi=nông nghiệp chính xác,precision agriculture|en=precision agriculture|zh=精准农业`},
		{"AGR2_GMO",         3, `label=cây trồng biến đổi gen|desc=sinh vật có gen được chỉnh sửa GMO kháng sâu bệnh năng suất cao tranh cãi an toàn|vi=cây trồng biến đổi gen,GMO|en=GMO,genetically modified|zh=转基因作物`},
		{"AGR2_VERTICAL",    3, `label=nông nghiệp thẳng đứng|desc=trồng cây trong nhà nhiều tầng đèn LED thủy canh kiểm soát hoàn toàn môi trường|vi=nông nghiệp thẳng đứng,vertical farming|en=vertical farming|zh=垂直农业`},

		// ── SỨC KHỎE TÂM THẦN (PSYCH2_) ─────────────────────────
		{"PSYCH2_ANXIETY",   3, `label=lo âu|desc=rối loạn lo âu cảm giác sợ hãi quá mức không tương xứng với mối đe dọa thực tế điều trị liệu pháp|vi=lo âu,anxiety,rối loạn lo âu|en=anxiety disorder|zh=焦虑症`},
		{"PSYCH2_DEPRESSION",3, `label=trầm cảm|desc=rối loạn tâm thần buồn bã dai dẳng mất hứng thú WHO 280 triệu người thuốc chống trầm cảm|vi=trầm cảm,depression|en=depression|zh=抑郁症`},
		{"PSYCH2_MINDFULNESS",3,`label=chánh niệm|desc=thực hành chú ý vào hiện tại không phán xét giảm stress thiền định MBSR sức khỏe tâm lý|vi=chánh niệm,mindfulness,thiền|en=mindfulness,meditation|zh=正念`},

		// ── VĂN HÓA / XÃ HỘI (CULT_) ────────────────────────────
		{"CULT_FESTIVAL",    3, `label=lễ hội|desc=sự kiện văn hóa cộng đồng kỷ niệm truyền thống Tết Nguyên Đán Diwali Christmas Carnival|vi=lễ hội,festival,Tết|en=festival|zh=节日`},
		{"CULT_LANGUAGE_DIV",3, `label=đa dạng ngôn ngữ|desc=7000 ngôn ngữ trên thế giới nguy cơ tuyệt chủng bảo tồn UNESCO đa ngôn ngữ văn hóa|vi=đa dạng ngôn ngữ,language diversity|en=language diversity|zh=语言多样性`},
		{"CULT_HERITAGE",    3, `label=di sản văn hóa|desc=tài sản vật thể phi vật thể truyền từ quá khứ UNESCO bảo tồn Angkor Vịnh Hạ Long|vi=di sản văn hóa,cultural heritage|en=cultural heritage|zh=文化遗产`},
		{"CULT_GLOBALIZATION",3,`label=toàn cầu hóa văn hóa|desc=lan rộng ý tưởng phong tục giá trị qua biên giới K-pop Hollywood đồng nhất hóa văn hóa|vi=toàn cầu hóa văn hóa,cultural globalization|en=cultural globalization|zh=文化全球化`},

		// ── NĂNG LƯỢNG THÊM (ENRG2_) ─────────────────────────────
		{"ENRG2_HYDROGEN",   3, `label=hydro xanh|desc=nhiên liệu sạch từ điện phân nước dùng điện tái tạo không phát thải CO2 pin nhiên liệu|vi=hydro xanh,green hydrogen|en=green hydrogen|zh=绿氢`},
		{"ENRG2_NUCLEAR_NEW",3, `label=điện hạt nhân thế hệ mới|desc=lò phản ứng hạt nhân thế hệ IV an toàn hơn SMR lò mô-đun nhỏ phát thải thấp|vi=điện hạt nhân mới,SMR,nuclear power|en=next-gen nuclear,SMR|zh=新一代核电`},
		{"ENRG2_GRID",       3, `label=lưới điện thông minh|desc=hệ thống phân phối điện tích hợp cảm biến AI cân bằng cung cầu tích hợp năng lượng tái tạo|vi=lưới điện thông minh,smart grid|en=smart grid|zh=智能电网`},

		// ── TOÁN HỌC THÊM (MATH2_) ───────────────────────────────
		{"MATH2_PROBABILITY", 3, `label=xác suất|desc=thước đo khả năng xảy ra sự kiện Bayes Monte Carlo thống kê suy diễn học máy|vi=xác suất,probability|en=probability|zh=概率`},
		{"MATH2_TOPOLOGY",    3, `label=tô pô học|desc=nhánh toán học nghiên cứu tính chất bất biến dưới biến dạng liên tục Möbius Klein đa tạp|vi=tô pô học,topology|en=topology|zh=拓扑学`},
		{"MATH2_GRAPH",       3, `label=lý thuyết đồ thị|desc=nghiên cứu đồ thị gồm đỉnh và cạnh mạng xã hội GPS tối ưu hóa bài toán NP|vi=lý thuyết đồ thị,graph theory|en=graph theory|zh=图论`},

		// ── VẬT LÝ THÊM (PHYS2_) ─────────────────────────────────
		{"PHYS2_QUANTUM",    3, `label=cơ học lượng tử|desc=mô tả vật lý ở quy mô nguyên tử hạt nhân xác suất chồng chất rối lượng tử Heisenberg|vi=cơ học lượng tử,quantum mechanics|en=quantum mechanics|zh=量子力学`},
		{"PHYS2_RELATIVITY", 3, `label=thuyết tương đối|desc=Einstein không-thời gian cong E=mc² giãn thời gian GPS cần hiệu chỉnh tương đối tính|vi=thuyết tương đối,relativity|en=relativity,Einstein|zh=相对论`},
		{"PHYS2_PLASMA",     3, `label=plasma|desc=trạng thái thứ tư của vật chất khí ion hóa nhiệt độ cực cao Mặt Trời phản ứng nhiệt hạch|vi=plasma|en=plasma|zh=等离子体`},

		// ── Y TẾ THÊM (MED2_) ────────────────────────────────────
		{"MED2_SURGERY",     3, `label=phẫu thuật|desc=can thiệp y tế xâm lấn bằng dụng cụ robot nội soi tim mạch thần kinh ghép tạng|vi=phẫu thuật,surgery|en=surgery|zh=外科手术`},
		{"MED2_VACCINE",     3, `label=vaccine|desc=chế phẩm sinh học kích hoạt miễn dịch chống bệnh truyền nhiễm COVID-19 mRNA Pasteur Jenner|vi=vaccine,vắc-xin|en=vaccine|zh=疫苗`},
		{"MED2_TELEMEDICINE",3, `label=y tế từ xa|desc=cung cấp dịch vụ y tế qua internet video call tư vấn bác sĩ từ xa AI chẩn đoán|vi=y tế từ xa,telemedicine|en=telemedicine|zh=远程医疗`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"TECH2_ROBOTICS",    "TECH_AI",           "uses"},
		{"TECH2_QUANTUM",     "PHYS2_QUANTUM",     "applies"},
		{"TECH2_DRONE2",      "AGR2_PRECISION",    "enables"},
		{"SPACE2_BLACKHOLE",  "PHYS2_RELATIVITY",  "confirmed-by"},
		{"AGR2_PRECISION",    "TECH_AI",           "powered-by"},
		{"AGR2_GMO",          "BIO_GENETICS",      "uses"},
		{"PSYCH2_ANXIETY",    "PSYCH2_MINDFULNESS","treated-by"},
		{"PSYCH2_DEPRESSION", "ANAT_BRAIN",        "involves"},
		{"CULT_HERITAGE",     "PLACE_VIET_NAM",    "includes"},
		{"ENRG2_HYDROGEN",    "ENERGY_RENEWABLE",  "uses"},
		{"ENRG2_GRID",        "ENERGY_SOLAR",      "integrates"},
		{"MATH2_PROBABILITY", "TECH_ML",           "foundation-of"},
		{"MATH2_GRAPH",       "DIG_INTERNET",      "models"},
		{"PHYS2_QUANTUM",     "TECH2_QUANTUM",     "basis-of"},
		{"PHYS2_RELATIVITY",  "SPACE2_BLACKHOLE",  "predicts"},
		{"MED2_VACCINE",      "ANAT_IMMUNE",       "trains"},
		{"MED2_SURGERY",      "TECH2_ROBOTICS",    "enhanced-by"},
		{"MED2_TELEMEDICINE", "DIG_INTERNET",      "uses"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); ne := be32(raw[16:20])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, ne)
	if nn >= 2300 { fmt.Println("🎉 MILESTONE 2300+ ĐẠT!") }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"uses":1,"applies":2,"enables":3,"confirmed-by":4,"powered-by":5,
		"treats":6,"involves":7,"includes":8,"integrates":9,"foundation-of":10,
		"models":11,"basis-of":12,"predicts":13,"trains":14,"enhanced-by":15,
		"treated-by":16,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
