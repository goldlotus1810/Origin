//go:build ignore
// seed_milestone4800.go — MILESTONE 4800 — 100 nodes
// Domains: IMMUNOL4_ CANCER2_ AGING2_ MICROBIOME3_ GENOMICS2_
//          PHILOSOPHY4_ LOGIC2_ ONTOLOGY_ PHENOMENOLOGY_ PRAGMATISM_
//          ARCHITECTURE3_ STRUCTURAL_ ACOUSTIC_ THERMAL_ FACADE_
//          SUPPLY_CHAIN_ OPERATIONS_ QUALITY_ LEAN_ SIX_SIGMA_
//          VNARCH_ VNDESIGN_ VNCRAFT2_ VNMUSIC2_ VNFILM2_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── IMMUNOLOGY 4 ─────────────────────────────────────────────
		{"IMMUNOL4_CHECKPOINT",  3,`label=liệu pháp ức chế checkpoint|desc=checkpoint inhibitor PD-1 PD-L1 CTLA-4 ipilimumab pembrolizumab nivolumab immune-related adverse|vi=liệu pháp ức chế checkpoint,checkpoint inhibitor|en=checkpoint inhibitor`},
		{"IMMUNOL4_CAR_T",       3,`label=liệu pháp CAR-T|desc=CAR-T cell therapy chimeric antigen receptor CD19 B cell leukemia lymphoma cytokine storm manufacturing cost|vi=liệu pháp CAR-T,CAR-T therapy|en=CAR-T therapy`},
		{"IMMUNOL4_INNATE",      3,`label=miễn dịch bẩm sinh|desc=innate immunity pattern recognition TLR NLR NLRP3 inflammasome DAMP PAMP macrophage NK cell|vi=miễn dịch bẩm sinh,innate immunity|en=innate immunity`},
		{"IMMUNOL4_TOLERANCE",   3,`label=dung nạp miễn dịch|desc=immune tolerance central peripheral regulatory T cell Treg anergy clonal deletion self autoimmune|vi=dung nạp miễn dịch,immune tolerance|en=immune tolerance`},
		{"CANCER2_LIQUID_BIOPSY",3,`label=sinh thiết lỏng|desc=liquid biopsy ctDNA circulating tumor cells cfDNA methylation early detection Guardant Grail MCED|vi=sinh thiết lỏng,liquid biopsy|en=liquid biopsy`},

		// ── CANCER 2 & AGING ─────────────────────────────────────────
		{"CANCER2_METABOLISM",   3,`label=trao đổi chất ung thư|desc=cancer metabolism Warburg effect aerobic glycolysis glutamine IDH mutation TCA cycle HIF-1alpha|vi=trao đổi chất ung thư,cancer metabolism|en=cancer metabolism`},
		{"CANCER2_MICROENV",     3,`label=vi môi trường khối u|desc=tumor microenvironment TME stromal fibroblast myeloid suppressor angiogenesis hypoxia immunotherapy|vi=vi môi trường khối u,tumor microenvironment|en=tumor microenvironment`},
		{"AGING2_HALLMARKS",     3,`label=đặc điểm lão hóa|desc=hallmarks of aging Lopez-Otin telomere attrition genomic instability proteostasis senescence NAD+ decline|vi=đặc điểm lão hóa,hallmarks of aging|en=hallmarks of aging`},
		{"AGING2_LONGEVITY",     3,`label=khoa học trường thọ|desc=longevity science Bryan Johnson Altos Labs Calico rapamycin senolytics epigenetic clock Horvath age|vi=khoa học trường thọ,longevity science|en=longevity science`},
		{"AGING2_SENESCENCE",    3,`label=lão hóa tế bào|desc=cellular senescence p16 p21 SASP senescence-associated secretory phenotype senolytics dasatinib quercetin|vi=lão hóa tế bào,cellular senescence|en=cellular senescence`},

		// ── MICROBIOME 3 & GENOMICS 2 ────────────────────────────────
		{"MICROBIOME3_BRAIN",    3,`label=trục ruột-não|desc=gut-brain axis microbiome vagus nerve serotonin GABA SCFAs depression anxiety psychobiotics FMT|vi=trục ruột-não,gut-brain axis|en=gut-brain axis`},
		{"MICROBIOME3_CANCER",   3,`label=vi khuẩn và ung thư|desc=microbiome cancer Fusobacterium colorectal Helicobacter gastric intratumoral immunotherapy response|vi=vi khuẩn và ung thư,microbiome cancer|en=microbiome cancer`},
		{"GENOMICS2_SINGLE_CELL",3,`label=giải trình tự đơn bào|desc=single-cell sequencing scRNA-seq ATAC spatial transcriptomics Visium 10x cell atlas heterogeneity|vi=giải trình tự đơn bào,single-cell sequencing|en=single-cell sequencing`},
		{"GENOMICS2_EPIGENOME",  3,`label=hệ gen biểu sinh|desc=epigenome DNA methylation histone modification chromatin accessibility ENCODE ChIP-seq ATAC-seq|vi=hệ gen biểu sinh,epigenome|en=epigenome`},
		{"GENOMICS2_PROTEOMICS", 3,`label=hệ protein học|desc=proteomics mass spectrometry TMT iTRAQ DIA phosphoproteomics protein-protein interaction network|vi=hệ protein học,proteomics|en=proteomics`},

		// ── PHILOSOPHY 4 ─────────────────────────────────────────────
		{"PHILOSOPHY4_MIND",     3,`label=triết học tâm trí|desc=philosophy of mind hard problem consciousness qualia Mary's room zombie Chalmers Dennett eliminativism|vi=triết học tâm trí,philosophy of mind|en=philosophy of mind`},
		{"PHILOSOPHY4_LANGUAGE", 3,`label=triết học ngôn ngữ|desc=philosophy of language reference meaning Frege Russell Wittgenstein speech act Kripke Saul possible worlds|vi=triết học ngôn ngữ,philosophy of language|en=philosophy of language`},
		{"PHILOSOPHY4_SCIENCE",  3,`label=triết học khoa học|desc=philosophy of science Kuhn paradigm Popper falsifiability Lakatos research programme underdetermination|vi=triết học khoa học,philosophy of science|en=philosophy of science`},
		{"LOGIC2_MODAL",         3,`label=logic tình thái|desc=modal logic possible worlds necessity contingency S4 S5 Kripke semantics temporal deontic epistemic|vi=logic tình thái,modal logic|en=modal logic`},
		{"LOGIC2_PARA",          3,`label=logic phi cổ điển|desc=paraconsistent logic dialetheism true contradiction relevance logic fuzzy Łukasiewicz multi-valued|vi=logic phi cổ điển,non-classical logic|en=non-classical logic`},

		// ── ONTOLOGY & PHENOMENOLOGY ──────────────────────────────────
		{"ONTOLOGY_PROCESS",     3,`label=bản thể học quá trình|desc=process ontology Whitehead actual occasion becoming event flux Bergson duration organism philosophy|vi=bản thể học quá trình,process ontology|en=process ontology`},
		{"ONTOLOGY_SOCIAL",      3,`label=bản thể học xã hội|desc=social ontology collective intentionality Searle institutional reality Bratman group agency plural|vi=bản thể học xã hội,social ontology|en=social ontology`},
		{"PHENOMENOLOGY_HUSSERL",3,`label=hiện tượng học Husserl|desc=phenomenology Husserl intentionality epoché noesis noema lifeworld intersubjectivity bracketing reduction|vi=hiện tượng học Husserl,phenomenology Husserl|en=phenomenology Husserl`},
		{"PHENOMENOLOGY_HEIDEG", 3,`label=hiện tượng học Heidegger|desc=Heidegger Being Time Dasein thrownness care ready-to-hand present-at-hand anxiety authenticity|vi=hiện tượng học Heidegger,Heidegger Being|en=Heidegger Being`},
		{"PRAGMATISM_CLASSIC",   3,`label=chủ nghĩa thực dụng|desc=pragmatism Peirce James Dewey inquiry meaning truth warranted assertibility experience consequences|vi=chủ nghĩa thực dụng,pragmatism|en=pragmatism`},

		// ── ARCHITECTURE 3 ────────────────────────────────────────────
		{"ARCHITECTURE3_PARAM",  3,`label=kiến trúc tham số|desc=parametric architecture Zaha Hadid Grasshopper Rhino generative computational form-finding optimization|vi=kiến trúc tham số,parametric architecture|en=parametric architecture`},
		{"ARCHITECTURE3_SUSTAIN",3,`label=kiến trúc bền vững|desc=sustainable architecture passive solar green roof LEED BREEAM net zero Passivhaus embodied carbon|vi=kiến trúc bền vững,sustainable architecture|en=sustainable architecture`},
		{"STRUCTURAL_SEISMIC",   3,`label=kết cấu chịu động đất|desc=seismic structural base isolation damper ductility design spectrum pushover IDA performance based|vi=kết cấu chịu động đất,seismic structural|en=seismic structural`},
		{"ACOUSTIC_ROOM",        3,`label=âm học phòng|desc=room acoustics RT60 reverberation absorption diffusion concert hall speech intelligibility STI noise criterion|vi=âm học phòng,room acoustics|en=room acoustics`},
		{"FACADE_PERFORMANCE",   3,`label=mặt dựng hiệu năng|desc=facade performance unitized curtain wall double skin thermal solar gain g-value Uw daylight glare|vi=mặt dựng hiệu năng,facade performance|en=facade performance`},

		// ── SUPPLY CHAIN & OPERATIONS ─────────────────────────────────
		{"SUPPLY_CHAIN_RESILIENCE",3,`label=chuỗi cung ứng linh hoạt|desc=supply chain resilience nearshoring friendshoring dual source inventory safety stock bullwhip risk|vi=chuỗi cung ứng linh hoạt,supply chain resilience|en=supply chain resilience`},
		{"SUPPLY_CHAIN_DIGITAL",  3,`label=số hóa chuỗi cung ứng|desc=digital supply chain control tower visibility IoT tracking digital twin demand sensing AI forecast|vi=số hóa chuỗi cung ứng,digital supply chain|en=digital supply chain`},
		{"OPERATIONS_SCHEDULING", 3,`label=lập lịch vận hành|desc=operations scheduling job shop flow shop makespan tardiness Johnson algorithm branch bound heuristic|vi=lập lịch vận hành,operations scheduling|en=operations scheduling`},
		{"LEAN_MFGR",            3,`label=sản xuất tinh gọn|desc=lean manufacturing Toyota Production System waste muda kanban just-in-time heijunka jidoka poka-yoke|vi=sản xuất tinh gọn,lean manufacturing|en=lean manufacturing`},
		{"SIX_SIGMA_DMAIC",      3,`label=Six Sigma|desc=Six Sigma DMAIC define measure analyze improve control DPMO process capability Cpk belt certification|vi=Six Sigma,Six Sigma DMAIC|en=Six Sigma DMAIC`},

		// ── QUALITY & THERMAL ─────────────────────────────────────────
		{"QUALITY_RELIABILITY",  3,`label=độ tin cậy kỹ thuật|desc=reliability engineering MTBF MTTR failure mode FMEA FTA Weibull analysis accelerated life test|vi=độ tin cậy kỹ thuật,reliability engineering|en=reliability engineering`},
		{"QUALITY_ISO",          3,`label=hệ thống quản lý chất lượng|desc=quality management ISO 9001 ISO 14001 ISO 45001 IATF 16949 audit nonconformity corrective action|vi=hệ thống quản lý chất lượng,quality management ISO|en=quality management ISO`},
		{"THERMAL_HEAT_TRANSFER",3,`label=truyền nhiệt|desc=heat transfer conduction convection radiation Fourier Newton Stefan-Boltzmann fin PCM thermal resistance|vi=truyền nhiệt,heat transfer|en=heat transfer`},
		{"THERMAL_HVAC2",        3,`label=điều hòa không khí nâng cao|desc=HVAC advanced variable refrigerant flow VRF chiller COP psychrometric duct CFD IAQ energy modeling|vi=điều hòa không khí nâng cao,advanced HVAC|en=advanced HVAC`},
		{"ACOUSTIC_NOISE_CTRL",  3,`label=kiểm soát tiếng ồn|desc=noise control sound transmission loss STC IIC vibration isolation resilient mount HVAC duct attenuation|vi=kiểm soát tiếng ồn,noise control|en=noise control`},

		// ── VIETNAM: ARCHITECTURE, DESIGN, CRAFT ─────────────────────
		{"VNARCH_TRADITIONAL",   3,`label=kiến trúc truyền thống Việt Nam|desc=kiến trúc truyền thống Việt Nam đình làng chùa nhà rường Huế nhà phố Hội An gỗ mái cong|vi=kiến trúc truyền thống Việt Nam,traditional Vietnamese architecture|en=traditional Vietnamese architecture`},
		{"VNARCH_FRENCH_INDO",   3,`label=kiến trúc Pháp Đông Dương|desc=kiến trúc Pháp Đông Dương Bưu điện TP HCM nhà hát lớn Hà Nội art deco tropical colonial|vi=kiến trúc Pháp Đông Dương,French Indochina architecture|en=French Indochina architecture`},
		{"VNARCH_MODERN",        3,`label=kiến trúc hiện đại Việt Nam|desc=kiến trúc hiện đại Việt Nam Võ Trọng Nghĩa tre bamboo Farming Kindergarten Nocenco Café|vi=kiến trúc hiện đại Việt Nam,modern Vietnamese architecture|en=modern Vietnamese architecture`},
		{"VNDESIGN_GRAPHIC",     3,`label=thiết kế đồ họa Việt Nam|desc=thiết kế đồ họa Việt Nam branding packaging truyền thông visual identity studio agency xu hướng|vi=thiết kế đồ họa Việt Nam,Vietnamese graphic design|en=Vietnamese graphic design`},
		{"VNDESIGN_FASHION",     3,`label=thời trang Việt Nam|desc=thời trang Việt Nam Minh Hạnh Cong Tri Chung Thanh Phong áo dài hiện đại xuất khẩu thị trường|vi=thời trang Việt Nam,Vietnamese fashion|en=Vietnamese fashion`},

		// ── VIETNAM MUSIC & FILM ──────────────────────────────────────
		{"VNMUSIC2_TRADITIONAL", 3,`label=âm nhạc truyền thống Việt Nam|desc=âm nhạc truyền thống Việt Nam đàn tranh bầu tỳ bà ca trù hát xẩm nhã nhạc Huế UNESCO|vi=âm nhạc truyền thống Việt Nam,traditional Vietnamese music|en=traditional Vietnamese music`},
		{"VNMUSIC2_VPOP",        3,`label=Vpop và âm nhạc đương đại|desc=Vpop Việt Nam Sơn Tùng MTP BLACKPINK ảnh hưởng streaming Spotify indie underground lyrics|vi=Vpop và âm nhạc đương đại,Vpop Vietnamese pop|en=Vpop Vietnamese pop`},
		{"VNFILM2_NEW_WAVE",     3,`label=điện ảnh Việt Nam mới|desc=điện ảnh Việt Nam mới Victor Vũ Phan Gia Nhật Linh Hai Phượng Bố Già coproduction thị trường|vi=điện ảnh Việt Nam mới,new Vietnamese cinema|en=new Vietnamese cinema`},
		{"VNFILM2_ANIMATION",    3,`label=hoạt hình Việt Nam|desc=hoạt hình Việt Nam Paprika studio Colory Animation outsource Disney Netflix nội địa phát triển|vi=hoạt hình Việt Nam,Vietnamese animation|en=Vietnamese animation`},
		{"VNCRAFT2_EMBROIDERY",  3,`label=thêu thủ công Việt Nam|desc=thêu thủ công Việt Nam thêu ren Văn Lâm Ninh Hải xuất khẩu thêu tay cao cấp thời trang|vi=thêu thủ công Việt Nam,Vietnamese embroidery|en=Vietnamese embroidery`},

		// ── MISC STRONG NODES ─────────────────────────────────────────
		{"AGING2_DEMOGRAPH",     3,`label=dân số già và xã hội|desc=demographic ageing dependency ratio pension burden Japan Korea Italy social care immigrant workforce|vi=dân số già và xã hội,demographic ageing|en=demographic ageing`},
		{"CANCER2_PREVENTION",   3,`label=phòng ngừa ung thư|desc=cancer prevention HPV vaccine HBV colorectal screening mammography tobacco cessation obesity weight|vi=phòng ngừa ung thư,cancer prevention|en=cancer prevention`},
		{"MICROBIOME3_DIET",     3,`label=chế độ ăn và vi khuẩn đường ruột|desc=diet microbiome fiber fermented food Mediterranean ultra-processed dysbiosis diversity species richness|vi=chế độ ăn và vi khuẩn đường ruột,diet microbiome|en=diet microbiome`},
		{"GENOMICS2_GWAS",       3,`label=nghiên cứu liên kết toàn bộ hệ gen|desc=GWAS genome-wide association polygenic risk score PRS common variant rare variant biobank UK|vi=nghiên cứu liên kết toàn bộ hệ gen,GWAS|en=GWAS`},
		{"PHILOSOPHY4_FREE_WILL",3,`label=ý chí tự do|desc=free will compatibilism incompatibilism determinism libertarianism Frankfurt cases manipulation argument|vi=ý chí tự do,free will|en=free will`},

		{"ONTOLOGY_INFO",        3,`label=bản thể học thông tin|desc=information ontology Floridi levels of abstraction semantic information veridicality environmental|vi=bản thể học thông tin,information ontology|en=information ontology`},
		{"PRAGMATISM_NEO",       3,`label=tân thực dụng chủ nghĩa|desc=neopragmatism Rorty anti-foundationalism solidarity contingency irony liberal hope truth as tool|vi=tân thực dụng chủ nghĩa,neopragmatism|en=neopragmatism`},
		{"ARCHITECTURE3_CLIMATE",3,`label=kiến trúc ứng phó khí hậu|desc=climate-responsive architecture bioclimatic vernacular passive cooling natural ventilation solar shading|vi=kiến trúc ứng phó khí hậu,climate-responsive architecture|en=climate-responsive architecture`},
		{"STRUCTURAL_TALL",      3,`label=công trình cao tầng|desc=tall building outrigger diagrid tube-in-tube wind load vortex shedding tuned mass damper floor vibration|vi=công trình cao tầng,tall building|en=tall building`},
		{"SUPPLY_CHAIN_CIRCULAR",3,`label=chuỗi cung ứng tuần hoàn|desc=circular supply chain reverse logistics take-back end-of-life refurbish remanufacture closed loop|vi=chuỗi cung ứng tuần hoàn,circular supply chain|en=circular supply chain`},

		{"LEAN_SERVICE",         3,`label=tinh gọn trong dịch vụ|desc=lean service value stream mapping healthcare hospital ED flow patient journey waste rework|vi=tinh gọn trong dịch vụ,lean service|en=lean service`},
		{"SIX_SIGMA_DESIGN",     3,`label=Design for Six Sigma|desc=DFSS Design for Six Sigma DMADV IDOV QFD House of Quality CTQ transfer function tolerance|vi=Design for Six Sigma,DFSS|en=Design for Six Sigma`},
		{"THERMAL_DATA_CENTER",  3,`label=làm mát trung tâm dữ liệu|desc=data center cooling PUE liquid immersion direct liquid rear door airflow containment hot cold aisle|vi=làm mát trung tâm dữ liệu,data center cooling|en=data center cooling`},
		{"FACADE_SMART",         3,`label=mặt dựng thông minh|desc=smart facade electrochromic photovoltaic BIPV kinetic adaptive shading sensor actuator daylight control|vi=mặt dựng thông minh,smart facade|en=smart facade`},
		{"VNDESIGN_INTERIOR",    3,`label=thiết kế nội thất Việt Nam|desc=thiết kế nội thất Việt Nam phong cách Indochine hiện đại Đông phương gỗ tự nhiên thủ công|vi=thiết kế nội thất Việt Nam,Vietnamese interior design|en=Vietnamese interior design`},

		{"VNMUSIC2_FOLK",        3,`label=âm nhạc dân gian Việt Nam|desc=âm nhạc dân gian Việt Nam quan họ hát then dân ca vùng miền bảo tồn UNESCO trẻ hóa|vi=âm nhạc dân gian Việt Nam,Vietnamese folk music|en=Vietnamese folk music`},
		{"VNCRAFT2_CONICAL_HAT", 3,`label=nón lá Việt Nam|desc=nón lá Việt Nam Huế lá buông thêu thơ làng Chuông xuất khẩu biểu tượng văn hóa bảo tồn|vi=nón lá Việt Nam,Vietnamese conical hat|en=Vietnamese conical hat`},
		{"IMMUNOL4_VACCINE_ADJ", 3,`label=tá dược vaccine|desc=vaccine adjuvant alum AS01 AS03 MF59 TLR agonist ISCOM mRNA LNP innate immune training|vi=tá dược vaccine,vaccine adjuvant|en=vaccine adjuvant`},
		{"CANCER2_PRECISION",    3,`label=ung thư học chính xác|desc=precision oncology TCGA TMB MSI biomarker companion diagnostic targeted therapy basket umbrella trial|vi=ung thư học chính xác,precision oncology|en=precision oncology`},
		{"GENOMICS2_PANGENOME",  3,`label=hệ gen toàn dân|desc=pangenome reference graph genome variation structural SV T2T telomere-to-telomere CHM13 diversity|vi=hệ gen toàn dân,pangenome|en=pangenome`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 4800 { fmt.Println(" MILESTONE 4800! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
