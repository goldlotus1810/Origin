//go:build ignore

// scripts/seed_milestone3500.go
// MILESTONE 3500 — 100 nodes mới
// Domains: QUANTUM_ BLOCKCHAIN_ CLIMATE2_ NEUROSCI_ GENOMICS_
//          MEDIEVAL_ COLONIAL_ RENAISSANCE2_ INDO_ ROMAN2_
//          FUNGI_ VIRUS_ MARINE3_ ARCTIC_ DESERT_
//          STARTUP_ INVEST2_ MARKET2_ TAX_ AUDIT_
//          PHILOS2_ COGN2_ LANG3_ SIGNAL_ THERMO_
//          VNHIST2_ VNLIT_ VNSCI_ VNEDU_ VNARCH_

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24 // 280

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	existing := readNames(raw)

	type nodeDef struct { name string; layer uint8; dna string }
	nodes := []nodeDef{

		// ── QUANTUM PHYSICS (QUANTUM_) ──────────────────────────────
		{"QUANTUM_SUPERPOSITION", 3, `label=chồng chất lượng tử|desc=superposition Schrödinger cat qubit |0⟩+|1⟩ collapse on measurement wavefunction Copenhagen interpretation|vi=chồng chất lượng tử,superposition|en=quantum superposition`},
		{"QUANTUM_ENTANGLEMENT",  3, `label=vướng víu lượng tử|desc=entanglement EPR paradox Bell inequality spooky action at distance quantum teleportation non-local correlation|vi=vướng víu lượng tử,entanglement|en=quantum entanglement`},
		{"QUANTUM_TUNNELING",     3, `label=xuyên hầm lượng tử|desc=quantum tunneling barrier penetration alpha decay scanning tunneling microscope flash memory nuclear fusion stars|vi=xuyên hầm lượng tử,quantum tunneling|en=quantum tunneling`},
		{"QUANTUM_COMPUTING",     3, `label=máy tính lượng tử|desc=quantum computing qubit gate Shor algorithm Grover RSA break IBM Google quantum advantage NISQ era|vi=máy tính lượng tử,quantum computing|en=quantum computing`},
		{"QUANTUM_DECOHERENCE",   3, `label=giải kết hợp lượng tử|desc=decoherence environment interaction quantum-to-classical transition error correction noise threshold fault-tolerant quantum computing|vi=giải kết hợp lượng tử|en=decoherence`},

		// ── BLOCKCHAIN & WEB3 (BLOCKCHAIN_) ────────────────────────
		{"BLOCKCHAIN_BASICS",     3, `label=chuỗi khối|desc=blockchain distributed ledger SHA256 hash chain consensus PoW PoS immutable append-only Satoshi Nakamoto Bitcoin 2009|vi=chuỗi khối,blockchain|en=blockchain`},
		{"BLOCKCHAIN_SMART",      3, `label=hợp đồng thông minh|desc=smart contract Ethereum Solidity EVM self-executing code DeFi dApp token ERC-20 ERC-721 NFT|vi=hợp đồng thông minh,smart contract|en=smart contract`},
		{"BLOCKCHAIN_CONSENSUS",  3, `label=cơ chế đồng thuận|desc=consensus mechanism PoW proof of work PoS proof of stake validator Byzantine fault BFT PBFT Nakamoto consensus|vi=cơ chế đồng thuận,consensus|en=consensus mechanism`},
		{"BLOCKCHAIN_DEFI",       3, `label=tài chính phi tập trung|desc=DeFi decentralized finance AMM liquidity pool yield farming Uniswap Aave Compound stablecoin DAI TVL|vi=tài chính phi tập trung,DeFi|en=DeFi`},
		{"BLOCKCHAIN_LAYER2",     3, `label=giải pháp layer 2|desc=Layer 2 scaling rollup optimistic ZK-proof Lightning Network Polygon Arbitrum Optimism state channel plasma sidechain|vi=giải pháp layer 2,Layer 2|en=Layer 2`},

		// ── CLIMATE SCIENCE 2 (CLIMATE2_) ──────────────────────────
		{"CLIMATE2_TIPPING",      3, `label=điểm tới hạn khí hậu|desc=tipping point AMOC shutdown permafrost methane ice sheet collapse Amazon dieback 1.5°C 2°C threshold irreversible|vi=điểm tới hạn khí hậu,tipping point|en=climate tipping point`},
		{"CLIMATE2_CARBON",       3, `label=thị trường carbon|desc=carbon market ETS cap-and-trade carbon price offset CDM REDD+ net zero carbon neutral scope 1 2 3 EU ETS|vi=thị trường carbon,carbon market|en=carbon market`},
		{"CLIMATE2_SOLAR_GEO",    3, `label=địa kỹ thuật mặt trời|desc=solar geoengineering stratospheric aerosol injection marine cloud brightening SAI SRM risk governance side effect|vi=địa kỹ thuật mặt trời,solar geoengineering|en=solar geoengineering`},
		{"CLIMATE2_ADAPT",        3, `label=thích ứng biến đổi khí hậu|desc=climate adaptation resilience sea wall managed retreat heat action plan drought crop insurance green infrastructure|vi=thích ứng khí hậu,climate adaptation|en=climate adaptation`},
		{"CLIMATE2_OCEAN_ACID",   3, `label=axit hóa đại dương|desc=ocean acidification CO2 absorption pH decrease coral bleaching shellfish dissolution pteropod carbonate chemistry aragonite saturation|vi=axit hóa đại dương,ocean acidification|en=ocean acidification`},

		// ── NEUROSCIENCE (NEUROSCI_) ────────────────────────────────
		{"NEUROSCI_NEUROPLAST",   3, `label=tính dẻo thần kinh|desc=neuroplasticity Hebb rule synaptic plasticity LTP LTD BDNF adult neurogenesis learning motor rehab stroke recovery|vi=tính dẻo thần kinh,neuroplasticity|en=neuroplasticity`},
		{"NEUROSCI_MEMORY",       3, `label=trí nhớ và não|desc=memory hippocampus consolidation sleep encoding retrieval episodic semantic procedural working memory forgetting Ebbinghaus|vi=trí nhớ và não,memory neuroscience|en=memory neuroscience`},
		{"NEUROSCI_DOPAMINE",     3, `label=dopamine hệ thống thưởng|desc=dopamine reward prediction error nucleus accumbens VTA addiction motivation pleasure seeking behavior reinforcement learning|vi=dopamine hệ thống thưởng,dopamine|en=dopamine reward`},
		{"NEUROSCI_SLEEP",        3, `label=giấc ngủ và não|desc=sleep neuroscience REM NREM glymphatic system memory consolidation circadian rhythm adenosine melatonin sleep deprivation cognitive|vi=giấc ngủ và não,sleep neuroscience|en=sleep neuroscience`},
		{"NEUROSCI_PAIN",         3, `label=cơ chế đau|desc=pain nociception gate control theory substance P CGRP central sensitization chronic pain opioid endorphin placebo|vi=cơ chế đau,pain neuroscience|en=pain neuroscience`},

		// ── GENOMICS (GENOMICS_) ────────────────────────────────────
		{"GENOMICS_CRISPR",       3, `label=CRISPR chỉnh sửa gene|desc=CRISPR-Cas9 Jennifer Doudna Emmanuelle Charpentier Nobel 2020 guide RNA gene editing therapeutic germline ethics|vi=CRISPR chỉnh sửa gene,CRISPR|en=CRISPR`},
		{"GENOMICS_EPIGENETICS",  3, `label=biểu sinh học|desc=epigenetics DNA methylation histone modification chromatin remodeling gene expression environment heritable non-sequence|vi=biểu sinh học,epigenetics|en=epigenetics`},
		{"GENOMICS_PROTEOMICS",   3, `label=hệ protein|desc=proteomics mass spectrometry protein folding AlphaFold2 DeepMind structure prediction function disease biomarker drug target|vi=hệ protein,proteomics|en=proteomics`},
		{"GENOMICS_MICROBIOME",   3, `label=hệ vi sinh vật|desc=microbiome gut brain axis 38 trillion bacteria immune mental health prebiotics probiotics dysbiosis FMT fecal transplant|vi=hệ vi sinh vật,microbiome|en=microbiome`},
		{"GENOMICS_CANCER_GEN",   3, `label=di truyền học ung thư|desc=cancer genetics oncogene tumor suppressor mutation somatic germline BRCA1 BRCA2 p53 liquid biopsy ctDNA|vi=di truyền học ung thư,cancer genetics|en=cancer genetics`},

		// ── MEDIEVAL HISTORY (MEDIEVAL_) ────────────────────────────
		{"MEDIEVAL_FEUDAL",       3, `label=chế độ phong kiến|desc=feudalism lord vassal serf manor system oath homage fief knight cavalry hierarchy Europe 9th-15th century|vi=chế độ phong kiến,feudalism|en=feudalism`},
		{"MEDIEVAL_CRUSADE",      3, `label=thập tự chinh|desc=Crusades 1095 Pope Urban II Jerusalem First Crusade Richard Lionheart Saladin fall of Acre 1291 aftermath|vi=thập tự chinh,Crusades|en=Crusades`},
		{"MEDIEVAL_PLAGUE",       3, `label=bệnh dịch hạch đen|desc=Black Death bubonic plague 1347-1351 Yersinia pestis 30-60% Europe population flea rat flagellants labor shortage|vi=bệnh dịch hạch đen,Black Death|en=Black Death`},
		{"MEDIEVAL_ISLAM_MED",    3, `label=y học Hồi giáo trung đại|desc=Islamic medicine Avicenna Ibn Sina Canon of Medicine hospital bimaristan surgery pharmacology optics Alhazen|vi=y học Hồi giáo,Islamic medicine|en=Islamic medicine`},
		{"MEDIEVAL_MONGOL",       3, `label=đế quốc Mông Cổ|desc=Mongol Empire Genghis Khan 1206 largest contiguous Pax Mongolica Silk Road trade Baghdad sack 1258 fragmentation|vi=đế quốc Mông Cổ,Mongol Empire|en=Mongol Empire`},

		// ── COLONIAL HISTORY (COLONIAL_) ────────────────────────────
		{"COLONIAL_SLAVE_TRADE",  3, `label=buôn bán nô lệ|desc=transatlantic slave trade Middle Passage 12.5 million enslaved triangular trade plantation economy abolition Wilberforce|vi=buôn bán nô lệ,slave trade|en=slave trade`},
		{"COLONIAL_INDIA",        3, `label=thực dân Ấn Độ|desc=British India East India Company Sepoy Mutiny 1857 partition 1947 Gandhi non-cooperation independence Nehru|vi=thực dân Ấn Độ,British India|en=British India`},
		{"COLONIAL_AFRICA",       3, `label=phân chia châu Phi|desc=Scramble for Africa Berlin Conference 1884 colonial partition resistance Maji Maji Zulu independence movements|vi=phân chia châu Phi,Africa colonialism|en=Africa colonialism`},
		{"COLONIAL_DECOLONIZE",   3, `label=phi thực dân hóa|desc=decolonization 1945-1975 UN self-determination Bandung 1955 Non-Aligned Movement Cold War proxy independence wave|vi=phi thực dân hóa,decolonization|en=decolonization`},
		{"COLONIAL_LATIN_AM",     3, `label=thuộc địa Mỹ Latin|desc=Latin America Spanish Portuguese colonization Aztec Inca encomienda Bolivar San Martin independence 1810-1826|vi=thuộc địa Mỹ Latin,Latin America colonial|en=Latin America colonial`},

		// ── FUNGI & MICROBIOLOGY (FUNGI_) ──────────────────────────
		{"FUNGI_MYCORRHIZA",      3, `label=nấm cộng sinh rễ|desc=mycorrhiza mutualism plant phosphorus exchange wood wide web mycelium network Suzanne Simard forest communication|vi=nấm cộng sinh rễ,mycorrhiza|en=mycorrhiza`},
		{"FUNGI_FERMENT",         3, `label=lên men nấm men|desc=yeast fermentation Saccharomyces cerevisiae bread beer wine glycolysis ethanol CO2 brewing homebrewing industrial|vi=lên men nấm men,yeast fermentation|en=yeast fermentation`},
		{"FUNGI_ANTIBIOTIC",      3, `label=kháng sinh từ nấm|desc=penicillin Alexander Fleming 1928 Penicillium mold antibiotic revolution World War II resistance AMR mechanisms|vi=kháng sinh từ nấm,penicillin|en=penicillin`},
		{"FUNGI_PSYCHEDELIC",     3, `label=nấm tâm thần|desc=psilocybin mushroom Psilocybe cubensis serotonin 5-HT2A receptor psychedelic therapy depression PTSD clinical trial FDA|vi=nấm tâm thần,psilocybin|en=psilocybin`},
		{"FUNGI_LICHEN",          3, `label=địa y|desc=lichen symbiosis fungi algae cyanobacteria pioneer species rock weathering nitrogen fixation climate indicator air pollution sensitive|vi=địa y,lichen|en=lichen`},

		// ── VIROLOGY (VIRUS_) ───────────────────────────────────────
		{"VIRUS_REPLICATION",     3, `label=sao chép virus|desc=viral replication attachment entry uncoating replication assembly budding lytic lysogenic cycle host cell hijack|vi=sao chép virus,viral replication|en=viral replication`},
		{"VIRUS_IMMUNE_EVASION",  3, `label=virus trốn miễn dịch|desc=immune evasion antigenic drift shift influenza HIV latency herpes reactivation immunosuppression cytokine storm|vi=virus trốn miễn dịch,immune evasion|en=immune evasion`},
		{"VIRUS_MRNA_VACCINE",    3, `label=vaccine mRNA|desc=mRNA vaccine BioNTech Moderna COVID-19 lipid nanoparticle spike protein immune response no DNA integration safety|vi=vaccine mRNA,mRNA vaccine|en=mRNA vaccine`},
		{"VIRUS_ZOONOSIS",        3, `label=bệnh lây từ động vật|desc=zoonosis spillover bat pangolin wet market SARS MERS Ebola HIV avian flu One Health approach surveillance|vi=bệnh lây từ động vật,zoonosis|en=zoonosis`},
		{"VIRUS_BACTERIOPHAGE",   3, `label=thực khuẩn thể|desc=bacteriophage phage therapy antibiotic resistance alternative T4 phage lysogenic lytic CRISPR origin phage display|vi=thực khuẩn thể,bacteriophage|en=bacteriophage`},

		// ── STARTUP & ENTREPRENEURSHIP (STARTUP_) ──────────────────
		{"STARTUP_LEAN",          3, `label=khởi nghiệp tinh gọn|desc=lean startup Eric Ries MVP minimum viable product build-measure-learn pivot validated learning customer discovery|vi=khởi nghiệp tinh gọn,lean startup|en=lean startup`},
		{"STARTUP_FUNDING",       3, `label=gọi vốn khởi nghiệp|desc=startup funding seed angel VC venture capital Series A B C unicorn term sheet valuation dilution cap table|vi=gọi vốn khởi nghiệp,startup funding|en=startup funding`},
		{"STARTUP_PRODUCT_MARKET",3, `label=phù hợp thị trường sản phẩm|desc=product-market fit PMF retention cohort NPS Sean Ellis test 40% very disappointed churn CAC LTV|vi=phù hợp thị trường sản phẩm,product-market fit|en=product-market fit`},
		{"STARTUP_GROWTH_HACK",   3, `label=tăng trưởng đột phá|desc=growth hacking viral loop referral Dropbox Airbnb A/B testing funnel AARRR pirate metrics acquisition retention|vi=tăng trưởng đột phá,growth hacking|en=growth hacking`},
		{"STARTUP_FAILURE",       3, `label=thất bại khởi nghiệp|desc=startup failure 90% cash flow product-market fit wrong founder conflict scaling premature bad timing market|vi=thất bại khởi nghiệp,startup failure|en=startup failure`},

		// ── INVESTMENT (INVEST2_) ───────────────────────────────────
		{"INVEST2_VALUE",         3, `label=đầu tư giá trị|desc=value investing Benjamin Graham Warren Buffett intrinsic value margin of safety P/E P/B moat franchise earnings power|vi=đầu tư giá trị,value investing|en=value investing`},
		{"INVEST2_PORTFOLIO",     3, `label=lý thuyết danh mục|desc=modern portfolio theory Markowitz efficient frontier diversification beta correlation risk-return trade-off Sharpe ratio|vi=lý thuyết danh mục,portfolio theory|en=portfolio theory`},
		{"INVEST2_DERIVATIVES",   3, `label=công cụ phái sinh|desc=derivatives options futures swaps Black-Scholes model hedge speculation leverage underlying Greeks delta gamma theta|vi=công cụ phái sinh,derivatives|en=derivatives`},
		{"INVEST2_ESG",           3, `label=đầu tư ESG|desc=ESG investing environmental social governance impact investing green bond sustainable finance TCFD CSRD EU taxonomy|vi=đầu tư ESG,ESG investing|en=ESG investing`},
		{"INVEST2_REAL_ESTATE",   3, `label=đầu tư bất động sản|desc=real estate investment REIT cap rate NOI cash-on-cash return leverage rental yield property appreciation location|vi=đầu tư bất động sản,real estate|en=real estate investment`},

		// ── THERMODYNAMICS (THERMO_) ────────────────────────────────
		{"THERMO_LAWS",           3, `label=các định luật nhiệt động|desc=thermodynamics zeroth first second third law entropy internal energy enthalpy Gibbs free energy spontaneous|vi=các định luật nhiệt động,thermodynamics laws|en=thermodynamics laws`},
		{"THERMO_ENTROPY",        3, `label=entropy|desc=entropy Boltzmann S=k·lnW disorder arrow of time irreversibility heat death universe Maxwell demon information entropy Shannon|vi=entropy,entropy thermodynamics|en=entropy`},
		{"THERMO_HEAT_ENGINE",    3, `label=động cơ nhiệt|desc=heat engine Carnot cycle efficiency QH-QC/QH steam engine Otto cycle Diesel cycle Brayton turbine refrigeration|vi=động cơ nhiệt,heat engine|en=heat engine`},
		{"THERMO_PHASE",          3, `label=chuyển pha|desc=phase transition solid liquid gas plasma latent heat triple point critical point phase diagram Clausius-Clapeyron order disorder|vi=chuyển pha,phase transition|en=phase transition`},
		{"THERMO_STAT_MECH",      3, `label=cơ học thống kê|desc=statistical mechanics partition function Boltzmann distribution Maxwell-Boltzmann Fermi-Dirac Bose-Einstein ensemble microstate|vi=cơ học thống kê,statistical mechanics|en=statistical mechanics`},

		// ── PHILOSOPHY 2 (PHILOS2_) ─────────────────────────────────
		{"PHILOS2_FREE_WILL",     3, `label=ý chí tự do|desc=free will determinism compatibilism libertarianism hard determinism Libet experiment neuroscience moral responsibility|vi=ý chí tự do,free will|en=free will`},
		{"PHILOS2_CONSCIOUSNESS", 3, `label=ý thức|desc=consciousness hard problem Chalmers qualia Mary's room philosophical zombie IIT Global Workspace Theory phenomenal access|vi=ý thức,consciousness|en=consciousness`},
		{"PHILOS2_ETHICS_AI",     3, `label=đạo đức AI|desc=AI ethics alignment value learning Trolley problem autonomous weapon surveillance bias fairness accountability transparency|vi=đạo đức AI,AI ethics|en=AI ethics`},
		{"PHILOS2_TRANSHUMANISM", 3, `label=chủ nghĩa siêu nhân|desc=transhumanism Nick Bostrom longevity mind upload enhancement genetic engineering singularity Kurzweil posthumanism|vi=chủ nghĩa siêu nhân,transhumanism|en=transhumanism`},
		{"PHILOS2_STOIC_MODERN",  3, `label=triết học khắc kỷ hiện đại|desc=modern Stoicism Ryan Holiday Marcus Aurelius dichotomy control negative visualization memento mori amor fati|vi=triết học khắc kỷ hiện đại,modern Stoicism|en=modern Stoicism`},

		// ── SIGNAL PROCESSING (SIGNAL_) ─────────────────────────────
		{"SIGNAL_FOURIER",        3, `label=biến đổi Fourier|desc=Fourier transform frequency domain Jean-Baptiste Fourier FFT DFT spectrum analysis filter convolution signal decomposition|vi=biến đổi Fourier,Fourier transform|en=Fourier transform`},
		{"SIGNAL_FILTER",         3, `label=bộ lọc tín hiệu|desc=signal filter low-pass high-pass band-pass FIR IIR Butterworth Chebyshev Kalman filter noise reduction|vi=bộ lọc tín hiệu,signal filter|en=signal filter`},
		{"SIGNAL_COMPRESS",       3, `label=nén tín hiệu|desc=signal compression Nyquist sampling theorem MP3 JPEG HEVC codec lossy lossless Shannon entropy rate distortion|vi=nén tín hiệu,signal compression|en=signal compression`},
		{"SIGNAL_RADAR",          3, `label=radar|desc=radar radio detection ranging Doppler effect pulse compression synthetic aperture SAR weather radar air traffic control phased array|vi=radar,radar|en=radar`},
		{"SIGNAL_NEURAL_SIGNAL",  3, `label=tín hiệu thần kinh|desc=neural signal action potential EEG MEG fMRI BOLD electrode BCI brain-computer interface spike sorting LFP|vi=tín hiệu thần kinh,neural signal|en=neural signal`},

		// ── VIETNAMESE HISTORY 2 (VNHIST2_) ─────────────────────────
		{"VNHIST2_HUNG_VUONG",    3, `label=thời Hùng Vương|desc=Hùng Vương Văn Lang Âu Lạc 2879-258 BC bánh chưng bánh dày lễ hội đền Hùng Phú Thọ giỗ tổ quốc|vi=thời Hùng Vương,Hung Vuong|en=Hung Vuong era`},
		{"VNHIST2_TRAN",          3, `label=nhà Trần|desc=nhà Trần 1225-1400 ba lần đánh bại Mông Cổ Trần Hưng Đạo Bạch Đằng Giang 1288 hịch tướng sĩ Trần Nhân Tông Trúc Lâm|vi=nhà Trần,nha Tran|en=Tran Dynasty`},
		{"VNHIST2_LE_LOI",        3, `label=khởi nghĩa Lam Sơn|desc=khởi nghĩa Lam Sơn 1418-1427 Lê Lợi Nguyễn Trãi đánh đuổi quân Minh bình Ngô đại cáo nhà Hậu Lê|vi=khởi nghĩa Lam Sơn,Lam Son uprising|en=Lam Son uprising`},
		{"VNHIST2_NGUYEN",        3, `label=nhà Nguyễn|desc=nhà Nguyễn 1802-1945 Gia Long thống nhất đất nước Huế kinh đô Pháp xâm lược 1858 Bảo Đại thoái vị 1945|vi=nhà Nguyễn,nha Nguyen|en=Nguyen Dynasty`},
		{"VNHIST2_CHIEN_TRANH",   3, `label=chiến tranh Việt Nam|desc=Vietnam War 1955-1975 Hồ Chí Minh Điện Biên Phủ 1954 giải phóng miền Nam 30/4/1975 thống nhất đất nước|vi=chiến tranh Việt Nam,Vietnam War|en=Vietnam War`},

		// ── VIETNAMESE LITERATURE (VNLIT_) ──────────────────────────
		{"VNLIT_TRUYEN_KIEU",     3, `label=Truyện Kiều|desc=Truyện Kiều Nguyễn Du 3254 câu thơ lục bát Thúy Kiều Thúy Vân Kim Trọng Từ Hải tác phẩm đỉnh cao văn học cổ điển|vi=Truyện Kiều,Truyen Kieu|en=Tale of Kieu`},
		{"VNLIT_NAM_QUOC",        3, `label=Nam quốc sơn hà|desc=Nam quốc sơn hà Lý Thường Kiệt 1077 sông Như Nguyệt bài thơ thần tuyên ngôn độc lập đầu tiên Việt Nam|vi=Nam quốc sơn hà,Nam Quoc Son Ha|en=Nam Quoc Son Ha`},
		{"VNLIT_HO_XUAN_HUONG",   3, `label=Hồ Xuân Hương|desc=Hồ Xuân Hương bà chúa thơ Nôm thơ tứ tuyệt đường luật ẩn dụ kép phụ nữ xã hội phong kiến|vi=Hồ Xuân Hương,Ho Xuan Huong|en=Ho Xuan Huong`},
		{"VNLIT_MODERN",          3, `label=văn học hiện đại Việt Nam|desc=văn học hiện đại Nam Quốc 1930s Tự Lực Văn Đoàn Nhất Linh Khái Hưng thơ mới Xuân Diệu Huy Cận|vi=văn học hiện đại Việt Nam,modern Vietnamese lit|en=modern Vietnamese literature`},
		{"VNLIT_WAR_LIT",         3, `label=văn học kháng chiến|desc=văn học kháng chiến Tố Hữu Việt Bắc Bên kia sông Đuống Hoàng Cầm Đất nước Nguyễn Đình Thi Nỗi buồn chiến tranh Bảo Ninh|vi=văn học kháng chiến,war literature|en=Vietnamese war literature`},

		// ── VIETNAMESE ARCHITECTURE (VNARCH_) ──────────────────────
		{"VNARCH_DINH",           3, `label=đình làng|desc=đình làng trung tâm cộng đồng nơi thờ thành hoàng họp dân thờ tổ nghề mái cong đầu đao trụ đồng trụ|vi=đình làng,dinh lang|en=Vietnamese communal house`},
		{"VNARCH_CHUA",           3, `label=chùa Việt Nam|desc=chùa Việt kiến trúc Phật giáo mái ngói đầu đao tháp chuông sân hòa tam quan Một cột Bái Đính Hương|vi=chùa Việt Nam,Vietnamese pagoda|en=Vietnamese pagoda`},
		{"VNARCH_HUE",            3, `label=kiến trúc Huế|desc=kiến trúc cố đô Huế Đại Nội Ngọ Môn Thái Hòa điện lăng tẩm Minh Mạng Khải Định UNESCO 1993|vi=kiến trúc Huế,Hue architecture|en=Hue architecture`},
		{"VNARCH_PHO_CO",         3, `label=phố cổ Hội An|desc=phố cổ Hội An UNESCO 1999 nhà cổ Quảng Đông Nhật Bản mái ngói rêu phong đèn lồng cảng thị thương mại|vi=phố cổ Hội An,Hoi An old town|en=Hoi An ancient town`},
		{"VNARCH_NHA_RONG",       3, `label=nhà rông Tây Nguyên|desc=nhà rông Tây Nguyên Bahnar Jarai gỗ cao trên 10m mái dốc nơi họp buôn làng lễ hội cồng chiêng|vi=nhà rông Tây Nguyên,nha rong|en=Rong house`},

		// ── COGNITION 2 (COGN2_) ────────────────────────────────────
		{"COGN2_ATTENTION",       3, `label=chú ý và nhận thức|desc=attention spotlight model Treisman feature integration theory selective sustained divided attentional blink inattentional blindness|vi=chú ý và nhận thức,attention|en=attention cognition`},
		{"COGN2_DECISION",        3, `label=ra quyết định|desc=decision making dual process Kahneman System 1 2 prospect theory loss aversion anchoring framing heuristics nudge|vi=ra quyết định,decision making|en=decision making`},
		{"COGN2_LANGUAGE_BRAIN",  3, `label=ngôn ngữ và não|desc=language brain Broca Wernicke area SLF arcuate fasciculus bilingualism aphasia critical period Chomsky universal grammar|vi=ngôn ngữ và não,language brain|en=language brain`},
		{"COGN2_EMOTION_COGNIT",  3, `label=cảm xúc và nhận thức|desc=emotion cognition somatic marker Damasio amygdala prefrontal cortex emotional regulation reappraisal suppression|vi=cảm xúc và nhận thức,emotion cognition|en=emotion cognition`},
		{"COGN2_CREATIVITY_BRAIN",3, `label=sáng tạo và não|desc=creativity neuroscience default mode network insight Aha moment incubation preparation divergent convergent thinking|vi=sáng tạo và não,creativity brain|en=creativity brain`},

		// ── LANGUAGE SCIENCE 3 (LANG3_) ────────────────────────────
		{"LANG3_PRAGMATICS",      3, `label=ngữ dụng học|desc=pragmatics speech act Austin Searle Grice maxims implicature context deixis politeness face theory|vi=ngữ dụng học,pragmatics|en=pragmatics`},
		{"LANG3_DISCOURSE",       3, `label=phân tích diễn ngôn|desc=discourse analysis coherence cohesion conversation analysis turn-taking adjacency pairs genre register ideology CDA|vi=phân tích diễn ngôn,discourse analysis|en=discourse analysis`},
		{"LANG3_LANGUAGE_CHANGE", 3, `label=biến đổi ngôn ngữ|desc=language change sound shift Grimm's law Great Vowel Shift borrowing calque semantic change grammaticalization contact|vi=biến đổi ngôn ngữ,language change|en=language change`},
		{"LANG3_TRANSLATION",     3, `label=dịch thuật học|desc=translation theory equivalence Eugene Nida dynamic formal Skopos theory localization machine translation post-editing quality|vi=dịch thuật học,translation theory|en=translation theory`},
		{"LANG3_ENDANGERED",      3, `label=ngôn ngữ nguy cấp|desc=endangered language language death 7000 languages 50% endangered UNESCO atlas revitalization Hawaiian Welsh Maori|vi=ngôn ngữ nguy cấp,endangered language|en=endangered language`},

		// ── ARCTIC / POLAR (ARCTIC_) ────────────────────────────────
		{"ARCTIC_ICE_LOSS",       3, `label=tan băng Bắc Cực|desc=Arctic ice loss sea ice extent minimum record 2012 albedo feedback Arctic amplification Northwest Passage open|vi=tan băng Bắc Cực,Arctic ice loss|en=Arctic ice loss`},
		{"ARCTIC_PERMAFROST",     3, `label=lớp đất đóng băng vĩnh cửu|desc=permafrost thaw methane release thermokarst lake subsidence infrastructure damage carbon feedback loop Siberia|vi=lớp đất đóng băng vĩnh cửu,permafrost|en=permafrost`},
		{"ARCTIC_FAUNA",          3, `label=động vật Bắc Cực|desc=Arctic fauna polar bear ringed seal narwhal Arctic fox snowy owl lemming migration adaptation blubber hibernation|vi=động vật Bắc Cực,Arctic fauna|en=Arctic fauna`},

		// ── DESERT ECOLOGY (DESERT_) ────────────────────────────────
		{"DESERT_ADAPT",          3, `label=thích nghi sa mạc|desc=desert adaptation cactus CAM photosynthesis camel hump fat water storage nocturnal behavior dormancy extremophile|vi=thích nghi sa mạc,desert adaptation|en=desert adaptation`},
		{"DESERT_DESERTIFICATION",3, `label=sa mạc hóa|desc=desertification land degradation Sahel overgrazing deforestation Great Green Wall UN drought dust bowl aridification|vi=sa mạc hóa,desertification|en=desertification`},
		{"DESERT_WATER",          3, `label=nước trong sa mạc|desc=desert water fog collector dew harvesting qanats ancient irrigation wadi oasis aquifer depletion water scarcity|vi=nước trong sa mạc,desert water|en=desert water`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3500 { fmt.Println(" MILESTONE 3500! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
