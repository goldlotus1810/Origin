//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── TÀI CHÍNH CÁ NHÂN (PERSONFIN_) ──────────────────────
		{"PERSONFIN_COMPOUND",3,`label=lãi kép|desc=compound interest Albert Einstein eighth wonder daily monthly annual doubling time 72|vi=lãi kép,compound interest|en=compound interest|zh=复利`},
		{"PERSONFIN_DIVERSIFY",3,`label=đa dạng hóa danh mục|desc=diversification portfolio modern portfolio theory Markowitz uncorrelated assets risk reduction|vi=đa dạng hóa danh mục,diversification|en=portfolio diversification|zh=投资组合多元化`},
		{"PERSONFIN_TAX",    3,`label=thuế thu nhập cá nhân|desc=personal income tax progressive marginal rate deduction W2 bracket filing IRS|vi=thuế thu nhập cá nhân,income tax|en=income tax|zh=个人所得税`},
		{"PERSONFIN_RETIRE", 3,`label=lập kế hoạch hưu trí|desc=retirement planning 401k IRA pension annuity 4% rule sequence of returns risk|vi=lập kế hoạch hưu trí,retirement planning|en=retirement planning|zh=退休规划`},

		// ── LỊCH SỬ TRUNG QUỐC BỔ SUNG (CHINAHIST_) ─────────────
		{"CHINAHIST_HAN",    3,`label=nhà Hán|desc=Han Dynasty 206 BCE–220 CE silk road Confucianism bureaucracy census 60 triệu paper|vi=nhà Hán,Han Dynasty|en=Han Dynasty|zh=汉朝`},
		{"CHINAHIST_TANG",   3,`label=nhà Đường|desc=Tang Dynasty 618-907 peak culture poetry Li Bai Du Fu trade Silk Road diverse|vi=nhà Đường,Tang Dynasty|en=Tang Dynasty|zh=唐朝`},
		{"CHINAHIST_SONG",   3,`label=nhà Tống|desc=Song Dynasty 960-1279 printing gunpowder compass paper money commercial revolution|vi=nhà Tống,Song Dynasty|en=Song Dynasty|zh=宋朝`},
		{"CHINAHIST_REFORM", 3,`label=cải cách mở cửa Trung Quốc|desc=Reform Opening Up Deng Xiaoping 1978 SEZ Shenzhen market economy rapid growth|vi=cải cách mở cửa Trung Quốc,Reform Opening|en=China Reform Opening|zh=改革开放`},

		// ── KHOA HỌC THỰC VẬT (BOTANY_) ─────────────────────────
		{"BOTANY_PHOTOSYN2", 3,`label=quang hợp nâng cao|desc=C3 C4 CAM photosynthesis pathway dark reaction light reaction Calvin cycle RuBisCO|vi=quang hợp nâng cao,advanced photosynthesis|en=advanced photosynthesis|zh=高级光合作用`},
		{"BOTANY_PLANT_CELL",3,`label=tế bào thực vật|desc=plant cell wall cellulose chloroplast vacuole plasmodesmata turgor pressure cell plate|vi=tế bào thực vật,plant cell|en=plant cell|zh=植物细胞`},
		{"BOTANY_GERMINATION",3,`label=nảy mầm|desc=seed germination dormancy imbibition radicle hypocotyl cotyledon light temperature moisture|vi=nảy mầm,germination|en=seed germination|zh=种子萌发`},
		{"BOTANY_TROPISM",   3,`label=hướng động thực vật|desc=tropism phototropism gravitropism thigmotropism auxin IAA touch climbing vine|vi=hướng động thực vật,tropism|en=plant tropism|zh=植物向性`},

		// ── AN TOÀN THÔNG TIN (CYBERSEC_) ────────────────────────
		{"CYBERSEC_ENCRYPT2",3,`label=mã hóa nâng cao|desc=RSA ECC public key infrastructure PKI digital signature certificate TLS HTTPS|vi=mã hóa nâng cao,encryption|en=encryption|zh=加密`},
		{"CYBERSEC_PENTEST", 3,`label=kiểm tra xâm nhập|desc=penetration testing ethical hacking CVE OWASP Kali Linux Metasploit red team|vi=kiểm tra xâm nhập,penetration testing|en=penetration testing|zh=渗透测试`},
		{"CYBERSEC_SOCIAL_ENG",3,`label=tấn công phi kỹ thuật|desc=social engineering phishing spear phishing vishing pretexting Kevin Mitnick|vi=tấn công phi kỹ thuật,social engineering|en=social engineering|zh=社会工程学`},
		{"CYBERSEC_ZERO_DAY",3,`label=lỗ hổng zero-day|desc=zero-day vulnerability unknown exploit before patch CVE CERT responsible disclosure|vi=lỗ hổng zero-day,zero-day|en=zero-day vulnerability|zh=零日漏洞`},

		// ── PHÚC LỢI ĐỘNG VẬT (ANIMAL_WELF_) ────────────────────
		{"ANIMAL_WELF_FARM",  3,`label=phúc lợi động vật nông trại|desc=farm animal welfare 5 freedoms factory farming cage free free range RSPCA|vi=phúc lợi động vật nông trại,farm animal welfare|en=farm animal welfare|zh=农场动物福利`},
		{"ANIMAL_WELF_WILD",  3,`label=bảo tồn động vật hoang dã|desc=wildlife conservation IUCN Red List CITES poaching keystone species rewilding|vi=bảo tồn động vật hoang dã,wildlife conservation|en=wildlife conservation|zh=野生动物保护`},
		{"ANIMAL_WELF_ZOO",   3,`label=vườn thú và bảo tồn|desc=zoo accreditation AZA SSP captive breeding program ark education research|vi=vườn thú và bảo tồn,zoo conservation|en=zoo conservation|zh=动物园保育`},

		// ── KINH TẾ CHIA SẺ (SHARE_ECON_) ───────────────────────
		{"SHARE_ECON_AIRBNB",3,`label=kinh tế chia sẻ chỗ ở|desc=Airbnb sharing economy peer-to-peer accommodation regulation housing market trust|vi=kinh tế chia sẻ chỗ ở,Airbnb|en=Airbnb sharing economy|zh=共享住宿经济`},
		{"SHARE_ECON_RIDE",   3,`label=gọi xe công nghệ|desc=ride sharing Uber Lyft Grab surge pricing gig worker regulation taxi disruption|vi=gọi xe công nghệ,ride sharing|en=ride sharing|zh=网约车`},
		{"SHARE_ECON_COWORK", 3,`label=không gian làm việc chung|desc=coworking WeWork hot desking remote work community amenity flexible lease|vi=không gian làm việc chung,coworking|en=coworking|zh=共享办公`},

		// ── SỨC KHỎE SINH SẢN (REPRO_HEALTH_) ───────────────────
		{"REPRO_HEALTH_FERTIL",3,`label=khả năng sinh sản|desc=fertility IVF ART sperm egg embryo IUI surrogacy declining rate lifestyle|vi=khả năng sinh sản,fertility|en=fertility|zh=生育力`},
		{"REPRO_HEALTH_CONTRA",3,`label=biện pháp tránh thai|desc=contraception pill IUD condom hormonal barrier implant abstinence WHO family planning|vi=biện pháp tránh thai,contraception|en=contraception|zh=避孕`},
		{"REPRO_HEALTH_MENOP",3,`label=mãn kinh|desc=menopause perimenopause HRT estrogen hot flash bone density cognitive cardiovascular|vi=mãn kinh,menopause|en=menopause|zh=更年期`},

		// ── LỊCH SỬ ĐÔNG NAM Á (SEA_HIST_) ──────────────────────
		{"SEA_HIST_VIET",    3,`label=lịch sử Việt Nam cổ đại|desc=Văn Lang Âu Lạc Hùng Vương 2879 BCE thời kỳ Bắc thuộc 938 Ngô Quyền|vi=lịch sử Việt Nam cổ đại,ancient Vietnam|en=ancient Vietnam history|zh=越南古代史`},
		{"SEA_HIST_THAI",    3,`label=lịch sử Thái Lan|desc=Sukhothai Ayutthaya Chakri dynasty Rama Bangkok 1782 never colonized|vi=lịch sử Thái Lan,Thai history|en=Thai history|zh=泰国历史`},
		{"SEA_HIST_PHILIP",  3,`label=lịch sử Philippines|desc=Magellan 1521 Spanish colony 333 năm American colonial independence 1946 Marcos|vi=lịch sử Philippines,Philippine history|en=Philippine history|zh=菲律宾历史`},
		{"SEA_HIST_INDO",    3,`label=lịch sử Indonesia|desc=Dutch colony VOC 350 năm Sukarno independence 1945 Pancasila 17000 islands|vi=lịch sử Indonesia,Indonesian history|en=Indonesian history|zh=印度尼西亚历史`},

		// ── TÍNH TOÁN KHOA HỌC (SCICOMP_) ────────────────────────
		{"SCICOMP_SIMULATION",3,`label=mô phỏng khoa học|desc=scientific simulation Monte Carlo finite element CFD climate model protein folding|vi=mô phỏng khoa học,scientific simulation|en=scientific simulation|zh=科学模拟`},
		{"SCICOMP_HPC",      3,`label=tính toán hiệu năng cao|desc=HPC supercomputer GPU cluster MPI parallel computing petaflops Frontier Summit|vi=tính toán hiệu năng cao,HPC,supercomputer|en=HPC supercomputer|zh=高性能计算`},
		{"SCICOMP_NUMMETHOD",3,`label=phương pháp số học|desc=numerical method Newton-Raphson Euler Runge-Kutta finite difference error convergence|vi=phương pháp số học,numerical methods|en=numerical methods|zh=数值方法`},

		// ── THIẾT KẾ SẢN PHẨM (PRODUCT_DESIGN_) ─────────────────
		{"PRODUCT_DESIGN_UX",3,`label=UX/UI Design|desc=user experience usability Nielsen heuristics Figma wireframe prototype user testing|vi=UX/UI Design,thiết kế trải nghiệm|en=UX/UI Design|zh=用户体验设计`},
		{"PRODUCT_DESIGN_PM",3,`label=quản lý sản phẩm|desc=product management roadmap backlog user story OKR product-market fit Marty Cagan|vi=quản lý sản phẩm,product management|en=product management|zh=产品管理`},
		{"PRODUCT_DESIGN_SPRINT",3,`label=Design Sprint|desc=Design Sprint Google Ventures Jake Knapp 5 days understand sketch prototype test|vi=Design Sprint|en=Design Sprint|zh=设计冲刺`},

		// ── NGÔN NGỮ HỌC TIẾNG VIỆT (VNLANG2_) ──────────────────
		{"VNLANG2_TONEMES",  3,`label=thanh điệu tiếng Việt|desc=6 thanh bằng huyền ngã hỏi sắc nặng ngang phân biệt nghĩa tonal language|vi=thanh điệu tiếng Việt,Vietnamese tones|en=Vietnamese tones|zh=越南语声调`},
		{"VNLANG2_DIALECT",  3,`label=phương ngữ tiếng Việt|desc=tiếng Bắc Nam Trung phương ngữ Hà Nội Huế Sài Gòn khác biệt phát âm từ vựng|vi=phương ngữ tiếng Việt,Vietnamese dialect|en=Vietnamese dialect|zh=越南语方言`},
		{"VNLANG2_ORIGIN",   3,`label=nguồn gốc tiếng Việt|desc=tiếng Việt Austroasiatic Mon-Khmer gốc Trung Hán Việt chữ Nôm chữ Quốc ngữ|vi=nguồn gốc tiếng Việt,Vietnamese origin|en=Vietnamese language origin|zh=越南语起源`},

		// ── VĂN HÓA ĐỌC SÁCH (BOOKCULTURE_) ─────────────────────
		{"BOOKCULTURE_NOVEL", 3,`label=tiểu thuyết|desc=novel fiction narrative Cervantes Don Quixote rise realism modernism postmodern|vi=tiểu thuyết,novel|en=novel|zh=小说`},
		{"BOOKCULTURE_NONFICTION",3,`label=sách phi hư cấu|desc=nonfiction memoir biography history science self-help narrative nonfiction|vi=sách phi hư cấu,nonfiction|en=nonfiction|zh=非虚构类书籍`},
		{"BOOKCULTURE_LIBRARY",3,`label=thư viện|desc=library Alexandria Library of Congress digital archive open access knowledge institution|vi=thư viện,library|en=library|zh=图书馆`},

		// ── TOÁN HỌC RỜI RẠC (DISCMATH_) ────────────────────────
		{"DISCMATH_COMB",    3,`label=tổ hợp|desc=combinatorics counting permutation combination binomial coefficient Pascal triangle|vi=tổ hợp,combinatorics|en=combinatorics|zh=组合数学`},
		{"DISCMATH_NUMBER",  3,`label=lý thuyết số|desc=number theory prime Euclid RSA cryptography Fermat Goldbach conjecture Riemann|vi=lý thuyết số,number theory|en=number theory|zh=数论`},
		{"DISCMATH_AUTOMATA",3,`label=lý thuyết ô tô mát|desc=automata theory Turing machine regular expression finite automaton Church-Turing thesis|vi=lý thuyết ô tô mát,automata theory|en=automata theory|zh=自动机理论`},

		// ── QUÂN SỰ VÀ CHIẾN LƯỢC (MILSTRAT_) ───────────────────
		{"MILSTRAT_SUN_TZU", 3,`label=Tôn Tử|desc=Sun Tzu Art of War binh pháp chiến lược cổ đại 孫子兵法 know enemy know self|vi=Tôn Tử,Sun Tzu|en=Sun Tzu|zh=孙子`},
		{"MILSTRAT_CLAUSEWITZ",3,`label=Clausewitz|desc=Carl von Clausewitz On War 1832 fog of war center of gravity war is politics|vi=Clausewitz,Về chiến tranh|en=Clausewitz On War|zh=克劳塞维茨`},
		{"MILSTRAT_DETERRENCE",3,`label=răn đe hạt nhân|desc=nuclear deterrence MAD mutually assured destruction second strike ICBM triad|vi=răn đe hạt nhân,nuclear deterrence|en=nuclear deterrence|zh=核威慑`},

		// ── KỸ NĂNG LẬP TRÌNH (CODESKILL_) ──────────────────────
		{"CODESKILL_CLEAN_CODE",3,`label=clean code|desc=clean code Robert Martin naming functions DRY KISS SOLID refactoring readability|vi=clean code,code sạch|en=clean code|zh=整洁代码`},
		{"CODESKILL_TDD",    3,`label=phát triển hướng kiểm thử|desc=TDD Test-Driven Development red green refactor Kent Beck unit test mock stub|vi=TDD,phát triển hướng kiểm thử|en=TDD|zh=测试驱动开发`},
		{"CODESKILL_GIT",    3,`label=Git|desc=Git version control Linus Torvalds distributed branch merge rebase commit history|vi=Git|en=Git version control|zh=Git`},
		{"CODESKILL_ALGO2",  3,`label=thuật toán nâng cao|desc=advanced algorithms dynamic programming greedy divide conquer NP-complete P vs NP|vi=thuật toán nâng cao,advanced algorithms|en=advanced algorithms|zh=高级算法`},

		// ── LỊCH SỬ VĂN MINH ẤN ĐỘ (INDHIST_) ──────────────────
		{"INDHIST_INDUS",    3,`label=văn minh Indus|desc=Indus Valley Harappa Mohenjo-daro 2500 BCE drainage writing script urban planning|vi=văn minh Indus,Indus Valley|en=Indus Valley civilization|zh=印度河流域文明`},
		{"INDHIST_MAURYA",   3,`label=đế quốc Maurya|desc=Maurya Empire Ashoka 268 BCE non-violence Buddhism dhamma edicts largest India|vi=đế quốc Maurya,Maurya|en=Maurya Empire|zh=孔雀王朝`},
		{"INDHIST_MUGHAL",   3,`label=đế quốc Mughal|desc=Mughal Empire Babur Akbar Shah Jahan Taj Mahal Aurangzeb art architecture|vi=đế quốc Mughal,Mughal|en=Mughal Empire|zh=莫卧儿帝国`},

		// ── VẬT LÝ LƯỢNG TỬ BỔ SUNG (QM2_) ──────────────────────
		{"QM2_UNCERTAINTY",  3,`label=nguyên lý bất định|desc=Heisenberg uncertainty principle position momentum cannot simultaneously measure ℏ/2|vi=nguyên lý bất định,Heisenberg uncertainty|en=Heisenberg uncertainty principle|zh=海森堡不确定性原理`},
		{"QM2_SCHRODINGER",  3,`label=Schrödinger|desc=Schrödinger equation wave function ψ probability amplitude quantum mechanics formalism|vi=Schrödinger,phương trình Schrödinger|en=Schrödinger equation|zh=薛定谔方程`},
		{"QM2_FEYNMAN",      3,`label=Feynman|desc=Richard Feynman path integral QED quantum electrodynamics Nobel 1965 diagrams|vi=Feynman,giản đồ Feynman|en=Feynman|zh=费曼`},

		// ── NGOẠI GIAO VIỆT NAM (VNDIPLO_) ──────────────────────
		{"VNDIPLO_BAMBOO",   3,`label=ngoại giao cây tre|desc=bamboo diplomacy Nguyễn Phú Trọng linh hoạt độc lập đa phương bình thường hóa|vi=ngoại giao cây tre,bamboo diplomacy|en=bamboo diplomacy Vietnam|zh=竹子外交`},
		{"VNDIPLO_US_VN",    3,`label=quan hệ Mỹ-Việt|desc=bình thường hóa 1995 Clinton đối tác chiến lược toàn diện 2023 Biden thương mại|vi=quan hệ Mỹ-Việt,US-Vietnam relations|en=US-Vietnam relations|zh=美越关系`},
		{"VNDIPLO_ASEAN_VN", 3,`label=Việt Nam trong ASEAN|desc=gia nhập ASEAN 1995 Chủ tịch ASEAN 2020 VAP thương mại hội nhập khu vực|vi=Việt Nam trong ASEAN,Vietnam ASEAN|en=Vietnam ASEAN|zh=越南与东盟`},

		// ── SINH HỌC TIẾN HÓA BỔ SUNG (EVOBIO2_) ────────────────
		{"EVOBIO2_COEVOL",   3,`label=đồng tiến hóa|desc=coevolution predator prey arms race pollinator flower mycorrhiza obligate mutualism|vi=đồng tiến hóa,coevolution|en=coevolution|zh=协同进化`},
		{"EVOBIO2_EXAPT",    3,`label=thích nghi lại|desc=exaptation feathers flight repurposed function Gould Vrba bird wing swim bladder|vi=thích nghi lại,exaptation|en=exaptation|zh=外适应`},
		{"EVOBIO2_MASS_EXT", 3,`label=tuyệt chủng hàng loạt|desc=mass extinction 5 Big Five Permian K-Pg asteroid Chicxulub dinosaur 6th ongoing|vi=tuyệt chủng hàng loạt,mass extinction|en=mass extinction|zh=大灭绝`},

		// ── PHÁT TRIỂN BỀN VỮNG (SUSTDEV_) ──────────────────────
		{"SUSTDEV_SDG2",     3,`label=SDG chi tiết|desc=SDG 17 goals 169 targets 2030 agenda Brundtland Commission no poverty zero hunger|vi=SDG chi tiết,Sustainable Development Goals|en=SDG details|zh=可持续发展目标详情`},
		{"SUSTDEV_ESG",      3,`label=ESG đầu tư|desc=ESG Environmental Social Governance investing rating Bloomberg MSCI 35 nghìn tỷ USD|vi=ESG đầu tư,ESG investing|en=ESG investing|zh=ESG投资`},
		{"SUSTDEV_CIRCULAR", 3,`label=kinh tế tuần hoàn|desc=circular economy cradle-to-cradle Ellen MacArthur Foundation waste=food close loop|vi=kinh tế tuần hoàn,circular economy|en=circular economy|zh=循环经济`},

		// ── LỊCH SỬ VIỄN ĐÔNG (FAREAST_) ────────────────────────
		{"FAREAST_MONGOL2",  3,`label=đế quốc Mông Cổ|desc=Mongol Empire Genghis Khan 1206 largest contiguous 33 triệu km2 Pax Mongolica|vi=đế quốc Mông Cổ,Mongol Empire|en=Mongol Empire|zh=蒙古帝国`},
		{"FAREAST_MING",     3,`label=nhà Minh|desc=Ming Dynasty 1368-1644 Great Wall rebuild Forbidden City Zheng He voyages 7 seas|vi=nhà Minh,Ming Dynasty|en=Ming Dynasty|zh=明朝`},
		{"FAREAST_QING",     3,`label=nhà Thanh|desc=Qing Dynasty 1644-1912 Manchu Kangxi Qianlong 1.3 tỷ dân Opium War decline|vi=nhà Thanh,Qing Dynasty|en=Qing Dynasty|zh=清朝`},

		// ── NGHỆ THUẬT THẾ GIỚI (WORLDART_) ─────────────────────
		{"WORLDART_LEONARDO",3,`label=Leonardo da Vinci|desc=Renaissance polymath Mona Lisa Last Supper anatomy invention flying machine|vi=Leonardo da Vinci|en=Leonardo da Vinci|zh=达芬奇`},
		{"WORLDART_VAN_GOGH",3,`label=Van Gogh|desc=Post-Impressionism Starry Night Sunflowers brush stroke color mental illness 900 paintings|vi=Van Gogh|en=Van Gogh|zh=梵高`},
		{"WORLDART_FRIDA",   3,`label=Frida Kahlo|desc=Mexican painter surrealism self-portrait pain identity feminism Diego Rivera|vi=Frida Kahlo|en=Frida Kahlo|zh=弗里达·卡洛`},

		// ── VI SINH VẬT HỌC (MICRO_BIO_) ─────────────────────────
		{"MICRO_BIO_BACTERIA",3,`label=vi khuẩn|desc=bacteria prokaryote binary fission antibiotic resistance gram positive negative E. coli|vi=vi khuẩn,bacteria|en=bacteria|zh=细菌`},
		{"MICRO_BIO_VIRUS2", 3,`label=virus|desc=virus capsid protein RNA DNA host replication lytic lysogenic pandemic COVID influenza|vi=virus|en=virus|zh=病毒`},
		{"MICRO_BIO_FUNGUS", 3,`label=nấm|desc=fungi mycology yeast mold mushroom decomposer penicillin Aspergillus mycorrhiza spore|vi=nấm,fungi|en=fungi|zh=真菌`},
		{"MICRO_BIO_PRION",  3,`label=prion|desc=prion misfolded protein Prusiner Nobel 1997 CJD BSE mad cow untreatable brain|vi=prion|en=prion|zh=朊病毒`},

		// ── TOÁN TỐI ƯU (OPTMATH_) ───────────────────────────────
		{"OPTMATH_LINEAR",   3,`label=quy hoạch tuyến tính|desc=linear programming simplex method Dantzig objective function constraints Kantorovich|vi=quy hoạch tuyến tính,linear programming|en=linear programming|zh=线性规划`},
		{"OPTMATH_GRADIENT", 3,`label=giảm dần gradient|desc=gradient descent stochastic mini-batch learning rate saddle point convergence deep learning|vi=giảm dần gradient,gradient descent|en=gradient descent|zh=梯度下降`},
		{"OPTMATH_GENETIC",  3,`label=thuật toán tiến hóa|desc=genetic algorithm evolutionary computation mutation crossover selection fitness landscape TSP|vi=thuật toán tiến hóa,genetic algorithm|en=genetic algorithm|zh=遗传算法`},

		// ── VĂN HÓA ẨM THỰC VIỆT NAM BỔ SUNG (VNFOOD2_) ─────────
		{"VNFOOD2_BUN_BO",   3,`label=bún bò Huế|desc=bún bò Huế mì gạo thịt bò chân giò sả ớt tôm ruốc Huế đậm đà|vi=bún bò Huế|en=bun bo Hue|zh=顺化牛肉粉`},
		{"VNFOOD2_COM_TAM",  3,`label=cơm tấm|desc=cơm tấm Sài Gòn gạo tấm tôm nướng chả trứng nước mắm đặc trưng phố thị|vi=cơm tấm Sài Gòn|en=com tam Saigon|zh=碎米饭`},
		{"VNFOOD2_BANH_MI",  3,`label=bánh mì Việt Nam|desc=bánh mì baguette pâté rau đồ chua chả lụa ớt CNN best sandwich UNESCO|vi=bánh mì Việt Nam,banh mi|en=Vietnamese banh mi|zh=越南法棍`},
		{"VNFOOD2_CA_PHE_SUA",3,`label=cà phê sữa đá|desc=cà phê sữa đá phin Robusta condensed milk đặc trưng Việt Nam đen đá ấm|vi=cà phê sữa đá,Vietnamese iced coffee|en=Vietnamese iced coffee|zh=越南炼乳冰咖啡`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
		fmt.Printf("  ✚ %-26s %q\n", nd.name, extractLabel(nd.dna))
	}
	fmt.Printf("\n✚ %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes\n", nn)
	if nn >= 3200 { fmt.Println("🎉 MILESTONE 3200!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
