//go:build ignore
// go run scripts/seed_medicine_philosophy.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── Y HỌC / SINH LÝ NGƯỜI ─────────────────────────────────
		{"MED_HEART",       3, `label=tim|desc=cơ quan bơm máu duy trì tuần hoàn đập 60-100 lần/phút trung bình 3 tỷ nhịp đời người|vi=tim,heart|en=heart|zh=心脏`},
		{"MED_LUNG",        3, `label=phổi|desc=cơ quan trao đổi khí hít oxy thải CO2 hai lá phổi chứa 300 triệu phế nang|vi=phổi,lung|en=lung|zh=肺`},
		{"MED_BRAIN",       3, `label=não|desc=cơ quan điều khiển trung tâm 86 tỷ tế bào thần kinh tiêu thụ 20% năng lượng cơ thể|vi=não,brain|en=brain|zh=大脑`},
		{"MED_BLOOD",       3, `label=máu|desc=mô lỏng vận chuyển oxy dinh dưỡng hormone gồm hồng cầu bạch cầu tiểu cầu huyết tương|vi=máu,blood|en=blood|zh=血液`},
		{"MED_BONE",        3, `label=xương|desc=mô cứng tạo khung cơ thể 206 chiếc người trưởng thành sản xuất tế bào máu|vi=xương,bone|en=bone|zh=骨骼`},
		{"MED_MUSCLE",      3, `label=cơ|desc=mô co rút tạo chuyển động gồm cơ vân cơ trơn cơ tim hơn 600 cơ trong cơ thể|vi=cơ,cơ bắp,muscle|en=muscle|zh=肌肉`},
		{"MED_NERVE",       3, `label=dây thần kinh|desc=bó sợi thần kinh truyền tín hiệu điện giữa não tủy sống và cơ quan|vi=dây thần kinh,nerve|en=nerve|zh=神经`},
		{"MED_IMMUNE",      3, `label=hệ miễn dịch|desc=hệ thống bảo vệ cơ thể chống vi khuẩn virus gồm bạch cầu kháng thể lympho|vi=hệ miễn dịch,immune system|en=immune system|zh=免疫系统`},
		{"MED_VIRUS",       3, `label=virus|desc=tác nhân lây nhiễm cực nhỏ cần tế bào chủ để nhân bản gây bệnh cúm COVID HIV|vi=virus,vi rút|en=virus|zh=病毒`},
		{"MED_BACTERIA",    3, `label=vi khuẩn|desc=sinh vật đơn bào nhân sơ có thể gây bệnh hoặc có lợi hệ vi sinh đường ruột|vi=vi khuẩn,bacteria|en=bacteria|zh=细菌`},
		{"MED_VACCINE",     3, `label=vaccine|desc=chế phẩm sinh học huấn luyện hệ miễn dịch nhận diện mầm bệnh ngừa bệnh|vi=vaccine,vắc xin|en=vaccine|zh=疫苗`},
		{"MED_SURGERY",     3, `label=phẫu thuật|desc=can thiệp y tế dùng dao mổ hoặc công cụ để điều trị chẩn đoán hoặc cải thiện chức năng|vi=phẫu thuật,surgery|en=surgery|zh=手术`},
		{"MED_MEDICINE",    3, `label=dược phẩm|desc=chất hóa học dùng để chẩn đoán điều trị hoặc phòng ngừa bệnh tật|vi=dược phẩm,thuốc,medicine|en=medicine|zh=药物`},
		{"MED_GENE_THERAPY",3, `label=liệu pháp gen|desc=điều trị bệnh bằng cách chỉnh sửa hoặc thay thế gen bất thường CRISPR-Cas9|vi=liệu pháp gen,gene therapy|en=gene therapy|zh=基因疗法`},
		{"MED_NUTRITION",   3, `label=dinh dưỡng y tế|desc=khoa học nghiên cứu tác động của thực phẩm đến sức khỏe protein carb chất béo vitamin|vi=dinh dưỡng y tế,nutrition|en=nutrition|zh=营养学`},
		{"MED_MENTAL",      3, `label=sức khỏe tâm thần|desc=trạng thái khỏe mạnh về cảm xúc tâm lý xã hội ảnh hưởng cách suy nghĩ cảm nhận hành động|vi=sức khỏe tâm thần,mental health|en=mental health|zh=心理健康`},
		{"MED_DNA_REPAIR",  3, `label=sửa chữa DNA|desc=cơ chế tế bào phát hiện và sửa lỗi trong chuỗi DNA để duy trì tính toàn vẹn gen|vi=sửa chữa DNA,DNA repair|en=DNA repair|zh=DNA修复`},

		// ── TRIẾT HỌC / LOGIC ─────────────────────────────────────
		{"PHIL_LOGIC",      3, `label=logic|desc=ngành nghiên cứu các nguyên tắc tư duy đúng đắn và suy luận hợp lệ|vi=logic,luận lý học|en=logic|zh=逻辑学`},
		{"PHIL_ETHICS",     3, `label=đạo đức học|desc=ngành triết học nghiên cứu các giá trị đạo đức đúng sai thiện ác nghĩa vụ|vi=đạo đức học,ethics|en=ethics|zh=伦理学`},
		{"PHIL_EPISTEM",    3, `label=nhận thức luận|desc=ngành triết học nghiên cứu bản chất nguồn gốc và giới hạn của tri thức|vi=nhận thức luận,epistemology|en=epistemology|zh=认识论`},
		{"PHIL_METAPHYS",   3, `label=siêu hình học|desc=ngành triết học nghiên cứu bản chất cơ bản của thực tại tồn tại không gian thời gian|vi=siêu hình học,metaphysics|en=metaphysics|zh=形而上学`},
		{"PHIL_MIND",       3, `label=triết học tâm trí|desc=ngành nghiên cứu bản chất ý thức tư duy cảm xúc mối quan hệ giữa não và tâm trí|vi=triết học tâm trí,philosophy of mind|en=philosophy of mind|zh=心灵哲学`},
		{"PHIL_ARGUMENT",   3, `label=lập luận|desc=tập hợp mệnh đề tiền đề dẫn đến kết luận trong tư duy logic và lập luận|vi=lập luận,argument|en=argument|zh=论证`},
		{"PHIL_TRUTH",      3, `label=sự thật|desc=tính phù hợp của mệnh đề với thực tại khái niệm trung tâm trong triết học và khoa học|vi=sự thật,truth|en=truth|zh=真理`},
		{"PHIL_CONSCIOUSNESS",3,`label=ý thức|desc=trạng thái nhận thức chủ quan về bản thân và môi trường vấn đề khó trong triết học tâm trí|vi=ý thức,consciousness|en=consciousness|zh=意识`},
		{"PHIL_FREEDOM",    3, `label=tự do ý chí|desc=khả năng hành động theo quyết định của bản thân không bị ép buộc hay tất định|vi=tự do ý chí,free will|en=free will|zh=自由意志`},
		{"PHIL_SCIENCE",    3, `label=triết học khoa học|desc=ngành nghiên cứu phương pháp nền tảng và hàm ý của khoa học|vi=triết học khoa học,philosophy of science|en=philosophy of science|zh=科学哲学`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Y học nội bộ
		{"MED_HEART",       "MED_BLOOD",       "pumps"},
		{"MED_LUNG",        "MED_BLOOD",       "oxygenates"},
		{"MED_BRAIN",       "MED_NERVE",       "controls-via"},
		{"MED_BLOOD",       "MED_BONE",        "produced-by"},
		{"MED_IMMUNE",      "MED_BLOOD",       "component-of"},
		{"MED_VACCINE",     "MED_IMMUNE",      "trains"},
		{"MED_VIRUS",       "MED_IMMUNE",      "triggers"},
		{"MED_BACTERIA",    "MED_IMMUNE",      "triggers"},
		{"MED_MEDICINE",    "MED_VIRUS",       "treats"},
		{"MED_MEDICINE",    "MED_BACTERIA",    "treats"},
		{"MED_SURGERY",     "MED_BRAIN",       "can-operate-on"},
		{"MED_GENE_THERAPY","MOL_DNA",         "modifies"},
		{"MED_DNA_REPAIR",  "MOL_DNA",         "maintains"},
		{"MED_MENTAL",      "MED_BRAIN",       "rooted-in"},
		{"MED_NUTRITION",   "MED_BLOOD",       "sustains"},
		// Y học ↔ Hóa học
		{"MED_MEDICINE",    "CHEM_MOLECULE",   "is-a"},
		{"MED_VACCINE",     "CHEM_PROTEIN",    "contains"},
		// Triết học nội bộ
		{"PHIL_LOGIC",      "PHIL_ARGUMENT",   "formalizes"},
		{"PHIL_ETHICS",     "PHIL_TRUTH",      "seeks"},
		{"PHIL_EPISTEM",    "PHIL_TRUTH",      "studies"},
		{"PHIL_METAPHYS",   "PHIL_EPISTEM",    "precedes"},
		{"PHIL_MIND",       "PHIL_CONSCIOUSNESS","studies"},
		{"PHIL_FREEDOM",    "PHIL_MIND",       "problem-of"},
		{"PHIL_SCIENCE",    "PHIL_EPISTEM",    "applies"},
		{"PHIL_CONSCIOUSNESS","MED_BRAIN",     "grounded-in"},
		// Triết học ↔ Toán
		{"PHIL_LOGIC",      "MATH_PROOF",      "basis-of"},
		{"PHIL_TRUTH",      "MATH_EQUATION",   "verified-by"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-24s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"related-to":3,"causes":4,"uses":5,
		"produces":6,"contains":7,"pumps":8,"oxygenates":9,"controls-via":10,
		"produced-by":11,"component-of":12,"trains":13,"triggers":14,"treats":15,
		"can-operate-on":16,"modifies":17,"maintains":18,"rooted-in":19,
		"sustains":20,"formalizes":21,"seeks":22,"studies":23,"precedes":24,
		"problem-of":25,"applies":26,"grounded-in":27,"basis-of":28,
		"verified-by":29,"similar":30,"opposite":31,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
