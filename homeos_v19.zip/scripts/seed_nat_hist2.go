//go:build ignore
// go run scripts/seed_nat_hist2.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── TÀI NGUYÊN THIÊN NHIÊN / ĐỊA LÝ ────────────────────
		{"NAT_MOUNTAIN",    3, `label=núi|desc=địa hình cao hơn 600m so với xung quanh Himalaya Everest Alps Andes hình thành do kiến tạo|vi=núi,mountain|en=mountain|zh=山`},
		{"NAT_RIVER",       3, `label=sông|desc=dòng chảy nước ngọt tự nhiên hướng về biển hồ Amazon Mekong Nile Mississippi|vi=sông,river|en=river|zh=河流`},
		{"NAT_FOREST",      3, `label=rừng|desc=hệ sinh thái cây gỗ che phủ lớn rừng nhiệt đới ôn đới hàn đới Amazon Congo|vi=rừng,forest|en=forest|zh=森林`},
		{"NAT_DESERT",      3, `label=sa mạc|desc=vùng đất khô hạn lượng mưa dưới 250mm/năm Sahara Gobi Arabian môi trường khắc nghiệt|vi=sa mạc,desert|en=desert|zh=沙漠`},
		{"NAT_ARCTIC",      3, `label=cực Bắc|desc=vùng cực Bắc Trái Đất băng biển tan chảy do biến đổi khí hậu gấu Bắc Cực|vi=cực Bắc,Arctic,Bắc Cực|en=Arctic|zh=北极`},
		{"NAT_VOLCANO",     3, `label=núi lửa|desc=lỗ hổng trên vỏ Trái Đất phun trào dung nham Vesuvius Krakatoa Fuji hình thành đất màu mỡ|vi=núi lửa,volcano|en=volcano|zh=火山`},
		{"NAT_LAKE",        3, `label=hồ|desc=vùng nước đứng bao quanh đất liền Caspian Victoria Baikal hệ sinh thái nước ngọt|vi=hồ,lake|en=lake|zh=湖泊`},
		{"NAT_CAVE",        3, `label=hang động|desc=khoang rỗng tự nhiên trong đá Phong Nha Sơn Đoòng thạch nhũ hệ sinh thái tối|vi=hang động,cave,Phong Nha|en=cave|zh=洞穴`},
		{"NAT_MINERAL",     3, `label=khoáng sản|desc=tài nguyên khoáng vật tự nhiên trong đất đá than đá dầu mỏ kim loại quý hiếm|vi=khoáng sản,mineral resources|en=mineral resources|zh=矿产`},
		{"NAT_WETLAND",     3, `label=đất ngập nước|desc=hệ sinh thái vùng đất thường xuyên hay định kỳ ngập nước đầm lầy bãi triều|vi=đất ngập nước,wetland|en=wetland|zh=湿地`},

		// ── LỊCH SỬ HIỆN ĐẠI ────────────────────────────────────
		{"HIST2_WW2",        3, `label=Thế chiến II|desc=xung đột vũ trang toàn cầu 1939-1945 Đức Ý Nhật vs Đồng Minh Holocaust bom nguyên tử Hiroshima|vi=Thế chiến II,Chiến tranh thế giới thứ hai,WW2|en=World War II,WW2|zh=第二次世界大战`},
		{"HIST2_COLD_WAR",   3, `label=Chiến tranh Lạnh|desc=căng thẳng địa chính trị 1947-1991 Mỹ vs Liên Xô chạy đua vũ trang không gian|vi=Chiến tranh Lạnh,Cold War|en=Cold War|zh=冷战`},
		{"HIST2_IND_REV",    3, `label=Cách mạng Công nghiệp|desc=chuyển đổi sản xuất từ thủ công sang máy móc 18-19c Anh hơi nước nhà máy dệt|vi=Cách mạng Công nghiệp,Industrial Revolution|en=Industrial Revolution|zh=工业革命`},
		{"HIST2_COLONIALISM",3, `label=chủ nghĩa thực dân|desc=sự chiếm đóng và bóc lột lãnh thổ nước khác bởi các cường quốc châu Âu thế kỷ 15-20|vi=chủ nghĩa thực dân,colonialism|en=colonialism|zh=殖民主义`},
		{"HIST2_INTERNET_AGE",3,`label=kỷ nguyên internet|desc=giai đoạn từ 1990s web toàn cầu thương mại điện tử mạng xã hội số hóa toàn diện|vi=kỷ nguyên internet,kỷ nguyên số|en=internet age,digital age|zh=互联网时代`},
		{"HIST2_RENAISSANCE",3, `label=Phục hưng|desc=phong trào văn hóa châu Âu thế kỷ 14-17 Leonardo da Vinci khoa học nghệ thuật|vi=Phục hưng,Renaissance|en=Renaissance|zh=文艺复兴`},
		{"HIST2_FRENCH_REV", 3, `label=Cách mạng Pháp|desc=biến động chính trị xã hội 1789-1799 Pháp tự do bình đẳng bác ái Napoléon|vi=Cách mạng Pháp,French Revolution|en=French Revolution|zh=法国大革命`},
		{"HIST2_DECOLONIZE",3,  `label=giải thực dân|desc=quá trình các thuộc địa giành độc lập từ đế quốc thực dân sau WW2 châu Á Phi|vi=giải thực dân,decolonization,độc lập dân tộc|en=decolonization|zh=非殖民化`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Tự nhiên
		{"NAT_MOUNTAIN",    "GEO_PLATE",         "formed-by"},
		{"NAT_RIVER",       "GEO_WATER_CYCLE",   "part-of"},
		{"NAT_FOREST",      "ENV_BIODIVERSITY",  "hosts"},
		{"NAT_FOREST",      "ENV_CARBON",        "absorbs"},
		{"NAT_DESERT",      "ENV_CLIMATE_CHANGE","affected-by"},
		{"NAT_ARCTIC",      "ENV_CLIMATE_CHANGE","melted-by"},
		{"NAT_VOLCANO",     "GEO_PLATE",         "caused-by"},
		{"NAT_WETLAND",     "ENV_BIODIVERSITY",  "hosts"},
		{"NAT_WETLAND",     "ENV_CARBON",        "stores"},
		{"NAT_MINERAL",     "ECON_GDP",          "drives"},
		{"NAT_CAVE",        "PLACE_VIET_NAM",    "landmark-of"},
		// Lịch sử hiện đại
		{"HIST2_WW2",       "PHYS_NUCLEAR",      "used"},
		{"HIST2_WW2",       "HIST2_COLD_WAR",    "led-to"},
		{"HIST2_COLD_WAR",  "ASTRO_SPACE_RACE",  "spawned"},
		{"HIST2_IND_REV",   "ENERGY_FOSSIL",     "relied-on"},
		{"HIST2_IND_REV",   "ENV_CLIMATE_CHANGE","caused"},
		{"HIST2_COLONIALISM","HIST2_DECOLONIZE",  "followed-by"},
		{"HIST2_INTERNET_AGE","TECH_AI",         "enabled"},
		{"HIST2_RENAISSANCE","ART_PAINTING",     "flourished"},
		{"HIST2_FRENCH_REV","SOC_DEMOCRACY",     "advanced"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-28s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	fmt.Printf("✅ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"formed-by":1,"part-of":2,"hosts":3,"absorbs":4,"affected-by":5,
		"melted-by":6,"caused-by":7,"stores":8,"drives":9,"landmark-of":10,
		"used":11,"led-to":12,"spawned":13,"relied-on":14,"caused":15,
		"followed-by":16,"enabled":17,"flourished":18,"advanced":19,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
