//go:build ignore
// go run scripts/seed_soc_trans.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── XÃ HỘI / CỘNG ĐỒNG ────────────────────────────────────
		{"SOC_DEMOCRACY",   3, `label=dân chủ|desc=hệ thống chính trị người dân có quyền bầu cử lãnh đạo bảo vệ quyền con người tự do ngôn luận|vi=dân chủ,democracy|en=democracy|zh=民主`},
		{"SOC_HUMAN_RIGHTS",3, `label=nhân quyền|desc=quyền cơ bản của mọi người không phân biệt chủng tộc giới tính tôn giáo Tuyên ngôn Nhân quyền LHQ|vi=nhân quyền,human rights|en=human rights|zh=人权`},
		{"SOC_POVERTY",     3, `label=nghèo đói|desc=thiếu nguồn lực cơ bản để sống ổn định thu nhập thấp dưới mức nghèo xóa đói giảm nghèo|vi=nghèo đói,nghèo,poverty|en=poverty|zh=贫困`},
		{"SOC_MIGRATION",   3, `label=di cư|desc=sự dịch chuyển dân số từ vùng này sang vùng khác tị nạn nhập cư người lao động nước ngoài|vi=di cư,migration,nhập cư|en=migration,immigration|zh=移民`},
		{"SOC_GENDER",      3, `label=bình đẳng giới|desc=quyền bình đẳng giữa nam và nữ phong trào nữ quyền cơ hội việc làm lương bình đẳng|vi=bình đẳng giới,gender equality|en=gender equality,feminism|zh=性别平等`},
		{"SOC_VOLUNTEER",   3, `label=tình nguyện|desc=hoạt động đóng góp thời gian công sức không vì lợi nhuận cộng đồng xã hội dân sự|vi=tình nguyện,volunteer|en=volunteer,volunteering|zh=志愿者`},
		{"SOC_SOCIAL_MEDIA",3, `label=mạng xã hội|desc=nền tảng trực tuyến kết nối người dùng chia sẻ nội dung Facebook TikTok Instagram|vi=mạng xã hội,social media|en=social media|zh=社交媒体`},
		{"SOC_URBANIZATION",3, `label=đô thị hóa|desc=quá trình dân số tập trung vào thành thị tăng trưởng kinh tế cơ sở hạ tầng|vi=đô thị hóa,urbanization|en=urbanization|zh=城镇化`},
		{"SOC_AGING_POP",   3, `label=già hóa dân số|desc=tỷ lệ người cao tuổi tăng do sinh ít hơn sống thọ hơn tác động an sinh xã hội|vi=già hóa dân số,aging population|en=aging population|zh=人口老龄化`},
		{"SOC_INEQUALITY",  3, `label=bất bình đẳng|desc=chênh lệch thu nhập tài sản cơ hội giữa các nhóm xã hội hệ số Gini|vi=bất bình đẳng,inequality|en=inequality|zh=不平等`},

		// ── VẬN TẢI / LOGISTICS ────────────────────────────────────
		{"TRANS_SHIP",      3, `label=tàu biển|desc=phương tiện vận tải hàng hóa và hành khách trên biển container ship tàu chở dầu|vi=tàu biển,tàu,ship|en=ship,cargo ship|zh=轮船`},
		{"TRANS_AIRPLANE",  3, `label=máy bay|desc=phương tiện bay chở người hàng hóa qua bầu khí quyển động cơ phản lực Boeing Airbus|vi=máy bay,aircraft,airplane|en=airplane,aircraft|zh=飞机`},
		{"TRANS_TRAIN",     3, `label=tàu hỏa|desc=phương tiện vận tải trên đường ray chở hành khách hàng hóa tàu cao tốc Shinkansen|vi=tàu hỏa,tàu điện,train|en=train,railway|zh=火车`},
		{"TRANS_TRUCK",     3, `label=xe tải|desc=phương tiện vận tải hàng hóa trên đường bộ logistics chuỗi cung ứng kho bãi|vi=xe tải,truck|en=truck|zh=卡车`},
		{"TRANS_CONTAINER", 3, `label=container|desc=hộp kim loại tiêu chuẩn vận chuyển hàng hóa quốc tế TEU tàu container cảng biển|vi=container,thùng hàng|en=container,shipping container|zh=集装箱`},
		{"TRANS_LOGISTICS", 3, `label=logistics|desc=quản lý dòng chảy hàng hóa từ sản xuất đến tiêu thụ kho bãi vận tải chuỗi cung ứng|vi=logistics,chuỗi cung ứng|en=logistics,supply chain|zh=物流`},
		{"TRANS_PORT",      3, `label=cảng biển|desc=cơ sở hạ tầng cho tàu bè cập bến bốc dỡ hàng hóa cảng Rotterdam Singapore|vi=cảng biển,cảng|en=seaport,port|zh=港口`},
		{"TRANS_HIGHWAY",   3, `label=đường cao tốc|desc=đường bộ thiết kế tốc độ cao nhiều làn xe không giao cắt đồng mức kết nối vùng|vi=đường cao tốc,highway,freeway|en=highway,freeway|zh=高速公路`},
		{"TRANS_EV",        3, `label=xe điện|desc=phương tiện sử dụng động cơ điện thay xăng Tesla BYD pin lithium sạc điện|vi=xe điện,electric vehicle,EV|en=electric vehicle,EV|zh=电动汽车`},
		{"TRANS_DRONE",     3, `label=máy bay không người lái|desc=UAV drone điều khiển từ xa giao hàng giám sát quân sự nông nghiệp|vi=máy bay không người lái,drone,UAV|en=drone,UAV,unmanned aerial vehicle|zh=无人机`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Xã hội
		{"SOC_DEMOCRACY",    "SOC_HUMAN_RIGHTS",  "protects"},
		{"SOC_POVERTY",      "SOC_INEQUALITY",    "caused-by"},
		{"SOC_MIGRATION",    "SOC_URBANIZATION",  "drives"},
		{"SOC_GENDER",       "SOC_HUMAN_RIGHTS",  "part-of"},
		{"SOC_SOCIAL_MEDIA", "SOC_DEMOCRACY",     "affects"},
		{"SOC_AGING_POP",    "PH_AGING",          "related-to"},
		{"SOC_INEQUALITY",   "ECON_GDP",          "inverse-of"},
		{"SOC_URBANIZATION", "BUILD_URBAN",       "requires"},
		{"SOC_VOLUNTEER",    "SOC_POVERTY",       "reduces"},
		// Vận tải
		{"TRANS_SHIP",       "TRANS_CONTAINER",   "carries"},
		{"TRANS_CONTAINER",  "TRANS_LOGISTICS",   "enables"},
		{"TRANS_LOGISTICS",  "ECON_GDP",          "supports"},
		{"TRANS_AIRPLANE",   "ENERGY_FUEL",       "uses"},
		{"TRANS_EV",         "ENERGY_BATTERY",    "powered-by"},
		{"TRANS_EV",         "ENV_CARBON",        "reduces"},
		{"TRANS_DRONE",      "TECH_AI",           "enhanced-by"},
		{"TRANS_PORT",       "TRANS_SHIP",        "serves"},
		{"TRANS_HIGHWAY",    "BUILD_ROAD",        "type-of"},
		{"TRANS_TRAIN",      "ENERGY_ELECTRIC",   "uses"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"protects":1,"caused-by":2,"drives":3,"part-of":4,"affects":5,
		"related-to":6,"inverse-of":7,"requires":8,"reduces":9,"carries":10,
		"enables":11,"supports":12,"uses":13,"powered-by":14,"enhanced-by":15,
		"serves":16,"type-of":17,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
