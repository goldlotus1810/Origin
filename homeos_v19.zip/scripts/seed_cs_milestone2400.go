//go:build ignore
// go run scripts/seed_cs_milestone2400.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes, %d edges\n", be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── KHOA HỌC MÁY TÍNH (CS_) ──────────────────────────────
		{"CS_ALGORITHM",    3, `label=thuật toán|desc=tập hợp các bước hướng dẫn giải quyết vấn đề sắp xếp tìm kiếm đồ thị độ phức tạp O(n)|vi=thuật toán,algorithm|en=algorithm|zh=算法`},
		{"CS_DATA_STRUCT",  3, `label=cấu trúc dữ liệu|desc=cách tổ chức lưu trữ dữ liệu hiệu quả mảng danh sách liên kết cây stack queue hash|vi=cấu trúc dữ liệu,data structure|en=data structure|zh=数据结构`},
		{"CS_OS",           3, `label=hệ điều hành|desc=phần mềm quản lý tài nguyên phần cứng Linux Windows macOS kernel process thread|vi=hệ điều hành,operating system,OS|en=operating system|zh=操作系统`},
		{"CS_NETWORK",      3, `label=mạng máy tính|desc=hệ thống kết nối máy tính trao đổi dữ liệu TCP/IP HTTP DNS WiFi Ethernet LAN WAN|vi=mạng máy tính,computer network|en=computer network|zh=计算机网络`},
		{"CS_DATABASE_CS",  3, `label=cơ sở dữ liệu|desc=hệ thống lưu trữ truy vấn dữ liệu có cấu trúc SQL NoSQL MySQL PostgreSQL MongoDB|vi=cơ sở dữ liệu,database,SQL|en=database|zh=数据库`},
		{"CS_COMPILER",     3, `label=trình biên dịch|desc=chương trình dịch mã nguồn sang mã máy lexer parser AST code generation LLVM GCC|vi=trình biên dịch,compiler|en=compiler|zh=编译器`},
		{"CS_SECURITY",     3, `label=bảo mật máy tính|desc=bảo vệ hệ thống khỏi tấn công mã hóa xác thực firewall zero-day CVE penetration test|vi=bảo mật máy tính,cybersecurity,computer security|en=computer security|zh=计算机安全`},
		{"CS_PARALLEL",     3, `label=lập trình song song|desc=thực thi đồng thời nhiều tác vụ đa luồng GPU CUDA MapReduce phân tán|vi=lập trình song song,parallel computing|en=parallel computing|zh=并行计算`},
		{"CS_CLOUD_CS",     3, `label=điện toán đám mây|desc=cung cấp tài nguyên máy tính qua internet AWS GCP Azure IaaS PaaS SaaS serverless|vi=điện toán đám mây,cloud computing|en=cloud computing|zh=云计算`},
		{"CS_UI_UX",        3, `label=thiết kế giao diện|desc=UI/UX thiết kế trải nghiệm người dùng Figma prototype usability accessibility human-centered|vi=thiết kế giao diện,UI/UX|en=UI/UX,user interface|zh=界面设计`},

		// ── VẬT LÝ BỔ SUNG (PHYS3_) ──────────────────────────────
		{"PHYS3_OPTICS",    3, `label=quang học|desc=nghiên cứu ánh sáng phản xạ khúc xạ nhiễu xạ phân cực kính hiển vi telescope laser|vi=quang học,optics|en=optics|zh=光学`},
		{"PHYS3_ACOUSTICS", 3, `label=âm học|desc=nghiên cứu âm thanh sóng âm tần số biên độ cộng hưởng siêu âm y tế sonar|vi=âm học,acoustics|en=acoustics|zh=声学`},
		{"PHYS3_THERMO",    3, `label=nhiệt động lực học|desc=nghiên cứu nhiệt năng entropy 4 định luật nhiệt động lực học máy hơi nước Carnot|vi=nhiệt động lực học,thermodynamics|en=thermodynamics|zh=热力学`},
		{"PHYS3_NUCLEAR",   3, `label=vật lý hạt nhân|desc=nghiên cứu hạt nhân nguyên tử phản ứng phân hạch tổng hợp hạt nhân năng lượng hạt nhân|vi=vật lý hạt nhân,nuclear physics|en=nuclear physics|zh=核物理`},

		// ── HOÁ HỌC BỔ SUNG (CHEM2_) ─────────────────────────────
		{"CHEM2_ORGANIC",   3, `label=hóa học hữu cơ|desc=nghiên cứu hợp chất carbon hydro oxy nitơ benzene polymer dược phẩm nhựa|vi=hóa học hữu cơ,organic chemistry|en=organic chemistry|zh=有机化学`},
		{"CHEM2_POLYMER",   3, `label=polyme|desc=phân tử chuỗi dài lặp lại monomer nhựa cao su sợi tổng hợp PET nylon protein|vi=polyme,polymer|en=polymer|zh=聚合物`},
		{"CHEM2_CATALYST",  3, `label=xúc tác|desc=chất làm tăng tốc phản ứng hóa học mà không bị tiêu thụ enzyme kim loại quý|vi=xúc tác,catalyst|en=catalyst|zh=催化剂`},

		// ── TOÁN HỌC BỔ SUNG (MATH3_) ────────────────────────────
		{"MATH3_CALCULUS",  3, `label=giải tích|desc=vi phân tích phân đạo hàm tích phân giới hạn Newton Leibniz ứng dụng vật lý kỹ thuật|vi=giải tích,calculus|en=calculus|zh=微积分`},
		{"MATH3_LINEAR",    3, `label=đại số tuyến tính|desc=vector ma trận hệ phương trình tuyến tính eigenvalue biến đổi tuyến tính học máy|vi=đại số tuyến tính,linear algebra|en=linear algebra|zh=线性代数`},
		{"MATH3_DISCRETE",  3, `label=toán học rời rạc|desc=logic tổ hợp lý thuyết đồ thị mã hóa thuật toán cơ sở khoa học máy tính|vi=toán học rời rạc,discrete math|en=discrete mathematics|zh=离散数学`},
		{"MATH3_STATS",     3, `label=thống kê|desc=thu thập phân tích giải thích dữ liệu phân phối chuẩn p-value hồi quy Bayes|vi=thống kê,statistics|en=statistics|zh=统计学`},

		// ── KIẾN TRÚC / XÂY DỰNG BỔ SUNG (ARCH_) ─────────────────
		{"ARCH_BAROQUE",    3, `label=kiến trúc baroque|desc=phong cách kiến trúc Châu Âu thế kỷ 17-18 trang trí phức tạp nhà thờ cung điện Versailles|vi=kiến trúc baroque,baroque|en=baroque architecture|zh=巴洛克建筑`},
		{"ARCH_MODERN",     3, `label=kiến trúc hiện đại|desc=phong cách thế kỷ 20 đơn giản hóa bê tông kính thép Le Corbusier Bauhaus chức năng|vi=kiến trúc hiện đại,modern architecture|en=modern architecture|zh=现代建筑`},
		{"ARCH_SUSTAINABLE",3, `label=kiến trúc bền vững|desc=thiết kế tiết kiệm năng lượng thân thiện môi trường LEED tấm pin mặt trời nhà thụ động|vi=kiến trúc bền vững,sustainable architecture|en=sustainable architecture|zh=可持续建筑`},

		// ── NHÂN VẬT HỌC / KHẢO CỔ (ANTH_) ──────────────────────
		{"ANTH_ARCHAEOLOGY",3, `label=khảo cổ học|desc=nghiên cứu quá khứ qua di vật khai quật carbon-14 DNA cổ đại Pompeii|vi=khảo cổ học,archaeology|en=archaeology|zh=考古学`},
		{"ANTH_ANTHROPOLOGY",3,`label=nhân học|desc=nghiên cứu con người văn hóa ngôn ngữ tiến hóa xã hội so sánh văn hóa|vi=nhân học,anthropology|en=anthropology|zh=人类学`},

		// ── TRIẾT HỌC BỔ SUNG (PHIL2_) ───────────────────────────
		{"PHIL2_ETHICS",    3, `label=đạo đức học|desc=nghiên cứu đúng sai lý thuyết đạo đức Kant hậu quả luận đức hạnh ứng dụng AI y tế|vi=đạo đức học,ethics|en=ethics|zh=伦理学`},
		{"PHIL2_EPISTEM",   3, `label=nhận thức luận|desc=nghiên cứu bản chất nguồn gốc tri thức Plato Descartes Hume thực nghiệm luận|vi=nhận thức luận,epistemology|en=epistemology|zh=认识论`},
		{"PHIL2_LOGIC",     3, `label=logic học|desc=nghiên cứu lý luận đúng đắn mệnh đề suy luận logic hình thức Aristotle Boole|vi=logic học,logic|en=logic|zh=逻辑学`},

		// ── THIÊN VĂN BỔ SUNG (ASTRO3_) ──────────────────────────
		{"ASTRO3_GALAXY",   3, `label=thiên hà|desc=hệ thống hàng tỷ sao hành tinh khí bụi Milky Way Andromeda hình xoắn ốc elliptical|vi=thiên hà,galaxy,Milky Way|en=galaxy|zh=星系`},
		{"ASTRO3_EXOPLANET",3, `label=ngoại hành tinh|desc=hành tinh ngoài Hệ Mặt Trời James Webb TRAPPIST-1 vùng sống được biomarker|vi=ngoại hành tinh,exoplanet|en=exoplanet|zh=系外行星`},
		{"ASTRO3_NEBULA",   3, `label=tinh vân|desc=đám mây khí bụi không gian vũ trụ Orion Nebula sao mới hình thành|vi=tinh vân,nebula|en=nebula|zh=星云`},

		// ── VĂN HÓA VIỆT NAM (VN_) ────────────────────────────────
		{"VN_AO_DAI",       3, `label=áo dài|desc=trang phục truyền thống Việt Nam cổ đứng tà dài lụa Hà Đông biểu tượng văn hóa|vi=áo dài,aodai|en=ao dai|zh=越南长袍`},
		{"VN_PHO",          3, `label=phở|desc=món ăn truyền thống Việt Nam nước dùng xương bò bánh phở thịt bò gà rau thơm|vi=phở,pho|en=pho|zh=越南河粉`},
		{"VN_TET",          3, `label=Tết Nguyên Đán|desc=lễ hội lớn nhất Việt Nam đón năm mới âm lịch thăm gia đình lì xì mai đào|vi=Tết Nguyên Đán,Tết,tết|en=Tet,Vietnamese New Year|zh=越南春节`},
		{"VN_HA_LONG",      3, `label=Vịnh Hạ Long|desc=di sản thiên nhiên UNESCO Quảng Ninh đảo đá vôi hang động du lịch|vi=Vịnh Hạ Long,Halong Bay|en=Halong Bay|zh=下龙湾`},
		{"VN_HO_CHI_MINH",  3, `label=Hồ Chí Minh|desc=lãnh tụ Cách mạng Việt Nam 1890-1969 Bác Hồ thống nhất đất nước độc lập dân tộc|vi=Hồ Chí Minh,Bác Hồ|en=Ho Chi Minh|zh=胡志明`},
		{"VN_WATER_PUPPET", 3, `label=múa rối nước|desc=nghệ thuật biểu diễn truyền thống Việt Nam con rối trên mặt nước đồng bằng sông Hồng|vi=múa rối nước,water puppet|en=water puppet|zh=水上木偶`},

		// ── SỨC KHỎE / THỂ THAO (HLTH_) ─────────────────────────
		{"HLTH_CARDIO",     3, `label=tim mạch học|desc=nghiên cứu điều trị bệnh tim mạch nhồi máu cơ tim tăng huyết áp suy tim stent|vi=tim mạch học,cardiology|en=cardiology|zh=心脏病学`},
		{"HLTH_ONCOLOGY",   3, `label=ung thư học|desc=nghiên cứu điều trị ung thư hóa trị xạ trị liệu pháp miễn dịch tế bào CAR-T sinh thiết|vi=ung thư học,oncology,ung thư|en=oncology|zh=肿瘤学`},
		{"HLTH_NUTRITION",  3, `label=khoa học dinh dưỡng|desc=nghiên cứu tác động thực phẩm sức khỏe chế độ ăn Mediterranean DASH béo phì|vi=khoa học dinh dưỡng,nutrition science|en=nutrition science|zh=营养科学`},
		{"HLTH_EXERCISE",   3, `label=khoa học tập luyện|desc=nghiên cứu ảnh hưởng vận động sức khỏe VO2 max sức mạnh HIIT recovery|vi=khoa học tập luyện,exercise science|en=exercise science|zh=运动科学`},

		// ── KINH TẾ VI MÔ BỔ SUNG (MICRO2_) ─────────────────────
		{"MICRO2_MARKET",   3, `label=cơ chế thị trường|desc=cung cầu quyết định giá cả equilibrium externality market failure cạnh tranh hoàn hảo|vi=cơ chế thị trường,market mechanism|en=market mechanism|zh=市场机制`},
		{"MICRO2_GAME",     3, `label=lý thuyết trò chơi|desc=mô hình toán học ra quyết định chiến lược Nash equilibrium tù nhân Schelling điểm|vi=lý thuyết trò chơi,game theory|en=game theory|zh=博弈论`},
		{"MICRO2_BEHAV",    3, `label=kinh tế học hành vi|desc=nghiên cứu ảnh hưởng tâm lý quyết định kinh tế Kahneman Thaler nudge heuristics bias|vi=kinh tế học hành vi,behavioral economics|en=behavioral economics|zh=行为经济学`},

		// ── NĂNG LƯỢNG CHI TIẾT (NRG_) ───────────────────────────
		{"NRG_BATTERY",     3, `label=pin|desc=thiết bị lưu trữ năng lượng điện hóa lithium-ion solid-state pin xe điện Tesla|vi=pin,battery|en=battery|zh=电池`},
		{"NRG_WIND",        3, `label=điện gió|desc=chuyển đổi động năng gió thành điện turbine gió offshore onshore GW tua-bin|vi=điện gió,wind power,turbine gió|en=wind power|zh=风力发电`},
		{"NRG_GEOTHERMAL",  3, `label=địa nhiệt|desc=năng lượng từ nhiệt bên trong Trái Đất Iceland nhà máy địa nhiệt phát điện sưởi ấm|vi=địa nhiệt,geothermal|en=geothermal energy|zh=地热能`},

		// ── THIẾT KẾ / NGHỆ THUẬT BỔ SUNG (DESIGN_) ─────────────
		{"DESIGN_GRAPHIC",  3, `label=thiết kế đồ họa|desc=tạo hình ảnh truyền thông trực quan typography màu sắc bố cục Photoshop Illustrator|vi=thiết kế đồ họa,graphic design|en=graphic design|zh=平面设计`},
		{"DESIGN_PRODUCT",  3, `label=thiết kế sản phẩm|desc=tạo sản phẩm hữu dụng đẹp ergonomics prototyping user testing Dieter Rams Apple|vi=thiết kế sản phẩm,product design|en=product design|zh=产品设计`},
		{"DESIGN_FASHION",  3, `label=thiết kế thời trang|desc=tạo quần áo phụ kiện xu hướng haute couture Chanel Dior bền vững fast fashion|vi=thiết kế thời trang,fashion design|en=fashion design|zh=时装设计`},

		// ── ÂM NHẠC BỔ SUNG (MUSIC_) ─────────────────────────────
		{"MUSIC_THEORY",    3, `label=lý thuyết âm nhạc|desc=nghiên cứu cấu trúc âm nhạc hợp âm giai điệu nhịp điệu ký hiệu nhạc|vi=lý thuyết âm nhạc,music theory|en=music theory|zh=乐理`},
		{"MUSIC_JAZZ",      3, `label=nhạc jazz|desc=thể loại âm nhạc nguồn gốc Mỹ gốc Phi ứng tấu swing bebop Miles Davis Coltrane|vi=nhạc jazz,jazz|en=jazz|zh=爵士乐`},
		{"MUSIC_CLASSICAL", 3, `label=nhạc cổ điển|desc=âm nhạc Châu Âu thế kỷ 17-19 Bach Mozart Beethoven giao hưởng sonata concerto|vi=nhạc cổ điển,classical music|en=classical music|zh=古典音乐`},

		// ── ĐIỆN ẢNH / TRUYỀN THÔNG (MEDIA_) ─────────────────────
		{"MEDIA_FILM",      3, `label=điện ảnh|desc=nghệ thuật kể chuyện qua hình ảnh chuyển động đạo diễn biên kịch đặc hiệu ứng Oscar|vi=điện ảnh,film,cinema|en=cinema,film|zh=电影`},
		{"MEDIA_JOURNALISM",3, `label=báo chí|desc=thu thập truyền đạt thông tin đến công chúng phóng viên biên tập kiểm chứng tự do báo chí|vi=báo chí,journalism|en=journalism|zh=新闻业`},
		{"MEDIA_PODCAST",   3, `label=podcast|desc=nội dung âm thanh số phát sóng theo tập Spotify Apple chủ đề đa dạng|vi=podcast|en=podcast|zh=播客`},

		// ── MÔI TRƯỜNG BỔ SUNG (ENV2_) ────────────────────────────
		{"ENV2_PLASTIC",    3, `label=ô nhiễm nhựa|desc=rác thải nhựa đại dương microplastic Great Pacific Garbage Patch sinh vật biển|vi=ô nhiễm nhựa,plastic pollution|en=plastic pollution|zh=塑料污染`},
		{"ENV2_DEFOREST",   3, `label=phá rừng|desc=mất rừng do nông nghiệp khai thác gỗ đô thị hóa Amazon CO2 đa dạng sinh học|vi=phá rừng,deforestation|en=deforestation|zh=森林砍伐`},
		{"ENV2_WATER",      3, `label=khủng hoảng nước|desc=thiếu hụt nước sạch 2 tỷ người thiếu ô nhiễm nước biến đổi khí hậu|vi=khủng hoảng nước,water crisis|en=water crisis|zh=水资源危机`},
		{"ENV2_AIR",        3, `label=ô nhiễm không khí|desc=PM2.5 NO2 CO ozone tầng mặt đất WHO khuyến nghị sức khỏe đô thị|vi=ô nhiễm không khí,air pollution|en=air pollution|zh=空气污染`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// CS
		{"CS_ALGORITHM",    "MATH2_GRAPH",         "uses"},
		{"CS_ALGORITHM",    "MATH3_DISCRETE",      "grounded-in"},
		{"CS_DATABASE_CS",  "DIG_DATABASE",        "implements"},
		{"CS_CLOUD_CS",     "DIG_CLOUD",           "implements"},
		{"CS_SECURITY",     "DIG_CYBERSEC",        "part-of"},
		{"CS_NETWORK",      "DIG_INTERNET",        "enables"},
		{"CS_PARALLEL",     "TECH_ML",             "accelerates"},
		// Vật lý
		{"PHYS3_OPTICS",    "PHYS2_QUANTUM",       "uses"},
		{"PHYS3_THERMO",    "ENERGY_FOSSIL",       "underlies"},
		{"PHYS3_NUCLEAR",   "ENERGY_NUCLEAR",      "basis-of"},
		// Hoá học
		{"CHEM2_ORGANIC",   "BIO2_PROTEIN",        "describes"},
		{"CHEM2_POLYMER",   "MATL_PLASTICS",       "includes"},
		// Toán học
		{"MATH3_CALCULUS",  "PHYS2_QUANTUM",       "used-in"},
		{"MATH3_LINEAR",    "TECH_ML",             "foundation-of"},
		{"MATH3_STATS",     "MATH2_PROBABILITY",   "extends"},
		// Việt Nam
		{"VN_HA_LONG",      "PLACE_VIET_NAM",      "part-of"},
		{"VN_TET",          "PLACE_VIET_NAM",      "celebrated-in"},
		{"VN_PHO",          "FOOD_CULTURE",        "part-of"},
		// Sức khoẻ
		{"HLTH_CARDIO",     "ANAT_HEART",          "studies"},
		{"HLTH_ONCOLOGY",   "BIO2_CELL_DIVISION",  "studies"},
		{"HLTH_NUTRITION",  "NUTR_MICRONUTRIENT",  "includes"},
		// Năng lượng
		{"NRG_BATTERY",     "ENERGY_SOLAR",        "stores"},
		{"NRG_WIND",        "ENERGY_RENEWABLE",    "part-of"},
		// Môi trường
		{"ENV2_DEFOREST",   "NAT_FOREST",          "destroys"},
		{"ENV2_PLASTIC",    "OCEAN_CORAL",         "threatens"},
		{"ENV2_WATER",      "ENV_CLIMATE_CHANGE",  "worsened-by"},
		// Triết học
		{"PHIL2_ETHICS",    "TECH_AI",             "governs"},
		{"PHIL2_LOGIC",     "MATH3_DISCRETE",      "basis-of"},
		// Thiên văn
		{"ASTRO3_GALAXY",   "ASTRO2_DARK_MATTER",  "contains"},
		{"ASTRO3_EXOPLANET","ASTRO2_BIG_BANG",     "result-of"},
		// Âm nhạc
		{"MUSIC_JAZZ",      "ART_MUSIC",           "genre-of"},
		{"MUSIC_CLASSICAL", "ART_MUSIC",           "genre-of"},
		// Game theory
		{"MICRO2_GAME",     "ECON_MARKET",         "analyzes"},
		{"MICRO2_BEHAV",    "PSY2_MOTIVATION",     "draws-from"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2400 { fmt.Println("🎉 MILESTONE 2400!") }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"uses":1,"grounded-in":2,"implements":3,"part-of":4,"enables":5,
		"accelerates":6,"underlies":7,"basis-of":8,"describes":9,"includes":10,
		"used-in":11,"foundation-of":12,"extends":13,"celebrated-in":14,
		"studies":15,"stores":16,"destroys":17,"threatens":18,"worsened-by":19,
		"governs":20,"contains":21,"result-of":22,"genre-of":23,"analyzes":24,
		"draws-from":25,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
