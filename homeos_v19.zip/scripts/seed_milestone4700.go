//go:build ignore
// seed_milestone4700.go — MILESTONE 4700 — ~140 nodes mới
// Domains: NEUROSCI3_ PSYCH3_ COGPSYCH_ CLINPSYCH_ NEUROPSYCH_
//          ECON4_ BEHAVECON_ DEVECON_ LABOREC_ MACROEC2_
//          MEDIA4_ JOURNALISM_ SOCIALMEDIA2_ FILM3_ PODCAST_
//          INDIA_ INDONESIA_ BRAZIL_ TURKEY_ NIGERIA_
//          VNTRADE_ VNENERGY_ VNHEALTH_ VNDIGITAL2_ VNINNOVATE_
//          OPTIM_ GRAPHTHEORY_ TOPOLOGY2_ PROBABILITY2_ NUMTHEORY_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── NEUROSCIENCE 3 ────────────────────────────────────────────
		{"NEUROSCI3_CONNECTOME",3,`label=connectome|desc=connectome wiring diagram C elegans mouse Human Connectome Project diffusion MRI tractography synapse graph|vi=connectome,connectome|en=connectome`},
		{"NEUROSCI3_OPTOGEN",   3,`label=quang di truyền học|desc=optogenetics channelrhodopsin Deisseroth light pulse neuron circuit causal interrogation behavior viral vector|vi=quang di truyền học,optogenetics|en=optogenetics`},
		{"NEUROSCI3_SPATIAL",   3,`label=trí nhớ không gian|desc=spatial memory hippocampus place cell grid cell O'Keefe Moser Nobel cognitive map navigation theta oscillation|vi=trí nhớ không gian,spatial memory|en=spatial memory`},
		{"NEUROSCI3_PAIN",      3,`label=thần kinh học đau|desc=pain neuroscience nociception spinal dorsal horn ascending pathway opioid gate control chronic sensitization|vi=thần kinh học đau,pain neuroscience|en=pain neuroscience`},
		{"NEUROSCI3_REWARD",    3,`label=hệ thống phần thưởng não|desc=reward system dopamine nucleus accumbens VTA mesolimbic prediction error addiction craving cue|vi=hệ thống phần thưởng não,reward system|en=reward system`},

		// ── PSYCHOLOGY 3 ──────────────────────────────────────────────
		{"PSYCH3_POSITIVE",     3,`label=tâm lý học tích cực|desc=positive psychology Seligman PERMA wellbeing flourishing character strengths VIA gratitude savoring flow|vi=tâm lý học tích cực,positive psychology|en=positive psychology`},
		{"PSYCH3_TRAUMA",       3,`label=tâm lý học sang chấn|desc=trauma psychology PTSD ACEs adverse childhood polyvagal theory window tolerance somatic experiencing EMDR|vi=tâm lý học sang chấn,trauma psychology|en=trauma psychology`},
		{"PSYCH3_CULTURAL",     3,`label=tâm lý học văn hóa|desc=cultural psychology WEIRD individualism collectivism honor culture self-construal Hofstede emic etic|vi=tâm lý học văn hóa,cultural psychology|en=cultural psychology`},
		{"COGPSYCH_DECISION",   3,`label=ra quyết định nhận thức|desc=decision making dual process System 1 2 Kahneman Tversky prospect theory framing anchoring loss aversion|vi=ra quyết định nhận thức,decision making|en=decision making`},
		{"CLINPSYCH_CBT2",      3,`label=liệu pháp nhận thức hành vi nâng cao|desc=CBT third wave ACT acceptance commitment DBT dialectical mindfulness-based cognitive MBCT|vi=liệu pháp nhận thức hành vi nâng cao,third wave CBT|en=third wave CBT`},

		// ── ECONOMICS 4 ───────────────────────────────────────────────
		{"ECON4_PLATFORM",      3,`label=kinh tế nền tảng số|desc=platform economics two-sided market network effect tipping point winner-take-all antitrust DMA regulation|vi=kinh tế nền tảng số,platform economics|en=platform economics`},
		{"ECON4_CLIMATE",       3,`label=kinh tế khí hậu|desc=climate economics Stern Review social cost carbon Nordhaus DICE tipping damage function IAM uncertainty|vi=kinh tế khí hậu,climate economics|en=climate economics`},
		{"BEHAVECON_NUDGE",     3,`label=kinh tế học hành vi và nudge|desc=behavioral economics nudge Thaler Sunstein choice architecture default opt-in organ donation pension|vi=kinh tế học hành vi và nudge,nudge theory|en=nudge theory`},
		{"BEHAVECON_INEQUALITY",3,`label=bất bình đẳng kinh tế|desc=inequality Gini top 1% Piketty r>g wealth concentration intergenerational mobility Chetty opportunity|vi=bất bình đẳng kinh tế,economic inequality|en=economic inequality`},
		{"LABOREC_FUTURE",      3,`label=tương lai việc làm|desc=future of work automation displacement Autor task framework routine non-routine complementarity UBI reskilling|vi=tương lai việc làm,future of work|en=future of work`},

		// ── MACROECONOMICS 2 ──────────────────────────────────────────
		{"MACROEC2_MMT",        3,`label=lý thuyết tiền tệ hiện đại|desc=Modern Monetary Theory MMT sovereign currency deficit spending functional finance Kelton inflation constraint|vi=lý thuyết tiền tệ hiện đại,MMT|en=Modern Monetary Theory`},
		{"MACROEC2_SECULAR",    3,`label=trì trệ thế tục|desc=secular stagnation Summers demand shortfall saving glut neutral rate R-star fiscal space aging demographics|vi=trì trệ thế tục,secular stagnation|en=secular stagnation`},
		{"DEVECON_MICRO",       3,`label=kinh tế phát triển vi mô|desc=development economics randomized control trial Duflo Banerjee Kremer J-PAL microfinance treatment effect|vi=kinh tế phát triển vi mô,development economics RCT|en=development economics RCT`},
		{"DEVECON_INSTITUTION", 3,`label=thể chế và phát triển|desc=institutions development Acemoglu Johnson Robinson extractive inclusive property rights rule of law|vi=thể chế và phát triển,institutions development|en=institutions development`},
		{"LABOREC_MINIMUM_WAGE",3,`label=lương tối thiểu|desc=minimum wage Card Krueger Seattle $15 monopsony labor market spillover teen employment elasticity|vi=lương tối thiểu,minimum wage|en=minimum wage`},

		// ── MEDIA 4 & JOURNALISM ──────────────────────────────────────
		{"MEDIA4_TRUST",        3,`label=niềm tin vào truyền thông|desc=media trust Edelman Reuters Institute polarization partisan local news desert subscription model|vi=niềm tin vào truyền thông,media trust|en=media trust`},
		{"JOURNALISM_DATA",     3,`label=báo chí dữ liệu|desc=data journalism investigative ICIJ Panama Papers scraping visualization D3 Flourish Datawrapper public interest|vi=báo chí dữ liệu,data journalism|en=data journalism`},
		{"JOURNALISM_SAFETY",   3,`label=an toàn nhà báo|desc=journalist safety CPJ RSF impunity murder detention digital security spyware Pegasus source protection|vi=an toàn nhà báo,journalist safety|en=journalist safety`},
		{"SOCIALMEDIA2_ALGO",   3,`label=thuật toán mạng xã hội|desc=social media algorithm recommendation engagement outrage amplification filter bubble rabbit hole Facebook TikTok|vi=thuật toán mạng xã hội,social media algorithm|en=social media algorithm`},
		{"SOCIALMEDIA2_MENTAL", 3,`label=mạng xã hội và sức khỏe tâm thần|desc=social media mental health adolescent girls Instagram comparison Haidt Twenge screen time causal debate|vi=mạng xã hội và sức khỏe tâm thần,social media mental health|en=social media mental health`},

		// ── FILM 3 & PODCAST ──────────────────────────────────────────
		{"FILM3_INDIE",         3,`label=phim độc lập|desc=indie film Sundance A24 low budget auteur distribution VOD streaming festival circuit foreign language|vi=phim độc lập,indie film|en=indie film`},
		{"FILM3_DOCUMENTARY",   3,`label=phim tài liệu|desc=documentary film observational performative expository reflexive poetic Netflix subject ethics reenactment|vi=phim tài liệu,documentary film|en=documentary film`},
		{"FILM3_VIET",          3,`label=điện ảnh Việt Nam|desc=điện ảnh Việt Nam Đất Phương Nam Mùa Len Trâu Trần Anh Hùng Scent Green Papaya quốc tế coproduction|vi=điện ảnh Việt Nam,Vietnamese cinema|en=Vietnamese cinema`},
		{"PODCAST_ECON",        3,`label=podcast giáo dục và kinh doanh|desc=podcast education business Freakonomics Planet Money How I Built This Acquired Lex Fridman form long|vi=podcast giáo dục và kinh doanh,education podcast|en=education podcast`},
		{"MEDIA4_LOCAL",        3,`label=truyền thông địa phương|desc=local news decline newspaper closure civic engagement voter turnout corruption accountability watchdog|vi=truyền thông địa phương,local news|en=local news`},

		// ── MAJOR ECONOMIES (INDIA → NIGERIA) ────────────────────────
		{"INDIA_ECONOMY",       3,`label=kinh tế Ấn Độ|desc=India economy 5th largest GDP service IT sector UPI digital payment NIFTY unicorn startup Modi Make in India|vi=kinh tế Ấn Độ,India economy|en=India economy`},
		{"INDIA_SOCIETY",       3,`label=xã hội Ấn Độ|desc=India society caste reservation OBC Dalit communal tension Hindu nationalism BJP Hindutva secularism|vi=xã hội Ấn Độ,India society|en=India society`},
		{"INDIA_TECH",          3,`label=công nghệ Ấn Độ|desc=India tech Infosys TCS Wipro outsourcing Bangalore IIT brain drain return reverse diaspora startup|vi=công nghệ Ấn Độ,India tech|en=India tech`},
		{"INDONESIA_ECONOMY",   3,`label=kinh tế Indonesia|desc=Indonesia economy ASEAN largest archipelago commodity palm oil coal nickel EV battery supply chain|vi=kinh tế Indonesia,Indonesia economy|en=Indonesia economy`},
		{"INDONESIA_SOCIETY",   3,`label=xã hội Indonesia|desc=Indonesia society 270M Muslim majority Pancasila pluralism ethnic diversity Papua decentralization|vi=xã hội Indonesia,Indonesia society|en=Indonesia society`},

		{"BRAZIL_AMAZON",       3,`label=Brazil và Amazon|desc=Brazil Amazon deforestation Bolsonaro Lula indigenous land rights soy cattle carbon sink tipping point|vi=Brazil và Amazon,Brazil Amazon|en=Brazil Amazon`},
		{"BRAZIL_ECONOMY",      3,`label=kinh tế Brazil|desc=Brazil economy Petrobras offshore oil Embraer agribusiness inequality Bolsa Familia conditional cash transfer|vi=kinh tế Brazil,Brazil economy|en=Brazil economy`},
		{"TURKEY_GEOPOLIT",     3,`label=địa chính trị Thổ Nhĩ Kỳ|desc=Turkey geopolitics NATO Erdogan S-400 Russia Syria Kurdish Bosphorus Black Sea grain corridor|vi=địa chính trị Thổ Nhĩ Kỳ,Turkey geopolitics|en=Turkey geopolitics`},
		{"NIGERIA_DEVELOP",     3,`label=phát triển Nigeria|desc=Nigeria development largest Africa economy oil curse Nollywood fintech Lagos megacity diaspora remittance|vi=phát triển Nigeria,Nigeria development|en=Nigeria development`},
		{"NIGERIA_TECH",        3,`label=công nghệ Nigeria|desc=Nigeria tech Paystack Flutterwave Andela Lagos Silicon Africa fintech mobile money unbanked M-Pesa|vi=công nghệ Nigeria,Nigeria tech|en=Nigeria tech`},

		// ── VIETNAM: TRADE, ENERGY, HEALTH, DIGITAL ──────────────────
		{"VNTRADE_EXPORT",      3,`label=xuất khẩu Việt Nam|desc=xuất khẩu Việt Nam điện tử Samsung LG Nike Adidas dệt may 300 tỷ USD FDI chuỗi cung ứng RCEP|vi=xuất khẩu Việt Nam,Vietnam exports|en=Vietnam exports`},
		{"VNTRADE_FTA",         3,`label=hiệp định thương mại tự do Việt Nam|desc=FTA Việt Nam EVFTA CPTPP RCEP UKVFTA thị trường EU Mỹ Nhật Hàn thuế quan quy tắc xuất xứ|vi=hiệp định thương mại tự do Việt Nam,Vietnam FTA|en=Vietnam FTA`},
		{"VNENERGY_SOLAR",      3,`label=năng lượng mặt trời Việt Nam|desc=điện mặt trời Việt Nam 16GW FIT giá mái nhà trang trại nối lưới EVN quá tải đường dây|vi=năng lượng mặt trời Việt Nam,Vietnam solar energy|en=Vietnam solar energy`},
		{"VNENERGY_WIND",       3,`label=năng lượng gió Việt Nam|desc=điện gió Việt Nam offshore onshore Bình Thuận Ninh Thuận Gia Lai tiềm năng 475GW quy hoạch 8|vi=năng lượng gió Việt Nam,Vietnam wind energy|en=Vietnam wind energy`},
		{"VNHEALTH_SYSTEM",     3,`label=hệ thống y tế Việt Nam|desc=hệ thống y tế Việt Nam bảo hiểm y tế toàn dân bệnh viện tuyến cơ sở quá tải Bộ Y tế dịch vụ tư nhân|vi=hệ thống y tế Việt Nam,Vietnam health system|en=Vietnam health system`},

		{"VNHEALTH_NONCOMM",    3,`label=bệnh không lây nhiễm Việt Nam|desc=bệnh không lây nhiễm Việt Nam ung thư tim mạch tiểu đường béo phì thuốc lá đô thị hóa lối sống|vi=bệnh không lây nhiễm Việt Nam,Vietnam NCDs|en=Vietnam NCDs`},
		{"VNDIGITAL2_ECOM",     3,`label=thương mại điện tử Việt Nam|desc=thương mại điện tử Việt Nam Shopee Lazada TikTok Shop Tiki logistics last-mile thanh toán COD|vi=thương mại điện tử Việt Nam,Vietnam ecommerce|en=Vietnam ecommerce`},
		{"VNDIGITAL2_STARTUP",  3,`label=startup Việt Nam|desc=startup Việt Nam unicorn VNG VNPay Sky Mavis Axie Infinity Momo ecosystem ecosystem investor|vi=startup Việt Nam,Vietnam startup|en=Vietnam startup`},
		{"VNINNOVATE_POLICY",   3,`label=chính sách đổi mới sáng tạo Việt Nam|desc=đổi mới sáng tạo Việt Nam chiến lược 2030 sandbox thí điểm trung tâm SHTP Hòa Lạc NIC|vi=chính sách đổi mới sáng tạo Việt Nam,Vietnam innovation policy|en=Vietnam innovation policy`},
		{"VNINNOVATE_TALENT",   3,`label=nhân tài công nghệ Việt Nam|desc=nhân tài công nghệ Việt Nam kỹ sư lập trình viên STEM đào tạo chất lượng Topdev giữ chân|vi=nhân tài công nghệ Việt Nam,Vietnam tech talent|en=Vietnam tech talent`},

		// ── MATHEMATICS ───────────────────────────────────────────────
		{"OPTIM_CONVEX",        3,`label=tối ưu lồi|desc=convex optimization CVX CVXPY gradient descent SGD Adam constraint duality KKT conditions LP QP SOCP SDP|vi=tối ưu lồi,convex optimization|en=convex optimization`},
		{"OPTIM_STOCHASTIC",    3,`label=tối ưu ngẫu nhiên|desc=stochastic optimization mini-batch variance reduction SVRG SAGA momentum Nesterov convergence rate|vi=tối ưu ngẫu nhiên,stochastic optimization|en=stochastic optimization`},
		{"OPTIM_COMBINATORIAL", 3,`label=tối ưu tổ hợp|desc=combinatorial optimization TSP NP-hard branch bound integer programming heuristic metaheuristic simulated annealing|vi=tối ưu tổ hợp,combinatorial optimization|en=combinatorial optimization`},
		{"GRAPHTHEORY_SPECTRAL",3,`label=lý thuyết đồ thị phổ|desc=spectral graph theory Laplacian eigenvalue Fiedler algebraic connectivity graph cut normalized partitioning|vi=lý thuyết đồ thị phổ,spectral graph theory|en=spectral graph theory`},
		{"GRAPHTHEORY_RANDOM",  3,`label=đồ thị ngẫu nhiên|desc=random graph Erdos-Renyi Barabasi-Albert preferential attachment power law small world clustering|vi=đồ thị ngẫu nhiên,random graph|en=random graph`},

		{"TOPOLOGY2_KNOT",      3,`label=lý thuyết nút|desc=knot theory invariant Jones polynomial HOMFLY unknot trefoil chirality DNA topology enzyme linking number|vi=lý thuyết nút,knot theory|en=knot theory`},
		{"TOPOLOGY2_MANIFOLD",  3,`label=đa tạp|desc=manifold Riemannian differentiable smooth atlas chart tangent bundle geodesic Ricci flow Perelman Poincare|vi=đa tạp,manifold|en=manifold`},
		{"PROBABILITY2_MARKOV", 3,`label=chuỗi Markov|desc=Markov chain transition matrix stationary distribution mixing time hitting reversible MCMC sampling ergodic|vi=chuỗi Markov,Markov chain|en=Markov chain`},
		{"PROBABILITY2_BAYES",  3,`label=thống kê Bayes|desc=Bayesian statistics prior posterior likelihood Bayes theorem conjugate MCMC variational inference credible interval|vi=thống kê Bayes,Bayesian statistics|en=Bayesian statistics`},
		{"NUMTHEORY_CRYPTO",    3,`label=lý thuyết số và mật mã|desc=number theory RSA prime factoring elliptic curve discrete logarithm Shor algorithm quantum threat lattice|vi=lý thuyết số và mật mã,number theory cryptography|en=number theory cryptography`},

		// ── NEUROPSYCHOLOGY ───────────────────────────────────────────
		{"NEUROPSYCH_TBI",      3,`label=chấn thương não|desc=traumatic brain injury TBI concussion CTE chronic traumatic encephalopathy NFL tau protein blast injury|vi=chấn thương não,traumatic brain injury|en=traumatic brain injury`},
		{"NEUROPSYCH_STROKE",   3,`label=đột quỵ|desc=stroke ischemic hemorrhagic tPA thrombectomy penumbra rehabilitation neuroplasticity Broca aphasia dysphagia|vi=đột quỵ,stroke|en=stroke`},
		{"NEUROPSYCH_DEMENTIA2",3,`label=sa sút trí tuệ nâng cao|desc=dementia advanced Alzheimer tau amyloid plaque PET biomarker lecanemab donanemab clinical trial|vi=sa sút trí tuệ nâng cao,advanced dementia|en=advanced dementia`},
		{"NEUROPSYCH_DEVELOP",  3,`label=rối loạn phát triển thần kinh|desc=neurodevelopmental disorder ADHD ASD dyslexia dyscalculia executive function early intervention|vi=rối loạn phát triển thần kinh,neurodevelopmental disorder|en=neurodevelopmental disorder`},
		{"COGPSYCH_LANGUAGE",   3,`label=tâm lý ngôn ngữ|desc=psycholinguistics word recognition sentence processing mental lexicon parsing garden path Chomsky Pinker|vi=tâm lý ngôn ngữ,psycholinguistics|en=psycholinguistics`},

		// ── MISC STRONG NODES ─────────────────────────────────────────
		{"MACROEC2_INFLATION",  3,`label=lạm phát|desc=inflation CPI PCE wage-price spiral supply chain energy food 2022 Fed tightening sacrifice ratio soft landing|vi=lạm phát,inflation|en=inflation`},
		{"DEVECON_URBANIZE",    3,`label=đô thị hóa và phát triển|desc=urbanization development Lewis model rural urban migration agglomeration productivity megacity informal settlement|vi=đô thị hóa và phát triển,urbanization development|en=urbanization development`},
		{"INDIA_GEOPOLIT",      3,`label=địa chính trị Ấn Độ|desc=India geopolitics Quad Indo-Pacific China border LAC non-alignment strategic autonomy SCO BRICS|vi=địa chính trị Ấn Độ,India geopolitics|en=India geopolitics`},
		{"INDONESIA_CAPITAL",   3,`label=thủ đô mới Indonesia|desc=Indonesia new capital Nusantara Kalimantan Borneo Jakarta sinking climate risk infrastructure megaproject|vi=thủ đô mới Indonesia,Indonesia new capital|en=Indonesia new capital`},
		{"BRAZIL_SOCIETY",      3,`label=xã hội Brazil|desc=Brazil society racial democracy Afro-Brazilian quilombo quilombola femicide gender violence carnival syncretism|vi=xã hội Brazil,Brazil society|en=Brazil society`},

		{"VNTRADE_SEMI",        3,`label=Việt Nam và chuỗi bán dẫn|desc=Việt Nam bán dẫn Samsung HANA Intel đóng gói kiểm thử nhân lực kỹ sư chip design VSMC|vi=Việt Nam và chuỗi bán dẫn,Vietnam semiconductor|en=Vietnam semiconductor`},
		{"VNENERGY_LNG",        3,`label=LNG và khí Việt Nam|desc=LNG Việt Nam nhập khẩu khí hóa lỏng Thị Vải cảng PVGas chuyển đổi năng lượng giảm than|vi=LNG và khí Việt Nam,Vietnam LNG|en=Vietnam LNG`},
		{"VNHEALTH_MENTAL",     3,`label=sức khỏe tâm thần Việt Nam|desc=sức khỏe tâm thần Việt Nam kỳ thị thiếu nhân lực trầm cảm lo âu thanh niên đô thị chính sách|vi=sức khỏe tâm thần Việt Nam,Vietnam mental health|en=Vietnam mental health`},
		{"SOCIALMEDIA2_VIET",   3,`label=mạng xã hội Việt Nam|desc=mạng xã hội Việt Nam Facebook Zalo TikTok YouTube 70 triệu người dùng kiểm duyệt luật 97|vi=mạng xã hội Việt Nam,Vietnam social media|en=Vietnam social media`},
		{"FILM3_ASEAN",         3,`label=điện ảnh Đông Nam Á|desc=ASEAN cinema Thailand Malaysia Indonesia Philippines Singapore co-production streaming Netflix regional market|vi=điện ảnh Đông Nam Á,ASEAN cinema|en=ASEAN cinema`},

		{"GRAPHTHEORY_NEURAL",  3,`label=lý thuyết đồ thị và mạng nơ-ron|desc=graph neural network GNN message passing GraphSAGE GAT molecular property prediction knowledge graph|vi=lý thuyết đồ thị và mạng nơ-ron,graph neural network|en=graph neural network`},
		{"OPTIM_RL",            3,`label=tối ưu trong học tăng cường|desc=RL optimization Bellman optimality Q-learning TD learning value function approximation convergence|vi=tối ưu trong học tăng cường,RL optimization|en=RL optimization`},
		{"TOPOLOGY2_TDA",       3,`label=phân tích dữ liệu topo học|desc=topological data analysis persistent homology Betti number simplicial complex Mapper filtration|vi=phân tích dữ liệu topo học,topological data analysis|en=topological data analysis`},
		{"PROBABILITY2_PROCESS",3,`label=quá trình ngẫu nhiên|desc=stochastic process Wiener Brownian motion Poisson Ito calculus SDE martingale optional stopping|vi=quá trình ngẫu nhiên,stochastic process|en=stochastic process`},
		{"NUMTHEORY_PRIME",     3,`label=số nguyên tố|desc=prime number sieve Eratosthenes Riemann hypothesis zeta function prime distribution Goldbach twin prime|vi=số nguyên tố,prime number|en=prime number`},

		{"JOURNALISM_AI",       3,`label=AI trong báo chí|desc=AI journalism automated news detection deepfake synthetic media verification fact-check newsroom tool|vi=AI trong báo chí,AI journalism|en=AI journalism`},
		{"PODCAST_VIET",        3,`label=podcast Việt Nam|desc=podcast Việt Nam Vietcetera Talk Vietnam Voz Ơi NXB Trẻ nội dung giáo dục kinh doanh phát triển|vi=podcast Việt Nam,Vietnam podcast|en=Vietnam podcast`},
		{"PSYCH3_GRIEF",        3,`label=tâm lý học đau buồn|desc=grief psychology Kübler-Ross stages Worden tasks continuing bonds meaning making prolonged grief disorder|vi=tâm lý học đau buồn,grief psychology|en=grief psychology`},
		{"CLINPSYCH_SCHEMA",    3,`label=liệu pháp sơ đồ|desc=schema therapy Young early maladaptive schemas modes limited reparenting imagery rescripting personality disorder|vi=liệu pháp sơ đồ,schema therapy|en=schema therapy`},
		{"NEUROSCI3_CEREBELLUM",3,`label=tiểu não|desc=cerebellum motor learning timing prediction internal model Purkinje cell climbing fiber coordination balance|vi=tiểu não,cerebellum|en=cerebellum`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 4700 { fmt.Println(" MILESTONE 4700! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
