//go:build ignore
// seed_milestone4900.go — MILESTONE 4900 — 100 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── LABOR 2 ──────────────────────────────────────────────────
		{"LABOR2_UNION",         3,`label=công đoàn và quyền lao động|desc=labor union collective bargaining NLRA Wagner strike right-to-work density decline Amazon warehouse|vi=công đoàn và quyền lao động,labor union|en=labor union`},
		{"LABOR2_INFORMAL",      3,`label=lao động phi chính thức|desc=informal labor sector self-employed home-based piece-rate ILO decent work social protection extension|vi=lao động phi chính thức,informal labor|en=informal labor`},
		{"LABOR2_REMOTE",        3,`label=làm việc từ xa|desc=remote work hybrid distributed team async communication timezone Slack Zoom productivity monitoring trust|vi=làm việc từ xa,remote work|en=remote work`},
		{"LABOR2_GENDERWORK",    3,`label=giới và công việc chăm sóc|desc=care work gender unpaid domestic childcare eldercare shadow economy GDP undercount valuation|vi=giới và công việc chăm sóc,care work gender|en=care work gender`},
		{"LABOR2_YOUTH",         3,`label=lao động trẻ và NEET|desc=youth labor NEET not in employment education training school-to-work transition apprenticeship VET|vi=lao động trẻ và NEET,youth labor NEET|en=youth labor NEET`},

		// ── MIGRATION 2 ───────────────────────────────────────────────
		{"MIGRATION2_CLIMATE",   3,`label=di cư khí hậu|desc=climate migration displacement sea level rise drought flood Bangladesh Pacific island planned relocation|vi=di cư khí hậu,climate migration|en=climate migration`},
		{"MIGRATION2_INTERNAL",  3,`label=di cư nội địa|desc=internal migration rural urban China hukou India IHDS Africa megacity informal settlement service access|vi=di cư nội địa,internal migration|en=internal migration`},
		{"MIGRATION2_INTEGRATION",3,`label=hòa nhập người nhập cư|desc=immigrant integration host society language education labor market discrimination policy reception|vi=hòa nhập người nhập cư,immigrant integration|en=immigrant integration`},
		{"REFUGEE_LAW",          3,`label=luật tị nạn|desc=refugee law 1951 Convention non-refoulement UNHCR RSD status determination asylum procedure safe third country|vi=luật tị nạn,refugee law|en=refugee law`},
		{"REFUGEE_CAMP",         3,`label=trại tị nạn và nhân đạo|desc=refugee camp Zaatari Cox's Bazar UNHCR WFP shelter WASH protection education livelihoods durable|vi=trại tị nạn và nhân đạo,refugee camp|en=refugee camp`},

		// ── HUMANITARIAN ──────────────────────────────────────────────
		{"HUMANITARIAN_AID",     3,`label=viện trợ nhân đạo|desc=humanitarian aid cluster OCHA ICRC IFRC Sphere standards needs assessment cash transfer localization|vi=viện trợ nhân đạo,humanitarian aid|en=humanitarian aid`},
		{"HUMANITARIAN_NEXUS",   3,`label=kết nối nhân đạo-phát triển|desc=humanitarian development nexus triple nexus peace resilience durable solution HDP linking|vi=kết nối nhân đạo-phát triển,humanitarian nexus|en=humanitarian nexus`},
		{"HUMANITARIAN_DATA",    3,`label=dữ liệu trong viện trợ|desc=humanitarian data HDX OCHA responsible AI biometric refugee digital ID privacy protection|vi=dữ liệu trong viện trợ,humanitarian data|en=humanitarian data`},
		{"REFUGEE_URBAN",        3,`label=người tị nạn đô thị|desc=urban refugee self-settlement Jordan Lebanon Kampala work permit service access invisible population|vi=người tị nạn đô thị,urban refugee|en=urban refugee`},
		{"MIGRATION2_SKILLED",   3,`label=di cư lao động có kỹ năng|desc=skilled migration points-based H1B talent visa shortage occupation list brain drain gain return|vi=di cư lao động có kỹ năng,skilled migration|en=skilled migration`},

		// ── URBAN 4 ───────────────────────────────────────────────────
		{"URBAN4_INFORMAL",      3,`label=khu dân cư không chính thức|desc=informal settlement slum favela upgrading Baan Mankong PRODEL tenure security incremental|vi=khu dân cư không chính thức,informal settlement|en=informal settlement`},
		{"URBAN4_CLIMATE",       3,`label=đô thị và biến đổi khí hậu|desc=urban climate resilience heat island sponge city blue green infrastructure flood adaptation coastal|vi=đô thị và biến đổi khí hậu,urban climate|en=urban climate`},
		{"URBAN4_MOBILITY",      3,`label=giao thông đô thị|desc=urban mobility BRT metro bike lane pedestrian 15-minute city last-mile micro-mobility e-scooter|vi=giao thông đô thị,urban mobility|en=urban mobility`},
		{"URBAN4_SMART",         3,`label=thành phố thông minh|desc=smart city Sidewalk Toronto Songdo Singapore data governance surveillance privacy citizen engagement|vi=thành phố thông minh,smart city|en=smart city`},
		{"URBAN4_SHRINKING",     3,`label=thành phố thu hẹp|desc=shrinking city population decline Detroit Rust Belt Eastern Europe demolition rightsizing land bank|vi=thành phố thu hẹp,shrinking city|en=shrinking city`},

		// ── HOUSING 2 ─────────────────────────────────────────────────
		{"HOUSING2_AFFORD",      3,`label=nhà ở giá rẻ|desc=affordable housing cost burden 30% income subsidized voucher inclusionary zoning density bonus upzoning|vi=nhà ở giá rẻ,affordable housing|en=affordable housing`},
		{"HOUSING2_POLICY",      3,`label=chính sách nhà ở|desc=housing policy Singapore HDB public rental Vienna social Austria community land trust cohousing|vi=chính sách nhà ở,housing policy|en=housing policy`},
		{"HOUSING2_MARKET",      3,`label=thị trường bất động sản|desc=real estate market supply demand zoning NIMBYism institutional investor Blackstone rent cap|vi=thị trường bất động sản,real estate market|en=real estate market`},
		{"HOUSING2_HOMELESSNESS",3,`label=vô gia cư|desc=homelessness Housing First Finland Finland model rough sleeping point-in-time count encampment mental health|vi=vô gia cư,homelessness|en=homelessness`},
		{"HOUSING2_VIET",        3,`label=nhà ở Việt Nam|desc=nhà ở Việt Nam nhà xã hội nhà ở công nhân giá căn hộ Hà Nội HCMC sốt đất đầu cơ phân lô bán nền|vi=nhà ở Việt Nam,Vietnam housing|en=Vietnam housing`},

		// ── TRANSPORT 2 ───────────────────────────────────────────────
		{"TRANSPORT2_RAIL",      3,`label=đường sắt tốc độ cao|desc=high speed rail Shinkansen TGV ICE AVE Eurostar China HSR cost benefit HS2 infrastructure|vi=đường sắt tốc độ cao,high speed rail|en=high speed rail`},
		{"TRANSPORT2_EV",        3,`label=xe điện và hạ tầng|desc=EV electric vehicle charging infrastructure range anxiety grid demand V2G battery degradation incentive|vi=xe điện và hạ tầng,EV infrastructure|en=EV infrastructure`},
		{"TRANSPORT2_AVIATION",  3,`label=hàng không bền vững|desc=sustainable aviation SAF synthetic fuel hydrogen electric contrail NOx CORSIA offset net zero|vi=hàng không bền vững,sustainable aviation|en=sustainable aviation`},
		{"TRANSPORT2_SHIPPING",  3,`label=vận tải biển xanh|desc=green shipping IMO 2050 ammonia methanol hydrogen LNG scrubber Poseidon Principles carbon intensity|vi=vận tải biển xanh,green shipping|en=green shipping`},
		{"TRANSPORT2_VIET",      3,`label=giao thông Việt Nam|desc=giao thông Việt Nam metro Hà Nội HCMC đường sắt Bắc Nam tốc độ cao cao tốc BOT ùn tắc|vi=giao thông Việt Nam,Vietnam transport|en=Vietnam transport`},

		// ── ENERGY POLICY ─────────────────────────────────────────────
		{"ENERGY_POLICY_JUST",   3,`label=chuyển đổi năng lượng công bằng|desc=just energy transition coal workers community JETP South Africa Indonesia Vietnam ILO social floor|vi=chuyển đổi năng lượng công bằng,just energy transition|en=just energy transition`},
		{"ENERGY_POLICY_NUCLEAR",3,`label=chính sách điện hạt nhân|desc=nuclear power policy SMR advanced reactor waste repository lifecycle carbon cost France Germany|vi=chính sách điện hạt nhân,nuclear policy|en=nuclear policy`},
		{"ENERGY_POLICY_GRID",   3,`label=lưới điện thông minh|desc=smart grid SCADA demand response DSM VPP virtual power plant flexibility prosumer microgrid island|vi=lưới điện thông minh,smart grid|en=smart grid`},
		{"ENERGY_POLICY_ACCESS", 3,`label=tiếp cận năng lượng|desc=energy access SDG7 electricity universal cooking fuel kerosene LPG solar lantern mini-grid last mile|vi=tiếp cận năng lượng,energy access|en=energy access`},
		{"ENERGY_POLICY_MARKET", 3,`label=thị trường điện|desc=electricity market wholesale spot price merit order negative price duck curve renewable integration|vi=thị trường điện,electricity market|en=electricity market`},

		// ── MATHEMATICS 2 ─────────────────────────────────────────────
		{"MEASURE_THEORY",       3,`label=lý thuyết đo lường|desc=measure theory Lebesgue sigma algebra measurable function integration Radon-Nikodym dominated convergence|vi=lý thuyết đo lường,measure theory|en=measure theory`},
		{"FUNCTIONAL_ANALYSIS",  3,`label=giải tích hàm|desc=functional analysis Banach Hilbert space operator bounded linear spectral Riesz representation dual|vi=giải tích hàm,functional analysis|en=functional analysis`},
		{"PARTIAL_DIFF_EQ",      3,`label=phương trình vi phân riêng phần|desc=PDE elliptic parabolic hyperbolic Laplace heat wave Navier-Stokes existence regularity weak solution|vi=phương trình vi phân riêng phần,PDE|en=PDE`},
		{"DYNAMICAL_SYSTEMS",    3,`label=hệ động lực học|desc=dynamical systems attractor bifurcation Lyapunov stability chaos Lorenz butterfly limit cycle ergodic|vi=hệ động lực học,dynamical systems|en=dynamical systems`},
		{"CATEGORY_THEORY",      3,`label=lý thuyết phạm trù|desc=category theory functor natural transformation adjunction monad topos Grothendieck higher category|vi=lý thuyết phạm trù,category theory|en=category theory`},

		// ── COGNITIVE SCIENCE ─────────────────────────────────────────
		{"COGSCI_ENACTIVE",      3,`label=nhận thức hành động|desc=enactive cognition Varela Thompson Rosch embodied embedded extended 4E cognition mind body coupling|vi=nhận thức hành động,enactive cognition|en=enactive cognition`},
		{"COGSCI_PREDICTIVE",    3,`label=não dự đoán|desc=predictive brain Friston free energy principle active inference precision-weighting prediction error minimization|vi=não dự đoán,predictive brain|en=predictive brain`},
		{"COGSCI_SOCIAL",        3,`label=nhận thức xã hội|desc=social cognition theory of mind mentalizing mirror neuron simulation shared intentionality cultural learning|vi=nhận thức xã hội,social cognition|en=social cognition`},
		{"COGSCI_LEARNING",      3,`label=học máy và học người|desc=machine human learning comparison inductive bias curriculum transfer few-shot Bayesian brain|vi=học máy và học người,machine human learning|en=machine human learning`},
		{"COGSCI_LANGUAGE2",     3,`label=ngôn ngữ và tư duy|desc=language thought Sapir-Whorf hypothesis linguistic relativity color perception time spatial grammar|vi=ngôn ngữ và tư duy,language thought|en=language thought`},

		// ── VIETNAM ───────────────────────────────────────────────────
		{"VNLABOR_MIGRANT",      3,`label=lao động di cư Việt Nam|desc=lao động di cư Việt Nam xuất khẩu Nhật Hàn Đài Loan phí môi giới kiều hối 18 tỷ USD|vi=lao động di cư Việt Nam,Vietnam migrant labor|en=Vietnam migrant labor`},
		{"VNLABOR_INDUSTRY",     3,`label=lao động công nghiệp Việt Nam|desc=lao động công nghiệp Việt Nam khu công nghiệp lương tối thiểu điều kiện an toàn đình công|vi=lao động công nghiệp Việt Nam,Vietnam industrial labor|en=Vietnam industrial labor`},
		{"VNURBAN2_TRANSPORT",   3,`label=giao thông đô thị Việt Nam|desc=giao thông đô thị Việt Nam xe máy ô tô hóa metro BRT đỗ xe vỉa hè ùn tắc giải pháp|vi=giao thông đô thị Việt Nam,Vietnam urban transport|en=Vietnam urban transport`},
		{"VNURBAN2_HOUSING",     3,`label=đô thị hóa và nhà ở Việt Nam|desc=đô thị hóa Việt Nam khu đô thị mới Vinhomes Ecopark chung cư cao tầng hạ tầng kỹ thuật|vi=đô thị hóa và nhà ở Việt Nam,Vietnam urbanization housing|en=Vietnam urbanization housing`},
		{"VNENERGY2_POLICY",     3,`label=chính sách năng lượng Việt Nam|desc=chính sách năng lượng Việt Nam quy hoạch 8 JETP Net Zero 2050 EVN PDP8 tư nhân hóa|vi=chính sách năng lượng Việt Nam,Vietnam energy policy|en=Vietnam energy policy`},

		// ── MISC ──────────────────────────────────────────────────────
		{"HUMANITARIAN_PROTCTN", 3,`label=bảo vệ nhân đạo|desc=humanitarian protection GBV gender-based violence child protection safe space MHPSS survivor-centered|vi=bảo vệ nhân đạo,humanitarian protection|en=humanitarian protection`},
		{"URBAN4_GOVERNANCE",    3,`label=quản trị đô thị|desc=urban governance metropolitan fragmentation coordination finance fiscal decentralization property tax land value|vi=quản trị đô thị,urban governance|en=urban governance`},
		{"HOUSING2_ELDERLY",     3,`label=nhà ở cho người cao tuổi|desc=elderly housing age-friendly assisted living nursing home PACE PACE village movement universal design|vi=nhà ở cho người cao tuổi,elderly housing|en=elderly housing`},
		{"TRANSPORT2_LOGISTICS2",3,`label=logistics đô thị|desc=urban logistics last-mile delivery micro-fulfillment cargo bike consolidated delivery point PUDO|vi=logistics đô thị,urban logistics|en=urban logistics`},
		{"ENERGY_POLICY_STORAGE",3,`label=lưu trữ năng lượng quy mô lớn|desc=grid-scale storage BESS lithium iron phosphate flow battery pumped hydro CAES compressed air|vi=lưu trữ năng lượng quy mô lớn,grid storage|en=grid storage`},
		{"MEASURE_PROBABILITY",  3,`label=lý thuyết xác suất đo lường|desc=probability measure Kolmogorov axioms conditional expectation martingale optional sampling CLT LLN|vi=lý thuyết xác suất đo lường,probability measure theory|en=probability measure theory`},
		{"FUNCTIONAL_PDE",       3,`label=giải tích hàm và PDE|desc=Sobolev space trace embedding Lions Magenes elliptic regularity Lax-Milgram inf-sup Galerkin|vi=giải tích hàm và PDE,functional analysis PDE|en=functional analysis PDE`},
		{"DYNAMICAL_NEURO",      3,`label=hệ động lực học thần kinh|desc=neural dynamics Hopfield attractor network oscillation synchrony gamma theta Wilson-Cowan FitzHugh-Nagumo|vi=hệ động lực học thần kinh,neural dynamics|en=neural dynamics`},
		{"CATEGORY_APPLIED",     3,`label=lý thuyết phạm trù ứng dụng|desc=applied category theory Fong Spivak compositionality string diagram open systems database query|vi=lý thuyết phạm trù ứng dụng,applied category theory|en=applied category theory`},
		{"COGSCI_CONSCIOUSNESS", 3,`label=khoa học nhận thức về ý thức|desc=consciousness science IIT GWT global workspace integrated information Baars Tononi NCC neural correlate|vi=khoa học nhận thức về ý thức,consciousness science|en=consciousness science`},
		{"MIGRATION2_DIASPORA",  3,`label=cộng đồng người Việt hải ngoại|desc=Vietnamese diaspora Viet Kieu overseas 4.5 triệu kiều hối văn hóa chính sách thu hút đầu tư|vi=cộng đồng người Việt hải ngoại,Vietnamese diaspora|en=Vietnamese diaspora`},
		{"LABOR2_FUTURE_SKILLS", 3,`label=kỹ năng tương lai|desc=future skills WEF jobs report reskilling upskilling digital literacy critical thinking adaptability STEM|vi=kỹ năng tương lai,future skills|en=future skills`},
		{"URBAN4_FOOD",          3,`label=hệ thống thực phẩm đô thị|desc=urban food system food desert wet market street food urban agriculture rooftop vertical farm|vi=hệ thống thực phẩm đô thị,urban food system|en=urban food system`},
		{"HOUSING2_COOPERATIVE", 3,`label=nhà ở hợp tác|desc=cooperative housing limited equity co-op community land trust Mietshäuser Syndikat Baugruppen collective|vi=nhà ở hợp tác,cooperative housing|en=cooperative housing`},
		{"TRANSPORT2_AUTONOMOUS",3,`label=xe tự lái|desc=autonomous vehicle Waymo Cruise Tesla FSD SAE levels regulation liability insurance urban testing|vi=xe tự lái,autonomous vehicle|en=autonomous vehicle`},
		{"ENERGY_POLICY_EFFICIENCY",3,`label=hiệu quả năng lượng|desc=energy efficiency building code appliance standard MEPS Jevons rebound industrial motor heat pump|vi=hiệu quả năng lượng,energy efficiency|en=energy efficiency`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 4900 { fmt.Println(" MILESTONE 4900! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
