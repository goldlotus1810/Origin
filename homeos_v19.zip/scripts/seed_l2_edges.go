//go:build ignore

// scripts/seed_l2_edges.go
// Silk edges L2 Nature ↔ L6 Perception ↔ L3 Life
// Chạy: go run scripts/seed_l2_edges.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const l2Path  = "homeos.olang"
const l2LIE   = 64 + 9*24

type l2Edge struct{ from, to string; typ uint8 }

// 0x08=∈  0x09=⊂  0x0A=∘(causes)  0x0C=≈(similar)  0x0D=⊥(opposite)
var l2Edges = []l2Edge{
	// ── NATURE_LIGHT ────────────────────────────────────────────
	{"NATURE_LIGHT",       "PERCEPT_BRIGHT",    0x0A}, // ánh sáng → sáng
	{"NATURE_LIGHT",       "PERCEPT_WARM",      0x0C}, // ánh sáng ≈ ấm
	{"NATURE_LIGHT",       "PERCEPT_WHITE",     0x0C}, // ánh sáng ≈ trắng
	{"NATURE_LIGHT",       "NATURE_COLOR_WAVE", 0x0A}, // ánh sáng → sóng màu
	{"NATURE_LIGHT",       "PERCEPT_YELLOW",    0x0C}, // ánh sáng mặt trời ≈ vàng
	{"NATURE_LIGHT",       "LIFE_AWAKE",        0x0A}, // ánh sáng → thức giấc

	// ── NATURE_HEAT ─────────────────────────────────────────────
	{"NATURE_HEAT",        "PERCEPT_HOT",       0x0A}, // nhiệt → nóng
	{"NATURE_HEAT",        "PERCEPT_BRIGHT",    0x0C}, // nhiệt ≈ sáng (lửa)
	{"NATURE_HEAT",        "NATURE_COLD",       0x0D}, // nóng ⊥ lạnh
	{"NATURE_HEAT",        "LIFE_EAT",          0x0C}, // nhiệt ≈ nấu ăn

	// ── NATURE_COLD ─────────────────────────────────────────────
	{"NATURE_COLD",        "PERCEPT_COLD",      0x0A}, // lạnh → cảm giác lạnh
	{"NATURE_COLD",        "PERCEPT_FRESH",     0x0C}, // lạnh ≈ mát mẻ
	{"NATURE_COLD",        "PERCEPT_WHITE",     0x0C}, // tuyết ≈ trắng
	{"NATURE_COLD",        "LIFE_SLEEP",        0x0C}, // lạnh ≈ ngủ nhiều

	// ── NATURE_FIRE ─────────────────────────────────────────────
	{"NATURE_FIRE",        "PERCEPT_HOT",       0x0A}, // lửa → nóng
	{"NATURE_FIRE",        "PERCEPT_BRIGHT",    0x0A}, // lửa → sáng
	{"NATURE_FIRE",        "PERCEPT_RED",       0x0C}, // lửa ≈ đỏ
	{"NATURE_FIRE",        "PERCEPT_ORANGE",    0x0C}, // lửa ≈ cam
	{"NATURE_FIRE",        "PERCEPT_LOUD",      0x0C}, // lửa ≈ tiếng lửa
	{"NATURE_FIRE",        "LIFE_FEAR",         0x0A}, // lửa → sợ hãi
	{"NATURE_FIRE",        "NATURE_HEAT",       0x0C}, // lửa ≈ nhiệt

	// ── NATURE_WATER ────────────────────────────────────────────
	{"NATURE_WATER",       "PERCEPT_COLD",      0x0C}, // nước ≈ mát lạnh
	{"NATURE_WATER",       "PERCEPT_CLEAN",     0x0C}, // nước ≈ sạch
	{"NATURE_WATER",       "PERCEPT_BLUE",      0x0C}, // nước ≈ xanh dương
	{"NATURE_WATER",       "PERCEPT_SMOOTH",    0x0C}, // nước ≈ trơn mịn
	{"NATURE_WATER",       "PERCEPT_FRESH",     0x0C}, // nước ≈ tươi mát
	{"NATURE_WATER",       "LIFE_BREATHE",      0x0C}, // nước ≈ sự sống
	{"NATURE_WATER",       "NATURE_COLD",       0x0C}, // nước ≈ lạnh

	// ── NATURE_WIND ─────────────────────────────────────────────
	{"NATURE_WIND",        "PERCEPT_FRESH",     0x0A}, // gió → mát mẻ
	{"NATURE_WIND",        "PERCEPT_LOUD",      0x0C}, // gió mạnh ≈ ồn ào
	{"NATURE_WIND",        "PERCEPT_COLD",      0x0C}, // gió ≈ lạnh
	{"NATURE_WIND",        "PERCEPT_FAST",      0x0C}, // gió ≈ nhanh
	{"NATURE_WIND",        "NATURE_COLD",       0x0C}, // gió ≈ lạnh

	// ── NATURE_SOUND_WAVE ────────────────────────────────────────
	{"NATURE_SOUND_WAVE",  "PERCEPT_LOUD",      0x0A}, // sóng âm → to
	{"NATURE_SOUND_WAVE",  "PERCEPT_VOICE",     0x0C}, // sóng âm ≈ giọng nói
	{"NATURE_SOUND_WAVE",  "PERCEPT_MUSIC",     0x0C}, // sóng âm ≈ âm nhạc
	{"NATURE_SOUND_WAVE",  "PERCEPT_SHARP",     0x0C}, // sóng âm sắc ≈ nhọn

	// ── NATURE_COLOR_WAVE ────────────────────────────────────────
	{"NATURE_COLOR_WAVE",  "PERCEPT_RED",       0x0A}, // sóng màu → đỏ
	{"NATURE_COLOR_WAVE",  "PERCEPT_BLUE",      0x0A}, // sóng màu → xanh
	{"NATURE_COLOR_WAVE",  "PERCEPT_GREEN",     0x0A}, // sóng màu → lục
	{"NATURE_COLOR_WAVE",  "PERCEPT_YELLOW",    0x0A}, // sóng màu → vàng
	{"NATURE_COLOR_WAVE",  "PERCEPT_BRIGHT",    0x0C}, // sóng màu ≈ sáng

	// ── NATURE_RAIN ──────────────────────────────────────────────
	{"NATURE_RAIN",        "PERCEPT_COLD",      0x0A}, // mưa → lạnh
	{"NATURE_RAIN",        "PERCEPT_LOUD",      0x0A}, // mưa → âm thanh
	{"NATURE_RAIN",        "PERCEPT_CLEAN",     0x0C}, // mưa ≈ sạch
	{"NATURE_RAIN",        "PERCEPT_FRESH",     0x0C}, // mưa ≈ mát mẻ
	{"NATURE_RAIN",        "PERCEPT_DARK",      0x0C}, // trời mưa ≈ tối
	{"NATURE_RAIN",        "NATURE_WATER",      0x0C}, // mưa ≈ nước
	{"NATURE_RAIN",        "LIFE_SLEEP",        0x0C}, // mưa ≈ buồn ngủ

	// ── NATURE_EARTH ─────────────────────────────────────────────
	{"NATURE_EARTH",       "PERCEPT_HARD",      0x0C}, // đất ≈ cứng
	{"NATURE_EARTH",       "PERCEPT_ROUGH",     0x0C}, // đất ≈ thô ráp
	{"NATURE_EARTH",       "PERCEPT_HEAVY",     0x0C}, // đất ≈ nặng
	{"NATURE_EARTH",       "PERCEPT_DARK",      0x0C}, // đất ≈ tối (nâu)
	{"NATURE_EARTH",       "LIFE_WALK",         0x0C}, // đất ≈ đi lại
	{"NATURE_EARTH",       "NATURE_GRAVITY",    0x0C}, // đất ≈ trọng lực

	// ── NATURE_GRAVITY ───────────────────────────────────────────
	{"NATURE_GRAVITY",     "PERCEPT_HEAVY",     0x0A}, // trọng lực → nặng
	{"NATURE_GRAVITY",     "PERCEPT_SLOW",      0x0C}, // trọng lực ≈ chậm (kéo xuống)
	{"NATURE_GRAVITY",     "LIFE_WALK",         0x0C}, // trọng lực ≈ đứng/đi

	// ── NATURE_ELECTRICITY ───────────────────────────────────────
	{"NATURE_ELECTRICITY", "PERCEPT_BRIGHT",    0x0A}, // điện → sáng (đèn)
	{"NATURE_ELECTRICITY", "PERCEPT_FAST",      0x0C}, // điện ≈ nhanh
	{"NATURE_ELECTRICITY", "PERCEPT_SHARP",     0x0C}, // điện ≈ sắc (giật điện)
	{"NATURE_ELECTRICITY", "LIFE_FEAR",         0x0C}, // điện giật ≈ sợ hãi
	{"NATURE_ELECTRICITY", "HOME_LIGHT_ON",     0x0A}, // điện → đèn bật
	{"NATURE_ELECTRICITY", "HOME_COMPUTER",     0x0A}, // điện → máy tính
	{"NATURE_ELECTRICITY", "HOME_TV",           0x0A}, // điện → TV

	// ── NATURE_MAGNETISM ─────────────────────────────────────────
	{"NATURE_MAGNETISM",   "PERCEPT_NEAR",      0x0A}, // từ trường → kéo gần
	{"NATURE_MAGNETISM",   "PERCEPT_HARD",      0x0C}, // nam châm ≈ cứng
	{"NATURE_MAGNETISM",   "NATURE_ELECTRICITY", 0x0C}, // điện từ ≈ nhau

	// ── NATURE_PRESSURE ──────────────────────────────────────────
	{"NATURE_PRESSURE",    "PERCEPT_HARD",      0x0A}, // áp suất → cứng/chặt
	{"NATURE_PRESSURE",    "PERCEPT_HEAVY",     0x0C}, // áp suất ≈ nặng
	{"NATURE_PRESSURE",    "PERCEPT_PAIN",      0x0C}, // áp suất cao ≈ đau
	{"NATURE_PRESSURE",    "NATURE_WIND",       0x0C}, // áp suất ≈ gió

	// ── NATURE_TEMPERATURE ───────────────────────────────────────
	{"NATURE_TEMPERATURE", "NATURE_HEAT",       0x0C}, // nhiệt độ ≈ nhiệt
	{"NATURE_TEMPERATURE", "NATURE_COLD",       0x0C}, // nhiệt độ ≈ lạnh
	{"NATURE_TEMPERATURE", "PERCEPT_HOT",       0x0C}, // nhiệt độ ≈ nóng
	{"NATURE_TEMPERATURE", "PERCEPT_COLD",      0x0C}, // nhiệt độ ≈ lạnh
	{"NATURE_TEMPERATURE", "HOME_SENSOR",       0x0C}, // nhiệt độ ≈ sensor đo

	// ── NATURE_SPACE ─────────────────────────────────────────────
	{"NATURE_SPACE",       "PERCEPT_FAR",       0x0A}, // không gian → xa
	{"NATURE_SPACE",       "PERCEPT_BIG",       0x0C}, // không gian ≈ lớn
	{"NATURE_SPACE",       "PERCEPT_DARK",      0x0C}, // vũ trụ ≈ tối
	{"NATURE_SPACE",       "NATURE_TIME",       0x0C}, // không-thời gian ≈ nhau

	// ── NATURE_TIME ──────────────────────────────────────────────
	{"NATURE_TIME",        "PERCEPT_FAST",      0x0C}, // thời gian ≈ nhanh (trôi qua)
	{"NATURE_TIME",        "PERCEPT_SLOW",      0x0C}, // thời gian ≈ chậm
	{"NATURE_TIME",        "LIFE_AWAKE",        0x0C}, // thời gian ≈ chu kỳ thức/ngủ
	{"NATURE_TIME",        "LIFE_SLEEP",        0x0C}, // thời gian ≈ ngủ (đêm)
	{"NATURE_TIME",        "NATURE_SPACE",      0x0C}, // thời gian ≈ không gian
}

func main() {
	if _, err := os.Stat(l2Path); err != nil {
		log.Fatalf("file not found: %s", l2Path)
	}
	names := l2ReadNames(l2Path)
	fmt.Printf("Nodes loaded: %d\n", len(names))
	existing := l2ReadEdges(l2Path)
	fmt.Printf("Existing edges: %d\n", len(existing))

	added, skipped, errs := 0, 0, 0
	for _, e := range l2Edges {
		src, srcOK := names[e.from]
		dst, dstOK := names[e.to]
		if !srcOK { fmt.Printf("  MISS src: %s\n", e.from); errs++; continue }
		if !dstOK { fmt.Printf("  MISS dst: %s\n", e.to);   errs++; continue }

		key := l2Key(src, dst, e.typ)
		if existing[key] { skipped++; continue }

		if err := l2AppendEdge(l2Path, src, dst, e.typ); err != nil {
			fmt.Printf("  ERR %s→%s: %v\n", e.from, e.to, err)
			errs++; continue
		}
		existing[key] = true
		fmt.Printf("  +%s  %-28s → %s\n", sym(e.typ), e.from, e.to)
		added++
	}
	fmt.Printf("\n✅ seed_l2_edges: +%d edges, %d skip, %d err\n", added, skipped, errs)
	if err := l2Verify(l2Path); err != nil {
		log.Fatalf("VERIFY FAIL: %v", err)
	}
	fmt.Println("✅ SHA256 OK")
}

func sym(t uint8) string {
	switch t {
	case 0x08: return "∈"
	case 0x09: return "⊂"
	case 0x0A: return "∘"
	case 0x0C: return "≈"
	case 0x0D: return "⊥"
	}
	return fmt.Sprintf("%02x", t)
}

func l2ReadNames(path string) map[string][8]byte {
	raw, _ := os.ReadFile(path)
	m := map[string][8]byte{}
	for off := 0; off+20 < len(raw); {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 3
		var isl [8]byte; copy(isl[:], raw[off:off+8]); off += 8
		off += 4
		dl := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nl := int(raw[off]); off++
		ns := off + dl; ne := ns + nl
		if ne > len(raw) { break }
		m[string(raw[ns:ne])] = isl
		off = ne
	}
	return m
}

func l2ReadEdges(path string) map[string]bool {
	raw, _ := os.ReadFile(path)
	m := map[string]bool{}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	start := len(raw) - nedges*17
	if start < l2LIE { return m }
	for i := start; i+17 <= len(raw); i += 17 {
		var s, d [8]byte
		copy(s[:], raw[i:i+8]); copy(d[:], raw[i+8:i+16])
		m[l2Key(s, d, raw[i+16])] = true
	}
	return m
}

func l2Key(s, d [8]byte, t uint8) string {
	return fmt.Sprintf("%x:%x:%02x", s, d, t)
}

func l2AppendEdge(path string, s, d [8]byte, t uint8) error {
	raw, err := os.ReadFile(path)
	if err != nil { return err }
	rb := make([]byte, len(raw)+17)
	copy(rb, raw)
	copy(rb[len(raw):], s[:])
	copy(rb[len(raw)+8:], d[:])
	rb[len(raw)+16] = t
	n := binary.BigEndian.Uint32(rb[16:20])
	binary.BigEndian.PutUint32(rb[16:20], n+1)
	h := sha256.Sum256(rb[l2LIE:])
	copy(rb[28:60], h[:])
	tmp := path + ".l2tmp"
	if err := os.WriteFile(tmp, rb, 0644); err != nil { return err }
	return os.Rename(tmp, path)
}

func l2Verify(path string) error {
	raw, _ := os.ReadFile(path)
	var st [32]byte; copy(st[:], raw[28:60])
	cm := sha256.Sum256(raw[l2LIE:])
	if st != cm { return fmt.Errorf("hash mismatch") }
	return nil
}
