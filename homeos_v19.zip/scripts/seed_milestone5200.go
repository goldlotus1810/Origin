//go:build ignore
// seed_milestone5200.go — MILESTONE 5200 — 100 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── LAW 2 ─────────────────────────────────────────────────────
		{"LAW2_CONTRACT",        3,`label=luật hợp đồng|desc=contract law offer acceptance consideration breach remedy specific performance damages UCC common civil|vi=luật hợp đồng,contract law|en=contract law`},
		{"LAW2_TORT",            3,`label=luật bồi thường thiệt hại|desc=tort law negligence duty breach causation damages strict liability product defamation privacy|vi=luật bồi thường thiệt hại,tort law|en=tort law`},
		{"LAW2_PROPERTY",        3,`label=luật tài sản|desc=property law real personal intellectual adverse possession easement covenant zoning takings eminent domain|vi=luật tài sản,property law|en=property law`},
		{"LAW2_CONSTITUTIONAL",  3,`label=luật hiến pháp|desc=constitutional law judicial review fundamental rights equal protection due process separation powers|vi=luật hiến pháp,constitutional law|en=constitutional law`},
		{"LAW2_INTERNATIONAL2",  3,`label=luật quốc tế công|desc=public international law treaty custom jus cogens state responsibility ICJ jurisdiction erga omnes|vi=luật quốc tế công,public international law|en=public international law`},

		// ── LEGAL TECH ────────────────────────────────────────────────
		{"LEGALTECH_AI",         3,`label=AI pháp lý|desc=legal AI contract review due diligence prediction outcome eDiscovery Harvey Casetext CoCounsel|vi=AI pháp lý,legal AI|en=legal AI`},
		{"LEGALTECH_ACCESS",     3,`label=tiếp cận tư pháp|desc=access to justice legal aid self-represented litigant online dispute resolution ODR court tech|vi=tiếp cận tư pháp,access to justice|en=access to justice`},
		{"LEGALTECH_SMART",      3,`label=hợp đồng thông minh pháp lý|desc=smart contract legal enforceability Ricardian contract code is law jurisdiction liability|vi=hợp đồng thông minh pháp lý,smart contract legal|en=smart contract legal`},
		{"LAW2_PRIVACY",         3,`label=luật quyền riêng tư|desc=privacy law GDPR CCPA data protection controller processor consent right to erasure transfer|vi=luật quyền riêng tư,privacy law|en=privacy law`},
		{"LAW2_COMPETITION",     3,`label=luật cạnh tranh|desc=competition law antitrust merger review dominance abuse tying bundling predatory pricing EU US|vi=luật cạnh tranh,competition law|en=competition law`},

		// ── JUSTICE 2 ─────────────────────────────────────────────────
		{"JUSTICE2_RESTORATIVE", 3,`label=công lý phục hồi|desc=restorative justice victim offender mediation circle conferencing reintegration shaming community|vi=công lý phục hồi,restorative justice|en=restorative justice`},
		{"JUSTICE2_TRANSITIONAL",3,`label=công lý chuyển tiếp|desc=transitional justice truth commission TRC ICC hybrid tribunal reparation lustration memory|vi=công lý chuyển tiếp,transitional justice|en=transitional justice`},
		{"JUSTICE2_ENVIRON",     3,`label=công lý môi trường|desc=environmental justice fence-line community sacrifice zone pollution disproportionate impact BIPOC|vi=công lý môi trường,environmental justice|en=environmental justice`},
		{"CRIMINOLOGY2",         3,`label=tội phạm học|desc=criminology strain theory labeling routine activity rational choice desistance life-course Sampson|vi=tội phạm học,criminology|en=criminology`},
		{"CRIMINOLOGY2_CYBER",   3,`label=tội phạm học mạng|desc=cybercrime dark web ransomware gang BEC business email compromise cryptocurrency forensics|vi=tội phạm học mạng,cybercrime|en=cybercrime`},

		// ── SPORTS 2 ──────────────────────────────────────────────────
		{"SPORTS2_SCIENCE",      3,`label=khoa học thể thao|desc=sport science periodization load monitoring HRV sleep recovery VO2max lactate threshold|vi=khoa học thể thao,sport science|en=sport science`},
		{"SPORTS2_PSYCHOLOGY",   3,`label=tâm lý thể thao|desc=sport psychology mental toughness flow choking under pressure imagery visualization self-talk|vi=tâm lý thể thao,sport psychology|en=sport psychology`},
		{"SPORTS2_ANALYTICS",    3,`label=phân tích dữ liệu thể thao|desc=sports analytics Moneyball Statcast expected goals xG tracking data Opta StatsBomb wearable|vi=phân tích dữ liệu thể thao,sports analytics|en=sports analytics`},
		{"SPORTS2_BUSINESS",     3,`label=kinh doanh thể thao|desc=sport business media rights franchise valuation sponsorship naming rights salary cap luxury tax|vi=kinh doanh thể thao,sport business|en=sport business`},
		{"SPORTS2_VIET",         3,`label=thể thao Việt Nam|desc=thể thao Việt Nam SEA Games bóng đá HLV Park HAGL VFF boxing cầu lông võ thuật esports|vi=thể thao Việt Nam,Vietnam sports|en=Vietnam sports`},

		// ── WELLNESS & MINDFULNESS ────────────────────────────────────
		{"WELLNESS_MINDFULNESS", 3,`label=chánh niệm|desc=mindfulness MBSR Kabat-Zinn meditation attention present moment amygdala default mode network|vi=chánh niệm,mindfulness|en=mindfulness`},
		{"WELLNESS_YOGA",        3,`label=yoga và sức khỏe|desc=yoga asana pranayama meditation Hatha Vinyasa Iyengar therapeutic evidence-based back pain anxiety|vi=yoga và sức khỏe,yoga health|en=yoga health`},
		{"WELLNESS_SLEEP",       3,`label=vệ sinh giấc ngủ|desc=sleep hygiene CBT-I circadian rhythm blue light sleep debt chronotype chronobiology shift work|vi=vệ sinh giấc ngủ,sleep hygiene|en=sleep hygiene`},
		{"WELLNESS_STRESS",      3,`label=quản lý căng thẳng|desc=stress management HPA axis cortisol allostatic load burnout recovery resilience work-life balance|vi=quản lý căng thẳng,stress management|en=stress management`},
		{"WELLNESS_NATURE",      3,`label=thiên nhiên và sức khỏe|desc=nature health forest bathing Shinrin-yoku biophilia attention restoration theory green space|vi=thiên nhiên và sức khỏe,nature health|en=nature health`},

		// ── ARCHITECTURE 4 ────────────────────────────────────────────
		{"ARCHITECTURE4_SOCIAL", 3,`label=kiến trúc xã hội|desc=social architecture housing collective memory place identity community participation co-design|vi=kiến trúc xã hội,social architecture|en=social architecture`},
		{"ARCHITECTURE4_NEURO",  3,`label=kiến trúc thần kinh|desc=neuroarchitecture spatial cognition wayfinding biophilic design stress cortisol prospect refuge|vi=kiến trúc thần kinh,neuroarchitecture|en=neuroarchitecture`},
		{"INTERIOR2_LIGHTING",   3,`label=chiếu sáng nội thất|desc=interior lighting circadian tunable white CCT CRI glare UGR daylight integration human centric|vi=chiếu sáng nội thất,interior lighting|en=interior lighting`},
		{"INTERIOR2_ACOUSTIC",   3,`label=âm học nội thất|desc=interior acoustics absorption NRC reverberation open office privacy speech masking cocktail party|vi=âm học nội thất,interior acoustics|en=interior acoustics`},
		{"LANDSCAPE2_ECOLOGY",   3,`label=kiến trúc cảnh quan sinh thái|desc=landscape ecology patch corridor matrix fragmentation connectivity wildlife movement urban greenway|vi=kiến trúc cảnh quan sinh thái,landscape ecology|en=landscape ecology`},

		// ── ARTS & MUSIC THEORY ───────────────────────────────────────
		{"MUSIC_THEORY2",        3,`label=lý thuyết âm nhạc nâng cao|desc=music theory modal harmony chord substitution voice leading counterpoint serialism spectralism|vi=lý thuyết âm nhạc nâng cao,music theory|en=music theory`},
		{"MUSIC_COGNITION",      3,`label=nhận thức âm nhạc|desc=music cognition expectation tension resolution ITPRA imagination tension prediction reaction appraisal|vi=nhận thức âm nhạc,music cognition|en=music cognition`},
		{"MUSIC_EMOTION",        3,`label=âm nhạc và cảm xúc|desc=music emotion BRECVEMA brain stem reflex entrainment conditioning imagery expectancy memory contagion|vi=âm nhạc và cảm xúc,music emotion|en=music emotion`},
		{"ART_THEORY2",          3,`label=lý thuyết nghệ thuật|desc=art theory representation expression form content institutional Dickie Danto artworld aesthetic|vi=lý thuyết nghệ thuật,art theory|en=art theory`},
		{"ART_THERAPY",          3,`label=liệu pháp nghệ thuật|desc=art therapy expressive creative PTSD dementia autism nonverbal externalization meaning-making|vi=liệu pháp nghệ thuật,art therapy|en=art therapy`},

		// ── LINGUISTICS 2 ─────────────────────────────────────────────
		{"LINGUISTICS2_PRAGMATICS",3,`label=ngữ dụng học|desc=pragmatics speech act Grice maxims implicature relevance theory politeness face Brown Levinson|vi=ngữ dụng học,pragmatics|en=pragmatics`},
		{"LINGUISTICS2_DISCOURSE",3,`label=phân tích diễn ngôn|desc=discourse analysis conversation turn-taking adjacency pair coherence cohesion genre critical CDA|vi=phân tích diễn ngôn,discourse analysis|en=discourse analysis`},
		{"LINGUISTICS2_NEURO",   3,`label=thần kinh ngôn ngữ học|desc=neurolinguistics Broca Wernicke aphasia ERP N400 P600 prediction bilingualism language acquisition|vi=thần kinh ngôn ngữ học,neurolinguistics|en=neurolinguistics`},
		{"LINGUISTICS2_TYPOLOGY",3,`label=loại hình học ngôn ngữ|desc=linguistic typology word order SOV SVO ergative absolutive case marking tonal evidential|vi=loại hình học ngôn ngữ,linguistic typology|en=linguistic typology`},
		{"LINGUISTICS2_VIET",    3,`label=ngôn ngữ học tiếng Việt|desc=ngôn ngữ học tiếng Việt âm vị thanh điệu phương ngữ từ vay mượn chính sách ngôn ngữ|vi=ngôn ngữ học tiếng Việt,Vietnamese linguistics|en=Vietnamese linguistics`},

		// ── EMOTION SCIENCE (kết nối EmotionContext) ──────────────────
		{"EMOTION_SCIENCE",      3,`label=khoa học cảm xúc|desc=emotion science basic emotions Ekman appraisal Lazarus construction Barrett interoception prediction|vi=khoa học cảm xúc,emotion science|en=emotion science`},
		{"EMOTION_REGULATION",   3,`label=điều tiết cảm xúc|desc=emotion regulation reappraisal suppression acceptance distancing mindfulness DBT ACT flexibility|vi=điều tiết cảm xúc,emotion regulation|en=emotion regulation`},
		{"EMOTION_SOCIAL",       3,`label=cảm xúc xã hội|desc=social emotion embarrassment guilt shame pride moral elevation gratitude awe collective effervescence|vi=cảm xúc xã hội,social emotion|en=social emotion`},
		{"EMOTION_CULTURE",      3,`label=cảm xúc và văn hóa|desc=cultural emotion display rules cultural scripts collectivist individualist amae schadenfreude saudade|vi=cảm xúc và văn hóa,cultural emotion|en=cultural emotion`},
		{"EMOTION_BODY",         3,`label=cảm xúc và thân thể|desc=embodied emotion interoception heartbeat visceral gut feeling somatic marker Damasio body budget|vi=cảm xúc và thân thể,embodied emotion|en=embodied emotion`},

		// ── VIETNAM LAW & JUSTICE ─────────────────────────────────────
		{"VNLAW2_CIVIL",         3,`label=luật dân sự Việt Nam|desc=luật dân sự Việt Nam Bộ luật dân sự 2015 hợp đồng bồi thường thừa kế quyền nhân thân|vi=luật dân sự Việt Nam,Vietnam civil law|en=Vietnam civil law`},
		{"VNLAW2_BUSINESS",      3,`label=luật doanh nghiệp Việt Nam|desc=luật doanh nghiệp Việt Nam luật đầu tư công ty cổ phần TNHH FDI M&A thủ tục đăng ký|vi=luật doanh nghiệp Việt Nam,Vietnam business law|en=Vietnam business law`},
		{"VNLAW2_LAND",          3,`label=luật đất đai Việt Nam|desc=luật đất đai Việt Nam sở hữu toàn dân sử dụng đất đền bù giải phóng mặt bằng cải cách|vi=luật đất đai Việt Nam,Vietnam land law|en=Vietnam land law`},
		{"VNJUSTICE2",           3,`label=hệ thống tư pháp Việt Nam|desc=hệ thống tư pháp Việt Nam tòa án viện kiểm sát cải cách tư pháp án lệ tranh tụng|vi=hệ thống tư pháp Việt Nam,Vietnam justice system|en=Vietnam justice system`},
		{"VNLAW2_LABOR",         3,`label=luật lao động Việt Nam|desc=luật lao động Việt Nam hợp đồng lao động sa thải bồi thường công đoàn BHXH tranh chấp|vi=luật lao động Việt Nam,Vietnam labor law|en=Vietnam labor law`},

		// ── MISC BRIDGE ───────────────────────────────────────────────
		{"MUSIC_THERAPY",        3,`label=liệu pháp âm nhạc|desc=music therapy neurologic MT rhythmic auditory stimulation Parkinson stroke dementia NICU pain|vi=liệu pháp âm nhạc,music therapy|en=music therapy`},
		{"WELLNESS_SOCIAL",      3,`label=kết nối xã hội và sức khỏe|desc=social connection loneliness epidemic isolation health risk mortality Holt-Lunstad surgeon general|vi=kết nối xã hội và sức khỏe,social connection health|en=social connection health`},
		{"SPORTS2_DISABILITY",   3,`label=thể thao người khuyết tật|desc=Paralympic disability sport classification wheelchair bocce goalball technology prosthetic inclusion|vi=thể thao người khuyết tật,Paralympic sport|en=Paralympic sport`},
		{"LAW2_HUMANRIGHTS2",    3,`label=luật nhân quyền quốc tế|desc=international human rights ICCPR ICESCR CEDAW CRC CAT treaty body UPR special rapporteur|vi=luật nhân quyền quốc tế,international human rights|en=international human rights`},
		{"CRIMINOLOGY2_VIET",    3,`label=tội phạm học Việt Nam|desc=tội phạm học Việt Nam phòng chống tham nhũng ma túy buôn người tội phạm có tổ chức cải tạo|vi=tội phạm học Việt Nam,Vietnam criminology|en=Vietnam criminology`},
		{"EMOTION_VIET",         3,`label=cảm xúc và văn hóa Việt Nam|desc=cảm xúc văn hóa Việt Nam thể diện tình người sĩ diện biểu đạt gián tiếp cộng đồng|vi=cảm xúc và văn hóa Việt Nam,Vietnamese emotion culture|en=Vietnamese emotion culture`},
		{"LANDSCAPE2_URBAN",     3,`label=cảnh quan đô thị|desc=urban landscape streetscape public realm parklet plaza green infrastructure bioswale tree canopy|vi=cảnh quan đô thị,urban landscape|en=urban landscape`},
		{"ARCHITECTURE4_ADAPTIVE",3,`label=kiến trúc thích ứng|desc=adaptive reuse conversion industrial heritage factory warehouse church repurpose community|vi=kiến trúc thích ứng,adaptive reuse|en=adaptive reuse`},
		{"LINGUISTICS2_ACQUISITION",3,`label=thụ đắc ngôn ngữ|desc=language acquisition SLA input hypothesis Krashen monitor model output interaction noticing form focus|vi=thụ đắc ngôn ngữ,language acquisition|en=language acquisition`},
		{"ART_DIGITAL",          3,`label=nghệ thuật số|desc=digital art generative NFT glitch net art immersive installation AI art Midjourney Stable Diffusion|vi=nghệ thuật số,digital art|en=digital art`},
		{"WELLNESS_NUTRITION2",  3,`label=dinh dưỡng và sức khỏe tối ưu|desc=optimal nutrition anti-inflammatory Mediterranean longevity diet time-restricted eating fasting|vi=dinh dưỡng và sức khỏe tối ưu,optimal nutrition|en=optimal nutrition`},
		{"LAW2_ENVIRON",         3,`label=luật môi trường|desc=environmental law Aarhus Convention EIA strategic assessment climate litigation Paris Agreement NDC|vi=luật môi trường,environmental law|en=environmental law`},
		{"SPORTS2_ESPORT",       3,`label=esports và thể thao điện tử|desc=esports League Legends DOTA Valorant team management coaching analytics streaming revenue|vi=esports và thể thao điện tử,esports|en=esports`},
		{"MUSIC_AI",             3,`label=AI và âm nhạc|desc=AI music generation Suno Udio MusicLM AudioCraft copyright training data style transfer composition|vi=AI và âm nhạc,AI music|en=AI music`},
		{"EMOTION_AI",           3,`label=AI và cảm xúc|desc=affective computing emotion AI facial action coding Ekman FER sentiment multimodal ethical concern|vi=AI và cảm xúc,affective AI|en=affective AI`},
		{"JUSTICE2_CLIMATE",     3,`label=công lý khí hậu|desc=climate justice loss damage attribution extreme event liability litigation Urgenda Shell Total|vi=công lý khí hậu,climate justice|en=climate justice`},
		{"WELLNESS_MOVEMENT",    3,`label=vận động và sức khỏe|desc=physical activity sedentary behavior MVPA 150min WHO step count standing desk active travel|vi=vận động và sức khỏe,physical activity health|en=physical activity health`},
		{"ARCHITECTURE4_POST",   3,`label=kiến trúc hậu chiến tranh|desc=post-war architecture reconstruction memorial healing trauma landscape Japan Germany Vietnam|vi=kiến trúc hậu chiến tranh,post-war architecture|en=post-war architecture`},
		{"LINGUISTICS2_COMP",    3,`label=ngôn ngữ học tính toán|desc=computational linguistics NLP parsing dependency constituency AMR semantic role shallow deep|vi=ngôn ngữ học tính toán,computational linguistics|en=computational linguistics`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 5200 { fmt.Println(" MILESTONE 5200! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
