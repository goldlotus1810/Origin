//go:build ignore
// seed_milestone4300.go — MILESTONE 4300 — 100 nodes
// Domains: COMPUTERVISION_ NLPROC2_ ROBOTICS2_ REINFORCE2_ GENERATIVE_
//          MATERIALS2_ PHOTONICS_ NANOTECH2_ BIOMATERIAL_ COMPOSITE_
//          FINTECH2_ INSURTECH_ PROPTECH_ LEGALTECH_ HRTECH_
//          SPACE2_ SATELLITE_ LAUNCH_ MOONBASE_ ASTEROID_
//          ANCIENT_MESOAMER_ ANCIENT_MIDEAST_ BYZANTINE_ OTTOMAN_ MONGOL_
//          PHONOLOGY_ MORPHOLOGY_ SYNTAX2_ PRAGMATICS_ SOCIOLING2_
//          VNAGRI2_ VNTOURISM2_ VNCRAFT_ VNFOOD3_ VNSPORT2_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── COMPUTER VISION (COMPUTERVISION_) ────────────────────────
		{"COMPUTERVISION_DETECT", 3,`label=phát hiện vật thể|desc=object detection YOLO RCNN SSD anchor box NMS mAP COCO benchmark real-time inference edge deployment|vi=phát hiện vật thể,object detection|en=object detection`},
		{"COMPUTERVISION_SEG",    3,`label=phân đoạn ảnh|desc=image segmentation semantic instance panoptic SAM Segment Anything FCN DeepLab mask pixel class|vi=phân đoạn ảnh,image segmentation|en=image segmentation`},
		{"COMPUTERVISION_3D",     3,`label=thị giác máy tính 3D|desc=3D computer vision depth estimation NeRF 3D Gaussian splatting point cloud mesh reconstruction stereo|vi=thị giác máy tính 3D,3D computer vision|en=3D computer vision`},
		{"COMPUTERVISION_TRACK",  3,`label=theo dõi vật thể|desc=object tracking DeepSORT ByteTrack occlusion re-ID multi-object MOT benchmark Kalman filter association|vi=theo dõi vật thể,object tracking|en=object tracking`},
		{"COMPUTERVISION_ANOMALY",3,`label=phát hiện bất thường|desc=anomaly detection unsupervised reconstruction PatchCore industrial defect medical lesion video surveillance|vi=phát hiện bất thường,anomaly detection|en=anomaly detection`},

		// ── NLP 2 (NLPROC2_) ─────────────────────────────────────────
		{"NLPROC2_RAG",           3,`label=RAG - tăng cường truy xuất|desc=RAG retrieval augmented generation vector database embedding cosine similarity chunking reranking hallucination|vi=RAG tăng cường truy xuất,RAG|en=RAG retrieval augmented generation`},
		{"NLPROC2_FINETUNE",      3,`label=tinh chỉnh mô hình ngôn ngữ|desc=LLM finetuning LoRA QLoRA PEFT instruction tuning RLHF DPO preference alignment dataset|vi=tinh chỉnh mô hình ngôn ngữ,LLM finetuning|en=LLM finetuning`},
		{"NLPROC2_AGENT",         3,`label=AI agent|desc=AI agent ReAct tool use function calling planning memory autonomous loop LangChain LangGraph orchestration|vi=AI agent,AI agent|en=AI agent`},
		{"NLPROC2_VIET_NLP",      3,`label=xử lý ngôn ngữ tiếng Việt|desc=Vietnamese NLP PhoBERT VinAI word segmentation tonal diacritics low-resource benchmark PhoNLP|vi=xử lý ngôn ngữ tiếng Việt,Vietnamese NLP|en=Vietnamese NLP`},
		{"NLPROC2_MULTIMODAL",    3,`label=mô hình đa phương thức|desc=multimodal model vision language CLIP BLIP GPT-4V Gemini image text audio video alignment contrastive|vi=mô hình đa phương thức,multimodal model|en=multimodal model`},

		// ── ROBOTICS 2 (ROBOTICS2_) ───────────────────────────────────
		{"ROBOTICS2_MANIPULATE",  3,`label=tay máy robot|desc=robot manipulation grasp planning dexterous hand tactile sensor force control compliance sim-to-real|vi=tay máy robot,robot manipulation|en=robot manipulation`},
		{"ROBOTICS2_LEGGED",      3,`label=robot chân|desc=legged robot Boston Dynamics Spot Anymal quadruped bipedal locomotion gait terrain adaptation whole body|vi=robot chân,legged robot|en=legged robot`},
		{"ROBOTICS2_SWARM",       3,`label=robot bầy đàn|desc=swarm robotics distributed collective emergent behavior stigmergy consensus formation control micro drone|vi=robot bầy đàn,swarm robotics|en=swarm robotics`},
		{"ROBOTICS2_SURGICAL",    3,`label=robot phẫu thuật|desc=surgical robot Da Vinci teleoperation haptic tremor filter laparoscopic endoscopic accuracy FDA clearance|vi=robot phẫu thuật,surgical robot|en=surgical robot`},
		{"ROBOTICS2_SOFT",        3,`label=robot mềm|desc=soft robotics silicone pneumatic actuator compliant continuum tentacle bio-inspired deformable gripper safe|vi=robot mềm,soft robotics|en=soft robotics`},

		// ── REINFORCEMENT LEARNING 2 (REINFORCE2_) ────────────────────
		{"REINFORCE2_OFFLINE",    3,`label=học tăng cường offline|desc=offline RL batch fixed dataset conservative Q-learning CQL IQL decision transformer behavior cloning|vi=học tăng cường offline,offline RL|en=offline RL`},
		{"REINFORCE2_MULTI",      3,`label=học tăng cường đa tác tử|desc=multi-agent RL MARL cooperative competitive communication emergent MADDPG QMIX StarCraft II|vi=học tăng cường đa tác tử,multi-agent RL|en=multi-agent RL`},
		{"REINFORCE2_HUMAN",      3,`label=học từ phản hồi con người|desc=RLHF reinforcement learning human feedback reward model PPO Proximal Policy Optimization preference|vi=học từ phản hồi con người,RLHF|en=RLHF`},
		{"REINFORCE2_WORLD",      3,`label=mô hình thế giới trong RL|desc=world model model-based RL Dreamer MuZero latent imagination planning imagination rollout sample efficiency|vi=mô hình thế giới trong RL,world model RL|en=world model RL`},
		{"REINFORCE2_GAME",       3,`label=RL trong trò chơi|desc=game playing RL AlphaGo AlphaZero AlphaStar OpenAI Five Dota self-play curriculum exploration|vi=RL trong trò chơi,game playing RL|en=game playing RL`},

		// ── GENERATIVE AI (GENERATIVE_) ──────────────────────────────
		{"GENERATIVE_DIFFUSION",  3,`label=mô hình khuếch tán|desc=diffusion model DDPM score matching stable diffusion DALL-E Midjourney denoising noise schedule|vi=mô hình khuếch tán,diffusion model|en=diffusion model`},
		{"GENERATIVE_GAN2",       3,`label=GAN nâng cao|desc=advanced GAN StyleGAN2 BigGAN conditional GAN mode collapse training stability FID Frechet Inception Distance|vi=GAN nâng cao,advanced GAN|en=advanced GAN`},
		{"GENERATIVE_VIDEO",      3,`label=tạo sinh video|desc=video generation Sora temporal consistency motion coherence world simulation physics 3D understanding|vi=tạo sinh video,video generation|en=video generation`},
		{"GENERATIVE_AUDIO",      3,`label=tạo sinh âm thanh|desc=audio generation WaveNet TTS speech synthesis music generation MusicGen AudioCraft neural codec vocoders|vi=tạo sinh âm thanh,audio generation|en=audio generation`},
		{"GENERATIVE_CODE",       3,`label=tạo sinh code|desc=code generation Copilot Codex AlphaCode program synthesis HumanEval MBPP execution feedback debugging|vi=tạo sinh code,code generation|en=code generation`},

		// ── MATERIALS 2 (MATERIALS2_) ────────────────────────────────
		{"MATERIALS2_2D",         3,`label=vật liệu 2D|desc=2D materials graphene MoS2 hBN TMD heterostructure van der Waals stacking twist angle moiré superconductor|vi=vật liệu 2D,2D materials|en=2D materials`},
		{"MATERIALS2_SHAPE",      3,`label=vật liệu nhớ hình dạng|desc=shape memory alloy NiTi Nitinol superelastic martensite austenite biomedical stent actuator|vi=vật liệu nhớ hình dạng,shape memory alloy|en=shape memory alloy`},
		{"MATERIALS2_SELFHEAL",   3,`label=vật liệu tự phục hồi|desc=self-healing material microcapsule vascular intrinsic autonomic recovery scratch coating structural health|vi=vật liệu tự phục hồi,self-healing material|en=self-healing material`},
		{"PHOTONICS_FIBER",       3,`label=cáp quang|desc=optical fiber single-mode multi-mode SMF28 attenuation dispersion amplifier EDFA DWDM bandwidth telecom|vi=cáp quang,optical fiber|en=optical fiber`},
		{"PHOTONICS_LASER",       3,`label=laser và ứng dụng|desc=laser stimulated emission coherent monochromatic semiconductor VCSEL fiber laser CO2 cutting welding lidar|vi=laser và ứng dụng,laser|en=laser`},

		// ── SPACE 2 (SPACE2_) ─────────────────────────────────────────
		{"SPACE2_CONSTELLATION",  3,`label=chùm vệ tinh|desc=satellite constellation Starlink OneWeb Kuiper LEO low latency global coverage broadband spectrum interference|vi=chùm vệ tinh,satellite constellation|en=satellite constellation`},
		{"SPACE2_EARTHOBS",       3,`label=quan sát Trái Đất từ vũ trụ|desc=Earth observation remote sensing SAR optical multispectral change detection land use fire flood crop|vi=quan sát Trái Đất từ vũ trụ,Earth observation|en=Earth observation`},
		{"SPACE2_REUSABLE",       3,`label=tên lửa tái sử dụng|desc=reusable rocket SpaceX Falcon 9 Starship landing propulsive VTVL cost reduction launch cadence|vi=tên lửa tái sử dụng,reusable rocket|en=reusable rocket`},
		{"SPACE2_LUNAR",          3,`label=chương trình Mặt Trăng|desc=lunar program Artemis SLS Orion Gateway CLPS commercial lander ice south pole Shackleton crater|vi=chương trình Mặt Trăng,lunar program|en=lunar program`},
		{"SPACE2_ASTEROID",       3,`label=khai thác tiểu hành tinh|desc=asteroid mining DART Psyche carbon chondrite water platinum PGM space resource extraction regulation|vi=khai thác tiểu hành tinh,asteroid mining|en=asteroid mining`},

		// ── ANCIENT MESOAMERICA & MIDDLE EAST ────────────────────────
		{"ANCIENT_MAYA",          3,`label=văn minh Maya|desc=Maya civilization calendar Long Count astronomy zero number pyramid Tikal Chichen Itza collapse drought|vi=văn minh Maya,Maya civilization|en=Maya civilization`},
		{"ANCIENT_AZTEC",         3,`label=văn minh Aztec|desc=Aztec empire Tenochtitlan Mexica Triple Alliance tribute human sacrifice Cortes conquest smallpox|vi=văn minh Aztec,Aztec empire|en=Aztec civilization`},
		{"ANCIENT_MESOPOTAMIA",   3,`label=Lưỡng Hà cổ đại|desc=Mesopotamia Sumer Akkad Babylonia cuneiform Gilgamesh Code Hammurabi irrigation ziggurat Ur|vi=Lưỡng Hà cổ đại,Mesopotamia|en=Mesopotamia`},
		{"BYZANTINE_EMPIRE",      3,`label=Đế chế Byzantine|desc=Byzantine Empire Eastern Roman Constantinople Hagia Sophia Justinian Corpus Juris Greek Orthodox 1453|vi=Đế chế Byzantine,Byzantine Empire|en=Byzantine Empire`},
		{"OTTOMAN_EMPIRE",        3,`label=Đế chế Ottoman|desc=Ottoman Empire Suleiman Topkapi devshirme millet janissary decline Sick Man reform Tanzimat|vi=Đế chế Ottoman,Ottoman Empire|en=Ottoman Empire`},

		// ── MONGOL & FINTECH ──────────────────────────────────────────
		{"MONGOL_EMPIRE",         3,`label=Đế chế Mông Cổ|desc=Mongol Empire Genghis Khan Pax Mongolica trade silk road yam post system plague spread Kublai|vi=Đế chế Mông Cổ,Mongol Empire|en=Mongol Empire`},
		{"FINTECH2_PAYMENT",      3,`label=thanh toán số|desc=digital payment NFC QR code wallet Stripe Adyen interchange acquiring issuing POS contactless BNPL|vi=thanh toán số,digital payment|en=digital payment`},
		{"FINTECH2_OPEN",         3,`label=ngân hàng mở|desc=open banking PSD2 API third party provider TPP account aggregation consent data portability UK EU|vi=ngân hàng mở,open banking|en=open banking`},
		{"FINTECH2_REGTECH",      3,`label=công nghệ tuân thủ|desc=regtech compliance AML KYC transaction monitoring sanctions screening NLP automation FATF|vi=công nghệ tuân thủ,regtech|en=regtech`},
		{"INSURTECH_PARAM",       3,`label=bảo hiểm tham số|desc=parametric insurance trigger weather index satellite IoT basis risk crop flood catastrophe payout|vi=bảo hiểm tham số,parametric insurance|en=parametric insurance`},

		// ── LINGUISTICS: PHONOLOGY → SOCIOLINGUISTICS ─────────────────
		{"PHONOLOGY_TONE",        3,`label=thanh điệu học|desc=tone language tonal contour register Mandarin Vietnamese Thai Yoruba lexical grammatical prosody|vi=thanh điệu học,tone language|en=tone language`},
		{"PHONOLOGY_PROSODY",     3,`label=ngữ điệu học|desc=prosody intonation stress rhythm sentence focus downstep upstep phonological phrase ToBI autosegmental|vi=ngữ điệu học,prosody|en=linguistic prosody`},
		{"MORPHOLOGY_DERIVATION", 3,`label=hình vị học|desc=morphology derivation inflection agglutinative fusional isolating root pattern word formation productivity|vi=hình vị học,morphology|en=morphology`},
		{"SYNTAX2_MINIMALIST",    3,`label=cú pháp tối giản|desc=minimalist syntax Chomsky merge Agree feature copy movement phase spellout transfer interface|vi=cú pháp tối giản,minimalist syntax|en=minimalist syntax`},
		{"PRAGMATICS_IMPLICATURE",3,`label=hàm ý ngôn ngữ|desc=pragmatics implicature Grice maxims cooperative principle relevance theory speech act Austin Searle|vi=hàm ý ngôn ngữ,pragmatics implicature|en=pragmatics implicature`},

		// ── SOCIOLINGUISTICS 2 ────────────────────────────────────────
		{"SOCIOLING2_CODESWITCH", 3,`label=chuyển mã ngôn ngữ|desc=code-switching Labov matrix frame language island constraint insertion alternation social meaning|vi=chuyển mã ngôn ngữ,code-switching|en=code-switching`},
		{"SOCIOLING2_ENDANGERED", 3,`label=ngôn ngữ nguy cấp|desc=endangered language documentation revitalization Ethnologue UNESCO atlas sleeping waking last speaker|vi=ngôn ngữ nguy cấp,endangered language|en=endangered language`},
		{"SOCIOLING2_DIGITAL",    3,`label=ngôn ngữ số|desc=digital language CMC emoji hashtag meme internet slang youth language orthographic variation Netspeak|vi=ngôn ngữ số,digital language|en=digital language`},
		{"SOCIOLING2_POLICY",     3,`label=chính sách ngôn ngữ|desc=language policy official language medium instruction minority rights bilingual education planning corpus|vi=chính sách ngôn ngữ,language policy|en=language policy`},
		{"SOCIOLING2_VIET",       3,`label=xã hội ngôn ngữ Việt Nam|desc=xã hội ngôn ngữ Việt Nam phương ngữ Bắc Nam Trung tiếng dân tộc song ngữ chính sách|vi=xã hội ngôn ngữ Việt Nam,Vietnamese sociolinguistics|en=Vietnamese sociolinguistics`},

		// ── VIETNAM: AGRICULTURE, TOURISM, CRAFT ─────────────────────
		{"VNAGRI2_RICE",          3,`label=lúa gạo Việt Nam|desc=lúa gạo Việt Nam ST25 gạo ngon nhất thế giới IRRI đồng bằng sông Cửu Long biến đổi khí hậu xâm nhập mặn|vi=lúa gạo Việt Nam,Vietnam rice|en=Vietnam rice`},
		{"VNAGRI2_SHRIMP",        3,`label=tôm Việt Nam|desc=tôm Việt Nam nuôi trồng thủy sản Cà Mau Bạc Liêu xuất khẩu tôm sú tôm thẻ chân trắng bệnh EMS|vi=tôm Việt Nam,Vietnam shrimp|en=Vietnam shrimp`},
		{"VNAGRI2_COFFEE",        3,`label=cà phê Việt Nam|desc=cà phê Việt Nam Robusta Arabica Tây Nguyên Buôn Ma Thuột xuất khẩu thứ 2 thế giới cà phê chồn|vi=cà phê Việt Nam,Vietnam coffee|en=Vietnam coffee`},
		{"VNTOURISM2_HERITAGE",   3,`label=du lịch di sản Việt Nam|desc=du lịch di sản Hội An Mỹ Sơn Cố đô Huế Phong Nha Hạ Long UNESCO phát triển bền vững overtourism|vi=du lịch di sản Việt Nam,Vietnam heritage tourism|en=Vietnam heritage tourism`},
		{"VNTOURISM2_COASTAL",    3,`label=du lịch biển đảo Việt Nam|desc=du lịch biển Việt Nam Phú Quốc Đà Nẵng Nha Trang resort 5 sao hạ tầng du thuyền casino|vi=du lịch biển đảo Việt Nam,Vietnam coastal tourism|en=Vietnam coastal tourism`},

		// ── VIETNAM CRAFT & FOOD ──────────────────────────────────────
		{"VNCRAFT_SILK",          3,`label=lụa Việt Nam|desc=lụa Việt Nam làng lụa Vạn Phúc Hội An tơ tằm dệt thủ công xuất khẩu thời trang bền vững|vi=lụa Việt Nam,Vietnamese silk|en=Vietnamese silk`},
		{"VNCRAFT_LACQUER",       3,`label=sơn mài Việt Nam|desc=sơn mài Việt Nam nhựa cây sơn nhung đen đỏ son thếp vàng bạc nghệ thuật ứng dụng xuất khẩu|vi=sơn mài Việt Nam,Vietnamese lacquer|en=Vietnamese lacquer`},
		{"VNCRAFT_POTTERY",       3,`label=gốm sứ Việt Nam|desc=gốm sứ Việt Nam Bát Tràng Chu Đậu Lái Thiêu men lam men ngọc hoa lam xuất khẩu thế kỷ XV|vi=gốm sứ Việt Nam,Vietnamese pottery|en=Vietnamese pottery`},
		{"VNFOOD3_FERMENT",       3,`label=thực phẩm lên men Việt Nam|desc=thực phẩm lên men Việt Nam mắm tôm mắm nêm nước mắm Phú Quốc tương dưa cà muối vi sinh|vi=thực phẩm lên men Việt Nam,Vietnamese fermented food|en=Vietnamese fermented food`},
		{"VNFOOD3_STREET",        3,`label=ẩm thực đường phố Việt Nam|desc=ẩm thực đường phố Việt Nam bánh mì phở bún chả gỏi cuốn bánh xèo Anthony Bourdain CNN|vi=ẩm thực đường phố Việt Nam,Vietnam street food|en=Vietnam street food`},

		// ── VIETNAM SPORT ─────────────────────────────────────────────
		{"VNSPORT2_FOOTBALL",     3,`label=bóng đá Việt Nam|desc=bóng đá Việt Nam U23 châu Á Park Hang-seo AFF Cup V.League Công Phượng Quang Hải phát triển|vi=bóng đá Việt Nam,Vietnam football|en=Vietnam football`},
		{"VNSPORT2_MARTIAL",      3,`label=võ thuật Việt Nam|desc=võ thuật Việt Nam Vovinam võ cổ truyền Bình Định đẩy gậy vật dân tộc SEA Games quốc tế|vi=võ thuật Việt Nam,Vietnamese martial arts|en=Vietnamese martial arts`},
		{"VNSPORT2_ESPORT",       3,`label=thể thao điện tử Việt Nam|desc=esport Việt Nam LMHT Liên Quân Mobile quốc tế SEA Games VCS team T1 đào tạo vận động viên|vi=thể thao điện tử Việt Nam,Vietnam esports|en=Vietnam esports`},

		// ── NANOTECH 2 & BIOMATERIALS ────────────────────────────────
		{"NANOTECH2_DRUG",        3,`label=nano drug delivery|desc=nanoparticle drug delivery liposome polymeric micelle targeted cancer tumor EPR stealth PEG FDA approval|vi=nano drug delivery,nanoparticle drug delivery|en=nanoparticle drug delivery`},
		{"NANOTECH2_QUANTUM",     3,`label=quantum dot|desc=quantum dot CdSe core shell size tunable fluorescence bioimaging display QLED photovoltaic cadmium-free|vi=quantum dot,quantum dot|en=quantum dot`},
		{"BIOMATERIAL_SCAFFOLD",  3,`label=vật liệu sinh học scaffold|desc=biomaterial scaffold tissue engineering bone cartilage skin 3D bioprint hydrogel ECM biodegradable|vi=vật liệu sinh học scaffold,biomaterial scaffold|en=biomaterial scaffold`},
		{"COMPOSITE_CARBON",      3,`label=vật liệu composite carbon|desc=carbon fiber composite CFRP epoxy matrix aerospace structural lightweight tension modulus fatigue|vi=vật liệu composite carbon,carbon fiber composite|en=carbon fiber composite`},
		{"PROPTECH_DIGITAL",      3,`label=công nghệ bất động sản|desc=proptech digital real estate platform listing BIM digital twin IoT smart building facility management|vi=công nghệ bất động sản,proptech|en=proptech`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 4300 { fmt.Println(" MILESTONE 4300! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
