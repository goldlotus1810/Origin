//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── ROBOT HỌC (ROBOTICS_) ─────────────────────────────────
		{"ROBOTICS_INDUSTRIAL",3, `label=robot công nghiệp|desc=cánh tay robot hàn lắp ráp ô tô điện tử ABB KUKA Fanuc tự động hóa nhà máy|vi=robot công nghiệp,industrial robot|en=industrial robot|zh=工业机器人`},
		{"ROBOTICS_HUMANOID",  3, `label=robot hình người|desc=Boston Dynamics Atlas Spot Tesla Optimus bipedal locomotion cảm biến AI|vi=robot hình người,humanoid robot|en=humanoid robot|zh=仿人机器人`},
		{"ROBOTICS_DRONE",     3, `label=máy bay không người lái|desc=drone UAV DJI giao hàng quân sự nông nghiệp ảnh hàng không cấm khu|vi=drone,UAV,máy bay không người lái|en=drone,UAV|zh=无人机`},
		{"ROBOTICS_AUTONOMOUS",3, `label=xe tự lái|desc=autonomous vehicle Tesla Waymo Level 1-5 lidar camera AI safety đường phố|vi=xe tự lái,autonomous vehicle|en=self-driving car|zh=自动驾驶汽车`},

		// ── KINH TẾ VIỆT NAM BỔ SUNG (VNECON2_) ──────────────────
		{"VNECON2_STOCK",     3, `label=thị trường chứng khoán VN|desc=VN-Index HoSE HNX UPCoM cổ phiếu trái phiếu phái sinh nhà đầu tư cá nhân|vi=chứng khoán Việt Nam,VN-Index|en=Vietnam stock market|zh=越南股市`},
		{"VNECON2_REAL_ESTATE",3,`label=bất động sản Việt Nam|desc=thị trường nhà đất TP.HCM Hà Nội giá tăng mạnh pháp lý sổ đỏ condotel phân khúc|vi=bất động sản Việt Nam,nhà đất|en=Vietnam real estate|zh=越南房地产`},
		{"VNECON2_BANKING",   3, `label=ngân hàng Việt Nam|desc=Vietcombank VietinBank BIDV Agribank Techcombank MB VPBank tín dụng số hóa|vi=ngân hàng Việt Nam,hệ thống ngân hàng|en=Vietnam banking|zh=越南银行业`},
		{"VNECON2_TOURISM",   3, `label=du lịch Việt Nam|desc=5 triệu khách quốc tế 2023 Hội An Hạ Long Đà Nẵng Phú Quốc phục hồi sau COVID|vi=du lịch Việt Nam,tourism|en=Vietnam tourism|zh=越南旅游业`},

		// ── VẬT LÝ HẠT NHÂN (NUCLEAR_) ────────────────────────────
		{"NUCLEAR_FISSION",   3, `label=phân hạch hạt nhân|desc=uranium-235 plutonium-239 phản ứng dây chuyền nhà máy điện hạt nhân bom nguyên tử|vi=phân hạch hạt nhân,nuclear fission|en=nuclear fission|zh=核裂变`},
		{"NUCLEAR_RADIATION", 3, `label=bức xạ hạt nhân|desc=tia alpha beta gamma neutron Sievert dose y tế chẩn đoán Chernobyl Fukushima|vi=bức xạ hạt nhân,radiation|en=nuclear radiation|zh=核辐射`},
		{"NUCLEAR_REACTOR",   3, `label=lò phản ứng hạt nhân|desc=PWR BWR CANDU thanh nhiên liệu chất làm mát điều khiển an toàn|vi=lò phản ứng hạt nhân,nuclear reactor|en=nuclear reactor|zh=核反应堆`},

		// ── HÓA HỌC HỮU CƠ (ORGCHEM_) ────────────────────────────
		{"ORGCHEM_CARBOHY",   3, `label=carbohydrate|desc=glucose fructose sucrose tinh bột cellulose năng lượng thực vật cấu trúc vòng Fischer|vi=carbohydrate,đường|en=carbohydrate|zh=碳水化合物`},
		{"ORGCHEM_PROTEIN_CHEM",3,`label=protein hóa học|desc=chuỗi polypeptide axit amin cấu trúc bậc 1-4 enzyme cấu trúc chức năng biến tính|vi=protein hóa học,protein|en=protein chemistry|zh=蛋白质化学`},
		{"ORGCHEM_LIPID",     3, `label=lipid|desc=chất béo phospholipid steroid cholesterol màng tế bào năng lượng dự trữ mỡ dầu|vi=lipid,chất béo|en=lipid|zh=脂质`},
		{"ORGCHEM_NUCLEIC",   3, `label=axit nucleic|desc=DNA RNA nucleotide base A T G C chuỗi đôi xoắn Watson Crick di truyền|vi=axit nucleic,DNA,RNA|en=nucleic acid|zh=核酸`},

		// ── LỊCH SỬ VIỆT NAM BỔ SUNG (VNHIST2_) ──────────────────
		{"VNHIST2_ANCIENT",   3, `label=Việt Nam cổ đại|desc=Văn Lang Âu Lạc Đông Sơn Hùng Vương Lạc Long Quân Âu Cơ trống đồng|vi=Việt Nam cổ đại,Văn Lang,Hùng Vương|en=ancient Vietnam|zh=古代越南`},
		{"VNHIST2_FRENCH",    3, `label=thời Pháp thuộc|desc=Đông Dương thuộc Pháp 1887-1945 khai thác cao su cà phê lúa gạo phong trào yêu nước|vi=Pháp thuộc,thực dân Pháp|en=French Indochina|zh=法属印度支那`},
		{"VNHIST2_REUNIFY",   3, `label=thống nhất đất nước|desc=30-4-1975 giải phóng Sài Gòn thống nhất Bắc Nam 1976 đổi tên Hồ Chí Minh|vi=thống nhất,30-4-1975|en=Vietnam reunification|zh=越南统一`},

		// ── THIÊN VĂN ỨNG DỤNG (ASTRO_APP_) ─────────────────────
		{"ASTRO_APP_GPS",     3, `label=GPS|desc=hệ thống định vị toàn cầu 31 vệ tinh Mỹ tọa độ thời gian đồng hồ nguyên tử hiệu ứng Einstein|vi=GPS,định vị toàn cầu|en=GPS,Global Positioning System|zh=全球定位系统`},
		{"ASTRO_APP_WEATHER", 3, `label=vệ tinh khí tượng|desc=dự báo thời tiết hình ảnh mây bão GOES NOAA Himawari cảnh báo thiên tai|vi=vệ tinh khí tượng,thời tiết vệ tinh|en=weather satellite|zh=气象卫星`},
		{"ASTRO_APP_TELECOM", 3, `label=vệ tinh viễn thông|desc=Starlink OneWeb Intelsat internet tốc độ cao vùng sâu xa phủ sóng toàn cầu|vi=vệ tinh viễn thông,Starlink|en=communication satellite|zh=通信卫星`},

		// ── ĐẠO ĐỨC CÔNG NGHỆ (TECHETHICS_) ──────────────────────
		{"TECHETHICS_AI",     3, `label=đạo đức AI|desc=bias fairness transparency explainability accountability algorithmic harm AI safety|vi=đạo đức AI,AI ethics|en=AI ethics|zh=人工智能伦理`},
		{"TECHETHICS_PRIVACY",3, `label=quyền riêng tư số|desc=GDPR CCPA dữ liệu cá nhân thu thập sử dụng đồng ý quyền bị quên surveillance|vi=quyền riêng tư số,privacy|en=digital privacy|zh=数字隐私`},
		{"TECHETHICS_CYBER",  3, `label=tội phạm mạng|desc=cybercrime phishing ransomware hacker social engineering identity theft zero-day|vi=tội phạm mạng,cybercrime|en=cybercrime|zh=网络犯罪`},
		{"TECHETHICS_DESINF", 3, `label=thông tin sai lệch|desc=disinformation misinformation deepfake fact-checking media literacy social media|vi=thông tin sai lệch,fake news|en=disinformation|zh=虚假信息`},

		// ── VĂN HỌC VIỆT NAM BỔ SUNG (VNLIT2_) ───────────────────
		{"VNLIT2_NAM_QUOC",   3, `label=Nam quốc sơn hà|desc=bài thơ Lý Thường Kiệt thế kỷ 11 tuyên ngôn độc lập đầu tiên quân Tống|vi=Nam quốc sơn hà,Lý Thường Kiệt|en=Nam quoc son ha poem|zh=南国山河`},
		{"VNLIT2_BINH_NGO",   3, `label=Bình Ngô Đại Cáo|desc=tuyên ngôn độc lập Nguyễn Trãi 1428 đuổi quân Minh hùng văn chính luận|vi=Bình Ngô Đại Cáo,Nguyễn Trãi|en=Proclamation of Victory|zh=平吴大诰`},
		{"VNLIT2_HSTORY_NOVEL",3,`label=tiểu thuyết lịch sử VN|desc=Nam Quốc Sơn Hà Hồ Biểu Chánh Ngô Tất Tố Vũ Trọng Phụng văn học hiện thực|vi=tiểu thuyết lịch sử VN,văn học VN|en=Vietnamese historical novel|zh=越南历史小说`},

		// ── ĐỊA LÝ ĐÔNG NAM Á (SEA_GEO_) ────────────────────────
		{"SEA_GEO_MEKONG",    3, `label=sông Mê Kông|desc=dài 4350 km Trung Quốc Myanmar Lào Thái Lan Campuchia Việt Nam thủy sản giao thông|vi=sông Mê Kông,Mekong|en=Mekong River|zh=湄公河`},
		{"SEA_GEO_BORNEO",    3, `label=đảo Borneo|desc=đảo lớn thứ 3 thế giới Malaysia Indonesia Brunei rừng nhiệt đới đười ươi|vi=đảo Borneo,Kalimantan|en=Borneo island|zh=婆罗洲`},
		{"SEA_GEO_JAVA",      3, `label=đảo Java|desc=đảo đông dân nhất thế giới 150 triệu người Indonesia Jakarta Borobudur Jawa|vi=đảo Java,Java|en=Java island|zh=爪哇岛`},

		// ── NGOẠI NGỮ PHỔ BIẾN (LANG_) ───────────────────────────
		{"LANG_MANDARIN",     3, `label=tiếng Trung Phổ thông|desc=ngôn ngữ nhiều người nói nhất 1.1 tỷ 4 thanh điệu chữ Hán phồn giản thể|vi=tiếng Trung,tiếng Hoa|en=Mandarin Chinese|zh=普通话`},
		{"LANG_SPANISH",      3, `label=tiếng Tây Ban Nha|desc=500 triệu người 21 quốc gia ngôn ngữ chính thức Tây Ban Nha Mỹ Latin|vi=tiếng Tây Ban Nha,Spanish|en=Spanish|zh=西班牙语`},
		{"LANG_JAPANESE",     3, `label=tiếng Nhật|desc=hiragana katakana kanji SOV agglutinative 127 triệu người Nhật Bản anime manga|vi=tiếng Nhật,Japanese|en=Japanese|zh=日语`},
		{"LANG_ARABIC",       3, `label=tiếng Ả Rập|desc=ngôn ngữ Semitic 422 triệu người 22 quốc gia Hồi giáo viết phải sang trái Modern Standard|vi=tiếng Ả Rập,Arabic|en=Arabic|zh=阿拉伯语`},
		{"LANG_HINDI",        3, `label=tiếng Hindi|desc=600 triệu người Ấn Độ Devanagari script ngôn ngữ chính thức Ấn Độ cùng tiếng Anh|vi=tiếng Hindi,Hindi|en=Hindi|zh=印地语`},

		// ── SINH HỌC TIẾN HÓA (EVOBIO_) ─────────────────────────
		{"EVOBIO_DARWIN",     3, `label=thuyết tiến hóa Darwin|desc=chọn lọc tự nhiên biến đổi đột biến thích nghi On the Origin of Species 1859|vi=thuyết tiến hóa,Darwin|en=Darwin's evolution theory|zh=达尔文进化论`},
		{"EVOBIO_GENETICS",   3, `label=di truyền Mendel|desc=Gregor Mendel đậu Hà Lan quy luật phân ly độc lập gen trội lặn di truyền|vi=di truyền Mendel,di truyền học|en=Mendelian genetics|zh=孟德尔遗传学`},
		{"EVOBIO_SPECIATION", 3, `label=hình thành loài|desc=speciation cách ly địa lý sinh sản cây phát sinh gene flow allopatric sympatric|vi=hình thành loài,speciation|en=speciation|zh=物种形成`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"ROBOTICS_AUTONOMOUS","FUTURE_NEURALINK",  "integrates-with"},
		{"ROBOTICS_DRONE",     "ROBOTICS_AUTONOMOUS","inspired"},
		{"VNECON2_STOCK",      "VNECON_FDI",        "attracts"},
		{"VNECON2_BANKING",    "VNECON2_STOCK",     "funds"},
		{"NUCLEAR_FISSION",    "FUTURE_FUSION",     "precedes"},
		{"NUCLEAR_REACTOR",    "NUCLEAR_FISSION",   "uses"},
		{"ORGCHEM_PROTEIN_CHEM","BIO2_GENE_THERAPY","targets"},
		{"ORGCHEM_NUCLEIC",    "BIO2_MICROBIOME",   "encodes"},
		{"ML2_TRANSFORMER",    "ML2_RAG",           "enables"},
		{"TECHETHICS_AI",      "AI2_ETHICS",        "extends"},
		{"TECHETHICS_PRIVACY", "DIGITAL2_PRIV",     "implements"},
		{"ASTRO_APP_GPS",      "ROBOTICS_AUTONOMOUS","enables"},
		{"ASTRO_APP_TELECOM",  "SPACE3_SPACEX",     "deployed-by"},
		{"SEA_GEO_MEKONG",     "VNENV_MEKONG",      "is"},
		{"EVOBIO_DARWIN",      "EVOBIO_GENETICS",   "combined-with"},
		{"EVOBIO_SPECIATION",  "EVOBIO_DARWIN",     "explains"},
		{"LANG_MANDARIN",      "ASIAHIST_CHINA_HIST","reflects"},
		{"LANG_JAPANESE",      "ASIAHIST_JAPAN",    "part-of"},
		{"VNLIT2_BINH_NGO",    "VNHIST2_ANCIENT",   "celebrates"},
		{"VNHIST2_FRENCH",     "VNHIST_DIENBIEN",   "leads-to"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2700 { fmt.Println("🎉 MILESTONE 2700!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"integrates-with":1,"inspired":2,"attracts":3,"funds":4,"precedes":5,
		"uses":6,"targets":7,"encodes":8,"enables":9,"extends":10,
		"implements":11,"deployed-by":12,"is":13,"combined-with":14,"explains":15,
		"reflects":16,"part-of":17,"celebrates":18,"leads-to":19,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
