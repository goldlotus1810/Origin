//go:build ignore
// seed_milestone4100.go — MILESTONE 4100 — 100 nodes
// Domains: COGNLANG_ NEUROLANG_ TRANSLING_ TYPOLOGY_ WRITING_
//          COMIC_ ILLUSTRATION_ TYPOGRAPHY_ VISUALCOMM_ BRANDING_
//          ZOONOSIS_ ECOLOGY3_ SPECIES_ MARINE2_ BIODIV2_
//          SLEEP_ CHRONIC_ PAIN_ NUTRITION2_ PREVENTIVE_
//          ASTROPHYS2_ PLASMA_ PARTICLE_ CONDENSED_ NUCLEAR2_
//          VNPHILOSOPHY_ VNRELIGION_ VNETHICS_ VNSCIENCE_ VNMILITARY_
//          STARTUP2_ LEADERSHIP_ MANAGEMENT_ CONSULTING_ NONPROFIT_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── COGNITIVE LINGUISTICS (COGNLANG_) ────────────────────────
		{"COGNLANG_METAPHOR",    3,`label=ẩn dụ nhận thức|desc=conceptual metaphor Lakoff Johnson embodied LIFE IS JOURNEY argument war container schema image schema mapping|vi=ẩn dụ nhận thức,conceptual metaphor|en=conceptual metaphor`},
		{"COGNLANG_PROTOTYPE",   3,`label=lý thuyết nguyên mẫu|desc=prototype theory Rosch basic level category graded membership family resemblance radial category fuzzy boundary|vi=lý thuyết nguyên mẫu,prototype theory|en=prototype theory`},
		{"COGNLANG_CONSTRUAL",   3,`label=cấu trúc hóa ngôn ngữ|desc=construal Langacker specificity prominence perspective figure ground profiling active zone scope|vi=cấu trúc hóa ngôn ngữ,construal|en=linguistic construal`},
		{"COGNLANG_FRAME",       3,`label=ngữ nghĩa khung|desc=frame semantics Fillmore FrameNet scene scenario understanding inference commercial transaction buyer seller|vi=ngữ nghĩa khung,frame semantics|en=frame semantics`},
		{"COGNLANG_GESTURE",     3,`label=cử chỉ và ngôn ngữ|desc=gesture speech integration McNeill growth point iconic metaphoric beat deictic spatial thinking-for-speaking|vi=cử chỉ và ngôn ngữ,gesture language|en=gesture language`},

		// ── NEUROLINGUISTICS (NEUROLANG_) ─────────────────────────────
		{"NEUROLANG_BROCA",      3,`label=vùng Broca và ngôn ngữ|desc=Broca area BA44 BA45 syntax production working memory hierarchical structure apraxia left hemisphere|vi=vùng Broca và ngôn ngữ,Broca area|en=Broca area language`},
		{"NEUROLANG_WERNICKE",   3,`label=vùng Wernicke|desc=Wernicke area BA22 speech comprehension fluent aphasia semantic paraphasia arcuate fasciculus dual stream model|vi=vùng Wernicke,Wernicke area|en=Wernicke area`},
		{"NEUROLANG_BILINGUAL",  3,`label=não song ngữ|desc=bilingual brain L1 L2 age of acquisition proficiency BOLD fMRI code-switching subcortical basal ganglia inhibition|vi=não song ngữ,bilingual brain|en=bilingual brain`},
		{"NEUROLANG_READING",    3,`label=thần kinh học đọc|desc=reading neuroscience visual word form area VWFA fusiform orthographic phonological dual route phonics dyslexia|vi=thần kinh học đọc,reading neuroscience|en=reading neuroscience`},
		{"NEUROLANG_PROSODY",    3,`label=ngữ điệu và não|desc=prosody brain right hemisphere emotion intonation rhythm stress tone language music overlap temporal|vi=ngữ điệu và não,prosody brain|en=prosody brain`},

		// ── TRANSLATION STUDIES (TRANSLING_) ─────────────────────────
		{"TRANSLING_THEORY",     3,`label=lý thuyết dịch thuật|desc=translation theory equivalence Nida formal dynamic Venuti foreignization domestication Skopos purpose target|vi=lý thuyết dịch thuật,translation theory|en=translation theory`},
		{"TRANSLING_MACHINE",    3,`label=dịch máy|desc=machine translation rule-based statistical SMT neural NMT transformer BLEU score post-edit MTPE quality|vi=dịch máy,machine translation|en=machine translation`},
		{"TRANSLING_INTERP",     3,`label=phiên dịch|desc=interpreting consecutive simultaneous whisper liaison conference UN booth note-taking memory short-term cognitive load|vi=phiên dịch,interpreting|en=interpreting`},
		{"TRANSLING_LOCALIZE",   3,`label=bản địa hóa|desc=localization L10n i18n software game cultural adaptation calendar date format right-to-left layout pseudo|vi=bản địa hóa,localization|en=localization`},
		{"TRANSLING_VIET_TRAD",  3,`label=dịch thuật Việt Nam|desc=dịch thuật Việt Nam Hán Nôm chữ quốc ngữ Alexandre de Rhodes dịch kinh điển Phật giáo văn học|vi=dịch thuật Việt Nam,Vietnamese translation|en=Vietnamese translation`},

		// ── WRITING SYSTEMS (WRITING_) ────────────────────────────────
		{"WRITING_SYSTEMS",      3,`label=hệ thống chữ viết|desc=writing systems logographic syllabic alphabetic abjad abugida featural Hangul direction boustrophedon Unicode|vi=hệ thống chữ viết,writing systems|en=writing systems`},
		{"WRITING_HISTORY",      3,`label=lịch sử chữ viết|desc=writing history Sumerian cuneiform Egyptian hieroglyph Linear B Phoenician alphabet spread trade literacy|vi=lịch sử chữ viết,history of writing|en=history of writing`},
		{"WRITING_CJKV",         3,`label=chữ CJK và chữ Nôm|desc=CJK Chinese Japanese Korean Vietnamese characters kanji hanja chữ Nôm radical stroke count unification|vi=chữ CJK và chữ Nôm,CJK Nom|en=CJK Nom writing`},
		{"WRITING_ENDANGERED",   3,`label=chữ viết nguy cấp|desc=endangered script Cherokee Vai Bamum revival community literacy documentation Unicode proposal|vi=chữ viết nguy cấp,endangered script|en=endangered script`},
		{"WRITING_DIGITAL",      3,`label=chữ viết trong kỷ nguyên số|desc=digital writing text messaging emoji GIF keyboard prediction handwriting OCR screen reading comprehension|vi=chữ viết trong kỷ nguyên số,digital writing|en=digital writing`},

		// ── COMICS & ILLUSTRATION (COMIC_ / ILLUSTRATION_) ───────────
		{"COMIC_LANGUAGE",       3,`label=ngôn ngữ truyện tranh|desc=comics language panel gutter closure McCloud understanding comics time space sequence word image blend|vi=ngôn ngữ truyện tranh,comics language|en=comics language`},
		{"COMIC_MANGA_STYLE",    3,`label=phong cách manga|desc=manga style screentone speedline deformation chibi super-deformed emotional expression movement Japanese aesthetic|vi=phong cách manga,manga style|en=manga style`},
		{"COMIC_GRAPHIC_NOVEL",  3,`label=tiểu thuyết đồ họa|desc=graphic novel Maus Persepolis Watchmen Sandman literary comics memoir journalism complex narrative|vi=tiểu thuyết đồ họa,graphic novel|en=graphic novel`},
		{"ILLUSTRATION_CONCEPT", 3,`label=concept art|desc=concept art game film pre-production character design environment vehicle prop thumbnail iteration style guide|vi=concept art,concept art|en=concept art`},
		{"ILLUSTRATION_EDITORIAL",3,`label=minh họa báo chí|desc=editorial illustration metaphor opinion abstraction NYT New Yorker editorial brief limited color narrative visual argument|vi=minh họa báo chí,editorial illustration|en=editorial illustration`},

		// ── TYPOGRAPHY & VISUAL COMM (TYPOGRAPHY_ / VISUALCOMM_) ─────
		{"TYPOGRAPHY_TYPE",      3,`label=kiểu chữ và typography|desc=typography typeface serif sans-serif kerning leading tracking x-height baseline grid legibility readability hierarchy|vi=kiểu chữ và typography,typography|en=typography`},
		{"TYPOGRAPHY_VIET",      3,`label=typography tiếng Việt|desc=Vietnamese typography diacritics tone marks stacking Unicode normalization font rendering screen mobile|vi=typography tiếng Việt,Vietnamese typography|en=Vietnamese typography`},
		{"VISUALCOMM_INFOGRAPH",  3,`label=đồ họa thông tin|desc=infographic data visualization Tufte chartjunk data-ink ratio Bertin visual variables preattentive processing|vi=đồ họa thông tin,infographic|en=infographic`},
		{"VISUALCOMM_WAYFIND",   3,`label=hệ thống định hướng|desc=wayfinding signage pictogram icon system Otl Aicher AIGA airport hospital landmark decision point|vi=hệ thống định hướng,wayfinding|en=wayfinding signage`},
		{"BRANDING_IDENTITY",    3,`label=nhận diện thương hiệu|desc=brand identity logo wordmark symbol color typography system brand book touchpoint consistency equity|vi=nhận diện thương hiệu,brand identity|en=brand identity`},

		// ── ZOONOSIS & ECOLOGY 3 ─────────────────────────────────────
		{"ZOONOSIS_SPILLOVER",   3,`label=bệnh lây từ động vật|desc=zoonosis spillover bat reservoir amplification host intermediate SARS MERS COVID Nipah Ebola wet market|vi=bệnh lây từ động vật,zoonosis|en=zoonosis`},
		{"ECOLOGY3_FOOD_WEB",    3,`label=mạng lưới thức ăn|desc=food web trophic level keystone species trophic cascade wolf Yellowstone orca kelp bottom-up top-down control|vi=mạng lưới thức ăn,food web|en=food web`},
		{"ECOLOGY3_BIOME",       3,`label=quần xã sinh vật|desc=biome tropical rainforest savanna desert taiga tundra coral reef deep ocean climate adaptation zonation|vi=quần xã sinh vật,biome|en=biome`},
		{"SPECIES_INVASION",     3,`label=sinh vật ngoại lai xâm hại|desc=invasive species introduction pathway impact eradication management cane toad kudzu Burmese python economic cost|vi=sinh vật ngoại lai xâm hại,invasive species|en=invasive species`},
		{"MARINE2_CORAL",        3,`label=rạn san hô|desc=coral reef bleaching symbiodinium zooxanthellae thermal stress calcification ocean acidification Great Barrier Reef restoration|vi=rạn san hô,coral reef|en=coral reef`},

		// ── HEALTH: SLEEP, PAIN, NUTRITION 2 ─────────────────────────
		{"SLEEP_DISORDER",       3,`label=rối loạn giấc ngủ|desc=sleep disorder insomnia sleep apnea narcolepsy RLS PLMD CBT-I polysomnography CPAP melatonin adenosine|vi=rối loạn giấc ngủ,sleep disorder|en=sleep disorder`},
		{"SLEEP_SCIENCE",        3,`label=khoa học giấc ngủ|desc=sleep science REM NREM slow wave memory consolidation glymphatic system adenosine circadian rhythm Walker Why We Sleep|vi=khoa học giấc ngủ,sleep science|en=sleep science`},
		{"CHRONIC_DISEASE",      3,`label=bệnh mãn tính|desc=chronic disease NCD multimorbidity self-management patient education shared decision making care coordination primary care|vi=bệnh mãn tính,chronic disease|en=chronic disease`},
		{"PAIN_SCIENCE",         3,`label=khoa học đau|desc=pain science biopsychosocial model central sensitization neuroplasticity Moseley graded motor imagery nocebo|vi=khoa học đau,pain science|en=pain science`},
		{"NUTRITION2_MICRONUT",  3,`label=vi chất dinh dưỡng|desc=micronutrients iron deficiency anemia iodine vitamin A zinc B12 folate biofortification supplementation fortification|vi=vi chất dinh dưỡng,micronutrients|en=micronutrients`},

		// ── ASTROPHYSICS 2 (ASTROPHYS2_) ─────────────────────────────
		{"ASTROPHYS2_STELLAR",   3,`label=tiến hóa sao|desc=stellar evolution main sequence HR diagram Hertzsprung-Russell red giant white dwarf neutron star black hole mass|vi=tiến hóa sao,stellar evolution|en=stellar evolution`},
		{"ASTROPHYS2_NEBULA",    3,`label=tinh vân|desc=nebula emission reflection dark planetary molecular cloud star formation Hubble pillars of creation Eagle NGC|vi=tinh vân,nebula|en=nebula`},
		{"ASTROPHYS2_MULTI",     3,`label=thiên văn đa thông điệp|desc=multimessenger astronomy gravitational wave electromagnetic neutrino GW170817 kilonova r-process gold platinum|vi=thiên văn đa thông điệp,multimessenger astronomy|en=multimessenger astronomy`},
		{"PARTICLE_HIGGS",       3,`label=hạt Higgs|desc=Higgs boson LHC CERN 125 GeV 2012 discovery mass mechanism spontaneous symmetry breaking BEH Brout Englert|vi=hạt Higgs,Higgs boson|en=Higgs boson`},
		{"CONDENSED_TOPOLOGICAL",3,`label=vật liệu tô pô|desc=topological material topological insulator Weyl semimetal Berry phase Chern number surface state ARPES prediction|vi=vật liệu tô pô,topological material|en=topological material`},

		// ── VIETNAM PHILOSOPHY & RELIGION (VNPHILOSOPHY_ / VNRELIGION_)
		{"VNPHILOSOPHY_CONFUC",  3,`label=Nho giáo Việt Nam|desc=Nho giáo Việt Nam tam giáo đồng nguyên trung thần hiếu nghĩa trí tín hệ thống thi cử ảnh hưởng xã hội|vi=Nho giáo Việt Nam,Vietnamese Confucianism|en=Vietnamese Confucianism`},
		{"VNPHILOSOPHY_BUDD",    3,`label=Phật giáo Việt Nam|desc=Phật giáo Việt Nam Phật giáo Bắc tông Nam tông Khất sĩ Trúc Lâm Thích Nhất Hạnh chánh niệm tại thế|vi=Phật giáo Việt Nam,Vietnamese Buddhism|en=Vietnamese Buddhism`},
		{"VNRELIGION_CAODAI",    3,`label=Cao Đài|desc=Cao Đài tôn giáo bản địa 1926 Tây Ninh tam giáo Phật Lão Nho đại đoàn kết thiên nhiên thần linh|vi=Cao Đài,Cao Dai religion|en=Cao Dai`},
		{"VNRELIGION_HOAHAO",    3,`label=Hòa Hảo|desc=Phật giáo Hòa Hảo 1939 Huỳnh Phú Sổ đồng bằng sông Cửu Long thực hành không chùa giản dị|vi=Hòa Hảo,Hoa Hao Buddhism|en=Hoa Hao`},
		{"VNPHILOSOPHY_MODERN",  3,`label=triết học Việt Nam hiện đại|desc=triết học Việt Nam hiện đại Phan Bội Châu Nguyễn An Ninh Trần Đức Thảo chủ nghĩa duy vật biện chứng|vi=triết học Việt Nam hiện đại,modern Vietnamese philosophy|en=modern Vietnamese philosophy`},

		// ── VIETNAM SCIENCE & MILITARY ─────────────────────────────────
		{"VNSCIENCE_MATH",       3,`label=toán học Việt Nam|desc=toán học Việt Nam Ngô Bảo Châu Fields Medal 2010 bổ đề cơ bản Langlands Viện toán cao cấp VIASM|vi=toán học Việt Nam,Vietnamese mathematics|en=Vietnamese mathematics`},
		{"VNSCIENCE_PHYSICS",    3,`label=vật lý Việt Nam|desc=vật lý Việt Nam Nguyễn Văn Hiệu Viện vật lý Hà Nội hội nhập quốc tế CERN IAEA hợp tác nghiên cứu|vi=vật lý Việt Nam,Vietnamese physics|en=Vietnamese physics`},
		{"VNMILITARY_HISTORY",   3,`label=lịch sử quân sự Việt Nam|desc=quân sự Việt Nam chống Mông Cổ Bạch Đằng kháng Pháp kháng Mỹ chiến tranh biên giới 1979 chiến lược|vi=lịch sử quân sự Việt Nam,Vietnamese military history|en=Vietnamese military history`},
		{"VNMILITARY_STRATEGY",  3,`label=chiến lược quân sự Việt Nam|desc=chiến lược Việt Nam toàn dân toàn diện lâu dài tự lực chiến tranh nhân dân du kích Võ Nguyên Giáp|vi=chiến lược quân sự Việt Nam,Vietnamese military strategy|en=Vietnamese military strategy`},
		{"VNETHICS_TRADITION",   3,`label=đạo đức truyền thống Việt Nam|desc=đạo đức Việt Nam truyền thống nhân nghĩa lễ trí tín tương thân tương ái uống nước nhớ nguồn|vi=đạo đức truyền thống Việt Nam,Vietnamese traditional ethics|en=Vietnamese traditional ethics`},

		// ── STARTUP 2 & LEADERSHIP ────────────────────────────────────
		{"STARTUP2_VENTURE",     3,`label=đầu tư mạo hiểm|desc=venture capital term sheet pre-seed seed Series A B C SAFE convertible note valuation cap table dilution|vi=đầu tư mạo hiểm,venture capital|en=venture capital`},
		{"STARTUP2_PITCH",       3,`label=thuyết trình gọi vốn|desc=startup pitch deck problem solution market size traction team ask YC demo day storytelling investor|vi=thuyết trình gọi vốn,startup pitch|en=startup pitch`},
		{"STARTUP2_PRODUCT",     3,`label=quản lý sản phẩm|desc=product management PM roadmap OKR user story sprint backlog prioritization RICE framework discovery delivery|vi=quản lý sản phẩm,product management|en=product management`},
		{"LEADERSHIP_SERVANT",   3,`label=lãnh đạo phụng sự|desc=servant leadership Greenleaf listening empathy healing awareness persuasion community foresight stewardship growth|vi=lãnh đạo phụng sự,servant leadership|en=servant leadership`},
		{"LEADERSHIP_TRANSFOR",  3,`label=lãnh đạo chuyển đổi|desc=transformational leadership Burns Bass idealized influence inspirational motivation intellectual stimulation individual consideration|vi=lãnh đạo chuyển đổi,transformational leadership|en=transformational leadership`},

		// ── MANAGEMENT & CONSULTING ──────────────────────────────────
		{"MANAGEMENT_OKR",       3,`label=OKR và quản lý mục tiêu|desc=OKR objectives key results Intel Google Measure What Matters Doerr committed aspirational CFR check-in|vi=OKR và quản lý mục tiêu,OKR|en=OKR`},
		{"MANAGEMENT_AGILE",     3,`label=quản lý Agile|desc=Agile manifesto Scrum Kanban sprint retrospective velocity definition of done SAFe LeSS scaling enterprise|vi=quản lý Agile,Agile management|en=Agile management`},
		{"MANAGEMENT_CHANGE",    3,`label=quản lý thay đổi|desc=change management Kotter 8 steps ADKAR Lewin unfreeze change refreeze resistance coalition vision communicate|vi=quản lý thay đổi,change management|en=change management`},
		{"CONSULTING_FRAMEWORK", 3,`label=framework tư vấn|desc=consulting framework McKinsey MECE pyramid principle issue tree hypothesis driven structured problem solving|vi=framework tư vấn,consulting framework|en=consulting framework`},
		{"NONPROFIT_IMPACT",     3,`label=tổ chức phi lợi nhuận|desc=nonprofit impact measurement theory of change logic model SROI social return evidence-based philanthropic|vi=tổ chức phi lợi nhuận,nonprofit impact|en=nonprofit impact`},

		// ── PREVENTIVE & PRECISION MEDICINE ──────────────────────────
		{"PREVENTIVE_SCREEN",    3,`label=tầm soát và phòng ngừa|desc=screening cancer mammography colonoscopy PSA USPSTF NNS lead time bias overdiagnosis risk stratification|vi=tầm soát và phòng ngừa,screening prevention|en=screening prevention`},
		{"PREVENTIVE_LIFESTYLE", 3,`label=y học lối sống|desc=lifestyle medicine physical activity diet sleep stress social connection tobacco Mediterranean DASH MIND blue zone|vi=y học lối sống,lifestyle medicine|en=lifestyle medicine`},
		{"NUTRITION2_GUT",       3,`label=dinh dưỡng và hệ vi sinh|desc=gut microbiome diet fiber fermented food diversity short chain fatty acid SCFA akkermansia bacteroidetes firmicutes|vi=dinh dưỡng và hệ vi sinh,nutrition gut microbiome|en=nutrition gut microbiome`},
		{"ECOLOGY3_RESTORATION", 3,`label=phục hồi sinh thái|desc=ecological restoration Rewilding Europe prairie wolf reintroduction seed bank assisted migration succession pioneer|vi=phục hồi sinh thái,ecological restoration|en=ecological restoration`},
		{"BIODIV2_HOTSPOT",      3,`label=điểm nóng đa dạng sinh học|desc=biodiversity hotspot Myers 36 hotspots endemic species threat loss priority conservation investment effort|vi=điểm nóng đa dạng sinh học,biodiversity hotspot|en=biodiversity hotspot`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 4100 { fmt.Println(" MILESTONE 4100! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
