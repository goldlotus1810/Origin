//go:build ignore
// seed_milestone5000.go — MILESTONE 5000 — 100 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── PHILOSOPHY 5 ─────────────────────────────────────────────
		{"PHILOSOPHY5_AESTHETICS",3,`label=mỹ học triết học|desc=aesthetics philosophy beauty sublime Kant Critique Judgment Hegel art Danto artworld institutional theory|vi=mỹ học triết học,aesthetics philosophy|en=aesthetics philosophy`},
		{"PHILOSOPHY5_RHETORIC",  3,`label=tu từ học|desc=rhetoric Aristotle ethos pathos logos epideictic deliberative forensic enthymeme Burke identification|vi=tu từ học,rhetoric|en=rhetoric`},
		{"PHILOSOPHY5_HERMENEU",  3,`label=thông diễn học|desc=hermeneutics Gadamer Ricoeur understanding interpretation text meaning horizon fusion Schleiermacher|vi=thông diễn học,hermeneutics|en=hermeneutics`},
		{"PHILOSOPHY5_CRITICAL",  3,`label=lý thuyết phê bình|desc=critical theory Frankfurt School Adorno Horkheimer Habermas communicative rationality domination emancipation|vi=lý thuyết phê bình,critical theory|en=critical theory`},
		{"PHILOSOPHY5_SOCIAL",    3,`label=triết học xã hội|desc=social philosophy recognition Hegel Honneth struggle Fraser redistribution power Foucault genealogy|vi=triết học xã hội,social philosophy|en=social philosophy`},

		// ── MILITARY & STRATEGY ───────────────────────────────────────
		{"MILITARY_STRATEGY",    3,`label=chiến lược quân sự|desc=military strategy Clausewitz war politics means end trinity Sun Tzu maneuver attrition center gravity|vi=chiến lược quân sự,military strategy|en=military strategy`},
		{"MILITARY_TECHNOLOGY",  3,`label=công nghệ quân sự|desc=military technology drone swarm loitering munition hypersonic ASAT EW electronic warfare C4ISR|vi=công nghệ quân sự,military technology|en=military technology`},
		{"MILITARY_HYBRID",      3,`label=chiến tranh hỗn hợp|desc=hybrid warfare grey zone information disinformation cyber proxy irregular conventional below threshold|vi=chiến tranh hỗn hợp,hybrid warfare|en=hybrid warfare`},
		{"STRATEGY_GRAND",       3,`label=đại chiến lược|desc=grand strategy national interest resources statecraft Liddell Hart ends ways means resource constraint|vi=đại chiến lược,grand strategy|en=grand strategy`},
		{"INTELLIGENCE_ANALYSIS",3,`label=phân tích tình báo|desc=intelligence analysis OSINT HUMINT SIGINT collection processing all-source analytic failure bias|vi=phân tích tình báo,intelligence analysis|en=intelligence analysis`},

		// ── SECURITY STUDIES ──────────────────────────────────────────
		{"SECURITY_NUCLEAR",     3,`label=an ninh hạt nhân|desc=nuclear security deterrence MAD extended deterrence first strike stability arms control NPT TPNW|vi=an ninh hạt nhân,nuclear security|en=nuclear security`},
		{"SECURITY_MARITIME",    3,`label=an ninh hàng hải|desc=maritime security SLOC choke point piracy Gulf of Aden Malacca Strait UNCLOS freedom navigation|vi=an ninh hàng hải,maritime security|en=maritime security`},
		{"SECURITY_CYBER2",      3,`label=an ninh mạng chiến lược|desc=cyber security strategy nation-state APT critical infrastructure ransomware attribution Five Eyes|vi=an ninh mạng chiến lược,cyber security strategy|en=cyber security strategy`},
		{"SECURITY_SPACE",       3,`label=an ninh vũ trụ|desc=space security anti-satellite ASAT debris collision avoidance SSA situational awareness dual-use|vi=an ninh vũ trụ,space security|en=space security`},
		{"INTELLIGENCE_COVERT",  3,`label=hành động bí mật|desc=covert action paramilitary propaganda influence operation plausible deniability oversight accountability|vi=hành động bí mật,covert action|en=covert action`},

		// ── OCEAN 5 ───────────────────────────────────────────────────
		{"OCEAN5_DEEP",          3,`label=vùng biển sâu|desc=deep sea hadal zone Mariana Trench pressure extremophile hydrothermal vent chemosynthesis bioluminescence|vi=vùng biển sâu,deep sea|en=deep sea`},
		{"OCEAN5_CURRENT",       3,`label=dòng hải lưu|desc=ocean current thermohaline AMOC Gulf Stream ENSO PDO upwelling downwelling gyre subtropical|vi=dòng hải lưu,ocean current|en=ocean current`},
		{"OCEAN5_ACIDIFICATION", 3,`label=axit hóa đại dương|desc=ocean acidification pH carbonate saturation aragonite pteropod coral dissolution shellfish aquaculture|vi=axit hóa đại dương,ocean acidification|en=ocean acidification`},
		{"OCEAN5_BIODIVERSITY",  3,`label=đa dạng sinh học biển|desc=marine biodiversity hotspot seamount kelp forest mangrove seagrass whale migration critical habitat|vi=đa dạng sinh học biển,marine biodiversity|en=marine biodiversity`},
		{"OCEAN5_GOVERNANCE",    3,`label=quản trị đại dương|desc=ocean governance BBNJ high seas treaty ISA seabed mining EEZ flag state ITLOS dispute|vi=quản trị đại dương,ocean governance|en=ocean governance`},

		// ── ARCTIC & POLAR ────────────────────────────────────────────
		{"ARCTIC_GEOPOLIT",      3,`label=địa chính trị Bắc Cực|desc=Arctic geopolitics Arctic Council Russia Norway Canada Iceland Northwest Passage Northern Sea Route|vi=địa chính trị Bắc Cực,Arctic geopolitics|en=Arctic geopolitics`},
		{"ARCTIC_CLIMATE",       3,`label=biến đổi khí hậu Bắc Cực|desc=Arctic climate warming amplification sea ice loss albedo feedback permafrost methane thermokarst|vi=biến đổi khí hậu Bắc Cực,Arctic climate|en=Arctic climate`},
		{"PERMAFROST_THAW",      3,`label=băng vĩnh cửu tan chảy|desc=permafrost thaw carbon methane feedback Siberia Alaska Canada thermokarst lake subsidence infrastructure|vi=băng vĩnh cửu tan chảy,permafrost thaw|en=permafrost thaw`},
		{"TUNDRA_ECOLOGY",       3,`label=hệ sinh thái đài nguyên|desc=tundra ecology caribou reindeer lemming ptarmigan phenology mismatch shrub encroachment greening|vi=hệ sinh thái đài nguyên,tundra ecology|en=tundra ecology`},
		{"SAVANNA2_FIRE",        3,`label=lửa và thảo nguyên|desc=savanna fire ecology pyrogeography C4 grass feedback tree grass coexistence cerrado Miombo|vi=lửa và thảo nguyên,savanna fire|en=savanna fire`},

		// ── HUMANITIES EXTENSION ──────────────────────────────────────
		{"HISTORIOGRAPH",        3,`label=sử học phương pháp luận|desc=historiography method primary source oral history microhistory Annales school longue durée|vi=sử học phương pháp luận,historiography|en=historiography`},
		{"LITERARY_THEORY2",     3,`label=lý thuyết văn học nâng cao|desc=literary theory reader response Iser Fish deconstruction Derrida postcolonial Spivak subaltern|vi=lý thuyết văn học nâng cao,literary theory|en=literary theory`},
		{"CULTURAL_STUDIES2",    3,`label=nghiên cứu văn hóa|desc=cultural studies Birmingham CCCS Hall encoding decoding hegemony Gramsci subculture resistance|vi=nghiên cứu văn hóa,cultural studies|en=cultural studies`},
		{"MEMORY_STUDIES",       3,`label=nghiên cứu ký ức|desc=memory studies collective memory Halbwachs lieux de mémoire Nora Holocaust trauma testimony witnessing|vi=nghiên cứu ký ức,memory studies|en=memory studies`},
		{"SCIENCE_TECHNOLOGY",   3,`label=nghiên cứu khoa học công nghệ|desc=STS science technology society Latour actor-network constructivism Kuhn lab ethnography|vi=nghiên cứu khoa học công nghệ,science technology studies|en=science technology studies`},

		// ── APPLIED MATH EXTENSION ────────────────────────────────────
		{"GAME_THEORY2",         3,`label=lý thuyết trò chơi nâng cao|desc=game theory mechanism design revelation principle VCG auction Myerson optimal bargaining|vi=lý thuyết trò chơi nâng cao,game theory mechanism design|en=game theory mechanism design`},
		{"INFORMATION_GEOMETRY", 3,`label=hình học thông tin|desc=information geometry Amari Fisher-Rao metric statistical manifold exponential family natural gradient|vi=hình học thông tin,information geometry|en=information geometry`},
		{"ALGEBRAIC_TOPOLOGY2",  3,`label=topo đại số nâng cao|desc=algebraic topology homology cohomology cup product Poincaré duality Morse theory CW complex|vi=topo đại số nâng cao,algebraic topology|en=algebraic topology`},
		{"COMBINATORICS2",       3,`label=tổ hợp nâng cao|desc=combinatorics generating function Polya enumeration Ramsey extremal probabilistic method Lovász|vi=tổ hợp nâng cao,combinatorics|en=combinatorics`},
		{"ABSTRACT_ALGEBRA2",    3,`label=đại số trừu tượng nâng cao|desc=abstract algebra Galois theory field extension splitting solvability group representation character|vi=đại số trừu tượng nâng cao,abstract algebra|en=abstract algebra`},

		// ── VIETNAM SPECIAL ───────────────────────────────────────────
		{"VNMILITARY_HISTORY",   3,`label=lịch sử quân sự Việt Nam|desc=lịch sử quân sự Việt Nam chiến tranh nhân dân Điện Biên Phủ Tổng tấn công Mậu Thân nghệ thuật quân sự|vi=lịch sử quân sự Việt Nam,Vietnam military history|en=Vietnam military history`},
		{"VNMILITARY_MODERN",    3,`label=quốc phòng Việt Nam hiện đại|desc=quốc phòng Việt Nam ba không chính sách quốc phòng toàn dân hiện đại hóa quân đội Biển Đông|vi=quốc phòng Việt Nam hiện đại,Vietnam modern defense|en=Vietnam modern defense`},
		{"VNPHILOSOPHY",         3,`label=triết học Việt Nam|desc=triết học Việt Nam tư tưởng Hồ Chí Minh Nho giáo Phật giáo bản địa chủ nghĩa Marx-Lenin vận dụng|vi=triết học Việt Nam,Vietnamese philosophy|en=Vietnamese philosophy`},
		{"VNLITERATURE3",        3,`label=văn học Việt Nam thế kỷ 20|desc=văn học Việt Nam thế kỷ 20 Nam Quốc Sơn Hà Truyện Kiều hiện đại Tự Lực Văn Đoàn kháng chiến đổi mới|vi=văn học Việt Nam thế kỷ 20,20th century Vietnamese literature|en=20th century Vietnamese literature`},
		{"VNCULTURE_IDENTITY",   3,`label=bản sắc văn hóa Việt Nam|desc=bản sắc văn hóa Việt Nam toàn cầu hóa giữ gìn bản sắc tiếng Việt Tết lễ hội truyền thống hiện đại hóa|vi=bản sắc văn hóa Việt Nam,Vietnamese cultural identity|en=Vietnamese cultural identity`},

		// ── BIOSYSTEMS & ECOLOGY EXT ──────────────────────────────────
		{"MARINE_ECOLOGY2",      3,`label=sinh thái biển nâng cao|desc=marine ecology food web trophic cascade keystone top-down bottom-up regime shift resilience|vi=sinh thái biển nâng cao,marine ecology|en=marine ecology`},
		{"TERRESTRIAL_ECOLOGY",  3,`label=sinh thái trên cạn|desc=terrestrial ecology NPP gross primary productivity respiration carbon use efficiency biome transition|vi=sinh thái trên cạn,terrestrial ecology|en=terrestrial ecology`},
		{"BIODIVERSITY_LOSS",    3,`label=mất đa dạng sinh học|desc=biodiversity loss sixth extinction IPBES habitat fragmentation invasive species wildlife trade|vi=mất đa dạng sinh học,biodiversity loss|en=biodiversity loss`},
		{"ECOSYSTEM_SERVICE",    3,`label=dịch vụ hệ sinh thái|desc=ecosystem service provisioning regulating cultural supporting TEEB natural capital valuation payment|vi=dịch vụ hệ sinh thái,ecosystem service|en=ecosystem service`},
		{"ONE_HEALTH",           3,`label=Một sức khỏe|desc=One Health zoonosis spillover wildlife-livestock-human interface EcoHealth planetary health AMR|vi=Một sức khỏe,One Health|en=One Health`},

		// ── SOCIAL SCIENCE EXT ────────────────────────────────────────
		{"SOCIAL_CAPITAL",       3,`label=vốn xã hội|desc=social capital Putnam Bourdieu bridging bonding trust networks reciprocity civic engagement decline bowling|vi=vốn xã hội,social capital|en=social capital`},
		{"INSTITUTIONAL_ECON2",  3,`label=kinh tế học thể chế nâng cao|desc=institutional economics Ostrom commons CPR polycentric governance Williamson transaction cost|vi=kinh tế học thể chế nâng cao,institutional economics|en=institutional economics`},
		{"POLITICAL_ECONOMY2",   3,`label=kinh tế chính trị học nâng cao|desc=political economy capitalism varieties state market Marx Weber Polanyi great transformation|vi=kinh tế chính trị học nâng cao,political economy|en=political economy`},
		{"COMPARATIVE_POLITICS2",3,`label=chính trị học so sánh nâng cao|desc=comparative politics democratization backsliding competitive authoritarianism hybrid regime Levitsky|vi=chính trị học so sánh nâng cao,comparative politics|en=comparative politics`},
		{"INTERNATIONAL_RELATIONS2",3,`label=quan hệ quốc tế nâng cao|desc=IR theory liberal institutionalism constructivism norm diffusion Wendt Finnemore security community|vi=quan hệ quốc tế nâng cao,international relations|en=international relations`},

		// ── TECHNOLOGY EXTENSION ──────────────────────────────────────
		{"QUANTUM3_NETWORK",     3,`label=mạng lượng tử|desc=quantum network entanglement distribution quantum repeater memory Bell pair satellite Micius Delft|vi=mạng lượng tử,quantum network|en=quantum network`},
		{"BIOTECH2_SYNTHETIC",   3,`label=sinh học tổng hợp|desc=synthetic biology BioBrick iGEM metabolic engineering yeast production artemisinin insulin spider silk|vi=sinh học tổng hợp,synthetic biology|en=synthetic biology`},
		{"BIOTECH2_CELL_THERAPY",3,`label=liệu pháp tế bào|desc=cell therapy iPSC induced pluripotent stem NK cell therapy TIL tumor infiltrating allogeneic off-shelf|vi=liệu pháp tế bào,cell therapy|en=cell therapy`},
		{"MATERIALS3_2D",        3,`label=vật liệu 2D|desc=2D materials graphene MoS2 hBN TMD van der Waals heterostructure twist angle moiré superconductor|vi=vật liệu 2D,2D materials|en=2D materials`},
		{"ROBOTICS3_SOFT",       3,`label=robot mềm|desc=soft robotics silicone pneumatic actuator continuum origami bio-inspired compliant mechanism gripper|vi=robot mềm,soft robotics|en=soft robotics`},

		// ── MISC / BRIDGE NODES ───────────────────────────────────────
		{"AI_ALIGNMENT2",        3,`label=căn chỉnh AI nâng cao|desc=AI alignment scalable oversight debate amplification recursive reward modeling interpretability mech interp|vi=căn chỉnh AI nâng cao,AI alignment|en=AI alignment`},
		{"PHILOSOPHY5_DEATH",    3,`label=triết học về cái chết|desc=death philosophy Epicurus fear nothing Heidegger being-towards-death Nagel what is it like Tolstoy|vi=triết học về cái chết,philosophy of death|en=philosophy of death`},
		{"MILITARY_ETHICS",      3,`label=đạo đức quân sự|desc=military ethics just war theory jus ad bellum jus in bello proportionality discrimination LOAC IHL|vi=đạo đức quân sự,military ethics|en=military ethics`},
		{"OCEAN5_PLASTIC",       3,`label=ô nhiễm nhựa đại dương|desc=ocean plastic microplastic Great Pacific Patch HDPE PET marine ingestion food chain human health|vi=ô nhiễm nhựa đại dương,ocean plastic|en=ocean plastic`},
		{"ARCTIC_RESOURCE",      3,`label=tài nguyên Bắc Cực|desc=Arctic resources oil gas Barents Kara rare earth minerals shelf claim extended continental seabed|vi=tài nguyên Bắc Cực,Arctic resources|en=Arctic resources`},
		{"HISTORIOGRAPH_VIET",   3,`label=sử học Việt Nam|desc=sử học Việt Nam Đại Việt Sử Ký Toàn Thư phương pháp lịch sử tân sử học bản địa hóa|vi=sử học Việt Nam,Vietnamese historiography|en=Vietnamese historiography`},
		{"MEMORY_VIET",          3,`label=ký ức chiến tranh Việt Nam|desc=ký ức chiến tranh Việt Nam hòa giải hai miền di tích lịch sử bảo tàng thế hệ sau Agent Orange|vi=ký ức chiến tranh Việt Nam,Vietnam war memory|en=Vietnam war memory`},
		{"GAME_THEORY_COOPERATE",3,`label=hợp tác trong lý thuyết trò chơi|desc=cooperative game theory Shapley value core TU non-TU coalition formation Nash bargaining|vi=hợp tác trong lý thuyết trò chơi,cooperative game theory|en=cooperative game theory`},
		{"INFORMATION_GEOMETRY2",3,`label=học máy và hình học thông tin|desc=information geometry machine learning natural gradient Adam Fisher neural tangent kernel|vi=học máy và hình học thông tin,information geometry ML|en=information geometry ML`},
		{"BIOTECH2_DIAGNOSTICS", 3,`label=chẩn đoán sinh học phân tử|desc=molecular diagnostics PCR NGS CRISPR Cas12 Cas13 lateral flow ddPCR point-of-care LDT|vi=chẩn đoán sinh học phân tử,molecular diagnostics|en=molecular diagnostics`},
		{"SOCIAL_MOVEMENT",      3,`label=phong trào xã hội|desc=social movement framing resource mobilization political opportunity structure McAdam Tarrow repertoire|vi=phong trào xã hội,social movement|en=social movement`},
		{"COMPARATIVE_WELFARE",  3,`label=so sánh nhà nước phúc lợi|desc=welfare state Esping-Andersen three worlds liberal conservative social-democratic power resources|vi=so sánh nhà nước phúc lợi,welfare state|en=welfare state`},
		{"AI_MULTIMODAL",        3,`label=AI đa phương thức|desc=multimodal AI vision language audio GPT-4V Gemini CLIP DALL-E alignment benchmark evaluation|vi=AI đa phương thức,multimodal AI|en=multimodal AI`},
		{"QUANTUM3_ERROR",       3,`label=sửa lỗi lượng tử|desc=quantum error correction surface code logical qubit threshold fault-tolerant threshold syndrome measurement|vi=sửa lỗi lượng tử,quantum error correction|en=quantum error correction`},
		{"ROBOTICS3_LEARNING",   3,`label=robot học tăng cường|desc=robot reinforcement learning sim-to-real domain randomization dexterous manipulation foundation policy|vi=robot học tăng cường,robot reinforcement learning|en=robot reinforcement learning`},
		{"TERRESTRIAL_CARBON",   3,`label=chu trình carbon trên cạn|desc=terrestrial carbon cycle NEP net ecosystem production soil respiration litter decomposition fire disturbance|vi=chu trình carbon trên cạn,terrestrial carbon cycle|en=terrestrial carbon cycle`},
		{"ONE_HEALTH_VIET",      3,`label=Một sức khỏe tại Việt Nam|desc=One Health Việt Nam cúm gia cầm H5N1 ASF lợn dịch tả sốt xuất huyết năng lực thú y|vi=Một sức khỏe tại Việt Nam,Vietnam One Health|en=Vietnam One Health`},
		{"POLITICAL_ECONOMY_VIET",3,`label=kinh tế chính trị Việt Nam|desc=kinh tế chính trị Việt Nam nhà nước phát triển doanh nghiệp nhà nước tư nhân hóa thể chế đảng|vi=kinh tế chính trị Việt Nam,Vietnam political economy|en=Vietnam political economy`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 5000 { fmt.Println(" MILESTONE 5000! 🎉🎉🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
