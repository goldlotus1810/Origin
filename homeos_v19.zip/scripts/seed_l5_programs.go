//go:build ignore

// scripts/seed_l5_programs.go
//
// Seed L5 Program nodes vào homeos.olang.
// L5 = Programs — phần mềm, AI, giao thức, hệ điều hành
//
// Theo kiến trúc:
//   L0 Primitive · L1 UTF-32 · L2 Nature · L3 Life
//   L4 Objects   · L5 Programs · L6 Perception · L7 Runtime
//
// Chạy: go run scripts/seed_l5_programs.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const l5Path = "homeos.olang"

type l5Def struct {
	name  string
	label string
	desc  string
	vi    string
}

var l5Defs = []l5Def{
	// ── AI / ML ──────────────────────────────────────────────────
	{"PROG_LLM",       "mô hình ngôn ngữ lớn", "neural network có hàng tỷ tham số dự đoán token tiếp theo",  "llm,large language model,gpt,claude"},
	{"PROG_NEURAL_NET","mạng nơ-ron",           "kiến trúc tính toán mô phỏng não với các lớp nơ-ron kết nối","neural network,deep learning,ann"},
	{"PROG_TRAINING",  "huấn luyện mô hình",   "quá trình tối ưu hóa tham số qua gradient descent",          "training,học máy,machine learning"},
	{"PROG_INFERENCE",  "suy luận",             "chạy mô hình đã huấn luyện trên dữ liệu mới",               "inference,dự đoán,prediction"},
	{"PROG_EMBEDDING", "embedding",             "biểu diễn ý nghĩa ngữ nghĩa bằng vector số thực",           "vector,representation,mã hóa"},
	{"PROG_ATTENTION", "attention",             "cơ chế chú ý trong transformer đo độ liên quan token",       "self-attention,transformer"},
	{"PROG_AGENT",     "agent",                 "thực thể tự trị nhận thức môi trường và hành động có mục tiêu","tác nhân,autonomous agent"},
	{"PROG_MEMORY",    "bộ nhớ",               "lưu trữ và truy xuất thông tin ngắn hạn hoặc dài hạn",       "memory,context,lưu trữ"},
	{"PROG_SKILL",     "kỹ năng",              "một năng lực cụ thể một trách nhiệm duy nhất của agent",      "skill,capability,khả năng"},
	{"PROG_PROMPT",    "prompt",               "văn bản hướng dẫn đầu vào cho mô hình ngôn ngữ",             "lệnh,instruction,context window"},
	// ── HomeOS ───────────────────────────────────────────────────
	{"PROG_HOMEOS",    "HomeOS",               "hệ điều hành thông minh học theo vòng đời tri thức QT1-QT7",  "home os,hệ thống nhà thông minh"},
	{"PROG_ISL",       "ISL",                  "ngôn ngữ tín hiệu nội tại 64-bit nhị phân bảo mật AES-256",  "internal signal language,isl,64bit"},
	{"PROG_SILK",      "Silk Tree",            "đồ thị tri thức append-only ED25519 từ ĐN lên QR",           "silk,knowledge tree,web tree"},
	{"PROG_NCA",       "NCA",                  "kiến trúc vỏ não thần kinh Soma+Dendrites+Axon học liên tục", "neural cortex,nca,leoai"},
	{"PROG_SDF",       "SDF",                  "hàm khoảng cách có dấu mô tả hình học bằng công thức",       "signed distance function,raymarching"},
	{"PROG_OLANG",     "Olang",               "ngôn ngữ lập trình cho SDF/gene/agent chạy trong HomeOS",     "olang,o-lang,bytecode"},
	// ── Hệ điều hành / Protocol ──────────────────────────────────
	{"PROG_OS",        "hệ điều hành",         "phần mềm quản lý tài nguyên phần cứng và cung cấp dịch vụ",  "operating system,os,kernel"},
	{"PROG_NETWORK",   "mạng máy tính",        "hệ thống kết nối thiết bị trao đổi dữ liệu qua giao thức",   "network,mạng,internet,tcp/ip"},
	{"PROG_ALGORITHM", "thuật toán",           "tập hợp bước hữu hạn để giải quyết bài toán",                "algorithm,giải thuật"},
	{"PROG_DATABASE",  "cơ sở dữ liệu",        "hệ thống lưu trữ và truy vấn dữ liệu có cấu trúc",           "database,db,sql,nosql"},
	{"PROG_API",       "giao diện lập trình",  "hợp đồng kết nối phần mềm qua HTTP/REST/JSON",               "api,rest,endpoint,interface"},
	{"PROG_ENCRYPT",   "mã hóa",              "biến đổi dữ liệu để chỉ người có khóa mới đọc được",         "encryption,aes,ed25519,mật mã"},
	{"PROG_COMPILE",   "biên dịch",           "chuyển mã nguồn thành bytecode hoặc mã máy",                  "compile,build,bytecode,compiler"},
	{"PROG_SENSOR",    "cảm biến phần mềm",   "thu thập dữ liệu từ môi trường qua giao diện phần mềm",       "software sensor,iot,mqtt"},
}

func main() {
	if _, err := os.Stat(l5Path); err != nil {
		log.Fatalf("không tìm thấy %s", l5Path)
	}
	existing := l5LoadNames(l5Path)
	fmt.Printf("Existing nodes: %d\n", len(existing))

	added, skipped := 0, 0
	for _, d := range l5Defs {
		if existing[d.name] {
			fmt.Printf("  SKIP %-25s\n", d.name)
			skipped++
			continue
		}
		dna := "label=" + d.label + "|desc=" + d.desc
		if d.vi != "" { dna += "|vi=" + d.vi }
		isl := l5ISL(d.name)
		if err := l5Append(l5Path, 5, isl, []byte(dna), d.name); err != nil {
			fmt.Printf("  ERR  %-25s %v\n", d.name, err)
		} else {
			fmt.Printf("  +L5  %-25s %s\n", d.name, d.label)
			added++
		}
	}
	fmt.Printf("\n✅ seed_l5_programs: +%d nodes, %d skip\n", added, skipped)
}

func l5LoadNames(path string) map[string]bool {
	raw, err := os.ReadFile(path)
	if err != nil { return nil }
	out := map[string]bool{}
	const idx = 64 + 9*24
	for i := idx; i+20 < len(raw); {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		ns := i + 20 + dl
		ne := ns + nl
		if ne > len(raw) { break }
		out[string(raw[ns:ne])] = true
		i = ne
	}
	return out
}

func l5ISL(name string) [8]byte {
	h := sha256.Sum256([]byte(name))
	return [8]byte{5, h[0]%200 + 1, h[1]%200 + 1, h[2]%200 + 1, h[3], h[4], h[5], h[6]}
}

func l5Append(filePath string, layer uint8, islB [8]byte, dna []byte, name string) error {
	raw, err := os.ReadFile(filePath)
	if err != nil { return err }

	const (hdr = 64; ent = 24; nls = 9; idx = hdr + nls*ent)
	if len(raw) < idx || string(raw[0:4]) != "OLNG" { return fmt.Errorf("bad file") }

	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }

	// Check duplicate
	for i := idx; i+20 < len(raw); {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		ns := i + 20 + dl
		ne := ns + nl
		if ne > len(raw) { break }
		if string(raw[ns:ne]) == name { return fmt.Errorf("dup: %s", name) }
		i = ne
	}

	rec := make([]byte, 2+1+8+4+4+1+len(dna)+len(nb))
	p := 0
	rec[p] = 'N'; p++; rec[p] = 'D'; p++; rec[p] = layer; p++
	copy(rec[p:], islB[:]); p += 8
	binary.BigEndian.PutUint32(rec[p:], 0); p += 4
	binary.BigEndian.PutUint32(rec[p:], uint32(len(dna))); p += 4
	rec[p] = uint8(len(nb)); p++
	copy(rec[p:], dna); p += len(dna)
	copy(rec[p:], nb)

	type li struct{ off, sz uint64; nn uint32 }
	ls := [nls]li{}
	for i := 0; i < nls; i++ {
		o := hdr + i*ent
		ls[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		ls[i].sz  = binary.BigEndian.Uint64(raw[o+12 : o+20])
		ls[i].nn  = binary.BigEndian.Uint32(raw[o+20 : o+24])
	}

	tgt := int(layer)
	var ins uint64
	if ls[tgt].sz > 0 {
		ins = ls[tgt].off + ls[tgt].sz
	} else {
		ins = uint64(idx)
		for i := tgt - 1; i >= 0; i-- {
			if ls[i].sz > 0 { ins = ls[i].off + ls[i].sz; break }
		}
	}

	out := append(append([]byte{}, raw[:ins]...), append(rec, raw[ins:]...)...)

	if ls[tgt].sz == 0 { binary.BigEndian.PutUint64(out[hdr+tgt*ent+4:], ins) }
	binary.BigEndian.PutUint64(out[hdr+tgt*ent+12:], ls[tgt].sz+uint64(len(rec)))
	binary.BigEndian.PutUint32(out[hdr+tgt*ent+20:], ls[tgt].nn+1)
	for i := tgt + 1; i < nls; i++ {
		if ls[i].sz > 0 {
			o := hdr + i*ent
			off := binary.BigEndian.Uint64(out[o+4:])
			binary.BigEndian.PutUint64(out[o+4:], off+uint64(len(rec)))
		}
	}

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return err }
	return os.Rename(tmp, filePath)
}
