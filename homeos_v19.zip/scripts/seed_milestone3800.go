//go:build ignore
// seed_milestone3800.go — MILESTONE 3800 — 100 nodes
// Domains: ASTRO2_ QUANTUM2_ THERMO2_ OPTICS_ FLUID_
//          ANTHRO_ ARCHAEO_ DEMOGR_ MIGRATION_ GENDER_
//          PSYCH3_ BEHAV_ ADDIC_ TRAUMA_ WELLBEING_
//          AGRI2_ AQUA_ BIOTECH2_ PHARMA2_ NANOTECH_
//          VNGEOG_ VNETHNIC_ VNINNOVATE_ VNSOCIETY_ VNCLIMATE_
//          ART2_ FILM2_ GAME3_ SPORT5_ CULINARY2_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct { name string; layer uint8; dna string }
	nodes := []nd{

		// ── ASTRONOMY 2 (ASTRO2_) ────────────────────────────────────
		{"ASTRO2_NEUTRON_STAR",  3,`label=sao neutron|desc=neutron star remnant core collapse supernova 1.4 Msun radius 10km pulsars magnetars rotation period glitch|vi=sao neutron,neutron star|en=neutron star`},
		{"ASTRO2_SUPERNOVA",     3,`label=siêu tân tinh|desc=supernova Type Ia Ia thermonuclear Type II core collapse SN1987A Chandrasekhar limit heavy element nucleosynthesis|vi=siêu tân tinh,supernova|en=supernova`},
		{"ASTRO2_GALAXY",        3,`label=thiên hà|desc=galaxy Milky Way spiral elliptical irregular Hubble sequence dark matter halo local group supercluster cosmic web|vi=thiên hà,galaxy|en=galaxy`},
		{"ASTRO2_COSMOLOGY",     3,`label=vũ trụ học|desc=cosmology Big Bang CMB Planck inflation Lambda-CDM dark energy 68% accelerating expansion Hubble tension|vi=vũ trụ học,cosmology|en=cosmology`},
		{"ASTRO2_TELESCOPE",     3,`label=kính thiên văn|desc=telescope JWST Hubble ELT radio VLA interferometry adaptive optics diffraction limit angular resolution|vi=kính thiên văn,telescope|en=telescope`},

		// ── QUANTUM 2 (QUANTUM2_) ─────────────────────────────────────
		{"QUANTUM2_FIELD",       3,`label=lý thuyết trường lượng tử|desc=quantum field theory QED QCD Standard Model virtual particle vacuum fluctuation renormalization Feynman diagram|vi=lý thuyết trường lượng tử,QFT|en=quantum field theory`},
		{"QUANTUM2_SPIN",        3,`label=spin lượng tử|desc=quantum spin half-integer Pauli matrices Stern-Gerlach spinor SU(2) singlet triplet spin-orbit coupling|vi=spin lượng tử,quantum spin|en=quantum spin`},
		{"QUANTUM2_OPTICS",      3,`label=quang học lượng tử|desc=quantum optics photon Fock state coherent squeezed Hong-Ou-Mandel laser cavity QED single photon detector|vi=quang học lượng tử,quantum optics|en=quantum optics`},
		{"QUANTUM2_SENSING",     3,`label=cảm biến lượng tử|desc=quantum sensing atomic clock magnetometer gravimeter NV center diamond GPS timing navigation beyond standard limit|vi=cảm biến lượng tử,quantum sensing|en=quantum sensing`},
		{"QUANTUM2_CRYPTO",      3,`label=mật mã lượng tử|desc=quantum cryptography BB84 QKD E91 quantum key distribution eavesdrop detection no-cloning theorem unconditional security|vi=mật mã lượng tử,quantum cryptography|en=quantum cryptography`},

		// ── OPTICS (OPTICS_) ─────────────────────────────────────────
		{"OPTICS_DIFFRACTION",   3,`label=nhiễu xạ ánh sáng|desc=diffraction Huygens principle single double slit Young experiment wavelength grating spectroscopy X-ray crystal|vi=nhiễu xạ ánh sáng,diffraction|en=diffraction`},
		{"OPTICS_FIBER",         3,`label=cáp quang|desc=fiber optics total internal reflection single multi mode graded index attenuation DWDM WDM bandwidth internet backbone|vi=cáp quang,fiber optics|en=fiber optics`},
		{"OPTICS_LASER",         3,`label=laser|desc=laser light amplification stimulated emission population inversion cavity modes Nd:YAG CO2 diode LIDAR surgery cutting|vi=laser,laser|en=laser`},
		{"OPTICS_HOLOGRAPHY",    3,`label=toàn ký|desc=holography coherent light interference pattern reconstruct 3D Gabor Nobel 1971 data storage security display|vi=toàn ký,holography|en=holography`},
		{"OPTICS_METAMATERIAL",  3,`label=siêu vật liệu quang|desc=metamaterial negative refractive index perfect lens superlens cloaking transformation optics left-handed material|vi=siêu vật liệu quang,metamaterial|en=metamaterial`},

		// ── FLUID DYNAMICS (FLUID_) ──────────────────────────────────
		{"FLUID_TURBULENCE",     3,`label=chảy rối|desc=turbulence Reynolds number Kolmogorov cascade energy spectrum DNS LES RANS Navier-Stokes unsolved Millennium Prize|vi=chảy rối,turbulence|en=turbulence`},
		{"FLUID_AERODYNAMICS",   3,`label=khí động học|desc=aerodynamics lift drag Bernoulli Coanda boundary layer laminar turbulent stall airfoil NACA CFD simulation|vi=khí động học,aerodynamics|en=aerodynamics`},
		{"FLUID_MICROFLUIDICS",  3,`label=vi lưu chất|desc=microfluidics lab-on-chip PDMS droplet organ-on-chip DNA sequencing blood diagnostics capillary electrophoresis|vi=vi lưu chất,microfluidics|en=microfluidics`},
		{"FLUID_MAGNETO",        3,`label=từ thủy động lực|desc=magnetohydrodynamics MHD plasma tokamak solar wind geodynamo Hall thruster liquid metal cooling|vi=từ thủy động lực,MHD|en=magnetohydrodynamics`},
		{"FLUID_RHEOLOGY",       3,`label=lưu biến học|desc=rheology non-Newtonian fluid shear thinning thickening viscoelastic yield stress ketchup oobleck polymer melt|vi=lưu biến học,rheology|en=rheology`},

		// ── ANTHROPOLOGY (ANTHRO_) ────────────────────────────────────
		{"ANTHRO_CULTURAL",      3,`label=nhân học văn hóa|desc=cultural anthropology fieldwork ethnography participant observation kinship ritual symbol Geertz thick description|vi=nhân học văn hóa,cultural anthropology|en=cultural anthropology`},
		{"ANTHRO_LINGUISTIC",    3,`label=nhân học ngôn ngữ|desc=linguistic anthropology Sapir-Whorf hypothesis language relativity grammar thought color perception time concept|vi=nhân học ngôn ngữ,linguistic anthropology|en=linguistic anthropology`},
		{"ANTHRO_PHYSICAL",      3,`label=nhân học thể chất|desc=physical anthropology osteology forensic paleoanthropology hominin fossil bipedalism skull morphology variation|vi=nhân học thể chất,physical anthropology|en=physical anthropology`},
		{"ANTHRO_KINSHIP",       3,`label=thân tộc và hôn nhân|desc=kinship descent lineage clan moiety totem marriage alliance exchange Lévi-Strauss elementary structures|vi=thân tộc và hôn nhân,kinship|en=kinship anthropology`},
		{"ANTHRO_RITUAL",        3,`label=nghi lễ và biểu tượng|desc=ritual liminality Turner rites of passage van Gennep communitas sacred profane totem taboo pollution|vi=nghi lễ và biểu tượng,ritual|en=ritual anthropology`},

		// ── ARCHAEOLOGY (ARCHAEO_) ────────────────────────────────────
		{"ARCHAEO_METHOD",       3,`label=phương pháp khảo cổ|desc=archaeological method stratigraphy typology radiocarbon LiDAR remote sensing excavation context matrix Harris|vi=phương pháp khảo cổ,archaeology method|en=archaeology method`},
		{"ARCHAEO_PREHISTORY",   3,`label=thời tiền sử|desc=prehistory Paleolithic Mesolithic Neolithic Chalcolithic Bronze Iron Age tool assemblage cave art burial|vi=thời tiền sử,prehistory|en=prehistory`},
		{"ARCHAEO_UNDERWATER",   3,`label=khảo cổ dưới nước|desc=underwater archaeology shipwreck Mary Rose Titanic preservation salt waterlogged wood ROV photogrammetry|vi=khảo cổ dưới nước,underwater archaeology|en=underwater archaeology`},
		{"ARCHAEO_BIOARCH",      3,`label=sinh khảo cổ học|desc=bioarchaeology ancient DNA isotope diet migration paleopathology trauma skeletal stress marker aDNA|vi=sinh khảo cổ học,bioarchaeology|en=bioarchaeology`},
		{"ARCHAEO_VIETNAM",      3,`label=khảo cổ Việt Nam|desc=khảo cổ Đông Sơn trống đồng Sa Huỳnh Óc Eo văn hóa Hòa Bình di chỉ khảo cổ Tràng An|vi=khảo cổ Việt Nam,Vietnam archaeology|en=Vietnam archaeology`},

		// ── PSYCHOLOGY 3 (PSYCH3_) ────────────────────────────────────
		{"PSYCH3_ATTACHMENT",    3,`label=lý thuyết gắn bó|desc=attachment theory Bowlby Ainsworth secure anxious avoidant disorganized Strange Situation adult attachment style|vi=lý thuyết gắn bó,attachment theory|en=attachment theory`},
		{"PSYCH3_CBT",           3,`label=liệu pháp nhận thức hành vi|desc=CBT cognitive behavioral therapy Beck Ellis automatic thoughts cognitive distortion schema behavioral activation exposure|vi=liệu pháp nhận thức hành vi,CBT|en=CBT`},
		{"PSYCH3_POSITIVE",      3,`label=tâm lý học tích cực|desc=positive psychology Seligman PERMA flourishing character strength gratitude flow Csikszentmihalyi VIA classification|vi=tâm lý học tích cực,positive psychology|en=positive psychology`},
		{"PSYCH3_FORENSIC",      3,`label=tâm lý học pháp y|desc=forensic psychology criminal profiling insanity defense competency risk assessment psychopathy PCL-R Hare|vi=tâm lý học pháp y,forensic psychology|en=forensic psychology`},
		{"PSYCH3_SPORT",         3,`label=tâm lý thể thao|desc=sport psychology motivation self-talk imagery choking pressure zone flow mental toughness pre-performance routine|vi=tâm lý thể thao,sport psychology|en=sport psychology`},

		// ── BEHAVIORAL ECONOMICS (BEHAV_) ─────────────────────────────
		{"BEHAV_NUDGE",          3,`label=cú hích hành vi|desc=nudge Thaler Sunstein libertarian paternalism default option choice architecture organ donation cafeteria|vi=cú hích hành vi,nudge|en=nudge`},
		{"BEHAV_TIME_PREF",      3,`label=ưu tiên thời gian|desc=time preference hyperbolic discounting present bias beta-delta model commitment device Ulysses contract savings|vi=ưu tiên thời gian,time preference|en=time preference`},
		{"BEHAV_SOCIAL_NORM",    3,`label=chuẩn mực xã hội|desc=social norms injunctive descriptive conformity Cialdini hotel towels energy feedback peer comparison behavior change|vi=chuẩn mực xã hội,social norms|en=social norms`},
		{"BEHAV_IDENTITY",       3,`label=kinh tế học bản sắc|desc=identity economics Akerlof Kranton group identity social category insider outsider norm payoff utility|vi=kinh tế học bản sắc,identity economics|en=identity economics`},
		{"BEHAV_OVERCONFIDENCE", 3,`label=quá tự tin|desc=overconfidence above-average effect planning fallacy better-than-average illusion of control Dunning-Kruger expert calibration|vi=quá tự tin,overconfidence|en=overconfidence bias`},

		// ── AGRICULTURE 2 (AGRI2_) ───────────────────────────────────
		{"AGRI2_PRECISION",      3,`label=nông nghiệp chính xác|desc=precision agriculture GPS variable rate application NDVI drone sensor soil map yield monitor data-driven|vi=nông nghiệp chính xác,precision agriculture|en=precision agriculture`},
		{"AGRI2_VERTICAL",       3,`label=nông nghiệp thẳng đứng|desc=vertical farming LED hydroponics aeroponics controlled environment CEA water efficiency urban food security|vi=nông nghiệp thẳng đứng,vertical farming|en=vertical farming`},
		{"AGRI2_AGROFORESTRY",   3,`label=nông lâm kết hợp|desc=agroforestry trees crops livestock alley cropping silvopasture shade-grown coffee biodiversity carbon sequestration|vi=nông lâm kết hợp,agroforestry|en=agroforestry`},
		{"AGRI2_SOIL_HEALTH",    3,`label=sức khỏe đất|desc=soil health organic matter microbiome carbon sequestration no-till cover crop earthworm regenerative agriculture|vi=sức khỏe đất,soil health|en=soil health`},
		{"AGRI2_FOOD_SECURITY",  3,`label=an ninh lương thực|desc=food security four pillars availability access utilization stability FAO SDG2 stunting wasting hidden hunger|vi=an ninh lương thực,food security|en=food security`},

		// ── BIOTECHNOLOGY 2 (BIOTECH2_) ──────────────────────────────
		{"BIOTECH2_SYNBIO",      3,`label=sinh học tổng hợp|desc=synthetic biology BioBricks genetic circuit toggle switch oscillator chassis minimal genome JCVI Venter|vi=sinh học tổng hợp,synthetic biology|en=synthetic biology`},
		{"BIOTECH2_BIOREACTOR",  3,`label=lò phản ứng sinh học|desc=bioreactor fermenter batch fed-batch continuous stirred tank airlift cell culture scale-up GMP pharma|vi=lò phản ứng sinh học,bioreactor|en=bioreactor`},
		{"BIOTECH2_STEM_CELL",   3,`label=tế bào gốc|desc=stem cell pluripotent embryonic iPSC Yamanaka factors differentiation organoid clinical trial regenerative medicine|vi=tế bào gốc,stem cell|en=stem cell`},
		{"BIOTECH2_BIOSENSOR",   3,`label=cảm biến sinh học|desc=biosensor glucose monitor lateral flow immunoassay electrochemical optical aptamer point-of-care diagnostics|vi=cảm biến sinh học,biosensor|en=biosensor`},
		{"BIOTECH2_CULTURED",    3,`label=thịt nuôi cấy|desc=cultivated meat cell-cultured scaffold growth factor scaffold bioreactor cost reduction scaffolding regulatory approval|vi=thịt nuôi cấy,cultivated meat|en=cultivated meat`},

		// ── VIETNAM GEOGRAPHY (VNGEOG_) ──────────────────────────────
		{"VNGEOG_MEKONG",        3,`label=đồng bằng sông Cửu Long|desc=đồng bằng sông Cửu Long Mekong delta lúa nước trái cây thủy sản ngập mặn biến đổi khí hậu sạt lở|vi=đồng bằng sông Cửu Long,Mekong Delta|en=Mekong Delta Vietnam`},
		{"VNGEOG_HIGHLANDS",     3,`label=Tây Nguyên|desc=Tây Nguyên cao nguyên Kon Tum Gia Lai Đắk Lắk cà phê cao su đa dạng tộc người buôn làng bazan đất đỏ|vi=Tây Nguyên,Central Highlands Vietnam|en=Central Highlands Vietnam`},
		{"VNGEOG_RED_RIVER",     3,`label=đồng bằng sông Hồng|desc=đồng bằng sông Hồng châu thổ phù sa Thăng Long Hà Nội văn minh lúa nước đê điều thủy lợi mật độ dân số cao|vi=đồng bằng sông Hồng,Red River Delta|en=Red River Delta`},
		{"VNGEOG_COASTLINE",     3,`label=bờ biển Việt Nam|desc=bờ biển Việt Nam 3260km vịnh cảng biển Đà Nẵng Nha Trang Phú Quốc ngư nghiệp du lịch biển đảo Hoàng Sa Trường Sa|vi=bờ biển Việt Nam,Vietnam coastline|en=Vietnam coastline`},
		{"VNGEOG_BORDER",        3,`label=vùng biên giới Việt Nam|desc=biên giới Việt Nam Trung Quốc Lào Campuchia giao thương kinh tế cửa khẩu Móng Cái Lào Cai Mộc Bài|vi=vùng biên giới Việt Nam,Vietnam border|en=Vietnam border`},

		// ── VIETNAM ETHNIC (VNETHNIC_) ────────────────────────────────
		{"VNETHNIC_KINH",        3,`label=người Kinh|desc=người Kinh Việt 86% dân số đồng bằng ven biển lúa nước văn hóa Hán Phật Đạo bản sắc quốc gia|vi=người Kinh,Kinh people|en=Kinh people`},
		{"VNETHNIC_TAY_NUNG",    3,`label=dân tộc Tày Nùng|desc=dân tộc Tày Nùng Đông Bắc nhà sàn chữ Nôm Tày đàn tính then lễ hội lồng tồng ruộng bậc thang văn hóa phong phú|vi=dân tộc Tày Nùng,Tay Nung people|en=Tay Nung people`},
		{"VNETHNIC_HMONG",       3,`label=người H'Mông|desc=người H'Mông Mèo Tây Bắc Hà Giang Lai Châu thổ cẩm khèn lễ hội Gầu Tào ruộng bậc thang Mù Cang Chải du lịch|vi=người H'Mông,Hmong people|en=Hmong people Vietnam`},
		{"VNETHNIC_CHAM",        3,`label=người Chăm|desc=người Chăm Champa tháp Chàm Pô Nagar Mỹ Sơn UNESCO Hồi giáo Bà la môn dệt lụa nghề gốm Ninh Thuận|vi=người Chăm,Cham people|en=Cham people`},
		{"VNETHNIC_KHMER",       3,`label=người Khmer Nam Bộ|desc=người Khmer Nam Bộ Đồng bằng sông Cửu Long Phật giáo Tiểu thừa chùa Khmer Sóc Trăng Trà Vinh lễ Ok Om Bok|vi=người Khmer Nam Bộ,Southern Khmer|en=Southern Khmer Vietnam`},

		// ── VIETNAM INNOVATION (VNINNOVATE_) ─────────────────────────
		{"VNINNOVATE_STARTUP",   3,`label=startup Việt Nam|desc=startup Việt Nam VinGroup Momo ZaloPay Tiki Grab VNG unicorn hệ sinh thái đổi mới VSMA quỹ đầu tư mạo hiểm|vi=startup Việt Nam,Vietnam startup|en=Vietnam startup`},
		{"VNINNOVATE_TECH_HUB",  3,`label=trung tâm công nghệ|desc=trung tâm công nghệ Việt Nam Hà Nội TP.HCM Đà Nẵng SHTP Khu công nghệ cao gia công phần mềm FPT Viettel|vi=trung tâm công nghệ,Vietnam tech hub|en=Vietnam tech hub`},
		{"VNINNOVATE_AGRITECH",  3,`label=nông nghiệp công nghệ cao|desc=agritech Việt Nam nhà màng thủy canh IoT cảm biến đất xuất khẩu nông sản rau sạch OCOP chuỗi giá trị|vi=nông nghiệp công nghệ cao,Vietnam agritech|en=Vietnam agritech`},
		{"VNINNOVATE_FINTECH",   3,`label=fintech Việt Nam|desc=fintech Việt Nam ví điện tử Momo ZaloPay VNPay ngân hàng số thanh toán không tiền mặt NHNN sandbox|vi=fintech Việt Nam,Vietnam fintech|en=Vietnam fintech`},
		{"VNINNOVATE_EDTECH",    3,`label=công nghệ giáo dục|desc=edtech Việt Nam VNPT E-Learning TOPIK online Duolingo Vietnam coding bootcamp STEM robot hóa học|vi=công nghệ giáo dục,Vietnam edtech|en=Vietnam edtech`},

		// ── ART 2 (ART2_) ─────────────────────────────────────────────
		{"ART2_CONCEPT",         3,`label=nghệ thuật ý niệm|desc=conceptual art Duchamp readymade idea over craft dematerialization Kosuth Art as Idea Sol LeWitt instruction|vi=nghệ thuật ý niệm,conceptual art|en=conceptual art`},
		{"ART2_STREET",          3,`label=nghệ thuật đường phố|desc=street art graffiti Banksy Basquiat stencil paste-up public space social commentary Bristol New York urban|vi=nghệ thuật đường phố,street art|en=street art`},
		{"ART2_DIGITAL",         3,`label=nghệ thuật số|desc=digital art generative NFT glitch pixel processing p5.js Casey Reas creative coding interactive installation|vi=nghệ thuật số,digital art|en=digital art`},
		{"ART2_PERFORMANCE",     3,`label=nghệ thuật trình diễn|desc=performance art Marina Abramović Yoko Ono body endurance durational presence documentation ephemeral|vi=nghệ thuật trình diễn,performance art|en=performance art`},
		{"ART2_INSTALLATION",    3,`label=nghệ thuật sắp đặt|desc=installation art site-specific immersive Olafur Eliasson Turrell light space viewer environment room experience|vi=nghệ thuật sắp đặt,installation art|en=installation art`},

		// ── FILM 2 (FILM2_) ──────────────────────────────────────────
		{"FILM2_NEOREALISM",     3,`label=chủ nghĩa hiện thực mới|desc=Italian neorealism De Sica Rossellini non-actors location shooting working class Bicycle Thieves Rome Open City|vi=chủ nghĩa hiện thực mới,neorealism|en=neorealism`},
		{"FILM2_DOCUMENTARY",    3,`label=phim tài liệu|desc=documentary observational participatory performative expository reflexive direct cinema cinéma vérité ethics consent|vi=phim tài liệu,documentary film|en=documentary film`},
		{"FILM2_ANIMATION",      3,`label=hoạt hình|desc=animation 12 principles Disney squash stretch anticipation timing spacing arc secondary follow-through Pixar CGI|vi=hoạt hình,animation|en=animation`},
		{"FILM2_SOUND",          3,`label=âm thanh phim|desc=film sound diegetic non-diegetic Foley room tone ADR dialogue score ambient design Dolby Atmos spatial|vi=âm thanh phim,film sound|en=film sound`},
		{"FILM2_VIETNAM",        3,`label=điện ảnh Việt Nam|desc=điện ảnh Việt Nam Mùi đu đủ xanh Trần Anh Hùng Bụi đời Chợ Lớn Hai Phượng Bố già phim thị trường|vi=điện ảnh Việt Nam,Vietnamese cinema|en=Vietnamese cinema`},

		// ── GAME 3 (GAME3_) ──────────────────────────────────────────
		{"GAME3_NARRATIVE",      3,`label=kể chuyện trong game|desc=game narrative environmental storytelling ludonarrative dissonance branching dialogue The Last of Us Disco Elysium|vi=kể chuyện trong game,game narrative|en=game narrative`},
		{"GAME3_PROCEDURAL",     3,`label=tạo sinh thủ tục|desc=procedural generation Minecraft No Man's Sky Dwarf Fortress PCG algorithm seed noise Perlin terrain dungeon|vi=tạo sinh thủ tục,procedural generation|en=procedural generation`},
		{"GAME3_ESPORT",         3,`label=thể thao điện tử|desc=esports League of Legends Dota2 CS:GO Valorant prize pool viewership broadcast coaching mental coaching|vi=thể thao điện tử,esports|en=esports`},
		{"GAME3_MONETIZE",       3,`label=mô hình kinh doanh game|desc=game monetization F2P battle pass loot box gacha season pass subscription live service ethical design|vi=mô hình kinh doanh game,game monetization|en=game monetization`},
		{"GAME3_ACCESSIBILITY",  3,`label=trò chơi dễ tiếp cận|desc=game accessibility subtitle colorblind mode remapping difficulty assist mode The Last of Us 2 deaf deaf|vi=trò chơi dễ tiếp cận,game accessibility|en=game accessibility`},

		// ── CULINARY 2 (CULINARY2_) ──────────────────────────────────
		{"CULINARY2_FERMENT",    3,`label=lên men ẩm thực|desc=fermentation kimchi miso kefir sourdough tempeh koji lacto-fermentation SCOBY microbiome gut health probiotic|vi=lên men ẩm thực,food fermentation|en=food fermentation`},
		{"CULINARY2_SPICE",      3,`label=gia vị và hương liệu|desc=spice terroir saffron vanilla cardamom star anise Maillard reaction volatile compound flavor pairing science|vi=gia vị và hương liệu,spices|en=spices culinary`},
		{"CULINARY2_MOLECULAR",  3,`label=ẩm thực phân tử|desc=molecular gastronomy Ferran Adrià Heston Blumenthal spherification emulsification gel foam liquid nitrogen texture|vi=ẩm thực phân tử,molecular gastronomy|en=molecular gastronomy`},
		{"CULINARY2_PLANT",      3,`label=chế độ ăn thực vật|desc=plant-based diet whole food vegan vegetarian Beyond Impossible meat analogue environmental footprint B12 omega3|vi=chế độ ăn thực vật,plant-based diet|en=plant-based diet`},
		{"CULINARY2_FOOD_WASTE", 3,`label=lãng phí thực phẩm|desc=food waste one-third production lost root to stem nose to tail preservation fermentation composting supply chain cold|vi=lãng phí thực phẩm,food waste|en=food waste`},

		// ── SPORT 5 (SPORT5_) ────────────────────────────────────────
		{"SPORT5_BIOMECH",       3,`label=cơ sinh học thể thao|desc=sports biomechanics force plate motion capture EMG kinematic kinetic ground reaction power output technique|vi=cơ sinh học thể thao,sports biomechanics|en=sports biomechanics`},
		{"SPORT5_NUTRITION",     3,`label=dinh dưỡng thể thao|desc=sports nutrition periodization carb loading protein synthesis creatine caffeine ergogenic aid hydration sweat rate|vi=dinh dưỡng thể thao,sports nutrition|en=sports nutrition`},
		{"SPORT5_ANALYTICS",     3,`label=phân tích dữ liệu thể thao|desc=sports analytics Moneyball xG expected goals tracking STATS Opta StatsBomb wearable GPS performance model|vi=phân tích dữ liệu thể thao,sports analytics|en=sports analytics`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3800 { fmt.Println(" MILESTONE 3800! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
