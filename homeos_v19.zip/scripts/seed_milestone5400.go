//go:build ignore
// seed_milestone5400.go — MILESTONE 5400 — 100 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── MEDIA & JOURNALISM ───────────────────────────────────────
		{"MEDIA_THEORY",         3,`label=lý thuyết truyền thông|desc=media theory agenda setting framing gatekeeping uses gratifications cultivation McLuhan medium message|vi=lý thuyết truyền thông,media theory|en=media theory`},
		{"MEDIA_DIGITAL2",       3,`label=truyền thông số nâng cao|desc=digital media platform algorithm filter bubble echo chamber engagement metric attention economy|vi=truyền thông số nâng cao,digital media|en=digital media`},
		{"JOURNALISM_INVEST",    3,`label=báo chí điều tra|desc=investigative journalism source protection whistleblower FOIA document leak data-driven accountability|vi=báo chí điều tra,investigative journalism|en=investigative journalism`},
		{"JOURNALISM_DATA",      3,`label=báo chí dữ liệu|desc=data journalism visualization scraping OSINT geolocation satellite imagery verification tools|vi=báo chí dữ liệu,data journalism|en=data journalism`},
		{"JOURNALISM_AI",        3,`label=AI và báo chí|desc=AI journalism automated content fact-check deepfake detection synthetic media trust credibility|vi=AI và báo chí,AI journalism|en=AI journalism`},
		{"MEDIA_VIET",           3,`label=truyền thông Việt Nam|desc=truyền thông Việt Nam báo chí nhà nước mạng xã hội Zalo Facebook kiểm duyệt thông tin|vi=truyền thông Việt Nam,Vietnam media|en=Vietnam media`},
		{"MEDIA_PODCAST",        3,`label=podcast và audio media|desc=podcast audio long-form storytelling serial narrative NPR This American Life distribution Spotify|vi=podcast và audio media,podcast|en=podcast`},

		// ── ADVERTISING & PR ─────────────────────────────────────────
		{"ADVERTISING_DIGITAL",  3,`label=quảng cáo số|desc=digital advertising programmatic RTB DSP SSP DMP audience targeting retargeting attribution ROAS|vi=quảng cáo số,digital advertising|en=digital advertising`},
		{"ADVERTISING_CREATIVE", 3,`label=sáng tạo quảng cáo|desc=advertising creative copywriting art direction big idea brief execution AIDА storytelling brand|vi=sáng tạo quảng cáo,advertising creative|en=advertising creative`},
		{"PR_CRISIS",            3,`label=PR khủng hoảng|desc=crisis PR reputation management issue dark site holding statement spokesperson media training|vi=PR khủng hoảng,crisis PR|en=crisis PR`},
		{"PR_DIGITAL",           3,`label=PR số và influencer|desc=digital PR influencer marketing micro-nano KOL earned media social listening brand monitoring|vi=PR số và influencer,digital PR|en=digital PR`},
		{"BRAND_STRATEGY",       3,`label=chiến lược thương hiệu|desc=brand strategy positioning differentiation brand equity Keller resonance pyramid identity prism|vi=chiến lược thương hiệu,brand strategy|en=brand strategy`},
		{"BRAND_VIET",           3,`label=thương hiệu Việt Nam|desc=thương hiệu Việt Nam Vinamilk Viettel FPT TH True Milk Biti's Made in Vietnam tự hào|vi=thương hiệu Việt Nam,Vietnam brand|en=Vietnam brand`},

		// ── BLOCKCHAIN & WEB3 ────────────────────────────────────────
		{"BLOCKCHAIN_CONSENSUS", 3,`label=cơ chế đồng thuận blockchain|desc=blockchain consensus PoW PoS DPoS BFT Nakamoto finality validator slashing MEV|vi=cơ chế đồng thuận blockchain,blockchain consensus|en=blockchain consensus`},
		{"BLOCKCHAIN_LAYER2",    3,`label=Layer 2 blockchain|desc=L2 blockchain rollup optimistic ZK validity proof state channel plasma bridge Arbitrum Optimism|vi=Layer 2 blockchain,blockchain L2|en=blockchain L2`},
		{"DEFI_PROTOCOL",        3,`label=giao thức DeFi|desc=DeFi protocol AMM liquidity pool yield farming lending borrowing Uniswap Aave Compound TVL|vi=giao thức DeFi,DeFi protocol|en=DeFi protocol`},
		{"DEFI_RISK",            3,`label=rủi ro DeFi|desc=DeFi risk smart contract exploit flash loan oracle manipulation rug pull impermanent loss audit|vi=rủi ro DeFi,DeFi risk|en=DeFi risk`},
		{"WEB3_GOVERN",          3,`label=quản trị Web3|desc=Web3 governance DAO token voting quadratic governance plutocracy voter apathy Sybil attack|vi=quản trị Web3,Web3 governance|en=Web3 governance`},
		{"WEB3_IDENTITY",        3,`label=danh tính Web3|desc=Web3 identity DID self-sovereign verifiable credential wallet ENS Lens Protocol Farcaster|vi=danh tính Web3,Web3 identity|en=Web3 identity`},
		{"CRYPTO_REGULATION",    3,`label=quy định tiền mã hóa|desc=crypto regulation SEC CFTC MiCA stablecoin CBDC AML KYC travel rule custody exchange|vi=quy định tiền mã hóa,crypto regulation|en=crypto regulation`},
		{"CRYPTO_VIET",          3,`label=crypto tại Việt Nam|desc=crypto Việt Nam SBV quy định P2P exchange VNDC thị trường cá nhân thuế pháp lý|vi=crypto tại Việt Nam,Vietnam crypto|en=Vietnam crypto`},

		// ── TYPOGRAPHY & VISUAL DESIGN ────────────────────────────────
		{"TYPOGRAPHY_FUND",      3,`label=nền tảng typography|desc=typography fundamentals typeface font weight width contrast hierarchy baseline grid legibility|vi=nền tảng typography,typography fundamentals|en=typography fundamentals`},
		{"TYPOGRAPHY_SYSTEM",    3,`label=hệ thống chữ|desc=type system modular scale fluid responsive variable font OpenType features design token|vi=hệ thống chữ,type system|en=type system`},
		{"GRAPHIC_DESIGN_HIST",  3,`label=lịch sử thiết kế đồ họa|desc=graphic design history Bauhaus Swiss International modernism postmodern digital contemporary|vi=lịch sử thiết kế đồ họa,graphic design history|en=graphic design history`},
		{"GRAPHIC_DESIGN_UI",    3,`label=thiết kế giao diện|desc=UI design visual hierarchy contrast alignment proximity repetition Gestalt affordance feedback|vi=thiết kế giao diện,UI design|en=UI design`},
		{"MOTION_DESIGN",        3,`label=thiết kế chuyển động|desc=motion design animation principles 12 principles Disney easing timing spacing squash stretch|vi=thiết kế chuyển động,motion design|en=motion design`},
		{"MOTION_UI",            3,`label=animation giao diện|desc=UI animation microinteraction transition state change feedback loading skeleton lottie GSAP|vi=animation giao diện,UI animation|en=UI animation`},
		{"DESIGN_SYSTEM",        3,`label=hệ thống thiết kế|desc=design system component library token Figma Storybook atomic design atomic molecule organism|vi=hệ thống thiết kế,design system|en=design system`},
		{"COLOR_THEORY",         3,`label=lý thuyết màu sắc|desc=color theory HSL wheel complementary analogous triadic harmony psychology cultural meaning|vi=lý thuyết màu sắc,color theory|en=color theory`},
		{"DESIGN_VIET",          3,`label=thiết kế tại Việt Nam|desc=thiết kế Việt Nam đồ họa thương hiệu font chữ Việt hoa văn truyền thống hiện đại|vi=thiết kế tại Việt Nam,Vietnam design|en=Vietnam design`},

		// ── NARRATIVE & STORYTELLING ─────────────────────────────────
		{"NARRATIVE_STRUCT",     3,`label=cấu trúc tường thuật|desc=narrative structure three act hero journey kishōtenketsu in medias res frame unreliable narrator|vi=cấu trúc tường thuật,narrative structure|en=narrative structure`},
		{"NARRATIVE_EMOTION",    3,`label=tường thuật và cảm xúc|desc=narrative emotion suspense tension surprise empathy identification character arc transformation|vi=tường thuật và cảm xúc,narrative emotion|en=narrative emotion`},
		{"NARRATIVE_TRANSMEDIA", 3,`label=kể chuyện đa phương tiện|desc=transmedia storytelling world-building Jenkins storyworld ARG immersive experience participatory|vi=kể chuyện đa phương tiện,transmedia storytelling|en=transmedia storytelling`},
		{"STORYTELLING_BRAND",   3,`label=kể chuyện thương hiệu|desc=brand storytelling content marketing narrative identity founder story origin mission why|vi=kể chuyện thương hiệu,brand storytelling|en=brand storytelling`},
		{"NARRATIVE_VIET",       3,`label=tự sự Việt Nam|desc=tự sự Việt Nam truyện ngắn tiểu thuyết hiện đại Nguyễn Huy Thiệp Bảo Ninh Nam Lê|vi=tự sự Việt Nam,Vietnamese narrative|en=Vietnamese narrative`},

		// ── INTERACTION DESIGN & UX ───────────────────────────────────
		{"UX_RESEARCH",          3,`label=nghiên cứu UX|desc=UX research usability testing interview card sorting tree testing eye tracking survey|vi=nghiên cứu UX,UX research|en=UX research`},
		{"UX_WRITING",           3,`label=viết UX|desc=UX writing microcopy error message onboarding empty state voice tone clarity conciseness|vi=viết UX,UX writing|en=UX writing`},
		{"INTERACTION_DESIGN",   3,`label=thiết kế tương tác|desc=interaction design IxD flow state transition feedback affordance discoverability Preece Rogers|vi=thiết kế tương tác,interaction design|en=interaction design`},
		{"ACCESSIBILITY_DESIGN", 3,`label=thiết kế tiếp cận|desc=accessibility WCAG screen reader color contrast keyboard navigation ARIA semantic HTML inclusive|vi=thiết kế tiếp cận,accessibility design|en=accessibility design`},

		// ── SEMIOTICS & COMMUNICATION ─────────────────────────────────
		{"SEMIOTICS2",           3,`label=ký hiệu học nâng cao|desc=semiotics Peirce icon index symbol Saussure signifier signified connotation denotation myth|vi=ký hiệu học nâng cao,semiotics|en=semiotics`},
		{"COMMUNICATION_CROSS",  3,`label=giao tiếp liên văn hóa|desc=cross-cultural communication Hofstede dimensions high low context power distance uncertainty|vi=giao tiếp liên văn hóa,cross-cultural communication|en=cross-cultural communication`},
		{"RHETORIC2",            3,`label=tu từ học nâng cao|desc=rhetoric ethos pathos logos kairos arrangement invention style memory delivery Aristotle|vi=tu từ học nâng cao,rhetoric|en=rhetoric`},

		// ── VIETNAM SPECIFIC ──────────────────────────────────────────
		{"VN_MEDIA_SOCIAL",      3,`label=mạng xã hội Việt Nam|desc=mạng xã hội Việt Nam Facebook TikTok Zalo YouTube influencer KOL nội dung sáng tạo|vi=mạng xã hội Việt Nam,Vietnam social media|en=Vietnam social media`},
		{"VN_ADVERTISING",       3,`label=quảng cáo tại Việt Nam|desc=quảng cáo Việt Nam Tết campaign viral insight văn hóa thương hiệu địa phương hóa|vi=quảng cáo tại Việt Nam,Vietnam advertising|en=Vietnam advertising`},
		{"VN_BLOCKCHAIN",        3,`label=blockchain Việt Nam|desc=blockchain Việt Nam Axie Infinity Sky Mavis KardiaChain ứng dụng NFT game thị trường|vi=blockchain Việt Nam,Vietnam blockchain|en=Vietnam blockchain`},
		{"VN_DESIGN_FONT",       3,`label=font chữ Việt Nam|desc=font chữ Việt Nam dấu thanh Unicode UTF-8 SVN font Be Vietnam Pro Noto Sans Vietnamese|vi=font chữ Việt Nam,Vietnamese font|en=Vietnamese font`},

		// ── MISC BRIDGE ───────────────────────────────────────────────
		{"MEDIA_LITERACY",       3,`label=văn hóa đọc hiểu truyền thông|desc=media literacy critical consumption source evaluation misinformation prebunking digital citizenship|vi=văn hóa đọc hiểu truyền thông,media literacy|en=media literacy`},
		{"CONTENT_STRATEGY",     3,`label=chiến lược nội dung|desc=content strategy editorial calendar SEO pillar cluster topic authority distribution repurpose|vi=chiến lược nội dung,content strategy|en=content strategy`},
		{"BLOCKCHAIN_ZERO",      3,`label=bằng chứng không tiết lộ|desc=zero knowledge proof ZK-SNARK STARK circuit witness prover verifier privacy-preserving|vi=bằng chứng không tiết lộ,zero knowledge proof|en=zero knowledge proof`},
		{"NARRATIVE_HORROR",     3,`label=thể loại kinh dị|desc=horror genre uncanny sublime dread atmosphere tension slow burn cosmic Lovecraft folk body|vi=thể loại kinh dị,horror genre|en=horror genre`},
		{"NARRATIVE_SCIFI",      3,`label=khoa học viễn tưởng|desc=science fiction hard SF cyberpunk solarpunk post-scarcity AI singularity first contact worldbuilding|vi=khoa học viễn tưởng,science fiction|en=science fiction`},
		{"UX_EMOTION_DESIGN",    3,`label=thiết kế cảm xúc|desc=emotional design Norman visceral behavioral reflective delight frustration trust brand personality|vi=thiết kế cảm xúc,emotional design|en=emotional design`},
		{"TYPOGRAPHY_VIET",      3,`label=typography tiếng Việt|desc=Vietnamese typography tonal diacritic stacking glyph height optical size kerning complex script|vi=typography tiếng Việt,Vietnamese typography|en=Vietnamese typography`},
		{"COLOR_CULTURE_VIET",   3,`label=màu sắc trong văn hóa Việt|desc=màu sắc văn hóa Việt Nam đỏ vàng may mắn đám cưới tang lễ ngũ hành phong thủy|vi=màu sắc trong văn hóa Việt,Vietnamese color culture|en=Vietnamese color culture`},
		{"DEFI_VIETNAM",         3,`label=DeFi tại Việt Nam|desc=DeFi Vietnam P2P lending yield farming Axie scholarship community participation barrier|vi=DeFi tại Việt Nam,DeFi Vietnam|en=DeFi Vietnam`},
		{"PR_VIET",              3,`label=PR tại Việt Nam|desc=PR Việt Nam quan hệ báo chí khủng hoảng truyền thông mạng xã hội thương hiệu cộng đồng|vi=PR tại Việt Nam,Vietnam PR|en=Vietnam PR`},
		{"MOTION_3D",            3,`label=motion graphics 3D|desc=3D motion Cinema 4D Blender Houdini simulation particle fluid dynamics render shading|vi=motion graphics 3D,3D motion|en=3D motion`},
		{"NARRATIVE_GAME",       3,`label=kể chuyện trong game|desc=game narrative environmental storytelling ludonarrative dissonance branching dialogue choice consequence|vi=kể chuyện trong game,game narrative|en=game narrative`},
		{"COMMUNICATION_NONVERBAL",3,`label=giao tiếp phi ngôn ngữ|desc=nonverbal communication body language microexpression proxemics haptics paralanguage gesture|vi=giao tiếp phi ngôn ngữ,nonverbal communication|en=nonverbal communication`},
		{"MEDIA_INFLUENCE",      3,`label=ảnh hưởng truyền thông|desc=media influence persuasion third-person effect spiral of silence priming cultivation theory|vi=ảnh hưởng truyền thông,media influence|en=media influence`},
		{"ADVERTISING_PSYCHOLOGY",3,`label=tâm lý quảng cáo|desc=advertising psychology emotion color scarcity social proof authority liking consistency|vi=tâm lý quảng cáo,advertising psychology|en=advertising psychology`},
		{"WEB3_CULTURE",         3,`label=văn hóa Web3|desc=Web3 culture meme degen WAGMI NGMI NFT community Discord Twitter CT on-chain identity|vi=văn hóa Web3,Web3 culture|en=Web3 culture`},
		{"UX_AI_DESIGN",         3,`label=thiết kế AI UX|desc=AI UX design explainability uncertainty communication error trust calibration human in loop|vi=thiết kế AI UX,AI UX design|en=AI UX design`},
		{"SEMIOTICS_VISUAL",     3,`label=ký hiệu học thị giác|desc=visual semiotics Barthes image text anchorage relay Panofsky iconology iconography meaning|vi=ký hiệu học thị giác,visual semiotics|en=visual semiotics`},
		{"NARRATIVE_MEMOIR",     3,`label=hồi ký và tự truyện|desc=memoir autobiography autofiction life writing unreliable narrator trauma narrative identity truth|vi=hồi ký và tự truyện,memoir autobiography|en=memoir autobiography`},
		{"BLOCKCHAIN_GAMING",    3,`label=blockchain gaming|desc=blockchain gaming play to earn NFT item ownership interoperability on-chain game economy token|vi=blockchain gaming,blockchain gaming|en=blockchain gaming`},
		{"TYPOGRAPHY_EMOTION",   3,`label=cảm xúc trong typography|desc=type emotion personality humanist geometric grotesque serif warmth coldness trust playful serious|vi=cảm xúc trong typography,type emotion|en=type emotion`},
		{"DESIGN_ETHICS",        3,`label=đạo đức thiết kế|desc=design ethics dark pattern deceptive UX manipulation consent privacy surveillance enshittification|vi=đạo đức thiết kế,design ethics|en=design ethics`},
		{"MEDIA_FUTURE",         3,`label=tương lai truyền thông|desc=future media AI-generated content synthetic journalism deepfake trust crisis subscription bundling|vi=tương lai truyền thông,future media|en=future media`},
		{"VN_STORYTELLING",      3,`label=kể chuyện Việt Nam|desc=kể chuyện Việt Nam truyện dân gian cổ tích truyền thuyết oral tradition hiện đại hóa|vi=kể chuyện Việt Nam,Vietnamese storytelling|en=Vietnamese storytelling`},
		{"INTERACTION_VOICE",    3,`label=tương tác giọng nói|desc=voice interaction VUI conversation design intent slot filling error handling persona wake word|vi=tương tác giọng nói,voice interaction|en=voice interaction`},
		{"COLOR_ACCESSIBILITY",  3,`label=màu sắc và tiếp cận|desc=color accessibility contrast ratio WCAG deuteranopia protanopia tritanopia color blind safe palette|vi=màu sắc và tiếp cận,color accessibility|en=color accessibility`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 5400 { fmt.Println(" MILESTONE 5400! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
