//go:build ignore
// Seed domain Thiên văn/Vũ trụ + Kinh tế vào homeos.olang
// go run scripts/seed_astro_economy.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ Đọc: %d bytes, %d nodes, %d edges\n",
		len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── THIÊN VĂN / VŨ TRỤ ──────────────────────────────────
		{"ASTRO_UNIVERSE",  3, `label=vũ trụ|desc=toàn bộ không gian vật chất năng lượng và thời gian hình thành từ Big Bang 13.8 tỷ năm trước|vi=vũ trụ,universe|en=universe|zh=宇宙`},
		{"ASTRO_GALAXY",    3, `label=thiên hà|desc=hệ thống hàng tỷ ngôi sao khí bụi liên kết bởi lực hút trọng lực Milky Way chứa Mặt Trời|vi=thiên hà,galaxy|en=galaxy|zh=星系`},
		{"ASTRO_STAR",      3, `label=ngôi sao|desc=quả cầu plasma khổng lồ phát sáng do phản ứng nhiệt hạch Mặt Trời là ngôi sao gần nhất|vi=ngôi sao,sao,star|en=star|zh=恒星`},
		{"ASTRO_PLANET",    3, `label=hành tinh|desc=thiên thể quay quanh ngôi sao đủ lớn để có hình cầu Hệ Mặt Trời có 8 hành tinh|vi=hành tinh,planet|en=planet|zh=行星`},
		{"ASTRO_SUN",       3, `label=mặt trời|desc=ngôi sao trung tâm Hệ Mặt Trời cung cấp năng lượng cho Trái Đất nhiệt độ bề mặt 5778 K|vi=mặt trời,sun|en=sun|zh=太阳`},
		{"ASTRO_MOON",      3, `label=mặt trăng|desc=vệ tinh tự nhiên duy nhất của Trái Đất ảnh hưởng thủy triều khoảng cách 384400 km|vi=mặt trăng,moon|en=moon|zh=月亮`},
		{"ASTRO_BLACKHOLE", 3, `label=hố đen|desc=vùng không gian có lực hút trọng lực cực mạnh ngay ánh sáng cũng không thoát ra được|vi=hố đen,black hole|en=black hole|zh=黑洞`},
		{"ASTRO_BIGBANG",   3, `label=big bang|desc=sự kiện kỳ dị khởi đầu vũ trụ 13.8 tỷ năm trước từ trạng thái cực nóng cực đặc|vi=big bang,vụ nổ lớn|en=big bang|zh=大爆炸`},
		{"ASTRO_NEBULA",    3, `label=tinh vân|desc=đám mây khí bụi trong không gian nơi hình thành ngôi sao mới|vi=tinh vân,nebula|en=nebula|zh=星云`},
		{"ASTRO_ORBIT",     3, `label=quỹ đạo|desc=đường chuyển động của thiên thể xung quanh thiên thể khác do lực hút trọng lực|vi=quỹ đạo,orbit|en=orbit|zh=轨道`},
		{"ASTRO_LIGHTSPEED",3, `label=tốc độ ánh sáng|desc=tốc độ tối đa trong vũ trụ 299792458 m/s ký hiệu c không gì vượt qua được|vi=tốc độ ánh sáng,light speed|en=speed of light|zh=光速`},
		{"ASTRO_SPACETIME", 3, `label=không thời gian|desc=mô hình 4 chiều kết hợp 3 chiều không gian và 1 chiều thời gian theo thuyết tương đối|vi=không thời gian,space-time|en=spacetime|zh=时空`},
		{"ASTRO_GRAVITY_WAVE",3,`label=sóng hấp dẫn|desc=gợn sóng trong không thời gian tạo ra bởi vật thể cực nặng chuyển động LIGO phát hiện 2015|vi=sóng hấp dẫn,gravitational wave|en=gravitational wave|zh=引力波`},
		{"ASTRO_COMET",     3, `label=sao chổi|desc=thiên thể nhỏ gồm đá bụi băng chạy theo quỹ đạo elip quanh Mặt Trời có đuôi sáng|vi=sao chổi,comet|en=comet|zh=彗星`},
		{"ASTRO_TELESCOPE", 3, `label=kính thiên văn|desc=dụng cụ quang học thu ánh sáng để quan sát thiên thể xa Hubble Space Telescope|vi=kính thiên văn,telescope|en=telescope|zh=望远镜`},

		// ── KINH TẾ ──────────────────────────────────────────────
		{"ECON_GDP",        3, `label=GDP|desc=tổng sản phẩm quốc nội tổng giá trị hàng hóa dịch vụ sản xuất trong một năm|vi=GDP,tổng sản phẩm quốc nội|en=gross domestic product|zh=国内生产总值`},
		{"ECON_INFLATION",  3, `label=lạm phát|desc=mức tăng giá cả hàng hóa dịch vụ theo thời gian làm giảm sức mua của tiền tệ|vi=lạm phát,inflation|en=inflation|zh=通货膨胀`},
		{"ECON_MARKET",     3, `label=thị trường|desc=hệ thống trao đổi hàng hóa dịch vụ giữa người mua và người bán xác định giá cả|vi=thị trường,market|en=market|zh=市场`},
		{"ECON_SUPPLY",     3, `label=cung|desc=lượng hàng hóa dịch vụ nhà sản xuất sẵn sàng cung cấp ở các mức giá khác nhau|vi=cung,supply|en=supply|zh=供给`},
		{"ECON_DEMAND",     3, `label=cầu|desc=lượng hàng hóa dịch vụ người tiêu dùng muốn và có khả năng mua ở các mức giá|vi=cầu,demand|en=demand|zh=需求`},
		{"ECON_CURRENCY",   3, `label=tiền tệ|desc=phương tiện trao đổi được chấp nhận rộng rãi trong thanh toán hàng hóa dịch vụ|vi=tiền tệ,tiền,currency|en=currency|zh=货币`},
		{"ECON_INVESTMENT", 3, `label=đầu tư|desc=sử dụng nguồn lực hiện tại để tạo ra giá trị trong tương lai cổ phiếu trái phiếu bất động sản|vi=đầu tư,investment|en=investment|zh=投资`},
		{"ECON_BANK",       3, `label=ngân hàng|desc=tổ chức tài chính nhận tiền gửi cho vay và cung cấp dịch vụ tài chính|vi=ngân hàng,bank|en=bank|zh=银行`},
		{"ECON_TAX",        3, `label=thuế|desc=khoản thu bắt buộc của chính phủ từ cá nhân doanh nghiệp để tài trợ cho dịch vụ công|vi=thuế,tax|en=tax|zh=税收`},
		{"ECON_TRADE_BAL",  3, `label=cán cân thương mại|desc=chênh lệch giữa xuất khẩu và nhập khẩu thặng dư thương mại khi xuất>nhập|vi=cán cân thương mại,trade balance|en=trade balance|zh=贸易差额`},
		{"ECON_INTEREST",   3, `label=lãi suất|desc=chi phí vay tiền hoặc thu nhập từ tiết kiệm tỷ lệ phần trăm trên năm|vi=lãi suất,interest rate|en=interest rate|zh=利率`},
		{"ECON_POVERTY",    3, `label=nghèo đói|desc=tình trạng thiếu nguồn lực cơ bản để đáp ứng nhu cầu sống tối thiểu|vi=nghèo đói,poverty|en=poverty|zh=贫困`},
		{"ECON_STARTUP",    3, `label=khởi nghiệp|desc=doanh nghiệp mới thành lập với mô hình kinh doanh đổi mới sáng tạo tăng trưởng nhanh|vi=khởi nghiệp,startup|en=startup|zh=创业`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Thiên văn nội bộ
		{"ASTRO_STAR",      "ASTRO_GALAXY",    "part-of"},
		{"ASTRO_PLANET",    "ASTRO_STAR",      "orbits"},
		{"ASTRO_SUN",       "ASTRO_STAR",      "is-a"},
		{"ASTRO_MOON",      "ASTRO_PLANET",    "orbits"},
		{"ASTRO_ORBIT",     "ASTRO_PLANET",    "property-of"},
		{"ASTRO_BLACKHOLE", "ASTRO_GALAXY",    "found-in"},
		{"ASTRO_BIGBANG",   "ASTRO_UNIVERSE",  "origin-of"},
		{"ASTRO_NEBULA",    "ASTRO_STAR",      "forms"},
		{"ASTRO_COMET",     "ASTRO_UNIVERSE",  "part-of"},
		{"ASTRO_GRAVITY_WAVE","ASTRO_SPACETIME","ripple-in"},
		{"ASTRO_TELESCOPE", "ASTRO_STAR",      "observes"},
		{"ASTRO_LIGHTSPEED","ASTRO_SPACETIME", "limits"},
		// Thiên văn ↔ Vật lý
		{"ASTRO_GRAVITY_WAVE","PHYS_WAVE",     "is-a"},
		{"ASTRO_LIGHTSPEED", "PHYS_LIGHT",     "speed-of"},
		{"ASTRO_BIGBANG",    "PHYS_ENERGY",    "releases"},
		// Kinh tế nội bộ
		{"ECON_SUPPLY",     "ECON_MARKET",     "part-of"},
		{"ECON_DEMAND",     "ECON_MARKET",     "part-of"},
		{"ECON_SUPPLY",     "ECON_DEMAND",     "related-to"},
		{"ECON_INFLATION",  "ECON_CURRENCY",   "erodes"},
		{"ECON_BANK",       "ECON_CURRENCY",   "manages"},
		{"ECON_INTEREST",   "ECON_BANK",       "set-by"},
		{"ECON_TAX",        "ECON_GDP",        "component-of"},
		{"ECON_INVESTMENT", "ECON_GDP",        "drives"},
		{"ECON_TRADE_BAL",  "ECON_MARKET",     "measures"},
		{"ECON_POVERTY",    "ECON_GDP",        "inverse-of"},
		{"ECON_STARTUP",    "ECON_INVESTMENT", "attracts"},
		// Kinh tế ↔ Lịch sử
		{"ECON_MARKET",     "HIST_TRADE",      "evolved-from"},
		{"ECON_GDP",        "GEO_COUNTRY",     "measures"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-22s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}

	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip edge %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}

	fmt.Printf("\n✚ Thêm: %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n",
		len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]
	return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		name := string(raw[i+20+dl:ne2])
		var v [8]byte; copy(v[:], raw[i+3:i+11]); m[name]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"related-to":3,"causes":4,"uses":5,
		"produces":6,"contains":7,"orbits":8,"property-of":9,"found-in":10,
		"origin-of":11,"forms":12,"ripple-in":13,"limits":14,"observes":15,
		"speed-of":16,"releases":17,"erodes":18,"manages":19,"set-by":20,
		"component-of":21,"drives":22,"measures":23,"inverse-of":24,
		"attracts":25,"evolved-from":26,"similar":27,"opposite":28,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
