//go:build ignore
// seed_milestone4000.go — MILESTONE 4000 — 100 nodes
// Domains: PHILOSOPHY3_ ETHICS2_ AESTHETICS_ EPISTEMOLOGY_ METAPHYSICS_
//          EDUCATION2_ PEDAGOGY_ CURRICULUM_ ELEARNING_ ASSESSMENT_
//          PUBHEALTH_ EPIDEMIOL_ GLOBALHEALTH_ MENTAL3_ REHAB_
//          ECON3_ DEVELOPMENT_ LABOR_ TRADE2_ MONETARY_
//          VNENVIRON_ VNWATER_ VNFOREST_ VNAIR_ VNBIODIV_
//          MUSIC3_ DANCE_ THEATER_ CIRCUS_ POETRY_
//          ARCHITECTURE2_ LANDSCAPE_ URBANISM2_ HERITAGE_ SACRED_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── PHILOSOPHY 3 (PHILOSOPHY3_) ──────────────────────────────
		{"PHILOSOPHY3_MIND",       3,`label=triết học tâm trí|desc=philosophy of mind qualia hard problem Chalmers functionalism eliminativism dualism physicalism zombie argument Mary's room|vi=triết học tâm trí,philosophy of mind|en=philosophy of mind`},
		{"PHILOSOPHY3_LANGUAGE",   3,`label=triết học ngôn ngữ|desc=philosophy of language meaning reference Frege Russell Wittgenstein Kripke rigid designator speech act Austin Searle|vi=triết học ngôn ngữ,philosophy of language|en=philosophy of language`},
		{"PHILOSOPHY3_SCIENCE",    3,`label=triết học khoa học|desc=philosophy of science falsificationism Popper Kuhn paradigm Lakatos Feyerabend underdetermination demarcation|vi=triết học khoa học,philosophy of science|en=philosophy of science`},
		{"PHILOSOPHY3_TIME",       3,`label=triết học thời gian|desc=philosophy of time A-theory B-theory presentism eternalism growing block McTaggart arrow of time relativity|vi=triết học thời gian,philosophy of time|en=philosophy of time`},
		{"PHILOSOPHY3_IDENTITY",   3,`label=đồng nhất tính cá nhân|desc=personal identity ship of Theseus Locke memory Parfit psychological continuity bodily criterion fission problem|vi=đồng nhất tính cá nhân,personal identity|en=personal identity`},

		// ── ETHICS 2 (ETHICS2_) ──────────────────────────────────────
		{"ETHICS2_BIOETHICS",      3,`label=đạo đức sinh học|desc=bioethics four principles autonomy beneficence nonmaleficence justice Belmont informed consent IRB clinical research|vi=đạo đức sinh học,bioethics|en=bioethics`},
		{"ETHICS2_TECH",           3,`label=đạo đức công nghệ|desc=tech ethics surveillance capitalism algorithmic bias privacy data ownership platform responsibility Zuboff|vi=đạo đức công nghệ,tech ethics|en=tech ethics`},
		{"ETHICS2_ANIMAL",         3,`label=đạo đức với động vật|desc=animal ethics Singer speciesism sentience capacity for suffering veganism factory farming welfare rights Regan|vi=đạo đức với động vật,animal ethics|en=animal ethics`},
		{"ETHICS2_GLOBAL",         3,`label=đạo đức toàn cầu|desc=global ethics cosmopolitanism Pogge world poverty obligation affluent effective altruism Singer drowning child|vi=đạo đức toàn cầu,global ethics|en=global ethics`},
		{"ETHICS2_FUTURE",         3,`label=đạo đức với thế hệ tương lai|desc=intergenerational ethics future generations Rawls veil of ignorance longtermism Ord existential risk moral weight|vi=đạo đức với thế hệ tương lai,future generations ethics|en=future generations ethics`},

		// ── EPISTEMOLOGY & AESTHETICS ─────────────────────────────────
		{"EPISTEMOLOGY_KNOWLEDGE", 3,`label=lý thuyết tri thức|desc=epistemology justified true belief Gettier problem reliabilism virtue externalism internalism foundationalism coherentism|vi=lý thuyết tri thức,epistemology|en=epistemology`},
		{"EPISTEMOLOGY_SKEPTIC",   3,`label=hoài nghi luận|desc=skepticism Descartes evil demon brain in vat Pyrrhonism Academic global local underdetermination closure principle|vi=hoài nghi luận,skepticism|en=skepticism`},
		{"AESTHETICS_BEAUTY",      3,`label=triết học cái đẹp|desc=aesthetics beauty Kant disinterested pleasure sublime Hume standard of taste Plato form Schiller play|vi=triết học cái đẹp,aesthetics beauty|en=aesthetics beauty`},
		{"AESTHETICS_ART_DEF",     3,`label=định nghĩa nghệ thuật|desc=definition of art institutional theory Dickie representational expression formalism Wittgenstein family resemblance Danto artworld|vi=định nghĩa nghệ thuật,definition of art|en=definition of art`},
		{"METAPHYSICS_CAUSATION",  3,`label=nhân quả siêu hình học|desc=causation metaphysics counterfactual regularity mechanism dispositionalism interventionism Lewis INUS condition|vi=nhân quả siêu hình học,causation|en=causation metaphysics`},

		// ── EDUCATION 2 (EDUCATION2_) ────────────────────────────────
		{"EDUCATION2_CONSTRUCTIV", 3,`label=kiến tạo luận giáo dục|desc=constructivism Piaget Vygotsky ZPD scaffolding discovery learning active knowledge construction social mediation|vi=kiến tạo luận giáo dục,constructivism|en=constructivism education`},
		{"EDUCATION2_MONTESSORI",  3,`label=phương pháp Montessori|desc=Montessori method Maria Montessori prepared environment sensitive period absorbent mind intrinsic motivation self-directed|vi=phương pháp Montessori,Montessori|en=Montessori education`},
		{"EDUCATION2_BLOOM",       3,`label=thang phân loại Bloom|desc=Bloom taxonomy remember understand apply analyze evaluate create higher order thinking revised Anderson cognitive|vi=thang phân loại Bloom,Bloom taxonomy|en=Bloom taxonomy`},
		{"EDUCATION2_ASSESSMENT",  3,`label=đánh giá học tập|desc=assessment formative summative authentic performance rubric feedback Hattie effect size growth mindset Dweck|vi=đánh giá học tập,assessment|en=educational assessment`},
		{"EDUCATION2_INCLUSION",   3,`label=giáo dục hòa nhập|desc=inclusive education disability universal design learning UDL IEP differentiation neurodiversity dyslexia ADHD support|vi=giáo dục hòa nhập,inclusive education|en=inclusive education`},

		// ── PUBLIC HEALTH (PUBHEALTH_) ────────────────────────────────
		{"PUBHEALTH_EPIDEMIOL",    3,`label=dịch tễ học|desc=epidemiology incidence prevalence RR OR cohort case-control RCT Bradford Hill criteria causal criteria confounding|vi=dịch tễ học,epidemiology|en=epidemiology`},
		{"PUBHEALTH_VACCINATION",  3,`label=vaccine và chương trình tiêm chủng|desc=vaccination herd immunity schedule GAVI EPI WHO routine immunization cold chain coverage equity hesitancy|vi=vaccine và chương trình tiêm chủng,vaccination|en=vaccination`},
		{"PUBHEALTH_NUTRITION",    3,`label=dinh dưỡng cộng đồng|desc=public health nutrition double burden malnutrition stunting obesity NCD salt sugar fat dietary guideline|vi=dinh dưỡng cộng đồng,public nutrition|en=public health nutrition`},
		{"PUBHEALTH_ANTIMICRO",    3,`label=kháng kháng sinh|desc=antimicrobial resistance AMR superbug ESKAPE WHO priority pathogen stewardship One Health surveillance pandemic|vi=kháng kháng sinh,antimicrobial resistance|en=antimicrobial resistance`},
		{"PUBHEALTH_HEALTH_SYS",   3,`label=hệ thống y tế|desc=health system WHO building blocks financing workforce information service delivery medical supply governance UHC|vi=hệ thống y tế,health system|en=health system`},

		// ── ECONOMICS 3 (ECON3_) ─────────────────────────────────────
		{"ECON3_INEQUALITY2",      3,`label=bất bình đẳng kinh tế|desc=economic inequality Gini Palma Atkinson index top 1% wealth concentration Piketty r>g capital 21st century|vi=bất bình đẳng kinh tế,economic inequality|en=economic inequality`},
		{"ECON3_PLATFORM",         3,`label=kinh tế nền tảng|desc=platform economy two-sided market network effect Amazon Google Meta aggregator toll road data monopoly Rochet Tirole|vi=kinh tế nền tảng,platform economy|en=platform economy`},
		{"ECON3_CIRCULAR",         3,`label=kinh tế tuần hoàn|desc=circular economy cradle-to-cradle Ellen MacArthur zero waste industrial symbiosis sharing repair remanufacture|vi=kinh tế tuần hoàn,circular economy|en=circular economy`},
		{"ECON3_LABOR2",           3,`label=kinh tế lao động|desc=labor economics monopsony minimum wage EITC gig work Autor job polarization automation task model|vi=kinh tế lao động,labor economics|en=labor economics`},
		{"ECON3_TRADE2",           3,`label=thương mại quốc tế|desc=international trade comparative advantage Heckscher-Ohlin gravity model WTO CPTPP trade war tariff infant industry|vi=thương mại quốc tế,international trade|en=international trade`},

		// ── VIETNAM ENVIRONMENT (VNENVIRON_) ─────────────────────────
		{"VNENVIRON_PLASTIC",      3,`label=ô nhiễm nhựa Việt Nam|desc=ô nhiễm nhựa Việt Nam top 5 biển thế giới túi nilon phí túi nhựa sử dụng một lần chính sách 2030|vi=ô nhiễm nhựa Việt Nam,Vietnam plastic pollution|en=Vietnam plastic pollution`},
		{"VNENVIRON_RIVER",        3,`label=ô nhiễm sông Việt Nam|desc=ô nhiễm sông Nhuệ Đáy Thị Vải Tô Lịch nước thải công nghiệp làng nghề xử lý nước thải|vi=ô nhiễm sông Việt Nam,Vietnam river pollution|en=Vietnam river pollution`},
		{"VNENVIRON_RENEW",        3,`label=năng lượng tái tạo Việt Nam|desc=năng lượng tái tạo Việt Nam điện gió điện mặt trời PDP8 quy hoạch điện 2030 offshore wind 12GW|vi=năng lượng tái tạo Việt Nam,Vietnam renewable energy|en=Vietnam renewable energy`},
		{"VNENVIRON_FLOOD",        3,`label=ngập lụt đô thị Việt Nam|desc=ngập lụt đô thị TP HCM Hà Nội biến đổi khí hậu triều cường hạ tầng thoát nước BĐKH thích ứng|vi=ngập lụt đô thị Việt Nam,Vietnam urban flood|en=Vietnam urban flood`},
		{"VNENVIRON_BIODIV",       3,`label=đa dạng sinh học Việt Nam|desc=đa dạng sinh học Việt Nam rừng Cúc Phương Cát Tiên Phong Nha phân loài mới IUCN săn bắt bảo tồn|vi=đa dạng sinh học Việt Nam,Vietnam biodiversity|en=Vietnam biodiversity`},

		// ── MUSIC 3 (MUSIC3_) ────────────────────────────────────────
		{"MUSIC3_JAZZ",            3,`label=nhạc jazz|desc=jazz blues swing bebop Miles Davis Kind of Blue John Coltrane Monk improvisation chord substitution modal|vi=nhạc jazz,jazz music|en=jazz music`},
		{"MUSIC3_CLASSICAL",       3,`label=nhạc cổ điển phương Tây|desc=classical music Baroque Classical Romantic Bach Mozart Beethoven Brahms symphony sonata sonata form development|vi=nhạc cổ điển phương Tây,classical music|en=classical music`},
		{"MUSIC3_ELECTRONIC",      3,`label=âm nhạc điện tử|desc=electronic music synthesizer Moog Arp Kraftwerk techno house ambient trance modular patch oscillator filter|vi=âm nhạc điện tử,electronic music|en=electronic music`},
		{"MUSIC3_WORLD",           3,`label=âm nhạc thế giới|desc=world music gamelan flamenco samba afrobeat qawwali maqam pentatonic microtone fusion WOMAD UNESCO|vi=âm nhạc thế giới,world music|en=world music`},
		{"MUSIC3_PRODUCTION",      3,`label=sản xuất âm nhạc|desc=music production DAW mixing mastering compression EQ reverb side-chain stem stem loudness war streaming|vi=sản xuất âm nhạc,music production|en=music production`},

		// ── DANCE (DANCE_) ────────────────────────────────────────────
		{"DANCE_BALLET",           3,`label=ballet|desc=ballet Petipa Diaghilev Balanchine Pina Bausch Nijinsky five positions turnout pointe en dehors romantique|vi=ballet,ballet|en=ballet`},
		{"DANCE_CONTEMPORARY",     3,`label=múa đương đại|desc=contemporary dance improvisation somatic release technique Laban movement analysis effort shape space weight time|vi=múa đương đại,contemporary dance|en=contemporary dance`},
		{"DANCE_HIP_HOP",          3,`label=nhảy hip-hop|desc=hip-hop dance breaking b-boy popping locking waacking voguing battle cipher cipher NYC Bronx culture|vi=nhảy hip-hop,hip-hop dance|en=hip-hop dance`},
		{"DANCE_VNDANCE",          3,`label=múa dân tộc Việt Nam|desc=múa dân tộc Việt Nam múa sạp xòe Thái nón lá Kinh múa chằn Khmer múa Chăm truyền thống|vi=múa dân tộc Việt Nam,Vietnamese folk dance|en=Vietnamese folk dance`},
		{"DANCE_THERAPY",          3,`label=trị liệu bằng múa|desc=dance movement therapy DMT body-mind connection somatic trauma processing embodiment nonverbal Chace Marion|vi=trị liệu bằng múa,dance therapy|en=dance movement therapy`},

		// ── THEATER (THEATER_) ────────────────────────────────────────
		{"THEATER_STANISLAVSKI",   3,`label=phương pháp Stanislavski|desc=Stanislavski system given circumstances magic if emotional memory objectives actions physical action method acting|vi=phương pháp Stanislavski,Stanislavski method|en=Stanislavski method`},
		{"THEATER_BRECHT",         3,`label=kịch Brecht|desc=Brecht epic theater Verfremdungseffekt alienation effect gestus dialectic social political didactic Berliner Ensemble|vi=kịch Brecht,Brecht epic theater|en=Brecht epic theater`},
		{"THEATER_MUSICAL",        3,`label=nhạc kịch|desc=musical theater book lyrics score Rodgers Hammerstein Sondheim Hamilton Chorus Line direction choreography Broadway|vi=nhạc kịch,musical theater|en=musical theater`},
		{"THEATER_IMPROV",         3,`label=ứng tấu|desc=improv theater Second City UCB yes-and status game structure Harold long form short form Viola Spolin|vi=ứng tấu,improv theater|en=improv theater`},
		{"THEATER_VIETNAM",        3,`label=sân khấu Việt Nam|desc=sân khấu Việt Nam tuồng chèo cải lương kịch nói kịch bản hiện đại NSƯT NSND rối nước|vi=sân khấu Việt Nam,Vietnamese theater|en=Vietnamese theater`},

		// ── POETRY (POETRY_) ─────────────────────────────────────────
		{"POETRY_FORM",            3,`label=thể thơ và hình thức|desc=poetry form sonnet villanelle ghazal ode elegy haiku tanka concrete prose syllabic stress accentual|vi=thể thơ và hình thức,poetry form|en=poetry form`},
		{"POETRY_MODERNIST",       3,`label=thơ hiện đại|desc=modernist poetry Eliot Waste Land Pound imagism vorticism Williams Cummings fragmentation stream consciousness|vi=thơ hiện đại,modernist poetry|en=modernist poetry`},
		{"POETRY_CONFESSIONAL",    3,`label=thơ tự thú|desc=confessional poetry Lowell Plath Sexton autobiographical trauma mental illness private public self persona|vi=thơ tự thú,confessional poetry|en=confessional poetry`},
		{"POETRY_SPOKEN_WORD",     3,`label=thơ nói|desc=spoken word poetry slam performance oral tradition Nuyorican cafe Gil Scott-Heron Last Poets beat generation|vi=thơ nói,spoken word poetry|en=spoken word poetry`},
		{"POETRY_VIETNAM",         3,`label=thơ Việt Nam|desc=thơ Việt Nam Nguyễn Du Truyện Kiều lục bát Tản Đà Xuân Diệu Hàn Mặc Tử Chế Lan Viên Nguyễn Bính hiện đại|vi=thơ Việt Nam,Vietnamese poetry|en=Vietnamese poetry`},

		// ── ARCHITECTURE 2 (ARCHITECTURE2_) ──────────────────────────
		{"ARCHITECTURE2_MODERN",   3,`label=kiến trúc hiện đại|desc=modern architecture Bauhaus Le Corbusier Mies van der Rohe Wright International Style functionalism form follows function|vi=kiến trúc hiện đại,modern architecture|en=modern architecture`},
		{"ARCHITECTURE2_VERNAC",   3,`label=kiến trúc bản địa|desc=vernacular architecture climate responsive local material tradition technique passive cooling earthen timber|vi=kiến trúc bản địa,vernacular architecture|en=vernacular architecture`},
		{"ARCHITECTURE2_PARAMETRIC",3,`label=kiến trúc tham số|desc=parametric architecture Zaha Hadid BIG Grasshopper computational design algorithmic optimization facade structure|vi=kiến trúc tham số,parametric architecture|en=parametric architecture`},
		{"ARCHITECTURE2_ADAPTIVE", 3,`label=tái sử dụng thích ứng|desc=adaptive reuse conversion warehouse church factory housing embodied carbon heritage preservation strategy|vi=tái sử dụng thích ứng,adaptive reuse|en=adaptive reuse`},
		{"ARCHITECTURE2_VIETNAM",  3,`label=kiến trúc Việt Nam|desc=kiến trúc Việt Nam đình chùa nhà ống phố Hội An biệt thự Pháp thuộc làng xã đương đại VinGroup|vi=kiến trúc Việt Nam,Vietnamese architecture|en=Vietnamese architecture`},

		// ── LANDSCAPE & HERITAGE ─────────────────────────────────────
		{"LANDSCAPE_ECOLOGY",      3,`label=sinh thái cảnh quan|desc=landscape ecology patch corridor matrix fragmentation connectivity wildlife movement green infrastructure|vi=sinh thái cảnh quan,landscape ecology|en=landscape ecology`},
		{"LANDSCAPE_DESIGN",       3,`label=thiết kế cảnh quan|desc=landscape architecture Olmsted Central Park Burle Marx planting design grading drainage stormwater green roof|vi=thiết kế cảnh quan,landscape design|en=landscape architecture`},
		{"HERITAGE_INTANGIBLE",    3,`label=di sản phi vật thể|desc=intangible cultural heritage UNESCO safeguarding transmission community living heritage disappearance documentation|vi=di sản phi vật thể,intangible heritage|en=intangible cultural heritage`},
		{"HERITAGE_CONSERVATION",  3,`label=bảo tồn di sản|desc=heritage conservation Venice Charter authenticity integrity minimum intervention reversibility documentation Riegl values|vi=bảo tồn di sản,heritage conservation|en=heritage conservation`},
		{"SACRED_SPACE",           3,`label=không gian thiêng liêng|desc=sacred space Eliade hierophany axis mundi threshold pilgrimage shrine temple mosque cathedral orientation cosmology|vi=không gian thiêng liêng,sacred space|en=sacred space`},

		// ── URBANISM 2 (URBANISM2_) ──────────────────────────────────
		{"URBANISM2_NEW",          3,`label=đô thị mới|desc=new urbanism Congress CNU walkable mixed-use TOD transit-oriented development Andres Duany Seaside Celebration|vi=đô thị mới,new urbanism|en=new urbanism`},
		{"URBANISM2_RESILIENT",    3,`label=đô thị kiên cường|desc=resilient city Rockefeller 100RC bounce-forward climate adaptation redundancy redundancy diversity multifunctionality|vi=đô thị kiên cường,resilient city|en=resilient city`},
		{"URBANISM2_PUBLIC",       3,`label=không gian công cộng|desc=public space Gehl life between buildings human scale activation programming ownership safety inclusivity|vi=không gian công cộng,public space|en=public space`},
		{"URBANISM2_MOBILITY",     3,`label=giao thông đô thị|desc=urban mobility mode share BRT LRT cycling pedestrian MAAS mobility as service congestion pricing demand management|vi=giao thông đô thị,urban mobility|en=urban mobility`},
		{"URBANISM2_HEAT",         3,`label=đảo nhiệt đô thị|desc=urban heat island albedo impervious surface tree canopy green roof cool pavement biophilic mitigation|vi=đảo nhiệt đô thị,urban heat island|en=urban heat island`},

		// ── MENTAL HEALTH 3 (MENTAL3_) ───────────────────────────────
		{"MENTAL3_ANXIETY",        3,`label=rối loạn lo âu|desc=anxiety disorder GAD panic social phobia PTSD OCD DSM-5 CBT exposure response prevention medication SSRIs|vi=rối loạn lo âu,anxiety disorder|en=anxiety disorder`},
		{"MENTAL3_DEPRESSION",     3,`label=trầm cảm|desc=depression MDD dysthymia bipolar PHQ-9 antidepressant SSRI SNRI ketamine TMS ECT behavioral activation|vi=trầm cảm,depression|en=depression`},
		{"MENTAL3_PSYCHOSIS",      3,`label=rối loạn tâm thần phân liệt|desc=psychosis schizophrenia positive negative symptoms dopamine hypothesis antipsychotic clozapine cognitive remediation early intervention|vi=rối loạn tâm thần phân liệt,psychosis|en=psychosis schizophrenia`},
		{"MENTAL3_STIGMA",         3,`label=kỳ thị sức khỏe tâm thần|desc=mental health stigma contact theory education label structural discrimination help-seeking barrier Vietnam context|vi=kỳ thị sức khỏe tâm thần,mental health stigma|en=mental health stigma`},
		{"MENTAL3_MINDFULNESS",    3,`label=chánh niệm|desc=mindfulness MBSR Kabat-Zinn MBCT meditation present moment awareness acceptance non-judgmental rumination|vi=chánh niệm,mindfulness|en=mindfulness`},

		// ── REHABILITATION (REHAB_) ───────────────────────────────────
		{"REHAB_PHYSIO",           3,`label=vật lý trị liệu|desc=physiotherapy musculoskeletal manual therapy exercise therapeutic ultrasound TENS neurological rehabilitation|vi=vật lý trị liệu,physiotherapy|en=physiotherapy`},
		{"REHAB_OCCUP",            3,`label=hoạt động trị liệu|desc=occupational therapy ADL IADL sensory integration pediatric hand therapy mental health assistive technology|vi=hoạt động trị liệu,occupational therapy|en=occupational therapy`},
		{"REHAB_SPEECH",           3,`label=ngôn ngữ trị liệu|desc=speech language pathology dysphasia aphasia stuttering voice AAC augmentative alternative communication swallowing|vi=ngôn ngữ trị liệu,speech therapy|en=speech language therapy`},
		{"REHAB_CARDIAC",          3,`label=phục hồi tim mạch|desc=cardiac rehabilitation exercise prescription risk factor modification education adherence phase 1 2 3 secondary prevention|vi=phục hồi tim mạch,cardiac rehabilitation|en=cardiac rehabilitation`},
		{"REHAB_NEURO",            3,`label=phục hồi thần kinh|desc=neurological rehabilitation stroke TBI SCI plasticity constraint induced movement therapy robot-assisted FES tDCS|vi=phục hồi thần kinh,neurological rehabilitation|en=neurological rehabilitation`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 4000 { fmt.Println(" MILESTONE 4000! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
