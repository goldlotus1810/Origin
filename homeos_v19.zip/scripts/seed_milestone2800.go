//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── QUẢN TRỊ (MGMT_) ─────────────────────────────────────
		{"MGMT_LEADERSHIP",   3, `label=lãnh đạo|desc=khả năng dẫn dắt tổ chức transformational servant situational Drucker vision|vi=lãnh đạo,leadership|en=leadership|zh=领导力`},
		{"MGMT_STRATEGY",     3, `label=chiến lược kinh doanh|desc=Porter 5 forces SWOT Blue Ocean competitive advantage BCG matrix|vi=chiến lược kinh doanh,business strategy|en=business strategy|zh=商业战略`},
		{"MGMT_AGILE",        3, `label=Agile|desc=phương pháp phát triển linh hoạt Scrum Kanban sprint backlog retrospective phần mềm|vi=Agile,Scrum,Kanban|en=Agile methodology|zh=敏捷开发`},
		{"MGMT_OKR",          3, `label=OKR|desc=Objectives and Key Results Google Intel John Doerr mục tiêu đo lường kết quả|vi=OKR,Objectives Key Results|en=OKR|zh=OKR目标管理`},
		{"MGMT_STARTUP",      3, `label=khởi nghiệp|desc=startup Lean startup Eric Ries MVP product-market fit unicorn venture capital|vi=khởi nghiệp,startup|en=startup|zh=创业`},

		// ── CÔNG NGHỆ BLOCKCHAIN (BLOCKCHAIN2_) ─────────────────
		{"BLOCKCHAIN2_SMART", 3, `label=hợp đồng thông minh|desc=smart contract tự thực thi Ethereum Solidity điều kiện phi tập trung|vi=hợp đồng thông minh,smart contract|en=smart contract|zh=智能合约`},
		{"BLOCKCHAIN2_NFT",   3, `label=NFT|desc=non-fungible token token không thể thay thế nghệ thuật số quyền sở hữu OpenSea|vi=NFT,non-fungible token|en=NFT|zh=非同质化代币`},
		{"BLOCKCHAIN2_DEFI",  3, `label=DeFi|desc=tài chính phi tập trung decentralized finance Uniswap Aave yield farming liquidity|vi=DeFi,tài chính phi tập trung|en=DeFi|zh=去中心化金融`},
		{"BLOCKCHAIN2_WEB3",  3, `label=Web3|desc=internet phi tập trung blockchain ownership creator economy DAO token|vi=Web3|en=Web3|zh=Web3`},

		// ── KHOA HỌC THẦN KINH NHẬN THỨC (COGNEURO_) ────────────
		{"COGNEURO_MEMORY",   3, `label=trí nhớ thần kinh|desc=hippocampus long-term potentiation engram memory consolidation sleep REM|vi=trí nhớ thần kinh,memory neuroscience|en=memory neuroscience|zh=记忆神经科学`},
		{"COGNEURO_EMOTION",  3, `label=cảm xúc và não|desc=amygdala cortex limbic system dopamine serotonin oxytocin cảm xúc cơ bản|vi=cảm xúc và não,emotion brain|en=emotion and brain|zh=情感与大脑`},
		{"COGNEURO_SLEEP",    3, `label=giấc ngủ thần kinh|desc=REM NREM sóng delta theta circadian rhythm melatonin củng cố ký ức|vi=giấc ngủ thần kinh,sleep science|en=sleep neuroscience|zh=睡眠神经科学`},
		{"COGNEURO_PAIN",     3, `label=đau và não|desc=nociception cảm giác đau thalamus cortex opioid receptor placebo chronic pain|vi=đau và não,pain|en=pain neuroscience|zh=疼痛神经科学`},

		// ── ĐỊA LÝ KINH TẾ (ECOGEO_) ────────────────────────────
		{"ECOGEO_SUPPLY_CHAIN",3,`label=chuỗi cung ứng toàn cầu|desc=global supply chain just-in-time reshoring nearshoring COVID disruption semiconductor|vi=chuỗi cung ứng,supply chain|en=global supply chain|zh=全球供应链`},
		{"ECOGEO_SEZ",        3, `label=khu kinh tế đặc biệt|desc=Special Economic Zone Trung Quốc Thâm Quyến ưu đãi thuế đầu tư nước ngoài|vi=khu kinh tế đặc biệt,SEZ|en=Special Economic Zone|zh=经济特区`},
		{"ECOGEO_PORT",       3, `label=cảng biển quốc tế|desc=Singapore Shanghai Rotterdam cảng container throughput TEU logistics trung chuyển|vi=cảng biển quốc tế,port|en=international port|zh=国际港口`},

		// ── SỨC KHỎE VẬN ĐỘNG (EXERCISE_) ───────────────────────
		{"EXERCISE_CARDIO",   3, `label=tập thể dục tim mạch|desc=cardio aerobic VO2 max chạy bộ bơi lội đạp xe 150 phút/tuần WHO|vi=cardio,tim mạch,aerobic|en=cardio exercise|zh=有氧运动`},
		{"EXERCISE_STRENGTH", 3, `label=tập sức mạnh|desc=strength training resistance progressive overload hypertrophy protein synthesis|vi=tập sức mạnh,gym,weightlifting|en=strength training|zh=力量训练`},
		{"EXERCISE_YOGA",     3, `label=yoga|desc=thực hành thể chất tâm linh Ấn Độ asana pranayama meditation Patanjali 8 nhánh|vi=yoga|en=yoga|zh=瑜伽`},
		{"EXERCISE_SPORT_SCI",3, `label=khoa học thể thao|desc=sports science biomechanics periodization recovery overtraining VO2 max lactate|vi=khoa học thể thao,sports science|en=sports science|zh=运动科学`},

		// ── LỊCH SỬ CHÂU MỸ (AMERHIST_) ─────────────────────────
		{"AMERHIST_CIVIL_WAR",3, `label=Nội chiến Mỹ|desc=1861-1865 Bắc Nam Lincoln bãi bỏ nô lệ Gettysburg Appomattox|vi=Nội chiến Mỹ,American Civil War|en=American Civil War|zh=美国内战`},
		{"AMERHIST_AZTEC",    3, `label=đế quốc Aztec|desc=Mesoamerica Mexico Tenochtitlan Moctezuma Cortés 1521 lịch Aztec nông nghiệp|vi=đế quốc Aztec,Aztec|en=Aztec Empire|zh=阿兹特克帝国`},
		{"AMERHIST_INCA",     3, `label=đế quốc Inca|desc=Nam Mỹ Peru Quechua Cuzco Machu Picchu Pizarro đường Inca|vi=đế quốc Inca,Inca|en=Inca Empire|zh=印加帝国`},
		{"AMERHIST_COLDWAR_US",3,`label=Mỹ thời Chiến tranh Lạnh|desc=Truman Marshall Plan Korea Cuba Vietnam détente Reagan SDI|vi=Mỹ Chiến tranh Lạnh,Cold War USA|en=US Cold War|zh=冷战时期美国`},

		// ── PHẬT GIÁO & TÔN GIÁO ĐÔNG Á (EASREL_) ───────────────
		{"EASREL_ZEN",        3, `label=Thiền tông|desc=Zen Buddhism thiền định koan tức thời giác ngộ Suzuki Thích Nhất Hạnh mindfulness|vi=Thiền tông,Zen,thiền|en=Zen Buddhism|zh=禅宗`},
		{"EASREL_SHINTO",     3, `label=Shinto|desc=tôn giáo bản địa Nhật Bản kami thiên nhiên đền thờ torii lễ hội matsuri|vi=Shinto,Thần đạo|en=Shinto|zh=神道教`},
		{"EASREL_HINDUISM",   3, `label=Ấn Độ giáo|desc=tôn giáo cổ nhất Brahma Vishnu Shiva karma samsara moksha Vedas|vi=Ấn Độ giáo,Hinduism|en=Hinduism|zh=印度教`},

		// ── VẬT LÝ HIỆN ĐẠI BỔ SUNG (MODPHYS_) ──────────────────
		{"MODPHYS_ENTANGLE",  3, `label=vướng víu lượng tử|desc=quantum entanglement Einstein spooky action Bell test thông tin lượng tử|vi=vướng víu lượng tử,quantum entanglement|en=quantum entanglement|zh=量子纠缠`},
		{"MODPHYS_DECOHERENCE",3,`label=giải kết hợp lượng tử|desc=decoherence mất tính lượng tử môi trường nhiễu loạn máy tính lượng tử|vi=giải kết hợp,decoherence|en=quantum decoherence|zh=量子退相干`},
		{"MODPHYS_STANDARD",  3, `label=mô hình chuẩn|desc=Standard Model quark lepton boson lực cơ bản Higgs 2012 LHC phần tử cơ bản|vi=mô hình chuẩn,Standard Model|en=Standard Model|zh=标准模型`},

		// ── KỸ THUẬT PHẦN MỀM (SOFTENG_) ─────────────────────────
		{"SOFTENG_SOLID",     3, `label=nguyên tắc SOLID|desc=Single Responsibility Open-Closed Liskov Interface Segregation Dependency Inversion|vi=SOLID,nguyên tắc SOLID|en=SOLID principles|zh=SOLID原则`},
		{"SOFTENG_DESIGN_PAT",3, `label=design pattern|desc=Gang of Four singleton factory observer strategy decorator MVC kiến trúc phần mềm|vi=design pattern,mẫu thiết kế|en=design pattern|zh=设计模式`},
		{"SOFTENG_MICROSERV", 3, `label=microservices|desc=kiến trúc vi dịch vụ Docker Kubernetes REST API gRPC service mesh Netflix|vi=microservices,vi dịch vụ|en=microservices|zh=微服务`},
		{"SOFTENG_DEVOPS",    3, `label=DevOps|desc=CI/CD pipeline Jenkins GitHub Actions Docker Kubernetes monitoring logging|vi=DevOps,CI/CD|en=DevOps|zh=DevOps`},

		// ── KHOA HỌC TÂM LÝ BỔ SUNG (PSYCH2_EXTRA) ──────────────
		{"PSYCH2_MOTIVATION",  3, `label=động lực|desc=Maslow hierarchy needs intrinsic extrinsic self-determination SDT Ryan Deci|vi=động lực,motivation|en=motivation|zh=动机`},
		{"PSYCH2_PERSONALITY", 3, `label=tính cách|desc=Big Five OCEAN personality MBTI openness conscientiousness extraversion agreeableness|vi=tính cách,personality|en=personality|zh=人格`},
		{"PSYCH2_HABIT",       3, `label=thói quen|desc=habit loop cue routine reward Charles Duhigg atomic habits James Clear|vi=thói quen,habit|en=habit|zh=习惯`},

		// ── MÔI TRƯỜNG NƯỚC (WATER_) ─────────────────────────────
		{"WATER_OCEAN_ACID",  3, `label=axit hóa đại dương|desc=CO2 hòa tan nước biển pH giảm san hô rạn coral bleaching|vi=axit hóa đại dương,ocean acidification|en=ocean acidification|zh=海洋酸化`},
		{"WATER_DROUGHT",     3, `label=hạn hán|desc=thiếu nước tự nhiên El Nino nông nghiệp sản xuất lương thực di cư khí hậu|vi=hạn hán,drought|en=drought|zh=干旱`},
		{"WATER_FLOOD",       3, `label=lũ lụt|desc=lũ quét lũ sông đồng bằng ngập lụt biến đổi khí hậu thiệt hại ĐBSCL|vi=lũ lụt,flood|en=flood|zh=洪水`},

		// ── LỊCH SỬ TƯ TƯỞNG (IDEAHIST_) ────────────────────────
		{"IDEAHIST_LIBERALISM",3,`label=chủ nghĩa tự do|desc=liberalism Locke Mill quyền cá nhân tự do kinh tế chính trị dân chủ|vi=chủ nghĩa tự do,liberalism|en=liberalism|zh=自由主义`},
		{"IDEAHIST_CONSERV",  3, `label=chủ nghĩa bảo thủ|desc=conservatism Burke truyền thống ổn định trật tự xã hội gia đình tôn giáo|vi=chủ nghĩa bảo thủ,conservatism|en=conservatism|zh=保守主义`},
		{"IDEAHIST_NATION",   3, `label=chủ nghĩa dân tộc|desc=nationalism nhà nước-quốc gia tự quyết dân tộc identity Anderson imagined community|vi=chủ nghĩa dân tộc,nationalism|en=nationalism|zh=民族主义`},

		// ── ĐỊA LÝ CHÂU PHI (AFRICA_) ────────────────────────────
		{"AFRICA_SAHEL",      3, `label=vùng Sahel|desc=vùng bán khô cằn Nam Sahara Mali Niger Chad Sudan hạn hán đói nghèo|vi=vùng Sahel,Sahel|en=Sahel region|zh=萨赫勒地区`},
		{"AFRICA_GREAT_RIFT", 3, `label=Thung lũng Rift châu Phi|desc=Great Rift Valley 6000km Ethiopia Kenya Tanzania hồ Tanganyika tiến hóa người|vi=Thung lũng Rift châu Phi,Great Rift Valley|en=Great Rift Valley|zh=东非大裂谷`},
		{"AFRICA_ECONOMY",    3, `label=kinh tế châu Phi|desc=tăng trưởng nhanh dân số trẻ tài nguyên khoáng sản Nigeria Ethiopia Kenya|vi=kinh tế châu Phi,Africa economy|en=Africa economy|zh=非洲经济`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"MGMT_STARTUP",      "VNECON_STARTUP",      "relates-to"},
		{"MGMT_AGILE",        "SOFTENG_DEVOPS",      "combines-with"},
		{"BLOCKCHAIN2_DEFI",  "BLOCKCHAIN2_SMART",   "uses"},
		{"BLOCKCHAIN2_WEB3",  "BLOCKCHAIN2_NFT",     "includes"},
		{"COGNEURO_MEMORY",   "COGNEURO_SLEEP",      "consolidated-by"},
		{"COGNEURO_EMOTION",  "PSY_HEALTH_ANXIETY",  "underlies"},
		{"EXERCISE_CARDIO",   "HEALTH2_DIABETES",    "prevents"},
		{"EXERCISE_YOGA",     "COGNEURO_EMOTION",    "regulates"},
		{"AMERHIST_AZTEC",    "LANDMARK_MACHU",      "near"},
		{"AMERHIST_INCA",     "LANDMARK_MACHU",      "built"},
		{"EASREL_ZEN",        "EASPHIL_BUDDHISM",    "branch-of"},
		{"MODPHYS_STANDARD",  "APPPHYS_SEMICOND",    "explains"},
		{"MODPHYS_ENTANGLE",  "FUTURE_NEURALINK",    "enables"},
		{"SOFTENG_MICROSERV", "SOFTENG_DEVOPS",      "uses"},
		{"SOFTENG_DESIGN_PAT","CS_ALGORITHM",        "applied-to"},
		{"PSYCH2_MOTIVATION", "PSYCH2_HABIT",        "drives"},
		{"WATER_OCEAN_ACID",  "ECO2_BIODIVERSITY",   "threatens"},
		{"IDEAHIST_LIBERALISM","POLINT_DEMOCRACY",   "foundation-of"},
		{"AFRICA_ECONOMY",    "SDG_POVERTY",         "addresses"},
		{"AFRICA_GREAT_RIFT", "EVOBIO_SPECIATION",   "site-of"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2800 { fmt.Println("🎉 MILESTONE 2800!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"relates-to":1,"combines-with":2,"uses":3,"includes":4,"consolidated-by":5,
		"underlies":6,"prevents":7,"regulates":8,"near":9,"built":10,
		"branch-of":11,"explains":12,"enables":13,"applied-to":14,"drives":15,
		"threatens":16,"foundation-of":17,"addresses":18,"site-of":19,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
