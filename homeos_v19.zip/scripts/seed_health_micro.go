//go:build ignore
// go run scripts/seed_health_micro.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── Y TẾ CÔNG CỘNG ────────────────────────────────────────
		{"PH_EPIDEMIC",     3, `label=dịch bệnh|desc=sự lây lan nhanh của bệnh truyền nhiễm trong cộng đồng lớn dịch cúm COVID đại dịch toàn cầu|vi=dịch bệnh,epidemic,dịch|en=epidemic,pandemic|zh=流行病`},
		{"PH_QUARANTINE",   3, `label=cách ly|desc=tách biệt người bệnh hoặc tiếp xúc để ngăn lây lan dịch bệnh kiểm dịch biên giới|vi=cách ly,quarantine|en=quarantine,isolation|zh=隔离`},
		{"PH_SANITATION",   3, `label=vệ sinh|desc=thực hành giữ sạch môi trường để phòng ngừa bệnh tật nước sạch xử lý rác thải|vi=vệ sinh,sanitation,hygiene|en=sanitation,hygiene|zh=卫生`},
		{"PH_WHO",          3, `label=WHO|desc=Tổ chức Y tế Thế giới cơ quan Liên Hợp Quốc điều phối y tế toàn cầu chuẩn mực y tế quốc tế|vi=WHO,Tổ chức Y tế Thế giới|en=WHO,World Health Organization|zh=世界卫生组织`},
		{"PH_ANTIBIOTIC",   3, `label=kháng sinh|desc=thuốc tiêu diệt hoặc ức chế vi khuẩn penicillin amoxicillin kháng kháng sinh AMR|vi=kháng sinh,antibiotic|en=antibiotic|zh=抗生素`},
		{"PH_CANCER",       3, `label=ung thư|desc=bệnh tế bào phân chia không kiểm soát xâm lấn mô xung quanh phổi vú đại tràng gan|vi=ung thư,cancer|en=cancer|zh=癌症`},
		{"PH_DIABETES",     3, `label=tiểu đường|desc=bệnh rối loạn chuyển hóa đường huyết insulin type 1 type 2 quản lý đường huyết|vi=tiểu đường,đái tháo đường,diabetes|en=diabetes|zh=糖尿病`},
		{"PH_OBESITY",      3, `label=béo phì|desc=tình trạng tích lũy mỡ quá mức BMI trên 30 nguy cơ tim mạch tiểu đường|vi=béo phì,obesity|en=obesity|zh=肥胖`},
		{"PH_AGING",        3, `label=lão hóa|desc=quá trình sinh học tích lũy thiệt hại tế bào theo thời gian giảm chức năng cơ thể tuổi thọ|vi=lão hóa,aging|en=aging,ageing|zh=衰老`},
		{"PH_GENOME",       3, `label=bộ gen|desc=toàn bộ thông tin di truyền của một sinh vật DNA nhiễm sắc thể hệ gen người|vi=bộ gen,genome|en=genome|zh=基因组`},

		// ── KINH TẾ VI MÔ / TÀI CHÍNH ────────────────────────────
		{"MICRO_SUPPLY_DEMAND",3,`label=cung cầu|desc=quy luật kinh tế cơ bản giá cân bằng khi cung bằng cầu thị trường tự do|vi=cung cầu,supply demand|en=supply and demand|zh=供需`},
		{"MICRO_PRICE",     3, `label=giá cả|desc=giá trị trao đổi của hàng hóa dịch vụ giá thị trường giá cố định lạm phát giá|vi=giá cả,price|en=price|zh=价格`},
		{"MICRO_PROFIT",    3, `label=lợi nhuận|desc=phần thu nhập còn lại sau khi trừ chi phí biên lợi nhuận gộp ròng EBITDA|vi=lợi nhuận,profit|en=profit|zh=利润`},
		{"MICRO_COST",      3, `label=chi phí|desc=tiền bỏ ra để sản xuất hàng hóa dịch vụ chi phí cố định biến đổi cơ hội|vi=chi phí,cost|en=cost|zh=成本`},
		{"MICRO_STOCK",     3, `label=cổ phiếu|desc=chứng khoán đại diện quyền sở hữu một phần công ty thị trường chứng khoán NYSE HOSE|vi=cổ phiếu,chứng khoán|en=stock,share,equity|zh=股票`},
		{"MICRO_CRYPTO",    3, `label=tiền mã hóa|desc=tiền kỹ thuật số phi tập trung dựa trên blockchain Bitcoin Ethereum altcoin DeFi|vi=tiền mã hóa,cryptocurrency,Bitcoin|en=cryptocurrency,bitcoin,crypto|zh=加密货币`},
		{"MICRO_DEBT",      3, `label=nợ|desc=nghĩa vụ tài chính phải trả trong tương lai nợ công nợ tư nợ xấu lãi suất|vi=nợ,nợ nần,debt|en=debt|zh=债务`},
		{"MICRO_BUDGET",    3, `label=ngân sách|desc=kế hoạch tài chính thu chi dự toán ngân sách nhà nước doanh nghiệp gia đình|vi=ngân sách,budget|en=budget|zh=预算`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Y tế công cộng
		{"PH_EPIDEMIC",     "MED_VIRUS",        "caused-by"},
		{"PH_EPIDEMIC",     "PH_QUARANTINE",    "managed-by"},
		{"PH_ANTIBIOTIC",   "MED_BACTERIA",     "kills"},
		{"PH_CANCER",       "MED_GENE_THERAPY", "treated-by"},
		{"PH_GENOME",       "MOL_DNA",          "contains"},
		{"PH_DIABETES",     "MED_NUTRITION",    "managed-by"},
		{"PH_OBESITY",      "SPORT_RUNNING",    "reduced-by"},
		{"PH_AGING",        "MED_DNA_REPAIR",   "slowed-by"},
		{"PH_WHO",          "PH_EPIDEMIC",      "monitors"},
		// Kinh tế vi mô
		{"MICRO_SUPPLY_DEMAND","MICRO_PRICE",   "determines"},
		{"MICRO_PROFIT",    "MICRO_COST",       "minus"},
		{"MICRO_CRYPTO",    "TECH_BLOCKCHAIN",  "uses"},
		{"MICRO_STOCK",     "ECON_MARKET",      "traded-in"},
		{"MICRO_CRYPTO",    "ECON_INVESTMENT",  "type-of"},
		{"MICRO_DEBT",      "ECON_INTEREST",    "incurs"},
		{"MICRO_BUDGET",    "ECON_GDP",         "part-of"},
		{"MICRO_PRICE",     "ECON_INFLATION",   "affected-by"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"caused-by":1,"managed-by":2,"kills":3,"treated-by":4,
		"contains":5,"slowed-by":6,"reduced-by":7,"monitors":8,
		"determines":9,"minus":10,"uses":11,"traded-in":12,
		"type-of":13,"incurs":14,"part-of":15,"affected-by":16,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
