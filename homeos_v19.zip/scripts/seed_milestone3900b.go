//go:build ignore
// seed_milestone3900b.go — thêm 20 nodes để đạt MILESTONE 3900
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── COMPLEXITY THEORY ────────────────────────────────────────
		{"COMPLEXITY_P_NP",     3,`label=bài toán P vs NP|desc=P vs NP Millennium Prize polynomial nondeterministic Cook theorem SAT NP-complete reduction 3-SAT graph coloring|vi=bài toán P vs NP,P vs NP|en=P vs NP`},
		{"COMPLEXITY_APPROX",   3,`label=thuật toán xấp xỉ|desc=approximation algorithm TSP vertex cover knapsack PTAS FPTAS greedy ratio bound NP-hard optimization|vi=thuật toán xấp xỉ,approximation algorithm|en=approximation algorithm`},
		{"COMPLEXITY_RANDOM",   3,`label=thuật toán ngẫu nhiên|desc=randomized algorithm Monte Carlo Las Vegas expected time derandomization prime testing Miller-Rabin|vi=thuật toán ngẫu nhiên,randomized algorithm|en=randomized algorithm`},
		// ── HYDROLOGY ────────────────────────────────────────────────
		{"HYDRO_GROUNDWATER",   3,`label=nước ngầm|desc=groundwater aquifer recharge pumping well cone of depression Darcy law hydraulic conductivity contamination remediation|vi=nước ngầm,groundwater|en=groundwater`},
		{"HYDRO_FLOOD",         3,`label=lũ lụt|desc=flood return period 100-year flood catchment runoff peak discharge flood plain mapping early warning evacuation|vi=lũ lụt,flood|en=flood`},
		{"HYDRO_WATERSHED",     3,`label=lưu vực sông|desc=watershed catchment area hydrological cycle evapotranspiration infiltration surface runoff baseflow water balance|vi=lưu vực sông,watershed|en=watershed`},
		// ── POLITICAL SCIENCE ────────────────────────────────────────
		{"POLITICAL_DEMOCRACY", 3,`label=dân chủ và các hình thức|desc=democracy direct representative deliberative liberal illiberal hybrid regime Freedom House Polity score electoral|vi=dân chủ và các hình thức,democracy|en=democracy types`},
		{"POLITICAL_POPULISM",  3,`label=chủ nghĩa dân túy|desc=populism thin ideology people vs elite Mudde Kaltwasser right left Erdogan Bolsonaro Orbán Brexit Trump|vi=chủ nghĩa dân túy,populism|en=populism`},
		{"POLITICAL_GEOPOLIT",  3,`label=địa chính trị|desc=geopolitics Mackinder heartland Mahan sea power Spykman rimland Indo-Pacific pivot South China Sea great power competition|vi=địa chính trị,geopolitics|en=geopolitics`},
		// ── CONFLICT & PEACE ─────────────────────────────────────────
		{"CONFLICT_CIVIL_WAR",  3,`label=nội chiến|desc=civil war greed grievance Collier Hoeffler ethnic religious resource curse duration termination negotiation DDR|vi=nội chiến,civil war|en=civil war`},
		{"CONFLICT_PEACEBUILD", 3,`label=xây dựng hòa bình|desc=peacebuilding reconciliation transitional justice TRC truth commission Gacaca reparations DDR security sector|vi=xây dựng hòa bình,peacebuilding|en=peacebuilding`},
		{"CONFLICT_HYBRID_WAR", 3,`label=chiến tranh hỗn hợp|desc=hybrid warfare grey zone disinformation cyberattack proxy economic coercion deniability Gerasimov doctrine|vi=chiến tranh hỗn hợp,hybrid warfare|en=hybrid warfare`},
		// ── RHETORIC & SEMIOTICS ─────────────────────────────────────
		{"RHETORIC_CLASSICAL",  3,`label=hùng biện cổ điển|desc=classical rhetoric Aristotle ethos pathos logos Cicero deliberative forensic epideictic anaphora chiasmus|vi=hùng biện cổ điển,classical rhetoric|en=classical rhetoric`},
		{"SEMIOTICS_SIGN",      3,`label=ký hiệu học|desc=semiotics sign signifier signified Saussure Peirce index icon symbol code connotation denotation Barthes myth|vi=ký hiệu học,semiotics|en=semiotics`},
		// ── VIETNAM TRANSPORT ────────────────────────────────────────
		{"VNTRANSPORT_METRO",   3,`label=metro Việt Nam|desc=metro Hà Nội tuyến 2A Cát Linh Hà Đông TP HCM tuyến 1 Bến Thành Suối Tiên vận hành công nghệ Nhật Trung|vi=metro Việt Nam,Vietnam metro|en=Vietnam metro`},
		{"VNTRANSPORT_HIGHWAY", 3,`label=cao tốc Việt Nam|desc=cao tốc Việt Nam Bắc Nam 2030 hoàn thành 5000km đầu tư PPP BOT giao thông kết nối vùng kinh tế|vi=cao tốc Việt Nam,Vietnam highway|en=Vietnam highway`},
		{"VNTRANSPORT_PORT",    3,`label=cảng biển Việt Nam|desc=cảng biển Việt Nam Lạch Huyện Cái Mép Thị Vải Đà Nẵng Quy Nhơn logistics chuỗi cung ứng container|vi=cảng biển Việt Nam,Vietnam seaport|en=Vietnam seaport`},
		// ── VIETNAM DIGITAL ──────────────────────────────────────────
		{"VNDIGITAL_GOVTECH",   3,`label=công nghệ quản trị Việt Nam|desc=GovTech Việt Nam Cổng dịch vụ công quốc gia khai sinh điện tử thuế điện tử định danh số 3 tầng|vi=công nghệ quản trị Việt Nam,Vietnam GovTech|en=Vietnam GovTech`},
		{"VNDIGITAL_5G",        3,`label=5G Việt Nam|desc=5G Việt Nam Viettel VinaPhone MobiFone tự phát triển chip 5G Make in Vietnam hạ tầng số băng tần|vi=5G Việt Nam,Vietnam 5G|en=Vietnam 5G`},
		{"VNDIGITAL_AI_VN",     3,`label=AI tại Việt Nam|desc=AI Việt Nam Chiến lược quốc gia 2030 VinAI Zalo AI FPT AI nhận dạng tiếng Việt xử lý ngôn ngữ tự nhiên|vi=AI tại Việt Nam,Vietnam AI|en=Vietnam AI`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3900 { fmt.Println(" MILESTONE 3900! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
