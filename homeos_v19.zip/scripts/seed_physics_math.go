//go:build ignore
// Seed domain Vật lý học + Toán học vào homeos.olang
// Chạy: go run scripts/seed_physics_math.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct {
	name  string
	layer uint8
	dna   string
}

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ Đọc %s: %d bytes, %d nodes, %d edges\n",
		filePath, len(raw), be32(raw[12:16]), be32(raw[16:20]))

	existing := readNames(raw)

	nodes := []Node{
		// ── VẬT LÝ HỌC ──────────────────────────────────────────

		// Cơ học
		{"PHYS_FORCE",       3, `label=lực|desc=đại lượng vector gây ra hoặc thay đổi chuyển động của vật F=ma|vi=lực,force|en=force|zh=力`},
		{"PHYS_MASS",        3, `label=khối lượng|desc=đại lượng vô hướng đo mức quán tính của vật kg|vi=khối lượng,mass|en=mass|zh=质量`},
		{"PHYS_VELOCITY",    3, `label=vận tốc|desc=đại lượng vector mô tả tốc độ và hướng chuyển động m/s|vi=vận tốc,velocity|en=velocity|zh=速度`},
		{"PHYS_ACCELERATION",3, `label=gia tốc|desc=tốc độ thay đổi vận tốc theo thời gian m/s²|vi=gia tốc,acceleration|en=acceleration|zh=加速度`},
		{"PHYS_GRAVITY",     3, `label=trọng lực|desc=lực hút giữa các vật có khối lượng g=9.8 m/s² trên Trái Đất|vi=trọng lực,trọng trường,gravity|en=gravity|zh=重力`},
		{"PHYS_MOMENTUM",    3, `label=động lượng|desc=tích của khối lượng và vận tốc p=mv bảo toàn trong hệ kín|vi=động lượng,momentum|en=momentum|zh=动量`},
		{"PHYS_FRICTION",    3, `label=ma sát|desc=lực cản trở chuyển động giữa hai bề mặt tiếp xúc|vi=ma sát,friction|en=friction|zh=摩擦力`},

		// Nhiệt động lực học
		{"PHYS_TEMPERATURE", 3, `label=nhiệt độ|desc=thước đo mức năng lượng nhiệt trung bình của các phân tử Kelvin Celsius|vi=nhiệt độ,temperature|en=temperature|zh=温度`},
		{"PHYS_HEAT",        3, `label=nhiệt năng|desc=năng lượng truyền do chênh lệch nhiệt độ đơn vị Joule|vi=nhiệt năng,nhiệt lượng,heat|en=heat|zh=热量`},
		{"PHYS_ENTROPY",     3, `label=entropy|desc=đại lượng đo mức độ hỗn loạn hay bất trật tự của hệ thống|vi=entropy,en=entropy|zh=熵`},
		{"PHYS_THERMODYNAMICS",3,`label=nhiệt động lực học|desc=ngành nghiên cứu mối quan hệ nhiệt năng công cơ học và entropy|vi=nhiệt động lực học,thermodynamics|en=thermodynamics|zh=热力学`},

		// Điện từ học
		{"PHYS_CHARGE",      3, `label=điện tích|desc=tính chất cơ bản của vật chất đơn vị Coulomb dương hoặc âm|vi=điện tích,charge|en=electric charge|zh=电荷`},
		{"PHYS_CURRENT",     3, `label=dòng điện|desc=dòng chuyển dịch có hướng của điện tích đơn vị Ampere|vi=dòng điện,current|en=electric current|zh=电流`},
		{"PHYS_VOLTAGE",     3, `label=điện áp|desc=hiệu điện thế giữa hai điểm đơn vị Volt V=IR|vi=điện áp,hiệu điện thế,voltage|en=voltage|zh=电压`},
		{"PHYS_RESISTANCE",  3, `label=điện trở|desc=đại lượng cản trở dòng điện đơn vị Ohm R=V/I|vi=điện trở,resistance|en=resistance|zh=电阻`},
		{"PHYS_MAGNETISM",   3, `label=từ trường|desc=trường vật lý tạo ra bởi điện tích chuyển động và nam châm|vi=từ trường,magnetism|en=magnetism|zh=磁场`},
		{"PHYS_WAVE",        3, `label=sóng|desc=sự lan truyền dao động trong môi trường vật chất hoặc trường điện từ|vi=sóng,wave|en=wave|zh=波`},
		{"PHYS_FREQUENCY",   3, `label=tần số|desc=số dao động trên giây đơn vị Hertz f=1/T|vi=tần số,frequency|en=frequency|zh=频率`},

		// Quang học
		{"PHYS_LIGHT",       3, `label=ánh sáng|desc=bức xạ điện từ 400-700nm mắt người nhìn thấy tốc độ 3×10⁸ m/s|vi=ánh sáng,light|en=light|zh=光`},
		{"PHYS_REFRACTION",  3, `label=khúc xạ|desc=sự thay đổi hướng truyền của ánh sáng khi đi qua môi trường khác|vi=khúc xạ,refraction|en=refraction|zh=折射`},
		{"PHYS_PHOTON",      3, `label=photon|desc=hạt lượng tử của ánh sáng mang năng lượng E=hf|vi=photon,hạt ánh sáng|en=photon|zh=光子`},

		// Vật lý hạt nhân / lượng tử
		{"PHYS_ATOM",        3, `label=nguyên tử|desc=đơn vị cơ bản của vật chất gồm hạt nhân và electron|vi=nguyên tử,atom|en=atom|zh=原子`},
		{"PHYS_ELECTRON",    3, `label=electron|desc=hạt cơ bản mang điện tích âm khối lượng 9.1×10⁻³¹ kg|vi=electron,điện tử|en=electron|zh=电子`},
		{"PHYS_PROTON",      3, `label=proton|desc=hạt trong hạt nhân mang điện tích dương khối lượng ~1836 lần electron|vi=proton,hạt nhân proton|en=proton|zh=质子`},
		{"PHYS_NEUTRON",     3, `label=neutron|desc=hạt trong hạt nhân không mang điện tích khối lượng tương đương proton|vi=neutron,hạt neutron|en=neutron|zh=中子`},
		{"PHYS_ENERGY",      3, `label=năng lượng|desc=khả năng thực hiện công đơn vị Joule E=mc² bảo toàn|vi=năng lượng,energy|en=energy|zh=能量`},

		// ── TOÁN HỌC ────────────────────────────────────────────

		// Số học cơ bản
		{"MATH_NUMBER",      3, `label=số|desc=khái niệm toán học cơ bản để đếm đo lường và tính toán|vi=số,number|en=number|zh=数`},
		{"MATH_INTEGER",     3, `label=số nguyên|desc=tập hợp {...-2,-1,0,1,2,...} không có phần thập phân|vi=số nguyên,integer|en=integer|zh=整数`},
		{"MATH_REAL",        3, `label=số thực|desc=tập hợp số bao gồm số hữu tỷ và vô tỷ biểu diễn trên trục số|vi=số thực,real number|en=real number|zh=实数`},
		{"MATH_COMPLEX",     3, `label=số phức|desc=số có dạng a+bi với i²=-1 mở rộng số thực|vi=số phức,complex number|en=complex number|zh=复数`},
		{"MATH_PRIME",       3, `label=số nguyên tố|desc=số tự nhiên >1 chỉ chia hết cho 1 và chính nó 2 3 5 7 11|vi=số nguyên tố,prime|en=prime number|zh=质数`},

		// Đại số
		{"MATH_FUNCTION",    3, `label=hàm số|desc=ánh xạ mỗi phần tử thuộc tập định nghĩa sang đúng một phần tử tập giá trị|vi=hàm số,hàm,function|en=function|zh=函数`},
		{"MATH_EQUATION",    3, `label=phương trình|desc=biểu thức toán học hai vế bằng nhau cần tìm ẩn số|vi=phương trình,equation|en=equation|zh=方程`},
		{"MATH_MATRIX",      3, `label=ma trận|desc=mảng chữ nhật các số hoặc biểu thức toán học dùng trong đại số tuyến tính|vi=ma trận,matrix|en=matrix|zh=矩阵`},
		{"MATH_VECTOR",      3, `label=vectơ|desc=đại lượng có độ lớn và hướng biểu diễn trong không gian n chiều|vi=vectơ,vector|en=vector|zh=向量`},
		{"MATH_DERIVATIVE",  3, `label=đạo hàm|desc=tốc độ thay đổi của hàm số tại một điểm f'(x)=lim(Δf/Δx)|vi=đạo hàm,derivative|en=derivative|zh=导数`},
		{"MATH_INTEGRAL",    3, `label=tích phân|desc=diện tích dưới đường cong tổng Riemann nghịch đảo đạo hàm|vi=tích phân,integral|en=integral|zh=积分`},
		{"MATH_LIMIT",       3, `label=giới hạn|desc=giá trị hàm số tiến đến khi biến tiến đến một điểm|vi=giới hạn,limit|en=limit|zh=极限`},

		// Hình học
		{"MATH_GEOMETRY",    3, `label=hình học|desc=ngành toán học nghiên cứu hình dạng kích thước và vị trí|vi=hình học,geometry|en=geometry|zh=几何`},
		{"MATH_ANGLE",       3, `label=góc|desc=đại lượng đo sự xoay giữa hai tia xuất phát từ cùng điểm đơn vị radian độ|vi=góc,angle|en=angle|zh=角`},
		{"MATH_TRIANGLE",    3, `label=tam giác|desc=đa giác ba cạnh tổng ba góc bằng 180° định lý Pythagoras|vi=tam giác,triangle|en=triangle|zh=三角形`},
		{"MATH_CIRCLE",      3, `label=hình tròn|desc=tập hợp điểm cách đều tâm một khoảng r chu vi 2πr diện tích πr²|vi=hình tròn,đường tròn,circle|en=circle|zh=圆`},

		// Xác suất / Thống kê
		{"MATH_PROBABILITY", 3, `label=xác suất|desc=số đo khả năng xảy ra của sự kiện từ 0 (không thể) đến 1 (chắc chắn)|vi=xác suất,probability|en=probability|zh=概率`},
		{"MATH_STATISTICS",  3, `label=thống kê|desc=khoa học thu thập phân tích và diễn giải dữ liệu số|vi=thống kê,statistics|en=statistics|zh=统计学`},
		{"MATH_LOGARITHM",   3, `label=logarithm|desc=nghịch đảo của hàm mũ log_b(x)=y khi b^y=x|vi=logarithm,lôgarit|en=logarithm|zh=对数`},
		{"MATH_INFINITY",    3, `label=vô cực|desc=khái niệm toán học lớn hơn mọi số hữu hạn ký hiệu ∞|vi=vô cực,infinity|en=infinity|zh=无穷`},
		{"MATH_PROOF",       3, `label=chứng minh|desc=chuỗi lập luận logic hợp lệ xác lập tính đúng đắn của mệnh đề toán học|vi=chứng minh,proof|en=proof|zh=证明`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Cơ học
		{"PHYS_FORCE",       "PHYS_MASS",        "causes-change-in"},
		{"PHYS_FORCE",       "PHYS_ACCELERATION","causes"},
		{"PHYS_GRAVITY",     "PHYS_FORCE",       "is-a"},
		{"PHYS_FRICTION",    "PHYS_FORCE",       "is-a"},
		{"PHYS_MOMENTUM",    "PHYS_MASS",        "involves"},
		{"PHYS_MOMENTUM",    "PHYS_VELOCITY",    "involves"},
		{"PHYS_VELOCITY",    "PHYS_ACCELERATION","derived-from"},
		// Nhiệt
		{"PHYS_THERMODYNAMICS","PHYS_HEAT",      "studies"},
		{"PHYS_THERMODYNAMICS","PHYS_ENTROPY",   "studies"},
		{"PHYS_THERMODYNAMICS","PHYS_TEMPERATURE","studies"},
		{"PHYS_HEAT",        "PHYS_TEMPERATURE", "related-to"},
		// Điện từ
		{"PHYS_CURRENT",     "PHYS_CHARGE",      "flow-of"},
		{"PHYS_VOLTAGE",     "PHYS_CURRENT",     "drives"},
		{"PHYS_RESISTANCE",  "PHYS_CURRENT",     "opposes"},
		{"PHYS_WAVE",        "PHYS_FREQUENCY",   "has-property"},
		{"PHYS_LIGHT",       "PHYS_WAVE",        "is-a"},
		{"PHYS_PHOTON",      "PHYS_LIGHT",       "quantum-of"},
		{"PHYS_REFRACTION",  "PHYS_LIGHT",       "property-of"},
		// Hạt nhân
		{"PHYS_ATOM",        "PHYS_ELECTRON",    "contains"},
		{"PHYS_ATOM",        "PHYS_PROTON",      "contains"},
		{"PHYS_ATOM",        "PHYS_NEUTRON",     "contains"},
		{"PHYS_ENERGY",      "PHYS_MASS",        "related-to"}, // E=mc²
		// Toán học
		{"MATH_INTEGER",     "MATH_NUMBER",      "is-a"},
		{"MATH_REAL",        "MATH_NUMBER",      "is-a"},
		{"MATH_COMPLEX",     "MATH_REAL",        "extends"},
		{"MATH_PRIME",       "MATH_INTEGER",     "is-a"},
		{"MATH_DERIVATIVE",  "MATH_FUNCTION",    "operates-on"},
		{"MATH_INTEGRAL",    "MATH_FUNCTION",    "operates-on"},
		{"MATH_DERIVATIVE",  "MATH_INTEGRAL",    "inverse-of"},
		{"MATH_LIMIT",       "MATH_DERIVATIVE",  "basis-of"},
		{"MATH_MATRIX",      "MATH_VECTOR",      "contains"},
		{"MATH_EQUATION",    "MATH_FUNCTION",    "uses"},
		{"MATH_TRIANGLE",    "MATH_GEOMETRY",    "part-of"},
		{"MATH_CIRCLE",      "MATH_GEOMETRY",    "part-of"},
		{"MATH_ANGLE",       "MATH_GEOMETRY",    "part-of"},
		{"MATH_PROBABILITY", "MATH_STATISTICS",  "basis-of"},
		{"MATH_LOGARITHM",   "MATH_FUNCTION",    "is-a"},
		// Vật lý ↔ Toán
		{"PHYS_FORCE",       "MATH_VECTOR",      "represented-by"},
		{"PHYS_VELOCITY",    "MATH_VECTOR",      "represented-by"},
		{"PHYS_WAVE",        "MATH_FUNCTION",    "described-by"},
		{"PHYS_ENERGY",      "MATH_EQUATION",    "expressed-in"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] {
			skipped++
			continue
		}
		isl := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, isl, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		lbl := extractLabel(nd.dna)
		fmt.Printf("  ✚  L%d %-25s label=%q\n", nd.layer, nd.name, lbl)
	}

	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		fromISL, ok1 := nodeISLMap[e.from]
		toISL, ok2   := nodeISLMap[e.to]
		if !ok1 || !ok2 { continue }
		raw = appendEdge(raw, fromISL, toISL, e.rel)
		edgeAdded++
	}

	fmt.Printf("\n✚  Thêm: %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, raw, 0644); err != nil { log.Fatal(err) }
	if err := os.Rename(tmp, filePath); err != nil { log.Fatal(err) }
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n",
		len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

// ── helpers (copy từ seed_biology.go) ────────────────────────────

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i
		for j < len(dna) && dna[j] != '|' { j++ }
		part := dna[i:j]
		if len(part) > 6 && part[:6] == "label=" { return part[6:] }
		i = j + 1
	}
	return ""
}

func buildRecord(layer uint8, isl [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], isl[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)
	return rec
}

func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0]=layer; isl[1]=h[0]%200+1; isl[2]=h[1]%200+1; isl[3]=h[2]%200+1
	isl[4]=h[3]; isl[5]=h[4]; isl[6]=h[5]; isl[7]=h[6]
	return isl
}

func insertNode(raw []byte, rec []byte) []byte {
	nedges := int(be32(raw[16:20]))
	nodeEnd := len(raw) - nedges*17
	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:nodeEnd]...)
	out = append(out, rec...)
	out = append(out, raw[nodeEnd:]...)
	n := be32(out[12:16]) + 1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}

func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
		nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne := i+20+dl+nl
		if ne > end { break }
		name := string(raw[i+20+dl : ne])
		var isl8 [8]byte
		copy(isl8[:], raw[i+3:i+11])
		m[name] = isl8
		i = ne
	}
	return m
}

func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	edge := make([]byte, 17)
	binary.BigEndian.PutUint64(edge[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(edge[8:16], binary.BigEndian.Uint64(to[:]))
	edge[16] = relToByte(rel)
	raw = append(raw, edge...)
	n := be32(raw[16:20]) + 1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}

func relToByte(rel string) uint8 {
	m := map[string]uint8{
		"is-a":            1,  "part-of":       2,  "member-of":      3,
		"similar":         4,  "opposite":       5,  "causes":         6,
		"uses":            7,  "produces":       8,  "consumes":       9,
		"contains":        10, "connected-to":   11, "develops-into":  12,
		"transcribes-to":  13, "translates-to":  14, "performs":       15,
		"built-from":      16, "forms-wall-of":  17, "causes-change-in":18,
		"involves":        19, "studies":        20, "related-to":     21,
		"flow-of":         22, "drives":         23, "opposes":        24,
		"has-property":    25, "quantum-of":     26, "property-of":    27,
		"extends":         28, "operates-on":    29, "inverse-of":     30,
		"basis-of":        31, "represented-by": 32, "described-by":   33,
		"expressed-in":    34, "derived-from":   35,
	}
	if b, ok := m[rel]; ok { return b }
	return 0
}

func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
		nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne := i+20+dl+nl
		if ne > end { break }
		m[string(raw[i+20+dl:ne])] = true
		i = ne
	}
	return m
}

func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
