//go:build ignore
// go run scripts/seed_tech_art.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── CÔNG NGHỆ / MÁY TÍNH ─────────────────────────────────
		{"TECH_CPU",         3, `label=CPU|desc=bộ xử lý trung tâm đơn vị tính toán chính của máy tính thực thi hàng tỷ lệnh mỗi giây|vi=CPU,bộ vi xử lý,processor|en=CPU,central processing unit|zh=中央处理器`},
		{"TECH_GPU",         3, `label=GPU|desc=bộ xử lý đồ họa xử lý song song hàng nghìn luồng dùng cho AI và đồ họa 3D|vi=GPU,card đồ họa|en=GPU,graphics processing unit|zh=图形处理器`},
		{"TECH_MEMORY_RAM",  3, `label=RAM|desc=bộ nhớ truy cập ngẫu nhiên lưu dữ liệu đang dùng tốc độ cao mất khi mất điện|vi=RAM,bộ nhớ RAM|en=RAM,random access memory|zh=随机存取存储器`},
		{"TECH_INTERNET",    3, `label=internet|desc=mạng máy tính toàn cầu kết nối hàng tỷ thiết bị qua giao thức TCP/IP|vi=internet,mạng toàn cầu|en=internet|zh=互联网`},
		{"TECH_ALGORITHM",   3, `label=thuật toán|desc=tập hợp hữu hạn bước xác định giải quyết vấn đề hoặc thực hiện tính toán|vi=thuật toán,algorithm|en=algorithm|zh=算法`},
		{"TECH_DATABASE",    3, `label=cơ sở dữ liệu|desc=hệ thống lưu trữ và quản lý dữ liệu có cấu trúc SQL NoSQL|vi=cơ sở dữ liệu,database|en=database|zh=数据库`},
		{"TECH_AI",          3, `label=trí tuệ nhân tạo|desc=mô phỏng trí thông minh con người trong máy tính học máy mạng nơ-ron|vi=trí tuệ nhân tạo,AI,artificial intelligence|en=artificial intelligence|zh=人工智能`},
		{"TECH_ML",          3, `label=học máy|desc=nhánh AI cho phép máy tính học từ dữ liệu cải thiện hiệu suất mà không lập trình tường minh|vi=học máy,machine learning|en=machine learning|zh=机器学习`},
		{"TECH_NEURAL_NET",  3, `label=mạng nơ-ron|desc=mô hình tính toán lấy cảm hứng từ não người với nhiều lớp neuron nhân tạo deep learning|vi=mạng nơ-ron,neural network|en=neural network|zh=神经网络`},
		{"TECH_BLOCKCHAIN",  3, `label=blockchain|desc=chuỗi khối sổ cái phân tán bất biến ghi lại giao dịch qua mạng ngang hàng|vi=blockchain,chuỗi khối|en=blockchain|zh=区块链`},
		{"TECH_CLOUD",       3, `label=điện toán đám mây|desc=cung cấp dịch vụ tính toán lưu trữ qua internet AWS Azure Google Cloud|vi=điện toán đám mây,cloud computing|en=cloud computing|zh=云计算`},
		{"TECH_SEMICONDUCTOR",3,`label=chất bán dẫn|desc=vật liệu dẫn điện một phần silicon germani nền tảng của vi mạch transistor|vi=chất bán dẫn,semiconductor|en=semiconductor|zh=半导体`},
		{"TECH_ENCRYPTION",  3, `label=mã hóa|desc=biến đổi dữ liệu thành dạng không đọc được trừ khi có khóa giải mã bảo mật thông tin|vi=mã hóa,encryption|en=encryption|zh=加密`},
		{"TECH_ROBOT",       3, `label=robot|desc=máy có thể lập trình thực hiện nhiệm vụ tự động hoặc bán tự động robot công nghiệp robot y tế|vi=robot|en=robot|zh=机器人`},
		{"TECH_QUANTUM",     3, `label=máy tính lượng tử|desc=máy tính dùng qubit hiện tượng lượng tử chồng chất vướng víu tính toán nhanh hơn exponential|vi=máy tính lượng tử,quantum computer|en=quantum computer|zh=量子计算机`},

		// ── NGHỆ THUẬT / ÂM NHẠC ──────────────────────────────────
		{"ART_PAINTING",    3, `label=hội họa|desc=nghệ thuật tạo hình ảnh bằng màu sắc trên bề mặt phẳng từ tranh cổ điển đến hiện đại|vi=hội họa,painting|en=painting|zh=绘画`},
		{"ART_SCULPTURE",   3, `label=điêu khắc|desc=nghệ thuật tạo hình ba chiều từ vật liệu như đất sét đá kim loại gỗ|vi=điêu khắc,sculpture|en=sculpture|zh=雕塑`},
		{"ART_MUSIC",       3, `label=âm nhạc|desc=nghệ thuật tổ chức âm thanh theo thời gian tạo ra giai điệu hòa âm nhịp điệu|vi=âm nhạc,music|en=music|zh=音乐`},
		{"ART_INSTRUMENT",  3, `label=nhạc cụ|desc=thiết bị tạo ra âm nhạc đàn piano violin guitar trống flute|vi=nhạc cụ,musical instrument|en=musical instrument|zh=乐器`},
		{"ART_POETRY",      3, `label=thơ ca|desc=hình thức văn học sử dụng ngôn ngữ cô đọng hình ảnh nhịp điệu để biểu đạt cảm xúc|vi=thơ ca,poetry|en=poetry|zh=诗歌`},
		{"ART_FILM",        3, `label=điện ảnh|desc=nghệ thuật tạo ra ảo giác chuyển động bằng cách chiếu chuỗi hình ảnh tĩnh|vi=điện ảnh,phim,film|en=film,cinema|zh=电影`},
		{"ART_DANCE",       3, `label=múa|desc=nghệ thuật biểu diễn dùng chuyển động cơ thể theo nhịp điệu âm nhạc|vi=múa,vũ đạo,dance|en=dance|zh=舞蹈`},
		{"ART_ARCHITECTURE",3, `label=kiến trúc|desc=nghệ thuật và khoa học thiết kế công trình xây dựng kết hợp thẩm mỹ và công năng|vi=kiến trúc,architecture|en=architecture|zh=建筑`},
		{"ART_LITERATURE",  3, `label=văn học|desc=nghệ thuật ngôn từ bao gồm tiểu thuyết truyện ngắn thơ kịch tự truyện|vi=văn học,literature|en=literature|zh=文学`},
		{"ART_COLOR_THEORY",3, `label=lý thuyết màu sắc|desc=khoa học và nghệ thuật sử dụng màu sắc màu cơ bản phối màu tương phản hài hòa|vi=lý thuyết màu sắc,color theory|en=color theory|zh=色彩理论`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Công nghệ nội bộ
		{"TECH_CPU",        "TECH_SEMICONDUCTOR","built-from"},
		{"TECH_GPU",        "TECH_SEMICONDUCTOR","built-from"},
		{"TECH_ML",         "TECH_AI",           "part-of"},
		{"TECH_NEURAL_NET", "TECH_ML",           "method-of"},
		{"TECH_NEURAL_NET", "TECH_GPU",          "accelerated-by"},
		{"TECH_BLOCKCHAIN", "TECH_ENCRYPTION",   "uses"},
		{"TECH_CLOUD",      "TECH_INTERNET",     "runs-on"},
		{"TECH_DATABASE",   "TECH_ALGORITHM",    "uses"},
		{"TECH_ROBOT",      "TECH_AI",           "powered-by"},
		{"TECH_QUANTUM",    "TECH_CPU",          "successor-of"},
		// Công nghệ ↔ Vật lý
		{"TECH_SEMICONDUCTOR","PHYS_ELECTRON",   "controls"},
		{"TECH_QUANTUM",    "PHYS_ENERGY",       "harnesses"},
		{"TECH_ENCRYPTION", "MATH_PRIME",        "relies-on"},
		// Nghệ thuật nội bộ
		{"ART_MUSIC",       "ART_INSTRUMENT",    "uses"},
		{"ART_FILM",        "ART_MUSIC",         "incorporates"},
		{"ART_DANCE",       "ART_MUSIC",         "accompanies"},
		{"ART_POETRY",      "ART_LITERATURE",    "part-of"},
		{"ART_PAINTING",    "ART_COLOR_THEORY",  "applies"},
		{"ART_ARCHITECTURE","ART_SCULPTURE",     "incorporates"},
		// Nghệ thuật ↔ Toán / Vật lý
		{"ART_MUSIC",       "MATH_FUNCTION",     "described-by"},
		{"ART_ARCHITECTURE","MATH_GEOMETRY",     "uses"},
		{"ART_COLOR_THEORY","PHYS_LIGHT",        "based-on"},
		// Công nghệ ↔ Toán
		{"TECH_ALGORITHM",  "MATH_FUNCTION",     "is-a"},
		{"TECH_ML",         "MATH_STATISTICS",   "uses"},
		{"TECH_AI",         "MATH_MATRIX",       "uses"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-24s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"related-to":3,"causes":4,"uses":5,
		"produces":6,"contains":7,"built-from":8,"method-of":9,
		"accelerated-by":10,"runs-on":11,"powered-by":12,"successor-of":13,
		"controls":14,"harnesses":15,"relies-on":16,"incorporates":17,
		"accompanies":18,"applies":19,"described-by":20,"based-on":21,
		"similar":22,"opposite":23,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
