//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── KHỞI NGHIỆP & ĐỔI MỚI (INNOV_) ──────────────────────
		{"INNOV_DESIGN_THINK",3, `label=tư duy thiết kế|desc=Design Thinking IDEO Stanford d.school empathize define ideate prototype test|vi=tư duy thiết kế,design thinking|en=design thinking|zh=设计思维`},
		{"INNOV_LEAN_CANVAS", 3, `label=Lean Canvas|desc=mô hình kinh doanh một trang Ash Maurya problem solution channels revenue cost|vi=Lean Canvas,mô hình kinh doanh|en=Lean Canvas|zh=精益画布`},
		{"INNOV_OPEN_INNOV",  3, `label=đổi mới mở|desc=Open Innovation Chesbrough sử dụng ý tưởng bên ngoài IP licensing crowdsourcing|vi=đổi mới mở,open innovation|en=open innovation|zh=开放式创新`},
		{"INNOV_DISRUPT",     3, `label=đổi mới phá vỡ|desc=Disruptive Innovation Clayton Christensen thị trường mới giá thấp Netflix Uber|vi=đổi mới phá vỡ,disruptive innovation|en=disruptive innovation|zh=颠覆性创新`},

		// ── KHOA HỌC NÃO BỘ CỤ THỂ (BRAINAREA_) ─────────────────
		{"BRAINAREA_PREFRONTAL",3,`label=vỏ não trước trán|desc=prefrontal cortex ra quyết định kiểm soát xung động lập kế hoạch nhân cách|vi=vỏ não trước trán,prefrontal cortex|en=prefrontal cortex|zh=前额叶皮质`},
		{"BRAINAREA_HIPPOC",  3, `label=hải mã|desc=hippocampus ký ức dài hạn điều hướng không gian Alzheimer London taxi driver|vi=hải mã,hippocampus|en=hippocampus|zh=海马体`},
		{"BRAINAREA_CEREBEL", 3, `label=tiểu não|desc=cerebellum phối hợp vận động thăng bằng tự động hóa kỹ năng đi xe đạp|vi=tiểu não,cerebellum|en=cerebellum|zh=小脑`},

		// ── KINH TẾ VĨ MÔ BỔ SUNG (MACRO2_) ─────────────────────
		{"MACRO2_TRADE_WAR",  3, `label=chiến tranh thương mại|desc=trade war thuế quan Mỹ-Trung 2018 Trump tariff supply chain phân tách|vi=chiến tranh thương mại,trade war|en=trade war|zh=贸易战`},
		{"MACRO2_STAGFLATION",3, `label=stagflation|desc=lạm phát cao thất nghiệp cao tăng trưởng thấp 1970s OPEC khủng hoảng dầu|vi=stagflation,đình lạm|en=stagflation|zh=滞胀`},
		{"MACRO2_AUSTERITY",  3, `label=thắt lưng buộc bụng|desc=austerity cắt giảm chi tiêu công Eurozone 2010 IMF Hy Lạp nợ công|vi=thắt lưng buộc bụng,austerity|en=austerity|zh=紧缩政策`},

		// ── SỨC KHỎE TÂM THẦN NÂNG CAO (MENTAL2_) ───────────────
		{"MENTAL2_THERAPY",   3, `label=liệu pháp tâm lý|desc=psychotherapy CBT DBT ACT psychoanalysis Freud Jung sức khỏe tâm thần|vi=liệu pháp tâm lý,psychotherapy|en=psychotherapy|zh=心理治疗`},
		{"MENTAL2_BURNOUT",   3, `label=kiệt sức|desc=burnout Maslach kiệt sức cảm xúc giảm nhân cách hoàn thành thấp công việc|vi=kiệt sức,burnout|en=burnout|zh=职业倦怠`},
		{"MENTAL2_RESILIENCE",3, `label=khả năng phục hồi|desc=resilience adversity coping trauma growth post-traumatic neuroplasticity|vi=khả năng phục hồi,resilience|en=resilience|zh=心理韧性`},

		// ── KỸ NĂNG MỀM (SOFTSKILL_) ─────────────────────────────
		{"SOFTSKILL_COMM",    3, `label=kỹ năng giao tiếp|desc=verbal nonverbal active listening feedback assertive communication|vi=kỹ năng giao tiếp,communication|en=communication skills|zh=沟通技能`},
		{"SOFTSKILL_NEGOTIAT",3, `label=đàm phán|desc=negotiation BATNA ZOPA Fisher Ury Getting to Yes win-win Harvard|vi=đàm phán,negotiation|en=negotiation|zh=谈判`},
		{"SOFTSKILL_TIME",    3, `label=quản lý thời gian|desc=time management Eisenhower matrix Pomodoro GTD deep work Cal Newport|vi=quản lý thời gian,time management|en=time management|zh=时间管理`},
		{"SOFTSKILL_EMOT",    3, `label=trí tuệ cảm xúc|desc=EQ EI Goleman nhận biết cảm xúc tự điều chỉnh đồng cảm xã hội|vi=trí tuệ cảm xúc,EQ,emotional intelligence|en=emotional intelligence|zh=情商`},

		// ── LỊCH SỬ TRUNG ĐÔNG (MIDEASTHIST_) ───────────────────
		{"MIDEASTHIST_ISLAM", 3, `label=lịch sử Hồi giáo|desc=Muhammad 632 Hồi giáo Sunni Shia Abbasid Ottoman Mecca Medina khalifate|vi=lịch sử Hồi giáo,Islam history|en=Islamic history|zh=伊斯兰历史`},
		{"MIDEASTHIST_OTTOMAN",3,`label=đế quốc Ottoman|desc=Ottoman Empire 1299-1922 Constantinople Istanbul Suleiman Magnificent millet|vi=đế quốc Ottoman,Ottoman|en=Ottoman Empire|zh=奥斯曼帝国`},
		{"MIDEASTHIST_ARAB_SPRING",3,`label=Mùa xuân Ả Rập|desc=Arab Spring 2010-2012 Tunisia Ai Cập Libya Syria mạng xã hội dân chủ hóa|vi=Mùa xuân Ả Rập,Arab Spring|en=Arab Spring|zh=阿拉伯之春`},

		// ── SINH THÁI HỌC BỔ SUNG (ECO3_) ───────────────────────
		{"ECO3_REWILD",       3, `label=tái hoang dã hóa|desc=rewilding tái tạo hệ sinh thái sói Yellowstone keystone species Pleistocene|vi=tái hoang dã hóa,rewilding|en=rewilding|zh=再野化`},
		{"ECO3_URBAN_ECOLOGY",3, `label=sinh thái đô thị|desc=urban ecology heat island green corridor biodiversity thành phố xanh|vi=sinh thái đô thị,urban ecology|en=urban ecology|zh=城市生态学`},
		{"ECO3_WETLAND",      3, `label=vùng đất ngập nước|desc=wetland đầm lầy mangrove đồng bằng lọc nước carbon sink Ramsar|vi=vùng đất ngập nước,wetland|en=wetland|zh=湿地`},

		// ── VẬT LÝ THỰC NGHIỆM (EXPPHYS_) ───────────────────────
		{"EXPPHYS_LASER",     3, `label=laser|desc=khuếch đại ánh sáng bức xạ cảm ứng coherent monochromatic ứng dụng y tế viễn thông|vi=laser|en=laser|zh=激光`},
		{"EXPPHYS_SPECTRO",   3, `label=quang phổ học|desc=spectroscopy phân tích ánh sáng vật chất hấp thụ phát xạ thiên văn|vi=quang phổ học,spectroscopy|en=spectroscopy|zh=光谱学`},
		{"EXPPHYS_PARTICLE",  3, `label=máy gia tốc hạt|desc=particle accelerator LHC CERN proton electron collision Higgs boson nghiên cứu|vi=máy gia tốc hạt,LHC|en=particle accelerator|zh=粒子加速器`},

		// ── CÔNG NGHỆ VIỆT NAM MỚI (VNTECH2_) ────────────────────
		{"VNTECH2_AI_STARTUP",3, `label=AI startup Việt Nam|desc=ecosystem AI Việt Nam VinAI VinBrain Phenikaa-X Cốc Cốc research lab|vi=AI startup Việt Nam,VinAI|en=Vietnam AI startup|zh=越南AI创业`},
		{"VNTECH2_EDTECH",    3, `label=EdTech Việt Nam|desc=ELSA Speak Kiến Guru ứng dụng giáo dục học ngoại ngữ AI toán học|vi=EdTech Việt Nam,ELSA|en=Vietnam EdTech|zh=越南教育科技`},
		{"VNTECH2_ECOM",      3, `label=thương mại điện tử VN|desc=Shopee Lazada Tiki Sendo TikTok Shop thanh toán số hóa thị trường|vi=thương mại điện tử Việt Nam,Shopee|en=Vietnam e-commerce|zh=越南电商`},

		// ── KHOA HỌC VŨ TRỤ ỨNG DỤNG (SPACEAPP_) ────────────────
		{"SPACEAPP_LANDING",  3, `label=hạ cánh lên Mặt Trăng|desc=Apollo 11 1969 Armstrong Aldrin Eagle LM Sea of Tranquility NASA 50 năm|vi=hạ cánh Mặt Trăng,Apollo 11|en=Moon landing|zh=登月`},
		{"SPACEAPP_MARS_MISS",3, `label=sứ mệnh sao Hỏa|desc=Perseverance Curiosity InSight Ingenuity NASA ESA SpaceX Artemis hành trình|vi=sứ mệnh sao Hỏa,Mars mission|en=Mars mission|zh=火星任务`},
		{"SPACEAPP_EXOPLANET",3, `label=ngoại hành tinh|desc=exoplanet Kepler TESS 5000+ phát hiện habitable zone trái đất thứ hai|vi=ngoại hành tinh,exoplanet|en=exoplanet|zh=系外行星`},

		// ── LUẬT DÂN SỰ (CIVILLAW_) ──────────────────────────────
		{"CIVILLAW_CONTRACT", 3, `label=hợp đồng|desc=contract offer acceptance consideration breach remedies specific performance|vi=hợp đồng,contract law|en=contract law|zh=合同法`},
		{"CIVILLAW_TORT",     3, `label=luật bồi thường|desc=tort negligence duty of care breach damages causation Donoghue v Stevenson|vi=luật bồi thường,tort law|en=tort law|zh=侵权法`},
		{"CIVILLAW_PROPERTY", 3, `label=luật tài sản|desc=property law real personal chattel possession title easement mortgage|vi=luật tài sản,property law|en=property law|zh=财产法`},

		// ── ĐỊA LÝ TỰ NHIÊN NÂNG CAO (PHYSGEO2_) ────────────────
		{"PHYSGEO2_GLACIAL",  3, `label=băng hà|desc=glacial period ice age Pleistocene ice sheet Greenland Antarctica glacier retreat|vi=băng hà,ice age,glacial|en=glacial period|zh=冰川期`},
		{"PHYSGEO2_TECTONICS",3, `label=kiến tạo mảng|desc=plate tectonics Wegener continental drift Pangaea subduction fault ring of fire|vi=kiến tạo mảng,plate tectonics|en=plate tectonics|zh=板块构造`},
		{"PHYSGEO2_OCEAN_CUR",3, `label=dòng hải lưu|desc=ocean current thermohaline circulation Gulf Stream conveyor belt ENSO climate|vi=dòng hải lưu,ocean current|en=ocean current|zh=洋流`},

		// ── LỊCH SỬ CHÂU ÂU BỔ SUNG (EURHIST2_) ─────────────────
		{"EURHIST2_WW1",      3, `label=Thế chiến I|desc=1914-1918 Franz Ferdinand trench warfare Western Front League of Nations 20 triệu|vi=Thế chiến I,Thế chiến thứ nhất|en=World War I|zh=第一次世界大战`},
		{"EURHIST2_COLD_EUR", 3, `label=Chiến tranh Lạnh châu Âu|desc=Berlin Wall NATO Warsaw Pact Iron Curtain Cuba crisis détente|vi=Chiến tranh Lạnh châu Âu,Cold War Europe|en=Cold War Europe|zh=欧洲冷战`},
		{"EURHIST2_EU_FOUND", 3, `label=thành lập EU|desc=Treaty of Rome 1957 EEC sáu nước sáng lập Adenauer De Gasperi Monnet hòa bình|vi=thành lập EU,lịch sử EU|en=EU founding|zh=欧盟成立`},

		// ── Y DƯỢC HỌC (PHARMA_) ──────────────────────────────────
		{"PHARMA_ANTIBIOTICS",3, `label=kháng sinh|desc=antibiotic penicillin Fleming 1928 resistance MRSA AMR overuse mechanism|vi=kháng sinh,antibiotic|en=antibiotic|zh=抗生素`},
		{"PHARMA_MRNA",       3, `label=mRNA y học|desc=mRNA technology Moderna BioNTech COVID vaccine Karikó Weissman Nobel 2023|vi=mRNA y học,mRNA vaccine|en=mRNA medicine|zh=mRNA医学`},
		{"PHARMA_GENE_EDIT",  3, `label=chỉnh sửa gen|desc=CRISPR-Cas9 Doudna Charpentier Nobel 2020 gene therapy cut-and-paste DNA|vi=chỉnh sửa gen,CRISPR|en=gene editing|zh=基因编辑`},

		// ── VĂN HÓA ẨM THỰC THẾ GIỚI (GLOBALFOOD_) ──────────────
		{"GLOBALFOOD_SUSHI",  3, `label=sushi|desc=ẩm thực Nhật Bản cơm giấm cá sống nigiri maki omakase UNESCO di sản phi vật thể|vi=sushi|en=sushi|zh=寿司`},
		{"GLOBALFOOD_PASTA",  3, `label=pasta|desc=mì ống Ý spaghetti penne rigatoni lasagna carbonara al dente gluten|vi=pasta,mì ống Ý|en=pasta|zh=意大利面`},
		{"GLOBALFOOD_TACOS",  3, `label=tacos|desc=ẩm thực Mexico ngô tortilla nhân thịt rau salsa guacamole street food UNESCO|vi=tacos|en=tacos|zh=墨西哥卷`},
		{"GLOBALFOOD_CURRY",  3, `label=cà ri|desc=curry Ấn Độ gia vị nghệ cà ri bột masala coconut milk nhiều biến thể Thái Nhật|vi=cà ri,curry|en=curry|zh=咖喱`},

		// ── TOÁN CAO CẤP (ADVMATH_) ───────────────────────────────
		{"ADVMATH_CALCULUS",  3, `label=giải tích|desc=calculus Newton Leibniz đạo hàm tích phân giới hạn liên tục cơ sở vật lý|vi=giải tích,calculus|en=calculus|zh=微积分`},
		{"ADVMATH_LINEAR_ALG",3, `label=đại số tuyến tính|desc=linear algebra ma trận vector eigenvalue eigenvector machine learning neural network|vi=đại số tuyến tính,linear algebra|en=linear algebra|zh=线性代数`},
		{"ADVMATH_PROBABILITY",3,`label=xác suất|desc=probability Bayes theorem random variable distribution Monte Carlo statistics|vi=xác suất,probability|en=probability|zh=概率论`},
		{"ADVMATH_GRAPH_THEORY",3,`label=lý thuyết đồ thị|desc=graph theory Euler Königsberg bridges vertex edge shortest path network|vi=lý thuyết đồ thị,graph theory|en=graph theory|zh=图论`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"INNOV_DESIGN_THINK",  "MGMT_STARTUP",       "used-in"},
		{"INNOV_DISRUPT",       "MGMT_STRATEGY",      "challenges"},
		{"BRAINAREA_HIPPOC",    "COGNEURO_MEMORY",    "location-of"},
		{"BRAINAREA_PREFRONTAL","COGNEURO_EMOTION",   "regulates"},
		{"MACRO2_TRADE_WAR",    "ECOGEO_SUPPLY_CHAIN","disrupts"},
		{"MENTAL2_THERAPY",     "PSY_HEALTH_DEPRESS", "treats"},
		{"MENTAL2_BURNOUT",     "SOFTSKILL_TIME",     "prevented-by"},
		{"SOFTSKILL_EMOT",      "SOFTSKILL_COMM",     "enhances"},
		{"MIDEASTHIST_OTTOMAN", "MIDEASTHIST_ISLAM",  "spreads"},
		{"ECO3_REWILD",         "ECO2_BIODIVERSITY",  "restores"},
		{"ECO3_WETLAND",        "WATER_FLOOD",        "buffers"},
		{"EXPPHYS_PARTICLE",    "MODPHYS_STANDARD",   "tests"},
		{"VNTECH2_AI_STARTUP",  "VNTECH_FPT",         "related-to"},
		{"PHARMA_MRNA",         "MODMED_VACCINE",     "advances"},
		{"PHARMA_GENE_EDIT",    "BIO2_GENE_THERAPY",  "enables"},
		{"PHYSGEO2_TECTONICS",  "PHYSGEO_VOLCANO",    "causes"},
		{"PHYSGEO2_OCEAN_CUR",  "ENV_CLIMATE_CHANGE", "affects"},
		{"EURHIST2_WW1",        "WORLD_COLD_WAR",     "leads-to"},
		{"ADVMATH_LINEAR_ALG",  "ML2_TRANSFORMER",    "foundation-of"},
		{"ADVMATH_PROBABILITY", "DATASCI_STATS",      "basis-of"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2900 { fmt.Println("🎉 MILESTONE 2900!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"used-in":1,"challenges":2,"location-of":3,"regulates":4,"disrupts":5,
		"treats":6,"prevented-by":7,"enhances":8,"spreads":9,"restores":10,
		"buffers":11,"tests":12,"related-to":13,"advances":14,"enables":15,
		"causes":16,"affects":17,"leads-to":18,"foundation-of":19,"basis-of":20,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
