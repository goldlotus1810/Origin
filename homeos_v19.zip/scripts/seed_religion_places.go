//go:build ignore
// go run scripts/seed_religion_places.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── TÔN GIÁO / VĂN HÓA ───────────────────────────────────
		{"REL_BUDDHISM",    3, `label=Phật giáo|desc=tôn giáo và triết học Ấn Độ do Siddhartha Gautama sáng lập tứ diệu đế bát chánh đạo niết bàn|vi=Phật giáo,đạo Phật|en=Buddhism|zh=佛教`},
		{"REL_CHRISTIANITY",3, `label=Thiên Chúa giáo|desc=tôn giáo lớn nhất thế giới dựa trên cuộc đời và giáo huấn của Chúa Giêsu Kinh Thánh|vi=Thiên Chúa giáo,Công giáo,Christianity|en=Christianity|zh=基督教`},
		{"REL_ISLAM",       3, `label=Hồi giáo|desc=tôn giáo độc thần Abraham Allah Muhammad Quran thánh địa Mecca Medina|vi=Hồi giáo,Islam|en=Islam|zh=伊斯兰教`},
		{"REL_HINDUISM",    3, `label=Ấn Độ giáo|desc=tôn giáo đa thần lâu đời nhất thế giới nghiệp chướng luân hồi yoga thiền|vi=Ấn Độ giáo,Hindu|en=Hinduism|zh=印度教`},
		{"REL_FESTIVAL",    3, `label=lễ hội|desc=sự kiện văn hóa cộng đồng kỷ niệm theo mùa hay tôn giáo Tết Trung Thu Giáng Sinh|vi=lễ hội,festival|en=festival|zh=节日`},
		{"REL_TET",         3, `label=Tết Nguyên Đán|desc=lễ hội truyền thống lớn nhất Việt Nam đón năm mới âm lịch hoa đào mai bánh chưng|vi=Tết,Tết Nguyên Đán|en=Vietnamese New Year,Tet|zh=越南春节`},
		{"REL_MEDITATION_2",3, `label=thiền Phật|desc=thực hành thiền định theo truyền thống Phật giáo vipassana zazen mindfulness|vi=thiền Phật,Buddhist meditation|en=Buddhist meditation|zh=佛教冥想`},
		{"REL_TRADITION",   3, `label=phong tục|desc=tập quán truyền thống của một cộng đồng được truyền từ thế hệ này sang thế hệ khác|vi=phong tục,tradition,tục lệ|en=tradition,custom|zh=传统`},
		{"REL_FOLKLORE",    3, `label=văn hóa dân gian|desc=truyền thuyết câu chuyện dân gian âm nhạc nghệ thuật của một dân tộc|vi=văn hóa dân gian,folklore|en=folklore|zh=民俗`},
		{"REL_PHILOSOPHY_E",3, `label=triết học phương Đông|desc=tư tưởng triết học từ châu Á Nho giáo Đạo giáo Phật giáo Lão Tử Khổng Tử|vi=triết học phương Đông,Eastern philosophy|en=Eastern philosophy|zh=东方哲学`},

		// ── ĐỊA DANH VIỆT NAM / CHÂU Á ───────────────────────────
		{"PLACE_HANOI",      3, `label=Hà Nội|desc=thủ đô Việt Nam thành phố nghìn năm văn hiến Hồ Gươm phố cổ Văn Miếu|vi=Hà Nội,hanoi|en=Hanoi|zh=河内`},
		{"PLACE_SAIGON",     3, `label=Sài Gòn|desc=thành phố Hồ Chí Minh trung tâm kinh tế lớn nhất Việt Nam năng động hiện đại|vi=Sài Gòn,TP HCM,TP Hồ Chí Minh,Ho Chi Minh City|en=Ho Chi Minh City,Saigon|zh=胡志明市`},
		{"PLACE_DANANG",     3, `label=Đà Nẵng|desc=thành phố biển miền Trung Việt Nam cầu Rồng bãi biển Mỹ Khê Bà Nà Hills|vi=Đà Nẵng|en=Da Nang|zh=岘港`},
		{"PLACE_HA_LONG",    3, `label=Vịnh Hạ Long|desc=di sản thế giới UNESCO Việt Nam hàng nghìn hòn đảo đá vôi trên biển Quảng Ninh|vi=Vịnh Hạ Long,Hạ Long|en=Ha Long Bay|zh=下龙湾`},
		{"PLACE_HOI_AN",     3, `label=Hội An|desc=đô thị cổ UNESCO Việt Nam đèn lồng phố cổ ẩm thực đặc sắc Quảng Nam|vi=Hội An|en=Hoi An|zh=会安`},
		{"PLACE_HUE",        3, `label=Huế|desc=cố đô triều Nguyễn Việt Nam kinh thành cung điện lăng tẩm ẩm thực hoàng gia|vi=Huế,hue|en=Hue|zh=顺化`},
		{"PLACE_MEKONG",     3, `label=đồng bằng sông Cửu Long|desc=vùng nông nghiệp phì nhiêu nhất Việt Nam lúa gạo trái cây sông Mekong|vi=đồng bằng sông Cửu Long,miền Tây|en=Mekong Delta|zh=湄公河三角洲`},
		{"PLACE_ANGKOR",     3, `label=Angkor Wat|desc=đền đài Hindu Khmer lớn nhất thế giới di sản UNESCO Campuchia biểu tượng kiến trúc châu Á|vi=Angkor Wat|en=Angkor Wat|zh=吴哥窟`},
		{"PLACE_TOKYO",      3, `label=Tokyo|desc=thủ đô Nhật Bản thành phố đông dân nhất thế giới công nghệ văn hóa ẩm thực|vi=Tokyo,Tô-ky-ô|en=Tokyo|zh=东京`},
		{"PLACE_BEIJING",    3, `label=Bắc Kinh|desc=thủ đô Trung Quốc trung tâm chính trị văn hóa Vạn Lý Trường Thành Tử Cấm Thành|vi=Bắc Kinh,Beijing|en=Beijing|zh=北京`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Tôn giáo nội bộ
		{"REL_BUDDHISM",    "REL_MEDITATION_2", "practices"},
		{"REL_MEDITATION_2","SPORT_MEDITATION",  "related-to"},
		{"REL_TET",         "REL_FESTIVAL",      "is-a"},
		{"REL_TET",         "PLACE_HANOI",       "celebrated-in"},
		{"REL_TET",         "REL_TRADITION",     "embodies"},
		{"REL_FOLKLORE",    "REL_TRADITION",     "part-of"},
		{"REL_PHILOSOPHY_E","REL_BUDDHISM",      "includes"},
		{"REL_HINDUISM",    "SPORT_YOGA",        "origin-of"},
		// Tôn giáo ↔ Triết học
		{"REL_BUDDHISM",    "PHIL_CONSCIOUSNESS","relates-to"},
		{"REL_PHILOSOPHY_E","PHIL_ETHICS",       "overlaps"},
		// Địa danh nội bộ Việt Nam
		{"PLACE_HANOI",     "PLACE_HA_LONG",     "near"},
		{"PLACE_SAIGON",    "PLACE_MEKONG",      "gateway-to"},
		{"PLACE_HOI_AN",    "PLACE_HUE",         "near"},
		{"PLACE_DANANG",    "PLACE_HOI_AN",      "near"},
		// Địa danh ↔ domain khác
		{"PLACE_HA_LONG",   "GEO_OCEAN",         "on"},
		{"PLACE_MEKONG",    "GEO_RIVER",         "formed-by"},
		{"PLACE_ANGKOR",    "ART_ARCHITECTURE",  "example-of"},
		{"PLACE_TOKYO",     "TECH_AI",           "hub-of"},
		{"PLACE_SAIGON",    "ECON_STARTUP",      "hub-of"},
		// Ẩm thực Việt Nam ↔ địa danh
		{"FOOD_VN_PHO",     "PLACE_HANOI",       "originated-in"},
		{"FOOD_VN_BUN_BO",  "PLACE_HUE",         "originated-in"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"related-to":3,"practices":4,"embodies":5,
		"includes":6,"origin-of":7,"relates-to":8,"overlaps":9,"near":10,
		"gateway-to":11,"on":12,"formed-by":13,"example-of":14,"hub-of":15,
		"originated-in":16,"celebrated-in":17,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
