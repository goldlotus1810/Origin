//go:build ignore
// seed_milestone5500.go — MILESTONE 5500 — 100 nodes
// Chủ đề: Philosophy, Ethics, Logic, Consciousness, Language Philosophy
// Đây là nền tảng cho IntentAsk + IntentOpinion (người dùng hỏi quan điểm)
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("▶ start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── PHILOSOPHY OF MIND ──────────────────────────────────
		{"CONSCIOUSNESS",       3,`label=ý thức|desc=consciousness hard problem qualia subjective experience phenomenology Chalmers Nagel what is it like to be|vi=ý thức,consciousness|en=consciousness`},
		{"QUALIA",              3,`label=qualia — trải nghiệm chủ quan|desc=qualia subjective experience redness pain Mary room thought experiment inverted spectrum|vi=qualia,subjective experience|en=qualia`},
		{"FREE_WILL",           3,`label=ý chí tự do|desc=free will determinism compatibilism libertarianism hard determinism Libet experiment agency moral responsibility|vi=ý chí tự do,free will|en=free will`},
		{"PERSONAL_IDENTITY",   3,`label=bản sắc cá nhân|desc=personal identity continuity psychological criterion Ship of Theseus teleportation Parfit|vi=bản sắc cá nhân,personal identity|en=personal identity`},
		{"MIND_BODY",           3,`label=vấn đề tâm thân|desc=mind-body problem dualism monism physicalism property dualism functionalism multiple realizability|vi=vấn đề tâm thân,mind-body problem|en=mind-body problem`},
		{"INTENTIONALITY",      3,`label=tính hướng đích|desc=intentionality aboutness Brentano directedness mental states representation Searle Chinese Room|vi=tính hướng đích,intentionality|en=intentionality`},
		{"SELF_CONCEPT",        3,`label=khái niệm bản thân|desc=self concept Hume bundle theory no-self Buddhism narrative self embodied self social construction|vi=khái niệm bản thân,self concept|en=self concept`},

		// ── EPISTEMOLOGY ────────────────────────────────────────
		{"KNOWLEDGE_THEORY",    3,`label=lý thuyết tri thức|desc=epistemology justified true belief Gettier problem foundationalism coherentism reliabilism knowledge|vi=lý thuyết tri thức,epistemology|en=epistemology`},
		{"SKEPTICISM",          3,`label=chủ nghĩa hoài nghi|desc=skepticism Descartes evil demon brain in vat external world problem Pyrrhonism radical doubt|vi=chủ nghĩa hoài nghi,skepticism|en=skepticism`},
		{"PERCEPTION_PHIL",     3,`label=triết học tri giác|desc=perception direct realism representationalism phenomenalism sense data naive realism illusion argument|vi=triết học tri giác,philosophy of perception|en=philosophy of perception`},
		{"TRUTH_THEORY",        3,`label=lý thuyết về sự thật|desc=truth correspondence coherence pragmatic deflationary Tarski semantic theory liar paradox|vi=lý thuyết về sự thật,theory of truth|en=theory of truth`},
		{"INFERENCE",           3,`label=suy luận|desc=inference deductive inductive abductive modus ponens tollens syllogism argument valid sound|vi=suy luận,inference|en=inference`},
		{"BELIEF_JUSTIFICATION",3,`label=niềm tin có căn cứ|desc=belief justification internalism externalism dogmatism default entitlement testimony evidence|vi=niềm tin có căn cứ,justified belief|en=justified belief`},

		// ── FORMAL LOGIC ────────────────────────────────────────
		{"PROPOSITIONAL_LOGIC", 3,`label=logic mệnh đề|desc=propositional logic connectives AND OR NOT implication biconditional truth table tautology contradiction|vi=logic mệnh đề,propositional logic|en=propositional logic`},
		{"PREDICATE_LOGIC",     3,`label=logic vị từ|desc=predicate logic quantifiers universal existential Aristotle syllogism Frege formal language|vi=logic vị từ,predicate logic|en=predicate logic`},
		{"MODAL_LOGIC",         3,`label=logic tình thái|desc=modal logic necessity possibility Kripke possible worlds S4 S5 deontic epistemic temporal|vi=logic tình thái,modal logic|en=modal logic`},
		{"FALLACIES",           3,`label=ngụy biện|desc=logical fallacies ad hominem straw man false dilemma slippery slope appeal to authority circular reasoning|vi=ngụy biện,logical fallacies|en=logical fallacies`},
		{"PARADOX",             3,`label=nghịch lý|desc=paradox liar sorites heap Russell Zeno Banach-Tarski unexpected hanging self-reference|vi=nghịch lý,paradox|en=paradox`},
		{"ARGUMENT_STRUCTURE",  3,`label=cấu trúc lập luận|desc=argument structure premise conclusion valid sound cogent deductive inductive Toulmin model claim warrant|vi=cấu trúc lập luận,argument structure|en=argument structure`},

		// ── ETHICS ──────────────────────────────────────────────
		{"METAETHICS",          3,`label=siêu đạo đức học|desc=metaethics moral realism anti-realism expressivism constructivism error theory Mackie queerness|vi=siêu đạo đức học,metaethics|en=metaethics`},
		{"VIRTUE_ETHICS",       3,`label=đạo đức học đức hạnh|desc=virtue ethics Aristotle eudaimonia phronesis practical wisdom character habituation flourishing|vi=đạo đức học đức hạnh,virtue ethics|en=virtue ethics`},
		{"DEONTOLOGY",          3,`label=đạo đức học nghĩa vụ|desc=deontology Kant categorical imperative duty universal law respect persons never treat as means|vi=đạo đức học nghĩa vụ,deontology|en=deontology`},
		{"CONSEQUENTIALISM",    3,`label=chủ nghĩa hệ quả|desc=consequentialism utilitarianism Mill Bentham greatest happiness act rule preference hedonism|vi=chủ nghĩa hệ quả,consequentialism|en=consequentialism`},
		{"MORAL_PSYCHOLOGY",    3,`label=tâm lý đạo đức|desc=moral psychology Haidt moral foundations disgust care fairness loyalty authority purity trolley problem|vi=tâm lý đạo đức,moral psychology|en=moral psychology`},
		{"APPLIED_ETHICS",      3,`label=đạo đức học ứng dụng|desc=applied ethics bioethics AI ethics animal rights environmental ethics business ethics abortion euthanasia|vi=đạo đức học ứng dụng,applied ethics|en=applied ethics`},
		{"AI_ETHICS",           3,`label=đạo đức AI|desc=AI ethics alignment value alignment bias fairness accountability transparency explainability AGI safety|vi=đạo đức AI,AI ethics|en=AI ethics`},

		// ── PHILOSOPHY OF LANGUAGE ──────────────────────────────
		{"MEANING_THEORY",      3,`label=lý thuyết ý nghĩa|desc=theory of meaning Frege sense reference Wittgenstein use theory truth conditions Grice implicature|vi=lý thuyết ý nghĩa,theory of meaning|en=theory of meaning`},
		{"REFERENCE_THEORY",    3,`label=lý thuyết chỉ chiếu|desc=reference theory proper names description theory causal-historical Kripke rigid designator baptism|vi=lý thuyết chỉ chiếu,reference theory|en=reference theory`},
		{"SPEECH_ACTS",         3,`label=hành động ngôn từ|desc=speech acts Austin How to Do Things with Words illocution perlocution performative promise assertion|vi=hành động ngôn từ,speech acts|en=speech acts`},
		{"LANGUAGE_THOUGHT",    3,`label=ngôn ngữ và tư duy|desc=language thought Sapir-Whorf linguistic relativity Mentalese language of thought Fodor concept|vi=ngôn ngữ và tư duy,language and thought|en=language and thought`},
		{"PRAGMATICS_PHIL",     3,`label=dụng học triết học|desc=pragmatics Grice maxims cooperative principle relevance theory implicature conversational inference|vi=dụng học triết học,philosophical pragmatics|en=philosophical pragmatics`},

		// ── METAPHYSICS ─────────────────────────────────────────
		{"ONTOLOGY",            3,`label=bản thể học|desc=ontology being existence substance property relation universal particular abstract concrete Quine|vi=bản thể học,ontology|en=ontology`},
		{"CAUSALITY_PHIL",      3,`label=triết học nhân quả|desc=causality Hume regularity counterfactual mechanist interventionist necessary connection problem|vi=triết học nhân quả,philosophy of causality|en=philosophy of causality`},
		{"TIME_PHILOSOPHY",     3,`label=triết học về thời gian|desc=philosophy of time A-theory B-theory presentism eternalism growing block McTaggart A-series B-series|vi=triết học về thời gian,philosophy of time|en=philosophy of time`},
		{"POSSIBLE_WORLDS",     3,`label=thế giới khả thể|desc=possible worlds Leibniz modal realism Lewis abstract concretism ersatzism counterpart theory|vi=thế giới khả thể,possible worlds|en=possible worlds`},
		{"EMERGENCE",           3,`label=tính nổi trội|desc=emergence weak strong reduction supervenience multiple realizability complex systems consciousness life|vi=tính nổi trội,emergence|en=emergence`},

		// ── POLITICAL PHILOSOPHY ────────────────────────────────
		{"SOCIAL_CONTRACT",     3,`label=khế ước xã hội|desc=social contract Hobbes Locke Rousseau Rawls original position veil ignorance justice legitimacy|vi=khế ước xã hội,social contract|en=social contract`},
		{"JUSTICE_THEORY",      3,`label=lý thuyết công bằng|desc=justice Rawls difference principle liberty equality Sen capability approach Nozick entitlement|vi=lý thuyết công bằng,theory of justice|en=theory of justice`},
		{"LIBERALISM_PHIL",     3,`label=triết học tự do chủ nghĩa|desc=liberalism Mill harm principle autonomy negative positive liberty Berlin Rawls political liberalism|vi=triết học tự do chủ nghĩa,political liberalism|en=political liberalism`},
		{"DEMOCRACY_THEORY",    3,`label=lý thuyết dân chủ|desc=democratic theory deliberative aggregative epistemic participatory republican Habermas Dahl polyarchy|vi=lý thuyết dân chủ,democratic theory|en=democratic theory`},
		{"POWER_PHIL",          3,`label=triết học về quyền lực|desc=power Foucault disciplinary biopower Arendt power-with Lukes three dimensions Gramsci hegemony|vi=triết học về quyền lực,philosophy of power|en=philosophy of power`},

		// ── AESTHETICS ──────────────────────────────────────────
		{"AESTHETICS_FUND",     3,`label=mỹ học cơ bản|desc=aesthetics beauty sublime Kant disinterested pleasure taste judgment Hume standard of taste|vi=mỹ học cơ bản,aesthetics fundamentals|en=aesthetics fundamentals`},
		{"ART_THEORY",          3,`label=lý thuyết nghệ thuật|desc=art theory representation expression formalism institutional theory Danto artworld Dickie aesthetic experience|vi=lý thuyết nghệ thuật,art theory|en=art theory`},
		{"CREATIVITY_PHIL",     3,`label=triết học sáng tạo|desc=creativity originality inspiration genius Romantic expression Boden conceptual combinatorial exploratory|vi=triết học sáng tạo,philosophy of creativity|en=philosophy of creativity`},

		// ── PHILOSOPHY OF SCIENCE ───────────────────────────────
		{"SCIENCE_DEMARCATION", 3,`label=ranh giới khoa học|desc=demarcation problem Popper falsificationism Kuhn paradigm Lakatos research programme Feyerabend anything goes|vi=ranh giới khoa học,demarcation of science|en=demarcation of science`},
		{"SCIENTIFIC_REALISM",  3,`label=thực tại luận khoa học|desc=scientific realism anti-realism instrumentalism structural realism inference best explanation unobservables|vi=thực tại luận khoa học,scientific realism|en=scientific realism`},
		{"PHILOSOPHY_PHYSICS",  3,`label=triết học vật lý|desc=philosophy of physics spacetime quantum mechanics measurement problem many worlds Copenhagen interpretation|vi=triết học vật lý,philosophy of physics|en=philosophy of physics`},
		{"PHILOSOPHY_BIOLOGY",  3,`label=triết học sinh học|desc=philosophy of biology teleology function natural selection species concept reduction emergence altruism|vi=triết học sinh học,philosophy of biology|en=philosophy of biology`},

		// ── EASTERN PHILOSOPHY ──────────────────────────────────
		{"BUDDHISM_PHIL",       3,`label=triết học Phật giáo|desc=Buddhist philosophy no-self impermanence suffering nirvana dependent origination Madhyamaka Yogacara|vi=triết học Phật giáo,Buddhist philosophy|en=Buddhist philosophy`},
		{"CONFUCIANISM_PHIL",   3,`label=triết học Khổng giáo|desc=Confucianism ren benevolence li ritual yi righteousness junzi exemplary person self-cultivation|vi=triết học Khổng giáo,Confucianism|en=Confucianism`},
		{"TAOISM_PHIL",         3,`label=triết học Đạo giáo|desc=Taoism Tao Te Ching wu wei non-action naturalness spontaneity Laozi Zhuangzi yin yang|vi=triết học Đạo giáo,Taoism|en=Taoism`},
		{"VEDANTA",             3,`label=Vedanta — triết học Hindu|desc=Vedanta Upanishads Brahman Atman Advaita non-duality Shankara consciousness reality maya illusion|vi=Vedanta,Vedanta philosophy|en=Vedanta`},
		{"ZEN_PHIL",            3,`label=thiền học|desc=Zen Buddhism koan zazen satori enlightenment direct experience no-mind beginner mind Suzuki|vi=thiền học,Zen philosophy|en=Zen philosophy`},
		{"VIETNAMESE_PHIL",     3,`label=triết học Việt Nam|desc=triết học Việt Nam tư tưởng Hồ Chí Minh Phật giáo Đại Việt làng xã cộng đồng nhân nghĩa|vi=triết học Việt Nam,Vietnamese philosophy|en=Vietnamese philosophy`},

		// ── CRITICAL THEORY ─────────────────────────────────────
		{"FRANKFURT_SCHOOL",    3,`label=trường phái Frankfurt|desc=Frankfurt school critical theory Adorno Horkheimer Habermas Benjamin instrumental reason culture industry|vi=trường phái Frankfurt,Frankfurt school|en=Frankfurt school`},
		{"POSTSTRUCTURALISM",   3,`label=hậu cấu trúc luận|desc=poststructuralism Derrida deconstruction différance Foucault discourse power knowledge archaeology genealogy|vi=hậu cấu trúc luận,poststructuralism|en=poststructuralism`},
		{"PHENOMENOLOGY",       3,`label=hiện tượng học|desc=phenomenology Husserl intentionality reduction Heidegger being-in-world Merleau-Ponty embodiment Sartre|vi=hiện tượng học,phenomenology|en=phenomenology`},
		{"EXISTENTIALISM",      3,`label=chủ nghĩa hiện sinh|desc=existentialism Sartre bad faith authenticity Camus absurd Heidegger thrownness Kierkegaard leap|vi=chủ nghĩa hiện sinh,existentialism|en=existentialism`},
		{"PRAGMATISM_PHIL",     3,`label=chủ nghĩa thực dụng|desc=pragmatism Peirce James Dewey truth useful belief inquiry experience anti-foundationalism Rorty|vi=chủ nghĩa thực dụng,pragmatism|en=pragmatism`},
		{"ANALYTIC_PHIL",       3,`label=triết học phân tích|desc=analytic philosophy Russell Frege Wittgenstein linguistic turn logical positivism ordinary language clarity|vi=triết học phân tích,analytic philosophy|en=analytic philosophy`},

		// ── PHILOSOPHY OF AI / MIND ─────────────────────────────
		{"TURING_TEST",         3,`label=bài kiểm tra Turing|desc=Turing test imitation game Chinese room Searle syntax semantics strong weak AI understanding|vi=bài kiểm tra Turing,Turing test|en=Turing test`},
		{"COMPUTATIONAL_MIND",  3,`label=tâm trí tính toán|desc=computational theory of mind functionalism symbol manipulation GOFAI connectionism embodied cognition|vi=tâm trí tính toán,computational mind|en=computational mind`},
		{"EXTENDED_MIND",       3,`label=tâm trí mở rộng|desc=extended mind Clark Chalmers cognitive coupling environmental scaffolding smartphone notebook Otto Inga|vi=tâm trí mở rộng,extended mind|en=extended mind`},
		{"ARTIFICIAL_CONSCIOUSNESS",3,`label=ý thức nhân tạo|desc=artificial consciousness machine consciousness IIT global workspace theory phi information integration phenomenal|vi=ý thức nhân tạo,artificial consciousness|en=artificial consciousness`},
		{"TRANSHUMANISM",       3,`label=chủ nghĩa vượt nhân|desc=transhumanism enhancement longevity mind uploading singularity Bostrom superintelligence posthuman|vi=chủ nghĩa vượt nhân,transhumanism|en=transhumanism`},

		// ── PHILOSOPHY OF MATHEMATICS ───────────────────────────
		{"MATH_PLATONISM",      3,`label=chủ nghĩa Platon trong toán học|desc=mathematical Platonism abstract objects independent existence Frege logicism Gödel intuition|vi=chủ nghĩa Platon toán học,mathematical Platonism|en=mathematical Platonism`},
		{"FORMALISM_MATH",      3,`label=hình thức luận toán học|desc=mathematical formalism Hilbert program axioms consistency completeness Gödel incompleteness theorem|vi=hình thức luận toán học,mathematical formalism|en=mathematical formalism`},
		{"INTUITIONISM",        3,`label=chủ nghĩa trực giác|desc=intuitionism Brouwer mental construction excluded middle constructive proof finitism philosophy math|vi=chủ nghĩa trực giác,intuitionism|en=intuitionism`},

		// ── CRITICAL THINKING ───────────────────────────────────
		{"CRITICAL_THINKING",   3,`label=tư duy phản biện|desc=critical thinking analysis evaluation argument bias recognition Socratic method intellectual humility|vi=tư duy phản biện,critical thinking|en=critical thinking`},
		{"COGNITIVE_BIAS",      3,`label=thiên kiến nhận thức|desc=cognitive bias confirmation bias anchoring availability heuristic dunning-kruger sunk cost framing|vi=thiên kiến nhận thức,cognitive bias|en=cognitive bias`},
		{"RHETORIC",            3,`label=tu từ học|desc=rhetoric ethos pathos logos Aristotle persuasion audience argument style classical contemporary|vi=tu từ học,rhetoric|en=rhetoric`},
		{"EPISTEMICS",          3,`label=nhận thức luận ứng dụng|desc=epistemics Bayesian updating calibration forecasting superforecasting rationality overconfidence|vi=nhận thức luận ứng dụng,epistemics|en=epistemics`},
		{"RATIONALITY",         3,`label=lý tính|desc=rationality theoretical practical bounded Simon satisficing optimization expected utility Kahneman system 1 2|vi=lý tính,rationality|en=rationality`},

		// ── PHILOSOPHY OF EMOTION ───────────────────────────────
		{"EMOTION_PHIL",        3,`label=triết học cảm xúc|desc=philosophy of emotion James-Lange somatic marker Damasio appraisal theory Nussbaum cognitive emotions|vi=triết học cảm xúc,philosophy of emotion|en=philosophy of emotion`},
		{"EMPATHY_PHIL",        3,`label=triết học đồng cảm|desc=empathy simulation theory theory of mind mirror neurons Zahavi phenomenological intersubjectivity|vi=triết học đồng cảm,philosophy of empathy|en=philosophy of empathy`},

		// ── PHILOSOPHY OF RELIGION ──────────────────────────────
		{"PHILOSOPHY_RELIGION", 3,`label=triết học tôn giáo|desc=philosophy of religion arguments God ontological cosmological teleological problem of evil faith reason|vi=triết học tôn giáo,philosophy of religion|en=philosophy of religion`},
		{"THEODICY",            3,`label=thần học biện minh|desc=theodicy problem of evil free will defense Plantinga Leibniz best possible world suffering God|vi=thần học biện minh,theodicy|en=theodicy`},
		{"MYSTICISM",           3,`label=huyền học|desc=mysticism direct experience ineffable Stace universal core James varieties religious experience union|vi=huyền học,mysticism|en=mysticism`},

		// ── PHILOSOPHY OF HISTORY ───────────────────────────────
		{"PHILOSOPHY_HISTORY",  3,`label=triết học lịch sử|desc=philosophy of history speculative critical explanation narrative Hegel dialectic Marx materialism Toynbee|vi=triết học lịch sử,philosophy of history|en=philosophy of history`},
		{"HERMENEUTICS",        3,`label=thông diễn học|desc=hermeneutics interpretation Gadamer horizon fusion Ricoeur text meaning Schleiermacher Dilthey circle|vi=thông diễn học,hermeneutics|en=hermeneutics`},

		// ── PHILOSOPHY OF EDUCATION ─────────────────────────────
		{"EDUCATION_PHIL",      3,`label=triết học giáo dục|desc=philosophy of education Dewey experience Freire pedagogy oppressed critical pedagogy Montessori constructivism|vi=triết học giáo dục,philosophy of education|en=philosophy of education`},
		{"LEARNING_THEORY",     3,`label=lý thuyết học tập|desc=learning theory behaviorism Skinner cognitivism Piaget constructivism Vygotsky ZPD scaffolding situated|vi=lý thuyết học tập,learning theory|en=learning theory`},

		// ── PHILOSOPHY OF TECHNOLOGY ────────────────────────────
		{"TECH_PHILOSOPHY",     3,`label=triết học công nghệ|desc=philosophy of technology Heidegger enframing Ellul technique Winner artifacts have politics Borgmann device paradigm|vi=triết học công nghệ,philosophy of technology|en=philosophy of technology`},
		{"DIGITAL_PHILOSOPHY",  3,`label=triết học kỹ thuật số|desc=digital philosophy information ontology Floridi infosphere digital minds virtual reality simulation|vi=triết học kỹ thuật số,digital philosophy|en=digital philosophy`},
	}

	added := 0
	for _, n := range nodes {
		if ex[n.name] { continue }
		raw = appendNode(raw, n.name, n.layer, n.dna)
		added++
	}
	if err := os.WriteFile(filePath, raw, 0644); err != nil { log.Fatal(err) }

	total := be32(raw[12:16])
	fmt.Printf(" +%d (skip %d)\n✓ %d nodes\n", added, len(nodes)-added, total)
	if total >= 5500 { fmt.Println("🎉 MILESTONE 5500!") }
}

func appendNode(raw []byte, name string, layer uint8, dna string) []byte {
	nameB := []byte(name)
	dnaB  := []byte(dna)
	nd    := make([]byte, 2+1+8+4+4+1+len(dnaB)+len(nameB))
	nd[0], nd[1] = 'N', 'D'
	nd[2] = layer
	copy(nd[3:11], make([]byte, 8))
	binary.BigEndian.PutUint32(nd[11:15], uint32(len(dnaB)))
	nd[15] = byte(len(nameB))
	copy(nd[16:], dnaB)
	copy(nd[16+len(dnaB):], nameB)
	raw = append(raw[:len(raw)-32], nd...)
	n := be32(raw[12:16]) + 1
	binary.BigEndian.PutUint32(raw[12:16], n)
	h := sha256.Sum256(raw[:len(raw)-32])
	raw = append(raw, h[:]...)
	return raw
}
func readNames(raw []byte) map[string]bool {
	m := make(map[string]bool)
	i := layerIdxEnd
	for i < len(raw)-32 {
		if i+2 > len(raw)-32 || raw[i] != 'N' || raw[i+1] != 'D' { break }
		dnaLen  := int(binary.BigEndian.Uint32(raw[i+11:i+15]))
		nameLen := int(raw[i+15])
		start   := i + 16 + dnaLen
		if start+nameLen > len(raw)-32 { break }
		m[string(raw[start:start+nameLen])] = true
		i += 16 + dnaLen + nameLen
	}
	return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
// Thêm vào nodes slice — nhưng file đã build ignore
// Run patch script riêng
