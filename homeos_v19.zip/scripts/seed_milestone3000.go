//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── KHOA HỌC NHẬN THỨC (COGSCI_) ─────────────────────────
		{"COGSCI_ATTENTION",  3, `label=sự chú ý|desc=attention cognitive resource spotlight model dual-process Kahneman System 1 2|vi=sự chú ý,attention|en=attention|zh=注意力`},
		{"COGSCI_WORKING_MEM",3, `label=bộ nhớ làm việc|desc=working memory Baddeley phonological loop visuospatial sketchpad central executive|vi=bộ nhớ làm việc,working memory|en=working memory|zh=工作记忆`},
		{"COGSCI_SCHEMA",     3, `label=schema nhận thức|desc=schema Piaget Bartlett khung kiến thức giải thích thông tin mới prototype|vi=schema nhận thức,schema|en=cognitive schema|zh=认知图式`},
		{"COGSCI_METACOG",    3, `label=siêu nhận thức|desc=metacognition Flavell biết mình biết gì học cách học kiểm soát nhận thức|vi=siêu nhận thức,metacognition|en=metacognition|zh=元认知`},

		// ── SINH HỌC PHÂN TỬ (MOLBIO_) ──────────────────────────
		{"MOLBIO_TRANSCRIPTION",3,`label=phiên mã|desc=transcription DNA→RNA RNA polymerase promoter codon gen biểu hiện tế bào nhân|vi=phiên mã,transcription|en=transcription|zh=转录`},
		{"MOLBIO_TRANSLATION",3, `label=dịch mã|desc=translation mRNA→protein ribosome codon anticodon tRNA amino acid chuỗi polypeptide|vi=dịch mã,translation|en=translation|zh=翻译`},
		{"MOLBIO_EPIGENETICS",3, `label=ngoại di truyền|desc=epigenetics methylation histone modification gene expression môi trường không thay đổi DNA|vi=ngoại di truyền,epigenetics|en=epigenetics|zh=表观遗传学`},
		{"MOLBIO_STEM_CELL",  3, `label=tế bào gốc|desc=stem cell pluripotent embryonic iPSC Yamanaka regenerative medicine Dolly|vi=tế bào gốc,stem cell|en=stem cell|zh=干细胞`},

		// ── VẬT LÝ CHẤT RẮN (SOLIDPHYS_) ─────────────────────────
		{"SOLIDPHYS_CRYSTAL", 3, `label=tinh thể học|desc=crystallography X-ray diffraction Bragg unit cell lattice crystal structure protein|vi=tinh thể học,crystallography|en=crystallography|zh=晶体学`},
		{"SOLIDPHYS_CONDUCTOR",3,`label=chất dẫn điện|desc=conductor electrical resistivity free electron metal copper silver gold band theory|vi=chất dẫn điện,conductor|en=electrical conductor|zh=导体`},
		{"SOLIDPHYS_QUANTUM_DOT",3,`label=chấm lượng tử|desc=quantum dot nano semiconductor tunable emission LED TV QLED medical imaging|vi=chấm lượng tử,quantum dot|en=quantum dot|zh=量子点`},

		// ── KINH TẾ TÀI NGUYÊN (RESECON_) ───────────────────────
		{"RESECON_RESOURCE_CURSE",3,`label=lời nguyền tài nguyên|desc=resource curse Dutch disease oil Angola Nigeria quản trị yếu tăng trưởng thấp|vi=lời nguyền tài nguyên,resource curse|en=resource curse|zh=资源诅咒`},
		{"RESECON_MINING",   3, `label=khai khoáng|desc=mining lithium cobalt copper rare earth EV battery supply chain ESG sustainability|vi=khai khoáng,mining|en=mining|zh=采矿业`},
		{"RESECON_FISHERY_ECON",3,`label=kinh tế nghề cá|desc=fishery economics common pool resource tragedy of commons quota IUU fishing|vi=kinh tế nghề cá,fishery economics|en=fishery economics|zh=渔业经济学`},

		// ── LỊCH SỬ CHÂU PHI BỔ SUNG (AFRHIST_) ─────────────────
		{"AFRHIST_COLONIALISM",3,`label=chủ nghĩa thực dân châu Phi|desc=Africa colonialism Berlin 1884 scramble for Africa Britain France Belgium decolonization|vi=thực dân châu Phi,colonialism Africa|en=African colonialism|zh=非洲殖民主义`},
		{"AFRHIST_APARTHEID", 3, `label=chế độ apartheid|desc=South Africa phân biệt chủng tộc Mandela ANC 1994 Truth Reconciliation|vi=chế độ apartheid,apartheid|en=apartheid|zh=种族隔离`},
		{"AFRHIST_EGYPT_MOD", 3, `label=Ai Cập hiện đại|desc=Suez Canal Nasser Sadat Camp David Arab Spring Sisi cairo civilization|vi=Ai Cập hiện đại,Modern Egypt|en=Modern Egypt|zh=现代埃及`},

		// ── ĐỊA LÝ CHÂU Á TRUNG TÂM (CENTRASIA_) ────────────────
		{"CENTRASIA_SILK",    3, `label=Trung Á và Con đường Tơ lụa|desc=Kazakhstan Uzbekistan Tajikistan Soviet Silk Road BRI Timurid Samarkand|vi=Trung Á,Central Asia|en=Central Asia|zh=中亚`},
		{"CENTRASIA_STAN",    3, `label=các nước Stan|desc=Kazakhstan Uzbekistan Kyrgyzstan Tajikistan Turkmenistan hydrocarbon nomadic heritage|vi=các nước Stan,Stan countries|en=Stan countries|zh=斯坦国家`},

		// ── NGÔN NGỮ HỌC ỨNG DỤNG (APPLLING_) ────────────────────
		{"APPLLING_SLA",      3, `label=thụ đắc ngôn ngữ thứ hai|desc=Second Language Acquisition Krashen input hypothesis affective filter immersion|vi=thụ đắc ngôn ngữ thứ hai,SLA|en=Second Language Acquisition|zh=第二语言习得`},
		{"APPLLING_TRANSLA",  3, `label=dịch thuật|desc=translation interpretation machine translation DeepL nuance cultural context|vi=dịch thuật,translation|en=translation|zh=翻译学`},
		{"APPLLING_NLP",      3, `label=xử lý ngôn ngữ tự nhiên|desc=NLP tokenization POS tagging named entity sentiment analysis BERT GPT|vi=xử lý ngôn ngữ tự nhiên,NLP|en=NLP|zh=自然语言处理`},

		// ── CÔNG NGHỆ NĂNG LƯỢNG MỚI (NEWENERGY_) ───────────────
		{"NEWENERGY_BATTERY", 3, `label=pin lưu trữ|desc=lithium-ion battery LFP NMC solid-state EV grid storage GWh Tesla Powerwall|vi=pin lưu trữ,battery|en=battery storage|zh=储能电池`},
		{"NEWENERGY_SMART_GRID",3,`label=lưới điện thông minh|desc=smart grid demand response SCADA AMI renewable integration EV charging|vi=lưới điện thông minh,smart grid|en=smart grid|zh=智能电网`},
		{"NEWENERGY_NUCLEAR_FUSION",3,`label=nhiệt hạch|desc=nuclear fusion ITER tokamak NIF inertial confinement plasma H-bomb infinite energy|vi=nhiệt hạch,nuclear fusion|en=nuclear fusion|zh=核聚变`},

		// ── NGHỆ THUẬT TRÌNH DIỄN (PERF_ART_) ───────────────────
		{"PERF_ART_THEATER",  3, `label=sân khấu|desc=theatre drama Shakespeare Brecht Stanislavski method acting Broadway West End|vi=sân khấu,theatre|en=theatre|zh=戏剧`},
		{"PERF_ART_DANCE",    3, `label=múa|desc=dance ballet contemporary tap choreography Nijinsky Alvin Ailey Martha Graham|vi=múa,dance|en=dance|zh=舞蹈`},
		{"PERF_ART_OPERA",    3, `label=opera|desc=opera nhạc kịch hát cổ điển Wagner Verdi Puccini La Traviata aria soprano|vi=opera|en=opera|zh=歌剧`},
		{"PERF_ART_CIRCUS",   3, `label=xiếc|desc=circus Cirque du Soleil acrobatics juggling aerialist fire performance entertainment|vi=xiếc,circus|en=circus|zh=马戏`},

		// ── TÀI CHÍNH QUỐC TẾ (INTFIN_) ─────────────────────────
		{"INTFIN_FOREX",      3, `label=thị trường ngoại hối|desc=forex FX market $7.5 nghìn tỷ/ngày USD EUR GBP carry trade hedging|vi=thị trường ngoại hối,forex|en=forex market|zh=外汇市场`},
		{"INTFIN_BOND",       3, `label=thị trường trái phiếu|desc=bond market treasury yield curve sovereign corporate duration credit rating|vi=thị trường trái phiếu,bond market|en=bond market|zh=债券市场`},
		{"INTFIN_DERIVATIVE", 3, `label=phái sinh tài chính|desc=financial derivative futures options swap Black-Scholes hedging speculation|vi=phái sinh tài chính,derivative|en=financial derivative|zh=金融衍生品`},

		// ── CHĂM SÓC XÃ HỘI (SOCIAL_CARE_) ─────────────────────
		{"SOCIAL_CARE_ELDERLY",3,`label=chăm sóc người cao tuổi|desc=elderly care aging population nursing home Alzheimer caregiver burnout|vi=chăm sóc người cao tuổi,elderly care|en=elderly care|zh=养老护理`},
		{"SOCIAL_CARE_CHILD", 3, `label=phúc lợi trẻ em|desc=child welfare UNICEF malnutrition education child labor rights CRC|vi=phúc lợi trẻ em,child welfare|en=child welfare|zh=儿童福利`},
		{"SOCIAL_CARE_DISAB", 3, `label=người khuyết tật|desc=disability rights ADA CRPD accessibility inclusion neurodiversity employment|vi=người khuyết tật,disability|en=disability|zh=残疾`},

		// ── LỊCH SỬ CÔNG NGHỆ (TECHHIST_) ───────────────────────
		{"TECHHIST_PRINTING", 3, `label=máy in Gutenberg|desc=Gutenberg printing press 1440 movable type book revolution Reformation literacy|vi=máy in Gutenberg,printing press|en=Gutenberg printing press|zh=古腾堡印刷机`},
		{"TECHHIST_STEAM",    3, `label=động cơ hơi nước|desc=steam engine Watt 1769 industrial revolution locomotive factory power|vi=động cơ hơi nước,steam engine|en=steam engine|zh=蒸汽机`},
		{"TECHHIST_TELEGRAPH",3, `label=điện báo|desc=telegraph Morse code Samuel Morse 1844 long-distance communication submarine cable|vi=điện báo,telegraph|en=telegraph|zh=电报`},
		{"TECHHIST_INTERNET_HIST",3,`label=lịch sử Internet|desc=ARPANET 1969 TCP/IP Tim Berners-Lee WWW 1991 browser Mosaic dot-com|vi=lịch sử Internet,Internet history|en=Internet history|zh=互联网历史`},

		// ── PHƯƠNG PHÁP NGHIÊN CỨU (RESEARCH_) ──────────────────
		{"RESEARCH_METHOD",   3, `label=phương pháp nghiên cứu|desc=research methodology quantitative qualitative mixed methods validity reliability|vi=phương pháp nghiên cứu,research method|en=research methodology|zh=研究方法`},
		{"RESEARCH_PEER_REV", 3, `label=phản biện đồng nghiệp|desc=peer review academic journal Nature Science blind double-blind preprint|vi=phản biện đồng nghiệp,peer review|en=peer review|zh=同行评审`},
		{"RESEARCH_META_AN",  3, `label=phân tích tổng hợp|desc=meta-analysis systematic review Cochrane effect size pooling studies evidence|vi=phân tích tổng hợp,meta-analysis|en=meta-analysis|zh=荟萃分析`},

		// ── SỨC KHỎE MÔI TRƯỜNG (ENVHEALTH_) ────────────────────
		{"ENVHEALTH_AIR_QUAL",3, `label=chất lượng không khí|desc=air quality PM2.5 PM10 AQI WHO ozone NO2 indoor outdoor health|vi=chất lượng không khí,air quality|en=air quality|zh=空气质量`},
		{"ENVHEALTH_LEAD",    3, `label=ô nhiễm chì|desc=lead poisoning children IQ development petrol paint Flint Michigan water|vi=ô nhiễm chì,lead poisoning|en=lead poisoning|zh=铅污染`},
		{"ENVHEALTH_NOISE",   3, `label=ô nhiễm tiếng ồn|desc=noise pollution 85dB hearing loss cardiovascular stress urban WHO limit|vi=ô nhiễm tiếng ồn,noise pollution|en=noise pollution|zh=噪声污染`},

		// ── KINH TẾ HỌC LÝ THUYẾT (ECON_THEORY2_) ───────────────
		{"ECON_THEORY2_GAME", 3, `label=lý thuyết trò chơi|desc=game theory Nash equilibrium prisoner dilemma zero-sum Schelling focal point|vi=lý thuyết trò chơi,game theory|en=game theory|zh=博弈论`},
		{"ECON_THEORY2_AUCTION",3,`label=lý thuyết đấu giá|desc=auction theory Milgrom Wilson Nobel 2020 spectrum auction Vickrey sealed bid|vi=lý thuyết đấu giá,auction theory|en=auction theory|zh=拍卖理论`},
		{"ECON_THEORY2_SEARCH",3,`label=lý thuyết tìm kiếm|desc=search theory Diamond Mortensen Pissarides Nobel 2010 job matching labor market|vi=lý thuyết tìm kiếm,search theory|en=search theory|zh=搜索理论`},

		// ── ÂM NHẠC VIỆT NAM (VNMUSIC_) ─────────────────────────
		{"VNMUSIC_DAN_BAU",   3, `label=đàn bầu|desc=nhạc cụ dây độc đáo Việt Nam một dây cộng hưởng không khí âm thanh độc đáo|vi=đàn bầu|en=dan bau|zh=独弦琴`},
		{"VNMUSIC_HAT_CHEO",  3, `label=chèo|desc=nghệ thuật dân gian Việt Nam đồng bằng Bắc Bộ hát múa kịch dân gian|vi=chèo,nghệ thuật chèo|en=cheo folk opera|zh=越南嘲剧`},
		{"VNMUSIC_NHAC_TRE",  3, `label=nhạc trẻ Việt Nam|desc=V-pop Sơn Tùng MTP Đen Vâu Jack Jack Trúc Nhân streaming xuất khẩu|vi=nhạc trẻ Việt Nam,V-pop|en=Vietnamese pop music|zh=越南流行音乐`},

		// ── CÔNG NGHỆ XÂY DỰNG (CONSTRUTECH_) ────────────────────
		{"CONSTRUTECH_BIM",   3, `label=BIM|desc=Building Information Modeling 3D digital twin thi công quản lý dự án Autodesk|vi=BIM,Building Information Modeling|en=BIM|zh=建筑信息模型`},
		{"CONSTRUTECH_3D_PRINT_BUILD",3,`label=in 3D kiến trúc|desc=3D printing construction concrete Apis Cor ICON house affordable rapid|vi=in 3D kiến trúc,3D printed house|en=3D printed construction|zh=3D打印建筑`},
		{"CONSTRUTECH_SMART_BUILD",3,`label=tòa nhà thông minh|desc=smart building automation HVAC IoT sensors energy management BAS EMS|vi=tòa nhà thông minh,smart building|en=smart building|zh=智能建筑`},

		// ── TÂM LÝ PHÁT TRIỂN (DEVPSYCH_) ───────────────────────
		{"DEVPSYCH_PIAGET",   3, `label=lý thuyết Piaget|desc=Jean Piaget giai đoạn phát triển nhận thức sensorimotor preoperational concrete formal|vi=lý thuyết Piaget,Piaget|en=Piaget's theory|zh=皮亚杰理论`},
		{"DEVPSYCH_VYGOTSKY", 3, `label=lý thuyết Vygotsky|desc=Vygotsky ZPD Zone of Proximal Development scaffolding social learning language|vi=lý thuyết Vygotsky,Vygotsky|en=Vygotsky's theory|zh=维果茨基理论`},
		{"DEVPSYCH_ATTACH",   3, `label=lý thuyết gắn bó|desc=attachment theory Bowlby Ainsworth secure anxious avoidant disorganized infancy|vi=lý thuyết gắn bó,attachment|en=attachment theory|zh=依恋理论`},

		// ── ĐỊA LÝ NAM Á (SOUTHASIA_) ────────────────────────────
		{"SOUTHASIA_PAKISTAN",3, `label=Pakistan|desc=180 triệu dân hạt nhân Islamabad Kashmir Taliban Afghanistan biên giới Ấn|vi=Pakistan|en=Pakistan|zh=巴基斯坦`},
		{"SOUTHASIA_BANG",    3, `label=Bangladesh|desc=nền kinh tế tăng trưởng nhanh dệt may xuất khẩu 170 triệu dân Dhaka lũ lụt|vi=Bangladesh|en=Bangladesh|zh=孟加拉国`},
		{"SOUTHASIA_SRI",     3, `label=Sri Lanka|desc=đảo Ấn Độ Dương trà Ceylon khủng hoảng kinh tế 2022 Colombo du lịch|vi=Sri Lanka|en=Sri Lanka|zh=斯里兰卡`},
		{"SOUTHASIA_NEPAL",   3, `label=Nepal|desc=Himalaya Everest 8848m Phật giáo Ấn Độ giáo du lịch leo núi Kathmandu|vi=Nepal|en=Nepal|zh=尼泊尔`},

		// ── VĂN HÓA TRUYỀN THÔNG (MEDCULTURE_) ──────────────────
		{"MEDCULTURE_MEME",   3, `label=meme văn hóa|desc=internet meme Richard Dawkins viral humor social commentary identity Gen Z|vi=meme văn hóa,meme|en=meme|zh=网络迷因`},
		{"MEDCULTURE_INFLUENCER",3,`label=influencer|desc=social media influencer YouTube TikTok brand partnership micro nano marketing|vi=influencer,người ảnh hưởng|en=influencer|zh=网红`},
		{"MEDCULTURE_DOCUMENTARY",3,`label=phim tài liệu|desc=documentary film Netflix David Attenborough Planet Earth journalism advocacy|vi=phim tài liệu,documentary|en=documentary|zh=纪录片`},

		// ── CÔNG NGHỆ BÁN DẪN (SEMICOND2_) ──────────────────────
		{"SEMICOND2_CHIP_DESIGN",3,`label=thiết kế chip|desc=VLSI EDA Cadence Synopsys ARM RISC-V MIPS instruction set architecture|vi=thiết kế chip,chip design|en=chip design|zh=芯片设计`},
		{"SEMICOND2_LITHO",   3, `label=in quang khắc|desc=lithography EUV ASML 7nm 5nm 3nm transistor Moore's Law node|vi=in quang khắc,lithography|en=lithography|zh=光刻`},
		{"SEMICOND2_MEMORY",  3, `label=bộ nhớ bán dẫn|desc=DRAM SRAM Flash NAND NOR Samsung SK Hynix Micron memory hierarchy|vi=bộ nhớ bán dẫn,semiconductor memory|en=semiconductor memory|zh=半导体存储器`},

		// ── LUẬT MÔI TRƯỜNG (ENVLAW_) ─────────────────────────────
		{"ENVLAW_PARIS",      3, `label=Hiệp định Paris|desc=Paris Agreement 2015 195 quốc gia 1.5C NDC net zero carbon neutrality|vi=Hiệp định Paris,Paris Agreement|en=Paris Agreement|zh=巴黎协定`},
		{"ENVLAW_KYOTO",      3, `label=Nghị định thư Kyoto|desc=Kyoto Protocol 1997 Annex I countries emission reduction CDM Joint Implementation|vi=Nghị định thư Kyoto,Kyoto Protocol|en=Kyoto Protocol|zh=京都议定书`},
		{"ENVLAW_BIODIV_CONV",3, `label=Công ước đa dạng sinh học|desc=CBD Convention on Biological Diversity 1992 Nagoya Protocol COP15 30x30|vi=Công ước đa dạng sinh học,CBD|en=CBD|zh=生物多样性公约`},

		// ── VẬT LÝ ỨNG DỤNG BỔ SUNG (APPPHYS2_) ─────────────────
		{"APPPHYS2_FIBER",    3, `label=cáp quang|desc=fiber optic total internal reflection glass silicon SiO2 bandwidth internet|vi=cáp quang,fiber optic|en=fiber optic|zh=光纤`},
		{"APPPHYS2_NUCLEAR_MED",3,`label=y học hạt nhân|desc=nuclear medicine PET scan SPECT technetium-99m radiotracer cancer diagnosis|vi=y học hạt nhân,nuclear medicine|en=nuclear medicine|zh=核医学`},
		{"APPPHYS2_ACOUSTICS",3, `label=âm học|desc=acoustics sound wave frequency amplitude decibel reverberation noise cancellation|vi=âm học,acoustics|en=acoustics|zh=声学`},

		// ── XÃ HỘI HỌC BỔ SUNG (SOCIOL2_) ───────────────────────
		{"SOCIOL2_INEQUALITY",3, `label=bất bình đẳng xã hội|desc=income wealth inequality Gini coefficient Piketty top 1% mobility redistribution|vi=bất bình đẳng xã hội,inequality|en=social inequality|zh=社会不平等`},
		{"SOCIOL2_SOCIAL_MOV",3, `label=phong trào xã hội|desc=social movement civil rights women's suffrage BLM MeToo collective action|vi=phong trào xã hội,social movement|en=social movement|zh=社会运动`},
		{"SOCIOL2_FAMILY",    3, `label=gia đình học|desc=family sociology nuclear extended single-parent fertility rate marriage divorce|vi=gia đình học,family sociology|en=family sociology|zh=家庭社会学`},

		// ── THIÊN VĂN LỊCH SỬ (ASTRO_HIST_) ─────────────────────
		{"ASTRO_HIST_COPERNICUS",3,`label=Copernicus|desc=Nicolaus Copernicus nhật tâm 1543 De Revolutionibus trái đất quanh mặt trời|vi=Copernicus|en=Copernicus|zh=哥白尼`},
		{"ASTRO_HIST_GALILEO",3, `label=Galileo|desc=Galileo Galilei kính thiên văn 1609 mặt trăng Jupiter Inquisition tòa dị giáo|vi=Galileo|en=Galileo Galilei|zh=伽利略`},
		{"ASTRO_HIST_KEPLER", 3, `label=Kepler|desc=Johannes Kepler định luật hành tinh elipse quỹ đạo T² ∝ a³ Mysterium Cosmographicum|vi=Kepler,định luật Kepler|en=Kepler|zh=开普勒`},

		// ── DU LỊCH VIỆT NAM (VNTRAVEL2_) ───────────────────────
		{"VNTRAVEL2_HOIAN",   3, `label=Hội An|desc=phố cổ UNESCO đèn lồng 400 năm thương cảng Nhật Bản Trung Quốc thế kỷ 15|vi=Hội An,Hoi An|en=Hoi An|zh=会安`},
		{"VNTRAVEL2_SAPA",    3, `label=Sa Pa|desc=núi Fansipan 3143m ruộng bậc thang H'Mông sương mù du lịch sinh thái|vi=Sa Pa,Sapa|en=Sapa|zh=沙坝`},
		{"VNTRAVEL2_MEKONG_DELTA",3,`label=Đồng bằng sông Cửu Long|desc=ĐBSCL lúa gạo thủy sản du lịch sông nước chợ nổi Cần Thơ|vi=Đồng bằng sông Cửu Long,ĐBSCL|en=Mekong Delta|zh=湄公河三角洲`},

		// ── CÔNG NGHỆ XÃ HỘI (SOCTECH_) ─────────────────────────
		{"SOCTECH_ALGO_BIAS", 3, `label=thuật toán thiên vị|desc=algorithmic bias facial recognition COMPAS recidivism gender race historical|vi=thuật toán thiên vị,algorithmic bias|en=algorithmic bias|zh=算法偏见`},
		{"SOCTECH_DIGITAL_DIV",3,`label=khoảng cách số|desc=digital divide access internet device literacy urban rural developing nations|vi=khoảng cách số,digital divide|en=digital divide|zh=数字鸿沟`},
		{"SOCTECH_SURVEILLANCE",3,`label=giám sát kỹ thuật số|desc=digital surveillance CCTV facial recognition social credit China metadata|vi=giám sát kỹ thuật số,surveillance|en=digital surveillance|zh=数字监控`},

		// ── LỊCH SỬ NHẬT BẢN BỔ SUNG (JAPANHIST_) ───────────────
		{"JAPANHIST_SHOGUN",  3, `label=Shogunate Nhật Bản|desc=shogunate Kamakura Muromachi Tokugawa samurai feudal Japan isolation sakoku|vi=Shogunate Nhật Bản,shogunate|en=Japanese Shogunate|zh=幕府时代`},
		{"JAPANHIST_HIROSHIMA",3,`label=Hiroshima|desc=nguyên tử bom 6-8-1945 Little Boy 70000 người chết hòa bình UNESCO memorial|vi=Hiroshima|en=Hiroshima|zh=广岛`},
		{"JAPANHIST_ECONOMIC_MIRACLE",3,`label=kỳ tích kinh tế Nhật|desc=Japan economic miracle 1955-1973 MITI export automotive electronics GDP|vi=kỳ tích kinh tế Nhật Bản,Japan economic miracle|en=Japan economic miracle|zh=日本经济奇迹`},

		// ── SINH HỌC BIỂN (MARINEBIO_) ───────────────────────────
		{"MARINEBIO_WHALE",   3, `label=cá voi|desc=whale cetacean blue whale largest mammal 30m echolocation humpback migration|vi=cá voi,whale|en=whale|zh=鲸鱼`},
		{"MARINEBIO_SHARK",   3, `label=cá mập|desc=shark apex predator 450 triệu năm cartilage electroreception finning conservation|vi=cá mập,shark|en=shark|zh=鲨鱼`},
		{"MARINEBIO_OCTOPUS", 3, `label=bạch tuộc|desc=octopus cephalopod 8 xúc tu chromatophore intelligence problem solving camouflage|vi=bạch tuộc,octopus|en=octopus|zh=章鱼`},

		// ── ĐẠO ĐỨC HỌC (ETHICS_) ───────────────────────────────
		{"ETHICS_UTILITARI",  3, `label=chủ nghĩa công lợi|desc=utilitarianism Bentham Mill greatest happiness principle trolley problem|vi=chủ nghĩa công lợi,utilitarianism|en=utilitarianism|zh=功利主义`},
		{"ETHICS_DEONTOL",    3, `label=đạo đức nghĩa vụ|desc=deontology Kant categorical imperative duty moral law never treat as means|vi=đạo đức nghĩa vụ,deontology|en=deontology|zh=义务论`},
		{"ETHICS_VIRTUE",     3, `label=đạo đức đức hạnh|desc=virtue ethics Aristotle eudaimonia phronesis courage justice temperance golden mean|vi=đạo đức đức hạnh,virtue ethics|en=virtue ethics|zh=美德伦理学`},
		{"ETHICS_CARE",       3, `label=đạo đức quan tâm|desc=care ethics Carol Gilligan Nel Noddings relationships context feminist moral|vi=đạo đức quan tâm,care ethics|en=care ethics|zh=关怀伦理学`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"COGSCI_WORKING_MEM","BRAINAREA_PREFRONTAL","located-in"},
		{"MOLBIO_TRANSCRIPTION","MOLBIO_TRANSLATION","precedes"},
		{"MOLBIO_EPIGENETICS","MOLBIO_STEM_CELL",   "modifies"},
		{"SOLIDPHYS_CONDUCTOR","NEWMAT_2D_MAT",      "compared-to"},
		{"APPLLING_NLP",      "ML2_TRANSFORMER",     "uses"},
		{"NEWENERGY_BATTERY", "ROBOTICS_AUTONOMOUS", "powers"},
		{"NEWENERGY_NUCLEAR_FUSION","NUCLEAR_REACTOR","successor-of"},
		{"INTFIN_FOREX",      "ECON3_CRYPTO",        "competes-with"},
		{"TECHHIST_INTERNET_HIST","CS2_CLOUD",       "enables"},
		{"RESEARCH_PEER_REV", "RESEARCH_META_AN",   "basis-of"},
		{"ENVLAW_PARIS",      "CLIMATE2_FEEDBACK",   "addresses"},
		{"ENVLAW_PARIS",      "SDG_GOALS",           "aligns-with"},
		{"SEMICOND2_LITHO",   "ASIA2_TAIWAN",        "dominated-by"},
		{"DEVPSYCH_VYGOTSKY", "MODEDU_CRITICAL",     "informs"},
		{"ETHICS_UTILITARI",  "ECON_THEORY2_GAME",   "applied-in"},
		{"MARINEBIO_WHALE",   "ECO3_REWILD",         "symbol-of"},
		{"ASTRO_HIST_GALILEO","MODPHYS_STANDARD",    "precursor-of"},
		{"VNTRAVEL2_HOIAN",   "VNHIST2_ANCIENT",     "from"},
		{"SOCTECH_ALGO_BIAS", "TECHETHICS_AI",       "part-of"},
		{"AFRHIST_APARTHEID", "IDEAHIST_LIBERALISM", "challenged"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 3000 { fmt.Println("🎉🎉🎉 MILESTONE 3000! 🎉🎉🎉") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"located-in":1,"precedes":2,"modifies":3,"compared-to":4,"uses":5,
		"powers":6,"successor-of":7,"competes-with":8,"enables":9,"basis-of":10,
		"addresses":11,"aligns-with":12,"dominated-by":13,"informs":14,
		"applied-in":15,"symbol-of":16,"precursor-of":17,"from":18,
		"part-of":19,"challenged":20,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
