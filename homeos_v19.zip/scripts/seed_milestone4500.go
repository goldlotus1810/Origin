//go:build ignore
// seed_milestone4500.go — MILESTONE 4500 — ~100 nodes
// Domains: QUANTUM2_ CONDENSED2_ PLASMA2_ ASTROPHYS3_ COSMOLOGY_
//          CLIMATE3_ HYDROLOGY2_ SOIL2_ FOREST2_ CORAL_
//          GOVERNANCE_ DIPLOMACY_ INTLAW_ HUMANRIGHT_ PEACEKEEP_
//          BIOETHICS_ TECHETHICS_ AIETHICS_ DATAETHICS_ ENVIROETHICS_
//          GAMEDESIGN_ GAMENARRATIVE_ GAMEDEVELOP_ ESPORT2_ GAMEPSYCH_
//          VNHISTORY3_ VNWAR_ VNREFORM_ VNDIPLOMACY_ VNCONSTITUTION_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── QUANTUM PHYSICS 2 ─────────────────────────────────────────
		{"QUANTUM2_ENTANGLE",    3,`label=vướng víu lượng tử|desc=quantum entanglement Bell inequality EPR nonlocality decoherence quantum teleportation swapping purification|vi=vướng víu lượng tử,quantum entanglement|en=quantum entanglement`},
		{"QUANTUM2_COMPUTE",     3,`label=điện toán lượng tử|desc=quantum computing qubit gate circuit noise NISQ error correction surface code IBM Google fault tolerant|vi=điện toán lượng tử,quantum computing|en=quantum computing`},
		{"QUANTUM2_SENSING",     3,`label=cảm biến lượng tử|desc=quantum sensing atomic clock gravimeter magnetometer NV center diamond precision measurement GPS alternative|vi=cảm biến lượng tử,quantum sensing|en=quantum sensing`},
		{"QUANTUM2_CRYPTO",      3,`label=mật mã lượng tử|desc=quantum cryptography QKD BB84 E91 post-quantum NIST CRYSTALS-Kyber lattice-based harvest now decrypt later|vi=mật mã lượng tử,quantum cryptography|en=quantum cryptography`},
		{"CONDENSED2_TOPOLOG",   3,`label=vật liệu topo học|desc=topological material insulator semimetal Weyl Dirac Majorana surface state bulk-boundary Berry phase|vi=vật liệu topo học,topological material|en=topological material`},

		// ── PLASMA & ASTRO ────────────────────────────────────────────
		{"PLASMA2_FUSION",       3,`label=nhiệt hạch|desc=nuclear fusion plasma tokamak ITER stellarator inertial confinement NIF ignition Q>1 tritium breeding|vi=nhiệt hạch,nuclear fusion|en=nuclear fusion`},
		{"PLASMA2_SPACE",        3,`label=plasma vũ trụ|desc=space plasma solar wind magnetosphere aurora Van Allen belts CME geomagnetic storm Dst index Kp|vi=plasma vũ trụ,space plasma|en=space plasma`},
		{"ASTROPHYS3_BLACKHOLE", 3,`label=lỗ đen|desc=black hole Schwarzschild radius event horizon EHT M87 Sgr A* accretion disk jet Hawking radiation tidal|vi=lỗ đen,black hole|en=black hole`},
		{"ASTROPHYS3_NEUTRON",   3,`label=sao neutron|desc=neutron star pulsar magnetar fast radio burst gravitational wave kilonova r-process heavy elements EOS|vi=sao neutron,neutron star|en=neutron star`},
		{"COSMOLOGY_DARKENERGY", 3,`label=năng lượng tối|desc=dark energy cosmological constant Hubble tension w equation state DESI survey SNe Ia standard candle|vi=năng lượng tối,dark energy|en=dark energy`},

		// ── CLIMATE 3 & HYDROLOGY ─────────────────────────────────────
		{"CLIMATE3_TIPPING",     3,`label=điểm tới hạn khí hậu|desc=climate tipping point AMOC shutdown Greenland WAIS Amazon dieback permafrost methane 1.5C 2C|vi=điểm tới hạn khí hậu,climate tipping point|en=climate tipping point`},
		{"CLIMATE3_CARBON",      3,`label=thị trường carbon|desc=carbon market ETS cap-and-trade offset CDM CORSIA voluntary REDD+ price floor ceiling leakage|vi=thị trường carbon,carbon market|en=carbon market`},
		{"CLIMATE3_ADAPT",       3,`label=thích ứng biến đổi khí hậu|desc=climate adaptation nature-based solution green infrastructure coastal retreat managed retreat heat island|vi=thích ứng biến đổi khí hậu,climate adaptation|en=climate adaptation`},
		{"HYDROLOGY2_GROUND",    3,`label=nước ngầm|desc=groundwater aquifer recharge depletion subsidence arsenic contamination GRACE satellite India Pakistan overextraction|vi=nước ngầm,groundwater|en=groundwater`},
		{"HYDROLOGY2_FLOOD",     3,`label=lũ lụt và quản lý rủi ro|desc=flood risk management early warning floodplain zoning retention basin levee failure loss damage|vi=lũ lụt và quản lý rủi ro,flood risk management|en=flood risk management`},

		// ── SOIL & FOREST ─────────────────────────────────────────────
		{"SOIL2_CARBON",         3,`label=carbon đất|desc=soil organic carbon sequestration regenerative agriculture no-till cover crop biochar earthworm microbiome|vi=carbon đất,soil carbon|en=soil carbon`},
		{"SOIL2_DEGRADE",        3,`label=suy thoái đất|desc=land degradation erosion salinization desertification UNCCD LDN restoration FOLU emission 3.4Gt|vi=suy thoái đất,land degradation|en=land degradation`},
		{"FOREST2_DEFOREST",     3,`label=nạn phá rừng|desc=deforestation Amazon Congo Indonesia soy cattle palm oil EUDR forest regulation supply chain due diligence|vi=nạn phá rừng,deforestation|en=deforestation`},
		{"FOREST2_RESTORE",      3,`label=phục hồi rừng|desc=forest restoration Bonn Challenge 350M ha native species agroforestry assisted natural regeneration ANR|vi=phục hồi rừng,forest restoration|en=forest restoration`},
		{"CORAL_BLEACH",         3,`label=san hô tẩy trắng|desc=coral bleaching Great Barrier Reef thermal anomaly zooxanthellae expulsion mass mortality 1.5C threshold|vi=san hô tẩy trắng,coral bleaching|en=coral bleaching`},

		// ── GOVERNANCE & DIPLOMACY ────────────────────────────────────
		{"GOVERNANCE_DIGITAL",   3,`label=quản trị kỹ thuật số|desc=digital governance e-government open data platform API interoperability Estonia Singapore GovTech|vi=quản trị kỹ thuật số,digital governance|en=digital governance`},
		{"GOVERNANCE_LOCAL",     3,`label=quản trị địa phương|desc=local governance decentralization participatory budgeting urban planning zoning community land trust|vi=quản trị địa phương,local governance|en=local governance`},
		{"DIPLOMACY_MULTILAT",   3,`label=ngoại giao đa phương|desc=multilateral diplomacy UN Security Council veto reform G20 WTO climate COP WHO pandemic treaty|vi=ngoại giao đa phương,multilateral diplomacy|en=multilateral diplomacy`},
		{"DIPLOMACY_ECONOMIC",   3,`label=ngoại giao kinh tế|desc=economic diplomacy FTA RCEP CPTPP BRI Belt Road Initiative strategic investment review national security|vi=ngoại giao kinh tế,economic diplomacy|en=economic diplomacy`},
		{"INTLAW_CYBER",         3,`label=luật quốc tế không gian mạng|desc=cyber international law Tallinn Manual state attribution threshold use of force due diligence|vi=luật quốc tế không gian mạng,cyber international law|en=cyber international law`},

		// ── HUMAN RIGHTS & PEACE ──────────────────────────────────────
		{"HUMANRIGHT_DIGITAL",   3,`label=quyền kỹ thuật số|desc=digital rights privacy surveillance facial recognition biometric border control GDPR CCPA data subject|vi=quyền kỹ thuật số,digital rights|en=digital rights`},
		{"HUMANRIGHT_CLIMATE",   3,`label=quyền con người và khí hậu|desc=climate human rights OHCHR displacement loss damage Pacific islander Indigenous rights|vi=quyền con người và khí hậu,climate human rights|en=climate human rights`},
		{"PEACEKEEP_UN",         3,`label=gìn giữ hòa bình LHQ|desc=UN peacekeeping blue helmets DPKO mandate ROE protection civilians sexual exploitation reform|vi=gìn giữ hòa bình LHQ,UN peacekeeping|en=UN peacekeeping`},
		{"PEACEKEEP_TRANSITIONAL",3,`label=công lý chuyển tiếp|desc=transitional justice truth commission TRC war crimes tribunal ICC Nuremberg hybrid court reparation|vi=công lý chuyển tiếp,transitional justice|en=transitional justice`},
		{"INTLAW_SPACE",         3,`label=luật vũ trụ|desc=space law Outer Space Treaty Moon Agreement liability convention registration debris national authorization|vi=luật vũ trụ,space law|en=space law`},

		// ── ETHICS ────────────────────────────────────────────────────
		{"BIOETHICS_GENE",       3,`label=đạo đức chỉnh sửa gene|desc=gene editing ethics CRISPR germline enhancement designer baby He Jiankui moratorium consent equity|vi=đạo đức chỉnh sửa gene,gene editing ethics|en=gene editing ethics`},
		{"BIOETHICS_DEATH",      3,`label=đạo đức y tế cuối đời|desc=end of life ethics euthanasia assisted dying palliative advance directive DNR autonomy dignity|vi=đạo đức y tế cuối đời,end of life ethics|en=end of life ethics`},
		{"AIETHICS_BIAS",        3,`label=thiên kiến AI|desc=AI bias fairness algorithmic discrimination COMPAS hiring credit face recognition protected attribute|vi=thiên kiến AI,AI bias|en=AI bias`},
		{"AIETHICS_SAFETY",      3,`label=an toàn AI|desc=AI safety alignment value learning RLHF constitutional AI interpretability red team jailbreak|vi=an toàn AI,AI safety|en=AI safety`},
		{"DATAETHICS_PRIVACY",   3,`label=đạo đức dữ liệu và quyền riêng tư|desc=data ethics privacy by design differential privacy federated learning data minimization purpose limitation|vi=đạo đức dữ liệu và quyền riêng tư,data ethics privacy|en=data ethics privacy`},

		// ── ENVIRONMENT ETHICS ────────────────────────────────────────
		{"ENVIROETHICS_ANIMAL",  3,`label=đạo đức môi trường và động vật|desc=environmental ethics animal rights Singer deep ecology land ethic Leopold ecocentrism speciesism|vi=đạo đức môi trường và động vật,environmental ethics|en=environmental ethics`},
		{"TECHETHICS_DUAL",      3,`label=đạo đức công nghệ kép|desc=dual use technology export control bioweapon cyber offense drone autonomous weapon LAWS lethal|vi=đạo đức công nghệ kép,dual use technology|en=dual use technology`},

		// ── GAME DESIGN & NARRATIVE ───────────────────────────────────
		{"GAMEDESIGN_MECHANICS", 3,`label=cơ chế trò chơi|desc=game mechanics core loop feedback reward schedule operant conditioning compulsion loop gacha loot box|vi=cơ chế trò chơi,game mechanics|en=game mechanics`},
		{"GAMEDESIGN_UX",        3,`label=UX thiết kế game|desc=game UX onboarding tutorial difficulty curve accessibility color blind screen reader controller support|vi=UX thiết kế game,game UX|en=game UX`},
		{"GAMENARRATIVE_STORY",  3,`label=kể chuyện trong game|desc=game narrative branching dialogue ludonarrative dissonance environmental storytelling emergent story|vi=kể chuyện trong game,game narrative|en=game narrative`},
		{"GAMENARRATIVE_WORLD",  3,`label=xây dựng thế giới game|desc=worldbuilding lore codex mythology factions economy history geography procedural generation rogue|vi=xây dựng thế giới game,worldbuilding|en=worldbuilding`},
		{"GAMEDEVELOP_ENGINE",   3,`label=engine game|desc=game engine Unity Unreal Godot rendering pipeline ECS job system burst compiler WebGPU WASM mobile|vi=engine game,game engine|en=game engine`},

		// ── ESPORT 2 & GAME PSYCHOLOGY ────────────────────────────────
		{"GAMEDEVELOP_NETCODE",  3,`label=netcode game|desc=netcode rollback GGPO lockstep latency compensation client prediction server reconciliation authoritative|vi=netcode game,game netcode|en=game netcode`},
		{"ESPORT2_ECOSYSTEM",    3,`label=hệ sinh thái esport|desc=esport ecosystem publisher league franchise team sponsor broadcast rights prize pool player welfare|vi=hệ sinh thái esport,esport ecosystem|en=esport ecosystem`},
		{"ESPORT2_TRAINING",     3,`label=huấn luyện esport|desc=esport training VOD review replay analysis coach mental performance sport science fatigue peak|vi=huấn luyện esport,esport training|en=esport training`},
		{"GAMEPSYCH_FLOW",       3,`label=trạng thái flow trong game|desc=game flow Csikszentmihalyi optimal experience challenge skill balance immersion presence embodiment|vi=trạng thái flow trong game,game flow|en=game flow`},
		{"GAMEPSYCH_ADDICTION",  3,`label=nghiện game|desc=gaming disorder WHO ICD-11 DSM criteria adolescent parent screen time intervention CBT|vi=nghiện game,gaming disorder|en=gaming disorder`},

		// ── VIETNAM HISTORY 3 ─────────────────────────────────────────
		{"VNHISTORY3_KINGDOM",   3,`label=các vương quốc cổ Việt Nam|desc=vương quốc cổ Việt Nam Văn Lang Âu Lạc Champa Phù Nam Đại Việt Nam tiến nền tảng lãnh thổ|vi=các vương quốc cổ Việt Nam,ancient Vietnamese kingdoms|en=ancient Vietnamese kingdoms`},
		{"VNHISTORY3_FRENCH",    3,`label=thời kỳ Pháp thuộc|desc=Pháp thuộc Đông Dương thuộc địa Pháp 1858-1954 khai thác tài nguyên chữ quốc ngữ phong trào yêu nước|vi=thời kỳ Pháp thuộc,French Indochina|en=French Indochina`},
		{"VNWAR_AMERICAN",       3,`label=chiến tranh Việt Nam|desc=chiến tranh Việt Nam 1955-1975 Mỹ Giải phóng miền Nam thống nhất di chứng Agent Orange PTSD hòa giải|vi=chiến tranh Việt Nam,Vietnam War|en=Vietnam War`},
		{"VNWAR_BORDER",         3,`label=chiến tranh biên giới Việt Nam|desc=chiến tranh biên giới 1979 Trung Việt Campuchia Khmer Đỏ diệt chủng quân sự ASEAN|vi=chiến tranh biên giới Việt Nam,Vietnam border wars|en=Vietnam border wars`},
		{"VNREFORM_DOIKMOI",     3,`label=Đổi Mới kinh tế Việt Nam|desc=Đổi Mới 1986 kinh tế thị trường định hướng XHCN FDI WTO gia nhập tăng trưởng GDP nghèo giảm|vi=Đổi Mới kinh tế Việt Nam,Vietnam Doi Moi reform|en=Vietnam Doi Moi reform`},

		// ── VIETNAM DIPLOMACY & CONSTITUTION ─────────────────────────
		{"VNDIPLOMACY_ASEAN",    3,`label=Việt Nam và ASEAN|desc=Việt Nam ASEAN 1995 gia nhập Cộng đồng kinh tế AEC RCEP chủ tịch luân phiên Biển Đông COC|vi=Việt Nam và ASEAN,Vietnam ASEAN|en=Vietnam ASEAN`},
		{"VNDIPLOMACY_SOUTH_SEA",3,`label=Biển Đông và chủ quyền|desc=Biển Đông chủ quyền Hoàng Sa Trường Sa UNCLOS phán quyết 2016 đường 9 đoạn tranh chấp đa phương|vi=Biển Đông và chủ quyền,South China Sea sovereignty|en=South China Sea sovereignty`},
		{"VNCONSTITUTION_2013",  3,`label=Hiến pháp Việt Nam 2013|desc=Hiến pháp 2013 nhà nước pháp quyền XHCN quyền con người quyền công dân kinh tế thị trường Điều 4|vi=Hiến pháp Việt Nam 2013,Vietnam Constitution 2013|en=Vietnam Constitution 2013`},
		{"VNREFORM_ADMIN",       3,`label=cải cách hành chính Việt Nam|desc=cải cách hành chính Việt Nam thủ tục hành chính một cửa dịch vụ công trực tuyến cắt giảm|vi=cải cách hành chính Việt Nam,Vietnam administrative reform|en=Vietnam administrative reform`},
		{"VNDIPLOMACY_US",       3,`label=quan hệ Việt-Mỹ|desc=quan hệ Việt Mỹ bình thường hóa 1995 đối tác toàn diện chiến lược 2023 thương mại quốc phòng|vi=quan hệ Việt-Mỹ,Vietnam US relations|en=Vietnam US relations`},

		// ── CONDENSED MATTER 2 ────────────────────────────────────────
		{"CONDENSED2_SUPER2",    3,`label=siêu dẫn nhiệt độ cao|desc=high temperature superconductor cuprate iron pnictide LK-99 controversy critical temperature mechanism|vi=siêu dẫn nhiệt độ cao,high temperature superconductor|en=high temperature superconductor`},
		{"CONDENSED2_MAGNET",    3,`label=từ học hiện đại|desc=modern magnetism spintronics GMR TMR MRAM skyrmion magnon spin Hall effect spin transfer torque|vi=từ học hiện đại,modern magnetism spintronics|en=modern magnetism spintronics`},
		{"COSMOLOGY_CMB",        3,`label=bức xạ nền vũ trụ|desc=CMB cosmic microwave background WMAP Planck anisotropy primordial gravitational waves inflation Silk damping|vi=bức xạ nền vũ trụ,cosmic microwave background|en=cosmic microwave background`},
		{"ASTROPHYS3_EXOPLANET", 3,`label=ngoại hành tinh|desc=exoplanet transit radial velocity TESS Kepler habitable zone biosignature JWST atmospheric spectroscopy|vi=ngoại hành tinh,exoplanet|en=exoplanet`},
		{"HYDROLOGY2_MEKONG",    3,`label=sông Mê Kông|desc=Mekong river delta Vietnam Cambodia Laos dam upstream China fishery sediment salinity food security|vi=sông Mê Kông,Mekong river|en=Mekong river`},

		// ── GAME/SOIL/GOVERNANCE misc ─────────────────────────────────
		{"SOIL2_MICROBIOME",     3,`label=vi sinh vật đất|desc=soil microbiome bacteria fungi mycorrhizal network rhizosphere nitrogen fixation phosphorus solubilization|vi=vi sinh vật đất,soil microbiome|en=soil microbiome`},
		{"GOVERNANCE_CRISIS",    3,`label=quản lý khủng hoảng|desc=crisis governance emergency management ICS incident command FEMA WHO GOARN One Health zoonosis|vi=quản lý khủng hoảng,crisis governance|en=crisis governance`},
		{"DIPLOMACY_TRACK2",     3,`label=ngoại giao kênh 2|desc=track 2 diplomacy think tank back channel CSCAP ASEAN-ISIS epistemic community policy dialogue|vi=ngoại giao kênh 2,track 2 diplomacy|en=track 2 diplomacy`},
		{"GAMEDEVELOP_MONETIZE", 3,`label=kiếm tiền từ game|desc=game monetization free-to-play battle pass cosmetic DLC season premium subscription live service|vi=kiếm tiền từ game,game monetization|en=game monetization`},
		{"GAMEPSYCH_PROSOCIAL",  3,`label=hành vi xã hội trong game|desc=prosocial game cooperation empathy civic engagement serious game health education training simulation|vi=hành vi xã hội trong game,prosocial gaming|en=prosocial gaming`},
		{"CORAL_RESTORE",        3,`label=phục hồi san hô|desc=coral restoration assisted evolution heat tolerant symbiont micro fragmentation reef substrate rubble|vi=phục hồi san hô,coral restoration|en=coral restoration`},
		{"FOREST2_VIET",         3,`label=rừng Việt Nam|desc=rừng Việt Nam che phủ 42% tái trồng rừng lâm nghiệp cộng đồng REDD+ Carbon tín chỉ kiểm lâm|vi=rừng Việt Nam,Vietnam forest|en=Vietnam forest`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" → %d nodes\n", nn)
	if nn >= 4500 { fmt.Println(" MILESTONE 4500! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
