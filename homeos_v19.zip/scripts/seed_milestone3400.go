//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── KHOA HỌC NHẬN THỨC ỨNG DỤNG (COGAPP_) ────────────────
		{"COGAPP_FLOW",       3,`label=trạng thái dòng chảy|desc=flow state Csikszentmihalyi challenge skill balance optimal experience immersion|vi=trạng thái dòng chảy,flow state|en=flow state|zh=心流状态`},
		{"COGAPP_EXPERT",     3,`label=chuyên gia và novice|desc=expert novice chunking pattern recognition deliberate practice Anders Ericsson 10000 hours|vi=chuyên gia và người mới,expert novice|en=expert novice|zh=专家与新手`},
		{"COGAPP_MENTAL_MODEL",3,`label=mô hình tư duy|desc=mental model Charlie Munger lattice multi-disciplinary thinking second order effects map territory|vi=mô hình tư duy,mental model|en=mental model|zh=思维模型`},
		{"COGAPP_CRITICAL",   3,`label=tư duy phản biện|desc=critical thinking fallacy ad hominem straw man false dilemma Socratic method epistemology|vi=tư duy phản biện,critical thinking|en=critical thinking|zh=批判性思维`},

		// ── SINH HỌC PHÁT TRIỂN (DEVBIO_) ────────────────────────
		{"DEVBIO_EMBRYO",    3,`label=phôi thai học|desc=embryology fertilization zygote blastocyst gastrulation organogenesis neural tube HOX gene|vi=phôi thai học,embryology|en=embryology|zh=胚胎学`},
		{"DEVBIO_AGING",     3,`label=sinh học lão hóa|desc=aging telomere Hayflick limit senescence mitochondria free radical caloric restriction|vi=sinh học lão hóa,aging biology|en=aging biology|zh=衰老生物学`},
		{"DEVBIO_REGENERATION",3,`label=tái tạo mô|desc=tissue regeneration planaria axolotl salamander stem cell wound healing liver regeneration|vi=tái tạo mô,tissue regeneration|en=tissue regeneration|zh=组织再生`},

		// ── HÓA SINH (BIOCHEM2_) ──────────────────────────────────
		{"BIOCHEM2_ENZYME",  3,`label=enzyme|desc=enzyme catalyst active site substrate lock-key induced fit Michaelis-Menten Km Vmax inhibition|vi=enzyme|en=enzyme|zh=酶`},
		{"BIOCHEM2_ATP",     3,`label=ATP và năng lượng tế bào|desc=ATP adenosine triphosphate cellular energy currency mitochondria oxidative phosphorylation glycolysis|vi=ATP năng lượng tế bào,ATP|en=ATP cellular energy|zh=ATP细胞能量`},
		{"BIOCHEM2_LIPID",   3,`label=lipid|desc=lipid fat phospholipid membrane bilayer cholesterol steroid hormone omega-3 metabolism|vi=lipid|en=lipid|zh=脂质`},

		// ── LỊCH SỬ KHOA HỌC (SCIHIST2_) ─────────────────────────
		{"SCIHIST2_REVOLUTION",3,`label=Cách mạng Khoa học|desc=Scientific Revolution Copernicus Galileo Newton 16-17th century inductive method empiricism|vi=Cách mạng Khoa học,Scientific Revolution|en=Scientific Revolution|zh=科学革命`},
		{"SCIHIST2_DARWIN2",  3,`label=Darwin và tiến hóa|desc=Darwin voyage Beagle 1831-36 Galápagos finches natural selection Origin Species 1859|vi=Darwin và tiến hóa|en=Darwin evolution|zh=达尔文与进化论`},
		{"SCIHIST2_BOHR",     3,`label=mô hình nguyên tử Bohr|desc=Bohr atom model 1913 planetary electron orbit energy level hydrogen spectrum quantum|vi=mô hình nguyên tử Bohr,Bohr|en=Bohr atom model|zh=玻尔原子模型`},

		// ── VĂN HÓA TRUNG ĐÔNG (MIDEAST2_) ──────────────────────
		{"MIDEAST2_PERSIAN",  3,`label=văn minh Ba Tư|desc=Persian Empire Achaemenid Cyrus Darius Xerxes 550-330 BCE Persepolis Zoroastrianism|vi=văn minh Ba Tư,Persian Empire|en=Persian Empire|zh=波斯帝国`},
		{"MIDEAST2_ARABIC",   3,`label=Thời đại Vàng Hồi giáo|desc=Islamic Golden Age 8-13th century algebra Algebra Al-Khwarizmi optics astronomy translation|vi=Thời đại Vàng Hồi giáo,Islamic Golden Age|en=Islamic Golden Age|zh=伊斯兰黄金时代`},
		{"MIDEAST2_OIL_POL",  3,`label=chính trị dầu mỏ Trung Đông|desc=Middle East oil politics OPEC 1973 embargo petrodollar Saudi Arabia Iran Iraq Gulf|vi=chính trị dầu mỏ Trung Đông,oil politics|en=Middle East oil politics|zh=中东石油政治`},

		// ── CÔNG NGHỆ Y TẾ (HEALTHTECH2_) ────────────────────────
		{"HEALTHTECH2_ROBOT_SURG",3,`label=phẫu thuật robot|desc=robotic surgery Da Vinci system minimally invasive laparoscopic precision tremor removal|vi=phẫu thuật robot,robotic surgery|en=robotic surgery|zh=机器人手术`},
		{"HEALTHTECH2_GENOMIC",3,`label=y học bộ gen|desc=genomic medicine whole genome sequencing WGS pharmacogenomics personalized cancer treatment|vi=y học bộ gen,genomic medicine|en=genomic medicine|zh=基因组医学`},
		{"HEALTHTECH2_NANOMED",3,`label=y học nano|desc=nanomedicine nanoparticle drug delivery targeted therapy cancer blood-brain barrier liposome|vi=y học nano,nanomedicine|en=nanomedicine|zh=纳米医学`},

		// ── HẠ TẦNG KỸ THUẬT SỐ (DIGINFRA_) ─────────────────────
		{"DIGINFRA_CDN",      3,`label=mạng phân phối nội dung|desc=CDN Content Delivery Network edge server Cloudflare Akamai latency geographic distribution|vi=CDN,mạng phân phối nội dung|en=CDN|zh=内容分发网络`},
		{"DIGINFRA_DNS2",     3,`label=DNS|desc=Domain Name System recursive resolver authoritative root server A AAAA CNAME TTL DNSSEC|vi=DNS,Domain Name System|en=DNS|zh=域名系统`},
		{"DIGINFRA_MICROSERVICE",3,`label=microservices|desc=microservices SOA service mesh API gateway resilience circuit breaker Netflix Uber Spotify|vi=microservices|en=microservices|zh=微服务`},

		// ── ĐẶC SẮC ẨM THỰC CHÂU Á (ASIAFOOD_) ──────────────────
		{"ASIAFOOD_RAMEN",    3,`label=ramen|desc=ramen Japanese noodle soup tonkotsu shoyu miso shio Ichiran Ippudo regional style|vi=ramen|en=ramen|zh=拉面`},
		{"ASIAFOOD_DIM_SUM",  3,`label=dim sum|desc=dim sum Cantonese yum cha har gow siu mai char siu bao Hong Kong weekend tradition|vi=dim sum|en=dim sum|zh=点心`},
		{"ASIAFOOD_KIMCHI",   3,`label=kimchi|desc=kimchi fermented Napa cabbage gochugaru daikon UNESCO intangible heritage Korea lactobacillus|vi=kimchi|en=kimchi|zh=泡菜`},
		{"ASIAFOOD_PAD_THAI", 3,`label=pad thai|desc=pad thai stir-fried rice noodle egg tofu shrimp peanut lime bean sprout Thailand|vi=pad thai|en=pad thai|zh=泰式炒河粉`},

		// ── DU LỊCH VÀ VĂN HÓA TOÀN CẦU (GLOBTRAVEL_) ──────────
		{"GLOBTRAVEL_ROME",   3,`label=Rome|desc=Rome Eternal City Vatican Colosseum Forum Trevi Fountain pasta pizza 2800 năm history|vi=Rome,La Mã|en=Rome|zh=罗马`},
		{"GLOBTRAVEL_KYOTO",  3,`label=Kyoto|desc=Kyoto 1794 cố đô Nhật Bản đền Kinkakuji Fushimi Inari geisha Gion UNESCO heritage|vi=Kyoto|en=Kyoto|zh=京都`},
		{"GLOBTRAVEL_NYC",    3,`label=New York City|desc=NYC Manhattan Times Square Central Park Broadway Statue of Liberty financial capital|vi=New York City,NYC|en=New York City|zh=纽约`},
		{"GLOBTRAVEL_PARIS",  3,`label=Paris|desc=Paris Eiffel Tower Louvre Seine Montmartre fashion art culture 2 tỷ khách/năm|vi=Paris|en=Paris|zh=巴黎`},

		// ── VẬT LÝ THỐNG KÊ (STATPHYS_) ─────────────────────────
		{"STATPHYS_BOLTZMANN",3,`label=thống kê Boltzmann|desc=Boltzmann statistics partition function classical ideal gas equipartition thermal equilibrium|vi=thống kê Boltzmann,Boltzmann statistics|en=Boltzmann statistics|zh=玻尔兹曼统计`},
		{"STATPHYS_PHASE_TR2",3,`label=chuyển pha và trật tự|desc=phase transition order parameter symmetry breaking Ising model ferromagnet critical point|vi=chuyển pha và trật tự,phase transition order|en=phase transition order|zh=相变与有序`},

		// ── KỸ NĂNG MỀM (SOFTSKILL2_) ────────────────────────────
		{"SOFTSKILL2_PRESENT",3,`label=kỹ năng thuyết trình|desc=presentation skills TED talk structure storytelling visual design delivery body language|vi=kỹ năng thuyết trình,presentation skills|en=presentation skills|zh=演讲技巧`},
		{"SOFTSKILL2_FEEDBACK",3,`label=cho và nhận phản hồi|desc=feedback SBI Situation Behavior Impact growth mindset psychological safety radical candor|vi=cho và nhận phản hồi,feedback|en=giving receiving feedback|zh=反馈技巧`},
		{"SOFTSKILL2_CONFLICT",3,`label=quản lý xung đột|desc=conflict management Thomas-Kilmann model competing avoiding collaborating compromising accommodating|vi=quản lý xung đột,conflict management|en=conflict management|zh=冲突管理`},
		{"SOFTSKILL2_STORY",  3,`label=kể chuyện|desc=storytelling Pixar story spine hero's journey narrative arc structure emotion hook|vi=kể chuyện,storytelling|en=storytelling|zh=讲故事`},

		// ── ĐỊA LÝ KINH TẾ (ECON_GEO_) ──────────────────────────
		{"ECON_GEO_CLUSTER",  3,`label=cụm kinh tế|desc=economic cluster Silicon Valley Hollywood Detroit auto Krugman agglomeration economies Porter|vi=cụm kinh tế,economic cluster|en=economic cluster|zh=产业集群`},
		{"ECON_GEO_GLOBALIZATION",3,`label=toàn cầu hóa|desc=globalization trade FDI migration culture technology Friedman flat world backlash|vi=toàn cầu hóa,globalization|en=globalization|zh=全球化`},
		{"ECON_GEO_URBANIZATION",3,`label=đô thị hóa|desc=urbanization 56% 2022 4 tỷ urbanites megacity infrastructure rural-urban migration|vi=đô thị hóa,urbanization|en=urbanization|zh=城镇化`},

		// ── LUẬT QUỐC TẾ (INTLAW_) ───────────────────────────────
		{"INTLAW_UNCLOS",     3,`label=UNCLOS|desc=UN Convention Law of Sea 1982 200nm EEZ territorial sea continental shelf arbitration|vi=UNCLOS,Công ước Biển|en=UNCLOS|zh=联合国海洋法公约`},
		{"INTLAW_ICC",        3,`label=Tòa án Hình sự Quốc tế|desc=ICC International Criminal Court Rome Statute genocide war crime crimes against humanity|vi=Tòa án Hình sự Quốc tế,ICC|en=ICC|zh=国际刑事法院`},
		{"INTLAW_WTO2",       3,`label=WTO và thương mại|desc=WTO dispute settlement MFN GATT tariff non-tariff barrier subsidies anti-dumping|vi=WTO và thương mại,WTO trade|en=WTO trade|zh=世贸组织贸易`},

		// ── VĂN HÓA VIỆT NAM BỔ SUNG (VNCULTURE2_) ──────────────
		{"VNCULTURE2_TET",    3,`label=Tết Nguyên Đán|desc=Tết Lunar New Year Việt Nam hoa mai hoa đào bánh chưng lì xì gia đình sum họp|vi=Tết Nguyên Đán,Tet|en=Vietnamese Tet|zh=越南春节`},
		{"VNCULTURE2_AO_DAI", 3,`label=áo dài|desc=áo dài trang phục truyền thống Việt Nam UNESCO đề xuất lụa Hà Đông áo tứ thân|vi=áo dài|en=ao dai|zh=越南长袍`},
		{"VNCULTURE2_CA_TRU", 3,`label=ca trù|desc=ca trù UNESCO 2009 hát ả đào đàn đáy phách nghệ thuật quý tộc thế kỷ 15|vi=ca trù|en=ca tru|zh=越南歌筹`},
		{"VNCULTURE2_QUAN_HO",3,`label=quan họ|desc=quan họ Bắc Ninh UNESCO dân ca quan họ nam nữ đối đáp lễ hội mùa xuân|vi=quan họ Bắc Ninh|en=quan ho folk songs|zh=越南官贺民歌`},

		// ── TRIẾT HỌC NHẬN THỨC (EPIST_) ────────────────────────
		{"EPIST_EMPIRICISM",  3,`label=kinh nghiệm luận|desc=empiricism Locke Hume Berkeley tabula rasa sense experience induction knowledge|vi=kinh nghiệm luận,empiricism|en=empiricism|zh=经验主义`},
		{"EPIST_RATIONALISM", 3,`label=duy lý luận|desc=rationalism Descartes Spinoza Leibniz innate ideas reason cogito deduction clear distinct|vi=duy lý luận,rationalism|en=rationalism|zh=理性主义`},
		{"EPIST_PRAGMATISM",  3,`label=thực dụng luận|desc=pragmatism Peirce James Dewey truth utility consequences meaning action American philosophy|vi=thực dụng luận,pragmatism|en=pragmatism|zh=实用主义`},

		// ── KIẾN TRÚC PHẦN MỀM (SOFTARCH_) ──────────────────────
		{"SOFTARCH_EVENT",    3,`label=kiến trúc hướng sự kiện|desc=event-driven architecture EDA message queue Kafka RabbitMQ pub-sub reactive loose coupling|vi=kiến trúc hướng sự kiện,event-driven|en=event-driven architecture|zh=事件驱动架构`},
		{"SOFTARCH_CQRS",     3,`label=CQRS|desc=Command Query Responsibility Segregation read write model event sourcing Martin Fowler DDD|vi=CQRS|en=CQRS|zh=命令查询职责分离`},
		{"SOFTARCH_DDD",      3,`label=Domain-Driven Design|desc=DDD Eric Evans bounded context aggregate repository ubiquitous language strategic tactical|vi=Domain-Driven Design,DDD|en=Domain-Driven Design|zh=领域驱动设计`},

		// ── LỊCH SỬ CHÂU MỸ (AMERHIST2_) ────────────────────────
		{"AMERHIST2_REVOLUTION",3,`label=Cách mạng Mỹ|desc=American Revolution 1776 Declaration Independence Boston Tea Party George Washington 13 colonies|vi=Cách mạng Mỹ,American Revolution|en=American Revolution|zh=美国独立革命`},
		{"AMERHIST2_CIVIL_WAR",3,`label=Nội chiến Mỹ|desc=American Civil War 1861-65 slavery Lincoln Emancipation Proclamation Gettysburg 620000|vi=Nội chiến Mỹ,American Civil War|en=American Civil War|zh=美国内战`},
		{"AMERHIST2_GREAT_DEP",3,`label=Đại Suy thoái|desc=Great Depression 1929 stock crash unemployment 25% FDR New Deal Dust Bowl Keynes|vi=Đại Suy thoái,Great Depression|en=Great Depression|zh=大萧条`},
		{"AMERHIST2_CIVIL_RIGHTS",3,`label=Phong trào Dân quyền Mỹ|desc=Civil Rights Movement Martin Luther King Rosa Parks 1964 Act March Washington I Have a Dream|vi=Phong trào Dân quyền,Civil Rights|en=Civil Rights Movement|zh=美国民权运动`},

		// ── SINH HỌC BIỂN BỔ SUNG (MARINEBIO2_) ──────────────────
		{"MARINEBIO2_CORAL2", 3,`label=rạn san hô|desc=coral reef symbiosis zooxanthellae bleaching climate change 25% marine species biodiversity|vi=rạn san hô,coral reef|en=coral reef|zh=珊瑚礁`},
		{"MARINEBIO2_HYDRO_VENT",3,`label=lỗ thủy nhiệt|desc=hydrothermal vent chemosynthesis extremophile tube worm deep sea Galapagos Rift 1977|vi=lỗ thủy nhiệt,hydrothermal vent|en=hydrothermal vent|zh=热液喷口`},
		{"MARINEBIO2_PLANKTON",3,`label=sinh vật phù du|desc=plankton phytoplankton zooplankton photosynthesis marine food web oxygen CO2 bloom|vi=sinh vật phù du,plankton|en=plankton|zh=浮游生物`},

		// ── THỂ THAO QUỐC TẾ (SPORT2_) ───────────────────────────
		{"SPORT2_OLYMPICS",   3,`label=Olympic|desc=Olympic Games Athens 1896 IOC Baron de Coubertin 5 rings 206 countries summer winter|vi=Olympic|en=Olympics|zh=奥林匹克运动会`},
		{"SPORT2_FOOTBALL",   3,`label=bóng đá thế giới|desc=soccer football FIFA World Cup 1930 Pelé Maradona Messi Ronaldo Premier League Champions League|vi=bóng đá thế giới,football|en=football soccer|zh=世界足球`},
		{"SPORT2_TENNIS",     3,`label=quần vợt|desc=tennis Grand Slam Wimbledon Roland Garros US Open Australian Open Djokovic Federer Nadal|vi=quần vợt,tennis|en=tennis|zh=网球`},
		{"SPORT2_CHESS",      3,`label=cờ vua|desc=chess Kasparov Deep Blue 1997 Carlsen Elo rating FIDE tactical positional endgame|vi=cờ vua,chess|en=chess|zh=国际象棋`},

		// ── KHÍ HẬU VIỆT NAM (VNCLIMATE_) ───────────────────────
		{"VNCLIMATE_MONSOON", 3,`label=gió mùa Việt Nam|desc=Vietnam monsoon southwest northeast mùa khô mưa Bắc Trung Nam khí hậu nhiệt đới|vi=gió mùa Việt Nam,Vietnam monsoon|en=Vietnam monsoon|zh=越南季风`},
		{"VNCLIMATE_FLOOD",   3,`label=lũ lụt miền Trung|desc=miền Trung lũ lụt hàng năm bão Haiyan Damrey mất mát tài sản nước biển dâng|vi=lũ lụt miền Trung,central Vietnam flood|en=central Vietnam flooding|zh=越南中部洪涝`},

		// ── KỸ THUẬT ROBOT (ROBOT2_) ─────────────────────────────
		{"ROBOT2_SLAM",       3,`label=SLAM|desc=Simultaneous Localization and Mapping LIDAR particle filter EKF loop closure autonomous robot|vi=SLAM|en=SLAM robotics|zh=即时定位与地图构建`},
		{"ROBOT2_PERCEPTION", 3,`label=nhận thức robot|desc=robot perception computer vision depth camera point cloud semantic segmentation YOLO|vi=nhận thức robot,robot perception|en=robot perception|zh=机器人感知`},
		{"ROBOT2_MANIPULATOR",3,`label=cánh tay robot|desc=robot manipulator DOF forward inverse kinematics Denavit-Hartenberg workspace singularity|vi=cánh tay robot,robot manipulator|en=robot manipulator|zh=机械臂`},

		// ── TOÁN GIẢI TÍCH (CALCULUS_) ───────────────────────────
		{"CALCULUS_INTEGRAL", 3,`label=tích phân|desc=integral Riemann sum area under curve Newton-Leibniz theorem antiderivative substitution parts|vi=tích phân,integral|en=integral calculus|zh=积分`},
		{"CALCULUS_SERIES",   3,`label=chuỗi số|desc=series Taylor Maclaurin Fourier convergence radius ratio test harmonic geometric power|vi=chuỗi số,series|en=mathematical series|zh=数学级数`},
		{"CALCULUS_MULTIVAR", 3,`label=giải tích nhiều biến|desc=multivariable calculus partial derivative gradient Hessian Lagrange multiplier double integral|vi=giải tích nhiều biến,multivariable calculus|en=multivariable calculus|zh=多变量微积分`},

		// ── LỊCH SỬ CHÂU ÂU BỔ SUNG (EURHIST3_) ──────────────────
		{"EURHIST3_RENAISSANCE",3,`label=Phục Hưng|desc=Renaissance 14-17th century Italy humanism Medici Florence art science literature printing|vi=Phục Hưng,Renaissance|en=Renaissance|zh=文艺复兴`},
		{"EURHIST3_REFORMATION",3,`label=Cải cách Tôn giáo|desc=Protestant Reformation Martin Luther 1517 95 Theses printing press Calvin Geneva|vi=Cải cách Tôn giáo,Reformation|en=Protestant Reformation|zh=宗教改革`},
		{"EURHIST3_NAPOLEON", 3,`label=Napoleon|desc=Napoleon Bonaparte Corsica 1769-1821 Waterloo Napoleonic Code Continental Europe empire|vi=Napoleon|en=Napoleon Bonaparte|zh=拿破仑`},
		{"EURHIST3_EMPIRE",   3,`label=chủ nghĩa đế quốc châu Âu|desc=European imperialism 1870-1914 Africa Asia colonialism scramble Berlin Congress civilizing|vi=chủ nghĩa đế quốc châu Âu,European imperialism|en=European imperialism|zh=欧洲帝国主义`},

		// ── XÃ HỘI HỌC HIỆN ĐẠI (SOCIOL3_) ─────────────────────
		{"SOCIOL3_GENDER",    3,`label=giới và xã hội|desc=gender sociology Judith Butler performativity patriarchy feminism intersectionality gender pay gap|vi=giới và xã hội,gender sociology|en=gender sociology|zh=性别社会学`},
		{"SOCIOL3_RACE",      3,`label=chủng tộc và sắc tộc|desc=race ethnicity social construction structural racism whiteness privilege Kimberlé Crenshaw|vi=chủng tộc và sắc tộc,race ethnicity|en=race ethnicity sociology|zh=种族与民族`},
		{"SOCIOL3_DIGITAL",   3,`label=xã hội học kỹ thuật số|desc=digital sociology social media echo chamber filter bubble algorithmic influence platform society|vi=xã hội học kỹ thuật số,digital sociology|en=digital sociology|zh=数字社会学`},

		// ── PHÁT TRIỂN CÁ NHÂN (SELFDEV_) ────────────────────────
		{"SELFDEV_HABITS",    3,`label=thói quen|desc=habit loop cue routine reward Charles Duhigg keystone habit 21 days atomic habits James Clear|vi=thói quen,habits|en=habits|zh=习惯`},
		{"SELFDEV_MINDSET",   3,`label=tư duy phát triển|desc=growth mindset Carol Dweck fixed vs growth praise effort talent neuroplasticity|vi=tư duy phát triển,growth mindset|en=growth mindset|zh=成长型思维`},
		{"SELFDEV_JOURNAL",   3,`label=nhật ký và phản tư|desc=journaling Marcus Aurelius Meditations gratitude journal stream of consciousness self-reflection|vi=nhật ký và phản tư,journaling|en=journaling|zh=日记与反思`},
		{"SELFDEV_IKIGAI",    3,`label=Ikigai|desc=Ikigai 生き甲斐 reason for being passion mission vocation profession Okinawa longevity|vi=Ikigai,lý do sống|en=Ikigai|zh=生き甲斐`},

		// ── THIÊN NHIÊN VIỆT NAM (VNNATURE_) ─────────────────────
		{"VNNATURE_HALONG",   3,`label=vịnh Hạ Long|desc=Hạ Long Bay UNESCO 1994 2023 limestone karst 1600 đảo Cat Ba National Park du lịch|vi=vịnh Hạ Long,Halong Bay|en=Halong Bay|zh=下龙湾`},
		{"VNNATURE_PHONG_NHA",3,`label=Phong Nha-Kẻ Bàng|desc=Phong Nha UNESCO 2003 Sơn Đoòng hang động lớn nhất thế giới Quảng Bình|vi=Phong Nha-Kẻ Bàng|en=Phong Nha Ke Bang|zh=丰芽己傍`},
		{"VNNATURE_CAT_TIEN", 3,`label=vườn quốc gia Cát Tiên|desc=Cat Tien National Park Đồng Nai gấu chó tê giác Java (tuyệt chủng) UNESCO rừng nguyên sinh|vi=vườn quốc gia Cát Tiên,Cat Tien|en=Cat Tien National Park|zh=吉仙国家公园`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
	}
	fmt.Printf("\n✚ %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes\n", nn)
	if nn >= 3400 { fmt.Println("🎉 MILESTONE 3400!") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
