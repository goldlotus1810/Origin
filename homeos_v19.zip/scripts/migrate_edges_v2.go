//go:build ignore

// migrate_edges_v2.go — migrate homeos.olang edge table từ V1 (17B) sang V2 (21B)
// Dùng: go run scripts/migrate_edges_v2.go homeos.olang
//
// V1: [src:8B][dst:8B][type:1B]         = 17 bytes/edge
// V2: [src:8B][dst:8B][type:1B][w:4B]   = 21 bytes/edge (weight float32 = 1.0 default)

package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: go run scripts/migrate_edges_v2.go <file.olang>")
		os.Exit(1)
	}
	path := os.Args[1]

	raw, err := os.ReadFile(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "read: %v\n", err)
		os.Exit(1)
	}

	// Đọc edge count từ header
	if len(raw) < 64 {
		fmt.Fprintln(os.Stderr, "file too small")
		os.Exit(1)
	}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	if nedges == 0 {
		fmt.Println("No edges to migrate.")
		return
	}

	// Xác định version hiện tại
	fileSize := len(raw)
	v1EdgeStart := fileSize - nedges*17
	v2EdgeStart := fileSize - nedges*21

	if v1EdgeStart < 64 && v2EdgeStart < 64 {
		fmt.Fprintln(os.Stderr, "cannot determine edge format")
		os.Exit(1)
	}

	// Check xem đã là V2 chưa
	if (fileSize-64)%21 == nedges*21%21 {
		// Thử kiểm tra: nếu phần nodes + v2 edges = fileSize
		nodeSection := fileSize - nedges*21
		if nodeSection >= 280 {
			// Có thể đã là V2 — kiểm tra magic
			fmt.Fprintf(os.Stderr, "Checking if already V2... nodeSection=%d\n", nodeSection)
		}
	}

	// Đọc V1 edges
	if v1EdgeStart < 280 {
		fmt.Fprintf(os.Stderr, "edge start %d < 280 (node section start)\n", v1EdgeStart)
		os.Exit(1)
	}

	type edgeV1 struct {
		src   uint64
		dst   uint64
		etype uint8
	}
	edges := make([]edgeV1, nedges)
	for i := 0; i < nedges; i++ {
		base := v1EdgeStart + i*17
		if base+17 > len(raw) {
			fmt.Fprintf(os.Stderr, "truncated at edge %d\n", i)
			break
		}
		edges[i].src = binary.BigEndian.Uint64(raw[base : base+8])
		edges[i].dst = binary.BigEndian.Uint64(raw[base+8 : base+16])
		edges[i].etype = raw[base+16]
	}

	// Rebuild file: nodes section giữ nguyên + V2 edges mới
	nodeSection := raw[:v1EdgeStart]

	// Build V2 edge table
	edgeDataV2 := make([]byte, nedges*21)
	defaultWeight := float32(1.0)
	wBits := math.Float32bits(defaultWeight)
	for i, e := range edges {
		base := i * 21
		binary.BigEndian.PutUint64(edgeDataV2[base:], e.src)
		binary.BigEndian.PutUint64(edgeDataV2[base+8:], e.dst)
		edgeDataV2[base+16] = e.etype
		binary.BigEndian.PutUint32(edgeDataV2[base+17:], wBits)
	}

	// Ghép lại
	newFile := make([]byte, len(nodeSection)+len(edgeDataV2))
	copy(newFile, nodeSection)
	copy(newFile[len(nodeSection):], edgeDataV2)

	// Backup
	backupPath := path + ".bak_v1_edges"
	if err := os.WriteFile(backupPath, raw, 0644); err != nil {
		fmt.Fprintf(os.Stderr, "backup failed: %v\n", err)
		os.Exit(1)
	}

	// Write
	if err := os.WriteFile(path, newFile, 0644); err != nil {
		fmt.Fprintf(os.Stderr, "write failed: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("✅ Migrated %d edges V1→V2\n", nedges)
	fmt.Printf("   Before: %d bytes (17B/edge)\n", fileSize)
	fmt.Printf("   After:  %d bytes (21B/edge)\n", len(newFile))
	fmt.Printf("   +%d bytes (weight fields)\n", len(newFile)-fileSize)
	fmt.Printf("   Backup: %s\n", backupPath)
}
