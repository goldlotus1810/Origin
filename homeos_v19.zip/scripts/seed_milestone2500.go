//go:build ignore
// go run scripts/seed_milestone2500.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── NGÔN NGỮ HỌC (LING_) ─────────────────────────────────
		{"LING_PHONETICS",   3, `label=ngữ âm học|desc=nghiên cứu âm thanh ngôn ngữ IPA phụ âm nguyên âm thanh điệu ngữ điệu giọng nói|vi=ngữ âm học,phonetics|en=phonetics|zh=语音学`},
		{"LING_SEMANTICS",   3, `label=ngữ nghĩa học|desc=nghiên cứu ý nghĩa từ ngữ câu đồng nghĩa trái nghĩa ẩn dụ ngữ cảnh|vi=ngữ nghĩa học,semantics|en=semantics|zh=语义学`},
		{"LING_PRAGMATICS",  3, `label=dụng học|desc=nghiên cứu ngôn ngữ trong ngữ cảnh sử dụng hành động ngôn từ hàm ý hội thoại|vi=dụng học,pragmatics|en=pragmatics|zh=语用学`},
		{"LING_MORPHOLOGY",  3, `label=hình thái học|desc=nghiên cứu cấu trúc từ hình vị tiền tố hậu tố gốc từ biến cách|vi=hình thái học,morphology|en=morphology|zh=形态学`},

		// ── KHOA HỌC NHẬN THỨC (COG_) ────────────────────────────
		{"COG_ATTENTION",    3, `label=chú ý|desc=khả năng tập trung vào kích thích cụ thể chú ý có chọn lọc đa nhiệm ADHD mindfulness|vi=chú ý,attention|en=attention|zh=注意力`},
		{"COG_LANGUAGE_ACQ", 3, `label=thụ đắc ngôn ngữ|desc=quá trình học ngôn ngữ tự nhiên trẻ em Chomsky LAD universal grammar giai đoạn nhạy cảm|vi=thụ đắc ngôn ngữ,language acquisition|en=language acquisition|zh=语言习得`},
		{"COG_DECISION",     3, `label=ra quyết định|desc=quá trình nhận thức chọn lựa heuristics bias Kahneman System 1 2 rủi ro không chắc chắn|vi=ra quyết định,decision making|en=decision making|zh=决策`},
		{"COG_CREATIVITY",   3, `label=sáng tạo|desc=khả năng tạo ra ý tưởng mới divergent thinking flow state brainstorming đổi mới|vi=sáng tạo,creativity|en=creativity|zh=创造力`},

		// ── THIÊN NHIÊN VIỆT NAM (VNNATURE_) ─────────────────────
		{"VNNATURE_FOREST",  3, `label=rừng Việt Nam|desc=rừng nhiệt đới Cúc Phương Phong Nha Cát Tiên đa dạng sinh học bảo tồn|vi=rừng Việt Nam,rừng nhiệt đới|en=Vietnam forest|zh=越南森林`},
		{"VNNATURE_SEA",     3, `label=biển Việt Nam|desc=3260 km bờ biển Đông tài nguyên thủy sản du lịch Phú Quốc Côn Đảo Nha Trang|vi=biển Việt Nam,bờ biển|en=Vietnam sea|zh=越南海洋`},
		{"VNNATURE_ETHNIC",  3, `label=dân tộc Việt Nam|desc=54 dân tộc Kinh Tày Thái Mường H'Mông đa văn hóa vùng núi trang phục truyền thống|vi=dân tộc Việt Nam,54 dân tộc|en=Vietnam ethnic groups|zh=越南民族`},

		// ── NGHỆ THUẬT VIỆT NAM (VNART_) ─────────────────────────
		{"VNART_CA_TRU",     3, `label=ca trù|desc=nghệ thuật ca hát truyền thống Bắc Việt Nam UNESCO đàn đáy trống chầu phách|vi=ca trù|en=ca tru|zh=越南祭祀歌`},
		{"VNART_QUAN_HO",    3, `label=quan họ Bắc Ninh|desc=dân ca đối đáp Bắc Ninh UNESCO nam nữ hát đối câu ca liền anh liền chị|vi=quan họ,quan họ Bắc Ninh|en=Quan Ho folk songs|zh=官贺民歌`},
		{"VNART_DONG_HO",    3, `label=tranh Đông Hồ|desc=tranh dân gian Bắc Ninh in từ bản khắc gỗ giấy điệp màu tự nhiên gà lợn cóc|vi=tranh Đông Hồ,Đông Hồ|en=Dong Ho painting|zh=东湖版画`},

		// ── ẨM THỰC VIỆT NAM (VNFOOD_) ───────────────────────────
		{"VNFOOD_BANH_MI",   3, `label=bánh mì|desc=bánh mì kẹp thịt Việt Nam baguette Pháp pa-tê chả lụa dưa cải The Guardian world's best|vi=bánh mì,banh mi|en=banh mi|zh=越式面包`},
		{"VNFOOD_BUN_BO",    3, `label=bún bò Huế|desc=món bún đặc sản Huế nước dùng sả mắm ruốc bò giò heo cay nồng đặc trưng miền Trung|vi=bún bò Huế,bún bò|en=bun bo Hue|zh=顺化牛肉米线`},
		{"VNFOOD_COM_TAM",   3, `label=cơm tấm|desc=cơm gạo tấm Sài Gòn sườn nướng bì chả trứng ốp la đặc sản Nam Bộ|vi=cơm tấm,broken rice|en=com tam|zh=碎米饭`},
		{"VNFOOD_CHE",       3, `label=chè|desc=món tráng miệng ngọt Việt Nam đậu xanh đậu đỏ bột lọc dừa thạch đặc sản miền nhiệt đới|vi=chè,che|en=Vietnamese sweet soup|zh=越南甜品`},

		// ── KHOA HỌC XÃ HỘI (SOC3_) ──────────────────────────────
		{"SOC3_URBANIZATION2",3,`label=đô thị hóa Việt Nam|desc=di dân Hà Nội TP.HCM nhà ở bất động sản hạ tầng giao thông ô nhiễm|vi=đô thị hóa Việt Nam|en=Vietnam urbanization|zh=越南城镇化`},
		{"SOC3_AGING_VN",    3, `label=già hóa dân số Việt Nam|desc=tỷ lệ người cao tuổi tăng hệ thống hưu trí chăm sóc sức khỏe lực lượng lao động|vi=già hóa dân số,dân số già|en=Vietnam aging population|zh=越南人口老龄化`},
		{"SOC3_MIDDLE_CLASS",3, `label=tầng lớp trung lưu|desc=thu nhập 5-30 USD/ngày tiêu dùng giáo dục du lịch Châu Á Việt Nam tăng trưởng|vi=tầng lớp trung lưu,middle class|en=middle class|zh=中产阶级`},

		// ── KHOA HỌC KHÁC (SCI_) ─────────────────────────────────
		{"SCI_COMPLEXITY",   3, `label=lý thuyết phức hợp|desc=hệ thống phức tạp nổi lên tự tổ chức chaos Santa Fe Institute mạng lưới|vi=lý thuyết phức hợp,complexity theory|en=complexity theory|zh=复杂性理论`},
		{"SCI_SYSTEMS",      3, `label=lý thuyết hệ thống|desc=tư duy hệ thống phản hồi vòng lặp emergence cybernetics Meadows limits to growth|vi=lý thuyết hệ thống,systems theory|en=systems theory|zh=系统论`},
		{"SCI_CHAOS",        3, `label=lý thuyết hỗn loạn|desc=chaos theory hiệu ứng bướm hệ phi tuyến nhạy cảm điều kiện đầu Lorenz fractal|vi=lý thuyết hỗn loạn,chaos theory|en=chaos theory|zh=混沌理论`},
		{"SCI_INFORMATION",  3, `label=lý thuyết thông tin|desc=Claude Shannon entropy thông tin bit nén dữ liệu kênh thông tin mã hóa|vi=lý thuyết thông tin,information theory|en=information theory|zh=信息论`},

		// ── LỊCH SỬ THẾ GIỚI BỔ SUNG (WORLD_) ───────────────────
		{"WORLD_COLD_WAR",   3, `label=Chiến tranh Lạnh|desc=1947-1991 Mỹ Liên Xô đối đầu ý thức hệ chạy đua vũ trang không gian Cuba|vi=Chiến tranh Lạnh,Cold War|en=Cold War|zh=冷战`},
		{"WORLD_COLONIALISM",3, `label=chủ nghĩa thực dân|desc=đế quốc Châu Âu chiếm đóng Châu Á Phi Mỹ La Tinh khai thác tài nguyên độc lập|vi=chủ nghĩa thực dân,colonialism|en=colonialism|zh=殖民主义`},
		{"WORLD_RENAISSANCE",3, `label=Phục Hưng|desc=phong trào văn hóa Châu Âu 14-17 thế kỷ nghệ thuật khoa học Leonardo Michelangelo|vi=Phục Hưng,Renaissance|en=Renaissance|zh=文艺复兴`},
		{"WORLD_INDUSTRIAL", 3, `label=Cách mạng Công nghiệp|desc=1760-1840 Anh máy hơi nước sản xuất hàng loạt đô thị hóa lao động tư bản|vi=Cách mạng Công nghiệp,Industrial Revolution|en=Industrial Revolution|zh=工业革命`},
		{"WORLD_ENLIGHTEN",  3, `label=Khai Sáng|desc=thế kỷ 18 Châu Âu lý trí khoa học nhân quyền Voltaire Rousseau Locke dân chủ|vi=Khai Sáng,Enlightenment|en=Enlightenment|zh=启蒙运动`},

		// ── CÔNG NGHỆ TƯƠNG LAI (FUTURE_) ────────────────────────
		{"FUTURE_AGI",       3, `label=trí tuệ tổng quát nhân tạo|desc=AGI AI thực hiện mọi nhiệm vụ trí tuệ con người Anthropic OpenAI an toàn|vi=AGI,trí tuệ tổng quát|en=AGI,artificial general intelligence|zh=通用人工智能`},
		{"FUTURE_FUSION",    3, `label=năng lượng nhiệt hạch|desc=fusion energy ITER tokamak plasma deuterium tritium nguồn năng lượng vô hạn sạch|vi=nhiệt hạch,fusion energy|en=nuclear fusion|zh=核聚变`},
		{"FUTURE_LONGEVITY", 3, `label=kéo dài tuổi thọ|desc=longevity research telomerase senolytics caloric restriction rapamycin Bryan Johnson|vi=kéo dài tuổi thọ,longevity|en=longevity|zh=长寿`},
		{"FUTURE_SPACE_COL", 3, `label=thuộc địa hóa không gian|desc=colonize Mars Moon base Elon Musk SpaceX terraforming đa hành tinh|vi=thuộc địa hóa không gian,space colonization|en=space colonization|zh=太空殖民`},
		{"FUTURE_NEURALINK", 3, `label=giao diện não-máy tính|desc=BCI brain-computer interface Neuralink điều khiển máy tính bằng suy nghĩ y tế tê liệt|vi=giao diện não-máy tính,BCI,Neuralink|en=BCI,brain-computer interface|zh=脑机接口`},

		// ── KINH TẾ ASEAN (ASEAN_) ────────────────────────────────
		{"ASEAN_SINGAPORE",  3, `label=Singapore|desc=thành phố quốc gia Đông Nam Á trung tâm tài chính cảng biển GDP đầu người cao nhất khu vực|vi=Singapore|en=Singapore|zh=新加坡`},
		{"ASEAN_THAILAND",   3, `label=Thái Lan|desc=vương quốc Đông Nam Á du lịch thức ăn đường phố Phật giáo Bangkok Muay Thai xuất khẩu gạo|vi=Thái Lan,Thailand|en=Thailand|zh=泰国`},
		{"ASEAN_INDONESIA",  3, `label=Indonesia|desc=quốc gia quần đảo lớn nhất thế giới 270 triệu dân dầu mỏ than đá Bali Borobudur G20|vi=Indonesia|en=Indonesia|zh=印度尼西亚`},
		{"ASEAN_PHILIPPINES",3, `label=Philippines|desc=quần đảo 7641 đảo tiếng Anh BPO kiều hối công nghệ du lịch Boracay|vi=Philippines|en=Philippines|zh=菲律宾`},

		// ── THỂ THAO VIỆT NAM (VNSPORT_) ─────────────────────────
		{"VNSPORT_FOOTBALL", 3, `label=bóng đá Việt Nam|desc=đội tuyển quốc gia Park Hang-seo AFF Cup SEA Games FIFA World Cup 2026|vi=bóng đá Việt Nam,đội tuyển Việt Nam|en=Vietnam football|zh=越南足球`},
		{"VNSPORT_MARTIAL",  3, `label=võ thuật Việt Nam|desc=Vovinam võ cổ truyền Việt Nam taekwondo judo SEA Games huy chương|vi=võ thuật Việt Nam,Vovinam|en=Vietnamese martial arts|zh=越南武术`},

		// ── TRIẾT HỌC HIỆN ĐẠI (MOD_PHIL_) ──────────────────────
		{"MOD_PHIL_EXISTENT",3, `label=chủ nghĩa hiện sinh|desc=Sartre Camus tự do chịu trách nhiệm ý nghĩa cuộc sống lo âu hiện sinh|vi=chủ nghĩa hiện sinh,existentialism|en=existentialism|zh=存在主义`},
		{"MOD_PHIL_UTILIT",  3, `label=chủ nghĩa công lợi|desc=Bentham Mill tối đa hóa hạnh phúc lợi ích lớn nhất cho số đông đạo đức kết quả|vi=chủ nghĩa công lợi,utilitarianism|en=utilitarianism|zh=功利主义`},
		{"MOD_PHIL_MARXISM", 3, `label=chủ nghĩa Marx|desc=Marx Engels biện chứng duy vật giai cấp đấu tranh tư bản lao động cộng sản|vi=chủ nghĩa Marx,Marxism|en=Marxism|zh=马克思主义`},

		// ── Y HỌC CỔ TRUYỀN (TRAD_MED_) ─────────────────────────
		{"TRAD_MED_TCM",     3, `label=y học cổ truyền Trung Hoa|desc=TCM âm dương ngũ hành châm cứu thảo dược khí huyết kinh lạc|vi=y học cổ truyền,TCM,đông y|en=TCM,traditional Chinese medicine|zh=中医`},
		{"TRAD_MED_VN",      3, `label=y học cổ truyền Việt Nam|desc=đông y Việt Nam Hải Thượng Lãn Ông thuốc nam châm cứu bài thuốc dân gian|vi=y học cổ truyền Việt Nam,thuốc nam|en=Vietnamese traditional medicine|zh=越南传统医学`},
		{"TRAD_MED_AYUR",    3, `label=Ayurveda|desc=y học cổ truyền Ấn Độ dosha vata pitta kapha thảo dược yoga thiền định sức khỏe toàn diện|vi=Ayurveda,y học Ấn Độ|en=Ayurveda|zh=阿育吠陀`},

		// ── DÂN SỐ HỌC (DEMO_) ───────────────────────────────────
		{"DEMO_POPULATION",  3, `label=dân số thế giới|desc=8 tỷ người 2022 tăng trưởng chậm lại già hóa châu Á Phi trẻ nhất|vi=dân số thế giới,world population|en=world population|zh=世界人口`},
		{"DEMO_MIGRATION",   3, `label=di cư|desc=di chuyển dân số quốc tế tị nạn lao động chính sách nhập cư hội nhập|vi=di cư,migration,nhập cư|en=migration|zh=移民`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"LING_SEMANTICS",    "AI2_NLP",            "used-in"},
		{"LING_PHONETICS",    "AI2_NLP",            "studied-by"},
		{"COG_ATTENTION",     "PSY2_MEMORY",        "enables"},
		{"COG_DECISION",      "MICRO2_BEHAV",       "underlies"},
		{"COG_CREATIVITY",    "COG_DECISION",       "extends"},
		{"VNNATURE_SEA",      "VNTRAVEL_DANANG",    "features-in"},
		{"VNFOOD_BANH_MI",    "VNTRAVEL_HCMC",      "known-in"},
		{"VNFOOD_BUN_BO",     "VNTRAVEL_DANANG",    "from"},
		{"WORLD_COLD_WAR",    "VNHIST_1975",        "context-of"},
		{"WORLD_INDUSTRIAL",  "WORLD_COLONIALISM",  "enabled"},
		{"WORLD_RENAISSANCE", "WORLD_ENLIGHTEN",    "preceded"},
		{"FUTURE_AGI",        "AI2_LLM",            "beyond"},
		{"FUTURE_FUSION",     "NRG_GEOTHERMAL",     "alternative-to"},
		{"FUTURE_NEURALINK",  "AI2_COMPUTER_VISION","integrates"},
		{"ASEAN_SINGAPORE",   "VNECON_FDI",         "source-of"},
		{"SOC3_MIDDLE_CLASS", "VNECON_STARTUP",     "fuels"},
		{"MOD_PHIL_MARXISM",  "WORLD_COLD_WAR",     "influenced"},
		{"TRAD_MED_VN",       "TRAD_MED_TCM",       "derived-from"},
		{"DEMO_MIGRATION",    "SOC3_MIDDLE_CLASS",  "creates"},
		{"SCI_INFORMATION",   "AI2_LLM",            "basis-of"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2500 { fmt.Println("🎉 MILESTONE 2500!") }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i
		for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]
		if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}
	return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'; rec[1] = 'D'; rec[2] = layer
	copy(rec[3:], islv[:])
	rec[15] = byte(len(dna) >> 24); rec[16] = byte(len(dna) >> 16)
	rec[17] = byte(len(dna) >> 8); rec[18] = byte(len(dna))
	rec[19] = uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0] = layer; v[1] = h[0]%200 + 1; v[2] = h[1]%200 + 1; v[3] = h[2]%200 + 1
	v[4] = h[3]; v[5] = h[4]; v[6] = h[5]; v[7] = h[6]
	return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16]) + 1
	out[12] = byte(n >> 24); out[13] = byte(n >> 16); out[14] = byte(n >> 8); out[15] = byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl
		if ne2 > end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])] = v
		i = ne2
	}
	return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel)
	raw = append(raw, e...)
	n := be32(raw[16:20]) + 1
	raw[16] = byte(n >> 24); raw[17] = byte(n >> 16); raw[18] = byte(n >> 8); raw[19] = byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"used-in": 1, "studied-by": 2, "enables": 3, "underlies": 4, "extends": 5,
		"features-in": 6, "known-in": 7, "from": 8, "context-of": 9, "enabled": 10,
		"preceded": 11, "beyond": 12, "alternative-to": 13, "integrates": 14,
		"source-of": 15, "fuels": 16, "influenced": 17, "derived-from": 18,
		"creates": 19, "basis-of": 20,
	}
	if b, ok := m[r]; ok { return b }
	return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl
		if ne2 > end { break }
		m[string(raw[i+20+dl:ne2])] = true
		i = ne2
	}
	return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
