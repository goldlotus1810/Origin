//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	existing := readNames(raw)
	nodes := []Node{
		{"SPORT2_ESPORT",   3, `label=thể thao điện tử|desc=thi đấu game chuyên nghiệp League of Legends DOTA CS:GO giải thưởng triệu đô khán giả toàn cầu|vi=thể thao điện tử,esport|en=esport,esports|zh=电子竞技`},
		{"SPORT2_WELLNESS", 3, `label=sức khỏe toàn diện|desc=phương pháp chăm sóc thể chất tinh thần xã hội yoga thiền định giấc ngủ dinh dưỡng|vi=sức khỏe toàn diện,wellness|en=wellness|zh=健康`},
		{"TECH3_EDGE",      3, `label=điện toán biên|desc=xử lý dữ liệu gần nguồn thay vì đám mây IoT xe tự lái latency thấp|vi=điện toán biên,edge computing|en=edge computing|zh=边缘计算`},
		{"TECH3_DIGITAL_TWIN",3,`label=bản sao số|desc=mô hình ảo của vật thể hệ thống thực trong thế giới số tối ưu hóa dự đoán nhà máy|vi=bản sao số,digital twin|en=digital twin|zh=数字孪生`},
		{"ECON3_ESG",       3, `label=đầu tư ESG|desc=tiêu chí môi trường xã hội quản trị trong đầu tư ESG reporting bền vững tài chính xanh|vi=đầu tư ESG,ESG|en=ESG investing|zh=ESG投资`},
		{"ECON3_REMITTANCE",3, `label=kiều hối|desc=tiền gửi của người lao động ở nước ngoài về nước GDP Việt Nam Philippines World Bank|vi=kiều hối,remittance|en=remittance|zh=汇款`},
		{"BIO3_SYNTHETIC",  3, `label=sinh học tổng hợp|desc=thiết kế tạo ra sinh vật mới từ đầu DNA tổng hợp biofuel dược phẩm J. Craig Venter|vi=sinh học tổng hợp,synthetic biology|en=synthetic biology|zh=合成生物学`},
		{"BIO3_AGING",      3, `label=khoa học lão hóa|desc=nghiên cứu quá trình lão hóa tế bào telomere senescence kéo dài tuổi thọ|vi=khoa học lão hóa,aging science|en=aging science,longevity|zh=老龄化科学`},
		{"GEO3_URBANIZATION",3,`label=đô thị hóa|desc=di dân từ nông thôn vào thành thị thành phố thông minh megacity bất bình đẳng cơ sở hạ tầng|vi=đô thị hóa,urbanization|en=urbanization|zh=城镇化`},
		{"PSYCH3_SOCIAL",   3, `label=tâm lý xã hội|desc=nghiên cứu ảnh hưởng người khác lên hành vi tuân thủ theo nhóm thiên kiến nhận thức|vi=tâm lý xã hội,social psychology|en=social psychology|zh=社会心理学`},
	}
	added := 0
	for _, nd := range nodes {
		if existing[nd.name] { continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ +%d nodes → %d total, %d edges\n", added, nn, be32(raw[16:20]))
	if nn >= 2400 { fmt.Println("🎉 MILESTONE 2400!") }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
