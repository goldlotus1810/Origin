//go:build ignore
// Seed domain Hóa học + Lịch sử/Địa lý vào homeos.olang
// Chạy: go run scripts/seed_chemistry_history.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ Đọc: %d bytes, %d nodes, %d edges\n",
		len(raw), be32(raw[12:16]), be32(raw[16:20]))

	existing := readNames(raw)

	nodes := []Node{
		// ── HÓA HỌC ──────────────────────────────────────────────
		{"CHEM_ELEMENT",     3, `label=nguyên tố|desc=chất tinh khiết không thể phân tách thành chất đơn giản hơn bằng phản ứng hóa học|vi=nguyên tố,element|en=chemical element|zh=元素`},
		{"CHEM_ATOM",        3, `label=nguyên tử hóa học|desc=đơn vị nhỏ nhất của nguyên tố mang tính chất hóa học gồm proton neutron electron|vi=nguyên tử hóa học|en=chemical atom|zh=化学原子`},
		{"CHEM_MOLECULE",    3, `label=phân tử|desc=nhóm nguyên tử liên kết cộng hóa trị ổn định đơn vị nhỏ nhất của hợp chất|vi=phân tử,molecule|en=molecule|zh=分子`},
		{"CHEM_BOND",        3, `label=liên kết hóa học|desc=lực hút giữ các nguyên tử lại với nhau cộng hóa trị ion kim loại|vi=liên kết hóa học,chemical bond|en=chemical bond|zh=化学键`},
		{"CHEM_REACTION",    3, `label=phản ứng hóa học|desc=quá trình chất hóa học biến đổi tạo ra chất mới bảo toàn khối lượng|vi=phản ứng hóa học,reaction|en=chemical reaction|zh=化学反应`},
		{"CHEM_ACID",        3, `label=axit|desc=chất cho proton pH<7 vị chua phản ứng với bazơ tạo muối và nước|vi=axit,acid|en=acid|zh=酸`},
		{"CHEM_BASE",        3, `label=bazơ|desc=chất nhận proton pH>7 phản ứng với axit tạo muối và nước|vi=bazơ,base,kiềm|en=base|zh=碱`},
		{"CHEM_SALT",        3, `label=muối|desc=hợp chất ion tạo thành từ phản ứng axit-bazơ ví dụ NaCl|vi=muối,salt|en=salt|zh=盐`},
		{"CHEM_PERIODIC",    3, `label=bảng tuần hoàn|desc=bảng sắp xếp nguyên tố hóa học theo số nguyên tử và tính chất 118 nguyên tố|vi=bảng tuần hoàn,periodic table|en=periodic table|zh=元素周期表`},
		{"CHEM_OXIDATION",   3, `label=oxy hóa|desc=quá trình mất electron tăng số oxy hóa trong phản ứng hóa học|vi=oxy hóa,oxidation|en=oxidation|zh=氧化`},
		{"CHEM_REDUCTION",   3, `label=khử|desc=quá trình nhận electron giảm số oxy hóa trong phản ứng redox|vi=khử,reduction|en=reduction|zh=还原`},
		{"CHEM_CATALYST",    3, `label=chất xúc tác|desc=chất làm tăng tốc phản ứng hóa học mà không bị tiêu thụ enzyme là ví dụ sinh học|vi=chất xúc tác,catalyst|en=catalyst|zh=催化剂`},
		{"CHEM_POLYMER",     3, `label=polyme|desc=đại phân tử gồm đơn vị lặp lại monomer nhựa cao su sợi tổng hợp|vi=polyme,polymer|en=polymer|zh=聚合物`},
		{"CHEM_SOLUTION",    3, `label=dung dịch|desc=hỗn hợp đồng nhất chất tan trong dung môi ví dụ muối tan trong nước|vi=dung dịch,solution|en=solution|zh=溶液`},
		{"CHEM_PH",          3, `label=pH|desc=thang đo độ axit bazơ từ 0 đến 14 pH=7 trung tính|vi=pH,độ pH|en=pH|zh=pH值`},
		{"CHEM_CARBON",      3, `label=carbon|desc=nguyên tố C số nguyên tử 6 cơ sở của hóa học hữu cơ kim cương graphene|vi=carbon,cacbon|en=carbon|zh=碳`},
		{"CHEM_WATER",       3, `label=nước|desc=hợp chất H₂O phân tử cực phân dung môi phổ biến nhất sự sống|vi=nước,water|en=water|zh=水`},
		{"CHEM_ORGANIC",     3, `label=hóa học hữu cơ|desc=ngành nghiên cứu hợp chất carbon hydro oxy nitơ dầu mỏ thuốc dược phẩm|vi=hóa học hữu cơ,organic chemistry|en=organic chemistry|zh=有机化学`},

		// ── LỊCH SỬ / ĐỊA LÝ ────────────────────────────────────
		{"GEO_CONTINENT",    3, `label=châu lục|desc=khối đất liền lớn trên Trái Đất 7 châu lục châu Á châu Âu châu Phi Mỹ Úc Nam Cực|vi=châu lục,continent|en=continent|zh=大陆`},
		{"GEO_COUNTRY",      3, `label=quốc gia|desc=vùng lãnh thổ có chính phủ độc lập chủ quyền và biên giới|vi=quốc gia,đất nước,country|en=country|zh=国家`},
		{"GEO_OCEAN",        3, `label=đại dương|desc=vùng nước mặn rộng lớn bao phủ 71% Trái Đất Thái Bình Dương lớn nhất|vi=đại dương,ocean|en=ocean|zh=海洋`},
		{"GEO_MOUNTAIN",     3, `label=núi|desc=địa hình cao nhô lên khỏi mặt đất Everest cao nhất 8849m|vi=núi,mountain|en=mountain|zh=山`},
		{"GEO_RIVER",        3, `label=sông|desc=dòng nước tự nhiên chảy từ nguồn ra biển hồ Amazon dài nhất|vi=sông,river|en=river|zh=河流`},
		{"GEO_CITY",         3, `label=thành phố|desc=khu dân cư đông đúc có cơ sở hạ tầng phát triển trung tâm kinh tế văn hóa|vi=thành phố,city|en=city|zh=城市`},
		{"HIST_CIVILIZATION",3, `label=nền văn minh|desc=xã hội phức tạp với chữ viết đô thị luật pháp và thể chế chính trị|vi=nền văn minh,civilization|en=civilization|zh=文明`},
		{"HIST_REVOLUTION",  3, `label=cách mạng|desc=sự thay đổi căn bản và đột ngột về chính trị xã hội hoặc công nghệ|vi=cách mạng,revolution|en=revolution|zh=革命`},
		{"HIST_EMPIRE",      3, `label=đế chế|desc=nhà nước rộng lớn cai trị nhiều dân tộc lãnh thổ bởi hoàng đế|vi=đế chế,empire|en=empire|zh=帝国`},
		{"HIST_DEMOCRACY",   3, `label=dân chủ|desc=hệ thống chính trị người dân có quyền bầu cử và kiểm soát chính phủ|vi=dân chủ,democracy|en=democracy|zh=民主`},
		{"HIST_WAR",         3, `label=chiến tranh|desc=xung đột vũ trang giữa các quốc gia hoặc nhóm người gây tổn thất người và vật chất|vi=chiến tranh,war|en=war|zh=战争`},
		{"HIST_CULTURE",     3, `label=văn hóa|desc=tổng thể giá trị ngôn ngữ nghệ thuật tập tục của một cộng đồng|vi=văn hóa,culture|en=culture|zh=文化`},
		{"HIST_TRADE",       3, `label=thương mại|desc=trao đổi hàng hóa dịch vụ giữa các cá nhân hay quốc gia|vi=thương mại,trade|en=trade|zh=贸易`},
		{"GEO_CLIMATE",      3, `label=khí hậu|desc=điều kiện thời tiết trung bình của khu vực trong thời gian dài nhiệt đới ôn đới|vi=khí hậu,climate|en=climate|zh=气候`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Hóa học nội bộ
		{"CHEM_ELEMENT",  "CHEM_PERIODIC",  "organized-in"},
		{"CHEM_ATOM",     "CHEM_ELEMENT",   "is-a"},
		{"CHEM_MOLECULE", "CHEM_ATOM",      "composed-of"},
		{"CHEM_BOND",     "CHEM_MOLECULE",  "holds-together"},
		{"CHEM_REACTION", "CHEM_MOLECULE",  "transforms"},
		{"CHEM_ACID",     "CHEM_REACTION",  "undergoes"},
		{"CHEM_BASE",     "CHEM_REACTION",  "undergoes"},
		{"CHEM_ACID",     "CHEM_BASE",      "opposite"},
		{"CHEM_SALT",     "CHEM_ACID",      "product-of"},
		{"CHEM_SALT",     "CHEM_BASE",      "product-of"},
		{"CHEM_PH",       "CHEM_ACID",      "measures"},
		{"CHEM_PH",       "CHEM_BASE",      "measures"},
		{"CHEM_OXIDATION","CHEM_REDUCTION", "opposite"},
		{"CHEM_CATALYST", "CHEM_REACTION",  "speeds-up"},
		{"CHEM_SOLUTION", "CHEM_WATER",     "uses"},
		{"CHEM_CARBON",   "CHEM_ORGANIC",   "basis-of"},
		{"CHEM_POLYMER",  "CHEM_MOLECULE",  "is-a"},
		// Hóa học ↔ Sinh học (cross-domain)
		{"CHEM_CARBON",   "MOL_DNA",        "component-of"},
		{"CHEM_WATER",    "BIO_CELL",       "essential-for"},
		{"CHEM_CATALYST", "MOL_PROTEIN",    "includes"},
		// Địa lý nội bộ
		{"GEO_COUNTRY",   "GEO_CONTINENT",  "part-of"},
		{"GEO_CITY",      "GEO_COUNTRY",    "part-of"},
		{"GEO_RIVER",     "GEO_OCEAN",      "flows-into"},
		{"GEO_CLIMATE",   "GEO_CONTINENT",  "varies-by"},
		// Lịch sử nội bộ
		{"HIST_CIVILIZATION","HIST_EMPIRE", "produces"},
		{"HIST_REVOLUTION",  "HIST_DEMOCRACY","leads-to"},
		{"HIST_WAR",         "HIST_EMPIRE",  "shapes"},
		{"HIST_TRADE",       "HIST_CIVILIZATION","drives"},
		{"HIST_CULTURE",     "HIST_CIVILIZATION","part-of"},
		// Cross-domain
		{"GEO_RIVER",     "BIO_ECOSYSTEM",  "supports"},
		{"GEO_OCEAN",     "PHOTO_OXYGEN",   "contains"},
		{"PHYS_TEMPERATURE","GEO_CLIMATE",  "determines"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚  L%d %-22s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}

	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip edge %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}

	fmt.Printf("\n✚  Thêm: %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n",
		len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]
	return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20]))
	end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
		nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		name := string(raw[i+20+dl:ne2])
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[name]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"member-of":3,"similar":4,"opposite":5,
		"causes":6,"uses":7,"produces":8,"consumes":9,"contains":10,
		"connected-to":11,"develops-into":12,"organized-in":13,"composed-of":14,
		"holds-together":15,"transforms":16,"undergoes":17,"product-of":18,
		"measures":19,"speeds-up":20,"basis-of":21,"includes":22,
		"component-of":23,"essential-for":24,"flows-into":25,"varies-by":26,
		"leads-to":27,"shapes":28,"drives":29,"supports":30,
		"determines":31,"related-to":32,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
