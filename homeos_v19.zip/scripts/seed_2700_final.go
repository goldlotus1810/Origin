//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── VẬT LÝ BỔ SUNG (PHYS5_) ─────────────────────────────
		{"PHYS5_SUPERCONDUCTOR",3,`label=siêu dẫn điện|desc=điện trở bằng 0 dưới nhiệt độ tới hạn MRI tàu đệm từ LK-99 Cooper pairs BCS|vi=siêu dẫn điện,superconductor|en=superconductor|zh=超导体`},
		{"PHYS5_PLASMA",       3, `label=plasma|desc=trạng thái thứ tư của vật chất khí ion hóa Mặt Trời tia sét màn hình plasma tokamak|vi=plasma|en=plasma|zh=等离子体`},
		{"PHYS5_MAGNETISM",    3, `label=từ trường|desc=lực từ nam châm điện từ Maxwell từ thông cảm ứng Lenz motor điện MRI|vi=từ trường,magnetism|en=magnetism|zh=磁场`},

		// ── SINH HỌC BỔ SUNG (BIO4_) ────────────────────────────
		{"BIO4_IMMUNOLOGY",   3, `label=miễn dịch học|desc=hệ miễn dịch tế bào T B kháng thể innate adaptive immunity autoimmune|vi=miễn dịch học,immunology|en=immunology|zh=免疫学`},
		{"BIO4_CANCER",       3, `label=ung thư học|desc=ung thư tế bào phân chia không kiểm soát khối u di căn hóa trị xạ trị immunotherapy|vi=ung thư học,ung thư|en=oncology|zh=肿瘤学`},
		{"BIO4_AGING",        3, `label=lão hóa sinh học|desc=telomere rút ngắn tế bào lão hóa senescence oxidative stress epigenetics tuổi thọ|vi=lão hóa sinh học,aging|en=biological aging|zh=生物衰老`},

		// ── HÓA HỌC MÔI TRƯỜNG (ENVCHEM_) ───────────────────────
		{"ENVCHEM_ACID_RAIN",  3, `label=mưa axit|desc=SO2 NOx phản ứng với nước H2SO4 HNO3 phá hủy hệ sinh thái công trình|vi=mưa axit,acid rain|en=acid rain|zh=酸雨`},
		{"ENVCHEM_MICRO_PLAST",3, `label=vi nhựa|desc=hạt nhựa <5mm biển thực phẩm cơ thể người PET PP PS sức khỏe môi trường|vi=vi nhựa,microplastic|en=microplastic|zh=微塑料`},

		// ── XÃ HỘI HỌC (SOCIOL_) ────────────────────────────────
		{"SOCIOL_GENDER",     3, `label=giới tính và xã hội|desc=gender roles feminism patriarchy LGBTQ+ equality Simone de Beauvoir intersectionality|vi=giới tính và xã hội,gender|en=gender and society|zh=性别与社会`},
		{"SOCIOL_CLASS",      3, `label=giai cấp xã hội|desc=phân tầng xã hội upper middle lower class Marx Weber Bourdieu capital mobility|vi=giai cấp xã hội,social class|en=social class|zh=社会阶级`},
		{"SOCIOL_GLOBALIZE",  3, `label=toàn cầu hóa|desc=hội nhập kinh tế thương mại văn hóa WTO thị trường tự do phụ thuộc lẫn nhau|vi=toàn cầu hóa,globalization|en=globalization|zh=全球化`},

		// ── TRIẾT HỌC KHOA HỌC (PHILSCI_) ───────────────────────
		{"PHILSCI_FALSIFY",   3, `label=lý thuyết bác bỏ|desc=Karl Popper falsifiability khoa học so với giả khoa học kiểm tra được phủ định|vi=lý thuyết bác bỏ,falsifiability|en=falsifiability|zh=可证伪性`},
		{"PHILSCI_PARADIGM",  3, `label=chuyển đổi hệ hình|desc=Thomas Kuhn paradigm shift khoa học bình thường khủng hoảng cách mạng khoa học|vi=chuyển đổi hệ hình,paradigm shift|en=paradigm shift|zh=范式转移`},

		// ── KINH TẾ HỌC HÀNH VI (BEHAV_ECON2_) ──────────────────
		{"BEHAV_ECON2_NUDGE", 3, `label=nudge theory|desc=thiết kế lựa chọn Thaler Sunstein kiến trúc lựa chọn mặc định hành vi tiết kiệm|vi=nudge theory,thuyết khích lệ nhẹ|en=nudge theory|zh=助推理论`},
		{"BEHAV_ECON2_PROSPECT",3,`label=lý thuyết triển vọng|desc=Kahneman Tversky mất mát đau hơn được lợi loss aversion framing reference point|vi=lý thuyết triển vọng,prospect theory|en=prospect theory|zh=前景理论`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	fmt.Printf("\n✚ %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2700 { fmt.Println("🎉 MILESTONE 2700!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
