//go:build ignore
// go run scripts/seed_anat_lit.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── GIẢI PHẪU / Y KHOA ──────────────────────────────────
		{"ANAT_HEART",     3, `label=tim|desc=cơ quan bơm máu của hệ tuần hoàn co bóp nhịp tim 60-100 lần/phút tâm nhĩ tâm thất|vi=tim,heart|en=heart|zh=心脏`},
		{"ANAT_LUNG",      3, `label=phổi|desc=cơ quan hô hấp trao đổi oxy CO2 với máu phế nang phổi trái phổi phải|vi=phổi,lung|en=lung|zh=肺`},
		{"ANAT_BRAIN",     3, `label=não|desc=cơ quan trung tâm thần kinh điều khiển toàn thân tư duy ký ức cảm xúc vỏ não|vi=não,brain|en=brain|zh=大脑`},
		{"ANAT_LIVER",     3, `label=gan|desc=cơ quan lọc độc tố sản xuất mật chuyển hóa glucose dự trữ glycogen xơ gan|vi=gan,liver|en=liver|zh=肝脏`},
		{"ANAT_KIDNEY",    3, `label=thận|desc=cơ quan lọc máu thải chất độc qua nước tiểu duy trì cân bằng điện giải|vi=thận,kidney|en=kidney|zh=肾脏`},
		{"ANAT_IMMUNE",    3, `label=hệ miễn dịch|desc=hệ thống bảo vệ cơ thể khỏi mầm bệnh kháng thể bạch cầu lympho vaccine|vi=hệ miễn dịch,immune system|en=immune system|zh=免疫系统`},
		{"ANAT_BONE",      3, `label=xương|desc=mô cứng tạo khung đỡ cơ thể bảo vệ nội tạng canxi collagen tủy xương tạo máu|vi=xương,bone|en=bone|zh=骨骼`},
		{"ANAT_MUSCLE",    3, `label=cơ|desc=mô co giãn tạo ra chuyển động cơ xương cơ trơn cơ tim protein actin myosin|vi=cơ bắp,cơ,muscle|en=muscle|zh=肌肉`},
		{"ANAT_NERVE",     3, `label=dây thần kinh|desc=cấu trúc truyền tín hiệu điện hóa học giữa não tủy sống và cơ thể neuron synapse|vi=dây thần kinh,nerve|en=nerve,neuron|zh=神经`},
		{"ANAT_BLOOD",     3, `label=máu|desc=chất lỏng lưu thông trong mạch máu hồng cầu bạch cầu tiểu cầu huyết tương nhóm máu|vi=máu,blood|en=blood|zh=血液`},

		// ── VĂN HỌC / NGÔN NGỮ HỌC ─────────────────────────────
		{"LIT_NOVEL",      3, `label=tiểu thuyết|desc=tác phẩm văn xuôi dài hư cấu nhân vật cốt truyện chủ đề Dostoevsky Hemingway|vi=tiểu thuyết,novel|en=novel|zh=小说`},
		{"LIT_POETRY",     3, `label=thơ|desc=hình thức văn học dùng nhịp điệu vần điệu hình ảnh ngôn ngữ cô đọng Shakespeare Tagore Nguyễn Du|vi=thơ,poem,poetry|en=poetry,poem|zh=诗歌`},
		{"LIT_TRANSLATION",3, `label=dịch thuật|desc=chuyển đổi văn bản từ ngôn ngữ này sang ngôn ngữ khác tương đương ngữ nghĩa văn hóa|vi=dịch thuật,translation|en=translation|zh=翻译`},
		{"LIT_GRAMMAR",    3, `label=ngữ pháp|desc=quy tắc cấu trúc ngôn ngữ cú pháp hình thái học từ loại câu Chomsky|vi=ngữ pháp,grammar|en=grammar,syntax|zh=语法`},
		{"LIT_FOLKLORE",   3, `label=văn học dân gian|desc=truyện cổ tích thần thoại ca dao tục ngữ truyền khẩu văn hóa dân gian|vi=văn học dân gian,folklore,truyện cổ tích|en=folklore,folk literature|zh=民间文学`},
		{"LIT_DRAMA",      3, `label=kịch|desc=tác phẩm nghệ thuật biểu diễn đối thoại nhân vật Shakespeare Sophocles sân khấu|vi=kịch,drama,theater|en=drama,theater|zh=戏剧`},
		{"LIT_ESSAY",      3, `label=tản văn|desc=bài viết ngắn phi hư cấu về chủ đề cụ thể phân tích nhận xét Montaigne|vi=tản văn,essay|en=essay|zh=散文`},
		{"LIT_LINGUISTICS",3, `label=ngôn ngữ học|desc=nghiên cứu khoa học ngôn ngữ âm vị học hình thái học cú pháp ngữ nghĩa Saussure|vi=ngôn ngữ học,linguistics|en=linguistics|zh=语言学`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Giải phẫu
		{"ANAT_HEART",     "ANAT_BLOOD",        "pumps"},
		{"ANAT_LUNG",      "ANAT_BLOOD",        "oxygenates"},
		{"ANAT_BRAIN",     "ANAT_NERVE",        "controls-via"},
		{"ANAT_LIVER",     "MED_NUTRITION",     "metabolizes"},
		{"ANAT_IMMUNE",    "MED_VIRUS",         "fights"},
		{"ANAT_IMMUNE",    "PH_ANTIBIOTIC",     "complemented-by"},
		{"ANAT_BONE",      "ANAT_MUSCLE",       "attached-to"},
		{"ANAT_NERVE",     "ANAT_BRAIN",        "connects-to"},
		{"ANAT_BLOOD",     "PH_DIABETES",       "affected-by"},
		{"ANAT_KIDNEY",    "MED_NUTRITION",     "filters"},
		// Văn học
		{"LIT_NOVEL",      "LIT_TRANSLATION",   "requires"},
		{"LIT_POETRY",     "ART_MUSIC",         "inspires"},
		{"LIT_GRAMMAR",    "LIT_LINGUISTICS",   "part-of"},
		{"LIT_FOLKLORE",   "HIST_MYTHOLOGY",    "includes"},
		{"LIT_DRAMA",      "ART_THEATER",       "performed-in"},
		{"LIT_LINGUISTICS","LANG_VIET",         "studies"},
		{"LIT_TRANSLATION","LIT_LINGUISTICS",   "relies-on"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	fmt.Printf("✅ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"pumps":1,"oxygenates":2,"controls-via":3,"metabolizes":4,"fights":5,
		"complemented-by":6,"attached-to":7,"connects-to":8,"affected-by":9,"filters":10,
		"requires":11,"inspires":12,"part-of":13,"includes":14,"performed-in":15,
		"studies":16,"relies-on":17,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
