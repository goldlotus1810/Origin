//go:build ignore
// scripts/seed_cjk.go — seed CJK Basic U+4E00 vào homeos.olang
// Chạy: go run scripts/seed_cjk.go homeos.olang [batch_size] [start_offset]
//
// CJK Unified Ideographs: U+4E00–U+9FFF (20992 chars)
// Mỗi char → L1 node với ISL address + name = CJK_XXXX

package main

import (
	"encoding/binary"
	"crypto/sha256"
	"fmt"
	"os"
	"strconv"
	"unicode"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: go run scripts/seed_cjk.go <file.olang> [batch=200] [start=0]")
		os.Exit(1)
	}
	path := os.Args[1]
	batchSize := 200
	startOffset := 0
	if len(os.Args) >= 3 {
		batchSize, _ = strconv.Atoi(os.Args[2])
	}
	if len(os.Args) >= 4 {
		startOffset, _ = strconv.Atoi(os.Args[3])
	}

	const cjkStart = 0x4E00
	const cjkEnd   = 0x9FFF

	added, skipped, failed := 0, 0, 0
	endOffset := startOffset + batchSize
	if endOffset > (cjkEnd - cjkStart + 1) {
		endOffset = cjkEnd - cjkStart + 1
	}

	for offset := startOffset; offset < endOffset; offset++ {
		cp := rune(cjkStart + offset)
		if !unicode.Is(unicode.Han, cp) {
			skipped++
			continue
		}

		// ISL address: layer=1, group=0x4E (CJK), type by block
		var islAddr [8]byte
		islAddr[0] = 0x01 // layer 1
		islAddr[1] = 0x4E // CJK group
		islAddr[2] = uint8(offset >> 8)
		islAddr[3] = uint8(offset & 0xFF)
		binary.BigEndian.PutUint32(islAddr[4:], uint32(cp))

		// DNA: codepoint + stroke info placeholder
		dna := make([]byte, 8)
		binary.BigEndian.PutUint32(dna[0:4], uint32(cp))
		binary.BigEndian.PutUint32(dna[4:8], uint32(offset))

		// Name: "CJK_4E00" etc
		name := fmt.Sprintf("CJK_%04X", cp)

		if err := appendL1Node(path, islAddr, dna, name, uint32(cp)); err != nil {
			if len(err.Error()) >= 9 && err.Error()[:9] == "duplicate" {
				skipped++
			} else {
				failed++
			}
		} else {
			added++
		}
	}

	fmt.Printf("CJK batch [%d..%d): +%d added  %d skipped  %d failed\n",
		startOffset, endOffset, added, skipped, failed)
	fmt.Printf("  Range: U+%04X – U+%04X\n",
		cjkStart+startOffset, cjkStart+endOffset-1)
}

func appendL1Node(path string, islAddr [8]byte, dna []byte, name string, codepoint uint32) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if len(raw) < 280 || string(raw[:4]) != "OLNG" {
		return fmt.Errorf("bad file")
	}

	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	if len(dna) > 65536 { dna = dna[:65536] }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	// Dup check
	for i := 280; i+20 < edgeStart; {
		if raw[i] == 'N' && raw[i+1] == 'D' {
			if string(raw[i+3:i+11]) == string(islAddr[:]) {
				return fmt.Errorf("duplicate ISL: %s", name)
			}
			dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
			nl := int(raw[i+19])
			if dl < 0 || dl > 65536 || nl > 255 { i++; continue }
			i += 20 + dl + nl
		} else {
			i++
		}
	}

	// Record
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'; rec[1] = 'D'
	rec[2] = 0x01 // layer 1
	copy(rec[3:11], islAddr[:])
	binary.BigEndian.PutUint32(rec[11:], codepoint)
	binary.BigEndian.PutUint32(rec[15:], uint32(len(dna)))
	rec[19] = uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)

	// Layer 1 insert point
	type li struct{ off, sz uint64 }
	layers := [9]li{}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		layers[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].sz  = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}
	var at uint64
	if layers[1].sz > 0 {
		at = layers[1].off + layers[1].sz
	} else {
		at = 280
		if layers[0].sz > 0 { at = layers[0].off + layers[0].sz }
	}

	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:at]...)
	out = append(out, rec...)
	out = append(out, raw[at:]...)

	// Update layer 1
	o1 := 64 + 1*24
	if layers[1].sz == 0 {
		binary.BigEndian.PutUint64(out[o1+4:], at)
	}
	binary.BigEndian.PutUint64(out[o1+12:], layers[1].sz+uint64(len(rec)))
	binary.BigEndian.PutUint32(out[o1+20:], binary.BigEndian.Uint32(out[o1+20:])+1)

	// Shift layers 2–8
	for i := 2; i < 9; i++ {
		o := 64 + i*24
		if layers[i].sz > 0 {
			binary.BigEndian.PutUint64(out[o+4:], binary.BigEndian.Uint64(out[o+4:])+uint64(len(rec)))
		}
	}
	binary.BigEndian.PutUint32(out[9:13], binary.BigEndian.Uint32(out[9:13])+1)

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := path + ".cjk.tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return err }
	return os.Rename(tmp, path)
}
