//go:build ignore
// Fix labels conflict:
//   LANG_WORD "từ" → "từ ngữ" (tránh conflict với "danh từ", "động từ" etc)
//   Thêm POS_NOUN, POS_VERB như L5 nodes (thay vì L0 không được index)
package main
import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)
const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %s: %d bytes, %d nodes, %d edges\n",
		filePath, len(raw), be32(raw[12:16]), be32(raw[16:20]))

	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17

	// ── Sửa DNA của các nodes bị conflict ──────────────────────
	fixes := map[string]string{
		// "từ" (1 rune) → "đơn vị từ" để không match "danh từ/động từ"
		"LANG_WORD": `label=đơn vị từ|desc=đơn vị ngôn ngữ độc lập mang nghĩa gồm một hoặc nhiều hình vị|en=word|vi=đơn vị từ,từ đơn,word|zh=词|fr=mot|de=Wort`,
		// "cụm từ" → "nhóm từ" để tránh conflict với "cụm danh từ/động từ"  
		"LANG_PHRASE": `label=nhóm từ|desc=nhóm từ liên kết không có chủ ngữ và vị ngữ đầy đủ vd the big dog|en=phrase|vi=nhóm từ,ngữ đoạn|zh=短语`,
	}

	// Đồng thời thêm L5 nodes POS_NOUN_L5, POS_VERB_L5 (khác với L0)
	// vì L0 bị skip trong byLabel
	extraNodes := []struct{ name, dna string; layer uint8 }{
		{"GRAM_POS_NOUN", `label=danh từ|desc=từ chỉ người vật địa điểm ý niệm vd dog city love|en=noun|vi=danh từ,noun|zh=名词|fr=nom`, 5},
		{"GRAM_POS_VERB", `label=động từ|desc=từ chỉ hành động trạng thái sự kiện vd run is think|en=verb|vi=động từ,verb|zh=动词|fr=verbe`, 5},
	}

	nFixed := 0
	pos := layerIdxEnd
	for pos < end-25 {
		idx := indexBytes(raw, []byte("ND"), pos)
		if idx < 0 || idx >= end-25 { break }
		layer := raw[idx+2]
		if layer > 7 { pos = idx+1; continue }
		dnaLen := int(be32BE(raw[idx+15:idx+19]))
		nameLen := int(raw[idx+19])
		total := 20 + dnaLen + nameLen
		if dnaLen > 5000 || nameLen > 200 || idx+total > end { pos = idx+1; continue }
		name := string(raw[idx+20+dnaLen : idx+20+dnaLen+nameLen])
		if newDNA, ok := fixes[name]; ok {
			newDNAb := []byte(newDNA)
			oldLabel := extractLabel(string(raw[idx+20:idx+20+dnaLen]))
			// Rebuild record với DNA mới
			newRec := make([]byte, 20+len(newDNAb)+nameLen)
			copy(newRec[:20], raw[idx:idx+20])
			// update dnaLen (big-endian như buildRecord)
			newRec[15] = byte(len(newDNAb) >> 24)
			newRec[16] = byte(len(newDNAb) >> 16)
			newRec[17] = byte(len(newDNAb) >> 8)
			newRec[18] = byte(len(newDNAb))
			copy(newRec[20:], newDNAb)
			copy(newRec[20+len(newDNAb):], raw[idx+20+dnaLen:idx+20+dnaLen+nameLen])
			// Splice
			out := make([]byte, 0, len(raw))
			out = append(out, raw[:idx]...)
			out = append(out, newRec...)
			out = append(out, raw[idx+total:]...)
			raw = out
			end = len(raw) - nedges*17
			fmt.Printf("  ✅ fix %-20s label %q → %q\n", name, oldLabel, extractLabel(newDNA))
			nFixed++
			pos = idx + len(newRec)
			continue
		}
		pos = idx + total
	}

	// ── Thêm extra nodes (nếu chưa tồn tại) ──────────────────
	existNames := readNames(raw)
	nAdded := 0
	for _, nd := range extraNodes {
		if existNames[nd.name] { fmt.Printf("  skip (exist) %s\n", nd.name); continue }
		isl := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, isl, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existNames[nd.name] = true
		nAdded++
		fmt.Printf("  ✚  add L%d %s label=%q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}

	fmt.Printf("\nFixed %d nodes, added %d nodes\n", nFixed, nAdded)

	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, raw, 0644); err != nil { log.Fatal(err) }
	if err := os.Rename(tmp, filePath); err != nil { log.Fatal(err) }
	fmt.Printf("✅ Done: %d bytes, %d nodes\n", len(raw), be32(raw[12:16]))
}

func extractLabel(dna string) string {
	for _, part := range splitPipe(dna) {
		if len(part) > 6 && part[:6] == "label=" {
			return part[6:]
		}
	}
	return ""
}
func splitPipe(s string) []string {
	var out []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '|' { out = append(out, s[start:i]); start = i + 1 }
	}
	out = append(out, s[start:])
	return out
}
func indexBytes(data, sub []byte, from int) int {
	for i := from; i <= len(data)-len(sub); i++ {
		if data[i] == sub[0] {
			match := true
			for j := 1; j < len(sub); j++ {
				if data[i+j] != sub[j] { match = false; break }
			}
			if match { return i }
		}
	}
	return -1
}
func buildRecord(layer uint8, isl [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], isl[:])
	// cp=0 at [11:15], dnaLen BE at [15:19]
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0]=layer; isl[1]=h[0]%200+1; isl[2]=h[1]%200+1; isl[3]=h[2]%200+1
	isl[4]=h[3]; isl[5]=h[4]; isl[6]=h[5]; isl[7]=h[6]
	return isl
}
func insertNode(raw []byte, rec []byte) []byte {
	nedges := int(be32(raw[16:20]))
	nodeEnd := len(raw) - nedges*17
	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:nodeEnd]...)
	out = append(out, rec...)
	out = append(out, raw[nodeEnd:]...)
	n := be32(out[12:16]) + 1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(be32BE(raw[i+15:i+19]))
		nl := int(raw[i+19])
		if dl > 5000 || nl > 200 { i++; continue }
		ns := i+20+dl; ne := ns+nl
		if ne > end { break }
		m[string(raw[ns:ne])] = true
		i = ne
	}
	return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
func be32BE(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
