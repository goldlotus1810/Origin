//go:build ignore

// scripts/seed_language.go
//
// SEED LANGUAGE ONTOLOGY — Tiếng Anh + đa ngôn ngữ
//
// Cấu trúc:
//   L5  LANG_*        — khái niệm ngôn ngữ học trừu tượng (POS, grammar, sentence type...)
//   L3  WORD_*        — từ vựng cụ thể + cảm xúc hành động ngôn ngữ
//   SILK EDGES        — quan hệ ngữ nghĩa giữa các node
//
// Edge types:
//   0x0A  CAUSES    / IS-A / LEADS-TO
//   0x0C  SIMILAR   / RELATED
//   0x0D  OPPOSITE
//   0x08  MEMBER-OF (thuộc nhóm)
//   0x09  PART-OF   (là một phần của)
//
// Chạy: go run scripts/seed_language.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24 // 280

// ═══════════════════════════════════════════════════════════════
// NODE DEFINITIONS
// ═══════════════════════════════════════════════════════════════

type nodeDef struct {
	layer uint8
	name  string
	dna   string // "label=...|desc=...|vi=...|en=...|zh=..."
}

var langNodes = []nodeDef{

	// ══════════════════════════════════════════════════════════
	// L5 — NGÔN NGỮ HỌC (Language Linguistics)
	// Tầng khái niệm trừu tượng, bất biến
	// ══════════════════════════════════════════════════════════

	// ── Tổng thể ──────────────────────────────────────────────
	{5, "LANG_LANGUAGE",
		"label=ngôn ngữ|desc=hệ thống ký hiệu âm thanh chữ viết dùng để giao tiếp tư duy|en=language|vi=ngôn ngữ,tiếng nói|zh=语言|fr=langue|de=Sprache|ja=言語|ko=언어|ar=لغة"},
	{5, "LANG_LINGUISTICS",
		"label=ngôn ngữ học|desc=khoa học nghiên cứu cấu trúc bản chất nguồn gốc và sự tiến hóa của ngôn ngữ|en=linguistics|vi=ngôn ngữ học|zh=语言学"},
	{5, "LANG_COMMUNICATION",
		"label=giao tiếp|desc=quá trình truyền đạt thông tin ý nghĩa giữa người gửi và người nhận|en=communication|vi=giao tiếp,truyền thông|zh=交流"},

	// ── Cấu trúc ngôn ngữ (Structure) ────────────────────────
	{5, "LANG_PHONEME",
		"label=âm vị|desc=đơn vị âm thanh nhỏ nhất phân biệt nghĩa trong ngôn ngữ vd /p/ /b/ /t/|en=phoneme|vi=âm vị,âm tiết tối thiểu|zh=音位|ipa=pʰoʊniːm"},
	{5, "LANG_SYLLABLE",
		"label=âm tiết|desc=đơn vị phát âm gồm nguyên âm kết hợp phụ âm vd 'cat' 1 âm tiết 'table' 2 âm tiết|en=syllable|vi=âm tiết|zh=音节"},
	{5, "LANG_MORPHEME",
		"label=hình vị|desc=đơn vị ngữ pháp nhỏ nhất mang nghĩa vd un- walk -ed = 3 hình vị|en=morpheme|vi=hình vị,đơn vị ngữ nghĩa|zh=词素"},
	{5, "LANG_WORD",
		"label=từ|desc=đơn vị ngôn ngữ độc lập mang nghĩa gồm một hoặc nhiều hình vị|en=word|vi=từ,chữ|zh=词|fr=mot|de=Wort"},
	{5, "LANG_PHRASE",
		"label=cụm từ|desc=nhóm từ liên kết không có chủ ngữ và vị ngữ đầy đủ vd 'the big dog'|en=phrase|vi=cụm từ,ngữ|zh=短语"},
	{5, "LANG_CLAUSE",
		"label=mệnh đề|desc=đơn vị ngữ pháp có chủ ngữ và vị ngữ có thể độc lập hoặc phụ thuộc|en=clause|vi=mệnh đề,câu phụ|zh=从句"},
	{5, "LANG_SENTENCE",
		"label=câu|desc=đơn vị ngôn ngữ hoàn chỉnh có chủ ngữ vị ngữ truyền đạt ý nghĩa trọn vẹn|en=sentence|vi=câu|zh=句子|fr=phrase|de=Satz"},
	{5, "LANG_PARAGRAPH",
		"label=đoạn văn|desc=nhóm câu liên kết chặt chẽ triển khai một ý chính topic sentence|en=paragraph|vi=đoạn văn,đoạn|zh=段落"},
	{5, "LANG_DISCOURSE",
		"label=diễn ngôn|desc=chuỗi ngôn ngữ liên kết thành văn bản hội thoại hoặc bài phát biểu có cấu trúc|en=discourse|vi=diễn ngôn,văn bản|zh=话语"},
	{5, "LANG_TEXT",
		"label=văn bản|desc=đơn vị ngôn ngữ lớn nhất được tổ chức có chủ đề nhất quán|en=text|vi=văn bản,bài viết|zh=文本"},

	// ── Từ loại (Parts of Speech) ─────────────────────────────
	{5, "POS_NOUN",
		"label=danh từ|desc=từ chỉ người vật địa điểm ý niệm vd dog city love|en=noun|vi=danh từ|zh=名词|fr=nom|de=Substantiv|ja=名詞"},
	{5, "POS_VERB",
		"label=động từ|desc=từ chỉ hành động trạng thái sự kiện vd run is think|en=verb|vi=động từ|zh=动词|fr=verbe|de=Verb|ja=動詞"},
	{5, "POS_ADJECTIVE",
		"label=tính từ|desc=từ bổ nghĩa cho danh từ mô tả đặc điểm tính chất vd big red happy|en=adjective|vi=tính từ|zh=形容词|fr=adjectif|de=Adjektiv"},
	{5, "POS_ADVERB",
		"label=trạng từ|desc=từ bổ nghĩa cho động từ tính từ hoặc trạng từ khác vd quickly very|en=adverb|vi=trạng từ|zh=副词|fr=adverbe|de=Adverb"},
	{5, "POS_PRONOUN",
		"label=đại từ|desc=từ thay thế cho danh từ vd I you he she it we they|en=pronoun|vi=đại từ|zh=代词|fr=pronom|de=Pronomen"},
	{5, "POS_PREPOSITION",
		"label=giới từ|desc=từ chỉ quan hệ không gian thời gian giữa các thành phần vd in on at for|en=preposition|vi=giới từ|zh=介词|fr=préposition|de=Präposition"},
	{5, "POS_CONJUNCTION",
		"label=liên từ|desc=từ nối các từ cụm từ mệnh đề vd and but or because although|en=conjunction|vi=liên từ|zh=连词|fr=conjonction|de=Konjunktion"},
	{5, "POS_ARTICLE",
		"label=mạo từ|desc=từ đứng trước danh từ xác định hay không xác định vd a an the|en=article|vi=mạo từ|zh=冠词|fr=article|de=Artikel"},
	{5, "POS_INTERJECTION",
		"label=thán từ|desc=từ biểu hiện cảm xúc tức thời vd oh wow ouch hey|en=interjection|vi=thán từ|zh=感叹词"},
	{5, "POS_DETERMINER",
		"label=hạn định từ|desc=từ xác định phạm vi tham chiếu của danh từ vd this that some every|en=determiner|vi=hạn định từ|zh=限定词"},
	{5, "POS_NUMERAL",
		"label=số từ|desc=từ chỉ số lượng hoặc thứ tự vd one first three hundred|en=numeral|vi=số từ|zh=数词"},

	// ── Ngữ pháp (Grammar) ────────────────────────────────────
	{5, "GRAM_TENSE",
		"label=thì|desc=phạm trù ngữ pháp định vị sự kiện trong thời gian quá khứ hiện tại tương lai|en=tense|vi=thì,thì động từ|zh=时态|fr=temps"},
	{5, "GRAM_TENSE_PAST",
		"label=thì quá khứ|desc=diễn tả hành động xảy ra trước thời điểm nói vd walked sang ate|en=past tense|vi=thì quá khứ|zh=过去时"},
	{5, "GRAM_TENSE_PRESENT",
		"label=thì hiện tại|desc=diễn tả hành động đang xảy ra hoặc sự thật chung vd walk walks|en=present tense|vi=thì hiện tại|zh=现在时"},
	{5, "GRAM_TENSE_FUTURE",
		"label=thì tương lai|desc=diễn tả hành động chưa xảy ra vd will go is going to|en=future tense|vi=thì tương lai|zh=将来时"},
	{5, "GRAM_ASPECT",
		"label=thể|desc=phạm trù ngữ pháp thể hiện cấu trúc bên trong của sự kiện hoàn thành tiếp diễn|en=aspect|vi=thể,khía cạnh|zh=体"},
	{5, "GRAM_ASPECT_SIMPLE",
		"label=thể đơn giản|desc=hành động xảy ra hoặc là sự thật không nhấn mạnh tiến trình vd I eat|en=simple aspect|vi=thể đơn|zh=简单时"},
	{5, "GRAM_ASPECT_CONTINUOUS",
		"label=thể tiếp diễn|desc=hành động đang diễn ra tại thời điểm tham chiếu vd I am eating|en=continuous aspect,progressive|vi=thể tiếp diễn,tiếp diễn|zh=进行时"},
	{5, "GRAM_ASPECT_PERFECT",
		"label=thể hoàn thành|desc=hành động đã hoàn tất có liên quan đến thời điểm tham chiếu vd I have eaten|en=perfect aspect|vi=thể hoàn thành,hoàn thành|zh=完成时"},
	{5, "GRAM_ASPECT_PERFECT_CONT",
		"label=thể hoàn thành tiếp diễn|desc=hành động bắt đầu trước tiếp diễn đến thời điểm tham chiếu vd I have been eating|en=perfect continuous|vi=hoàn thành tiếp diễn|zh=完成进行时"},
	{5, "GRAM_VOICE_ACTIVE",
		"label=thể chủ động|desc=chủ ngữ thực hiện hành động vd The dog bit the man|en=active voice|vi=thể chủ động,câu chủ động|zh=主动态"},
	{5, "GRAM_VOICE_PASSIVE",
		"label=thể bị động|desc=chủ ngữ nhận hành động vd The man was bitten by the dog|en=passive voice|vi=thể bị động,câu bị động|zh=被动态"},
	{5, "GRAM_MOOD_INDICATIVE",
		"label=lối trần thuật|desc=phát biểu sự thật hoặc sự kiện thực tế vd She works here|en=indicative mood|vi=lối trần thuật|zh=陈述语气"},
	{5, "GRAM_MOOD_SUBJUNCTIVE",
		"label=lối cầu khẩn|desc=diễn tả giả định ước muốn đề nghị vd I suggest that he be careful|en=subjunctive mood|vi=lối cầu khẩn|zh=虚拟语气"},
	{5, "GRAM_MOOD_IMPERATIVE",
		"label=lối mệnh lệnh|desc=mệnh lệnh yêu cầu hoặc đề nghị vd Come here! Please sit down|en=imperative mood|vi=lối mệnh lệnh,câu mệnh lệnh|zh=祈使语气"},
	{5, "GRAM_AGREEMENT",
		"label=sự hòa hợp|desc=hình thức ngữ pháp phải tương ứng nhau vd she runs họ phải hòa hợp|en=agreement,concord|vi=sự hòa hợp|zh=一致"},
	{5, "GRAM_CASE",
		"label=cách|desc=biến hóa hình thái của danh từ đại từ theo chức năng cú pháp vd he him his|en=grammatical case|vi=cách,biến cách|zh=格"},
	{5, "GRAM_NUMBER",
		"label=số|desc=phân biệt số ít và số nhiều vd cat-cats child-children|en=grammatical number|vi=số,số ít số nhiều|zh=数"},
	{5, "GRAM_GENDER",
		"label=giống|desc=phân loại danh từ theo giống đực cái trung tính|en=grammatical gender|vi=giống|zh=性"},
	{5, "GRAM_PERSON",
		"label=ngôi|desc=phân biệt người nói I người nghe you người được nói đến he she|en=grammatical person|vi=ngôi|zh=人称"},
	{5, "GRAM_MODALITY",
		"label=tình thái|desc=thể hiện thái độ của người nói với mệnh đề khả năng nghĩa vụ tất yếu|en=modality|vi=tình thái|zh=情态"},
	{5, "GRAM_MODAL_VERB",
		"label=động từ khuyết thiếu|desc=can could will would shall should may might must ought to|en=modal verb|vi=động từ khuyết thiếu,trợ động từ tình thái|zh=情态动词"},

	// ── Loại câu (Sentence Types) ─────────────────────────────
	{5, "SENT_DECLARATIVE",
		"label=câu trần thuật|desc=câu phát biểu sự thật thông tin vd The sun rises in the east|en=declarative sentence|vi=câu trần thuật,câu khẳng định|zh=陈述句"},
	{5, "SENT_INTERROGATIVE",
		"label=câu hỏi|desc=câu đặt câu hỏi yêu cầu thông tin hoặc xác nhận vd Where are you going?|en=interrogative sentence|vi=câu hỏi,câu nghi vấn|zh=疑问句"},
	{5, "SENT_IMPERATIVE",
		"label=câu mệnh lệnh|desc=câu yêu cầu mệnh lệnh đề nghị chủ ngữ thường ẩn vd Close the door|en=imperative sentence|vi=câu mệnh lệnh,câu cầu khiến|zh=祈使句"},
	{5, "SENT_EXCLAMATORY",
		"label=câu cảm thán|desc=câu biểu đạt cảm xúc mạnh ngạc nhiên vui mừng bực bội vd What a beautiful day!|en=exclamatory sentence|vi=câu cảm thán|zh=感叹句"},
	{5, "SENT_SIMPLE",
		"label=câu đơn|desc=câu có một mệnh đề độc lập một chủ ngữ một vị ngữ vd Dogs bark|en=simple sentence|vi=câu đơn|zh=简单句"},
	{5, "SENT_COMPOUND",
		"label=câu ghép|desc=hai mệnh đề độc lập nối bằng liên từ vd I ran but she walked|en=compound sentence|vi=câu ghép|zh=并列句"},
	{5, "SENT_COMPLEX",
		"label=câu phức|desc=một mệnh đề độc lập và một mệnh đề phụ thuộc vd When it rains I stay home|en=complex sentence|vi=câu phức|zh=复合句"},
	{5, "SENT_COMPOUND_COMPLEX",
		"label=câu ghép phức|desc=kết hợp câu ghép và câu phức nhiều mệnh đề độc lập và phụ|en=compound-complex sentence|vi=câu ghép phức|zh=并列复合句"},
	{5, "SENT_CONDITIONAL",
		"label=câu điều kiện|desc=câu If...then diễn tả điều kiện và kết quả vd If I study I will pass|en=conditional sentence|vi=câu điều kiện,câu giả định|zh=条件句"},
	{5, "SENT_RELATIVE",
		"label=câu quan hệ|desc=mệnh đề sửa đổi danh từ dùng who which that vd The man who called|en=relative clause|vi=câu quan hệ,mệnh đề quan hệ|zh=关系从句"},
	{5, "SENT_INDIRECT_SPEECH",
		"label=câu gián tiếp|desc=thuật lại lời nói của người khác không dùng dấu ngoặc kép|en=indirect speech,reported speech|vi=câu gián tiếp,lời gián tiếp|zh=间接引语"},
	{5, "SENT_DIRECT_SPEECH",
		"label=câu trực tiếp|desc=trích dẫn chính xác lời nói dùng dấu ngoặc kép vd He said 'I am tired'|en=direct speech|vi=câu trực tiếp,lời trực tiếp|zh=直接引语"},

	// ── Cú pháp (Syntax) ─────────────────────────────────────
	{5, "SYN_SUBJECT",
		"label=chủ ngữ|desc=thành phần câu chỉ người vật thực hiện hoặc liên quan đến hành động|en=subject|vi=chủ ngữ|zh=主语|fr=sujet|de=Subjekt"},
	{5, "SYN_PREDICATE",
		"label=vị ngữ|desc=thành phần câu nói về chủ ngữ gồm động từ và bổ sung|en=predicate|vi=vị ngữ|zh=谓语|fr=prédicat|de=Prädikat"},
	{5, "SYN_OBJECT_DIRECT",
		"label=tân ngữ trực tiếp|desc=người vật nhận trực tiếp hành động của động từ vd I see the cat|en=direct object|vi=tân ngữ trực tiếp,bổ ngữ trực tiếp|zh=直接宾语"},
	{5, "SYN_OBJECT_INDIRECT",
		"label=tân ngữ gián tiếp|desc=người vật nhận gián tiếp lợi ích của hành động vd I gave her a book|en=indirect object|vi=tân ngữ gián tiếp|zh=间接宾语"},
	{5, "SYN_COMPLEMENT",
		"label=bổ ngữ|desc=thành phần hoàn chỉnh nghĩa cho chủ ngữ hoặc tân ngữ vd She is happy|en=complement|vi=bổ ngữ|zh=补语"},
	{5, "SYN_MODIFIER",
		"label=định ngữ|desc=từ cụm từ bổ nghĩa cho thành phần khác tính từ trạng từ|en=modifier|vi=định ngữ,từ bổ nghĩa|zh=修饰语"},
	{5, "SYN_APPOSITIVE",
		"label=đồng vị ngữ|desc=danh từ cụm từ đứng cạnh giải thích cho danh từ đứng trước|en=appositive|vi=đồng vị ngữ|zh=同位语"},
	{5, "SYN_PHRASE_NOUN",
		"label=cụm danh từ|desc=nhóm từ với danh từ làm trung tâm vd the big red apple|en=noun phrase|vi=cụm danh từ|zh=名词短语"},
	{5, "SYN_PHRASE_VERB",
		"label=cụm động từ|desc=nhóm từ với động từ làm trung tâm gồm trợ động từ vd has been running|en=verb phrase|vi=cụm động từ|zh=动词短语"},
	{5, "SYN_PHRASE_ADJ",
		"label=cụm tính từ|desc=nhóm từ với tính từ làm trung tâm vd very happy about it|en=adjective phrase|vi=cụm tính từ|zh=形容词短语"},
	{5, "SYN_PHRASE_PREP",
		"label=cụm giới từ|desc=giới từ + tân ngữ chức năng tính từ hoặc trạng từ vd in the morning|en=prepositional phrase|vi=cụm giới từ|zh=介词短语"},

	// ── Ngữ nghĩa (Semantics) ─────────────────────────────────
	{5, "SEM_MEANING",
		"label=nghĩa|desc=nội dung thông tin mà ngôn ngữ biểu đạt quan hệ ký hiệu với thực tế|en=meaning,semantics|vi=nghĩa,ý nghĩa|zh=意义"},
	{5, "SEM_DENOTATION",
		"label=nghĩa biểu vật|desc=nghĩa đen ý nghĩa từ điển chính thức của từ|en=denotation|vi=nghĩa biểu vật,nghĩa đen|zh=字面意义"},
	{5, "SEM_CONNOTATION",
		"label=nghĩa hàm ý|desc=nghĩa bóng liên tưởng cảm xúc văn hóa gắn với từ ngoài nghĩa đen|en=connotation|vi=nghĩa hàm ý,nghĩa bóng|zh=内涵意义"},
	{5, "SEM_SYNONYM",
		"label=từ đồng nghĩa|desc=từ có nghĩa giống hoặc gần giống nhau vd happy=joyful big=large|en=synonym|vi=từ đồng nghĩa|zh=同义词|fr=synonyme"},
	{5, "SEM_ANTONYM",
		"label=từ trái nghĩa|desc=từ có nghĩa đối lập nhau vd hot/cold good/bad fast/slow|en=antonym|vi=từ trái nghĩa|zh=反义词|fr=antonyme"},
	{5, "SEM_HOMONYM",
		"label=từ đồng âm|desc=từ cùng âm thanh khác nghĩa vd bank bờ ngân hàng bat con dơi gậy|en=homonym|vi=từ đồng âm|zh=同音词"},
	{5, "SEM_POLYSEMY",
		"label=đa nghĩa|desc=một từ mang nhiều nghĩa liên quan vd run chạy điều hành ứng cử|en=polysemy|vi=đa nghĩa|zh=一词多义"},
	{5, "SEM_METAPHOR",
		"label=ẩn dụ|desc=so sánh ngầm áp dụng đặc điểm của vật này vào vật khác vd time is money|en=metaphor|vi=ẩn dụ|zh=隐喻|fr=métaphore"},
	{5, "SEM_METONYMY",
		"label=hoán dụ|desc=thay thế từ bằng từ liên quan vd crown cho royalty the press cho journalists|en=metonymy|vi=hoán dụ|zh=转喻"},
	{5, "SEM_IDIOM",
		"label=thành ngữ|desc=cụm từ cố định có nghĩa khác nghĩa đen của từng từ vd kick the bucket|en=idiom|vi=thành ngữ,quán ngữ|zh=惯用语"},
	{5, "SEM_COLLOCATION",
		"label=kết hợp từ|desc=các từ thường xuất hiện cạnh nhau vd make a mistake strong coffee|en=collocation|vi=kết hợp từ|zh=搭配"},
	{5, "SEM_FIELD",
		"label=trường nghĩa|desc=nhóm từ liên quan theo chủ đề vd furniture: table chair bed sofa|en=semantic field,lexical field|vi=trường nghĩa|zh=语义场"},
	{5, "SEM_PROTOTYPE",
		"label=nguyên mẫu|desc=thành viên điển hình nhất của một phạm trù vd robin là nguyên mẫu của bird|en=prototype|vi=nguyên mẫu|zh=原型"},
	{5, "SEM_PRESUPPOSITION",
		"label=tiền giả định|desc=thông tin được giả định đúng không cần nói rõ vd The king of France is bald|en=presupposition|vi=tiền giả định|zh=预设"},
	{5, "SEM_IMPLICATURE",
		"label=hàm ngôn|desc=nghĩa được suy ra từ ngữ cảnh không được nói trực tiếp Grice|en=implicature|vi=hàm ngôn|zh=含义"},
	{5, "SEM_AMBIGUITY",
		"label=mơ hồ|desc=từ hoặc câu có nhiều cách hiểu vd I saw the man with the telescope|en=ambiguity|vi=mơ hồ,đa nghĩa|zh=歧义"},

	// ── Ngữ dụng / Hoàn cảnh (Pragmatics / Context) ──────────
	{5, "PRAG_CONTEXT",
		"label=ngữ cảnh|desc=hoàn cảnh tình huống nơi chốn thời gian người tham gia ảnh hưởng đến nghĩa|en=context|vi=ngữ cảnh,hoàn cảnh|zh=语境"},
	{5, "PRAG_SPEECH_ACT",
		"label=hành động lời nói|desc=Austin Searle: ngôn ngữ không chỉ mô tả mà còn thực hiện hành động|en=speech act|vi=hành động lời nói|zh=言语行为"},
	{5, "PRAG_ILLOCUTION",
		"label=lực ngôn trung|desc=mục đích thực sự của phát ngôn hứa hẹn cảnh báo yêu cầu|en=illocutionary force|vi=lực ngôn trung|zh=言外行为"},
	{5, "PRAG_REGISTER",
		"label=phong cách ngôn ngữ|desc=biến thể ngôn ngữ theo tình huống xã hội formal informal technical|en=register|vi=phong cách ngôn ngữ,ngôn phong|zh=语体"},
	{5, "PRAG_REGISTER_FORMAL",
		"label=ngôn ngữ trang trọng|desc=văn phong lịch sự trang trọng dùng trong văn bản học thuật công vụ|en=formal register|vi=ngôn ngữ trang trọng|zh=正式语体"},
	{5, "PRAG_REGISTER_INFORMAL",
		"label=ngôn ngữ thân mật|desc=văn phong thường ngày thoải mái dùng với bạn bè gia đình|en=informal register,colloquial|vi=ngôn ngữ thân mật,khẩu ngữ|zh=非正式语体"},
	{5, "PRAG_REGISTER_SLANG",
		"label=tiếng lóng|desc=ngôn ngữ không chính thức đặc thù nhóm xã hội vd cool lit gonna|en=slang|vi=tiếng lóng|zh=俚语"},
	{5, "PRAG_POLITENESS",
		"label=lịch sự|desc=chiến lược ngôn ngữ giảm thiểu xung đột duy trì thể diện Brown Levinson|en=politeness|vi=lịch sự,phép lịch sự|zh=礼貌"},
	{5, "PRAG_DEIXIS",
		"label=chỉ xuất|desc=từ chỉ nghĩa phụ thuộc ngữ cảnh vd here now this I yesterday|en=deixis|vi=chỉ xuất,từ chỉ xuất|zh=指示语"},
	{5, "PRAG_COHERENCE",
		"label=mạch lạc|desc=liên kết nghĩa logic giữa các câu văn bản|en=coherence|vi=mạch lạc|zh=语篇连贯"},
	{5, "PRAG_COHESION",
		"label=liên kết|desc=liên kết hình thức giữa các câu qua đại từ liên từ từ thay thế|en=cohesion|vi=liên kết ngôn bản|zh=衔接"},
	{5, "PRAG_TOPIC",
		"label=chủ đề|desc=thông tin cũ đã biết người nghe trong câu phát ngôn|en=topic|vi=chủ đề,đề|zh=主题"},
	{5, "PRAG_FOCUS",
		"label=tiêu điểm|desc=thông tin mới quan trọng nhất trong phát ngôn|en=focus|vi=tiêu điểm,tiêu điểm thông báo|zh=焦点"},
	{5, "PRAG_INTONATION",
		"label=ngữ điệu|desc=thay đổi cao độ trong chuỗi lời nói mang nghĩa ngữ dụng|en=intonation|vi=ngữ điệu,ngữ điệu câu|zh=语调"},

	// ── Không gian ngôn ngữ (Spatial / Conceptual Space) ─────
	{5, "SPACE_CONCEPTUAL",
		"label=không gian ý niệm|desc=Fauconnier: vùng tư duy được xây dựng trong quá trình hiểu và diễn giải|en=conceptual space|vi=không gian ý niệm|zh=概念空间"},
	{5, "SPACE_BLENDING",
		"label=pha trộn ý niệm|desc=tích hợp hai không gian đầu vào tạo không gian pha trộn mới|en=conceptual blending|vi=pha trộn ý niệm|zh=概念整合"},
	{5, "SPACE_FRAME",
		"label=khung ý niệm|desc=Fillmore: cấu trúc tri thức nền tảng hiểu nghĩa từ vd commercial transaction|en=frame,conceptual frame|vi=khung ý niệm|zh=框架"},
	{5, "SPACE_SCHEMA",
		"label=giản đồ hình ảnh|desc=cấu trúc tư duy trừu tượng từ kinh nghiệm thể xác container path force|en=image schema|vi=giản đồ hình ảnh|zh=意象图式"},
	{5, "SPACE_FORCE_DYNAMICS",
		"label=lực động|desc=Talmy: quan hệ lực tác nhân nguyên nhân kháng cự trong ngôn ngữ và tư duy|en=force dynamics|vi=lực động|zh=力动态"},

	// ── Âm vị học & Âm học (Phonology & Phonetics) ───────────
	{5, "PHON_STRESS",
		"label=trọng âm|desc=âm tiết được phát âm mạnh hơn trong từ vd PHOtograph phoTOgraphy|en=stress,word stress|vi=trọng âm|zh=重音"},
	{5, "PHON_INTONATION",
		"label=thanh điệu câu|desc=mô hình cao độ trên toàn câu mang nghĩa nghi vấn trần thuật|en=sentence intonation|vi=thanh điệu câu|zh=句调"},
	{5, "PHON_VOWEL",
		"label=nguyên âm|desc=âm thanh tạo ra khi luồng khí không bị cản vd a e i o u|en=vowel|vi=nguyên âm|zh=元音|fr=voyelle"},
	{5, "PHON_CONSONANT",
		"label=phụ âm|desc=âm thanh tạo ra khi luồng khí bị cản một phần hoặc hoàn toàn|en=consonant|vi=phụ âm|zh=辅音|fr=consonne"},
	{5, "PHON_IPA",
		"label=IPA|desc=International Phonetic Alphabet bảng ký hiệu phiên âm quốc tế|en=IPA,International Phonetic Alphabet|vi=IPA,phiên âm quốc tế|zh=国际音标"},

	// ── Từ vựng học (Lexicology) ──────────────────────────────
	{5, "LEX_ROOT",
		"label=từ gốc|desc=hình thức cơ sở của từ chưa có tiền tố hay hậu tố vd walk run|en=root word|vi=từ gốc|zh=词根"},
	{5, "LEX_PREFIX",
		"label=tiền tố|desc=hình vị thêm vào trước từ gốc thay đổi nghĩa vd un- re- pre- dis-|en=prefix|vi=tiền tố|zh=前缀"},
	{5, "LEX_SUFFIX",
		"label=hậu tố|desc=hình vị thêm vào sau từ gốc thay đổi nghĩa hoặc từ loại vd -tion -ly -er|en=suffix|vi=hậu tố|zh=后缀"},
	{5, "LEX_COMPOUND",
		"label=từ ghép|desc=từ tạo thành từ hai từ trở lên vd blackbird notebook toothpaste|en=compound word|vi=từ ghép|zh=复合词"},
	{5, "LEX_DERIVATION",
		"label=phái sinh|desc=tạo từ mới bằng cách thêm tiền tố hậu tố vd happy unhappy happiness|en=derivation|vi=phái sinh,cấu tạo từ|zh=派生"},
	{5, "LEX_INFLECTION",
		"label=biến hình|desc=thay đổi hình thức từ để biểu đạt thì số ngôi vd walk walks walked|en=inflection|vi=biến hình|zh=屈折变化"},
	{5, "LEX_LOANWORD",
		"label=từ vay mượn|desc=từ lấy từ ngôn ngữ khác vd café ballet kindergarten sushi|en=loanword,borrowing|vi=từ vay mượn,từ ngoại lai|zh=借词"},
	{5, "LEX_NEOLOGISM",
		"label=từ mới|desc=từ hoặc nghĩa mới vừa xuất hiện trong ngôn ngữ vd selfie podcast googling|en=neologism|vi=từ mới,tân ngữ|zh=新词"},
	{5, "LEX_ARCHAISM",
		"label=từ cổ|desc=từ không còn dùng phổ biến trong tiếng Anh hiện đại vd thou dost forsooth|en=archaism|vi=từ cổ,từ lỗi thời|zh=古语词"},
	{5, "LEX_EUPHEMISM",
		"label=uyển ngữ|desc=từ nhẹ hơn thay cho từ thô tục hoặc khó chịu vd passed away cho died|en=euphemism|vi=uyển ngữ,từ né tránh|zh=委婉语"},

	// ── Thể loại văn bản (Text Types / Genres) ───────────────
	{5, "GENRE_NARRATIVE",
		"label=văn tường thuật|desc=kể chuyện sự kiện theo trình tự thời gian nhân vật cốt truyện|en=narrative text|vi=văn tường thuật,văn kể chuyện|zh=叙事文"},
	{5, "GENRE_DESCRIPTIVE",
		"label=văn miêu tả|desc=mô tả chi tiết đặc điểm của người vật nơi chốn|en=descriptive text|vi=văn miêu tả|zh=描述文"},
	{5, "GENRE_EXPOSITORY",
		"label=văn thuyết minh|desc=giải thích thông tin sự kiện một cách khách quan trung lập|en=expository text|vi=văn thuyết minh,văn giải thích|zh=说明文"},
	{5, "GENRE_ARGUMENTATIVE",
		"label=văn nghị luận|desc=đưa ra lập luận bằng chứng để thuyết phục quan điểm|en=argumentative text|vi=văn nghị luận,văn lập luận|zh=议论文"},
	{5, "GENRE_PROCEDURAL",
		"label=văn hướng dẫn|desc=chỉ dẫn từng bước thực hiện công việc recipe instructions|en=procedural text|vi=văn hướng dẫn|zh=程序文"},

	// ── Các ngôn ngữ lớn (Major Languages — L5) ──────────────
	{5, "LANG_ENGLISH",
		"label=tiếng Anh|desc=ngôn ngữ Germanic Tây được nói nhiều nhất thế giới 1.5 tỷ người nói|en=English|vi=tiếng Anh|zh=英语|fr=anglais|de=Englisch|ja=英語|ko=영어"},
	{5, "LANG_VIETNAMESE",
		"label=tiếng Việt|desc=ngôn ngữ Austroasiatic ngôn ngữ chính thức Việt Nam 90 triệu người nói|en=Vietnamese|vi=tiếng Việt|zh=越南语"},
	{5, "LANG_CHINESE",
		"label=tiếng Trung|desc=ngôn ngữ Sino-Tibetan nhiều người nói nhất thế giới Mandarin Cantonese|en=Chinese,Mandarin|vi=tiếng Trung,tiếng Hoa|zh=中文,普通话"},
	{5, "LANG_FRENCH",
		"label=tiếng Pháp|desc=ngôn ngữ Romance từ Latin 300 triệu người nói ngôn ngữ ngoại giao|en=French|vi=tiếng Pháp|zh=法语|fr=français"},
	{5, "LANG_SPANISH",
		"label=tiếng Tây Ban Nha|desc=ngôn ngữ Romance 500 triệu người nói ngôn ngữ chính thức 20 quốc gia|en=Spanish|vi=tiếng Tây Ban Nha|zh=西班牙语"},
	{5, "LANG_JAPANESE",
		"label=tiếng Nhật|desc=ngôn ngữ Japonic hiragana katakana kanji 3 hệ thống chữ viết|en=Japanese|vi=tiếng Nhật|zh=日语|ja=日本語"},
	{5, "LANG_KOREAN",
		"label=tiếng Hàn|desc=ngôn ngữ biệt lập sử dụng bảng chữ Hangul được King Sejong sáng tạo|en=Korean|vi=tiếng Hàn|zh=韩语|ko=한국어"},
	{5, "LANG_ARABIC",
		"label=tiếng Ả Rập|desc=ngôn ngữ Semitic đọc từ phải sang trái ngôn ngữ linh thiêng Hồi giáo|en=Arabic|vi=tiếng Ả Rập|zh=阿拉伯语|ar=العربية"},
	{5, "LANG_GERMAN",
		"label=tiếng Đức|desc=ngôn ngữ Germanic Tây ngôn ngữ mẹ đẻ nhiều người nhất EU|en=German|vi=tiếng Đức|zh=德语|de=Deutsch"},
	{5, "LANG_RUSSIAN",
		"label=tiếng Nga|desc=ngôn ngữ Slav dùng bảng chữ Cyrillic ngôn ngữ chính thức LHQ|en=Russian|vi=tiếng Nga|zh=俄语"},
	{5, "LANG_HINDI",
		"label=tiếng Hindi|desc=ngôn ngữ Indo-Aryan dùng chữ Devanagari ngôn ngữ chính thức Ấn Độ|en=Hindi|vi=tiếng Hindi|zh=印地语"},
	{5, "LANG_PORTUGUESE",
		"label=tiếng Bồ Đào Nha|desc=ngôn ngữ Romance Brazil Bồ Đào Nha Angola 250 triệu người|en=Portuguese|vi=tiếng Bồ Đào Nha|zh=葡萄牙语"},

	// ══════════════════════════════════════════════════════════
	// L3 — TỪ VỰNG HÀNH ĐỘNG NGÔN NGỮ (Language Acts)
	// Các động từ ngôn ngữ cụ thể, hành động giao tiếp
	// ══════════════════════════════════════════════════════════

	{3, "WORD_SAY",
		"label=nói|desc=phát ra lời nói ngôn ngữ để truyền đạt thông tin|en=say,speak,tell|vi=nói,phát biểu|zh=说"},
	{3, "WORD_WRITE",
		"label=viết|desc=tạo ra văn bản bằng chữ viết ký hiệu|en=write|vi=viết,ghi|zh=写"},
	{3, "WORD_READ",
		"label=đọc|desc=giải mã và hiểu văn bản chữ viết|en=read|vi=đọc|zh=读"},
	{3, "WORD_LISTEN",
		"label=nghe|desc=tiếp nhận và xử lý âm thanh ngôn ngữ|en=listen,hear|vi=nghe,lắng nghe|zh=听"},
	{3, "WORD_TRANSLATE",
		"label=dịch|desc=chuyển đổi ý nghĩa từ ngôn ngữ này sang ngôn ngữ khác|en=translate|vi=dịch,phiên dịch|zh=翻译"},
	{3, "WORD_INTERPRET",
		"label=thông dịch|desc=dịch trực tiếp lời nói theo thời gian thực|en=interpret|vi=thông dịch|zh=口译"},
	{3, "WORD_DEFINE",
		"label=định nghĩa|desc=giải thích nghĩa của từ hoặc khái niệm|en=define|vi=định nghĩa|zh=定义"},
	{3, "WORD_ARGUE",
		"label=tranh luận|desc=đưa ra lý lẽ ủng hộ hoặc phản đối quan điểm|en=argue,debate|vi=tranh luận,lập luận|zh=争论"},
	{3, "WORD_PERSUADE",
		"label=thuyết phục|desc=dùng ngôn ngữ thay đổi suy nghĩ hoặc hành động của người khác|en=persuade|vi=thuyết phục|zh=说服"},
	{3, "WORD_PROMISE",
		"label=hứa|desc=cam kết sẽ thực hiện hành động trong tương lai speech act|en=promise|vi=hứa,cam kết|zh=承诺"},
	{3, "WORD_WARN",
		"label=cảnh báo|desc=thông báo nguy hiểm hoặc hậu quả tiêu cực|en=warn|vi=cảnh báo,cảnh cáo|zh=警告"},
	{3, "WORD_APOLOGIZE",
		"label=xin lỗi|desc=thừa nhận lỗi lầm và bày tỏ hối hận|en=apologize|vi=xin lỗi,tạ lỗi|zh=道歉"},
	{3, "WORD_GREET",
		"label=chào hỏi|desc=mở đầu giao tiếp bằng cử chỉ hoặc lời nói thân thiện|en=greet|vi=chào,chào hỏi|zh=问候"},
	{3, "WORD_THANK",
		"label=cảm ơn|desc=bày tỏ lòng biết ơn với người khác|en=thank|vi=cảm ơn|zh=感谢"},
	{3, "WORD_REQUEST",
		"label=yêu cầu|desc=hỏi xin điều gì một cách lịch sự|en=request|vi=yêu cầu,nhờ|zh=请求"},
	{3, "WORD_ORDER",
		"label=ra lệnh|desc=mệnh lệnh đòi hỏi tuân theo có thẩm quyền|en=order,command|vi=ra lệnh,ra lệnh|zh=命令"},

	// ── Phân tích ngôn ngữ (Analysis words) ──────────────────
	{3, "WORD_ANALYZE",
		"label=phân tích|desc=chia nhỏ để hiểu cấu trúc thành phần và quan hệ|en=analyze|vi=phân tích|zh=分析"},
	{3, "WORD_SUMMARIZE",
		"label=tóm tắt|desc=rút gọn nội dung giữ ý chính|en=summarize|vi=tóm tắt|zh=总结"},
	{3, "WORD_PARAPHRASE",
		"label=diễn đạt lại|desc=diễn tả cùng ý nghĩa bằng cách khác bằng lời khác|en=paraphrase|vi=diễn đạt lại,nói lại|zh=改述"},
	{3, "WORD_COMPARE",
		"label=so sánh|desc=xác định điểm giống và khác nhau giữa hai sự vật|en=compare|vi=so sánh|zh=比较"},
	{3, "WORD_CONTRAST",
		"label=đối chiếu|desc=nhấn mạnh điểm khác nhau giữa hai sự vật|en=contrast|vi=đối chiếu|zh=对比"},
}

// ═══════════════════════════════════════════════════════════════
// EDGE DEFINITIONS
// ═══════════════════════════════════════════════════════════════

type edgeDef struct {
	from, to string
	typ      uint8
}

// Edge types
const (
	edgeISA      = 0x0A // is-a / leads-to / causes
	edgeSIMILAR  = 0x0C // similar / related
	edgeOPPOSITE = 0x0D // opposite
	edgeMEMBER   = 0x08 // member-of (thuộc nhóm)
	edgePART     = 0x09 // part-of (là phần của)
)

var langEdges = []edgeDef{
	// ── Structure hierarchy ────────────────────────────────────
	// phoneme < syllable < morpheme < word < phrase < clause < sentence < paragraph < discourse
	{"LANG_PHONEME",   "LANG_SYLLABLE",   edgePART},
	{"LANG_SYLLABLE",  "LANG_MORPHEME",   edgePART},
	{"LANG_MORPHEME",  "LANG_WORD",       edgePART},
	{"LANG_WORD",      "LANG_PHRASE",     edgePART},
	{"LANG_PHRASE",    "LANG_CLAUSE",     edgePART},
	{"LANG_CLAUSE",    "LANG_SENTENCE",   edgePART},
	{"LANG_SENTENCE",  "LANG_PARAGRAPH",  edgePART},
	{"LANG_PARAGRAPH", "LANG_DISCOURSE",  edgePART},
	{"LANG_DISCOURSE", "LANG_TEXT",       edgeSIMILAR},

	// ── POS → LANG_WORD (member-of) ───────────────────────────
	{"POS_NOUN",         "LANG_WORD", edgeMEMBER},
	{"POS_VERB",         "LANG_WORD", edgeMEMBER},
	{"POS_ADJECTIVE",    "LANG_WORD", edgeMEMBER},
	{"POS_ADVERB",       "LANG_WORD", edgeMEMBER},
	{"POS_PRONOUN",      "LANG_WORD", edgeMEMBER},
	{"POS_PREPOSITION",  "LANG_WORD", edgeMEMBER},
	{"POS_CONJUNCTION",  "LANG_WORD", edgeMEMBER},
	{"POS_ARTICLE",      "LANG_WORD", edgeMEMBER},
	{"POS_INTERJECTION", "LANG_WORD", edgeMEMBER},
	{"POS_DETERMINER",   "LANG_WORD", edgeMEMBER},
	{"POS_NUMERAL",      "LANG_WORD", edgeMEMBER},

	// ── POS opposites ─────────────────────────────────────────
	{"POS_NOUN",      "POS_VERB",      edgeOPPOSITE},
	{"POS_ADJECTIVE", "POS_ADVERB",    edgeOPPOSITE},
	{"POS_ADJECTIVE", "LANG_WORD",     edgeMEMBER},

	// ── Tense → Aspect ────────────────────────────────────────
	{"GRAM_TENSE",          "GRAM_ASPECT",              edgeSIMILAR},
	{"GRAM_TENSE_PAST",     "GRAM_TENSE",               edgeMEMBER},
	{"GRAM_TENSE_PRESENT",  "GRAM_TENSE",               edgeMEMBER},
	{"GRAM_TENSE_FUTURE",   "GRAM_TENSE",               edgeMEMBER},
	{"GRAM_ASPECT_SIMPLE",  "GRAM_ASPECT",              edgeMEMBER},
	{"GRAM_ASPECT_CONTINUOUS","GRAM_ASPECT",            edgeMEMBER},
	{"GRAM_ASPECT_PERFECT", "GRAM_ASPECT",              edgeMEMBER},
	{"GRAM_ASPECT_PERFECT_CONT","GRAM_ASPECT",          edgeMEMBER},
	{"GRAM_TENSE_PAST",     "GRAM_TENSE_PRESENT",       edgeOPPOSITE},
	{"GRAM_TENSE_PRESENT",  "GRAM_TENSE_FUTURE",        edgeISA},
	{"GRAM_VOICE_ACTIVE",   "GRAM_VOICE_PASSIVE",       edgeOPPOSITE},
	{"GRAM_MODAL_VERB",     "POS_VERB",                 edgeMEMBER},
	{"GRAM_MODALITY",       "GRAM_MODAL_VERB",          edgeISA},

	// ── Sentence types → LANG_SENTENCE ────────────────────────
	{"SENT_DECLARATIVE",     "LANG_SENTENCE", edgeMEMBER},
	{"SENT_INTERROGATIVE",   "LANG_SENTENCE", edgeMEMBER},
	{"SENT_IMPERATIVE",      "LANG_SENTENCE", edgeMEMBER},
	{"SENT_EXCLAMATORY",     "LANG_SENTENCE", edgeMEMBER},
	{"SENT_SIMPLE",          "LANG_SENTENCE", edgeMEMBER},
	{"SENT_COMPOUND",        "LANG_SENTENCE", edgeMEMBER},
	{"SENT_COMPLEX",         "LANG_SENTENCE", edgeMEMBER},
	{"SENT_COMPOUND_COMPLEX","LANG_SENTENCE", edgeMEMBER},
	{"SENT_CONDITIONAL",     "LANG_SENTENCE", edgeMEMBER},
	{"SENT_RELATIVE",        "LANG_CLAUSE",   edgeMEMBER},
	{"SENT_DECLARATIVE",     "SENT_INTERROGATIVE", edgeOPPOSITE},
	{"SENT_DIRECT_SPEECH",   "SENT_INDIRECT_SPEECH", edgeOPPOSITE},
	{"SENT_SIMPLE",          "SENT_COMPOUND_COMPLEX", edgeOPPOSITE},

	// ── Syntax → Sentence ─────────────────────────────────────
	{"SYN_SUBJECT",       "LANG_SENTENCE",   edgePART},
	{"SYN_PREDICATE",     "LANG_SENTENCE",   edgePART},
	{"SYN_OBJECT_DIRECT", "LANG_SENTENCE",   edgePART},
	{"SYN_SUBJECT",       "SYN_PREDICATE",   edgeSIMILAR},
	{"SYN_OBJECT_DIRECT", "SYN_OBJECT_INDIRECT", edgeSIMILAR},
	{"SYN_PHRASE_NOUN",   "LANG_PHRASE",     edgeMEMBER},
	{"SYN_PHRASE_VERB",   "LANG_PHRASE",     edgeMEMBER},
	{"SYN_PHRASE_ADJ",    "LANG_PHRASE",     edgeMEMBER},
	{"SYN_PHRASE_PREP",   "LANG_PHRASE",     edgeMEMBER},

	// ── Semantics ─────────────────────────────────────────────
	{"SEM_SYNONYM",    "SEM_ANTONYM",   edgeOPPOSITE},
	{"SEM_DENOTATION", "SEM_CONNOTATION", edgeOPPOSITE},
	{"SEM_METAPHOR",   "SEM_METONYMY",  edgeSIMILAR},
	{"SEM_IDIOM",      "SEM_COLLOCATION", edgeSIMILAR},
	{"SEM_SYNONYM",    "SEM_MEANING",   edgePART},
	{"SEM_ANTONYM",    "SEM_MEANING",   edgePART},
	{"SEM_AMBIGUITY",  "SEM_POLYSEMY",  edgeSIMILAR},
	{"SEM_METAPHOR",   "SPACE_CONCEPTUAL", edgeSIMILAR},
	{"SEM_IMPLICATURE","PRAG_CONTEXT",  edgeSIMILAR},
	{"SEM_FIELD",      "SEM_PROTOTYPE", edgeSIMILAR},

	// ── Pragmatics ────────────────────────────────────────────
	{"PRAG_CONTEXT",       "PRAG_REGISTER",    edgeSIMILAR},
	{"PRAG_SPEECH_ACT",    "PRAG_ILLOCUTION",  edgePART},
	{"PRAG_REGISTER_FORMAL","PRAG_REGISTER_INFORMAL", edgeOPPOSITE},
	{"PRAG_REGISTER_SLANG","PRAG_REGISTER_FORMAL",    edgeOPPOSITE},
	{"PRAG_POLITENESS",    "PRAG_CONTEXT",     edgeSIMILAR},
	{"PRAG_TOPIC",         "PRAG_FOCUS",       edgeOPPOSITE},
	{"PRAG_COHERENCE",     "PRAG_COHESION",    edgeSIMILAR},
	{"PRAG_DEIXIS",        "PRAG_CONTEXT",     edgePART},
	{"PRAG_INTONATION",    "PHON_INTONATION",  edgeSIMILAR},

	// ── Conceptual Space ──────────────────────────────────────
	{"SPACE_FRAME",     "SPACE_CONCEPTUAL",  edgePART},
	{"SPACE_SCHEMA",    "SPACE_CONCEPTUAL",  edgePART},
	{"SPACE_BLENDING",  "SPACE_CONCEPTUAL",  edgePART},
	{"SPACE_FRAME",     "SEM_MEANING",       edgeSIMILAR},

	// ── Phonology ─────────────────────────────────────────────
	{"PHON_VOWEL",     "LANG_PHONEME",  edgeMEMBER},
	{"PHON_CONSONANT", "LANG_PHONEME",  edgeMEMBER},
	{"PHON_VOWEL",     "PHON_CONSONANT", edgeOPPOSITE},
	{"PHON_STRESS",    "LANG_SYLLABLE", edgePART},
	{"PHON_IPA",       "LANG_PHONEME",  edgeSIMILAR},

	// ── Lexicology ────────────────────────────────────────────
	{"LEX_PREFIX",    "LANG_MORPHEME",   edgeMEMBER},
	{"LEX_SUFFIX",    "LANG_MORPHEME",   edgeMEMBER},
	{"LEX_ROOT",      "LANG_MORPHEME",   edgeMEMBER},
	{"LEX_PREFIX",    "LEX_SUFFIX",      edgeOPPOSITE},
	{"LEX_COMPOUND",  "LANG_WORD",       edgeMEMBER},
	{"LEX_DERIVATION","LEX_INFLECTION",  edgeSIMILAR},
	{"LEX_LOANWORD",  "LANG_WORD",       edgeMEMBER},
	{"LEX_EUPHEMISM", "SEM_CONNOTATION", edgeSIMILAR},
	{"LEX_ARCHAISM",  "LEX_NEOLOGISM",   edgeOPPOSITE},

	// ── Genre → Text ──────────────────────────────────────────
	{"GENRE_NARRATIVE",    "LANG_TEXT", edgeMEMBER},
	{"GENRE_DESCRIPTIVE",  "LANG_TEXT", edgeMEMBER},
	{"GENRE_EXPOSITORY",   "LANG_TEXT", edgeMEMBER},
	{"GENRE_ARGUMENTATIVE","LANG_TEXT", edgeMEMBER},
	{"GENRE_PROCEDURAL",   "LANG_TEXT", edgeMEMBER},
	{"GENRE_NARRATIVE",    "GENRE_DESCRIPTIVE", edgeSIMILAR},
	{"GENRE_ARGUMENTATIVE","GENRE_EXPOSITORY",  edgeSIMILAR},

	// ── Languages → LANG_LANGUAGE ────────────────────────────
	{"LANG_ENGLISH",    "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_VIETNAMESE", "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_CHINESE",    "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_FRENCH",     "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_SPANISH",    "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_JAPANESE",   "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_KOREAN",     "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_ARABIC",     "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_GERMAN",     "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_RUSSIAN",    "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_HINDI",      "LANG_LANGUAGE", edgeMEMBER},
	{"LANG_PORTUGUESE", "LANG_LANGUAGE", edgeMEMBER},
	// Cross-language similarities (Germanic)
	{"LANG_ENGLISH",    "LANG_GERMAN",    edgeSIMILAR},
	{"LANG_FRENCH",     "LANG_SPANISH",   edgeSIMILAR},
	{"LANG_FRENCH",     "LANG_PORTUGUESE",edgeSIMILAR},
	{"LANG_JAPANESE",   "LANG_KOREAN",    edgeSIMILAR},
	{"LANG_CHINESE",    "LANG_JAPANESE",  edgeSIMILAR},

	// ── Language acts → LANG_COMMUNICATION ────────────────────
	{"WORD_SAY",       "LANG_COMMUNICATION", edgeMEMBER},
	{"WORD_WRITE",     "LANG_COMMUNICATION", edgeMEMBER},
	{"WORD_READ",      "LANG_COMMUNICATION", edgeMEMBER},
	{"WORD_LISTEN",    "LANG_COMMUNICATION", edgeMEMBER},
	{"WORD_TRANSLATE", "LANG_LANGUAGE",      edgeSIMILAR},
	{"WORD_SAY",       "WORD_LISTEN",        edgeOPPOSITE},
	{"WORD_WRITE",     "WORD_READ",          edgeOPPOSITE},
	{"WORD_ARGUE",     "WORD_PERSUADE",      edgeSIMILAR},
	{"WORD_PROMISE",   "PRAG_SPEECH_ACT",    edgeMEMBER},
	{"WORD_WARN",      "PRAG_SPEECH_ACT",    edgeMEMBER},
	{"WORD_APOLOGIZE", "PRAG_SPEECH_ACT",    edgeMEMBER},
	{"WORD_GREET",     "PRAG_SPEECH_ACT",    edgeMEMBER},
	{"WORD_REQUEST",   "WORD_ORDER",         edgeSIMILAR},
	{"WORD_REQUEST",   "PRAG_POLITENESS",    edgeSIMILAR},

	// ── Cross-domain links ────────────────────────────────────
	{"LANG_LINGUISTICS","LANG_LANGUAGE",    edgePART},
	{"GRAM_TENSE",      "POS_VERB",         edgeSIMILAR},
	{"GRAM_AGREEMENT",  "GRAM_NUMBER",      edgeSIMILAR},
	{"GRAM_CASE",       "POS_PRONOUN",      edgeSIMILAR},
	{"GRAM_MOOD_IMPERATIVE","SENT_IMPERATIVE", edgeSIMILAR},
	{"GRAM_MOOD_INDICATIVE","SENT_DECLARATIVE", edgeSIMILAR},
	{"SYN_PHRASE_NOUN", "POS_NOUN",         edgeSIMILAR},
	{"SYN_PHRASE_VERB", "POS_VERB",         edgeSIMILAR},
	{"SYN_PHRASE_ADJ",  "POS_ADJECTIVE",    edgeSIMILAR},
	{"SYN_PHRASE_PREP", "POS_PREPOSITION",  edgeSIMILAR},
	{"SEM_MEANING",     "LANG_LINGUISTICS", edgePART},
	{"PRAG_CONTEXT",    "LANG_LINGUISTICS", edgePART},
	{"WORD_ANALYZE",    "LANG_LINGUISTICS", edgeMEMBER},
	{"WORD_DEFINE",     "SEM_MEANING",      edgeSIMILAR},
	{"WORD_PARAPHRASE", "SEM_SYNONYM",      edgeSIMILAR},
	{"WORD_COMPARE",    "WORD_CONTRAST",    edgeSIMILAR},
}

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil {
		log.Fatalf("read %s: %v", filePath, err)
	}
	fmt.Printf("○ Đọc %s: %d bytes, %d nodes, %d edges\n",
		filePath, len(raw), be32(raw[12:16]), be32(raw[16:20]))

	existNames := readNames(raw)
	nAdded := 0

	// ── BƯỚC 1: Thêm nodes ────────────────────────────────────
	for _, nd := range langNodes {
		if existNames[nd.name] {
			fmt.Printf("   skip (exist) %s\n", nd.name)
			continue
		}
		isl := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, isl, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existNames[nd.name] = true
		nAdded++
	}
	fmt.Printf("✚  Thêm nodes: %d\n", nAdded)

	// ── BƯỚC 2: Thêm edges ────────────────────────────────────
	nameToISL := readNameToISL(raw)
	existEdges := readEdges(raw)
	nEdgesAdded := 0

	for _, e := range langEdges {
		src, ok1 := nameToISL[e.from]
		dst, ok2 := nameToISL[e.to]
		if !ok1 {
			fmt.Printf("   edge MISS src: %s\n", e.from)
			continue
		}
		if !ok2 {
			fmt.Printf("   edge MISS dst: %s\n", e.to)
			continue
		}
		key := edgeKey(src, dst, e.typ)
		if existEdges[key] {
			continue
		}
		raw = appendEdge(raw, src, dst, e.typ)
		existEdges[key] = true
		nEdgesAdded++
	}
	fmt.Printf("✚  Thêm edges: %d\n", nEdgesAdded)

	// ── BƯỚC 3: Cập nhật SHA256 ───────────────────────────────
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])

	// ── BƯỚC 4: Ghi file atomic ───────────────────────────────
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, raw, 0644); err != nil {
		log.Fatal(err)
	}
	if err := os.Rename(tmp, filePath); err != nil {
		log.Fatal(err)
	}

	fmt.Printf("\n✅ Xong: %d nodes, %d edges, %d bytes\n",
		be32(raw[12:16]), be32(raw[16:20]), len(raw))
	fmt.Printf("   → %d nodes ngôn ngữ (L3+L5) + %d silk edges\n",
		nAdded, nEdgesAdded)
}

// ─── Helpers (copy từ cleanup_and_seed.go) ──────────────────

func buildRecord(layer uint8, isl [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 {
		nb = nb[:255]
	}
	rec := make([]byte, 2+1+8+4+4+1+len(dna)+len(nb))
	p := 0
	rec[p] = 'N'; p++
	rec[p] = 'D'; p++
	rec[p] = layer; p++
	copy(rec[p:], isl[:]); p += 8
	p += 4 // codepoint = 0
	rec[p] = byte(len(dna) >> 24); rec[p+1] = byte(len(dna) >> 16)
	rec[p+2] = byte(len(dna) >> 8); rec[p+3] = byte(len(dna)); p += 4
	rec[p] = uint8(len(nb)); p++
	copy(rec[p:], dna); p += len(dna)
	copy(rec[p:], nb)
	return rec
}

func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0] = layer
	isl[1] = h[0]%200 + 1
	isl[2] = h[1]%200 + 1
	isl[3] = h[2]%200 + 1
	isl[4] = h[3]; isl[5] = h[4]; isl[6] = h[5]; isl[7] = h[6]
	return isl
}

func insertNode(raw []byte, rec []byte) []byte {
	nedges := int(be32(raw[16:20]))
	edgeEnd := len(raw)
	nodeEnd := edgeEnd - nedges*17
	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:nodeEnd]...)
	out = append(out, rec...)
	out = append(out, raw[nodeEnd:]...)
	n := be32(out[12:16]) + 1
	out[12] = byte(n >> 24); out[13] = byte(n >> 16)
	out[14] = byte(n >> 8); out[15] = byte(n)
	return out
}

func appendEdge(raw []byte, src, dst [8]byte, typ uint8) []byte {
	edge := make([]byte, 17)
	copy(edge[:8], src[:]); copy(edge[8:16], dst[:]); edge[16] = typ
	out := append(raw, edge...)
	n := be32(out[16:20]) + 1
	out[16] = byte(n >> 24); out[17] = byte(n >> 16)
	out[18] = byte(n >> 8); out[19] = byte(n)
	return out
}

func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end {
		if i+2 < len(raw) && raw[i] == 'N' && raw[i+1] == 'D' {
			dl := int(be32(raw[i+15 : i+19]))
			nl := int(raw[i+19])
			ns := i + 20 + dl
			ne := ns + nl
			if ne > end {
				break
			}
			m[string(raw[ns:ne])] = true
			i = ne
		} else {
			i++
		}
	}
	return m
}

func readNameToISL(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end {
		if i+2 < len(raw) && raw[i] == 'N' && raw[i+1] == 'D' {
			var isl [8]byte
			copy(isl[:], raw[i+3:i+11])
			dl := int(be32(raw[i+15 : i+19]))
			nl := int(raw[i+19])
			ns := i + 20 + dl
			ne := ns + nl
			if ne > end {
				break
			}
			m[string(raw[ns:ne])] = isl
			i = ne
		} else {
			i++
		}
	}
	return m
}

func readEdges(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	start := len(raw) - nedges*17
	for i := start; i+17 <= len(raw); i += 17 {
		var s, d [8]byte
		copy(s[:], raw[i:i+8]); copy(d[:], raw[i+8:i+16])
		m[edgeKey(s, d, raw[i+16])] = true
	}
	return m
}

func edgeKey(s, d [8]byte, t uint8) string {
	return fmt.Sprintf("%x:%x:%02x", s, d, t)
}

func be32(b []byte) uint32 {
	return binary.BigEndian.Uint32(b)
}
