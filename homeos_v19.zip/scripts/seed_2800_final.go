//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── TRIẾT HỌC BỔ SUNG (PHIL3_) ────────────────────────────
		{"PHIL3_STOICISM",    3, `label=chủ nghĩa Khắc kỷ|desc=Stoicism Marcus Aurelius Epictetus Seneca kiểm soát nội tâm logos virtue resilience|vi=chủ nghĩa Khắc kỷ,Stoicism|en=Stoicism|zh=斯多葛主义`},
		{"PHIL3_NIHILISM",    3, `label=hư vô chủ nghĩa|desc=Nietzsche nihilism không có ý nghĩa khách quan God is dead will to power|vi=hư vô chủ nghĩa,nihilism|en=nihilism|zh=虚无主义`},
		{"PHIL3_PRAGMATISM",  3, `label=chủ nghĩa thực dụng|desc=pragmatism William James John Dewey ý nghĩa = hệ quả thực tế truth as usefulness|vi=chủ nghĩa thực dụng,pragmatism|en=pragmatism|zh=实用主义`},

		// ── KHOA HỌC VẬT LIỆU MỚI (NEWMAT_) ─────────────────────
		{"NEWMAT_2D_MAT",     3, `label=vật liệu 2D|desc=graphene MoS2 silicene vật liệu một nguyên tử dẫn điện siêu mỏng Nobel 2010|vi=vật liệu 2D,graphene|en=2D materials|zh=二维材料`},
		{"NEWMAT_METAMAT",    3, `label=siêu vật liệu|desc=metamaterial cấu trúc nhân tạo tính chất không tự nhiên âm tàng hình ánh sáng bẻ cong|vi=siêu vật liệu,metamaterial|en=metamaterial|zh=超材料`},
		{"NEWMAT_HYDROGEL",   3, `label=hydrogel|desc=vật liệu polymer ngậm nước mềm linh hoạt y tế lens kính áp tròng thuốc kiểm soát|vi=hydrogel|en=hydrogel|zh=水凝胶`},

		// ── LỊCH SỬ KHOA HỌC (SCIHIST_) ─────────────────────────
		{"SCIHIST_NEWTON",    3, `label=Isaac Newton|desc=vật lý cổ điển lực hấp dẫn định luật chuyển động Principia 1687 tích phân ánh sáng|vi=Isaac Newton,Newton|en=Isaac Newton|zh=艾萨克·牛顿`},
		{"SCIHIST_EINSTEIN",  3, `label=Albert Einstein|desc=tương đối hẹp rộng E=mc2 Nobel 1921 quang điện Brownian motion GPT cosmological constant|vi=Albert Einstein,Einstein|en=Albert Einstein|zh=阿尔伯特·爱因斯坦`},
		{"SCIHIST_CURIE",     3, `label=Marie Curie|desc=polonium radium Nobel Vật lý 1903 Hóa học 1911 phóng xạ phụ nữ đầu tiên|vi=Marie Curie,Curie|en=Marie Curie|zh=玛丽·居里`},
		{"SCIHIST_DARWIN_SCI",3, `label=Charles Darwin|desc=On the Origin of Species 1859 tiến hóa chọn lọc tự nhiên thuyến Beagle Galapagos|vi=Charles Darwin,Darwin nhà khoa học|en=Charles Darwin|zh=查尔斯·达尔文`},
		{"SCIHIST_TESLA",     3, `label=Nikola Tesla|desc=AC điện xoay chiều Tesla coil radio X-ray Westinghouse Edison đèn huỳnh quang|vi=Nikola Tesla,Tesla|en=Nikola Tesla|zh=尼古拉·特斯拉`},

		// ── ĐỊA LÝ TRUNG ĐÔNG (MIDEAST_) ─────────────────────────
		{"MIDEAST_OIL",       3, `label=dầu mỏ Trung Đông|desc=Saudi Arabia UAE Kuwait Iraq Iran OPEC trữ lượng địa chính trị petrodollar|vi=dầu mỏ Trung Đông,Middle East oil|en=Middle East oil|zh=中东石油`},
		{"MIDEAST_ISRAEL",    3, `label=Israel|desc=nhà nước Israel 1948 Do Thái Jerusalem công nghệ start-up nation xung đột|vi=Israel|en=Israel|zh=以色列`},
		{"MIDEAST_TURKEY",    3, `label=Thổ Nhĩ Kỳ|desc=Turkey NATO EU Istanbul Erdogan phát triển kinh tế đặc vị địa chiến lược|vi=Thổ Nhĩ Kỳ,Turkey|en=Turkey|zh=土耳其`},

		// ── CÁC TỔ CHỨC QUỐC TẾ (INTORG_) ───────────────────────
		{"INTORG_WHO",        3, `label=WHO|desc=Tổ chức Y tế Thế giới Genève COVID pandemic tiêm chủng bệnh truyền nhiễm sức khỏe toàn cầu|vi=WHO,Tổ chức Y tế Thế giới|en=WHO,World Health Organization|zh=世界卫生组织`},
		{"INTORG_IMF",        3, `label=IMF|desc=Quỹ Tiền tệ Quốc tế tổ chức tín dụng khủng hoảng kinh tế SDR tỷ giá hối đoái|vi=IMF,Quỹ Tiền tệ Quốc tế|en=IMF|zh=国际货币基金组织`},
		{"INTORG_WTO",        3, `label=WTO|desc=Tổ chức Thương mại Thế giới tự do hóa thương mại thuế quan tranh chấp DSB|vi=WTO,Tổ chức Thương mại Thế giới|en=WTO|zh=世界贸易组织`},
		{"INTORG_WORLD_BANK", 3, `label=Ngân hàng Thế giới|desc=World Bank cho vay phát triển xóa đói giảm nghèo cơ sở hạ tầng SDG|vi=Ngân hàng Thế giới,World Bank|en=World Bank|zh=世界银行`},

		// ── PHÚC LỢI XÃ HỘI (WELFARE_) ──────────────────────────
		{"WELFARE_BASIC_INCOME",3,`label=thu nhập cơ bản phổ quát|desc=UBI Universal Basic Income Finland pilot automation robot thất nghiệp|vi=thu nhập cơ bản,UBI|en=UBI,Universal Basic Income|zh=全民基本收入`},
		{"WELFARE_SOCIAL_SECURITY",3,`label=an sinh xã hội|desc=bảo hiểm xã hội thất nghiệp hưu trí y tế nhà ở welfare state Bismarck|vi=an sinh xã hội,social security|en=social security|zh=社会保障`},
		{"WELFARE_HEALTHCARE_SYS",3,`label=hệ thống y tế|desc=universal healthcare NHS Mỹ insurance single payer Bismarck Beveridge|vi=hệ thống y tế,healthcare system|en=healthcare system|zh=医疗体系`},

		// ── NGHỆ THUẬT HIỆN ĐẠI (ARTMODERN_) ─────────────────────
		{"ARTMODERN_SURREAL", 3, `label=chủ nghĩa siêu thực|desc=Surrealism Dali Magritte vô thức Freud dream juxtaposition irrational|vi=chủ nghĩa siêu thực,Surrealism|en=Surrealism|zh=超现实主义`},
		{"ARTMODERN_ABSTRACT",3, `label=trừu tượng|desc=Abstract art Kandinsky Mondrian Pollock Jackson không hình thức màu sắc cảm xúc|vi=trừu tượng,Abstract art|en=Abstract art|zh=抽象艺术`},
		{"ARTMODERN_POP_ART", 3, `label=Pop Art|desc=Andy Warhol Roy Lichtenstein văn hóa đại chúng Campbell soup Marilyn Monroe quảng cáo|vi=Pop Art,nghệ thuật đại chúng|en=Pop Art|zh=波普艺术`},

		// ── VĂN HỌC THẾ GIỚI BỔ SUNG (LIT3_) ────────────────────
		{"LIT3_KAFKA",        3, `label=Franz Kafka|desc=The Metamorphosis The Trial The Castle absurdist kafkaesque bureaucracy alienation|vi=Kafka,Franz Kafka|en=Franz Kafka|zh=卡夫卡`},
		{"LIT3_TOLKIEN",      3, `label=Tolkien|desc=The Lord of the Rings The Hobbit Middle-earth fantasy myth-making linguistics|vi=Tolkien,J.R.R. Tolkien|en=Tolkien|zh=托尔金`},
		{"LIT3_GEORGE_ORWELL",3, `label=George Orwell|desc=1984 Animal Farm totalitarianism Big Brother doublethink dystopia politics|vi=George Orwell,Orwell|en=George Orwell|zh=乔治·奥威尔`},

		// ── ÂM NHẠC THẾ GIỚI (WORLDMUSIC_) ──────────────────────
		{"WORLDMUSIC_BEETHOVEN",3,`label=Beethoven|desc=Ludvig van Beethoven Ninth Symphony điếc Moonlight Sonata Für Elise lãng mạn|vi=Beethoven|en=Beethoven|zh=贝多芬`},
		{"WORLDMUSIC_JAZZ",   3, `label=nhạc Jazz|desc=Jazz New Orleans improvisation blues bebop Miles Davis Coltrane Fitzgerald|vi=nhạc Jazz,jazz|en=Jazz music|zh=爵士乐`},
		{"WORLDMUSIC_HIP_HOP",3, `label=Hip-hop|desc=hip-hop rap breakdance graffiti DJ Bronx New York Tupac Jay-Z Kendrick Lamar|vi=hip-hop,rap|en=hip-hop|zh=嘻哈`},

		// ── KHOA HỌC KHÍ HẬU (CLIMATE2_) ────────────────────────
		{"CLIMATE2_FEEDBACK", 3, `label=vòng phản hồi khí hậu|desc=climate feedback albedo ice-albedo water vapor permafrost methane amplifying|vi=vòng phản hồi khí hậu,climate feedback|en=climate feedback|zh=气候反馈`},
		{"CLIMATE2_TIPPING",  3, `label=điểm tới hạn khí hậu|desc=tipping point Amazon dieback West Antarctic ice sheet permafrost 1.5C IPCC|vi=điểm tới hạn khí hậu,tipping point|en=climate tipping point|zh=气候临界点`},
		{"CLIMATE2_CARBON_CAP",3,`label=thu giữ carbon|desc=carbon capture CCS DAC direct air capture carbon sequestration net zero|vi=thu giữ carbon,carbon capture|en=carbon capture|zh=碳捕获`},
		{"CLIMATE2_ADAPT",    3, `label=thích ứng biến đổi khí hậu|desc=climate adaptation đê ngập lụt drought-resistant crops resilient infrastructure|vi=thích ứng biến đổi khí hậu,climate adaptation|en=climate adaptation|zh=气候适应`},

		// ── SỨC KHỎE DINH DƯỠNG (NUTRIHEALTH_) ──────────────────
		{"NUTRIHEALTH_MICRO", 3, `label=vi chất dinh dưỡng|desc=vitamin A B C D E K khoáng sắt kẽm iod thiếu hụt sức khỏe|vi=vi chất dinh dưỡng,micronutrient|en=micronutrient|zh=微量营养素`},
		{"NUTRIHEALTH_GUT",   3, `label=hệ vi sinh đường ruột|desc=gut microbiome 38 nghìn tỷ vi khuẩn probiotics prebiotics sức khỏe tâm thần|vi=hệ vi sinh đường ruột,gut microbiome|en=gut microbiome|zh=肠道微生物组`},
		{"NUTRIHEALTH_FASTING",3,`label=nhịn ăn gián đoạn|desc=intermittent fasting 16:8 5:2 OMAD autophagy insulin sensitivity longevity|vi=nhịn ăn gián đoạn,intermittent fasting|en=intermittent fasting|zh=间歇性禁食`},

		// ── KINH TẾ HỌC MÔI TRƯỜNG (ENVECON_) ───────────────────
		{"ENVECON_CARBON_TAX",3, `label=thuế carbon|desc=carbon tax giá phát thải CO2 Thụy Điển Canada BC khuyến khích chuyển đổi năng lượng|vi=thuế carbon,carbon tax|en=carbon tax|zh=碳税`},
		{"ENVECON_GREEN_ECON",3, `label=kinh tế xanh|desc=green economy circular economy ESG doanh nghiệp bền vững net zero|vi=kinh tế xanh,green economy|en=green economy|zh=绿色经济`},
		{"ENVECON_PAYMENT_ES",3, `label=chi trả dịch vụ hệ sinh thái|desc=PES Payment for Ecosystem Services rừng nước sạch carbon REDD+|vi=chi trả dịch vụ hệ sinh thái,PES|en=Payment for Ecosystem Services|zh=生态系统服务付费`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"PHIL3_STOICISM",     "MOD_PHIL_EXISTENT",   "contrasts-with"},
		{"SCIHIST_NEWTON",     "PHYS5_PLASMA",        "predates"},
		{"SCIHIST_EINSTEIN",   "MODPHYS_ENTANGLE",    "discovered"},
		{"SCIHIST_CURIE",      "NUCLEAR_RADIATION",   "discovered"},
		{"SCIHIST_DARWIN_SCI", "EVOBIO_DARWIN",       "is"},
		{"INTORG_WHO",         "PUBHEALTH2_EPIDEM",   "guides"},
		{"INTORG_WTO",         "GEOPOLIT_BRICS",      "regulates"},
		{"INTORG_IMF",         "GEOPOLIT_G7",         "funded-by"},
		{"WELFARE_BASIC_INCOME","DIGI_ECON_GIGS",     "response-to"},
		{"CLIMATE2_TIPPING",   "CLIMATE2_FEEDBACK",   "caused-by"},
		{"CLIMATE2_CARBON_CAP","SDG_GOALS",           "supports"},
		{"ENVECON_CARBON_TAX", "CLIMATE2_CARBON_CAP", "funds"},
		{"NUTRIHEALTH_GUT",    "HEALTH2_MENTAL",      "affects"},
		{"LIT3_GEORGE_ORWELL", "IDEAHIST_LIBERALISM", "warns-about"},
		{"WORLDMUSIC_JAZZ",    "POPCULTURE_KPOP",     "influenced"},
		{"ARTMODERN_SURREAL",  "ARTWORLD_PICASSO",    "contemporary-of"},
		{"NEWMAT_2D_MAT",      "APPPHYS_SEMICOND",    "advances"},
		{"MIDEAST_OIL",        "GEOPOLIT_INDO_PACIFIC","affects"},
		{"CLIMATE2_ADAPT",     "ENVSCI_SOIL",         "includes"},
		{"NUTRIHEALTH_FASTING","FUTURE_LONGEVITY",    "supports"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2800 { fmt.Println("🎉 MILESTONE 2800!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16]=relByte(rel); raw=append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"contrasts-with":1,"predates":2,"discovered":3,"is":4,"guides":5,
		"regulates":6,"funded-by":7,"response-to":8,"caused-by":9,"supports":10,
		"funds":11,"affects":12,"warns-about":13,"influenced":14,"contemporary-of":15,
		"advances":16,"includes":17,"contemporary":18,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
