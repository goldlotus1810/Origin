//go:build ignore
// Fix LAYER_INFER node: di chuyển "màu","âm thanh" từ l2_nature sang l6_perception
// Thêm l6_perception field
// Chạy: go run scripts/fix_layer_infer.go
package main
import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)
const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	pos := layerIdxEnd
	fixed := 0
	for pos < end-25 {
		idx := findND(raw, pos, end)
		if idx < 0 { break }
		dnaLen := int(be32be(raw[idx+15:idx+19]))
		nameLen := int(raw[idx+19])
		total := 20 + dnaLen + nameLen
		if dnaLen > 10000 || nameLen > 200 || idx+total > end { pos = idx+1; continue }
		name := string(raw[idx+20+dnaLen : idx+20+dnaLen+nameLen])
		if name == "LAYER_INFER" {
			oldDNA := string(raw[idx+20 : idx+20+dnaLen])
			fmt.Printf("Old DNA: %s\n\n", oldDNA)
			// DNA mới: bỏ màu/âm thanh khỏi l2, thêm l6
			newDNA := `l2_nature=ánh sáng,nước,lửa,gió,nhiệt,light,water,fire,wind,heat` +
				`|l4_object=đèn,cửa,xe,thiết bị,lamp,door,device,sensor,máy,robot,screen,màn hình` +
				`|l5_language=danh từ,động từ,tính từ,thì quá khứ,thì hiện tại,thì tương lai,ngữ pháp,ngữ nghĩa,ngôn ngữ học` +
				`|l6_perception=màu,màu sắc,màu đỏ,màu xanh,âm thanh,bước sóng,quang phổ,cảm giác,color,sound,spectrum` +
				`|default=7`
			fmt.Printf("New DNA: %s\n\n", newDNA)
			newDNAb := []byte(newDNA)
			newRec := make([]byte, 20+len(newDNAb)+nameLen)
			copy(newRec[:20], raw[idx:idx+20])
			newRec[15] = byte(len(newDNAb) >> 24)
			newRec[16] = byte(len(newDNAb) >> 16)
			newRec[17] = byte(len(newDNAb) >> 8)
			newRec[18] = byte(len(newDNAb))
			copy(newRec[20:], newDNAb)
			copy(newRec[20+len(newDNAb):], raw[idx+20+dnaLen:idx+20+dnaLen+nameLen])
			out := make([]byte, 0, len(raw))
			out = append(out, raw[:idx]...)
			out = append(out, newRec...)
			out = append(out, raw[idx+total:]...)
			raw = out
			end = len(raw) - nedges*17
			fixed++
			pos = idx + len(newRec)
			continue
		}
		pos = idx + total
	}
	fmt.Printf("Fixed %d nodes\n", fixed)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, raw, 0644); err != nil { log.Fatal(err) }
	if err := os.Rename(tmp, filePath); err != nil { log.Fatal(err) }
	fmt.Printf("✅ Done: %d bytes\n", len(raw))
}
func findND(data []byte, from, end int) int {
	for i := from; i < end-1; i++ {
		if data[i] == 'N' && data[i+1] == 'D' { return i }
	}
	return -1
}
func be32(b []byte) uint32  { return binary.BigEndian.Uint32(b) }
func be32be(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
