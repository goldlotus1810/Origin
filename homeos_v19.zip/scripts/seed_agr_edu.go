//go:build ignore
// go run scripts/seed_agr_edu.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── NÔNG NGHIỆP / LƯƠNG THỰC ──────────────────────────────
		{"AGR_RICE_FARM",   3, `label=trồng lúa|desc=canh tác lúa nước lúa mì chủ lực lương thực toàn cầu ruộng bậc thang mùa vụ thu hoạch|vi=trồng lúa,canh tác lúa,rice farming|en=rice farming,rice cultivation|zh=水稻种植`},
		{"AGR_LIVESTOCK",   3, `label=chăn nuôi|desc=nuôi gia súc gia cầm lợn bò gà vịt để lấy thịt trứng sữa chăn nuôi công nghiệp|vi=chăn nuôi,livestock|en=livestock farming,animal husbandry|zh=畜牧业`},
		{"AGR_IRRIGATION",  3, `label=tưới tiêu|desc=cung cấp nước cho cây trồng hệ thống kênh mương giếng khoan tưới nhỏ giọt|vi=tưới tiêu,irrigation|en=irrigation|zh=灌溉`},
		{"AGR_FERTILIZER",  3, `label=phân bón|desc=chất dinh dưỡng bổ sung cho đất giúp cây trồng phát triển phân đạm lân kali hữu cơ|vi=phân bón,fertilizer|en=fertilizer|zh=化肥`},
		{"AGR_ORGANIC",     3, `label=nông nghiệp hữu cơ|desc=canh tác không dùng hóa chất tổng hợp phân bón hữu cơ thuốc trừ sâu sinh học|vi=nông nghiệp hữu cơ,organic farming|en=organic farming,organic agriculture|zh=有机农业`},
		{"AGR_SEED",        3, `label=hạt giống|desc=phôi cây dùng để gieo trồng hạt giống cải tiến GMO hạt giống lai F1 bảo tồn|vi=hạt giống,seed|en=seed|zh=种子`},
		{"AGR_PEST",        3, `label=sâu bệnh|desc=sinh vật gây hại cây trồng sâu rầy nấm vi khuẩn thuốc bảo vệ thực vật IPM|vi=sâu bệnh,pest,thuốc trừ sâu|en=pest,crop disease|zh=病虫害`},
		{"AGR_GREENHOUSE",  3, `label=nhà kính|desc=cấu trúc kính hoặc nhựa trồng rau quả kiểm soát môi trường nhiệt độ độ ẩm|vi=nhà kính,greenhouse|en=greenhouse|zh=温室`},
		{"AGR_AQUA",        3, `label=nuôi trồng thủy sản|desc=nuôi cá tôm cua nhuyễn thể rong biển tại ao hồ biển cá tra cá hồi|vi=nuôi trồng thủy sản,aquaculture|en=aquaculture,fish farming|zh=水产养殖`},
		{"AGR_DROUGHT",     3, `label=hạn hán|desc=thiếu nước kéo dài ảnh hưởng nông nghiệp biến đổi khí hậu mất mùa cạn kiệt|vi=hạn hán,drought|en=drought|zh=干旱`},

		// ── GIÁO DỤC / HỌC TẬP ───────────────────────────────────
		{"EDU_SCHOOL",      3, `label=trường học|desc=cơ sở giáo dục tiểu học trung học phổ thông học sinh giáo viên chương trình|vi=trường học,school|en=school|zh=学校`},
		{"EDU_UNIVERSITY",  3, `label=đại học|desc=cơ sở giáo dục bậc cao nghiên cứu học thuật cấp bằng cử nhân thạc sĩ tiến sĩ|vi=đại học,university,college|en=university,college|zh=大学`},
		{"EDU_ONLINE",      3, `label=học trực tuyến|desc=học qua internet e-learning MOOC Coursera Khan Academy linh hoạt toàn cầu|vi=học trực tuyến,e-learning,online learning|en=online learning,e-learning,MOOC|zh=在线教育`},
		{"EDU_EXAM",        3, `label=kỳ thi|desc=bài kiểm tra đánh giá kiến thức kỹ năng học sinh sinh viên thi tốt nghiệp đại học|vi=kỳ thi,exam,thi cử|en=exam,test,examination|zh=考试`},
		{"EDU_LITERACY",    3, `label=chữ viết|desc=kỹ năng đọc và viết biết chữ tỷ lệ biết chữ giáo dục cơ bản quyền được học|vi=chữ viết,literacy,biết chữ|en=literacy|zh=识字率`},
		{"EDU_STEM",        3, `label=STEM|desc=khoa học công nghệ kỹ thuật toán học chương trình giáo dục STEM kỹ năng tương lai|vi=STEM,khoa học kỹ thuật|en=STEM,science technology engineering math|zh=STEM教育`},
		{"EDU_SCHOLARSHIP", 3, `label=học bổng|desc=hỗ trợ tài chính cho học sinh sinh viên xuất sắc hoặc có hoàn cảnh khó khăn|vi=học bổng,scholarship|en=scholarship|zh=奖学金`},
		{"EDU_KINDERGARTEN",3, `label=mầm non|desc=giáo dục trẻ em trước tuổi đi học phát triển nhận thức ngôn ngữ xã hội vui chơi|vi=mầm non,mẫu giáo,kindergarten|en=kindergarten,preschool|zh=幼儿园`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Nông nghiệp
		{"AGR_RICE_FARM",  "FOOD_RICE",          "produces"},
		{"AGR_LIVESTOCK",  "FOOD_PROTEIN",        "produces"},
		{"AGR_IRRIGATION", "AGR_RICE_FARM",       "supports"},
		{"AGR_FERTILIZER", "CHEM_MOLECULE",       "contains"},
		{"AGR_ORGANIC",    "ENV_BIODIVERSITY",    "protects"},
		{"AGR_ORGANIC",    "AGR_FERTILIZER",      "avoids"},
		{"AGR_SEED",       "BIO_GENETICS",        "modified-by"},
		{"AGR_PEST",       "AGR_RICE_FARM",       "threatens"},
		{"AGR_GREENHOUSE", "ENV_CLIMATE_CHANGE",  "mitigates"},
		{"AGR_AQUA",       "FOOD_PROTEIN",        "produces"},
		{"AGR_DROUGHT",    "ENV_CLIMATE_CHANGE",  "caused-by"},
		{"AGR_DROUGHT",    "AGR_IRRIGATION",      "requires"},
		// Giáo dục
		{"EDU_UNIVERSITY", "JOB_SCIENTIST",       "trains"},
		{"EDU_UNIVERSITY", "JOB_ENGINEER",        "trains"},
		{"EDU_ONLINE",     "TECH_AI",             "enhanced-by"},
		{"EDU_STEM",       "MATH_EQUATION",       "includes"},
		{"EDU_STEM",       "TECH_PROGRAMMING",    "includes"},
		{"EDU_SCHOOL",     "EDU_EXAM",            "conducts"},
		{"EDU_SCHOLARSHIP","EDU_UNIVERSITY",      "funds"},
		{"EDU_KINDERGARTEN","PSY_LEARNING",       "applies"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"produces":1,"supports":2,"contains":3,"protects":4,
		"avoids":5,"modified-by":6,"threatens":7,"mitigates":8,
		"caused-by":9,"requires":10,"trains":11,"enhanced-by":12,
		"includes":13,"conducts":14,"funds":15,"applies":16,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
