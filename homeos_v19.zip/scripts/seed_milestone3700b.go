//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	existing := readNames(raw)

	type nodeDef struct { name string; layer uint8; dna string }
	nodes := []nodeDef{
		{"CRAFT2_POTTERY",        3, `label=gốm thủ công|desc=pottery wheel throwing hand-building coiling slab kiln bisque glaze reduction oxidation Jomon Raku Seger cone|vi=gốm thủ công,pottery|en=pottery`},
		{"CRAFT2_WOODWORK",       3, `label=mộc thủ công|desc=woodworking joinery dovetail mortise tenon hand tool plane chisel Japanese saw kumiko furniture making|vi=mộc thủ công,woodworking|en=woodworking`},
		{"CRAFT2_TEXTILE",        3, `label=dệt thủ công|desc=textile weaving warp weft loom tapestry resist dyeing ikat shibori natural dye indigo madder weld|vi=dệt thủ công,textile weaving|en=textile weaving`},
		{"CRAFT2_GLASS",          3, `label=thổi thủy tinh|desc=glassblowing borosilicate soda-lime gather pontil blowpipe marvel annealing kiln forming Dale Chihuly studio|vi=thổi thủy tinh,glassblowing|en=glassblowing`},
		{"CRAFT2_LEATHER",        3, `label=đồ da thủ công|desc=leathercraft tanning vegetable chrome saddle stitching burnishing edge finishing tooling carving bookbinding|vi=đồ da thủ công,leathercraft|en=leathercraft`},
		{"DESIGN4_TYPOGRAPHY",    3, `label=typography|desc=typography typeface font kerning leading tracking serif sans hierarchy Helvetica Garamond grid modular scale ratio|vi=typography,typography|en=typography`},
		{"DESIGN4_COLOR",         3, `label=lý thuyết màu sắc|desc=color theory Itten Albers simultaneous contrast color harmony hue saturation value CIELAB perceptual uniform|vi=lý thuyết màu sắc,color theory|en=color theory`},
		{"DESIGN4_UX",            3, `label=UX design|desc=UX design user research persona journey map usability testing heuristics Nielsen Norman affordance Fitts law|vi=UX design,UX design|en=UX design`},
		{"DESIGN4_BRAND",         3, `label=thiết kế thương hiệu|desc=brand design identity logo visual system Pentagram Wolff Olins positioning differentiation consistency brand equity|vi=thiết kế thương hiệu,brand design|en=brand design`},
		{"DESIGN4_MOTION",        3, `label=đồ họa chuyển động|desc=motion graphics easing principles anticipation squash stretch 12 principles Disney After Effects Rive GSAP|vi=đồ họa chuyển động,motion graphics|en=motion graphics`},
		{"FASHION2_TEXTILE_HIST", 3, `label=lịch sử dệt may|desc=textile history Silk Road cotton gin spinning jenny Jacquard loom Industrial Revolution fast fashion sustainability|vi=lịch sử dệt may,textile history|en=textile history`},
		{"FASHION2_SUSTAIN",      3, `label=thời trang bền vững|desc=sustainable fashion slow fashion circular economy upcycling deadstock natural fiber certification Fair Trade|vi=thời trang bền vững,sustainable fashion|en=sustainable fashion`},
		{"FASHION2_STREETWEAR",   3, `label=streetwear culture|desc=streetwear Supreme Off-White BAPE sneaker culture hype drop collab resale market cultural appropriation luxury|vi=streetwear culture,streetwear|en=streetwear`},
		{"MUSEUM_CURATORIAL",     3, `label=quản lý bảo tàng|desc=museum curatorial collection management provenance repatriation decolonizing digital twin accessibility engagement|vi=quản lý bảo tàng,museum curatorial|en=museum curatorial`},
		{"GEOLOGY2_PLATE",        3, `label=kiến tạo mảng|desc=plate tectonics continental drift Wegener subduction seafloor spreading mid-ocean ridge hotspot mantle convection|vi=kiến tạo mảng,plate tectonics|en=plate tectonics`},
		{"GEOLOGY2_MINERAL",      3, `label=khoáng vật học|desc=mineralogy crystal structure silicate Mohs hardness cleavage luster piezoelectric quartz feldspar mica olivine|vi=khoáng vật học,mineralogy|en=mineralogy`},
		{"ECOLOGY2_SUCCESSION",   3, `label=diễn thế sinh thái|desc=ecological succession primary secondary pioneer climax community facilitation inhibition Clements Gleason|vi=diễn thế sinh thái,ecological succession|en=ecological succession`},
		{"ECOLOGY2_TROPHIC",      3, `label=mạng lưới thức ăn|desc=trophic cascade keystone species top-down bottom-up wolf reintroduction trophic level primary secondary tertiary|vi=mạng lưới thức ăn,trophic cascade|en=trophic cascade`},
		{"VNSPORT_VOVOTHUAT",     3, `label=võ cổ truyền Việt Nam|desc=võ cổ truyền Việt Nam võ Bình Định Nhất Nam Vovinam bài quyền binh khí Liên đoàn quốc tế|vi=võ cổ truyền Việt Nam,Vietnamese martial arts|en=Vietnamese martial arts`},
		{"VNSPORT_FOOTBALL",      3, `label=bóng đá Việt Nam|desc=bóng đá Việt Nam AFF Cup 2018 2022 Park Hang-seo Troussier đội tuyển quốc gia V-League CLB TP.HCM Hà Nội|vi=bóng đá Việt Nam,Vietnam football|en=Vietnam football`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3700 { fmt.Println(" MILESTONE 3700! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
