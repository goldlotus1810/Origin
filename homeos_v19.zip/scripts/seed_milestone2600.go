//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── NĂNG LƯỢNG VIỆT NAM (VNENERGY_) ──────────────────────
		{"VNENERGY_SOLAR_VN",  3, `label=điện mặt trời Việt Nam|desc=Việt Nam top 10 toàn cầu về công suất lắp đặt điện mặt trời Bình Thuận Ninh Thuận bùng nổ 2019-2021|vi=điện mặt trời Việt Nam,solar VN|en=Vietnam solar|zh=越南太阳能`},
		{"VNENERGY_WIND_VN",   3, `label=điện gió Việt Nam|desc=tiềm năng điện gió lớn nhất Đông Nam Á bờ biển dài Bạc Liêu Trà Vinh offshore 2030|vi=điện gió Việt Nam|en=Vietnam wind power|zh=越南风能`},
		{"VNENERGY_HYDRO_VN",  3, `label=thủy điện Việt Nam|desc=thủy điện Hòa Bình Sơn La Lai Châu hệ thống sông ngòi chiếm 35-40% sản lượng điện|vi=thủy điện Việt Nam|en=Vietnam hydropower|zh=越南水电`},

		// ── NÔNG NGHIỆP VIỆT NAM (VNAGR_) ────────────────────────
		{"VNAGR_RICE",        3, `label=lúa gạo Việt Nam|desc=Việt Nam top 3 xuất khẩu gạo thế giới gạo ST25 ngon nhất thế giới ĐBSCL Thái Bình|vi=lúa gạo Việt Nam,gạo ST25|en=Vietnam rice|zh=越南大米`},
		{"VNAGR_COFFEE",      3, `label=cà phê Việt Nam|desc=Việt Nam top 2 xuất khẩu cà phê robusta Tây Nguyên Buôn Ma Thuột cà phê trứng|vi=cà phê Việt Nam,cà phê|en=Vietnam coffee|zh=越南咖啡`},
		{"VNAGR_SEAFOOD",     3, `label=thủy sản Việt Nam|desc=tôm cá tra basa pangasius xuất khẩu top 3 thế giới Cà Mau An Giang nuôi trồng chế biến|vi=thủy sản Việt Nam,xuất khẩu thủy sản|en=Vietnam seafood|zh=越南水产`},
		{"VNAGR_DRAGON_FRUIT",3, `label=thanh long Việt Nam|desc=thanh long Bình Thuận xuất khẩu Trung Quốc giống trắng đỏ vàng GlobalGAP|vi=thanh long,dragon fruit|en=dragon fruit|zh=火龙果`},

		// ── HẠ TẦNG VIỆT NAM (VNINFRA_) ──────────────────────────
		{"VNINFRA_HIGHWAY",   3, `label=cao tốc Việt Nam|desc=mạng lưới cao tốc 2000 km Bắc-Nam Hà Nội TP.HCM kết nối kinh tế phát triển hạ tầng 2030|vi=cao tốc Việt Nam,đường cao tốc|en=Vietnam highway|zh=越南高速公路`},
		{"VNINFRA_METRO",     3, `label=tàu điện ngầm Việt Nam|desc=metro Hà Nội Nhổn-ga Hà Nội Bến Thành-Suối Tiên TP.HCM kẹt xe đô thị hóa|vi=metro Việt Nam,tàu điện ngầm|en=Vietnam metro|zh=越南地铁`},

		// ── CHÍNH TRỊ / QUAN HỆ QUỐC TẾ (POLINT_) ───────────────
		{"POLINT_UN",         3, `label=Liên Hợp Quốc|desc=tổ chức quốc tế lớn nhất 193 thành viên hòa bình an ninh phát triển SDG New York|vi=Liên Hợp Quốc,LHQ,UN|en=United Nations,UN|zh=联合国`},
		{"POLINT_NATO",       3, `label=NATO|desc=Tổ chức Hiệp ước Bắc Đại Tây Dương 32 thành viên quốc phòng tập thể Điều 5 mở rộng phía Đông|vi=NATO,Tổ chức Bắc Đại Tây Dương|en=NATO|zh=北约`},
		{"POLINT_DEMOCRACY",  3, `label=dân chủ|desc=chính thể nhân dân cai trị bầu cử tự do pháp quyền phân quyền Tocqueville|vi=dân chủ,democracy|en=democracy|zh=民主制度`},
		{"POLINT_HUMAN_RIGHTS",3,`label=nhân quyền|desc=quyền cơ bản bất khả xâm phạm UDHR 1948 dân sự chính trị kinh tế văn hóa|vi=nhân quyền,human rights|en=human rights|zh=人权`},

		// ── KINH TẾ HỌC LÝ THUYẾT (ECON_THEORY_) ────────────────
		{"ECON_THEORY_KEYNESIAN",3,`label=kinh tế học Keynes|desc=Keynes vai trò chính phủ kích thích tổng cầu chi tiêu công đầu tư thất nghiệp|vi=kinh tế học Keynes,Keynesian|en=Keynesian economics|zh=凯恩斯经济学`},
		{"ECON_THEORY_HAYEK",  3, `label=kinh tế học tự do|desc=Hayek Friedman thị trường tự do ít can thiệp nhà nước giá cả thông tin phân tán|vi=kinh tế học tự do,tự do thị trường|en=free market economics|zh=自由市场经济学`},
		{"ECON_THEORY_SUPPLY", 3, `label=kinh tế học cung|desc=supply-side economics giảm thuế cho người giàu kích thích đầu tư Reagan trickle-down|vi=kinh tế học cung|en=supply-side economics|zh=供给侧经济学`},

		// ── KHOA HỌC THẦN KINH (NEURO_) ──────────────────────────
		{"NEURO_BRAIN",       3, `label=não bộ|desc=cơ quan điều khiển trung ương 86 tỷ tế bào thần kinh vỏ não thùy trán thùy thái dương|vi=não bộ,brain|en=brain|zh=大脑`},
		{"NEURO_SYNAPSE",     3, `label=synapse|desc=khớp thần kinh điểm kết nối nơron chất dẫn truyền thần kinh serotonin dopamine học hỏi|vi=synapse,khớp thần kinh|en=synapse|zh=突触`},
		{"NEURO_NEUROPLAST",  3, `label=tính dẻo thần kinh|desc=khả năng não thay đổi cấu trúc chức năng học tập phục hồi sau tổn thương|vi=tính dẻo thần kinh,neuroplasticity|en=neuroplasticity|zh=神经可塑性`},
		{"NEURO_CONSCIOUSNESS",3,`label=ý thức|desc=trạng thái nhận biết chủ quan hard problem of consciousness Chalmers Tononi IIT Global Workspace|vi=ý thức,consciousness|en=consciousness|zh=意识`},

		// ── SINH THÁI HỌC BỔ SUNG (ECO2_) ───────────────────────
		{"ECO2_ECOSYSTEM",    3, `label=hệ sinh thái|desc=cộng đồng sinh vật và môi trường vô sinh tương tác dòng năng lượng chu trình dinh dưỡng|vi=hệ sinh thái,ecosystem|en=ecosystem|zh=生态系统`},
		{"ECO2_FOOD_WEB",     3, `label=mạng lưới thức ăn|desc=quan hệ ăn thịt chuỗi thức ăn sản xuất tiêu thụ phân hủy năng lượng 10%|vi=mạng lưới thức ăn,food web|en=food web|zh=食物网`},
		{"ECO2_BIODIVERSITY", 3, `label=đa dạng sinh học|desc=sự phong phú loài gen hệ sinh thái IUCN sách đỏ tuyệt chủng bảo tồn|vi=đa dạng sinh học,biodiversity|en=biodiversity|zh=生物多样性`},
		{"ECO2_INVASIVE",     3, `label=loài xâm lấn|desc=sinh vật ngoại lai phá vỡ hệ sinh thái bản địa ốc bươu vàng rùa tai đỏ ếch phi|vi=loài xâm lấn,invasive species|en=invasive species|zh=入侵物种`},

		// ── VẬT LÝ ỨNG DỤNG (APPPHYS_) ───────────────────────────
		{"APPPHYS_SEMICOND",  3, `label=chất bán dẫn|desc=vật liệu dẫn điện trung bình silicon germanium transistor chip TSMC Intel điện tử|vi=chất bán dẫn,semiconductor|en=semiconductor|zh=半导体`},
		{"APPPHYS_LED",       3, `label=LED|desc=điốt phát quang hiệu suất cao tiết kiệm điện ánh sáng xanh Nobel 2014 màn hình chiếu sáng|vi=LED,đèn LED|en=LED|zh=LED`},
		{"APPPHYS_MRI",       3, `label=MRI|desc=cộng hưởng từ y tế chẩn đoán não tim tủy sống không phóng xạ trường từ 1.5-3 Tesla|vi=MRI,cộng hưởng từ|en=MRI|zh=磁共振成像`},

		// ── KHOA HỌC MÁY TÍNH LÝ THUYẾT (CS_THEORY_) ────────────
		{"CS_THEORY_TURING",  3, `label=máy Turing|desc=mô hình tính toán lý thuyết Alan Turing băng vô hạn trạng thái decidable undecidable|vi=máy Turing,Turing machine|en=Turing machine|zh=图灵机`},
		{"CS_THEORY_NP",      3, `label=P vs NP|desc=bài toán mở lớn nhất CS P NP NP-complete SAT Halting Problem Clay Millennium|vi=P vs NP,NP-complete|en=P vs NP|zh=P对NP问题`},
		{"CS_THEORY_CRYPTO",  3, `label=mật mã học|desc=RSA AES elliptic curve public key private key hash SHA-256 quantum-safe|vi=mật mã học,cryptography|en=cryptography|zh=密码学`},

		// ── THIÊN VĂN HỆ MẶT TRỜI (SOLAR_) ──────────────────────
		{"SOLAR_MARS",        3, `label=Sao Hỏa|desc=hành tinh thứ 4 Hệ Mặt Trời khí quyển mỏng CO2 Olympus Mons Perseverance SpaceX|vi=Sao Hỏa,Mars|en=Mars|zh=火星`},
		{"SOLAR_JUPITER",     3, `label=Sao Mộc|desc=hành tinh lớn nhất Hệ Mặt Trời khí khổng lồ Great Red Spot 95 mặt trăng Europa|vi=Sao Mộc,Jupiter|en=Jupiter|zh=木星`},
		{"SOLAR_MOON",        3, `label=Mặt Trăng|desc=vệ tinh tự nhiên duy nhất Trái Đất Apollo 11 1969 thủy triều chu kỳ 29.5 ngày|vi=Mặt Trăng,Moon|en=Moon|zh=月球`},
		{"SOLAR_SUN",         3, `label=Mặt Trời|desc=ngôi sao trung tâm Hệ Mặt Trời 99.86% khối lượng tổng hợp hạt nhân hydro helium|vi=Mặt Trời,Sun|en=Sun|zh=太阳`},
		{"SOLAR_ASTEROID",    3, `label=tiểu hành tinh|desc=thiên thể đá kim loại nhỏ hơn hành tinh vành đai giữa Sao Hỏa Sao Mộc Apophis|vi=tiểu hành tinh,asteroid|en=asteroid|zh=小行星`},

		// ── ĐỊA LÝ VẬT LÝ (PHYSGEO_) ─────────────────────────────
		{"PHYSGEO_VOLCANO",   3, `label=núi lửa|desc=lỗ hở trên bề mặt Trái Đất phun dung nham tro bụi Krakatoa Vesuvius Pacific Ring of Fire|vi=núi lửa,volcano|en=volcano|zh=火山`},
		{"PHYSGEO_TSUNAMI",   3, `label=sóng thần|desc=sóng biển khổng lồ do địa chấn dưới đại dương 2004 Indian Ocean 2011 Nhật Bản hệ thống cảnh báo|vi=sóng thần,tsunami|en=tsunami|zh=海啸`},
		{"PHYSGEO_DESERT",    3, `label=sa mạc|desc=vùng khô hạn <250mm mưa/năm Sahara Gobi Arabian lạc đà xương rồng nóng lạnh|vi=sa mạc,desert|en=desert|zh=沙漠`},
		{"PHYSGEO_AMAZON",    3, `label=rừng Amazon|desc=rừng mưa nhiệt đới lớn nhất 10% loài trên cạn Brazil Peru Colombia phá rừng|vi=rừng Amazon,Amazon|en=Amazon rainforest|zh=亚马逊雨林`},

		// ── PHÁT TRIỂN BỀN VỮNG (SDG_) ───────────────────────────
		{"SDG_GOALS",         3, `label=SDG 17 mục tiêu|desc=Sustainable Development Goals 17 mục tiêu LHQ 2030 xóa đói giảm nghèo y tế giáo dục|vi=SDG,17 mục tiêu phát triển bền vững|en=SDG,Sustainable Development Goals|zh=可持续发展目标`},
		{"SDG_POVERTY",       3, `label=xóa đói giảm nghèo|desc=giảm nghèo cực đoan <1.9 USD/ngày 700 triệu người còn nghèo Châu Phi Nam Á|vi=xóa đói giảm nghèo,poverty|en=poverty reduction|zh=消除贫困`},
		{"SDG_CLEAN_WATER",   3, `label=nước sạch|desc=SDG 6 tiếp cận nước uống an toàn 2 tỷ người thiếu vệ sinh môi trường|vi=nước sạch,clean water|en=clean water|zh=清洁水`},
		{"SDG_EDUCATION2",    3, `label=giáo dục toàn cầu|desc=SDG 4 giáo dục chất lượng toàn diện công bằng học tập suốt đời literacy|vi=giáo dục toàn cầu,education for all|en=education for all|zh=全球教育`},

		// ── KHOA HỌC VŨ TRỤ (SPACE3_) ────────────────────────────
		{"SPACE3_ISS",        3, `label=Trạm vũ trụ quốc tế|desc=ISS station trên quỹ đạo thấp 400km NASA Roscosmos nghiên cứu vi trọng lực 1998|vi=ISS,Trạm vũ trụ quốc tế|en=ISS,International Space Station|zh=国际空间站`},
		{"SPACE3_JWST",       3, `label=Kính viễn vọng James Webb|desc=JWST infrared vũ trụ sâu thiên hà đầu tiên ngoại hành tinh 2022 phóng Lagrange L2|vi=James Webb,JWST,kính viễn vọng|en=James Webb Space Telescope,JWST|zh=詹姆斯韦伯空间望远镜`},
		{"SPACE3_SPACEX",     3, `label=SpaceX|desc=công ty vũ trụ tư nhân Elon Musk Falcon 9 tái sử dụng Starship Dragon ISS Mars 2024|vi=SpaceX|en=SpaceX|zh=太空探索技术公司`},

		// ── NGHỆ THUẬT THẾ GIỚI (ARTWORLD_) ──────────────────────
		{"ARTWORLD_LOUVRE",   3, `label=bảo tàng Louvre|desc=bảo tàng lớn nhất thế giới Paris Mona Lisa Venus de Milo kim tự tháp kính|vi=Louvre,bảo tàng Louvre|en=Louvre museum|zh=卢浮宫`},
		{"ARTWORLD_MONA",     3, `label=Mona Lisa|desc=kiệt tác Leonardo da Vinci dầu trên gỗ 1503-1519 nụ cười bí ẩn Louvre Paris|vi=Mona Lisa,nàng Mona Lisa|en=Mona Lisa|zh=蒙娜丽莎`},
		{"ARTWORLD_PICASSO",  3, `label=Picasso|desc=họa sĩ Tây Ban Nha lập thể Guernica Les Demoiselles d'Avignon nghệ thuật hiện đại|vi=Picasso,Pablo Picasso|en=Picasso|zh=毕加索`},

		// ── VĂN HỌC THẾ GIỚI (LIT2_) ─────────────────────────────
		{"LIT2_SHAKESPEARE",  3, `label=Shakespeare|desc=nhà thơ kịch tác gia Anh Hamlet Romeo Juliet Macbeth King Lear ngôn ngữ Anh|vi=Shakespeare,William Shakespeare|en=Shakespeare|zh=莎士比亚`},
		{"LIT2_DOSTOEVSKY",   3, `label=Dostoevsky|desc=nhà văn Nga Crime and Punishment The Brothers Karamazov tâm lý nhân vật|vi=Dostoevsky,Dostoyevsky|en=Dostoevsky|zh=陀思妥耶夫斯基`},
		{"LIT2_MARQUEZ",      3, `label=García Márquez|desc=nhà văn Colombia Trăm Năm Cô Đơn chủ nghĩa hiện thực huyền ảo Nobel 1982|vi=García Márquez,Trăm Năm Cô Đơn|en=Garcia Marquez|zh=加西亚·马尔克斯`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"VNENERGY_SOLAR_VN", "VNECON_EXPORT",      "contributes-to"},
		{"VNAGR_COFFEE",      "VNTRAVEL_HCMC",      "sold-in"},
		{"VNAGR_RICE",        "VNENV_MEKONG",       "grown-in"},
		{"POLINT_UN",         "SDG_GOALS",          "created"},
		{"SDG_POVERTY",       "SDG_GOALS",          "part-of"},
		{"SDG_CLEAN_WATER",   "ENV2_WATER",         "addresses"},
		{"NEURO_BRAIN",       "NEURO_SYNAPSE",      "contains"},
		{"NEURO_SYNAPSE",     "NEURO_NEUROPLAST",   "enables"},
		{"NEURO_CONSCIOUSNESS","NEURO_BRAIN",       "emerges-from"},
		{"ECO2_BIODIVERSITY", "ECO2_ECOSYSTEM",     "indicator-of"},
		{"ECO2_INVASIVE",     "ECO2_BIODIVERSITY",  "threatens"},
		{"APPPHYS_SEMICOND",  "CS_ALGORITHM",       "implements"},
		{"CS_THEORY_TURING",  "CS_ALGORITHM",       "formalizes"},
		{"CS_THEORY_CRYPTO",  "CS_SECURITY",        "foundation-of"},
		{"SOLAR_MARS",        "FUTURE_SPACE_COL",   "target-of"},
		{"SOLAR_SUN",         "NRG_GEOTHERMAL",     "source-of"},
		{"SPACE3_JWST",       "ASTRO3_EXOPLANET",   "observes"},
		{"SPACE3_SPACEX",     "FUTURE_SPACE_COL",   "enables"},
		{"LIT2_SHAKESPEARE",  "LIT_NOVEL",          "master-of"},
		{"ARTWORLD_MONA",     "ARTWORLD_LOUVRE",    "displayed-in"},
		{"ECON_THEORY_KEYNESIAN","WORLD_INDUSTRIAL","emerged-from"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2600 { fmt.Println("🎉 MILESTONE 2600!") }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'; rec[1] = 'D'; rec[2] = layer; copy(rec[3:], islv[:])
	rec[15] = byte(len(dna) >> 24); rec[16] = byte(len(dna) >> 16)
	rec[17] = byte(len(dna) >> 8); rec[18] = byte(len(dna)); rec[19] = uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0] = layer; v[1] = h[0]%200 + 1; v[2] = h[1]%200 + 1; v[3] = h[2]%200 + 1
	v[4] = h[3]; v[5] = h[4]; v[6] = h[5]; v[7] = h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16]) + 1
	out[12] = byte(n >> 24); out[13] = byte(n >> 16); out[14] = byte(n >> 8); out[15] = byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl; if ne2 > end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])] = v; i = ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20]) + 1
	raw[16] = byte(n >> 24); raw[17] = byte(n >> 16); raw[18] = byte(n >> 8); raw[19] = byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"contributes-to": 1, "sold-in": 2, "grown-in": 3, "created": 4, "part-of": 5,
		"addresses": 6, "contains": 7, "enables": 8, "emerges-from": 9, "indicator-of": 10,
		"threatens": 11, "implements": 12, "formalizes": 13, "foundation-of": 14,
		"target-of": 15, "source-of": 16, "observes": 17, "master-of": 18,
		"displayed-in": 19, "emerged-from": 20,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl; if ne2 > end { break }
		m[string(raw[i+20+dl:ne2])] = true; i = ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
