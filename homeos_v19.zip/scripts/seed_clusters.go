//go:build ignore
// seed_clusters.go — Thêm overview hub nodes + cluster edges trong 1 lần
// Đảm bảo file structure nhất quán (nodes → edges)
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const clusterFile = "homeos.olang"
const liEndC = 64 + 9*24

// Edge op types
const (
	OpMem  = uint8(1) // member of
	OpEq   = uint8(2) // equivalent
	OpComp = uint8(4) // composes
	OpSim  = uint8(5) // similar
	OpOpp  = uint8(3) // opposite
)

// encodeNode: ND+layer+isl(8)+flags(4)+dnaLen(4)+nameLen(1)+dna+name
func encodeNode(name string, layer uint8, dna string) []byte {
	nb := []byte(name)
	db := []byte(dna)
	buf := make([]byte, 2+1+8+4+4+1+len(db)+len(nb))
	buf[0], buf[1] = 'N', 'D'
	buf[2] = layer
	h := sha256.Sum256(nb)
	copy(buf[3:11], h[:8])                                              // isl
	binary.BigEndian.PutUint32(buf[11:15], 0)                           // flags
	binary.BigEndian.PutUint32(buf[15:19], uint32(len(db)))             // dnaLen
	buf[19] = byte(len(nb))                                             // nameLen
	copy(buf[20:], db)
	copy(buf[20+len(db):], nb)
	return buf
}

// islOf: sha256(name)[:8] → uint64
func islOf(name string) uint64 {
	h := sha256.Sum256([]byte(name))
	return binary.BigEndian.Uint64(h[:8])
}

// encodeEdge: fromISLU(8)+toISLU(8)+type(1) = 17 bytes
func encodeEdge(from, to string, eType uint8) [17]byte {
	var e [17]byte
	binary.BigEndian.PutUint64(e[:8], islOf(from))
	binary.BigEndian.PutUint64(e[8:16], islOf(to))
	e[16] = eType
	return e
}

func main() {
	raw, err := os.ReadFile(clusterFile)
	if err != nil { log.Fatal(err) }

	// Tách node section và edge section
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	ncount := int(binary.BigEndian.Uint32(raw[12:16]))
	edgeStart := len(raw) - nedges*17
	nodeSection := append([]byte{}, raw[:edgeStart]...)
	edgeSection := append([]byte{}, raw[edgeStart:]...)

	fmt.Printf("▶ before: %d nodes, %d edges\n", ncount, nedges)

	// ── 1. Thêm overview hub nodes ────────────────────────────────────────
	type NodeDef struct{ name string; layer uint8; dna string }
	newNodes := []NodeDef{
		{"PHIL_OVERVIEW", 3, `label=triết học|desc=philosophy metaphysics epistemology ethics logic mind consciousness Aristotle Plato Kant Hegel Descartes|vi=triết học|en=philosophy`},
		{"PHYS_OVERVIEW",  3, `label=vật lý học|desc=physics mechanics thermodynamics electromagnetism quantum relativity Newton Einstein Bohr Feynman|vi=vật lý học|en=physics`},
		{"HIST_OVERVIEW",  3, `label=lịch sử|desc=history civilization empire revolution culture trade war democracy Homo sapiens ancient medieval modern|vi=lịch sử|en=history`},
		{"ECON_OVERVIEW",  3, `label=kinh tế học|desc=economics market supply demand GDP inflation currency investment bank trade Smith Keynes Friedman|vi=kinh tế học|en=economics`},
		{"LANG_OVERVIEW",  3, `label=ngôn ngữ học|desc=linguistics language phoneme morpheme syntax semantics pragmatics Chomsky Saussure communication|vi=ngôn ngữ học|en=linguistics`},
		{"SPORT_OVERVIEW", 3, `label=thể thao|desc=sports athletics football basketball swimming running fitness competition Olympic training|vi=thể thao|en=sports`},
		{"MED_OVERVIEW",   3, `label=y học|desc=medicine health disease treatment diagnosis heart brain blood immune surgery pharmacology|vi=y học|en=medicine`},
		{"ASTRO_OVERVIEW", 3, `label=thiên văn học|desc=astronomy universe galaxy star planet solar system Big Bang dark matter cosmology telescope|vi=thiên văn học|en=astronomy`},
		{"NATURE_OVERVIEW",3, `label=tự nhiên|desc=nature physics chemistry biology ecology space time energy matter forces natural phenomena|vi=tự nhiên|en=nature`},
	}

	existingISL := buildISLSet(raw[:edgeStart])
	addedNodes := 0
	for _, nd := range newNodes {
		isl := islOf(nd.name)
		if existingISL[isl] { continue } // skip duplicate
		nodeSection = append(nodeSection, encodeNode(nd.name, nd.layer, nd.dna)...)
		ncount++
		addedNodes++
		fmt.Printf("  + node %s\n", nd.name)
	}

	// ── 2. Định nghĩa tất cả edges cần thêm ──────────────────────────────
	type EdgeDef struct{ from, to string; t uint8 }
	newEdges := []EdgeDef{
		// NATURE cluster
		{"NATURE_LIGHT",      "NATURE_HEAT",         OpSim},
		{"NATURE_HEAT",       "NATURE_TEMPERATURE",   OpEq},
		{"NATURE_GRAVITY",    "NATURE_SPACE",         OpComp},
		{"NATURE_WATER",      "NATURE_RAIN",          OpMem},
		{"NATURE_WIND",       "NATURE_EARTH",         OpComp},
		{"NATURE_ELECTRICITY","NATURE_MAGNETISM",     OpSim},
		{"NATURE_FIRE",       "NATURE_HEAT",          OpComp},
		{"NATURE_COLD",       "NATURE_TEMPERATURE",   OpOpp},
		{"NATURE_PRESSURE",   "NATURE_GRAVITY",       OpComp},
		{"NATURE_OVERVIEW",   "NATURE_GRAVITY",       OpMem},
		{"NATURE_OVERVIEW",   "NATURE_LIGHT",         OpMem},
		{"NATURE_OVERVIEW",   "NATURE_WATER",         OpMem},
		{"NATURE_OVERVIEW",   "NATURE_EARTH",         OpMem},
		{"NATURE_OVERVIEW",   "PHYS_OVERVIEW",        OpSim},

		// PHYS cluster
		{"PHYS_FORCE",       "PHYS_MASS",            OpComp},
		{"PHYS_FORCE",       "PHYS_ACCELERATION",    OpComp},
		{"PHYS_VELOCITY",    "PHYS_ACCELERATION",    OpComp},
		{"PHYS_MOMENTUM",    "PHYS_MASS",            OpComp},
		{"PHYS_MOMENTUM",    "PHYS_VELOCITY",        OpComp},
		{"PHYS_GRAVITY",     "PHYS_FORCE",           OpMem},
		{"PHYS_FRICTION",    "PHYS_FORCE",           OpMem},
		{"PHYS_TEMPERATURE", "PHYS_HEAT",            OpEq},
		{"PHYS_ENTROPY",     "PHYS_THERMODYNAMICS",  OpComp},
		{"PHYS_HEAT",        "PHYS_THERMODYNAMICS",  OpComp},
		{"PHYS_GRAVITY",     "NATURE_GRAVITY",       OpEq},
		{"PHYS_HEAT",        "NATURE_HEAT",          OpEq},
		{"PHYS_OVERVIEW",    "PHYS_FORCE",           OpMem},
		{"PHYS_OVERVIEW",    "PHYS_THERMODYNAMICS",  OpMem},
		{"PHYS_OVERVIEW",    "PHYS_GRAVITY",         OpMem},
		{"PHYS_OVERVIEW",    "NATURE_GRAVITY",       OpMem},

		// ASTRO cluster
		{"ASTRO_UNIVERSE",   "ASTRO_GALAXY",         OpMem},
		{"ASTRO_GALAXY",     "ASTRO_STAR",           OpMem},
		{"ASTRO_STAR",       "ASTRO_PLANET",         OpMem},
		{"ASTRO_SUN",        "ASTRO_STAR",           OpMem},
		{"ASTRO_MOON",       "ASTRO_PLANET",         OpSim},
		{"ASTRO_BLACKHOLE",  "ASTRO_STAR",           OpMem},
		{"ASTRO_BIGBANG",    "ASTRO_UNIVERSE",       OpComp},
		{"ASTROPHYS_CMB",    "ASTRO_BIGBANG",        OpComp},
		{"ASTRO_UNIVERSE",   "PHYS_GRAVITY",         OpComp},
		{"ASTRO_OVERVIEW",   "ASTRO_UNIVERSE",       OpMem},
		{"ASTRO_OVERVIEW",   "ASTRO_GALAXY",         OpMem},
		{"ASTRO_OVERVIEW",   "ASTRO_STAR",           OpMem},
		{"ASTRO_OVERVIEW",   "ASTRO_BLACKHOLE",      OpMem},
		{"ASTRO_UNIVERSE",   "ASTRO_OVERVIEW",       OpMem},

		// ECON cluster
		{"ECON_GDP",         "ECON_MARKET",          OpComp},
		{"ECON_INFLATION",   "ECON_CURRENCY",        OpComp},
		{"ECON_SUPPLY",      "ECON_DEMAND",          OpOpp},
		{"ECON_DEMAND",      "ECON_MARKET",          OpComp},
		{"ECON_SUPPLY",      "ECON_MARKET",          OpComp},
		{"ECON_INVESTMENT",  "ECON_BANK",            OpComp},
		{"ECON_INTEREST",    "ECON_BANK",            OpComp},
		{"ECON_INTEREST",    "ECON_INFLATION",       OpSim},
		{"ECON_TAX",         "ECON_GDP",             OpComp},
		{"ECON_POVERTY",     "ECON_GDP",             OpOpp},
		{"ECON_CURRENCY",    "ECON_MARKET",          OpComp},
		{"ECON_OVERVIEW",    "ECON_GDP",             OpMem},
		{"ECON_OVERVIEW",    "ECON_MARKET",          OpMem},
		{"ECON_OVERVIEW",    "ECON_INFLATION",       OpMem},
		{"ECON_OVERVIEW",    "ECON_CURRENCY",        OpMem},
		{"ECON_GDP",         "ECON_OVERVIEW",        OpMem},

		// LANG cluster
		{"LANG_PHONEME",     "LANG_SYLLABLE",        OpComp},
		{"LANG_SYLLABLE",    "LANG_WORD",            OpComp},
		{"LANG_MORPHEME",    "LANG_WORD",            OpComp},
		{"LANG_WORD",        "LANG_PHRASE",          OpComp},
		{"LANG_PHRASE",      "LANG_CLAUSE",          OpComp},
		{"LANG_CLAUSE",      "LANG_SENTENCE",        OpComp},
		{"LANG_SENTENCE",    "LANG_PARAGRAPH",       OpComp},
		{"LANG_PARAGRAPH",   "LANG_DISCOURSE",       OpComp},
		{"LANG_LINGUISTICS", "LANG_LANGUAGE",        OpComp},
		{"LANG_COMMUNICATION","LANG_LANGUAGE",       OpComp},
		{"LANG_LANGUAGE",    "APPLLING_NLP",         OpSim},
		{"LANG_OVERVIEW",    "LANG_LANGUAGE",        OpMem},
		{"LANG_OVERVIEW",    "LANG_LINGUISTICS",     OpMem},
		{"LANG_OVERVIEW",    "LANG_PHONEME",         OpMem},
		{"LANG_LANGUAGE",    "LANG_OVERVIEW",        OpMem},

		// PHIL cluster
		{"PHIL_LOGIC",       "PHIL_ARGUMENT",        OpComp},
		{"PHIL_ETHICS",      "PHIL_FREEDOM",         OpComp},
		{"PHIL_EPISTEM",     "PHIL_TRUTH",           OpComp},
		{"PHIL_METAPHYS",    "PHIL_CONSCIOUSNESS",   OpComp},
		{"PHIL_MIND",        "PHIL_CONSCIOUSNESS",   OpEq},
		{"PHIL_LOGIC",       "PHIL_TRUTH",           OpComp},
		{"PHIL_SCIENCE",     "PHIL_TRUTH",           OpComp},
		{"PHIL_ETHICS",      "AI2_ETHICS",           OpSim},
		{"PHIL_CONSCIOUSNESS","COGNITIVE_NEURO_CON", OpSim},
		{"PHIL_CONSCIOUSNESS","COGSCI_CONSCIOUSNESS", OpEq},
		{"PHIL_OVERVIEW",    "PHIL_LOGIC",           OpMem},
		{"PHIL_OVERVIEW",    "PHIL_ETHICS",          OpMem},
		{"PHIL_OVERVIEW",    "PHIL_EPISTEM",         OpMem},
		{"PHIL_OVERVIEW",    "PHIL_METAPHYS",        OpMem},
		{"PHIL_OVERVIEW",    "PHIL_MIND",            OpMem},
		{"PHIL_OVERVIEW",    "PHIL_CONSCIOUSNESS",   OpMem},
		{"PHIL_OVERVIEW",    "PHIL_TRUTH",           OpMem},
		{"PHIL_LOGIC",       "PHIL_OVERVIEW",        OpMem},

		// MED cluster
		{"MED_HEART",        "MED_BLOOD",            OpComp},
		{"MED_LUNG",         "MED_BLOOD",            OpComp},
		{"MED_BRAIN",        "MED_NERVE",            OpComp},
		{"MED_NERVE",        "NEURO_BRAIN",          OpSim},
		{"MED_IMMUNE",       "MED_BLOOD",            OpComp},
		{"MED_BONE",         "MED_MUSCLE",           OpComp},
		{"MEDIC2_CARDIO",    "MED_HEART",            OpComp},
		{"MEDIC2_NEURO",     "MED_BRAIN",            OpComp},
		{"MEDIC2_NEURO",     "NEURO_BRAIN",          OpSim},
		{"MED_OVERVIEW",     "MED_HEART",            OpMem},
		{"MED_OVERVIEW",     "MED_BRAIN",            OpMem},
		{"MED_OVERVIEW",     "MED_BLOOD",            OpMem},
		{"MED_OVERVIEW",     "MEDIC2_CARDIO",        OpMem},
		{"MED_OVERVIEW",     "MEDIC2_NEURO",         OpMem},
		{"MED_BRAIN",        "MED_OVERVIEW",         OpMem},

		// HIST cluster
		{"HIST_CIVILIZATION","HIST_CULTURE",         OpComp},
		{"HIST_REVOLUTION",  "HIST_DEMOCRACY",       OpComp},
		{"HIST_EMPIRE",      "HIST_WAR",             OpComp},
		{"HIST_TRADE",       "ECON_MARKET",          OpSim},
		{"HIST_OVERVIEW",    "HIST_CIVILIZATION",    OpMem},
		{"HIST_OVERVIEW",    "HIST_REVOLUTION",      OpMem},
		{"HIST_OVERVIEW",    "HIST_DEMOCRACY",       OpMem},
		{"HIST_OVERVIEW",    "HIST_CULTURE",         OpMem},
		{"HIST_CIVILIZATION","HIST_OVERVIEW",        OpMem},

		// SOC cluster
		{"SOC_DEMOCRACY",    "SOC_HUMAN_RIGHTS",     OpComp},
		{"SOC_POVERTY",      "ECON_POVERTY",         OpEq},
		{"SOC_URBANIZATION", "ECON_GDP",             OpComp},
		{"SOC_SOCIAL_MEDIA", "LANG_COMMUNICATION",   OpComp},
		{"SOC_GENDER",       "SOC_HUMAN_RIGHTS",     OpComp},

		// SPORT cluster
		{"SPORT_FOOTBALL",   "SPORT_BASKETBALL",     OpSim},
		{"SPORT_SWIMMING",   "SPORT_RUNNING",        OpSim},
		{"SPORT_YOGA",       "SPORT_RUNNING",        OpSim},
		{"SPORT_TENNIS",     "SPORT_FOOTBALL",       OpSim},
		{"SPORT_CYCLING",    "SPORT_RUNNING",        OpSim},
		{"SPORTS2_SCIENCE",  "SPORT_RUNNING",        OpComp},
		{"SPORTS2_ANALYTICS","TECH_ML",              OpComp},
		{"SPORT_OVERVIEW",   "SPORT_FOOTBALL",       OpMem},
		{"SPORT_OVERVIEW",   "SPORT_BASKETBALL",     OpMem},
		{"SPORT_OVERVIEW",   "SPORT_RUNNING",        OpMem},
		{"SPORT_OVERVIEW",   "SPORTS2_SCIENCE",      OpMem},

		// Memory cluster linkage
		{"BRAINAREA_HIPPOC", "PSY2_MEMORY",          OpComp},
		{"BRAINAREA_HIPPOC", "PSY_MEMORY",           OpComp},
		{"COGNEURO_MEMORY",  "PSY2_MEMORY",          OpEq},
		{"NEUROSCI_MEMORY",  "PSY_MEMORY",           OpEq},
		{"AI_MEMORY_ARCH",   "TECH_ML",              OpComp},
		{"AI_MEMORY_ARCH",   "AI2_LLM",              OpComp},

		// Cross-domain bridges
		{"ECON_MARKET",      "STATS2_BAYES",         OpComp},
		{"LANG_LINGUISTICS", "AI2_NLP",              OpSim},
		{"MED_BRAIN",        "AI2_TRANSFORMER",      OpSim},
		{"SOC_SOCIAL_MEDIA", "SOCIALMEDIA2_ALGO",    OpComp},
		{"PHYS_OVERVIEW",    "ASTRO_OVERVIEW",       OpSim},
		{"HIST_OVERVIEW",    "SOC_DEMOCRACY",        OpComp},
		{"LANG_OVERVIEW",    "AI2_NLP",              OpSim},
		{"MED_OVERVIEW",     "NEURO_BRAIN",          OpSim},
	}

	// Build ISL lookup từ existing nodes (bao gồm nodes mới vừa thêm)
	islLookup := buildISLMapFromSection(nodeSection)

	// Filter edges — chỉ thêm nếu cả 2 nodes tồn tại
	var newEdgeBytes []byte
	addedEdges := 0
	skippedEdges := 0
	for _, e := range newEdges {
		fromU := islOf(e.from)
		toU   := islOf(e.to)
		if _, ok := islLookup[fromU]; !ok { skippedEdges++; continue }
		if _, ok := islLookup[toU];   !ok { skippedEdges++; continue }
		eb := encodeEdge(e.from, e.to, e.t)
		newEdgeBytes = append(newEdgeBytes, eb[:]...)
		addedEdges++
	}

	// Rebuild file: nodeSection + newEdges + oldEdges
	newRaw := append(nodeSection, newEdgeBytes...)
	newRaw = append(newRaw, edgeSection...)
	newNedges := nedges + addedEdges
	binary.BigEndian.PutUint32(newRaw[12:16], uint32(ncount))
	binary.BigEndian.PutUint32(newRaw[16:20], uint32(newNedges))
	h := sha256.Sum256(newRaw[liEndC:])
	copy(newRaw[32:64], h[:])

	if err := os.WriteFile(clusterFile, newRaw, 0644); err != nil {
		log.Fatal(err)
	}
	fmt.Printf("✅ nodes: +%d → %d\n", addedNodes, ncount)
	fmt.Printf("✅ edges: +%d → %d (%d skipped)\n", addedEdges, newNedges, skippedEdges)
}

// buildISLSet trả về set các ISLU đã có trong node section
func buildISLSet(nodeSection []byte) map[uint64]bool {
	result := map[uint64]bool{}
	for off := 0; off+20 < len(nodeSection); {
		if nodeSection[off] != 'N' || nodeSection[off+1] != 'D' { off++; continue }
		base := off; off += 2
		off++ // layer
		islu := binary.BigEndian.Uint64(nodeSection[off : off+8]); off += 8
		off += 4
		dl := int(binary.BigEndian.Uint32(nodeSection[off : off+4])); off += 4
		nl := int(nodeSection[off]); off++
		end := off + dl + nl
		if dl > 4096 || nl > 200 || end > len(nodeSection) { off = base + 1; continue }
		result[islu] = true
		off = end
	}
	return result
}

// buildISLMapFromSection trả về map ISLU→name từ node section
func buildISLMapFromSection(nodeSection []byte) map[uint64]string {
	result := map[uint64]string{}
	for off := 0; off+20 < len(nodeSection); {
		if nodeSection[off] != 'N' || nodeSection[off+1] != 'D' { off++; continue }
		base := off; off += 2
		off++ // layer
		islu := binary.BigEndian.Uint64(nodeSection[off : off+8]); off += 8
		off += 4
		dl := int(binary.BigEndian.Uint32(nodeSection[off : off+4])); off += 4
		nl := int(nodeSection[off]); off++
		end := off + dl + nl
		if dl > 4096 || nl > 200 || end > len(nodeSection) { off = base + 1; continue }
		name := string(nodeSection[off+dl : end])
		result[islu] = name
		off = end
	}
	return result
}
