//go:build ignore
// go run scripts/seed_milestone2600b.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── CÔNG NGHỆ VIỆT NAM (VNTECH_) ──────────────────────────
		{"VNTECH_VIETTEL",    3, `label=Viettel|desc=tập đoàn viễn thông quân đội lớn nhất Việt Nam 5G quốc phòng công nghệ 11 quốc gia|vi=Viettel,tập đoàn Viettel|en=Viettel|zh=越捷电信`},
		{"VNTECH_VNPT",       3, `label=VNPT|desc=tổng công ty bưu chính viễn thông Việt Nam internet cáp quang hạ tầng số hóa|vi=VNPT|en=VNPT|zh=越南邮政电信`},
		{"VNTECH_FPT",        3, `label=FPT|desc=tập đoàn công nghệ phần mềm Việt Nam FPT Software outsourcing AI giáo dục đại học|vi=FPT,FPT Software|en=FPT|zh=FPT集团`},
		{"VNTECH_VINGROUP",   3, `label=VinGroup|desc=tập đoàn tư nhân lớn nhất Việt Nam VinFast xe điện VinSmart VinSchool bất động sản|vi=VinGroup,VinFast|en=VinGroup,VinFast|zh=Vingroup集团`},
		{"VNTECH_MOMO",       3, `label=MoMo|desc=ví điện tử lớn nhất Việt Nam thanh toán di động fintech unicorn siêu ứng dụng|vi=MoMo,ví điện tử|en=MoMo|zh=MoMo电子钱包`},

		// ── LỊCH SỬ CHÂU Á (ASIAHIST_) ────────────────────────────
		{"ASIAHIST_MEIJI",    3, `label=Minh Trị Duy Tân|desc=cải cách Nhật Bản 1868 hiện đại hóa công nghiệp hóa thoát Á nhập Âu đế quốc|vi=Minh Trị Duy Tân,Meiji|en=Meiji Restoration|zh=明治维新`},
		{"ASIAHIST_SILK_ROAD",3, `label=Con đường Tơ lụa|desc=mạng lưới thương mại cổ đại nối Châu Á Châu Âu Châu Phi lụa gia vị văn hóa|vi=Con đường Tơ lụa,Silk Road|en=Silk Road|zh=丝绸之路`},
		{"ASIAHIST_MONGOL",   3, `label=đế quốc Mông Cổ|desc=đế quốc lớn nhất lịch sử thế kỷ 13 Thành Cát Tư Hãn chinh phục Á Âu|vi=đế quốc Mông Cổ,Mông Cổ|en=Mongol Empire|zh=蒙古帝国`},
		{"ASIAHIST_CHINA_HIST",3,`label=lịch sử Trung Quốc|desc=4000 năm văn minh nhà Hán Đường Tống Minh Thanh Cách mạng 1949 cải cách 1978|vi=lịch sử Trung Quốc,Trung Quốc|en=Chinese history|zh=中国历史`},
		{"ASIAHIST_JAPAN",    3, `label=lịch sử Nhật Bản|desc=samurai shogunate thời Edo Meiji WWII kinh tế kỳ tích manga anime công nghệ|vi=lịch sử Nhật Bản,Nhật Bản|en=Japanese history|zh=日本历史`},

		// ── KHOA HỌC VẬT CHẤT (MATSCI_) ──────────────────────────
		{"MATSCI_CERAMICS",   3, `label=gốm sứ|desc=vật liệu vô cơ phi kim loại nung ở nhiệt độ cao silicon carbide nhôm oxit răng sứ|vi=gốm sứ,ceramics|en=ceramics|zh=陶瓷`},
		{"MATSCI_COMPOSITE",  3, `label=vật liệu composite|desc=kết hợp hai vật liệu trở lên carbon fiber reinforced polymer sợi thủy tinh máy bay|vi=vật liệu composite,composite|en=composite materials|zh=复合材料`},
		{"MATSCI_BIOMATERIAL",3, `label=vật liệu sinh học|desc=vật liệu tương thích cơ thể implant khớp xương stent titanium hydrogel y tế|vi=vật liệu sinh học,biomaterial|en=biomaterials|zh=生物材料`},

		// ── TOÁN ỨNG DỤNG (APPMATH_) ─────────────────────────────
		{"APPMATH_CRYPTOGRAPHY",3,`label=mật mã toán học|desc=lý thuyết số RSA elliptic curve Diffie-Hellman one-way function bảo mật thông tin|vi=mật mã toán học,cryptography math|en=mathematical cryptography|zh=数学密码学`},
		{"APPMATH_OPTIMIZATION",3,`label=tối ưu hóa|desc=gradient descent linear programming convex optimization machine learning training neural network|vi=tối ưu hóa,optimization|en=optimization|zh=最优化`},
		{"APPMATH_TOPOLOGY",  3, `label=tô pô học|desc=nghiên cứu tính chất bất biến qua biến dạng liên tục donut cốc cà phê knots manifold|vi=tô pô học,topology|en=topology|zh=拓扑学`},

		// ── Y HỌC HIỆN ĐẠI (MODMED_) ─────────────────────────────
		{"MODMED_VACCINE",    3, `label=vaccine|desc=phòng ngừa bệnh truyền nhiễm miễn dịch cộng đồng mRNA COVID-19 Pfizer BioNTech WHO|vi=vaccine,vắc-xin|en=vaccine|zh=疫苗`},
		{"MODMED_SURGERY",    3, `label=phẫu thuật|desc=can thiệp y tế dao mổ robot da Vinci laparoscopic ghép tạng tim phổi gan thận|vi=phẫu thuật,surgery|en=surgery|zh=外科手术`},
		{"MODMED_MENTAL_TREAT",3,`label=điều trị tâm thần|desc=liệu pháp CBT thuốc SSRI thiền định mindfulness trầm cảm lo âu PTSD tâm lý trị liệu|vi=điều trị tâm thần,psychiatric treatment|en=mental health treatment|zh=精神疾病治疗`},
		{"MODMED_PRECISION",  3, `label=y học chính xác|desc=genomics proteomics biomarker điều trị theo từng bệnh nhân ung thư individualized|vi=y học chính xác,precision medicine|en=precision medicine|zh=精准医疗`},

		// ── ĐỊA CHÍNH TRỊ (GEOPOLIT_) ────────────────────────────
		{"GEOPOLIT_BRICS",    3, `label=BRICS|desc=liên minh kinh tế Brazil Russia India China South Africa đối trọng G7 tiền tệ thay thế USD|vi=BRICS|en=BRICS|zh=金砖国家`},
		{"GEOPOLIT_G7",       3, `label=G7|desc=nhóm 7 nền kinh tế phát triển Mỹ Nhật Đức Pháp Anh Canada Ý G20 hợp tác|vi=G7|en=G7|zh=七国集团`},
		{"GEOPOLIT_INDO_PACIFIC",3,`label=Ấn Độ Dương-Thái Bình Dương|desc=khu vực chiến lược Mỹ Trung Nhật Ấn Độ Úc thương mại tự do quân sự QUAD|vi=Ấn Độ Dương-Thái Bình Dương,Indo-Pacific|en=Indo-Pacific|zh=印太地区`},
		{"GEOPOLIT_BELT_ROAD",3, `label=Vành đai Con đường|desc=BRI sáng kiến Trung Quốc cơ sở hạ tầng 140 quốc gia cảng biển đường sắt năng lượng|vi=Vành đai Con đường,BRI|en=Belt and Road Initiative,BRI|zh=一带一路`},

		// ── NGÔN NGỮ VIỆT NAM (VNLING_) ──────────────────────────
		{"VNLING_SCRIPT",     3, `label=chữ Quốc ngữ|desc=hệ thống chữ viết Việt Nam Latin hóa thế kỷ 17 Alexandre de Rhodes thay thế chữ Nôm|vi=chữ Quốc ngữ,tiếng Việt|en=Vietnamese script|zh=越南国语字`},
		{"VNLING_TONES",      3, `label=thanh điệu tiếng Việt|desc=6 thanh ngang huyền sắc nặng hỏi ngã phân biệt ý nghĩa đặc trưng ngôn ngữ đơn lập|vi=thanh điệu tiếng Việt,6 thanh|en=Vietnamese tones|zh=越南声调`},
		{"VNLING_NOM",        3, `label=chữ Nôm|desc=hệ thống chữ viết cổ Việt Nam dựa chữ Hán tạo thêm ký tự mới Truyện Kiều trước chữ Quốc ngữ|vi=chữ Nôm,Nôm|en=Chu Nom,Vietnamese demotic script|zh=字喃`},

		// ── VĂN HÓA ĐẠI CHÚNG (POPCULTURE_) ─────────────────────
		{"POPCULTURE_KPOP",   3, `label=K-pop|desc=nhạc pop Hàn Quốc BTS BLACKPINK Hallyu Wave toàn cầu hóa văn hóa fandom|vi=K-pop,nhạc Hàn|en=K-pop|zh=韩国流行音乐`},
		{"POPCULTURE_ANIME",  3, `label=anime|desc=hoạt hình Nhật Bản phong cách đặc trưng manga Studio Ghibli Naruto One Piece|vi=anime,hoạt hình Nhật|en=anime|zh=日本动漫`},
		{"POPCULTURE_GAMING", 3, `label=công nghiệp game|desc=video game thị trường 200 tỷ USD PC mobile console e-sport Minecraft GTA|vi=game,video game,trò chơi điện tử|en=video game industry|zh=游戏产业`},
		{"POPCULTURE_TIKTOK", 3, `label=TikTok|desc=nền tảng video ngắn ByteDance 1 tỷ người dùng thuật toán gợi ý nội dung|vi=TikTok,video ngắn|en=TikTok|zh=TikTok`},

		// ── SỨC KHỎE TÂM THẦN (PSY_HEALTH_) ──────────────────────
		{"PSY_HEALTH_DEPRESS",3, `label=trầm cảm|desc=rối loạn tâm thần phổ biến buồn bã mất hứng thú mệt mỏi 280 triệu người WHO SSRIs CBT|vi=trầm cảm,depression|en=depression|zh=抑郁症`},
		{"PSY_HEALTH_ANXIETY",3, `label=lo âu|desc=rối loạn lo âu lo lắng quá mức GAD panic disorder phobia serotonin GABA CBT|vi=lo âu,anxiety,rối loạn lo âu|en=anxiety disorder|zh=焦虑症`},
		{"PSY_HEALTH_ADHD",   3, `label=ADHD|desc=rối loạn tăng động giảm chú ý trẻ em người lớn methylphenidate Ritalin neurodiversity|vi=ADHD,tăng động,tăng động giảm chú ý|en=ADHD|zh=注意缺陷多动障碍`},
		{"PSY_HEALTH_AUTISM",  3, `label=tự kỷ|desc=rối loạn phổ tự kỷ ASD giao tiếp xã hội lặp lại hành vi spectrum neurodiversity|vi=tự kỷ,autism,ASD|en=autism,ASD|zh=自闭症`},

		// ── KINH TẾ SỐ (DIGI_ECON_) ──────────────────────────────
		{"DIGI_ECON_PLATFORM",3, `label=kinh tế nền tảng|desc=platform economy two-sided market network effect Amazon Grab Airbnb winner-take-all|vi=kinh tế nền tảng,platform economy|en=platform economy|zh=平台经济`},
		{"DIGI_ECON_GIGS",    3, `label=kinh tế gig|desc=lao động tự do freelance Uber Grab Fiverr bảo hiểm xã hội linh hoạt bất ổn định|vi=kinh tế gig,freelance|en=gig economy|zh=零工经济`},
		{"DIGI_ECON_DATA_EC", 3, `label=kinh tế dữ liệu|desc=dữ liệu là tài nguyên mới data monetization privacy GDPR AI training|vi=kinh tế dữ liệu,data economy|en=data economy|zh=数据经济`},

		// ── VẬT LÝ THIÊN VĂN (ASTROPHYS_) ───────────────────────
		{"ASTROPHYS_REDSHIFT",3, `label=dịch chuyển đỏ|desc=ánh sáng thiên hà xa dịch về đỏ Hubble vũ trụ giãn nở Doppler cosmology|vi=dịch chuyển đỏ,redshift|en=redshift|zh=红移`},
		{"ASTROPHYS_CMB",     3, `label=bức xạ nền vũ trụ|desc=CMB cosmic microwave background bức xạ còn lại từ Big Bang 380000 năm Nobel|vi=bức xạ nền vũ trụ,CMB|en=CMB,cosmic microwave background|zh=宇宙微波背景辐射`},
		{"ASTROPHYS_HUBBLE",  3, `label=hằng số Hubble|desc=tốc độ giãn nở vũ trụ 67-73 km/s/Mpc căng thẳng Hubble tension thiên hà xa|vi=hằng số Hubble,Hubble constant|en=Hubble constant|zh=哈勃常数`},

		// ── KHOA HỌC MÔI TRƯỜNG (ENVSCI_) ───────────────────────
		{"ENVSCI_CARBON",     3, `label=chu trình carbon|desc=carbon cycle quang hợp hô hấp đại dương đất carbon sink source CO2 khí hậu|vi=chu trình carbon,carbon cycle|en=carbon cycle|zh=碳循环`},
		{"ENVSCI_NITROGEN",   3, `label=chu trình nitơ|desc=nitrogen cycle cố định đạm vi khuẩn đất nông nghiệp phân bón eutrophication|vi=chu trình nitơ,nitrogen cycle|en=nitrogen cycle|zh=氮循环`},
		{"ENVSCI_OZONE",      3, `label=tầng ozone|desc=O3 bảo vệ tia UV CFC phá hủy lỗ thủng Nam Cực Montreal Protocol phục hồi|vi=tầng ozone,ozone layer|en=ozone layer|zh=臭氧层`},
		{"ENVSCI_SOIL",       3, `label=khoa học đất|desc=pedology tầng đất hữu cơ vô cơ vi sinh vật xói mòn sa mạc hóa nông nghiệp|vi=khoa học đất,soil science|en=soil science|zh=土壤科学`},

		// ── THỂ THAO THẾ GIỚI (SPORT3_) ──────────────────────────
		{"SPORT3_OLYMPICS",   3, `label=Olympic|desc=thế vận hội đại hội thể thao quốc tế 4 năm/lần 200+ quốc gia Paris 2024 LA 2028|vi=Olympic,Thế vận hội|en=Olympic Games|zh=奥运会`},
		{"SPORT3_FIFA",       3, `label=FIFA World Cup|desc=giải vô địch bóng đá thế giới 4 năm/lần 32 đội Brazil Argentina Pháp Đức|vi=World Cup bóng đá,FIFA World Cup|en=FIFA World Cup|zh=世界杯`},
		{"SPORT3_TENNIS",     3, `label=tennis|desc=môn thể thao vợt Grand Slam Wimbledon Roland Garros US Open Australian Open ATP WTA|vi=tennis,quần vợt|en=tennis|zh=网球`},
		{"SPORT3_SWIMMING",   3, `label=bơi lội|desc=môn thể thao dưới nước Olympic Michael Phelps kỹ thuật bơi freestyle backstroke butterfly|vi=bơi lội,swimming|en=swimming|zh=游泳`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"VNTECH_VINGROUP",   "VNECON_STARTUP",     "is"},
		{"VNTECH_MOMO",       "FINTECH_CBDC",       "competes-with"},
		{"VNTECH_FPT",        "VNEDU_UNIV",         "operates"},
		{"ASIAHIST_MEIJI",    "WORLD_INDUSTRIAL",   "inspired-by"},
		{"ASIAHIST_SILK_ROAD","ASIAHIST_MONGOL",    "used-by"},
		{"APPMATH_OPTIMIZATION","TECH_ML",          "core-of"},
		{"APPMATH_CRYPTOGRAPHY","CS_THEORY_CRYPTO", "extends"},
		{"MODMED_VACCINE",    "BIO2_MICROBIOME",    "relates-to"},
		{"MODMED_PRECISION",  "BIO2_GENE_THERAPY",  "uses"},
		{"GEOPOLIT_BRICS",    "GEOPOLIT_G7",        "counters"},
		{"GEOPOLIT_BELT_ROAD","ASEAN_SINGAPORE",    "passes-through"},
		{"VNLING_SCRIPT",     "VNLIT_KIEU",         "used-in"},
		{"VNLING_NOM",        "VNLING_SCRIPT",      "replaced-by"},
		{"PSY_HEALTH_DEPRESS","HEALTH2_MENTAL",     "type-of"},
		{"PSY_HEALTH_ANXIETY","HEALTH2_MENTAL",     "type-of"},
		{"DIGI_ECON_PLATFORM","DIGITAL2_SOCIAL",    "includes"},
		{"ASTROPHYS_CMB",     "ASTRO2_BIG_BANG",    "evidence-of"},
		{"ASTROPHYS_REDSHIFT","ASTROPHYS_HUBBLE",   "confirms"},
		{"ENVSCI_CARBON",     "ENV_CLIMATE_CHANGE", "drives"},
		{"SPORT3_OLYMPICS",   "SPORT3_SWIMMING",    "includes"},
		{"POPCULTURE_KPOP",   "MUSIC_CLASSICAL",    "contrasts-with"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2600 { fmt.Println("🎉 MILESTONE 2600!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'; rec[1] = 'D'; rec[2] = layer; copy(rec[3:], islv[:])
	rec[15] = byte(len(dna) >> 24); rec[16] = byte(len(dna) >> 16)
	rec[17] = byte(len(dna) >> 8); rec[18] = byte(len(dna)); rec[19] = uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0] = layer; v[1] = h[0]%200 + 1; v[2] = h[1]%200 + 1; v[3] = h[2]%200 + 1
	v[4] = h[3]; v[5] = h[4]; v[6] = h[5]; v[7] = h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16]) + 1
	out[12] = byte(n >> 24); out[13] = byte(n >> 16); out[14] = byte(n >> 8); out[15] = byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl; if ne2 > end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])] = v; i = ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20]) + 1
	raw[16] = byte(n >> 24); raw[17] = byte(n >> 16); raw[18] = byte(n >> 8); raw[19] = byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is":1,"competes-with":2,"operates":3,"inspired-by":4,"used-by":5,
		"core-of":6,"extends":7,"relates-to":8,"uses":9,"counters":10,
		"passes-through":11,"used-in":12,"replaced-by":13,"type-of":14,
		"includes":15,"evidence-of":16,"confirms":17,"drives":18,
		"contrasts-with":19,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl; if ne2 > end { break }
		m[string(raw[i+20+dl:ne2])] = true; i = ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
