//go:build ignore
// seed_milestone5100.go — MILESTONE 5100 — 100 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── HEALTH SYSTEMS ────────────────────────────────────────────
		{"HEALTH_SYSTEMS",       3,`label=hệ thống y tế|desc=health systems WHO six building blocks financing workforce information service delivery governance|vi=hệ thống y tế,health systems|en=health systems`},
		{"HEALTH_UHC",           3,`label=bao phủ y tế toàn dân|desc=universal health coverage UHC financial protection essential services Lancet Commission SDG 3.8|vi=bao phủ y tế toàn dân,universal health coverage|en=universal health coverage`},
		{"HEALTH_MENTAL",        3,`label=sức khỏe tâm thần toàn cầu|desc=global mental health treatment gap LMIC task-sharing mhGAP stigma WHO World Mental Health|vi=sức khỏe tâm thần toàn cầu,global mental health|en=global mental health`},
		{"HEALTH_NCDs",          3,`label=bệnh không lây nhiễm|desc=non-communicable disease NCD cardiovascular diabetes cancer COPD risk factor prevention WHO BEST|vi=bệnh không lây nhiễm,non-communicable disease|en=non-communicable disease`},
		{"HEALTH_PANDEMIC_PREP", 3,`label=chuẩn bị đại dịch|desc=pandemic preparedness IHR International Health Regulations PHEIC PPE stockpile early warning CEPI|vi=chuẩn bị đại dịch,pandemic preparedness|en=pandemic preparedness`},

		// ── NUTRITION & FOOD SYSTEMS ──────────────────────────────────
		{"NUTRITION_MALNUTRITION",3,`label=suy dinh dưỡng|desc=malnutrition undernutrition stunting wasting MUAC CMAM SAM MAM therapeutic food RUTF|vi=suy dinh dưỡng,malnutrition|en=malnutrition`},
		{"NUTRITION_OBESITY",    3,`label=béo phì và dinh dưỡng|desc=obesity overweight BMI double burden diet quality ultra-processed NOVA classification GBD|vi=béo phì và dinh dưỡng,obesity nutrition|en=obesity nutrition`},
		{"FOOD_AGRIFOOD",        3,`label=hệ thống nông lương|desc=agrifood system transformation IPCC IPBES nexus food environment diet planetary boundary|vi=hệ thống nông lương,agrifood system|en=agrifood system`},
		{"FOOD_TECH",            3,`label=công nghệ thực phẩm|desc=food technology precision fermentation cultivated meat plant-based alternative Impossible Beyond|vi=công nghệ thực phẩm,food technology|en=food technology`},
		{"FOOD_WASTE",           3,`label=lãng phí thực phẩm|desc=food loss waste FAO SDG 12.3 supply chain retail consumer behavior economic loss GHG|vi=lãng phí thực phẩm,food waste|en=food waste`},

		// ── DEVELOPMENT ECONOMICS 2 ───────────────────────────────────
		{"DEVECON2_STRUCTURAL",  3,`label=chuyển đổi cơ cấu kinh tế|desc=structural transformation agriculture manufacturing services Lewis model dual economy Kaldor|vi=chuyển đổi cơ cấu kinh tế,structural transformation|en=structural transformation`},
		{"DEVECON2_GROWTH",      3,`label=lý thuyết tăng trưởng|desc=growth theory Solow endogenous Romer Lucas AK model total factor productivity convergence|vi=lý thuyết tăng trưởng,growth theory|en=growth theory`},
		{"DEVECON2_FINANCEINCLUSION",3,`label=tài chính toàn diện|desc=financial inclusion mobile money M-Pesa microfinance digital payment fintech unbanked poverty|vi=tài chính toàn diện,financial inclusion|en=financial inclusion`},
		{"DEVECON2_SOCIALPROTECT",3,`label=bảo trợ xã hội|desc=social protection cash transfer conditional unconditional Bolsa Familia NREGS adaptive system|vi=bảo trợ xã hội,social protection|en=social protection`},
		{"DEVECON2_AID",         3,`label=viện trợ phát triển|desc=development aid ODA effectiveness Paris Declaration Accra Busan ownership alignment results accountability|vi=viện trợ phát triển,development aid|en=development aid`},

		// ── PSYCHOLOGY 2 ─────────────────────────────────────────────
		{"PSYCH2_POSITIVE",      3,`label=tâm lý học tích cực|desc=positive psychology Seligman PERMA well-being flourishing character strengths VIA flow Csikszentmihalyi|vi=tâm lý học tích cực,positive psychology|en=positive psychology`},
		{"PSYCH2_SOCIAL2",       3,`label=tâm lý xã hội nâng cao|desc=social psychology conformity Asch obedience Milgram bystander Latané group think polarization|vi=tâm lý xã hội nâng cao,social psychology|en=social psychology`},
		{"PSYCH2_TRAUMA",        3,`label=tâm lý chấn thương|desc=trauma psychology PTSD ACE adverse childhood complex trauma polyvagal theory Porges somatic|vi=tâm lý chấn thương,trauma psychology|en=trauma psychology`},
		{"PSYCH2_PERSONALITY",   3,`label=nhân cách học|desc=personality psychology Big Five OCEAN trait FFM MBTI dark triad narcissism psychopathy Machiavellianism|vi=nhân cách học,personality psychology|en=personality psychology`},
		{"PSYCH2_DECISION",      3,`label=tâm lý ra quyết định|desc=decision making heuristics bias Kahneman Tversky prospect theory framing anchoring availability|vi=tâm lý ra quyết định,decision making psychology|en=decision making psychology`},

		// ── NEUROSCIENCE 2 ────────────────────────────────────────────
		{"NEURO2_PLASTICITY",    3,`label=tính dẻo thần kinh|desc=neuroplasticity Hebbian LTP LTD synaptic BDNF experience-dependent adult learning rehabilitation stroke|vi=tính dẻo thần kinh,neuroplasticity|en=neuroplasticity`},
		{"NEURO2_SLEEP",         3,`label=thần kinh học giấc ngủ|desc=sleep neuroscience REM NREM slow wave default mode glymphatic clearance circadian rhythm|vi=thần kinh học giấc ngủ,sleep neuroscience|en=sleep neuroscience`},
		{"NEURO2_PAIN",          3,`label=thần kinh học đau|desc=pain neuroscience nociception central sensitization descending modulation placebo nocebo chronic|vi=thần kinh học đau,pain neuroscience|en=pain neuroscience`},
		{"NEURO2_REWARD",        3,`label=thần kinh học phần thưởng|desc=reward neuroscience dopamine nucleus accumbens VTA mesolimbic addiction prediction error|vi=thần kinh học phần thưởng,reward neuroscience|en=reward neuroscience`},
		{"NEURO2_SOCIAL",        3,`label=thần kinh học xã hội|desc=social neuroscience oxytocin trust empathy ToM TPJ mPFC amygdala in-group out-group|vi=thần kinh học xã hội,social neuroscience|en=social neuroscience`},

		// ── MATERIALS SCIENCE 2 ───────────────────────────────────────
		{"MATERIALS2_QUANTUM",   3,`label=vật liệu lượng tử|desc=quantum materials topological insulator Weyl semimetal Mott heavy fermion spin liquid Kitaev|vi=vật liệu lượng tử,quantum materials|en=quantum materials`},
		{"MATERIALS2_POLYMER",   3,`label=vật liệu polymer|desc=polymer materials self-healing shape memory hydrogel conducting conjugated block copolymer morphology|vi=vật liệu polymer,polymer materials|en=polymer materials`},
		{"MATERIALS2_CERAMIC",   3,`label=vật liệu gốm kỹ thuật|desc=technical ceramics SiC Al2O3 Si3N4 ZrO2 sintering spark plasma fracture toughness thermal barrier|vi=vật liệu gốm kỹ thuật,technical ceramics|en=technical ceramics`},
		{"MATERIALS2_COMPOSITE", 3,`label=vật liệu composite|desc=composite materials CFRP fiber reinforced matrix interface delamination fatigue repair aerospace|vi=vật liệu composite,composite materials|en=composite materials`},
		{"MATERIALS2_NANOMATER", 3,`label=vật liệu nano|desc=nanomaterials synthesis characterization TEM XRD surface area catalysis drug delivery toxicology|vi=vật liệu nano,nanomaterials|en=nanomaterials`},

		// ── ENVIRONMENT & CLIMATE 3 ───────────────────────────────────
		{"CLIMATE3_TIPPINGPOINT",3,`label=điểm bùng phát khí hậu|desc=climate tipping point Amazon dieback WAIS West Antarctic AMOC collapse Greenland permafrost|vi=điểm bùng phát khí hậu,climate tipping point|en=climate tipping point`},
		{"CLIMATE3_ADAPTATION",  3,`label=thích ứng biến đổi khí hậu|desc=climate adaptation NAP GCF loss damage residual risk limits managed retreat transformation|vi=thích ứng biến đổi khí hậu,climate adaptation|en=climate adaptation`},
		{"CLIMATE3_FINANCE",     3,`label=tài chính khí hậu|desc=climate finance GCF AF Green Climate Fund NDC IPCC carbon market Article 6 voluntary|vi=tài chính khí hậu,climate finance|en=climate finance`},
		{"CLIMATE3_REMOVAL",     3,`label=loại bỏ carbon|desc=carbon dioxide removal CDR BECCS DAC afforestation ocean alkalinity enhanced weathering|vi=loại bỏ carbon,carbon removal|en=carbon removal`},
		{"CLIMATE3_GEOENG",      3,`label=địa kỹ thuật khí hậu|desc=geoengineering SAI stratospheric aerosol injection solar radiation management ethics governance|vi=địa kỹ thuật khí hậu,geoengineering|en=geoengineering`},

		// ── VIETNAM HEALTH & SOCIETY ──────────────────────────────────
		{"VNHEALTH2_REFORM",     3,`label=cải cách y tế Việt Nam|desc=cải cách y tế Việt Nam bảo hiểm y tế toàn dân bệnh viện tư tuyến xã y bác sĩ gia đình|vi=cải cách y tế Việt Nam,Vietnam health reform|en=Vietnam health reform`},
		{"VNHEALTH2_TRADITION",  3,`label=y học cổ truyền Việt Nam|desc=y học cổ truyền Việt Nam đông y châm cứu thảo dược bệnh viện y học cổ truyền tích hợp|vi=y học cổ truyền Việt Nam,Vietnamese traditional medicine|en=Vietnamese traditional medicine`},
		{"VNSOCIETY_AGING",      3,`label=già hóa dân số Việt Nam|desc=già hóa dân số Việt Nam tỷ lệ sinh giảm dân số vàng lương hưu chăm sóc người cao tuổi|vi=già hóa dân số Việt Nam,Vietnam aging population|en=Vietnam aging population`},
		{"VNSOCIETY_RELIGION",   3,`label=tôn giáo và xã hội Việt Nam|desc=tôn giáo Việt Nam Phật giáo Thiên Chúa giáo Cao Đài Hòa Hảo tín ngưỡng dân gian tự do|vi=tôn giáo và xã hội Việt Nam,Vietnam religion society|en=Vietnam religion society`},
		{"VNSOCIETY_YOUTH",      3,`label=thanh niên Việt Nam|desc=thanh niên Việt Nam thế hệ Z gen Z mạng xã hội khởi nghiệp du học giá trị thay đổi|vi=thanh niên Việt Nam,Vietnam youth|en=Vietnam youth`},

		// ── EDUCATION SYSTEMS ─────────────────────────────────────────
		{"EDUCATION2_PEDAGOGY",  3,`label=phương pháp sư phạm|desc=pedagogy constructivism Vygotsky Dewey experiential project-based inquiry flipped classroom|vi=phương pháp sư phạm,pedagogy|en=pedagogy`},
		{"EDUCATION2_HIGHER",    3,`label=giáo dục đại học|desc=higher education massification ranking research university liberal arts vocational credential inflation|vi=giáo dục đại học,higher education|en=higher education`},
		{"EDUCATION2_TECH",      3,`label=công nghệ giáo dục|desc=edtech MOOCs Coursera Khan adaptive learning personalization AI tutor assessment learning analytics|vi=công nghệ giáo dục,edtech|en=edtech`},
		{"EDUCATION2_EQUITY",    3,`label=công bằng giáo dục|desc=education equity achievement gap socioeconomic race teacher quality school funding busing|vi=công bằng giáo dục,education equity|en=education equity`},
		{"VNEDUCATION2",         3,`label=giáo dục Việt Nam|desc=giáo dục Việt Nam thi THPT đại học tự chủ trường quốc tế PISA kỹ năng 21st century|vi=giáo dục Việt Nam,Vietnam education|en=Vietnam education`},

		// ── DIGITAL ECONOMY 2 ─────────────────────────────────────────
		{"DIGITAL2_PLATFORM",    3,`label=kinh tế nền tảng số|desc=platform economy network effect multi-sided Uber Airbnb Amazon marketplace gig monopoly|vi=kinh tế nền tảng số,platform economy|en=platform economy`},
		{"DIGITAL2_DATA_ECON",   3,`label=kinh tế dữ liệu|desc=data economy data as resource value creation monetization GDPR privacy regulation data portability|vi=kinh tế dữ liệu,data economy|en=data economy`},
		{"DIGITAL2_FINTECH",     3,`label=fintech và ngân hàng số|desc=fintech digital banking neobank open banking PSD2 API BaaS embedded finance BNPL|vi=fintech và ngân hàng số,fintech digital banking|en=fintech digital banking`},
		{"DIGITAL2_CBDC",        3,`label=tiền kỹ thuật số ngân hàng trung ương|desc=CBDC central bank digital currency e-CNY digital euro FedNow retail wholesale programmable|vi=tiền kỹ thuật số ngân hàng trung ương,CBDC|en=CBDC`},
		{"DIGITAL2_REGULATION",  3,`label=quản lý kinh tế số|desc=digital regulation EU DSA DMA antitrust platform accountability content moderation AI Act|vi=quản lý kinh tế số,digital regulation|en=digital regulation`},

		// ── MISC BRIDGE NODES ─────────────────────────────────────────
		{"CLIMATE3_VIET",        3,`label=biến đổi khí hậu Việt Nam|desc=biến đổi khí hậu Việt Nam ĐBSCL ngập lụt mặn xâm nhập bão lũ giải pháp thích ứng|vi=biến đổi khí hậu Việt Nam,Vietnam climate change|en=Vietnam climate change`},
		{"HEALTH_TROPICAL",      3,`label=bệnh nhiệt đới bị lãng quên|desc=neglected tropical diseases NTD WHO lymphatic filariasis schistosomiasis onchocerciasis trachoma|vi=bệnh nhiệt đới bị lãng quên,neglected tropical diseases|en=neglected tropical diseases`},
		{"DEVECON2_MIDDLE_INCOME",3,`label=bẫy thu nhập trung bình|desc=middle income trap innovation upgrading Korea Taiwan Malaysia Thailand Vietnam manufacturing|vi=bẫy thu nhập trung bình,middle income trap|en=middle income trap`},
		{"NEURO2_DEVELOPMENT",   3,`label=phát triển thần kinh|desc=neurodevelopment prenatal critical period synaptic pruning myelination ASD ADHD schizophrenia|vi=phát triển thần kinh,neurodevelopment|en=neurodevelopment`},
		{"PSYCH2_CULTURE",       3,`label=tâm lý học văn hóa|desc=cultural psychology collectivism individualism Hofstede WEIRD samples cross-cultural emotion display|vi=tâm lý học văn hóa,cultural psychology|en=cultural psychology`},
		{"MATERIALS2_SUSTAINABLE",3,`label=vật liệu bền vững|desc=sustainable materials bioplastic mycelium bamboo hemp flax recycled critical mineral substitution|vi=vật liệu bền vững,sustainable materials|en=sustainable materials`},
		{"FOOD_NUTRITION_VIET",  3,`label=dinh dưỡng và ẩm thực Việt Nam|desc=dinh dưỡng Việt Nam phở bún bánh mì đa dạng vùng miền chuyển đổi thực phẩm hiện đại|vi=dinh dưỡng và ẩm thực Việt Nam,Vietnam nutrition food|en=Vietnam nutrition food`},
		{"DIGITAL2_VIET",        3,`label=kinh tế số Việt Nam|desc=kinh tế số Việt Nam Grab Shopee TikTok Shop thanh toán số VNPay Momo VNPT FPT Viettel|vi=kinh tế số Việt Nam,Vietnam digital economy|en=Vietnam digital economy`},
		{"EDUCATION2_STEM",      3,`label=STEM và giáo dục kỹ thuật|desc=STEM education robotics coding maker space girls in STEM diversity pipeline industry-academia|vi=STEM và giáo dục kỹ thuật,STEM education|en=STEM education`},
		{"HEALTH_ANTIMICROBIAL", 3,`label=kháng kháng sinh|desc=antimicrobial resistance AMR superbugs ESKAPE priority pathogens One Health stewardship pipeline|vi=kháng kháng sinh,antimicrobial resistance|en=antimicrobial resistance`},
		{"CLIMATE3_JUST_TRANS",  3,`label=chuyển đổi công bằng khí hậu|desc=just transition coal communities developing nations JETP NDC capacity-building loss damage|vi=chuyển đổi công bằng khí hậu,just transition climate|en=just transition climate`},
		{"DEVECON2_INEQUALITY",  3,`label=bất bình đẳng và phát triển|desc=inequality development Kuznets curve Piketty r>g redistribution Gini coefficient mobility|vi=bất bình đẳng và phát triển,inequality development|en=inequality development`},
		{"PSYCH2_HEALTH",        3,`label=tâm lý học sức khỏe|desc=health psychology behavior change COM-B motivational interviewing chronic disease self-management|vi=tâm lý học sức khỏe,health psychology|en=health psychology`},
		{"NEURO2_IMAGING",       3,`label=hình ảnh thần kinh học|desc=neuroimaging fMRI resting state connectivity parcellation DWI tractography EEG MEG multimodal|vi=hình ảnh thần kinh học,neuroimaging|en=neuroimaging`},
		{"MATERIALS2_ENERGY",    3,`label=vật liệu năng lượng|desc=energy materials perovskite OPV thermoelectric piezoelectric triboelectric harvesting storage|vi=vật liệu năng lượng,energy materials|en=energy materials`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 5100 { fmt.Println(" MILESTONE 5100! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
