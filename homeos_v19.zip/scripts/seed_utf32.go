//go:build ignore

// scripts/seed_utf32.go
//
// Seed Unicode blocks quan trọng vào L1 (UTF-32) trong homeos.olang.
//
// MASTER.md §1.1: "L1 UTF-32 — ký tự cơ bản · QR · ED25519"
// QT6: "SDF == hữu hình" — mỗi ký tự lưu SDF formula, không phải pixel.
//
// Blocks được seed:
//   CJK Unified Ideographs U+4E00..U+9FFF  (ký tự Hán)
//   CJK thường dùng: 愛山水火木金土日月
//   Cyrillic U+0400..U+04FF
//   Arabic U+0600..U+06FF
//   Hebrew U+0590..U+05FF
//   Vietnamese precomposed U+00C0..U+01B0 (thêm dấu)
//   Digits + Math U+0030..U+0039, U+2200..U+22FF
//   IPA U+0250..U+02AF
//   Hiragana U+3040..U+309F
//   Katakana U+30A0..U+30FF
//   Hangul Jamo U+1100..U+11FF
//
// DNA cho L1 node:
//   [0x01][block_id][group_id][cp_b0][cp_b1][cp_b2][cp_b3]
//   + script tag text (e.g. "cjk", "latin", "arabic")
//
// Chạy:
//   cd <repo>
//   go run scripts/seed_utf32.go
//   ./olang verify homeos.olang
//   ./olang dump   homeos.olang | grep '^\s*\[L1\]' | wc -l

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"unicode"
)

const (
	path    = "homeos.olang"
	hdrSize = 64
	entSize = 24
	nLayers = 9
	idxEnd  = hdrSize + nLayers*entSize // = 280
)

type ISL [8]byte

func main() {
	if _, err := os.Stat(path); err != nil {
		log.Fatalf("không tìm thấy %s — chạy từ thư mục gốc repo", path)
	}

	// ── Định nghĩa các Unicode blocks cần seed ──────────────────
	type blockDef struct {
		name  string
		runes []rune
		tag   string // SDF group tag
	}

	blocks := []blockDef{
		// CJK thường dùng nhất (Tier 1 — có SDF concept)
		{
			name:  "CJK_COMMON",
			tag:   "cjk",
			runes: cjkCommon(),
		},
		// Vietnamese diacritics (precomposed)
		{
			name:  "VIETNAMESE",
			tag:   "latin_ext",
			runes: vietnameseChars(),
		},
		// Digits 0-9
		{
			name:  "DIGITS",
			tag:   "digit",
			runes: rangeRunes(0x0030, 0x0039),
		},
		// Math operators U+2200..U+22FF
		{
			name:  "MATH",
			tag:   "math",
			runes: filterPrintable(rangeRunes(0x2200, 0x22FF)),
		},
		// IPA U+0250..U+02AF
		{
			name:  "IPA",
			tag:   "phoneme",
			runes: filterPrintable(rangeRunes(0x0250, 0x02AF)),
		},
		// Cyrillic U+0400..U+045F (basic)
		{
			name:  "CYRILLIC",
			tag:   "cyrillic",
			runes: filterPrintable(rangeRunes(0x0410, 0x044F)), // А-Я а-я
		},
		// Arabic basic U+0621..U+064A
		{
			name:  "ARABIC",
			tag:   "arabic",
			runes: filterPrintable(rangeRunes(0x0621, 0x064A)),
		},
		// Hebrew basic U+05D0..U+05EA
		{
			name:  "HEBREW",
			tag:   "hebrew",
			runes: filterPrintable(rangeRunes(0x05D0, 0x05EA)),
		},
		// Hiragana U+3041..U+3096
		{
			name:  "HIRAGANA",
			tag:   "hiragana",
			runes: filterPrintable(rangeRunes(0x3041, 0x3096)),
		},
		// Katakana U+30A1..U+30F6
		{
			name:  "KATAKANA",
			tag:   "katakana",
			runes: filterPrintable(rangeRunes(0x30A1, 0x30F6)),
		},
		// Hangul Jamo U+1100..U+11FF
		{
			name:  "HANGUL_JAMO",
			tag:   "hangul",
			runes: filterPrintable(rangeRunes(0x1100, 0x11FF)),
		},
	}

	total, skip := 0, 0
	for _, blk := range blocks {
		added := 0
		for _, cp := range blk.runes {
			isl := charISL(cp, blk.tag)
			dna := charDNA(cp, blk.tag)
			name := charName(cp)
			err := appendL1(path, isl, cp, dna, name)
			if err != nil {
				skip++
			} else {
				added++
			}
		}
		fmt.Printf("  +L1 %-14s %4d nodes\n", blk.name, added)
		total += added
	}

	fmt.Printf("\n✅ seed_utf32: +%d nodes, %d skip\n", total, skip)
	fmt.Println("\nVerify:")
	fmt.Println("  ./olang verify homeos.olang")
	fmt.Println("  ./olang dump   homeos.olang | grep '^  \\[L1\\]' | wc -l")
}

// ── ISL cho L1 ký tự ──────────────────────────────────────────
//
// L1 = Layer 1 (UTF-32)
// group = script family (0=latin, 1=cjk, 2=cyrillic, 3=arabic, ...)
// type  = Unicode block sub-group
// id    = hash của codepoint

func charISL(cp rune, tag string) ISL {
	h := sha256.Sum256([]byte(fmt.Sprintf("%s:%d", tag, cp)))
	var isl ISL
	isl[0] = 0x01 // Layer 1
	isl[1] = tagGroup(tag)
	isl[2] = uint8(cp>>8) & 0xFF
	isl[3] = uint8(cp) & 0xFF
	copy(isl[4:], h[:4])
	return isl
}

func tagGroup(tag string) uint8 {
	switch tag {
	case "latin", "latin_ext": return 0x00
	case "cjk":                return 0x01
	case "cyrillic":           return 0x02
	case "arabic":             return 0x03
	case "hebrew":             return 0x04
	case "hiragana":           return 0x05
	case "katakana":           return 0x06
	case "hangul":             return 0x07
	case "digit":              return 0x08
	case "math":               return 0x09
	case "phoneme":            return 0x0A
	default:                   return 0xFF
	}
}

// charDNA: [0x01][group][block][cp:4bytes] + tag string
func charDNA(cp rune, tag string) []byte {
	dna := make([]byte, 7+len(tag))
	dna[0] = 0x01 // L1 marker
	dna[1] = tagGroup(tag)
	dna[2] = uint8(cp >> 24)
	dna[3] = uint8(cp >> 16)
	dna[4] = uint8(cp >> 8)
	dna[5] = uint8(cp)
	dna[6] = '|'
	copy(dna[7:], []byte(tag))
	return dna
}

func charName(cp rune) string {
	// Tên đơn giản: "U+XXXX 'char'"
	return fmt.Sprintf("U+%04X '%c'", cp, cp)
}

// ── Helpers tạo rune ranges ───────────────────────────────────

func rangeRunes(from, to rune) []rune {
	out := make([]rune, 0, int(to-from+1))
	for r := from; r <= to; r++ {
		out = append(out, r)
	}
	return out
}

func filterPrintable(runes []rune) []rune {
	out := runes[:0]
	for _, r := range runes {
		if unicode.IsPrint(r) {
			out = append(out, r)
		}
	}
	return out
}

// cjkCommon — CJK ký tự thường dùng nhất (Tier 1)
// Bao gồm: 200 ký tự phổ biến nhất trong văn bản Hán-Việt-Nhật-Hàn
func cjkCommon() []rune {
	// Explicit list: ký tự có concept SDF thật trong utf32_bridge
	explicit := []rune{
		'山', '水', '火', '木', '金', '土',
		'日', '月', '風', '雷', '電', '雲',
		'天', '地', '人', '心', '手', '目',
		'耳', '口', '足', '頭', '身', '血',
		'愛', '友', '家', '國', '道', '力',
		'光', '暗', '明', '空', '海', '川',
		'山', '石', '花', '草', '木', '林',
		'森', '鳥', '魚', '虫', '馬', '牛',
		'犬', '猫', '鼠', '龍', '虎', '熊',
		'米', '食', '飲', '酒', '茶', '塩',
		'一', '二', '三', '四', '五', '六',
		'七', '八', '九', '十', '百', '千',
		'万', '大', '小', '高', '低', '長',
		'短', '新', '古', '白', '黒', '赤',
		'青', '緑', '黄', '紫', '橙', '色',
		'上', '下', '左', '右', '中', '外',
		'前', '後', '内', '北', '南', '東',
		'西', '門', '窓', '壁', '床', '天',
		'星', '太', '月', '年', '月', '日',
		'時', '分', '秒', '今', '昨', '明',
	}
	// Deduplicate
	seen := map[rune]bool{}
	out := make([]rune, 0, len(explicit))
	for _, r := range explicit {
		if !seen[r] {
			seen[r] = true
			out = append(out, r)
		}
	}
	return out
}

// vietnameseChars — các ký tự dấu tiếng Việt precomposed
func vietnameseChars() []rune {
	// Toàn bộ bảng chữ cái tiếng Việt precomposed
	vi := []rune{
		'à', 'á', 'â', 'ã', 'è', 'é', 'ê',
		'ì', 'í', 'ò', 'ó', 'ô', 'õ', 'ù', 'ú',
		'ý', 'À', 'Á', 'Â', 'Ã', 'È', 'É', 'Ê',
		'Ì', 'Í', 'Ò', 'Ó', 'Ô', 'Õ', 'Ù', 'Ú', 'Ý',
		// Đặc trưng tiếng Việt
		'ă', 'Ă', 'ắ', 'ặ', 'ằ', 'ẳ', 'ẵ',
		'Ắ', 'Ặ', 'Ằ', 'Ẳ', 'Ẵ',
		'â', 'Â', 'ấ', 'ậ', 'ầ', 'ẩ', 'ẫ',
		'Ấ', 'Ậ', 'Ầ', 'Ẩ', 'Ẫ',
		'đ', 'Đ',
		'ê', 'Ê', 'ế', 'ệ', 'ề', 'ể', 'ễ',
		'Ế', 'Ệ', 'Ề', 'Ể', 'Ễ',
		'ô', 'Ô', 'ố', 'ộ', 'ồ', 'ổ', 'ỗ',
		'Ố', 'Ộ', 'Ồ', 'Ổ', 'Ỗ',
		'ơ', 'Ơ', 'ớ', 'ợ', 'ờ', 'ở', 'ỡ',
		'Ớ', 'Ợ', 'Ờ', 'Ở', 'Ỡ',
		'ư', 'Ư', 'ứ', 'ự', 'ừ', 'ử', 'ữ',
		'Ứ', 'Ự', 'Ừ', 'Ử', 'Ữ',
		// Tonal marks trên các nguyên âm khác
		'ả', 'ạ', 'ã', 'ā',
		'Ả', 'Ạ',
		'ỉ', 'ị', 'ĩ',
		'Ỉ', 'Ị',
		'ủ', 'ụ', 'ũ',
		'Ủ', 'Ụ',
		'ỳ', 'ỷ', 'ỵ', 'ỹ',
		'Ỳ', 'Ỷ', 'Ỵ', 'Ỹ',
	}
	// Deduplicate
	seen := map[rune]bool{}
	out := make([]rune, 0, len(vi))
	for _, r := range vi {
		if !seen[r] {
			seen[r] = true
			out = append(out, r)
		}
	}
	return out
}

// ── appendL1 — ghi node L1 vào homeos.olang ──────────────────
func appendL1(filePath string, isl ISL, cp rune, dna []byte, name string) error {
	raw, err := os.ReadFile(filePath)
	if err != nil { return err }
	if len(raw) < idxEnd || string(raw[0:4]) != "OLNG" {
		return fmt.Errorf("bad file")
	}

	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }

	// Kiểm tra trùng ISL
	for i := idxEnd; i+19 < len(raw); {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		if i+8+3 > len(raw) { break }
		if raw[i+2] == 0x01 { // L1
			existISL := raw[i+3 : i+11]
			if string(existISL) == string(isl[:]) {
				return fmt.Errorf("duplicate ISL")
			}
		}
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
		nl := int(raw[i+19])
		i += 20 + dl + nl
	}

	// Build record: ND + layer(1) + ISL(8) + cp(4) + dna_len(4) + name_len(1) + dna + name
	rec := make([]byte, 2+1+8+4+4+1+len(dna)+len(nb))
	p := 0
	rec[p] = 'N'; p++
	rec[p] = 'D'; p++
	rec[p] = 0x01; p++       // Layer 1
	copy(rec[p:], isl[:]); p += 8
	binary.BigEndian.PutUint32(rec[p:], uint32(cp)); p += 4
	binary.BigEndian.PutUint32(rec[p:], uint32(len(dna))); p += 4
	rec[p] = uint8(len(nb)); p++
	copy(rec[p:], dna); p += len(dna)
	copy(rec[p:], nb)

	// Tìm vị trí insert: sau L1 data hoặc sau header
	type li struct{ offset, size uint64 }
	layers := [nLayers]li{}
	for i := 0; i < nLayers; i++ {
		o := hdrSize + i*entSize
		layers[i].offset = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].size   = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}

	var insertAt uint64
	if layers[1].size > 0 {
		insertAt = layers[1].offset + layers[1].size
	} else {
		insertAt = uint64(idxEnd)
		for i := 0; i >= 0; i-- {
			if layers[i].size > 0 { insertAt = layers[i].offset + layers[i].size; break }
		}
	}

	// Insert record vào raw
	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:insertAt]...)
	out = append(out, rec...)
	out = append(out, raw[insertAt:]...)

	// Update L1 size + nnodes trong header
	o1 := hdrSize + 1*entSize
	if layers[1].size == 0 {
		binary.BigEndian.PutUint64(out[o1+4:], insertAt)
	}
	binary.BigEndian.PutUint64(out[o1+12:], layers[1].size+uint64(len(rec)))
	nnodes := binary.BigEndian.Uint32(out[o1+20:])
	binary.BigEndian.PutUint32(out[o1+20:], nnodes+1)

	// Shift offsets của các layers sau L1
	for i := 2; i < nLayers; i++ {
		o := hdrSize + i*entSize
		if layers[i].size > 0 {
			off := binary.BigEndian.Uint64(out[o+4:])
			binary.BigEndian.PutUint64(out[o+4:], off+uint64(len(rec)))
		}
	}

	// Cập nhật SHA256: hash của out[280:]
	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	// Atomic write
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return err }
	return os.Rename(tmp, filePath)
}
