//go:build ignore
// go run scripts/seed_bio2_more.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes, %d edges\n", be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── SINH HỌC PHÂN TỬ / GENE (BIO2_) ─────────────────────
		{"BIO2_CRISPR",     3, `label=CRISPR|desc=công cụ chỉnh sửa gene chính xác CRISPR-Cas9 cắt DNA sửa lỗi di truyền điều trị bệnh Nobel 2020|vi=CRISPR,chỉnh sửa gene|en=CRISPR,gene editing|zh=CRISPR基因编辑`},
		{"BIO2_STEM_CELL",  3, `label=tế bào gốc|desc=tế bào chưa biệt hóa có khả năng phát triển thành bất kỳ loại tế bào nào iPSC trị liệu tái tạo|vi=tế bào gốc,stem cell|en=stem cell|zh=干细胞`},
		{"BIO2_GENE_THERAPY",3,`label=liệu pháp gene|desc=điều trị bệnh bằng cách sửa đổi bổ sung gen vào tế bào bệnh nhân hemophilia ung thư|vi=liệu pháp gene,gene therapy|en=gene therapy|zh=基因治疗`},
		{"BIO2_MICROBIOME",  3, `label=hệ vi sinh vật|desc=tập hợp vi khuẩn virus nấm sống trong cơ thể người đường ruột sức khỏe tâm thần miễn dịch|vi=hệ vi sinh vật,microbiome,vi khuẩn đường ruột|en=microbiome|zh=微生物组`},
		{"BIO2_PROTEIN",    3, `label=protein|desc=phân tử sinh học chuỗi amino acid cấu trúc 3D enzyme kháng thể hormone AlphaFold gấp protein|vi=protein,amino acid|en=protein|zh=蛋白质`},
		{"BIO2_EPIGENETICS",3, `label=biểu sinh học|desc=thay đổi biểu hiện gen không thay đổi DNA methyl hóa histone môi trường ảnh hưởng di truyền|vi=biểu sinh học,epigenetics|en=epigenetics|zh=表观遗传学`},
		{"BIO2_EVOLUTION",  3, `label=tiến hóa|desc=quá trình thay đổi di truyền qua các thế hệ chọn lọc tự nhiên Darwin đột biến thích nghi|vi=tiến hóa,evolution|en=evolution,natural selection|zh=进化论`},
		{"BIO2_CELL_DIVISION",3,`label=phân bào|desc=quá trình tế bào tự nhân đôi nguyên phân giảm phân DNA nhân đôi chu kỳ tế bào ung thư|vi=phân bào,cell division|en=cell division,mitosis|zh=细胞分裂`},

		// ── TÂM LÝ HỌC THÊM (PSY2_) ─────────────────────────────
		{"PSY2_MEMORY",     3, `label=trí nhớ|desc=khả năng mã hóa lưu trữ truy xuất thông tin trí nhớ ngắn hạn dài hạn hippocampus Alzheimer|vi=trí nhớ,memory|en=memory|zh=记忆`},
		{"PSY2_MOTIVATION", 3, `label=động lực|desc=lý do thúc đẩy hành vi tháp nhu cầu Maslow nội tại ngoại tại thưởng phạt tâm lý học|vi=động lực,motivation|en=motivation|zh=动机`},
		{"PSY2_PERSONALITY",3, `label=tính cách|desc=mô hình hành vi suy nghĩ cảm xúc ổn định Big Five MBTI hướng ngoại hướng nội|vi=tính cách,personality|en=personality|zh=性格`},
		{"PSY2_IQ",         3, `label=trí tuệ|desc=khả năng tư duy logic giải quyết vấn đề IQ chỉ số thông minh đa trí tuệ Gardner|vi=trí tuệ,IQ,intelligence|en=intelligence,IQ|zh=智力`},

		// ── ĐỊA LÝ THÊM (GEO2_) ──────────────────────────────────
		{"GEO2_MONSOON",    3, `label=gió mùa|desc=hệ thống gió theo mùa mang mưa lớn châu Á Nam Á Đông Nam Á mùa mưa khô nông nghiệp|vi=gió mùa,monsoon|en=monsoon|zh=季风`},
		{"GEO2_EARTHQUAKE", 3, `label=động đất|desc=rung chuyển đột ngột vỏ Trái Đất do dịch chuyển mảng kiến tạo Richter tsunami Nhật Bản|vi=động đất,earthquake|en=earthquake|zh=地震`},
		{"GEO2_GLACIER",    3, `label=sông băng|desc=khối băng lớn di chuyển chậm tích lũy tuyết băng Alps Himalaya tan chảy do biến đổi khí hậu|vi=sông băng,glacier|en=glacier|zh=冰川`},
		{"GEO2_TECTONIC",   3, `label=kiến tạo mảng|desc=lý thuyết vỏ Trái Đất chia thành các mảng di chuyển tạo núi động đất núi lửa Wegener|vi=kiến tạo mảng,tectonic plates|en=tectonic plates|zh=板块构造`},

		// ── XÃ HỘI HỌC THÊM (SOC2_) ─────────────────────────────
		{"SOC2_FAMILY",     3, `label=gia đình|desc=đơn vị xã hội cơ bản gồm cha mẹ con cái gia đình hạt nhân mở rộng hôn nhân|vi=gia đình,family|en=family|zh=家庭`},
		{"SOC2_RELIGION",   3, `label=tôn giáo|desc=hệ thống niềm tin thực hành nghi lễ liên quan đến thiêng liêng siêu nhiên Phật giáo Hồi giáo Kitô|vi=tôn giáo,religion|en=religion|zh=宗教`},
		{"SOC2_RACISM",     3, `label=phân biệt chủng tộc|desc=thành kiến kỳ thị dựa trên chủng tộc dân tộc lịch sử nô lệ phong trào dân quyền BLM|vi=phân biệt chủng tộc,racism|en=racism|zh=种族歧视`},
		{"SOC2_FEMINISM",   3, `label=nữ quyền|desc=phong trào xã hội chính trị tranh đấu bình đẳng giới quyền bầu cử phụ nữ tiền lương|vi=nữ quyền,feminism,bình đẳng giới|en=feminism|zh=女权主义`},

		// ── KINH TẾ / CRYPTO (FINTECH_) ──────────────────────────
		{"FINTECH_DEFI",    3, `label=DeFi|desc=tài chính phi tập trung dịch vụ tài chính trên blockchain cho vay staking không cần ngân hàng|vi=DeFi,tài chính phi tập trung|en=DeFi,decentralized finance|zh=去中心化金融`},
		{"FINTECH_CBDC",    3, `label=tiền kỹ thuật số ngân hàng trung ương|desc=CBDC phiên bản kỹ thuật số của tiền pháp định phát hành bởi NHTW e-CNY e-VND|vi=CBDC,tiền kỹ thuật số|en=CBDC,digital currency|zh=央行数字货币`},
		{"FINTECH_INSURTECH",3,`label=bảo hiểm công nghệ|desc=ứng dụng AI big data IoT trong bảo hiểm định giá tự động bồi thường nhanh|vi=bảo hiểm công nghệ,insurtech|en=insurtech|zh=保险科技`},

		// ── THIÊN VĂN THÊM (ASTRO2_) ─────────────────────────────
		{"ASTRO2_PULSAR",   3, `label=sao xung|desc=sao neutron quay cực nhanh phát xung điện từ định kỳ cực kỳ chính xác đồng hồ vũ trụ|vi=sao xung,pulsar|en=pulsar|zh=脉冲星`},
		{"ASTRO2_DARK_MATTER",3,`label=vật chất tối|desc=vật chất không phát xạ ánh sáng chiếm 27% vũ trụ chỉ biết qua hấp dẫn bí ẩn vũ trụ học|vi=vật chất tối,dark matter|en=dark matter|zh=暗物质`},
		{"ASTRO2_BIG_BANG",  3, `label=Vụ Nổ Lớn|desc=lý thuyết khởi nguồn vũ trụ từ trạng thái cực nóng đặc ~13.8 tỷ năm trước giãn nở vũ trụ|vi=Vụ Nổ Lớn,Big Bang|en=Big Bang|zh=大爆炸`},

		// ── THỰC PHẨM / DINH DƯỠNG THÊM (NUTR_) ─────────────────
		{"NUTR_PROTEIN_FOOD",3,`label=thực phẩm giàu protein|desc=thịt cá trứng đậu phụ đậu nành nguồn cung cấp amino acid thiết yếu xây dựng cơ bắp|vi=thực phẩm giàu protein,protein food|en=protein-rich food|zh=高蛋白食物`},
		{"NUTR_FASTING",    3, `label=nhịn ăn gián đoạn|desc=phương pháp ăn uống xen kẽ nhịn ăn IF 16:8 5:2 giảm cân sức khỏe trao đổi chất|vi=nhịn ăn gián đoạn,intermittent fasting,IF|en=intermittent fasting|zh=间歇性禁食`},
		{"NUTR_MICRONUTRIENT",3,`label=vi chất dinh dưỡng|desc=vitamin khoáng chất cần với lượng nhỏ nhưng thiết yếu vitamin D B12 sắt kẽm iốt|vi=vi chất dinh dưỡng,micronutrient,vitamin|en=micronutrient,vitamin|zh=微量营养素`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"BIO2_CRISPR",      "BIO_GENETICS",      "modifies"},
		{"BIO2_CRISPR",      "BIO2_GENE_THERAPY", "enables"},
		{"BIO2_STEM_CELL",   "BIO2_GENE_THERAPY", "used-in"},
		{"BIO2_MICROBIOME",  "ANAT_IMMUNE",       "influences"},
		{"BIO2_PROTEIN",     "BIO_GENETICS",      "encoded-by"},
		{"BIO2_EVOLUTION",   "BIO_GENETICS",      "driven-by"},
		{"BIO2_CELL_DIVISION","BIO2_PROTEIN",     "requires"},
		{"PSY2_MEMORY",      "ANAT_BRAIN",        "stored-in"},
		{"PSY2_IQ",          "PSY2_MEMORY",       "includes"},
		{"GEO2_EARTHQUAKE",  "GEO2_TECTONIC",     "caused-by"},
		{"GEO2_GLACIER",     "CLIM_ICECAP",       "part-of"},
		{"GEO2_GLACIER",     "ENV_CLIMATE_CHANGE","melted-by"},
		{"SOC2_RACISM",      "SOC_HUMAN_RIGHTS",  "violates"},
		{"SOC2_FEMINISM",    "SOC_GENDER",        "advances"},
		{"FINTECH_DEFI",     "MICRO_CRYPTO",      "extends"},
		{"ASTRO2_BIG_BANG",  "SPACE2_BLACKHOLE",  "preceded"},
		{"ASTRO2_DARK_MATTER","ASTRO2_BIG_BANG",  "formed-in"},
		{"NUTR_FASTING",     "ANAT_LIVER",        "affects"},
		{"NUTR_MICRONUTRIENT","ANAT_IMMUNE",      "supports"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2350 { fmt.Printf("🎯 %d nodes — heading to 2400!\n", nn) }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"modifies":1,"enables":2,"used-in":3,"influences":4,"encoded-by":5,
		"driven-by":6,"requires":7,"stored-in":8,"includes":9,"caused-by":10,
		"part-of":11,"melted-by":12,"violates":13,"advances":14,"extends":15,
		"preceded":16,"formed-in":17,"affects":18,"supports":19,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
