//go:build ignore
// seed_ai_edges.go — Thêm silk edges nối AI/Neuro nodes
// Edge format: fromISL(8) + toISL(8) + eType(1) = 17 bytes
// Được lưu ở CUỐI file, trước header cập nhật nedges
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const edgeFile = "homeos.olang"

// Edge types (từ silk.go)
const (
	OpMember  uint8 = 1  // thuộc về
	OpEquiv   uint8 = 2  // tương đương
	OpSimilar uint8 = 5  // tương tự
	OpCompose uint8 = 4  // tổ hợp
)

func isl(name string) [8]byte {
	h := sha256.Sum256([]byte(name))
	var b [8]byte
	copy(b[:], h[:8])
	return b
}

func islU(name string) uint64 {
	b := isl(name)
	return binary.BigEndian.Uint64(b[:])
}

func edge(from, to string, eType uint8) [17]byte {
	var e [17]byte
	f := isl(from)
	t := isl(to)
	copy(e[:8], f[:])
	copy(e[8:16], t[:])
	e[16] = eType
	return e
}

func main() {
	raw, err := os.ReadFile(edgeFile)
	if err != nil { log.Fatal(err) }

	oldEdges := int(binary.BigEndian.Uint32(raw[16:20]))
	fmt.Printf("▶ edges before: %d\n", oldEdges)

	// Build ISL map từ file để kiểm tra node tồn tại
	nodeISLs := buildNodeISLs(raw)
	fmt.Printf("  known nodes: %d\n", len(nodeISLs))

	type E struct{ from, to string; t uint8 }
	edges := []E{
		// ── ML Core cluster ──────────────────────────────────────────────
		{"SUPERVISED_LEARNING",   "MACHINE_LEARNING",      OpMember},
		{"UNSUPERVISED_LEARNING",  "MACHINE_LEARNING",      OpMember},
		{"REINFORCEMENT_LEARNING", "MACHINE_LEARNING",      OpMember},
		{"TRANSFER_LEARNING",      "MACHINE_LEARNING",      OpMember},
		{"META_LEARNING",          "MACHINE_LEARNING",      OpMember},
		{"SELF_SUPERVISED",        "UNSUPERVISED_LEARNING", OpSimilar},
		{"FEDERATED_LEARNING",     "MACHINE_LEARNING",      OpMember},
		{"SUPERVISED_LEARNING",    "GRADIENT_DESCENT",      OpCompose},
		{"SUPERVISED_LEARNING",    "LOSS_FUNCTION",         OpCompose},

		// ── Deep Learning cluster ─────────────────────────────────────────
		{"TRANSFORMER",           "ATTENTION_MECHANISM",    OpCompose},
		{"TRANSFORMER",           "LLM",                    OpMember},
		{"TRANSFORMER",           "DEEP_LEARNING",          OpMember},
		{"CNN",                   "DEEP_LEARNING",          OpMember},
		{"RNN",                   "DEEP_LEARNING",          OpMember},
		{"GAN",                   "DEEP_LEARNING",          OpMember},
		{"VAE",                   "DEEP_LEARNING",          OpMember},
		{"DIFFUSION_MODEL",       "DEEP_LEARNING",          OpMember},
		{"GRAPH_NEURAL_NET",      "DEEP_LEARNING",          OpMember},
		{"ATTENTION_MECHANISM",   "TRANSFORMER",            OpCompose},
		{"CNN",                   "COMPUTER_VISION",        OpCompose},
		{"RNN",                   "NLP",                    OpCompose},

		// ── LLM cluster ───────────────────────────────────────────────────
		{"LLM",                   "TRANSFORMER",            OpCompose},
		{"RLHF",                  "LLM",                    OpCompose},
		{"RAG",                   "LLM",                    OpCompose},
		{"PROMPT_ENGINEERING",    "LLM",                    OpCompose},
		{"HALLUCINATION",         "LLM",                    OpMember},
		{"ALIGNMENT",             "LLM",                    OpCompose},
		{"EMERGENT_ABILITIES",    "LLM",                    OpMember},
		{"RLHF",                  "REINFORCEMENT_LEARNING", OpCompose},

		// ── Optimization cluster ──────────────────────────────────────────
		{"GRADIENT_DESCENT",      "BACKPROPAGATION",        OpCompose},
		{"BACKPROPAGATION",       "DEEP_LEARNING",          OpCompose},
		{"REGULARIZATION",        "MACHINE_LEARNING",       OpCompose},
		{"LOSS_FUNCTION",         "GRADIENT_DESCENT",       OpCompose},
		{"SCALING_LAW",           "LLM",                    OpMember},
		{"HYPERPARAMETER",        "MACHINE_LEARNING",       OpCompose},

		// ── Representation cluster ────────────────────────────────────────
		{"EMBEDDING",             "NLP",                    OpCompose},
		{"EMBEDDING",             "TRANSFORMER",            OpCompose},
		{"LATENT_SPACE",          "VAE",                    OpCompose},
		{"LATENT_SPACE",          "DIFFUSION_MODEL",        OpCompose},
		{"CONTRASTIVE_LEARNING",  "SELF_SUPERVISED",        OpCompose},
		{"DIMENSIONALITY",        "UNSUPERVISED_LEARNING",  OpCompose},

		// ── AI Safety cluster ─────────────────────────────────────────────
		{"INTERPRETABILITY",      "ALIGNMENT",              OpCompose},
		{"ROBUSTNESS",            "ALIGNMENT",              OpCompose},
		{"FAIRNESS_ML",           "ALIGNMENT",              OpCompose},
		{"SAFETY_AI",             "ALIGNMENT",              OpCompose},
		{"ALIGNMENT",             "SAFETY_AI",              OpCompose},
		{"HALLUCINATION",         "INTERPRETABILITY",       OpSimilar},

		// ── Neuroscience cluster ──────────────────────────────────────────
		{"NEURON",                "SYNAPSE",                OpCompose},
		{"SYNAPSE",               "NEUROPLASTICITY",        OpCompose},
		{"NEUROPLASTICITY",       "HEBBIAN_LEARNING",       OpEquiv},
		{"HIPPOCAMPUS",           "LONG_TERM_MEMORY",       OpCompose},
		{"HIPPOCAMPUS",           "NEUROPLASTICITY",        OpCompose},
		{"PREFRONTAL_CORTEX",     "WORKING_MEMORY",         OpCompose},
		{"PREFRONTAL_CORTEX",     "EXECUTIVE_FUNCTION",     OpCompose},
		{"AMYGDALA",              "EMOTION_COG",            OpCompose},
		{"BASAL_GANGLIA",         "DOPAMINE",               OpCompose},
		{"BASAL_GANGLIA",         "REINFORCEMENT_LEARNING", OpSimilar},
		{"CEREBRAL_CORTEX",       "NEURAL_CODING",          OpCompose},
		{"DOPAMINE",              "REINFORCEMENT_LEARNING", OpSimilar},
		{"SEROTONIN",             "EMOTION_COG",            OpCompose},

		// ── Cognitive Science cluster ─────────────────────────────────────
		{"WORKING_MEMORY",        "ATTENTION_COG",          OpCompose},
		{"LONG_TERM_MEMORY",      "HIPPOCAMPUS",            OpCompose},
		{"COGNITIVE_BIAS",        "DECISION_MAKING",        OpCompose},
		{"ATTENTION_COG",         "PERCEPTION",             OpCompose},
		{"EXECUTIVE_FUNCTION",    "PREFRONTAL_CORTEX",      OpCompose},
		{"CONSCIOUSNESS_COG",     "NEURAL_CODING",          OpCompose},
		{"EMOTION_COG",           "AMYGDALA",               OpCompose},
		{"LANGUAGE_COGNITION",    "NLP",                    OpSimilar},

		// ── Computational Neuro cluster ───────────────────────────────────
		{"PREDICTIVE_CODING",     "NEURAL_CODING",          OpCompose},
		{"HEBBIAN_LEARNING",      "NEUROPLASTICITY",        OpEquiv},
		{"SPIKING_NEURAL_NET",    "NEUROMORPHIC",           OpCompose},
		{"NEURAL_OSCILLATION",    "NEURAL_CODING",          OpCompose},
		{"HEBBIAN_LEARNING",      "SUPERVISED_LEARNING",    OpSimilar},

		// ── AI↔Brain bridges ─────────────────────────────────────────────
		{"NEUROMORPHIC",          "DEEP_LEARNING",          OpSimilar},
		{"BCI",                   "NEURAL_CODING",          OpCompose},
		{"COGNITIVE_ARCHITECTURE","AGI",                    OpCompose},
		{"AGI",                   "ALIGNMENT",              OpCompose},
		{"EMBODIED_AI",           "REINFORCEMENT_LEARNING", OpCompose},
		{"WORLD_MODEL",           "REINFORCEMENT_LEARNING", OpCompose},
		{"WORLD_MODEL",           "COGNITIVE_ARCHITECTURE", OpSimilar},
		{"NEUROSYMBOLIC",         "SYMBOLIC_AI",            OpCompose},
		{"NEUROSYMBOLIC",         "DEEP_LEARNING",          OpCompose},
		{"MEMORY_ARCHITECTURE",   "LONG_TERM_MEMORY",       OpSimilar},
		{"MEMORY_ARCHITECTURE",   "TRANSFORMER",            OpCompose},

		// ── Data Science cluster ──────────────────────────────────────────
		{"BAYESIAN_ML",           "MACHINE_LEARNING",       OpMember},
		{"ENSEMBLE_METHOD",       "SUPERVISED_LEARNING",    OpCompose},
		{"ANOMALY_DETECTION",     "UNSUPERVISED_LEARNING",  OpCompose},
		{"TIME_SERIES_ML",        "RNN",                    OpCompose},
		{"NLP",                   "TRANSFORMER",            OpCompose},
		{"COMPUTER_VISION",       "CNN",                    OpCompose},
		{"MULTIMODAL_AI",         "TRANSFORMER",            OpCompose},
		{"MULTIMODAL_AI",         "COMPUTER_VISION",        OpCompose},
		{"MULTIMODAL_AI",         "NLP",                    OpCompose},

		// ── Systems cluster ───────────────────────────────────────────────
		{"GPU_COMPUTING",         "DEEP_LEARNING",          OpCompose},
		{"DISTRIBUTED_TRAINING",  "DEEP_LEARNING",          OpCompose},
		{"MODEL_COMPRESSION",     "DEEP_LEARNING",          OpCompose},
		{"CONTINUAL_LEARNING",    "MACHINE_LEARNING",       OpMember},
		{"ACTIVE_LEARNING",       "SUPERVISED_LEARNING",    OpCompose},
		{"CAUSALITY_ML",          "MACHINE_LEARNING",       OpCompose},
		{"SYMBOLIC_AI",           "AGI",                    OpSimilar},
	}

	// Build edge bytes — chỉ thêm nếu cả 2 nodes tồn tại
	var newEdgeBytes []byte
	added := 0
	skipped := 0
	for _, e := range edges {
		fromU := islU(e.from)
		toU   := islU(e.to)
		if _, ok := nodeISLs[fromU]; !ok {
			skipped++
			continue
		}
		if _, ok := nodeISLs[toU]; !ok {
			skipped++
			continue
		}
		b := edge(e.from, e.to, e.t)
		newEdgeBytes = append(newEdgeBytes, b[:]...)
		added++
	}

	fmt.Printf("  adding %d edges (%d skipped — nodes not found)\n", added, skipped)

	// File structure: [node_section][old_edges]
	// Thêm new edges vào sau old edges, cập nhật nedges
	newRaw := append(raw, newEdgeBytes...)
	newEdgeCount := uint32(oldEdges + added)
	binary.BigEndian.PutUint32(newRaw[16:20], newEdgeCount)

	// Recalc sha256
	liEnd := 64 + 9*24
	h := sha256.Sum256(newRaw[liEnd:])
	copy(newRaw[32:64], h[:])

	if err := os.WriteFile(edgeFile, newRaw, 0644); err != nil {
		log.Fatal(err)
	}
	fmt.Printf("✅ edges: %d → %d\n", oldEdges, newEdgeCount)
}

// buildNodeISLs đọc ISL của tất cả nodes từ file
func buildNodeISLs(raw []byte) map[uint64]string {
	result := map[uint64]string{}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*17
	liEnd := 64 + 9*24

	off := liEnd
	for off+20 < edgeStart {
		if raw[off] != 'N' || raw[off+1] != 'D' {
			off++
			continue
		}
		base := off; off += 2
		off++ // layer
		islBytes := raw[off : off+8]; off += 8
		islU := binary.BigEndian.Uint64(islBytes)
		off += 4 // flags
		dl := int(binary.BigEndian.Uint32(raw[off : off+4])); off += 4
		nl := int(raw[off]); off++
		end := off + dl + nl
		if dl > 4096 || nl > 200 || end > len(raw) {
			off = base + 1
			continue
		}
		// name nằm SAU dna
		name := string(raw[off+dl : end])
		result[islU] = name
		off = end
	}
	return result
}
