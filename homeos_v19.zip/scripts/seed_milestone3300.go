//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── TRÍ TUỆ NHÂN TẠO NÂNG CAO (AI3_) ────────────────────
		{"AI3_MULTIMODAL",   3,`label=AI đa phương thức|desc=multimodal AI GPT-4V Gemini image audio text video understanding CLIP DALL-E Sora|vi=AI đa phương thức,multimodal AI|en=multimodal AI|zh=多模态AI`},
		{"AI3_FINETUNE",     3,`label=tinh chỉnh mô hình|desc=fine-tuning LoRA QLoRA RLHF instruction tuning domain adaptation PEFT parameter efficient|vi=tinh chỉnh mô hình,fine-tuning|en=fine-tuning|zh=模型微调`},
		{"AI3_HALLUCINATION",3,`label=ảo giác AI|desc=AI hallucination factual error confabulation sycophancy grounding RAG mitigation benchmark|vi=ảo giác AI,AI hallucination|en=AI hallucination|zh=AI幻觉`},
		{"AI3_SAFETY",       3,`label=an toàn AI|desc=AI safety alignment RLHF Constitutional AI red teaming jailbreak Anthropic OpenAI|vi=an toàn AI,AI safety|en=AI safety|zh=AI安全`},
		{"AI3_EDGE_AI",      3,`label=AI biên|desc=edge AI on-device inference TFLite ONNX quantization pruning NPU Qualcomm Apple Neural Engine|vi=AI biên,edge AI|en=edge AI|zh=边缘AI`},

		// ── KINH TẾ HÀNH VI (BEH_ECON2_) ─────────────────────────
		{"BEH_ECON2_LOSS_AV",3,`label=lo sợ mất mát|desc=loss aversion Kahneman Tversky prospect theory losses loom larger 2:1 ratio framing|vi=lo sợ mất mát,loss aversion|en=loss aversion|zh=损失厌恶`},
		{"BEH_ECON2_STATUS_QUO",3,`label=thiên kiến hiện trạng|desc=status quo bias endowment effect inertia default option switching cost Samuelson|vi=thiên kiến hiện trạng,status quo bias|en=status quo bias|zh=现状偏见`},
		{"BEH_ECON2_HERD",   3,`label=hành vi bầy đàn|desc=herd behavior information cascade social proof bank run stock bubble fashion|vi=hành vi bầy đàn,herd behavior|en=herd behavior|zh=羊群效应`},
		{"BEH_ECON2_PRESENT_BIAS",3,`label=thiên kiến hiện tại|desc=present bias hyperbolic discounting procrastination savings commitment device|vi=thiên kiến hiện tại,present bias|en=present bias|zh=当下偏见`},

		// ── THẦN KINH HỌC BỔ SUNG (NEURO3_) ─────────────────────
		{"NEURO3_NEUROPLAST",3,`label=tính mềm dẻo thần kinh|desc=neuroplasticity Hebb's rule LTP LTD experience-dependent synapse pruning adult learning|vi=tính mềm dẻo thần kinh,neuroplasticity|en=neuroplasticity|zh=神经可塑性`},
		{"NEURO3_MIRROR",    3,`label=tế bào thần kinh gương|desc=mirror neuron Rizzolatti imitation empathy autism theory of mind observation action|vi=tế bào thần kinh gương,mirror neuron|en=mirror neuron|zh=镜像神经元`},
		{"NEURO3_PAIN",      3,`label=đau và não bộ|desc=pain gate control theory Melzack Wall chronic pain placebo opioid nociception|vi=đau và não bộ,pain neuroscience|en=pain neuroscience|zh=疼痛神经科学`},

		// ── KHOA HỌC VŨ TRỤ BỔ SUNG (COSMO2_) ───────────────────
		{"COSMO2_CMB",       3,`label=bức xạ nền vũ trụ|desc=CMB cosmic microwave background 2.7K Penzias Wilson 1965 Big Bang fingerprint WMAP Planck|vi=bức xạ nền vũ trụ,CMB|en=CMB|zh=宇宙微波背景辐射`},
		{"COSMO2_DARK_ENERGY",3,`label=năng lượng tối|desc=dark energy cosmological constant Lambda accelerating expansion 68% universe Hubble tension|vi=năng lượng tối,dark energy|en=dark energy|zh=暗能量`},
		{"COSMO2_INFLATION",  3,`label=lạm phát vũ trụ|desc=cosmic inflation Alan Guth 1980 exponential expansion 10^-36s horizon flatness monopole problems|vi=lạm phát vũ trụ,cosmic inflation|en=cosmic inflation|zh=宇宙暴胀`},

		// ── HÓA HỌC HỮU CƠ BỔ SUNG (ORGCHEM2_) ──────────────────
		{"ORGCHEM2_ALCOHOL",  3,`label=alcohol hữu cơ|desc=alcohol ethanol methanol functional group OH fermentation distillation proof ABV|vi=alcohol hữu cơ,alcohol|en=organic alcohol|zh=醇`},
		{"ORGCHEM2_ACID",     3,`label=axit hữu cơ|desc=carboxylic acid acetic acid citric acid amino acid COOH pKa ester formation|vi=axit hữu cơ,carboxylic acid|en=carboxylic acid|zh=羧酸`},
		{"ORGCHEM2_BENZENE",  3,`label=benzene và vòng thơm|desc=benzene aromatic Kekulé ring delocalized pi electrons resonance Hückel rule 4n+2|vi=benzene vòng thơm,aromatic|en=benzene aromatic|zh=苯环芳香族`},

		// ── KIẾN TRÚC MÁY TÍNH (COMPARCH_) ──────────────────────
		{"COMPARCH_CPU",      3,`label=kiến trúc CPU|desc=CPU architecture pipeline ALU registers fetch decode execute RISC CISC Intel AMD ARM|vi=kiến trúc CPU,CPU|en=CPU architecture|zh=CPU架构`},
		{"COMPARCH_CACHE",    3,`label=bộ nhớ cache|desc=CPU cache L1 L2 L3 spatial temporal locality hit miss ratio write-back write-through|vi=bộ nhớ cache,CPU cache|en=CPU cache|zh=CPU缓存`},
		{"COMPARCH_OS_KERNEL",3,`label=nhân hệ điều hành|desc=OS kernel system call process thread scheduling virtual memory paging Linux monolithic|vi=nhân hệ điều hành,kernel|en=OS kernel|zh=操作系统内核`},
		{"COMPARCH_GPU",      3,`label=GPU|desc=GPU CUDA parallel processing NVIDIA AMD shader VRAM deep learning training inference|vi=GPU|en=GPU|zh=GPU`},

		// ── ĐỊA CHÍNH TRỊ HIỆN ĐẠI (GEOPOLIT_) ──────────────────
		{"GEOPOLIT_HEGEMONY", 3,`label=bá quyền|desc=hegemony US unipolar Gramsci soft hard power decline multipolarity Thucydides trap|vi=bá quyền,hegemony|en=hegemony|zh=霸权`},
		{"GEOPOLIT_BELT_ROAD",3,`label=Vành đai Con đường|desc=Belt Road Initiative BRI China infrastructure 150 countries debt trap diplomacy port|vi=Vành đai Con đường,BRI|en=Belt Road Initiative|zh=一带一路`},
		{"GEOPOLIT_NATO",     3,`label=NATO|desc=North Atlantic Treaty Organization collective defense Article 5 expansion Russia Ukraine Finland|vi=NATO|en=NATO|zh=北约`},
		{"GEOPOLIT_INDO_PAC", 3,`label=Ấn Độ Dương-Thái Bình Dương|desc=Indo-Pacific QUAD AUKUS US China contest trade route South China Sea Taiwan|vi=Ấn Độ Dương-Thái Bình Dương,Indo-Pacific|en=Indo-Pacific|zh=印太地区`},

		// ── VĂN HÓA NHẬT BẢN BỔ SUNG (JPCULTURE_) ───────────────
		{"JPCULTURE_ANIME",   3,`label=anime|desc=anime Japanese animation Miyazaki Studio Ghibli Akira One Piece Attack on Titan global|vi=anime|en=anime|zh=动画`},
		{"JPCULTURE_MANGA2",  3,`label=manga thể loại|desc=manga shonen shojo seinen josei isekai sports romance Osamu Tezuka god of manga|vi=manga thể loại,manga genre|en=manga genre|zh=漫画类型`},
		{"JPCULTURE_BUSHIDO", 3,`label=Bushido|desc=Bushido code of samurai loyalty honor integrity courage rectitude benevolence Yamamoto Tsunetomo|vi=Bushido,Võ sĩ đạo|en=Bushido|zh=武士道`},
		{"JPCULTURE_TEA_CEREM",3,`label=trà đạo Nhật Bản|desc=Japanese tea ceremony chado Sen no Rikyu wabi-sabi 四規七則 tatami chakai|vi=trà đạo Nhật Bản,tea ceremony|en=Japanese tea ceremony|zh=日本茶道`},

		// ── TRIẾT HỌC ĐÔNG PHƯƠNG BỔ SUNG (EASPHIL2_) ───────────
		{"EASPHIL2_MOHISM",  3,`label=Mặc gia|desc=Mohism Mo Tzu universal love utilitarian jian ai anti-war Chinese philosophy 5th BCE|vi=Mặc gia,Mohism|en=Mohism|zh=墨家`},
		{"EASPHIL2_LEGALISM",3,`label=Pháp gia|desc=Legalism Han Fei Qin dynasty law punishment state power Shang Yang strict governance|vi=Pháp gia,Legalism|en=Legalism China|zh=法家`},
		{"EASPHIL2_ADVAITA", 3,`label=Advaita Vedanta|desc=Advaita non-duality Shankaracharya Brahman Atman maya consciousness Indian philosophy|vi=Advaita Vedanta|en=Advaita Vedanta|zh=不二论`},

		// ── VẬT LÝ THIÊN VĂN (ASTROPHYS_) ───────────────────────
		{"ASTROPHYS_GRAVI_WAVE",3,`label=sóng hấp dẫn|desc=gravitational waves LIGO Virgo 2015 detection binary black hole GW150914 Nobel 2017|vi=sóng hấp dẫn,gravitational waves|en=gravitational waves|zh=引力波`},
		{"ASTROPHYS_CHANDRASEK",3,`label=giới hạn Chandrasekhar|desc=Chandrasekhar limit 1.44 solar masses white dwarf neutron star collapse Nobel 1983|vi=giới hạn Chandrasekhar,Chandrasekhar limit|en=Chandrasekhar limit|zh=钱德拉塞卡极限`},
		{"ASTROPHYS_HAWKING",3,`label=bức xạ Hawking|desc=Hawking radiation Stephen Hawking black hole thermal emission temperature entropy information|vi=bức xạ Hawking,Hawking radiation|en=Hawking radiation|zh=霍金辐射`},

		// ── KỸ THUẬT ĐIỆN TỬ (ELECENG_) ──────────────────────────
		{"ELECENG_TRANSISTOR2",3,`label=transistor|desc=transistor BJT MOSFET FET switch amplify Bardeen Shockley Brattain 1947 Bell Labs|vi=transistor|en=transistor|zh=晶体管`},
		{"ELECENG_OPAMP",     3,`label=op-amp|desc=operational amplifier inverting non-inverting gain feedback virtual ground instrumentation|vi=op-amp,khuếch đại thuật toán|en=op-amp|zh=运算放大器`},
		{"ELECENG_ADC_DAC",   3,`label=chuyển đổi ADC/DAC|desc=ADC DAC analog digital conversion sampling Nyquist theorem resolution bits quantization|vi=chuyển đổi ADC DAC|en=ADC DAC|zh=模数转换器`},

		// ── SINH LÝ HỌC (PHYSIOLOGY_) ────────────────────────────
		{"PHYSIOLOGY_HEART2", 3,`label=sinh lý tim mạch|desc=cardiac physiology stroke volume cardiac output Frank-Starling law preload afterload|vi=sinh lý tim mạch,cardiac physiology|en=cardiac physiology|zh=心脏生理学`},
		{"PHYSIOLOGY_LUNG",   3,`label=sinh lý hô hấp|desc=pulmonary physiology tidal volume FVC FEV1 compliance surfactant alveolar gas exchange|vi=sinh lý hô hấp,pulmonary physiology|en=pulmonary physiology|zh=肺生理学`},
		{"PHYSIOLOGY_KIDNEY", 3,`label=sinh lý thận|desc=renal physiology nephron GFR filtration reabsorption secretion acid-base balance|vi=sinh lý thận,renal physiology|en=renal physiology|zh=肾脏生理学`},

		// ── PHÁT TRIỂN ỨNG DỤNG (APPDEV_) ───────────────────────
		{"APPDEV_MOBILE",     3,`label=phát triển ứng dụng di động|desc=mobile development iOS Android Swift Kotlin React Native Flutter cross-platform|vi=phát triển ứng dụng di động,mobile dev|en=mobile development|zh=移动应用开发`},
		{"APPDEV_BACKEND",    3,`label=phát triển backend|desc=backend development REST GraphQL gRPC API database ORM authentication JWT Redis|vi=phát triển backend,backend dev|en=backend development|zh=后端开发`},
		{"APPDEV_CLOUD_NATIVE",3,`label=cloud native|desc=cloud native 12-factor app containerization Kubernetes Helm service mesh Istio GitOps|vi=cloud native|en=cloud native|zh=云原生`},

		// ── ĐỊA LÝ VIỆT NAM BỔ SUNG (VNGEO_) ───────────────────
		{"VNGEO_HIGHLANDS",   3,`label=Tây Nguyên|desc=Tây Nguyên 5 tỉnh cà phê cao su Đắk Lắk Gia Lai Kon Tum Lâm Đồng bào dân tộc|vi=Tây Nguyên,Central Highlands|en=Central Highlands Vietnam|zh=越南中部高原`},
		{"VNGEO_RED_RIVER",   3,`label=sông Hồng|desc=sông Hồng Red River 1149km Vân Nam Hà Nội ra biển châu thổ phù sa lúa nước|vi=sông Hồng,Red River|en=Red River Vietnam|zh=红河`},
		{"VNGEO_MEKONG",      3,`label=sông Mê Kông|desc=Mê Kông Mekong 4909km Tây Tạng 6 quốc gia ĐBSCL thủy điện Trung Quốc hạn|vi=sông Mê Kông,Mekong River|en=Mekong River|zh=湄公河`},

		// ── TÂM LÝ XÃ HỘI (SOC_PSYCH_) ──────────────────────────
		{"SOC_PSYCH_CONFORM", 3,`label=tuân theo nhóm|desc=conformity Asch experiment group pressure Milgram obedience authority 65% shock|vi=tuân theo nhóm,conformity|en=conformity|zh=从众`},
		{"SOC_PSYCH_COGDIS",  3,`label=bất hòa nhận thức|desc=cognitive dissonance Festinger 1957 belief action conflict rationalization self-justification|vi=bất hòa nhận thức,cognitive dissonance|en=cognitive dissonance|zh=认知失调`},
		{"SOC_PSYCH_FUNDAMENTAL",3,`label=lỗi quy kết căn bản|desc=fundamental attribution error Ross situation disposition over-attribute personality ignore context|vi=lỗi quy kết căn bản,fundamental attribution error|en=fundamental attribution error|zh=基本归因错误`},
		{"SOC_PSYCH_INGROUP", 3,`label=nhóm nội và ngoại|desc=in-group out-group bias prejudice Tajfel social identity theory minimal group paradigm|vi=nhóm nội và ngoại,in-group out-group|en=in-group out-group|zh=内外群体`},

		// ── ĐIỀU TRỊ TÂM LÝ (PSYCHOTHER_) ───────────────────────
		{"PSYCHOTHER_CBT",    3,`label=liệu pháp nhận thức hành vi|desc=CBT Cognitive Behavioral Therapy Beck Ellis thoughts feelings behaviors schema anxiety|vi=liệu pháp nhận thức hành vi,CBT|en=CBT|zh=认知行为疗法`},
		{"PSYCHOTHER_DBT",    3,`label=liệu pháp hành vi biện chứng|desc=DBT Dialectical Behavior Therapy Linehan borderline distress tolerance mindfulness skills|vi=liệu pháp hành vi biện chứng,DBT|en=DBT|zh=辩证行为疗法`},
		{"PSYCHOTHER_MINDFULNESS",3,`label=chánh niệm|desc=mindfulness MBSR Jon Kabat-Zinn present moment non-judgment meditation stress anxiety|vi=chánh niệm,mindfulness|en=mindfulness|zh=正念`},

		// ── LỊCH SỬ VIỆT NAM HIỆN ĐẠI (VNMODHIST_) ──────────────
		{"VNMODHIST_DIENBIEN",3,`label=Điện Biên Phủ|desc=Điện Biên Phủ 1954 Võ Nguyên Giáp 57 ngày kết thúc Pháp Đông Dương hội nghị Geneva|vi=Điện Biên Phủ,Dien Bien Phu|en=Dien Bien Phu|zh=奠边府战役`},
		{"VNMODHIST_REUNION", 3,`label=thống nhất Việt Nam 1975|desc=30/4/1975 giải phóng Sài Gòn thống nhất nước Việt Nam CHXHCNVN Nam Bắc|vi=thống nhất Việt Nam 1975,Vietnam reunification|en=Vietnam reunification 1975|zh=越南统一1975`},
		{"VNMODHIST_DOIMO",   3,`label=Đổi Mới kinh tế|desc=Đổi Mới 1986 kinh tế thị trường FDI tăng trưởng đói nghèo giảm hội nhập quốc tế|vi=Đổi Mới kinh tế,Doi Moi|en=Doi Moi Vietnam|zh=越南革新开放`},

		// ── KHOA HỌC NÃO BỘ (BRAINSCI_) ─────────────────────────
		{"BRAINSCI_DEFAULT",  3,`label=mạng lưới mặc định|desc=default mode network DMN daydreaming mind-wandering self-referential medial prefrontal|vi=mạng lưới mặc định,default mode network|en=default mode network|zh=默认模式网络`},
		{"BRAINSCI_REWARD",   3,`label=hệ thống phần thưởng|desc=reward system nucleus accumbens VTA dopamine motivation addiction reinforcement learning|vi=hệ thống phần thưởng,reward system|en=reward system brain|zh=奖励系统`},
		{"BRAINSCI_DECISION", 3,`label=ra quyết định não bộ|desc=decision making prefrontal orbitofrontal somatic marker Damasio dual process fast slow|vi=ra quyết định não bộ,brain decision making|en=brain decision making|zh=大脑决策`},

		// ── SINH THÁI HỌC ỨNG DỤNG (APPECO_) ────────────────────
		{"APPECO_INVASIVE",   3,`label=loài xâm lấn|desc=invasive species carp lionfish kudzu zebra mussel economic damage 120 tỷ USD/năm|vi=loài xâm lấn,invasive species|en=invasive species|zh=入侵物种`},
		{"APPECO_BIODIVERSITY_HOTSPOT",3,`label=điểm nóng đa dạng sinh học|desc=biodiversity hotspot Myers 36 regions Mesoamerica Madagascar Western Ghats threat endemic|vi=điểm nóng đa dạng sinh học,biodiversity hotspot|en=biodiversity hotspot|zh=生物多样性热点`},
		{"APPECO_TROPHIC",    3,`label=chuỗi thức ăn|desc=food chain trophic level producer primary secondary tertiary consumer apex predator energy 10%|vi=chuỗi thức ăn,food chain|en=food chain|zh=食物链`},

		// ── TOÁN XÁC SUẤT THỐNG KÊ BỔ SUNG (STATS2_) ────────────
		{"STATS2_BAYES",      3,`label=định lý Bayes nâng cao|desc=Bayesian inference posterior prior likelihood updating belief MCMC Stan PyMC model|vi=định lý Bayes nâng cao,Bayesian|en=Bayesian inference|zh=贝叶斯推断`},
		{"STATS2_HYPOTHESIS", 3,`label=kiểm định giả thuyết|desc=hypothesis testing p-value null alternative t-test ANOVA chi-square effect size power|vi=kiểm định giả thuyết,hypothesis testing|en=hypothesis testing|zh=假设检验`},
		{"STATS2_REGRESSION", 3,`label=hồi quy thống kê|desc=regression OLS multivariate logistic R² residuals heteroscedasticity multicollinearity|vi=hồi quy thống kê,regression|en=statistical regression|zh=统计回归`},

		// ── KINH TẾ CHÍNH TRỊ (POL_ECON_) ───────────────────────
		{"POL_ECON_MARX",     3,`label=kinh tế chính trị Marx|desc=Marxist political economy surplus value capital exploitation class struggle historical materialism|vi=kinh tế chính trị Marx,Marxism|en=Marxist political economy|zh=马克思政治经济学`},
		{"POL_ECON_KEYNES",   3,`label=kinh tế Keynes|desc=Keynesian economics aggregate demand fiscal stimulus multiplier liquidity trap 1936 General Theory|vi=kinh tế Keynes,Keynesian|en=Keynesian economics|zh=凯恩斯经济学`},
		{"POL_ECON_NEOLIBERAL",3,`label=chủ nghĩa tân tự do|desc=neoliberalism Washington Consensus Thatcher Reagan privatization deregulation free market IMF|vi=chủ nghĩa tân tự do,neoliberalism|en=neoliberalism|zh=新自由主义`},

		// ── THIẾT KẾ ĐỒ HỌA (GRAPHIC2_) ─────────────────────────
		{"GRAPHIC2_COLOR",    3,`label=lý thuyết màu sắc|desc=color theory Itten wheel RGB CMYK primary secondary complementary warm cool saturation|vi=lý thuyết màu sắc,color theory|en=color theory|zh=色彩理论`},
		{"GRAPHIC2_TYPO",     3,`label=typography|desc=typography typeface serif sans-serif kerning leading tracking hierarchy readability Helvetica|vi=typography,chữ học|en=typography|zh=字体排印`},
		{"GRAPHIC2_LOGO",     3,`label=thiết kế logo|desc=logo design wordmark lettermark emblem combination mark Nike Apple McDonald golden ratio|vi=thiết kế logo,logo design|en=logo design|zh=标志设计`},

		// ── VĂN HỌC THẾ GIỚI BỔ SUNG (LIT4_) ────────────────────
		{"LIT4_DOSTOEVSKY",   3,`label=Dostoevsky|desc=Crime Punishment Brothers Karamazov psyche suffering redemption Russian Orthodox existential|vi=Dostoevsky|en=Dostoevsky|zh=陀思妥耶夫斯基`},
		{"LIT4_GABRIEL",      3,`label=Gabriel García Márquez|desc=magical realism Cien años soledad One Hundred Years Solitude Nobel 1982 Macondo|vi=García Márquez|en=Garcia Marquez|zh=加西亚·马尔克斯`},
		{"LIT4_SHAKESPEARE2", 3,`label=Shakespeare tác phẩm|desc=Hamlet Macbeth Othello King Lear tragedy comedy sonnet Globe Theatre Elizabethan|vi=Shakespeare tác phẩm,Shakespeare works|en=Shakespeare works|zh=莎士比亚作品`},
		{"LIT4_POETRY_FORM",  3,`label=thể thơ|desc=poetry form sonnet haiku villanelle ballad free verse iambic pentameter meter rhyme|vi=thể thơ,poetry form|en=poetry form|zh=诗歌形式`},

		// ── KINH TẾ VIỆT NAM BỔ SUNG (VNECON2_) ─────────────────
		{"VNECON2_FDI",       3,`label=FDI Việt Nam|desc=FDI Vietnam 18 tỷ USD 2023 Samsung LG Intel manufacturing hub electronics textile|vi=FDI Việt Nam,Vietnam FDI|en=Vietnam FDI|zh=越南外资`},
		{"VNECON2_STARTUPS",  3,`label=startup Việt Nam|desc=startup Vietnam unicorn VNG MoMo Momo Sky Mavis Axie VNPay fintech ecosystem|vi=startup Việt Nam,Vietnam startups|en=Vietnam startups|zh=越南创业公司`},
		{"VNECON2_TOURISM",   3,`label=du lịch Việt Nam|desc=tourism Vietnam 12 triệu khách 2023 Đà Nẵng Hội An Hạ Long GDP 7% UNWTO|vi=du lịch Việt Nam,Vietnam tourism|en=Vietnam tourism|zh=越南旅游业`},

		// ── KHOA HỌC KHÍ HẬU (CLIM2_) ───────────────────────────
		{"CLIM2_SEA_LEVEL",   3,`label=mực nước biển dâng|desc=sea level rise thermal expansion ice melt IPCC 1m 2100 Bangladesh Vietnam Netherlands|vi=mực nước biển dâng,sea level rise|en=sea level rise|zh=海平面上升`},
		{"CLIM2_HEATWAVE",    3,`label=sóng nhiệt|desc=heatwave wet bulb temperature 35°C survival limit urban heat island health mortality|vi=sóng nhiệt,heatwave|en=heatwave|zh=热浪`},
		{"CLIM2_PERMAFROST",  3,`label=đất đóng băng vĩnh cửu|desc=permafrost Siberia Alaska methane release thaw positive feedback loop carbon|vi=đất đóng băng vĩnh cửu,permafrost|en=permafrost|zh=永久冻土`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
	}
	fmt.Printf("\n✚ %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes\n", nn)
	if nn >= 3300 { fmt.Println("🎉 MILESTONE 3300!") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
