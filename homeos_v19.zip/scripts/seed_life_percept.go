//go:build ignore

// scripts/seed_life_percept.go
//
// Seed L3 Life + L6 Perception nodes còn thiếu vào homeos.olang.
// Chỉ thêm nodes CHƯA TỒN TẠI trong file — không ghi đè.
//
// L3 Life: sinh vật, cảm xúc, hành động sống
// L6 Perception: giác quan, màu sắc, kích thước, trạng thái
//
// DNA format: "label=...|desc=...|vi=..."
// Chạy: go run scripts/seed_life_percept.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"strings"
)

const seedPath = "homeos.olang"

type seedDef struct {
	layer uint8
	name  string
	label string
	desc  string
	vi    string // aliases tiếng Việt
}

var lifeDefs = []seedDef{
	// ── L3 Life — sinh vật ──────────────────────────────────────
	{3, "LIFE_ANIMAL",   "động vật",   "sinh vật đa bào có thể di chuyển và cảm nhận",              "thú,vật,animal,con vật"},
	{3, "LIFE_BIRD",     "chim",       "động vật có lông vũ hai cánh đẻ trứng máu nóng",            "chim chóc,bird,cánh"},
	{3, "LIFE_FISH",     "cá",         "động vật sống dưới nước thở bằng mang có vây",              "cá mú,fish,dưới nước"},
	{3, "LIFE_CAT",      "con mèo",    "động vật có vú thuần hóa kêu meo độc lập",                  "mèo,miu,kitty,cat,meow"},
	{3, "LIFE_TREE",     "cây",        "thực vật lớn thân gỗ cứng cành lá rễ ăn sâu đất",          "cây gỗ,thân cây,tree,cây lớn"},
	{3, "LIFE_BRAIN",    "não",        "cơ quan điều khiển trung tâm nơi diễn ra tư duy",           "bộ não,não bộ,brain,suy nghĩ"},
	{3, "LIFE_EYE",      "mắt",        "cơ quan thị giác cảm nhận ánh sáng hình ảnh",              "đôi mắt,eye,nhìn,thị giác"},
	// ── L3 Life — cảm xúc ───────────────────────────────────────
	{3, "LIFE_FEAR",     "sợ hãi",     "cảm xúc cảnh báo nguy hiểm kích hoạt phản ứng chiến-chạy", "sợ,lo sợ,fear,kinh hãi"},
	{3, "LIFE_JOY",      "vui",        "cảm xúc tích cực hạnh phúc thỏa mãn khi đạt điều tốt",     "vui vẻ,hạnh phúc,joy,vui mừng"},
	{3, "LIFE_SADNESS",  "buồn",       "cảm xúc tiêu cực khi mất mát thất vọng cô đơn",            "buồn bã,sad,u buồn,đau lòng"},
	{3, "LIFE_ANGER",    "tức giận",   "cảm xúc phản ứng mạnh trước bất công tổn thương",          "tức,giận,angry,bực bội"},
	{3, "LIFE_SURPRISE", "ngạc nhiên", "phản ứng nhận thức trước sự kiện bất ngờ ngoài dự đoán",   "bất ngờ,surprise,shock"},
	{3, "LIFE_DISGUST",  "ghê tởm",    "cảm xúc đẩy xa vật gây hại bệnh tật mùi hôi",             "gớm,disgusting,disgusted"},
	{3, "LIFE_TRUST",    "tin tưởng",  "cảm giác an toàn khi giao phó cho người/vật khác",         "tin,trust,an tâm"},
	{3, "LIFE_CURIOSITY","tò mò",      "ham muốn tìm hiểu khám phá cái chưa biết",                 "tò mò,curious,khám phá"},
	// ── L3 Life — hành động ─────────────────────────────────────
	{3, "LIFE_WALK",     "đi bộ",      "di chuyển bằng chân ở tốc độ bình thường",                 "đi,walk,bước đi,đi lại"},
	{3, "LIFE_RUN",      "chạy",       "di chuyển bằng chân ở tốc độ cao",                         "chạy nhanh,run,chạy bộ"},
	{3, "LIFE_TALK",     "nói chuyện", "trao đổi thông tin bằng ngôn ngữ âm thanh",                "nói,talk,speak,giao tiếp"},
	{3, "LIFE_THINK",    "suy nghĩ",   "xử lý thông tin trong não tạo ra ý tưởng quyết định",      "think,suy,nghĩ,tư duy"},
	{3, "LIFE_GROW",     "lớn lên",    "quá trình tăng kích thước phát triển theo thời gian",       "grow,phát triển,trưởng thành"},
	{3, "LIFE_HEAL",     "chữa lành",  "quá trình phục hồi tổn thương trong cơ thể",               "heal,lành,phục hồi,bình phục"},
	{3, "LIFE_LEARN",    "học",        "tiếp thu kiến thức kỹ năng mới qua kinh nghiệm",           "học hỏi,learn,học bài,tiếp thu"},
}

var perceptDefs = []seedDef{
	// ── L6 Perception — màu sắc còn thiếu ──────────────────────
	{6, "PERCEPT_BLUE",     "màu xanh lam", "màu bầu trời đại dương bước sóng 450-495nm",      "xanh lam,xanh dương,blue,azure"},
	{6, "PERCEPT_GREEN",    "màu xanh lá",  "màu lá cây bước sóng 495-570nm",                  "xanh lá,green,lục"},
	{6, "PERCEPT_PURPLE",   "màu tím",      "màu giữa xanh lam và đỏ bước sóng 380-450nm",     "tím,purple,violet"},
	// ── L6 Perception — âm thanh ────────────────────────────────
	{6, "PERCEPT_LOUD",     "to tiếng",    "âm thanh cường độ cao trên 70 decibel",             "ồn ào,tiếng ồn,loud,noise"},
	{6, "PERCEPT_VOICE",    "giọng nói",   "âm thanh thanh quản tạo ra để giao tiếp",          "tiếng nói,voice,giọng"},
	// ── L6 Perception —촉각 / xúc giác ─────────────────────────
	{6, "PERCEPT_HARD",     "cứng",        "bề mặt không biến dạng khi tác lực như đá thép",   "hard,cứng rắn"},
	{6, "PERCEPT_SMOOTH",   "nhẵn mịn",    "bề mặt không gờ lồi lõm ma sát thấp",              "mịn,smooth,mượt"},
	{6, "PERCEPT_ROUGH",    "thô ráp",     "bề mặt nhiều gờ lồi lõm ma sát cao",               "rough,nhám,ráp"},
	// ── L6 Perception — vị giác ─────────────────────────────────
	{6, "PERCEPT_SOUR",     "chua",        "vị do axit pH thấp như chanh giấm",                "sour,chua,vị chua"},
	{6, "PERCEPT_BITTER",   "đắng",        "vị do alkaloid cơ chế cảnh báo chất độc",          "bitter,đắng,vị đắng"},
	// ── L6 Perception — tốc độ / kích thước ─────────────────────
	{6, "PERCEPT_FAST",     "nhanh",       "di chuyển hoặc xảy ra với tốc độ cao",              "fast,nhanh,tốc độ cao"},
	{6, "PERCEPT_SLOW",     "chậm",        "di chuyển hoặc xảy ra với tốc độ thấp",             "slow,chậm,tốc độ thấp"},
	{6, "PERCEPT_BRIGHT",   "sáng",        "môi trường nhiều ánh sáng rõ ràng",                 "bright,sáng,rực rỡ"},
	{6, "PERCEPT_SMALL",    "nhỏ bé",      "kích thước nhỏ hơn bình thường",                   "nhỏ,bé,small,tiny"},
	{6, "PERCEPT_HEAVY",    "nặng",        "khối lượng lớn lực hấp dẫn mạnh",                  "heavy,nặng,nặng nề"},
	{6, "PERCEPT_LIGHT_W",  "nhẹ",         "khối lượng nhỏ lực hấp dẫn yếu dễ mang",           "light,nhẹ,nhẹ nhàng"},
	{6, "PERCEPT_COLD",     "lạnh buốt",   "cảm giác nhiệt độ thấp da tê lạnh",                "lạnh,cold,rét,buốt"},
	// ── L6 Perception — không gian / thời gian ──────────────────
	{6, "PERCEPT_NEAR",     "gần",         "khoảng cách nhỏ giữa hai vật hoặc địa điểm",       "gần,near,close"},
	{6, "PERCEPT_FAR",      "xa",          "khoảng cách lớn giữa hai vật hoặc địa điểm",        "xa,far,distant"},
	{6, "PERCEPT_SHARP",    "sắc bén",     "cạnh hoặc đầu nhọn có thể cắt đâm",                "sharp,nhọn,sắc"},
	{6, "PERCEPT_CLEAN",    "sạch sẽ",     "không có bụi bẩn vi khuẩn tạp chất",               "sạch,clean,gọn gàng"},
	{6, "PERCEPT_DIRTY",    "bẩn thỉu",    "có bụi bẩn tạp chất không hợp vệ sinh",            "bẩn,dirty,dơ"},
	{6, "PERCEPT_FRESH",    "tươi mát",    "cảm giác mát lành không khí trong lành",            "fresh,tươi,mát mẻ"},
	{6, "PERCEPT_TIRED",    "mệt mỏi",     "cảm giác thiếu năng lượng cần nghỉ ngơi",           "mệt,tired,kiệt sức"},
	{6, "PERCEPT_AWAKE",    "tỉnh táo",    "trạng thái ý thức rõ ràng hoàn toàn",               "tỉnh,awake,tươi tỉnh"},
	{6, "PERCEPT_PAIN",     "đau đớn",     "cảm giác khó chịu dữ dội do tổn thương",            "đau,pain,nhức"},
	{6, "PERCEPT_HUNGER",   "đói bụng",    "cảm giác thiếu thức ăn dạ dày rỗng",               "đói,hungry,hunger,bụng đói"},
	{6, "PERCEPT_THIRST",   "khát nước",   "cảm giác thiếu nước cơ thể cần bổ sung",            "khát,thirsty,thirst,khô miệng"},
}

func main() {
	if _, err := os.Stat(seedPath); err != nil {
		log.Fatalf("không tìm thấy %s — chạy từ thư mục gốc repo", seedPath)
	}

	// Kiểm tra nodes nào đã tồn tại
	existing := loadExistingNames(seedPath)
	fmt.Printf("Existing nodes: %d\n", len(existing))

	all := append(lifeDefs, perceptDefs...)
	added, skipped := 0, 0

	for _, d := range all {
		if existing[d.name] {
			fmt.Printf("  SKIP %-22s (already exists)\n", d.name)
			skipped++
			continue
		}
		dna := "label=" + d.label + "|desc=" + d.desc
		if d.vi != "" {
			dna += "|vi=" + d.vi
		}
		isl := nodeISL(d.name, d.layer)
		if err := appendNode(seedPath, d.layer, isl, []byte(dna), d.name); err != nil {
			fmt.Printf("  ERR  %-22s %v\n", d.name, err)
		} else {
			fmt.Printf("  +L%d  %-22s %s\n", d.layer, d.name, d.label)
			added++
		}
	}

	fmt.Printf("\n✅ seed_life_percept: +%d nodes, %d skip\n", added, skipped)
	fmt.Println("Verify: ./olang verify homeos.olang")
}

// ── Helpers ───────────────────────────────────────────────────

func loadExistingNames(path string) map[string]bool {
	raw, err := os.ReadFile(path)
	if err != nil { return nil }
	out := map[string]bool{}
	const idx = 64 + 9*24
	for i := idx; i+20 < len(raw); {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		if i+20 > len(raw) { break }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		ns := i + 20 + dl
		ne := ns + nl
		if ne > len(raw) { break }
		out[string(raw[ns:ne])] = true
		i = ne
	}
	return out
}

func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0] = layer
	isl[1] = h[0]%200 + 1
	isl[2] = h[1]%200 + 1
	isl[3] = h[2]%200 + 1
	isl[4] = h[3]; isl[5] = h[4]; isl[6] = h[5]; isl[7] = h[6]
	return isl
}

func appendNode(filePath string, layer uint8, islB [8]byte, dna []byte, name string) error {
	raw, err := os.ReadFile(filePath)
	if err != nil { return err }

	const (hdr = 64; ent = 24; nls = 9; idx = hdr + nls*ent)
	if len(raw) < idx || string(raw[0:4]) != "OLNG" {
		return fmt.Errorf("bad file")
	}

	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }

	// Kiểm tra tên trùng
	for i := idx; i+20 < len(raw); {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		ns := i + 20 + dl
		ne := ns + nl
		if ne > len(raw) { break }
		if string(raw[ns:ne]) == name { return fmt.Errorf("duplicate: %s", name) }
		i = ne
	}

	// Build record
	rec := make([]byte, 2+1+8+4+4+1+len(dna)+len(nb))
	p := 0
	rec[p] = 'N'; p++; rec[p] = 'D'; p++; rec[p] = layer; p++
	copy(rec[p:], islB[:]); p += 8
	binary.BigEndian.PutUint32(rec[p:], 0); p += 4
	binary.BigEndian.PutUint32(rec[p:], uint32(len(dna))); p += 4
	rec[p] = uint8(len(nb)); p++
	copy(rec[p:], dna); p += len(dna)
	copy(rec[p:], nb)

	// Layer offsets
	type li struct{ off, sz uint64; nn uint32 }
	ls := [nls]li{}
	for i := 0; i < nls; i++ {
		o := hdr + i*ent
		ls[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		ls[i].sz  = binary.BigEndian.Uint64(raw[o+12 : o+20])
		ls[i].nn  = binary.BigEndian.Uint32(raw[o+20 : o+24])
	}

	tgt := int(layer)
	var ins uint64
	if ls[tgt].sz > 0 {
		ins = ls[tgt].off + ls[tgt].sz
	} else {
		ins = uint64(idx)
		for i := tgt - 1; i >= 0; i-- {
			if ls[i].sz > 0 { ins = ls[i].off + ls[i].sz; break }
		}
	}

	out := append(append([]byte{}, raw[:ins]...), append(rec, raw[ins:]...)...)

	// Update header
	if ls[tgt].sz == 0 {
		binary.BigEndian.PutUint64(out[hdr+tgt*ent+4:], ins)
	}
	binary.BigEndian.PutUint64(out[hdr+tgt*ent+12:], ls[tgt].sz+uint64(len(rec)))
	binary.BigEndian.PutUint32(out[hdr+tgt*ent+20:], ls[tgt].nn+1)

	// Shift offsets sau tgt
	for i := tgt + 1; i < nls; i++ {
		if ls[i].sz > 0 {
			o := hdr + i*ent
			off := binary.BigEndian.Uint64(out[o+4:])
			binary.BigEndian.PutUint64(out[o+4:], off+uint64(len(rec)))
		}
	}

	// SHA256
	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return err }
	return os.Rename(tmp, filePath)
}

// Kiểm tra DNA có chứa tên node không (để detect LIFE_ANIMAL vs LIFE_ANIMAL trong existing)
func containsName(dna, name string) bool {
	return strings.Contains(string(dna), name)
}
