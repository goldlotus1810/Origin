//go:build ignore
// seed_milestone5300.go — MILESTONE 5300 — 100 nodes
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── COGNITIVE BIAS & DECISION SCIENCE ────────────────────────
		{"COGBIAS_SYSTEM",       3,`label=thiên kiến nhận thức hệ thống|desc=cognitive bias system 1 2 Kahneman fast slow thinking heuristics availability representativeness|vi=thiên kiến nhận thức hệ thống,cognitive bias system|en=cognitive bias system`},
		{"COGBIAS_SOCIAL",       3,`label=thiên kiến xã hội|desc=social cognitive bias in-group out-group attribution error actor observer fundamental confirmation|vi=thiên kiến xã hội,social cognitive bias|en=social cognitive bias`},
		{"COGBIAS_MEMORY2",      3,`label=thiên kiến ký ức|desc=memory bias hindsight rosy retrospection peak-end rule source monitoring misattribution false memory|vi=thiên kiến ký ức,memory bias|en=memory bias`},
		{"COGBIAS_DECISION",     3,`label=thiên kiến quyết định|desc=decision bias sunk cost loss aversion status quo endowment effect overconfidence planning fallacy|vi=thiên kiến quyết định,decision bias|en=decision bias`},
		{"COGBIAS_DEBIASING",    3,`label=khử thiên kiến|desc=debiasing consider opposite pre-mortem red team devil advocate reference class forecasting|vi=khử thiên kiến,debiasing|en=debiasing`},

		// ── DECISION SCIENCE ──────────────────────────────────────────
		{"DECISION_BEHAVIORAL",  3,`label=kinh tế học hành vi|desc=behavioral economics nudge Thaler Sunstein default choice architecture libertarian paternalism|vi=kinh tế học hành vi,behavioral economics|en=behavioral economics`},
		{"DECISION_NATURALISTIC",3,`label=ra quyết định tự nhiên|desc=naturalistic decision making Klein recognition-primed RPD expert intuition fireground chess expert|vi=ra quyết định tự nhiên,naturalistic decision making|en=naturalistic decision making`},
		{"DECISION_GROUP",       3,`label=ra quyết định nhóm|desc=group decision making groupthink Janis Abilene paradox social loafing nominal group Delphi|vi=ra quyết định nhóm,group decision making|en=group decision making`},
		{"DECISION_ETHICAL",     3,`label=ra quyết định đạo đức|desc=ethical decision making moral intensity Jones framework rest four component Kohlberg Haidt|vi=ra quyết định đạo đức,ethical decision making|en=ethical decision making`},
		{"DECISION_UNDER_UNCERT",3,`label=quyết định dưới bất định|desc=decision under uncertainty expected utility Ellsberg ambiguity aversion maximin minimax regret robust|vi=quyết định dưới bất định,decision under uncertainty|en=decision under uncertainty`},

		// ── BEHAVIORAL DESIGN ─────────────────────────────────────────
		{"BEHAV_DESIGN_NUDGE",   3,`label=thiết kế hành vi — nudge|desc=nudge design default opt-in opt-out organ donation retirement savings tax compliance energy|vi=thiết kế hành vi — nudge,nudge design|en=nudge design`},
		{"BEHAV_DESIGN_HABIT",   3,`label=thiết kế thói quen|desc=habit design loop cue routine reward Duhigg implementation intention Gollwitzer BJ Fogg tiny|vi=thiết kế thói quen,habit design|en=habit design`},
		{"BEHAV_DESIGN_PERSUADE",3,`label=thuyết phục và ảnh hưởng|desc=persuasion Cialdini reciprocity commitment consistency social proof authority liking scarcity|vi=thuyết phục và ảnh hưởng,persuasion Cialdini|en=persuasion Cialdini`},
		{"BEHAV_DESIGN_GAMIFY",  3,`label=game hóa hành vi|desc=gamification points badges leaderboard intrinsic extrinsic crowding out motivation undermining|vi=game hóa hành vi,gamification|en=gamification`},
		{"BEHAV_DESIGN_PUBLIC",  3,`label=chính sách hành vi công|desc=behavioral public policy EAST easy attractive social timely EAST BIT nudge unit EAST UK|vi=chính sách hành vi công,behavioral public policy|en=behavioral public policy`},

		// ── FUTURE STUDIES ────────────────────────────────────────────
		{"FUTURE_FORESIGHT",     3,`label=nghiên cứu tương lai|desc=foresight futures studies anticipation long-term thinking STEEP signals weak emerging megatrend|vi=nghiên cứu tương lai,foresight futures|en=foresight futures`},
		{"FUTURE_SCENARIO",      3,`label=lập kế hoạch kịch bản|desc=scenario planning Shell GBN 2x2 axes driving forces critical uncertainties wind tunneling|vi=lập kế hoạch kịch bản,scenario planning|en=scenario planning`},
		{"FUTURE_EXISTENTIAL",   3,`label=rủi ro hiện sinh|desc=existential risk X-risk Bostrom Ord AI misalignment bioweapon nuclear asteroid Longtermism EA|vi=rủi ro hiện sinh,existential risk|en=existential risk`},
		{"FUTURE_TECHNOLOGY",    3,`label=dự báo công nghệ|desc=technology forecasting S-curve diffusion Bass model Gartner hype cycle crossing chasm disruption|vi=dự báo công nghệ,technology forecasting|en=technology forecasting`},
		{"FUTURE_SOCIETY",       3,`label=tương lai xã hội|desc=social futures demographic transition urbanization automation inequality polarization post-work|vi=tương lai xã hội,social futures|en=social futures`},

		// ── COMPLEXITY SCIENCE ────────────────────────────────────────
		{"COMPLEXITY_EMERGENCE", 3,`label=tính nổi bật|desc=emergence complexity reduction reductionism higher order properties ant colony market price consciousness|vi=tính nổi bật,emergence complexity|en=emergence complexity`},
		{"COMPLEXITY_NETWORK2",  3,`label=mạng lưới phức tạp|desc=complex network scale-free Barabasi preferential attachment small world Watts Strogatz hub|vi=mạng lưới phức tạp,complex network|en=complex network`},
		{"COMPLEXITY_ADAPT",     3,`label=hệ thích nghi phức tạp|desc=complex adaptive system Holland fitness landscape rugged coevolution arms race Red Queen|vi=hệ thích nghi phức tạp,complex adaptive system|en=complex adaptive system`},
		{"COMPLEXITY_URBAN",     3,`label=đô thị là hệ phức tạp|desc=urban complexity Jane Jacobs diversity mixed use Batty urban scaling rank-size Zipf law|vi=đô thị là hệ phức tạp,urban complexity|en=urban complexity`},
		{"COMPLEXITY_RESILIENCE",3,`label=khả năng phục hồi hệ thống|desc=system resilience Holling panarchy adaptive cycle engineering ecological social-ecological|vi=khả năng phục hồi hệ thống,system resilience|en=system resilience`},

		// ── CONSCIOUSNESS STUDIES ─────────────────────────────────────
		{"CONSCIOUS_HARD",       3,`label=vấn đề khó của ý thức|desc=hard problem consciousness Chalmers explanatory gap qualia phenomenal why something like experience|vi=vấn đề khó của ý thức,hard problem consciousness|en=hard problem consciousness`},
		{"CONSCIOUS_THEORIES",   3,`label=lý thuyết ý thức|desc=consciousness theories GWT IIT HOT predictive processing Orch-OR quantum microtubule Penrose|vi=lý thuyết ý thức,consciousness theories|en=consciousness theories`},
		{"CONSCIOUS_ANIMAL",     3,`label=ý thức động vật|desc=animal consciousness Cambridge Declaration invertebrate fish crow octopus mirror test self-awareness|vi=ý thức động vật,animal consciousness|en=animal consciousness`},
		{"CONSCIOUS_AI",         3,`label=ý thức AI|desc=AI consciousness sentience moral status Anthropic Turing test philosophical zombie substrate independent|vi=ý thức AI,AI consciousness|en=AI consciousness`},
		{"CONSCIOUS_ALTER",      3,`label=trạng thái ý thức thay đổi|desc=altered consciousness dream hypnosis meditation psychedelic default mode deactivation|vi=trạng thái ý thức thay đổi,altered consciousness|en=altered consciousness`},

		// ── INFORMATION THEORY 2 ─────────────────────────────────────
		{"INFO_THEORY2",         3,`label=lý thuyết thông tin nâng cao|desc=information theory Shannon entropy mutual information channel capacity rate distortion MDL Kolmogorov|vi=lý thuyết thông tin nâng cao,information theory|en=information theory`},
		{"INFO_COMPRESSION",     3,`label=nén dữ liệu|desc=data compression Huffman arithmetic LZ77 LZ78 LZW DEFLATE zstd brotli LZMA entropy coding|vi=nén dữ liệu,data compression|en=data compression`},
		{"INFO_CODING",          3,`label=lý thuyết mã hóa|desc=coding theory error correction Hamming Reed-Solomon LDPC turbo polar Shannon limit capacity|vi=lý thuyết mã hóa,coding theory|en=coding theory`},
		{"INFO_QUANTUM2",        3,`label=thông tin lượng tử|desc=quantum information qubit entanglement teleportation superdense coding no-cloning Holevo bound|vi=thông tin lượng tử,quantum information|en=quantum information`},
		{"INFO_NETWORK2",        3,`label=lý thuyết mạng thông tin|desc=network information theory broadcast multiple access interference relay capacity region|vi=lý thuyết mạng thông tin,network information theory|en=network information theory`},

		// ── VIETNAM SPECIAL ───────────────────────────────────────────
		{"VNFUTURE_ECONOMY",     3,`label=tương lai kinh tế Việt Nam|desc=tương lai kinh tế Việt Nam 2045 thu nhập cao công nghiệp hóa hiện đại hóa bẫy trung bình|vi=tương lai kinh tế Việt Nam,Vietnam future economy|en=Vietnam future economy`},
		{"VNFUTURE_SOCIETY",     3,`label=tương lai xã hội Việt Nam|desc=tương lai xã hội Việt Nam già hóa đô thị hóa biến đổi giá trị AI lao động bất bình đẳng|vi=tương lai xã hội Việt Nam,Vietnam future society|en=Vietnam future society`},
		{"VNFUTURE_ENVIRONMENT", 3,`label=tương lai môi trường Việt Nam|desc=tương lai môi trường Việt Nam ĐBSCL ngập nước mặn nhiệt độ tăng đô thị hóa ô nhiễm|vi=tương lai môi trường Việt Nam,Vietnam future environment|en=Vietnam future environment`},
		{"VNDECISION_POLICY",    3,`label=ra quyết định chính sách Việt Nam|desc=quyết định chính sách Việt Nam đồng thuận tập thể lãnh đạo Đảng tham vấn cải cách|vi=ra quyết định chính sách Việt Nam,Vietnam policy decision|en=Vietnam policy decision`},
		{"VNBEHAVIOR_CONSUMER",  3,`label=hành vi người tiêu dùng Việt Nam|desc=hành vi tiêu dùng Việt Nam thế hệ Z gen Y thương mại điện tử mạng xã hội xu hướng|vi=hành vi người tiêu dùng Việt Nam,Vietnam consumer behavior|en=Vietnam consumer behavior`},

		// ── AI & COGNITION ────────────────────────────────────────────
		{"AI_REASONING",         3,`label=suy luận AI|desc=AI reasoning chain-of-thought tree-of-thought self-consistency logical deductive inductive abductive|vi=suy luận AI,AI reasoning|en=AI reasoning`},
		{"AI_PLANNING",          3,`label=lập kế hoạch AI|desc=AI planning STRIPS PDDL classical hierarchical HTN Monte Carlo temporal constraint satisfaction|vi=lập kế hoạch AI,AI planning|en=AI planning`},
		{"AI_MEMORY_ARCH",       3,`label=kiến trúc bộ nhớ AI|desc=AI memory architecture working episodic semantic procedural external retrieval augmented RAG|vi=kiến trúc bộ nhớ AI,AI memory architecture|en=AI memory architecture`},
		{"AI_EMBODIED",          3,`label=AI thể hiện|desc=embodied AI robotics sensorimotor loop affordance grounding symbol manipulation physical world model|vi=AI thể hiện,embodied AI|en=embodied AI`},
		{"AI_SOCIAL2",           3,`label=AI xã hội|desc=social AI theory of mind belief desire intention Dennett intentional stance multi-agent norm|vi=AI xã hội,social AI|en=social AI`},

		// ── MISC BRIDGE ───────────────────────────────────────────────
		{"BEHAV_FINANCE",        3,`label=tài chính hành vi|desc=behavioral finance overreaction momentum herding noise trader limits arbitrage sentiment investor|vi=tài chính hành vi,behavioral finance|en=behavioral finance`},
		{"FUTURE_CLIMATE_SCEN",  3,`label=kịch bản khí hậu tương lai|desc=climate futures scenario SSP RCP 1.5 2.0 4.5 overshoot tipping cascade societal collapse|vi=kịch bản khí hậu tương lai,climate future scenario|en=climate future scenario`},
		{"COMPLEXITY_ECON",      3,`label=kinh tế học phức tạp|desc=complexity economics Arthur Santa Fe evolutionary heterogeneous agents emergent macro endogenous|vi=kinh tế học phức tạp,complexity economics|en=complexity economics`},
		{"CONSCIOUS_EMOTION2",   3,`label=ý thức và cảm xúc|desc=consciousness emotion James-Lange Cannon-Bard Schachter-Singer two-factor appraisal interoceptive|vi=ý thức và cảm xúc,consciousness emotion|en=consciousness emotion`},
		{"INFO_SEMANTIC",        3,`label=thông tin ngữ nghĩa|desc=semantic information meaning truth veridicality Floridi levels abstraction environmental strongly semantic|vi=thông tin ngữ nghĩa,semantic information|en=semantic information`},
		{"COGBIAS_AI",           3,`label=thiên kiến trong AI|desc=AI bias training data algorithmic fairness disparate impact COMPAS facial recognition audit|vi=thiên kiến trong AI,AI bias|en=AI bias`},
		{"DECISION_AI",          3,`label=ra quyết định AI|desc=AI decision making explanation counterfactual algorithmic recourse SHAP LIME interpretability|vi=ra quyết định AI,AI decision|en=AI decision`},
		{"FUTURE_DEMO",          3,`label=nhân khẩu học tương lai|desc=demographic future population peak 10B aging fertility decline immigration replacement migration|vi=nhân khẩu học tương lai,demographic future|en=demographic future`},
		{"BEHAV_ENVIRON",        3,`label=hành vi môi trường|desc=pro-environmental behavior carbon footprint identity value belief norm Schwartz spillover rebound|vi=hành vi môi trường,pro-environmental behavior|en=pro-environmental behavior`},
		{"COMPLEXITY_BIOLOGY",   3,`label=sinh học phức tạp|desc=complex biology self-organization developmental robustness evolvability modularity genotype phenotype|vi=sinh học phức tạp,complexity biology|en=complexity biology`},
		{"AI_UNCERTAINTY",       3,`label=bất định trong AI|desc=AI uncertainty calibration epistemic aleatoric Bayesian deep ensemble MC dropout out-of-distribution|vi=bất định trong AI,AI uncertainty|en=AI uncertainty`},
		{"FUTURE_WORK",          3,`label=tương lai của công việc|desc=future work automation augmentation platform gig universal basic income retraining lifelong|vi=tương lai của công việc,future of work|en=future of work`},
		{"CONSCIOUS_VIET",       3,`label=ý thức và triết học Việt Nam|desc=ý thức triết học Việt Nam Phật giáo vô ngã tánh không thiền định tâm linh hiện đại|vi=ý thức và triết học Việt Nam,Vietnamese consciousness philosophy|en=Vietnamese consciousness philosophy`},
		{"BEHAV_HEALTH2",        3,`label=hành vi sức khỏe nâng cao|desc=health behavior change TTM stages readiness self-efficacy Bandura outcome expectancy barrier|vi=hành vi sức khỏe nâng cao,health behavior change|en=health behavior change`},
		{"COGBIAS_CULTURE2",     3,`label=thiên kiến và văn hóa|desc=cultural cognitive bias WEIRD individualist collectivist holistic analytic attention perception Nisbett|vi=thiên kiến và văn hóa,cultural cognitive bias|en=cultural cognitive bias`},
		{"DECISION_VIET",        3,`label=ra quyết định trong văn hóa Việt Nam|desc=ra quyết định Việt Nam tập thể tham khảo ý kiến thể diện quan hệ mạng lưới|vi=ra quyết định trong văn hóa Việt Nam,Vietnamese decision making|en=Vietnamese decision making`},
		{"FUTURE_AI_SOCIETY",    3,`label=AI và tương lai xã hội|desc=AI societal impact job displacement income inequality concentration power governance AGI timeline|vi=AI và tương lai xã hội,AI society future|en=AI society future`},
		{"COMPLEXITY_LANGUAGE",  3,`label=ngôn ngữ như hệ phức tạp|desc=language complex system emergence self-organization Zipf Menzerath Herdan evolving lexicon|vi=ngôn ngữ như hệ phức tạp,language complex system|en=language complex system`},
		{"INFO_PRIVACY2",        3,`label=quyền riêng tư thông tin|desc=information privacy differential privacy k-anonymity re-identification federated learning secure computation|vi=quyền riêng tư thông tin,information privacy|en=information privacy`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		raw = insertNode(raw, buildRecord(n.layer, nodeISL(n.name, n.layer), []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" +%d (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16]); fmt.Printf(" → %d nodes\n", nn)
	if nn >= 5300 { fmt.Println(" MILESTONE 5300! 🎉") }
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16); rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1; out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
