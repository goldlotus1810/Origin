//go:build ignore
// seed_milestone4200.go — MILESTONE 4200 — 100 nodes
// Domains: OCEAN3_ POLAR_ WETLAND_ SAVANNA_ ALPINE_
//          IMMUNOL3_ MICROBIOME2_ VIROLOGY2_ PARASITOL_ TOXICOL_
//          ANCIENT_ROME_ ANCIENT_GREECE_ ANCIENT_EGYPT_ ANCIENT_INDIA_ ANCIENT_CHINA_
//          MEDIEVAL2_ RENAISSANCE_ ENLIGHTENMENT_ INDUSTRIALREV_ MODERNHIST_
//          COGNITION4_ MOTIVATION_ PERSONALITY2_ SOCIAL2_ DEVELOPMENTAL_
//          SEMICONDUCTOR_ DISPLAY_ BATTERY2_ PHOTOVOLTAIC_ SENSOR2_
//          VNLITERATURE2_ VNSOCIOLOGY_ VNURBAN_ VNEDUCATION_ VNPOVERTY_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── OCEAN 3 (OCEAN3_) ─────────────────────────────────────────
		{"OCEAN3_ACIDIFY",      3,`label=axit hóa đại dương|desc=ocean acidification CO2 carbonic acid pH decline aragonite saturation pteropod shell oyster reef ecosystem|vi=axit hóa đại dương,ocean acidification|en=ocean acidification`},
		{"OCEAN3_DEOXYGENATE",  3,`label=giảm oxy đại dương|desc=ocean deoxygenation hypoxic zone dead zone Gulf Mexico nitrogen runoff stratification warming OMZ|vi=giảm oxy đại dương,ocean deoxygenation|en=ocean deoxygenation`},
		{"OCEAN3_MICROPLASTIC", 3,`label=vi nhựa trong đại dương|desc=microplastic ocean 5mm fragments tire rubber textile polyester ingestion food chain human blood|vi=vi nhựa trong đại dương,ocean microplastic|en=ocean microplastic`},
		{"OCEAN3_SHIPPING",     3,`label=vận tải biển|desc=shipping container bulk tanker LNG IMO 2020 sulfur cap decarbonization green methanol ammonia vessel|vi=vận tải biển,shipping|en=shipping`},
		{"OCEAN3_DEEP_MINE",    3,`label=khai thác đáy biển|desc=deep sea mining polymetallic nodule cobalt crust hydrothermal vent ISA regulation biodiversity risk|vi=khai thác đáy biển,deep sea mining|en=deep sea mining`},

		// ── POLAR & WETLAND (POLAR_ / WETLAND_) ──────────────────────
		{"POLAR_ARCTIC_CHANGE", 3,`label=biến đổi Bắc Cực|desc=Arctic change amplification sea ice loss albedo feedback permafrost thaw methane AMOC Greenland melt|vi=biến đổi Bắc Cực,Arctic change|en=Arctic change`},
		{"POLAR_ANTARCTIC",     3,`label=Nam Cực|desc=Antarctica ice sheet Thwaites WAIS EAIS sea level contribution krill Southern Ocean carbon sink treaty|vi=Nam Cực,Antarctica|en=Antarctica`},
		{"WETLAND_PEATLAND",    3,`label=đất than bùn|desc=peatland carbon store Borneo Congo Indonesian fire drainage palm oil restoration rewetting methane sink|vi=đất than bùn,peatland|en=peatland`},
		{"WETLAND_RAMSAR",      3,`label=công ước Ramsar|desc=Ramsar wetland convention 1971 wise use Montreux Record importance biodiversity water cycle flood control|vi=công ước Ramsar,Ramsar convention|en=Ramsar convention`},
		{"SAVANNA_ECOSYSTEM",   3,`label=hệ sinh thái savanna|desc=savanna grassland fire regime elephant megaherbivore acacia C4 grass rainfall seasonality Africa Australia|vi=hệ sinh thái savanna,savanna ecosystem|en=savanna ecosystem`},

		// ── ANCIENT HISTORY ───────────────────────────────────────────
		{"ANCIENT_ROME_REPUBLIC",3,`label=Cộng hòa La Mã|desc=Roman Republic Senate consul tribune veto Gracchi reforms civil war Marius Sulla Caesar Rubicon SPQR|vi=Cộng hòa La Mã,Roman Republic|en=Roman Republic`},
		{"ANCIENT_ROME_EMPIRE",  3,`label=Đế chế La Mã|desc=Roman Empire Augustus Pax Romana Trajan Hadrian decline fall 476 CE barbarian frontier bureaucracy|vi=Đế chế La Mã,Roman Empire|en=Roman Empire`},
		{"ANCIENT_GREECE_ATHEN", 3,`label=Athens cổ đại|desc=ancient Athens democracy Pericles Agora Acropolis Parthenon tragedy comedy philosophy Socrates Plato|vi=Athens cổ đại,ancient Athens|en=ancient Athens`},
		{"ANCIENT_GREECE_ALEX",  3,`label=Alexander Đại đế|desc=Alexander Great Macedon conquest Persia Egypt India Hellenism spread Greek culture Diadochi succession|vi=Alexander Đại đế,Alexander the Great|en=Alexander the Great`},
		{"ANCIENT_EGYPT_PHARAOH",3,`label=các pharaoh Ai Cập|desc=pharaoh Egypt Ramesses II Tutankhamun Cleopatra Ptolemaic Ma'at divine kingship pyramid funerary|vi=các pharaoh Ai Cập,Egyptian pharaoh|en=Egyptian pharaoh`},

		// ── MEDIEVAL & RENAISSANCE ────────────────────────────────────
		{"MEDIEVAL2_ISLAM",      3,`label=thế giới Hồi giáo trung đại|desc=medieval Islamic world Golden Age Baghdad House of Wisdom algebra optics medicine trade routes Abbasid|vi=thế giới Hồi giáo trung đại,medieval Islamic world|en=medieval Islamic world`},
		{"MEDIEVAL2_EUROPE",     3,`label=Châu Âu trung đại|desc=medieval Europe feudalism plague Black Death 1347 Magna Carta Hundred Years War chivalry scholasticism|vi=Châu Âu trung đại,medieval Europe|en=medieval Europe`},
		{"RENAISSANCE_ART",      3,`label=nghệ thuật Phục Hưng|desc=Renaissance art perspective humanism Leonardo Michelangelo Raphael Botticelli Florence patronage Medici|vi=nghệ thuật Phục Hưng,Renaissance art|en=Renaissance art`},
		{"RENAISSANCE_SCIENCE",  3,`label=cách mạng khoa học|desc=scientific revolution Copernicus Galileo Kepler Newton heliocentrism telescope gravity calculus Royal Society|vi=cách mạng khoa học,scientific revolution|en=scientific revolution`},
		{"ENLIGHTENMENT_HIST",   3,`label=thời kỳ Khai sáng|desc=Enlightenment Voltaire Rousseau Locke Montesquieu reason progress encyclopedia social contract natural rights|vi=thời kỳ Khai sáng,Enlightenment|en=Enlightenment`},

		// ── INDUSTRIAL & MODERN HISTORY ───────────────────────────────
		{"INDUSTRIALREV_BRIT",   3,`label=cách mạng công nghiệp Anh|desc=industrial revolution Britain steam engine Watt textile factory system coal iron railway enclosure urbanization|vi=cách mạng công nghiệp Anh,industrial revolution|en=industrial revolution`},
		{"INDUSTRIALREV_SOCIAL", 3,`label=tác động xã hội công nghiệp hóa|desc=industrialization social impact child labor Owen Chartism trade union Marx Engels capital labor alienation|vi=tác động xã hội công nghiệp hóa,industrialization social impact|en=industrialization social impact`},
		{"MODERNHIST_WW1",       3,`label=Thế chiến thứ nhất|desc=World War I 1914-1918 assassination Franz Ferdinand trench warfare Somme Western Front Versailles Wilson|vi=Thế chiến thứ nhất,World War I|en=World War I`},
		{"MODERNHIST_COLDWAR",   3,`label=Chiến tranh Lạnh|desc=Cold War USA USSR containment Truman Doctrine NATO Warsaw Pact Cuban Missile Crisis détente Berlin Wall fall|vi=Chiến tranh Lạnh,Cold War|en=Cold War`},
		{"MODERNHIST_DECOLONIZE",3,`label=phi thực dân hóa|desc=decolonization independence Africa Asia 1945-1975 nonalignment Bandung Gandhi Nkrumah Ho Chi Minh postcolonial|vi=phi thực dân hóa,decolonization|en=decolonization`},

		// ── ANCIENT INDIA & CHINA ─────────────────────────────────────
		{"ANCIENT_INDIA_MAURYA",  3,`label=đế chế Maurya|desc=Maurya Empire Chandragupta Ashoka Dhamma edicts Buddhist spread Arthashastra Kautilya Magadha|vi=đế chế Maurya,Maurya Empire|en=Maurya Empire`},
		{"ANCIENT_INDIA_GUPTA",   3,`label=thời đại hoàng kim Gupta|desc=Gupta Empire golden age mathematics zero Aryabhata astronomy Sanskrit literature Kalidasa|vi=thời đại hoàng kim Gupta,Gupta Empire|en=Gupta Empire`},
		{"ANCIENT_CHINA_QIN",     3,`label=nhà Tần|desc=Qin Dynasty Qin Shi Huang unification Great Wall standardization legalism terracotta army Silk Road|vi=nhà Tần,Qin Dynasty|en=Qin Dynasty`},
		{"ANCIENT_CHINA_HAN",     3,`label=nhà Hán|desc=Han Dynasty Confucianism civil service examination Silk Road Zhang Qian paper invention Buddhism spread|vi=nhà Hán,Han Dynasty|en=Han Dynasty`},
		{"ALPINE_ECOLOGY",        3,`label=hệ sinh thái cao nguyên|desc=alpine ecology treeline ecotone glacial retreat endemic species marmot ibex edelweiss adaptation phenology|vi=hệ sinh thái cao nguyên,alpine ecology|en=alpine ecology`},

		// ── IMMUNOLOGY 3 (IMMUNOL3_) ─────────────────────────────────
		{"IMMUNOL3_CYTOKINE",    3,`label=cytokine và viêm|desc=cytokine storm TNF IL-6 IL-1 interferon JAK-STAT signaling tocilizumab baricitinib dexamethasone COVID|vi=cytokine và viêm,cytokine inflammation|en=cytokine inflammation`},
		{"IMMUNOL3_TRANSPLANT",  3,`label=miễn dịch ghép tạng|desc=transplant immunology HLA matching rejection graft-versus-host tacrolimus cyclosporine tolerance induction|vi=miễn dịch ghép tạng,transplant immunology|en=transplant immunology`},
		{"IMMUNOL3_MUCOSAL",     3,`label=miễn dịch niêm mạc|desc=mucosal immunity IgA gut-associated lymphoid GALT Peyer patches secretory dimeric neonatal transfer|vi=miễn dịch niêm mạc,mucosal immunity|en=mucosal immunity`},
		{"MICROBIOME2_SKIN",     3,`label=vi sinh vật da|desc=skin microbiome Staphylococcus Cutibacterium Malassezia eczema psoriasis acne barrier sebum pH|vi=vi sinh vật da,skin microbiome|en=skin microbiome`},
		{"VIROLOGY2_HIV",        3,`label=HIV và AIDS|desc=HIV AIDS retrovirus CD4 T cell tropism ART HAART undetectable=untransmittable U=U PrEP vaccine challenge|vi=HIV và AIDS,HIV AIDS|en=HIV AIDS`},

		// ── PARASITOLOGY & TOXICOLOGY ─────────────────────────────────
		{"PARASITOL_MALARIA",    3,`label=sốt rét|desc=malaria Plasmodium falciparum mosquito Anopheles artemisinin resistance RTS,S R21 vaccine bednet IRS elimination|vi=sốt rét,malaria|en=malaria`},
		{"PARASITOL_HELMINTH",   3,`label=giun sán|desc=helminth roundworm hookworm schistosomiasis mass drug administration albendazole praziquantel soil-transmitted|vi=giun sán,helminth|en=helminth`},
		{"TOXICOL_HEAVY",        3,`label=kim loại nặng độc|desc=heavy metal toxicity lead mercury arsenic cadmium bioaccumulation chelation treatment WHO limit exposure|vi=kim loại nặng độc,heavy metal toxicity|en=heavy metal toxicity`},
		{"TOXICOL_PESTICIDE",    3,`label=độc chất thuốc trừ sâu|desc=pesticide toxicity organophosphate neonicotinoid bee colony collapse IARC carcinogen metabolite biomonitoring|vi=độc chất thuốc trừ sâu,pesticide toxicity|en=pesticide toxicity`},
		{"TOXICOL_ENDOCRINE",    3,`label=chất rối loạn nội tiết|desc=endocrine disruptor BPA phthalate PFAS forever chemical thyroid reproductive development low-dose|vi=chất rối loạn nội tiết,endocrine disruptor|en=endocrine disruptor`},

		// ── PSYCHOLOGY: COGNITION 4 (COGNITION4_) ────────────────────
		{"COGNITION4_EXEC",      3,`label=chức năng điều hành|desc=executive function working memory inhibitory control cognitive flexibility prefrontal cortex development aging intervention|vi=chức năng điều hành,executive function|en=executive function`},
		{"COGNITION4_MEMORY2",   3,`label=hệ thống ký ức|desc=memory systems explicit implicit episodic semantic procedural priming reconsolidation sleep consolidation interference|vi=hệ thống ký ức,memory systems|en=memory systems`},
		{"MOTIVATION_SELF",      3,`label=tự quyết và động lực|desc=self-determination theory Deci Ryan intrinsic extrinsic autonomy competence relatedness motivation|vi=tự quyết và động lực,self-determination theory|en=self-determination theory`},
		{"MOTIVATION_GOAL",      3,`label=lý thuyết mục tiêu|desc=goal setting theory Locke Latham SMART difficult specific feedback commitment self-efficacy Bandura|vi=lý thuyết mục tiêu,goal setting theory|en=goal setting theory`},
		{"PERSONALITY2_BIG5",    3,`label=tính cách Big Five|desc=Big Five personality OCEAN openness conscientiousness extraversion agreeableness neuroticism heritability stability|vi=tính cách Big Five,Big Five personality|en=Big Five personality`},

		// ── DEVELOPMENTAL PSYCHOLOGY ─────────────────────────────────
		{"DEVELOPMENTAL_INFANT", 3,`label=phát triển trẻ sơ sinh|desc=infant development sensorimotor face preference proto-conversation object permanence joint attention prelinguistic|vi=phát triển trẻ sơ sinh,infant development|en=infant development`},
		{"DEVELOPMENTAL_ADOL",   3,`label=phát triển tuổi vị thành niên|desc=adolescent development puberty identity formation Erikson brain prefrontal risk peer influence Marcia|vi=phát triển tuổi vị thành niên,adolescent development|en=adolescent development`},
		{"DEVELOPMENTAL_ADULT",  3,`label=phát triển người trưởng thành|desc=adult development midlife crisis Levinson seasons generativity Erikson intimacy integrity wisdom aging|vi=phát triển người trưởng thành,adult development|en=adult development`},
		{"SOCIAL2_PREJUDICE",    3,`label=định kiến và kỳ thị|desc=prejudice implicit bias IAT Allport contact hypothesis stereotype threat intergroup anxiety reduction strategy|vi=định kiến và kỳ thị,prejudice bias|en=prejudice bias`},
		{"SOCIAL2_CONFORMITY",   3,`label=tuân thủ và áp lực xã hội|desc=conformity Asch line experiment Milgram obedience Zimbardo Stanford prison informational normative|vi=tuân thủ và áp lực xã hội,conformity|en=conformity`},

		// ── SEMICONDUCTOR & DISPLAY ───────────────────────────────────
		{"SEMICONDUCTOR_LOGIC",  3,`label=vi mạch logic|desc=logic chip CMOS transistor gate Moore law FinFET GAA 2nm node lithography EUV ASML fab TSMC|vi=vi mạch logic,logic chip|en=logic chip`},
		{"SEMICONDUCTOR_MEMORY", 3,`label=bộ nhớ bán dẫn|desc=memory chip DRAM NAND flash HBM 3D stacking LPDDR bandwidth latency Samsung SK Hynix Micron|vi=bộ nhớ bán dẫn,memory chip|en=memory chip`},
		{"SEMICONDUCTOR_ANALOG", 3,`label=IC tương tự|desc=analog IC op-amp ADC DAC PLL RF front-end power management LDO PMIC mixed signal noise|vi=IC tương tự,analog IC|en=analog IC`},
		{"DISPLAY_OLED",         3,`label=màn hình OLED|desc=OLED organic light emitting diode flexible foldable HDR infinite contrast burn-in Samsung LG Apple|vi=màn hình OLED,OLED display|en=OLED display`},
		{"DISPLAY_MICROLED",     3,`label=màn hình microLED|desc=microLED transfer printing mass yield efficiency Apple Watch AR headset hyperpixel brightness|vi=màn hình microLED,microLED|en=microLED`},

		// ── BATTERY 2 & PHOTOVOLTAIC ─────────────────────────────────
		{"BATTERY2_SOLIDSTATE",  3,`label=pin thể rắn|desc=solid-state battery solid electrolyte lithium metal anode energy density safety Toyota QuantumScape cycle|vi=pin thể rắn,solid-state battery|en=solid-state battery`},
		{"BATTERY2_RECYCLING",   3,`label=tái chế pin|desc=battery recycling lithium cobalt nickel black mass hydrometallurgy pyrometallurgy EU regulation closed loop|vi=tái chế pin,battery recycling|en=battery recycling`},
		{"PHOTOVOLTAIC_PEROV",   3,`label=pin mặt trời perovskite|desc=perovskite solar cell tandem silicon efficiency record 33% stability lead halide ABX3 commercialize|vi=pin mặt trời perovskite,perovskite solar|en=perovskite solar`},
		{"PHOTOVOLTAIC_BIFACIAL",3,`label=pin mặt trời hai mặt|desc=bifacial solar panel rear albedo bifaciality factor tracking tracker energy yield LCOE agrivoltaic|vi=pin mặt trời hai mặt,bifacial solar|en=bifacial solar`},
		{"SENSOR2_LIDAR",        3,`label=LiDAR|desc=LiDAR light detection ranging point cloud 3D mapping autonomous vehicle Velodyne Luminar solid-state SLAM|vi=LiDAR,LiDAR|en=LiDAR`},

		// ── VIETNAM LITERATURE 2 (VNLITERATURE2_) ────────────────────
		{"VNLITERATURE2_TRUYEN", 3,`label=truyện ngắn Việt Nam hiện đại|desc=truyện ngắn Việt Nam hiện đại Nam Cao Thạch Lam Nguyễn Công Hoan Vũ Trọng Phụng phê phán xã hội|vi=truyện ngắn Việt Nam hiện đại,Vietnamese short story|en=Vietnamese short story`},
		{"VNLITERATURE2_NOVEL",  3,`label=tiểu thuyết Việt Nam|desc=tiểu thuyết Việt Nam Nỗi Buồn Chiến Tranh Bảo Ninh Số Đỏ Vũ Trọng Phụng Dế Mèn Tô Hoài|vi=tiểu thuyết Việt Nam,Vietnamese novel|en=Vietnamese novel`},
		{"VNLITERATURE2_DIASPORA",3,`label=văn học Việt kiều|desc=văn học Việt kiều hải ngoại Ocean Vương Monique Trương Aimee Phan Lan Cao văn học di dân bản sắc|vi=văn học Việt kiều,Vietnamese diaspora literature|en=Vietnamese diaspora literature`},
		{"VNSOCIOLOGY_CLASS",    3,`label=giai cấp xã hội Việt Nam|desc=giai cấp Việt Nam tầng lớp trung lưu đô thị hóa nông dân công nhân bất bình đẳng Gini|vi=giai cấp xã hội Việt Nam,Vietnamese social class|en=Vietnamese social class`},
		{"VNSOCIOLOGY_FAMILY",   3,`label=gia đình Việt Nam hiện đại|desc=gia đình Việt Nam hiện đại hạt nhân đa thế hệ tỷ lệ sinh giảm ly hôn tăng vai trò phụ nữ|vi=gia đình Việt Nam hiện đại,Vietnamese family|en=Vietnamese family`},

		// ── VIETNAM URBAN & EDUCATION ─────────────────────────────────
		{"VNURBAN_PLANNING",     3,`label=quy hoạch đô thị Việt Nam|desc=quy hoạch đô thị Việt Nam quy hoạch Hà Nội 2030 TP HCM siêu đô thị không gian xanh ngập lụt|vi=quy hoạch đô thị Việt Nam,Vietnam urban planning|en=Vietnam urban planning`},
		{"VNURBAN_TRANSPORT",    3,`label=giao thông đô thị Việt Nam|desc=giao thông đô thị Việt Nam xe máy metro BRT ùn tắc cơ sở hạ tầng hành vi người dùng|vi=giao thông đô thị Việt Nam,Vietnam urban transport|en=Vietnam urban transport`},
		{"VNEDUCATION_REFORM",   3,`label=cải cách giáo dục Việt Nam|desc=cải cách giáo dục Việt Nam chương trình 2018 SGK mới thi THPT quốc gia tự chủ đại học|vi=cải cách giáo dục Việt Nam,Vietnam education reform|en=Vietnam education reform`},
		{"VNEDUCATION_HIGHER",   3,`label=giáo dục đại học Việt Nam|desc=đại học Việt Nam tự chủ học phí kiểm định ABET VNU HUST RMIT FPT University Fulbright|vi=giáo dục đại học Việt Nam,Vietnam higher education|en=Vietnam higher education`},
		{"VNPOVERTY_REDUCTION",  3,`label=giảm nghèo Việt Nam|desc=giảm nghèo Việt Nam tỷ lệ nghèo 70% 1990 xuống 5% 2020 chương trình 135 dân tộc thiểu số bền vững|vi=giảm nghèo Việt Nam,Vietnam poverty reduction|en=Vietnam poverty reduction`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 4200 { fmt.Println(" MILESTONE 4200! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
