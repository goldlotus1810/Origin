//go:build ignore

// scripts/seed_qt89.go
// Thêm QT8 + QT9 vào homeos.olang
//
// QT8: Không được thay đổi lịch sử và bản chất sự vật, sự việc đã xảy ra
// QT9: Không được gây bất cứ thông tin sai lệch nào
//
// Chạy: go run scripts/seed_qt89.go

package main

import (
	"encoding/binary"
	"fmt"
	"os"
)

func main() {
	path := "homeos.olang"
	raw, err := os.ReadFile(path)
	if err != nil { panic(err) }

	// Backup
	os.WriteFile(path+".bak_qt89", raw, 0644)

	qt8 := makeQTNode(8,
		"LỊCH SỬ BẤT BIẾN",
		`Không được thay đổi lịch sử và bản chất sự vật, sự việc đã xảy ra.
Sự kiện đã xảy ra == thực tế vật lý (QT3).
Không ai — kể cả LeoAI — được phép rewrite, overwrite, hoặc reinterpret
những gì đã được ghi nhận là sự thật (QR).
Vi phạm = SecurityGate từ chối + ghi log bất biến.`,
	)
	qt9 := makeQTNode(9,
		"KHÔNG THÔNG TIN SAI LỆCH",
		`Không được gây bất cứ thông tin sai lệch nào.
FICTION (SourceFiction) không bao giờ được trình bày như FACT.
Confidence cao != sự thật — phải có nguồn FACT + AAM.Approve.
Khi không chắc: nói "chưa biết", không được đoán mò rồi trình bày như thật.
Vi phạm = SecurityGate từ chối + ghi vào Ledger bất biến.`,
	)

	// Đọc header để update node count
	nnodes := int(binary.BigEndian.Uint32(raw[12:16]))
	binary.BigEndian.PutUint32(raw[12:16], uint32(nnodes+2))

	// Append trước edge table
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeSize := nedges * 17
	edgeStart := len(raw) - edgeSize

	newRaw := make([]byte, 0, len(raw)+len(qt8)+len(qt9))
	newRaw = append(newRaw, raw[:edgeStart]...)
	newRaw = append(newRaw, qt8...)
	newRaw = append(newRaw, qt9...)
	newRaw = append(newRaw, raw[edgeStart:]...)

	if err := os.WriteFile(path, newRaw, 0644); err != nil { panic(err) }

	fmt.Printf("✓ QT8 + QT9 added to %s\n", path)
	fmt.Printf("  Nodes: %d → %d\n", nnodes, nnodes+2)
	fmt.Printf("  File: %d → %d bytes\n", len(raw), len(newRaw))
}

func makeQTNode(n int, title, body string) []byte {
	name := fmt.Sprintf("QT%d_DEF", n)
	dna  := fmt.Sprintf("tag=rule|n=%d|title=%s|body=%s", n, title, body)

	var buf []byte
	buf = append(buf, 'N', 'D')
	buf = append(buf, 0x08) // layer BUILD (ĐN — bất biến về nội dung nhưng chưa QR)

	// ISL 8 bytes (placeholder — layer E, group QT)
	isl := [8]byte{'E', 'Q', 'T', byte(n), 0, 0, 0, 0}
	buf = append(buf, isl[:]...)

	// codepoint 4 bytes
	buf = append(buf, 0, 0, 0, 0)

	// dnaLen (4 bytes BE)
	dnaB := []byte(dna)
	dl := make([]byte, 4)
	binary.BigEndian.PutUint32(dl, uint32(len(dnaB)))
	buf = append(buf, dl...)

	// nameLen (1 byte)
	buf = append(buf, byte(len(name)))

	// dna + name
	buf = append(buf, dnaB...)
	buf = append(buf, []byte(name)...)

	return buf
}
