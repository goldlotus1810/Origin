//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── LỊCH SỬ VĂN MINH (CIVHIST_) ─────────────────────────
		{"CIVHIST_MESOPOTAMIA",3,`label=Lưỡng Hà|desc=Mesopotamia Iraq cổ đại Sumerian Akkadian Babylon Hammurabi chữ viết đầu tiên|vi=Lưỡng Hà,Mesopotamia|en=Mesopotamia|zh=美索不达米亚`},
		{"CIVHIST_EGYPT_ANC", 3, `label=Ai Cập cổ đại|desc=pharaoh kim tự tháp Giza sông Nile hieroglyphics Tutankhamun Cleopatra|vi=Ai Cập cổ đại,Ancient Egypt|en=Ancient Egypt|zh=古埃及`},
		{"CIVHIST_ROME",      3, `label=đế quốc La Mã|desc=Roman Empire Julius Caesar Augustus legions Pax Romana Colosseum 27 TCN|vi=đế quốc La Mã,Rome|en=Roman Empire|zh=罗马帝国`},
		{"CIVHIST_GREECE",    3, `label=Hy Lạp cổ đại|desc=polis Athens Sparta democracy philosophy Socrates Plato Aristotle Olympic|vi=Hy Lạp cổ đại,Ancient Greece|en=Ancient Greece|zh=古希腊`},

		// ── KINH TẾ VIỆT NAM VÀ ĐÔNG NAM Á (VNSEA_) ──────────────
		{"VNSEA_ASEAN_TRADE", 3, `label=thương mại ASEAN|desc=AFTA RCEP chuỗi giá trị khu vực tự do thương mại 670 triệu dân|vi=thương mại ASEAN,ASEAN trade|en=ASEAN trade|zh=东盟贸易`},
		{"VNSEA_MANU_HUB",    3, `label=trung tâm sản xuất|desc=Vietnam manufacturing hub Samsung Apple supply chain China plus one strategy|vi=trung tâm sản xuất Việt Nam,manufacturing|en=Vietnam manufacturing hub|zh=越南制造中心`},
		{"VNSEA_FDI",         3, `label=đầu tư trực tiếp nước ngoài VN|desc=FDI Việt Nam Samsung LG Intel chip bán dẫn khu công nghiệp|vi=FDI Việt Nam,foreign direct investment|en=Vietnam FDI|zh=越南外商投资`},

		// ── MÔI TRƯỜNG BIỂN VN (VNMARINE_) ───────────────────────
		{"VNMARINE_HALONG",   3, `label=Vịnh Hạ Long|desc=UNESCO kỳ quan thế giới 1994 đá vôi 1969 đảo khí hậu nhiệt đới du lịch|vi=Vịnh Hạ Long,Halong Bay|en=Halong Bay|zh=下龙湾`},
		{"VNMARINE_PHU_QUOC", 3, `label=Phú Quốc|desc=đảo lớn nhất Việt Nam Kiên Giang du lịch resort biển trong xanh hải sản|vi=Phú Quốc|en=Phu Quoc|zh=富国岛`},
		{"VNMARINE_FISHING",  3, `label=ngư nghiệp Việt Nam|desc=đánh bắt thủy sản nuôi trồng xuất khẩu tôm cá basa 10 tỷ USD|vi=ngư nghiệp Việt Nam,fishery|en=Vietnam fishery|zh=越南渔业`},

		// ── TRIẾT HỌC ĐÔNG Á BỔ SUNG (EASTPHIL2_) ────────────────
		{"EASTPHIL2_CONFUC",  3, `label=Nho giáo|desc=Confucianism Khổng Tử Analects nhân nghĩa lễ trí tín ngũ thường gia đình xã hội|vi=Nho giáo,Confucianism|en=Confucianism|zh=儒学`},
		{"EASTPHIL2_TAOISM",  3, `label=Đạo giáo|desc=Taoism Lão Tử Trang Tử Đạo Đức Kinh vô vi tự nhiên âm dương|vi=Đạo giáo,Taoism|en=Taoism|zh=道教`},
		{"EASTPHIL2_SAMURAI", 3, `label=Bushido|desc=Bushido võ sĩ đạo Nhật Bản trung thành danh dự tự trọng kiếm Katana|vi=Bushido,võ sĩ đạo|en=Bushido|zh=武士道`},

		// ── NÔNG NGHIỆP TƯƠNG LAI (FUTUREAGR_) ────────────────────
		{"FUTUREAGR_VERTICAL",3, `label=nông nghiệp thẳng đứng|desc=vertical farming LED hydroponics aeroponics tiết kiệm nước 95% đô thị|vi=nông nghiệp thẳng đứng,vertical farming|en=vertical farming|zh=垂直农业`},
		{"FUTUREAGR_PRECISION",3,`label=nông nghiệp chính xác|desc=precision agriculture drone GPS sensor IoT dữ liệu lớn giảm hóa chất|vi=nông nghiệp chính xác,precision agriculture|en=precision agriculture|zh=精准农业`},
		{"FUTUREAGR_ALT_PROT",3, `label=protein thay thế|desc=plant-based meat Impossible Foods Beyond Meat insect protein lab-grown meat|vi=protein thay thế,alternative protein|en=alternative protein|zh=替代蛋白质`},

		// ── HÓA HỌC XANH (GREENCHEM_) ───────────────────────────
		{"GREENCHEM_CATALY",  3, `label=xúc tác xanh|desc=green catalysis enzyme biocatalyst zeolite giảm waste atom economy|vi=xúc tác xanh,green catalysis|en=green catalysis|zh=绿色催化`},
		{"GREENCHEM_BIOPLAST",3, `label=nhựa sinh học|desc=bioplastic PLA PHA compostable biodegradable corn starch giải pháp ô nhiễm|vi=nhựa sinh học,bioplastic|en=bioplastic|zh=生物塑料`},

		// ── CÔNG NGHỆ Y TẾ (HEALTHTECH_) ─────────────────────────
		{"HEALTHTECH_TELE",   3, `label=y tế từ xa|desc=telemedicine telehealth video call bác sĩ rural area wearable monitor|vi=y tế từ xa,telemedicine|en=telemedicine|zh=远程医疗`},
		{"HEALTHTECH_WEARABLE",3,`label=thiết bị đeo y tế|desc=wearable health Apple Watch Fitbit continuous glucose monitor ECG heart rate|vi=thiết bị đeo y tế,wearable|en=health wearable|zh=健康可穿戴设备`},
		{"HEALTHTECH_IMAGING",3, `label=chẩn đoán hình ảnh AI|desc=medical imaging AI X-ray CT scan MRI pathology deep learning detection|vi=chẩn đoán hình ảnh AI,medical imaging|en=AI medical imaging|zh=AI医学影像`},

		// ── ĐẠI SỐ VÀ LOGIC (LOGIC_) ────────────────────────────
		{"LOGIC_BOOLEAN",     3, `label=đại số Boolean|desc=Boolean algebra AND OR NOT truth table logic gate circuit digital computer|vi=đại số Boolean,Boolean algebra|en=Boolean algebra|zh=布尔代数`},
		{"LOGIC_FORMAL",      3, `label=logic hình thức|desc=formal logic propositional predicate modus ponens syllogism Aristotle|vi=logic hình thức,formal logic|en=formal logic|zh=形式逻辑`},
		{"LOGIC_FUZZY",       3, `label=logic mờ|desc=fuzzy logic Zadeh degree of truth 0-1 điều khiển máy lạnh washing machine AI|vi=logic mờ,fuzzy logic|en=fuzzy logic|zh=模糊逻辑`},

		// ── VĂN HÓA ĐÔNG NAM Á (SEACULTURE_) ────────────────────
		{"SEACULTURE_BATIK",  3, `label=Batik|desc=nghệ thuật dệt nhuộm Indonesia UNESCO sáp ong hoa văn truyền thống Java|vi=Batik|en=Batik|zh=蜡染`},
		{"SEACULTURE_MUAY_THAI",3,`label=Muay Thai|desc=võ thuật Thái Lan 8 vũ khí tay chân khuỷu gối lịch sử văn hóa|vi=Muay Thai|en=Muay Thai|zh=泰拳`},
		{"SEACULTURE_ANGKOR_CIV",3,`label=văn minh Angkor|desc=Khmer Empire 802-1431 Angkor Thom thủy lợi nông nghiệp kiến trúc|vi=văn minh Angkor,Khmer|en=Angkor civilization|zh=吴哥文明`},

		// ── BỨC XẠ VÀ NĂNG LƯỢNG (RADENER_) ─────────────────────
		{"RADENER_SOLAR_CELL",3, `label=pin mặt trời|desc=photovoltaic silicon monocrystalline polycrystalline perovskite hiệu suất|vi=pin mặt trời,solar cell|en=solar cell|zh=太阳能电池`},
		{"RADENER_WIND_TURB", 3, `label=turbine gió|desc=wind turbine onshore offshore HAWT blade rotor generator MW capacity factor|vi=turbine gió,wind turbine|en=wind turbine|zh=风力涡轮机`},
		{"RADENER_HYDROGEN",  3, `label=hydro xanh|desc=green hydrogen electrolysis renewable energy fuel cell zero-emission transport|vi=hydro xanh,green hydrogen|en=green hydrogen|zh=绿氢`},

		// ── TRIẾT HỌC NGÔN NGỮ (PHILANG_) ───────────────────────
		{"PHILANG_WITTGENSTEIN",3,`label=Wittgenstein|desc=Ludwig Wittgenstein Tractatus Philosophical Investigations language game ngôn ngữ|vi=Wittgenstein|en=Wittgenstein|zh=维特根斯坦`},
		{"PHILANG_CHOMSKY",   3, `label=Noam Chomsky|desc=ngữ pháp biến đổi generative grammar universal grammar language acquisition political|vi=Noam Chomsky,Chomsky|en=Noam Chomsky|zh=乔姆斯基`},

		// ── KINH TẾ HỌC PHÁT TRIỂN (DEVEL_ECON_) ────────────────
		{"DEVEL_ECON_HDI",    3, `label=chỉ số phát triển con người|desc=HDI Human Development Index UNDP tuổi thọ giáo dục thu nhập|vi=chỉ số phát triển con người,HDI|en=HDI|zh=人类发展指数`},
		{"DEVEL_ECON_POVERTY",3, `label=xóa đói giảm nghèo|desc=poverty reduction extreme poverty $2.15/day World Bank MDGs SDGs microfinance|vi=xóa đói giảm nghèo,poverty|en=poverty reduction|zh=减贫`},
		{"DEVEL_ECON_MICRO_FIN",3,`label=tài chính vi mô|desc=microfinance Grameen Bank Muhammad Yunus Nobel 2006 cho vay nhỏ phụ nữ|vi=tài chính vi mô,microfinance|en=microfinance|zh=微型金融`},
	}

	added := 0
	for _, nd := range nodes {
		if existing[nd.name] { continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true
		added++
		fmt.Printf("  + %-26s %q\n", nd.name, extractLabel(nd.dna))
	}
	fmt.Printf("\n+%d nodes\n", added)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2900 { fmt.Println("🎉 MILESTONE 2900!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
