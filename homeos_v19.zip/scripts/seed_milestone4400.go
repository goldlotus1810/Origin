//go:build ignore
// seed_milestone4400.go — MILESTONE 4400 — 100 nodes
// Domains: QUANTUM3_ FUSION_ BIOPHY_ ASTROCHEM_ GEOPHYSICS_
//          COGNITIVE_NEURO2_ CONSCIOUSNESS_ LANGUAGE_ACQ_ EMOTION2_ ATTENTION_
//          SUPPLY_CHAIN_ LOGISTICS2_ WAREHOUSE_ CUSTOMS_ TRADE_FINANCE_
//          CLIMATE2_ CARBON2_ ADAPTATION_ TIPPING_ GEOENG_
//          VIET_HISTORY2_ VIET_KING_ VIET_WAR_ VIET_REFORM_ VIET_RELATION_
//          PHILOSOPHY4_ LOGIC3_ ONTOLOGY_ METAPHYSICS2_ PHENOMENOLOGY_
//          TEXTILES2_ COSMETICS_ PACKAGING_ FOOD_SAFETY_ PHARMA2_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── QUANTUM 3 (QUANTUM3_) ─────────────────────────────────────
		{"QUANTUM3_COMPUTE",     3,`label=máy tính lượng tử|desc=quantum computing qubit superposition entanglement gate error correction surface code Google Sycamore IBM quantum advantage|vi=máy tính lượng tử,quantum computing|en=quantum computing`},
		{"QUANTUM3_CRYPTO",      3,`label=mật mã hậu lượng tử|desc=post-quantum cryptography NIST lattice CRYSTALS-Kyber CRYSTALS-Dilithium Shor algorithm RSA ECC threat timeline|vi=mật mã hậu lượng tử,post-quantum cryptography|en=post-quantum cryptography`},
		{"QUANTUM3_SENSE",       3,`label=cảm biến lượng tử|desc=quantum sensing atomic clock gravimeter magnetometer NV center diamond GPS-free navigation medical imaging|vi=cảm biến lượng tử,quantum sensing|en=quantum sensing`},
		{"QUANTUM3_NETWORK",     3,`label=mạng lượng tử|desc=quantum network entanglement distribution quantum repeater memory teleportation key distribution QKD long distance|vi=mạng lượng tử,quantum network|en=quantum network`},
		{"QUANTUM3_SIMULATION",  3,`label=mô phỏng lượng tử|desc=quantum simulation Feynman Hubbard model chemistry molecules drug discovery material Hamiltonian analog|vi=mô phỏng lượng tử,quantum simulation|en=quantum simulation`},

		// ── FUSION (FUSION_) ──────────────────────────────────────────
		{"FUSION_TOKAMAK",       3,`label=lò phản ứng tokamak|desc=tokamak fusion ITER France plasma confinement D-T fuel 150 million degrees Q>1 net energy gain|vi=lò phản ứng tokamak,tokamak fusion|en=tokamak fusion`},
		{"FUSION_INERTIAL",      3,`label=tổng hợp hạt nhân quán tính|desc=inertial confinement fusion NIF ignition laser hohlraum implosion pellet 2022 breakthrough milestone|vi=tổng hợp hạt nhân quán tính,inertial fusion|en=inertial fusion`},
		{"FUSION_PRIVATE",       3,`label=công ty fusion tư nhân|desc=private fusion Commonwealth Helion TAE Technologies Zap Energy HB11 compact stellarator timeline 2030|vi=công ty fusion tư nhân,private fusion|en=private fusion`},

		// ── BIOPHYSICS (BIOPHY_) ─────────────────────────────────────
		{"BIOPHY_MEMBRANE",      3,`label=sinh lý học màng tế bào|desc=cell membrane biophysics lipid bilayer fluidity raft protein diffusion patch clamp ion channel reconstitution|vi=sinh lý học màng tế bào,membrane biophysics|en=membrane biophysics`},
		{"BIOPHY_MOTOR",         3,`label=protein vận động|desc=molecular motor kinesin myosin dynein ATP hydrolysis step size stall force optical trap single molecule|vi=protein vận động,molecular motor|en=molecular motor`},
		{"BIOPHY_DNA_MECH",      3,`label=cơ học DNA|desc=DNA mechanics persistence length worm-like chain stretching twisting torsion supercoiling topoisomerase AFM|vi=cơ học DNA,DNA mechanics|en=DNA mechanics`},

		// ── ASTROCHEMISTRY & GEOPHYSICS ───────────────────────────────
		{"ASTROCHEM_ISM",        3,`label=hóa học liên sao|desc=interstellar medium chemistry molecular cloud H2 CO complex organic PAH radio astronomy spectroscopy ALMA|vi=hóa học liên sao,interstellar chemistry|en=interstellar chemistry`},
		{"ASTROCHEM_EXOATMOS",   3,`label=khí quyển ngoại hành tinh|desc=exoplanet atmosphere transmission spectroscopy JWST biosignature water methane CO2 habitable zone|vi=khí quyển ngoại hành tinh,exoplanet atmosphere|en=exoplanet atmosphere`},
		{"GEOPHYSICS_SEISMIC",   3,`label=địa chấn học|desc=seismology body wave surface wave tomography mantle structure inner core anisotropy normal mode free oscillation|vi=địa chấn học,seismology|en=seismology`},
		{"GEOPHYSICS_MAGNETIC",  3,`label=từ trường Trái Đất|desc=geomagnetic field dynamo core convection reversal paleomagnetic pole wander compass declination space weather|vi=từ trường Trái Đất,geomagnetic field|en=geomagnetic field`},

		// ── COGNITIVE NEUROSCIENCE 2 (COGNITIVE_NEURO2_) ─────────────
		{"COGNNEURO2_PREDICT",   3,`label=não dự đoán|desc=predictive brain Friston free energy principle predictive coding hierarchical inference precision weighting perception|vi=não dự đoán,predictive brain|en=predictive brain`},
		{"COGNNEURO2_SOCIAL",    3,`label=thần kinh học xã hội|desc=social neuroscience mirror neuron theory of mind mentalizing TPJ empathy oxytocin trust in-group|vi=thần kinh học xã hội,social neuroscience|en=social neuroscience`},
		{"COGNNEURO2_REWARD",    3,`label=hệ thống phần thưởng não|desc=reward system dopamine VTA nucleus accumbens prediction error RPE addiction motivation incentive salience|vi=hệ thống phần thưởng não,reward system brain|en=reward system brain`},
		{"CONSCIOUSNESS_HARD",   3,`label=vấn đề ý thức khó|desc=hard problem consciousness Chalmers phenomenal experience qualia why subjective feel zombie IIT GWT|vi=vấn đề ý thức khó,hard problem consciousness|en=hard problem consciousness`},
		{"CONSCIOUSNESS_NCC",    3,`label=tương quan thần kinh của ý thức|desc=neural correlates consciousness NCC global workspace theory integrated information Tononi Dehaene Koch|vi=tương quan thần kinh của ý thức,neural correlates consciousness|en=neural correlates consciousness`},

		// ── LANGUAGE ACQUISITION (LANGUAGE_ACQ_) ─────────────────────
		{"LANGACQ_L1",           3,`label=thụ đắc ngôn ngữ thứ nhất|desc=first language acquisition LAD Chomsky UG critical period innateness Skinner behaviorism input poverty|vi=thụ đắc ngôn ngữ thứ nhất,first language acquisition|en=first language acquisition`},
		{"LANGACQ_L2",           3,`label=học ngôn ngữ thứ hai|desc=second language acquisition SLA Krashen input hypothesis monitor affective filter interlanguage fossilization|vi=học ngôn ngữ thứ hai,second language acquisition|en=second language acquisition`},
		{"LANGACQ_BILINGUAL",    3,`label=song ngữ từ thơ ấu|desc=bilingual acquisition simultaneous sequential code-mixing BFLA cross-linguistic influence metalinguistic advantage|vi=song ngữ từ thơ ấu,bilingual acquisition|en=bilingual acquisition`},

		// ── EMOTION 2 & ATTENTION ─────────────────────────────────────
		{"EMOTION2_APPRAISAL",   3,`label=lý thuyết đánh giá cảm xúc|desc=appraisal theory Lazarus Scherer Ellsworth relevance novelty coping potential goal congruence|vi=lý thuyết đánh giá cảm xúc,appraisal theory|en=appraisal theory emotion`},
		{"EMOTION2_REGULATION",  3,`label=điều tiết cảm xúc|desc=emotion regulation reappraisal suppression expressive Gross process model antecedent response flexibility strategy|vi=điều tiết cảm xúc,emotion regulation|en=emotion regulation`},
		{"ATTENTION_SELECTIVE",  3,`label=chú ý chọn lọc|desc=selective attention Broadbent filter Treisman attenuation Deutsch Norman late selection cocktail party dichotic|vi=chú ý chọn lọc,selective attention|en=selective attention`},
		{"ATTENTION_MINDFUL",    3,`label=chú ý có chủ đích|desc=mindful attention present moment awareness non-judgmental observe describe participate MBSR DBT skills|vi=chú ý có chủ đích,mindful attention|en=mindful attention`},

		// ── SUPPLY CHAIN (SUPPLY_CHAIN_) ──────────────────────────────
		{"SUPPLY_CHAIN_RISK",    3,`label=rủi ro chuỗi cung ứng|desc=supply chain risk disruption COVID semiconductor shortage single source concentration geographic diversification nearshore|vi=rủi ro chuỗi cung ứng,supply chain risk|en=supply chain risk`},
		{"SUPPLY_CHAIN_VISIBLE", 3,`label=minh bạch chuỗi cung ứng|desc=supply chain visibility blockchain track trace ESG due diligence forced labor EU regulation scope 3|vi=minh bạch chuỗi cung ứng,supply chain visibility|en=supply chain visibility`},
		{"LOGISTICS2_LAST",      3,`label=giao hàng chặng cuối|desc=last mile delivery drone autonomous vehicle micro-fulfillment dark store BOPIS click collect cost 53%|vi=giao hàng chặng cuối,last mile delivery|en=last mile delivery`},
		{"LOGISTICS2_COLD",      3,`label=chuỗi lạnh|desc=cold chain temperature controlled pharmaceutical vaccine 2-8C frozen -20C GDP good distribution practice monitoring|vi=chuỗi lạnh,cold chain logistics|en=cold chain`},
		{"WAREHOUSE_AUTO",       3,`label=kho tự động|desc=warehouse automation AMR autonomous mobile robot goods-to-person Kiva Amazon Symbotic AutoStore WMS throughput|vi=kho tự động,warehouse automation|en=warehouse automation`},

		// ── CLIMATE 2 (CLIMATE2_) ─────────────────────────────────────
		{"CLIMATE2_FEEDBACK",    3,`label=phản hồi khí hậu|desc=climate feedback positive negative water vapor ice albedo cloud lapse rate Planck sensitivity ECS TCR|vi=phản hồi khí hậu,climate feedback|en=climate feedback`},
		{"CLIMATE2_ATTRIBUTION", 3,`label=phân tích nguyên nhân khí hậu|desc=climate attribution extreme event human influence probability ratio FAR World Weather Attribution methodology|vi=phân tích nguyên nhân khí hậu,climate attribution|en=climate attribution`},
		{"CARBON2_CAPTURE",      3,`label=thu hồi carbon|desc=carbon capture CCS CCUS direct air capture DAC Climeworks enhanced weathering biochar soil sequestration|vi=thu hồi carbon,carbon capture|en=carbon capture`},
		{"CARBON2_MARKET",       3,`label=thị trường carbon|desc=carbon market EU ETS cap trade price voluntary offset additionality permanence leakage registry verification|vi=thị trường carbon,carbon market|en=carbon market`},
		{"ADAPTATION_INFRA",     3,`label=hạ tầng thích ứng khí hậu|desc=climate adaptation infrastructure seawall mangrove hybrid green-grey nature based solution cost benefit|vi=hạ tầng thích ứng khí hậu,climate adaptation infrastructure|en=climate adaptation infrastructure`},

		// ── TIPPING POINTS & GEO-ENGINEERING ─────────────────────────
		{"TIPPING_POINTS",       3,`label=điểm bùng phát khí hậu|desc=tipping points AMOC Greenland WAIS Amazon dieback permafrost methane cascade domino 1.5C threshold|vi=điểm bùng phát khí hậu,climate tipping points|en=climate tipping points`},
		{"GEOENG_SOLAR",         3,`label=địa kỹ thuật năng lượng mặt trời|desc=solar geoengineering stratospheric aerosol injection SAI marine cloud brightening SRM governance risk|vi=địa kỹ thuật năng lượng mặt trời,solar geoengineering|en=solar geoengineering`},

		// ── VIETNAM HISTORY 2 (VIET_HISTORY2_) ───────────────────────
		{"VIET_HISTORY_ANCIENT", 3,`label=lịch sử Việt Nam thời cổ đại|desc=lịch sử Việt Nam Văn Lang Âu Lạc Đông Sơn trống đồng Hùng Vương An Dương Vương Triệu Đà|vi=lịch sử Việt Nam thời cổ đại,ancient Vietnam history|en=ancient Vietnam history`},
		{"VIET_HISTORY_NORTH",   3,`label=thời kỳ Bắc thuộc|desc=Bắc thuộc 1000 năm Hán Đường đô hộ Hai Bà Trưng Lý Bí Triệu Quang Phục Ngô Quyền Bạch Đằng 938|vi=thời kỳ Bắc thuộc,Vietnam Chinese domination|en=Vietnam Chinese domination`},
		{"VIET_HISTORY_DYNASTIES",3,`label=các triều đại Việt Nam|desc=triều đại Việt Nam Đinh Lý Trần Lê Mạc Tây Sơn Nguyễn thống nhất mở rộng lãnh thổ văn hóa|vi=các triều đại Việt Nam,Vietnamese dynasties|en=Vietnamese dynasties`},
		{"VIET_HISTORY_FRENCH",  3,`label=thời kỳ Pháp thuộc|desc=Pháp thuộc Việt Nam 1858-1954 Đông Dương khai thác thuộc địa Phan Bội Châu Phan Châu Trinh Việt Minh|vi=thời kỳ Pháp thuộc,Vietnam French colonialism|en=Vietnam French colonialism`},
		{"VIET_HISTORY_WAR",     3,`label=kháng chiến chống Mỹ|desc=kháng chiến chống Mỹ 1955-1975 Điện Biên Phủ Hiệp định Geneva Mậu Thân 1968 giải phóng 30/4/1975|vi=kháng chiến chống Mỹ,Vietnam War|en=Vietnam War`},

		// ── VIETNAM FOREIGN RELATIONS & REFORM ───────────────────────
		{"VIET_REFORM_DOI_MOI",  3,`label=Đổi Mới|desc=Đổi Mới 1986 kinh tế thị trường định hướng XHCN tư nhân hóa mở cửa FDI tăng trưởng thoát nghèo|vi=Đổi Mới,Doi Moi reform|en=Doi Moi reform`},
		{"VIET_RELATION_ASEAN",  3,`label=Việt Nam và ASEAN|desc=Việt Nam ASEAN 1995 hội nhập khu vực AEC RCEP vai trò chủ tịch ASEAN 2010 2020 trung tâm|vi=Việt Nam và ASEAN,Vietnam ASEAN|en=Vietnam ASEAN`},
		{"VIET_RELATION_US",     3,`label=quan hệ Việt-Mỹ|desc=quan hệ Việt Nam Hoa Kỳ bình thường hóa 1995 đối tác chiến lược toàn diện 2023 thương mại quốc phòng|vi=quan hệ Việt-Mỹ,Vietnam US relations|en=Vietnam US relations`},
		{"VIET_RELATION_CHINA",  3,`label=quan hệ Việt-Trung|desc=quan hệ Việt Nam Trung Quốc 16 chữ vàng Biển Đông tranh chấp thương mại phụ thuộc cân bằng chiến lược|vi=quan hệ Việt-Trung,Vietnam China relations|en=Vietnam China relations`},
		{"VIET_KING_HEROES",     3,`label=anh hùng dân tộc Việt Nam|desc=anh hùng Việt Nam Trần Hưng Đạo Nguyễn Trãi Lê Lợi Quang Trung Nguyễn Huệ Hồ Chí Minh Võ Nguyên Giáp|vi=anh hùng dân tộc Việt Nam,Vietnamese national heroes|en=Vietnamese national heroes`},

		// ── PHILOSOPHY 4 (PHILOSOPHY4_) ──────────────────────────────
		{"PHILOSOPHY4_PRAGMA",   3,`label=triết học thực dụng|desc=pragmatism Peirce James Dewey Rorty truth as what works fallibilism inquiry community consequences|vi=triết học thực dụng,pragmatism|en=pragmatism`},
		{"PHILOSOPHY4_EXISTENT", 3,`label=triết học hiện sinh|desc=existentialism Sartre Camus Heidegger Kierkegaard authenticity bad faith thrownness anxiety nothingness|vi=triết học hiện sinh,existentialism|en=existentialism`},
		{"PHILOSOPHY4_ANALYTIC", 3,`label=triết học phân tích|desc=analytic philosophy Russell Moore Frege Vienna Circle logical positivism ordinary language Wittgenstein clarity|vi=triết học phân tích,analytic philosophy|en=analytic philosophy`},
		{"ONTOLOGY_CATEGORIES",  3,`label=bản thể học phạm trù|desc=ontological categories substance property relation event process trope bundle theory four-dimensionalism|vi=bản thể học phạm trù,ontology categories|en=ontology categories`},
		{"PHENOMENOLOGY_HUSSERL",3,`label=hiện tượng học|desc=phenomenology Husserl intentionality epoché reduction life-world Heidegger Merleau-Ponty embodiment Levinas|vi=hiện tượng học,phenomenology|en=phenomenology`},

		// ── PHARMA 2 & FOOD SAFETY ────────────────────────────────────
		{"PHARMA2_CLINICAL",     3,`label=thử nghiệm lâm sàng|desc=clinical trial phase I II III IV randomization blinding placebo CONSORT ICH GCP endpoints power|vi=thử nghiệm lâm sàng,clinical trial|en=clinical trial`},
		{"PHARMA2_REGULATORY",   3,`label=quản lý dược phẩm|desc=pharmaceutical regulation FDA EMA ICH NDA BLA IND accelerated approval breakthrough therapy priority review|vi=quản lý dược phẩm,pharmaceutical regulation|en=pharmaceutical regulation`},
		{"PHARMA2_GENERIC",      3,`label=thuốc generic|desc=generic drug bioequivalence ANDA patent cliff Hatch-Waxman paragraph IV challenge biosimilar interchangeable|vi=thuốc generic,generic drug|en=generic drug`},
		{"FOOD_SAFETY_HACCP",    3,`label=an toàn thực phẩm HACCP|desc=HACCP hazard analysis critical control point food safety management ISO 22000 preventive controls FDA FSMA|vi=an toàn thực phẩm HACCP,HACCP food safety|en=HACCP food safety`},
		{"FOOD_SAFETY_VIETNAM",  3,`label=an toàn thực phẩm Việt Nam|desc=an toàn thực phẩm Việt Nam thuốc bảo vệ thực vật tồn dư kháng sinh rau quả kiểm soát chuỗi|vi=an toàn thực phẩm Việt Nam,Vietnam food safety|en=Vietnam food safety`},

		// ── COSMETICS & PACKAGING ─────────────────────────────────────
		{"COSMETICS_ACTIVE",     3,`label=hoạt chất mỹ phẩm|desc=cosmetic active retinol niacinamide vitamin C peptide hyaluronic acid AHA BHA stability formulation|vi=hoạt chất mỹ phẩm,cosmetic active ingredient|en=cosmetic active ingredient`},
		{"COSMETICS_REGULATION", 3,`label=quản lý mỹ phẩm|desc=cosmetic regulation EU banned list INCI name safety assessment animal testing ban claim substantiation|vi=quản lý mỹ phẩm,cosmetic regulation|en=cosmetic regulation`},
		{"PACKAGING_SUSTAIN",    3,`label=bao bì bền vững|desc=sustainable packaging reduce reuse recycle monomaterial bio-based compostable extended producer responsibility EPR|vi=bao bì bền vững,sustainable packaging|en=sustainable packaging`},
		{"PACKAGING_ACTIVE",     3,`label=bao bì tích cực|desc=active packaging oxygen scavenger ethylene absorber antimicrobial modified atmosphere MAP shelf life extension|vi=bao bì tích cực,active packaging|en=active packaging`},

		// ── CUSTOMS & TRADE FINANCE ───────────────────────────────────
		{"CUSTOMS_PROCEDURE",    3,`label=thủ tục hải quan|desc=customs procedure HS code tariff classification valuation origin rules AEO authorized operator C-TPAT|vi=thủ tục hải quan,customs procedure|en=customs procedure`},
		{"TRADE_FINANCE",        3,`label=tài trợ thương mại|desc=trade finance letter of credit documentary collection open account supply chain finance SCF factoring forfaiting|vi=tài trợ thương mại,trade finance|en=trade finance`},

		// ── LOGIC 3 ───────────────────────────────────────────────────
		{"LOGIC3_NONMONOTONE",   3,`label=logic phi đơn điệu|desc=nonmonotonic logic default reasoning circumscription closed world assumption answer set programming defeasible|vi=logic phi đơn điệu,nonmonotonic logic|en=nonmonotonic logic`},
		{"LOGIC3_TEMPORAL",      3,`label=logic thời gian|desc=temporal logic LTL CTL model checking Kripke structure until since always eventually PLTL safety liveness|vi=logic thời gian,temporal logic|en=temporal logic`},
		{"METAPHYSICS2_FREE",    3,`label=ý chí tự do|desc=free will determinism compatibilism incompatibilism libertarian agent causation Frankfurt cases moral responsibility|vi=ý chí tự do,free will|en=free will`},
		{"TEXTILES2_SMART",      3,`label=vải thông minh|desc=smart textile e-textile conductive yarn embedded sensor actuator wearable health monitoring motion capture|vi=vải thông minh,smart textile|en=smart textile`},
		{"LANGACQ_CRITICAL",     3,`label=thời kỳ nhạy cảm ngôn ngữ|desc=critical period language acquisition Lenneberg Genie case neural plasticity phonology grammar accent native-like|vi=thời kỳ nhạy cảm ngôn ngữ,critical period language|en=critical period language`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 4400 { fmt.Println(" MILESTONE 4400! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
