//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── KHOA HỌC KHUYẾN KHÍCH (NUDGE_) ──────────────────────
		{"NUDGE_CHOICE_ARCH",3,`label=kiến trúc lựa chọn|desc=choice architecture Richard Thaler default option opt-in opt-out organ donation savings nudge|vi=kiến trúc lựa chọn,choice architecture|en=choice architecture|zh=选择架构`},
		{"NUDGE_FRAMING",   3,`label=hiệu ứng đóng khung|desc=framing effect Tversky Kahneman gain loss presentation same information different reaction|vi=hiệu ứng đóng khung,framing effect|en=framing effect|zh=框架效应`},
		{"NUDGE_ANCHOR",    3,`label=hiệu ứng neo giá|desc=anchoring bias first number influences judgment salary negotiation price retail|vi=hiệu ứng neo giá,anchoring|en=anchoring bias|zh=锚定效应`},

		// ── KHOA HỌC NƯỚC (HYDRO_) ───────────────────────────────
		{"HYDRO_GROUNDWATER",3,`label=nước ngầm|desc=groundwater aquifer well pumping depletion Ogallala High Plains California over-extraction|vi=nước ngầm,groundwater|en=groundwater|zh=地下水`},
		{"HYDRO_WATERSHED",  3,`label=lưu vực sông|desc=watershed catchment drainage basin river tributary land use hydrology flood|vi=lưu vực sông,watershed|en=watershed|zh=流域`},
		{"HYDRO_DESALIN",    3,`label=khử muối nước biển|desc=desalination reverse osmosis Saudi Arabia UAE Israel energy cost brine|vi=khử muối nước biển,desalination|en=desalination|zh=海水淡化`},

		// ── TỰ NHIÊN HỌC ĐẶC BIỆT (NATSPEC_) ─────────────────────
		{"NATSPEC_MIGRATION",3,`label=di cư động vật|desc=animal migration monarch butterfly Arctic tern wildebeest salmon navigation GPS magnetic|vi=di cư động vật,animal migration|en=animal migration|zh=动物迁徙`},
		{"NATSPEC_BIOLUM",   3,`label=phát quang sinh học|desc=bioluminescence firefly deep sea anglerfish dinoflagellate ATP luciferin cold light|vi=phát quang sinh học,bioluminescence|en=bioluminescence|zh=生物发光`},
		{"NATSPEC_SYMBIOSIS",3,`label=cộng sinh|desc=symbiosis mutualism clownfish anemone mycorrhiza lichen nitrogen-fixing bacteria cleaner fish|vi=cộng sinh,symbiosis|en=symbiosis|zh=共生`},
		{"NATSPEC_CAMOUFLAGE",3,`label=ngụy trang sinh vật|desc=camouflage octopus chameleon stick insect leaf-tailed gecko background matching countershading|vi=ngụy trang sinh vật,camouflage|en=biological camouflage|zh=生物伪装`},

		// ── CÔNG NGHỆ KHÔNG GIAN (SPACETECH_) ────────────────────
		{"SPACETECH_ROCKET", 3,`label=tên lửa|desc=rocket propulsion Tsiolkovsky equation thrust specific impulse SpaceX Falcon 9 reusable|vi=tên lửa,rocket|en=rocket|zh=火箭`},
		{"SPACETECH_ORBIT",  3,`label=quỹ đạo vệ tinh|desc=LEO MEO GEO HEO Starlink ISS orbital mechanics period inclination|vi=quỹ đạo vệ tinh,satellite orbit|en=satellite orbit|zh=卫星轨道`},
		{"SPACETECH_SPACE_ST",3,`label=trạm vũ trụ|desc=space station ISS Tiangong microgravity research module long duration NASA ESA|vi=trạm vũ trụ,ISS,space station|en=space station|zh=空间站`},

		// ── VẬT LÝ HẠT NHÂN BỔ SUNG (NUCPHYS_) ──────────────────
		{"NUCPHYS_FISSION2", 3,`label=phân hạch hạt nhân|desc=nuclear fission U-235 Pu-239 chain reaction critical mass bomb reactor Enrico Fermi|vi=phân hạch hạt nhân,nuclear fission|en=nuclear fission|zh=核裂变`},
		{"NUCPHYS_RADIOACT", 3,`label=phóng xạ|desc=radioactivity alpha beta gamma decay half-life Curie Becquerel isotope carbon-14 dating|vi=phóng xạ,radioactivity|en=radioactivity|zh=放射性`},

		// ── KINH TẾ SỐ BỔ SUNG (DIGI_ECON2_) ────────────────────
		{"DIGI_ECON2_PLAT",  3,`label=nền tảng kỹ thuật số|desc=digital platform two-sided market network effect Amazon Apple Google Facebook monopoly|vi=nền tảng kỹ thuật số,digital platform|en=digital platform|zh=数字平台`},
		{"DIGI_ECON2_SUBSCR",3,`label=mô hình đăng ký|desc=subscription model SaaS Netflix Spotify recurring revenue MRR ARR churn rate|vi=mô hình đăng ký,subscription|en=subscription model|zh=订阅模式`},
		{"DIGI_ECON2_MARKET",3,`label=thị trường trực tuyến|desc=online marketplace Amazon eBay Alibaba Shopee two-sided liquidity trust rating|vi=thị trường trực tuyến,online marketplace|en=online marketplace|zh=网络市场`},

		// ── VĂN HÓA ĐỌC (READING_) ───────────────────────────────
		{"READING_SPEED",    3,`label=đọc nhanh|desc=speed reading Tim Ferriss Evelyn Wood skimming scanning retention comprehension|vi=đọc nhanh,speed reading|en=speed reading|zh=速读`},
		{"READING_ACTIVE",   3,`label=đọc chủ động|desc=active reading annotation Cornell notes SQ3R synthesis critical thinking|vi=đọc chủ động,active reading|en=active reading|zh=主动阅读`},
		{"READING_SPACED",   3,`label=ôn tập cách quãng|desc=spaced repetition Ebbinghaus forgetting curve Anki SuperMemo flashcard memory retention|vi=ôn tập cách quãng,spaced repetition|en=spaced repetition|zh=间隔重复`},

		// ── KIẾN TRÚC THẾ GIỚI (ARCH_) ───────────────────────────
		{"ARCH_GOTHIC2",     3,`label=kiến trúc Gothic|desc=Gothic architecture Notre Dame pointed arch flying buttress stained glass Cologne Cathedral|vi=kiến trúc Gothic,Gothic architecture|en=Gothic architecture|zh=哥特式建筑`},
		{"ARCH_BAUHAUS",     3,`label=Bauhaus|desc=Bauhaus school 1919 Gropius form follows function modernism design art craft Dessau|vi=Bauhaus|en=Bauhaus|zh=包豪斯`},
		{"ARCH_JAPANESE",    3,`label=kiến trúc Nhật Bản|desc=Japanese architecture timber shoji screen engawa zen garden Ise Shrine torii|vi=kiến trúc Nhật Bản,Japanese architecture|en=Japanese architecture|zh=日本建筑`},
		{"ARCH_ISLAMIC2",    3,`label=kiến trúc Hồi giáo|desc=Islamic architecture Taj Mahal muqarnas arabesque calligraphy mosque dome minaret|vi=kiến trúc Hồi giáo,Islamic architecture|en=Islamic architecture|zh=伊斯兰建筑`},

		// ── DI TRUYỀN HỌC DÂN SỐ (POPGEN_) ──────────────────────
		{"POPGEN_DRIFT",     3,`label=trôi dạt di truyền|desc=genetic drift random allele frequency change small population bottleneck founder effect|vi=trôi dạt di truyền,genetic drift|en=genetic drift|zh=遗传漂变`},
		{"POPGEN_SELECTION", 3,`label=chọn lọc tự nhiên|desc=natural selection fitness survival variation heritable Darwin Malthus directional stabilizing|vi=chọn lọc tự nhiên,natural selection|en=natural selection|zh=自然选择`},
		{"POPGEN_HWE",       3,`label=cân bằng Hardy-Weinberg|desc=Hardy-Weinberg equilibrium allele frequency p+q=1 p²+2pq+q²=1 no selection mutation migration|vi=cân bằng Hardy-Weinberg,HWE|en=Hardy-Weinberg equilibrium|zh=哈迪-温伯格定律`},

		// ── LÝ THUYẾT HỌC (LEARN_THEORY_) ───────────────────────
		{"LEARN_THEORY_BEHAV",3,`label=chủ nghĩa hành vi|desc=behaviorism Pavlov Skinner Watson stimulus response conditioning operant classical|vi=chủ nghĩa hành vi,behaviorism|en=behaviorism|zh=行为主义`},
		{"LEARN_THEORY_COGN",3,`label=học nhận thức|desc=cognitive learning schema assimilation accommodation Piaget information processing memory|vi=học nhận thức,cognitive learning|en=cognitive learning|zh=认知学习`},
		{"LEARN_THEORY_CONS",3,`label=kiến tạo luận|desc=constructivism Piaget Vygotsky active construction knowledge social context zone proximal|vi=kiến tạo luận,constructivism|en=constructivism|zh=建构主义`},
		{"LEARN_THEORY_MULTI",3,`label=đa trí thông minh|desc=Multiple Intelligences Howard Gardner linguistic logical musical spatial bodily interpersonal|vi=đa trí thông minh,Multiple Intelligences|en=Multiple Intelligences|zh=多元智能`},

		// ── ĐÔ THỊ HỌC (URBANISM_) ───────────────────────────────
		{"URBANISM_DENSITY",  3,`label=mật độ đô thị|desc=urban density high-rise compact city Tokyo Hong Kong Singapore walkability transit|vi=mật độ đô thị,urban density|en=urban density|zh=城市密度`},
		{"URBANISM_GENTRIFICATION",3,`label=quý tộc hóa đô thị|desc=gentrification displacement rent increase cultural change Brooklyn Brooklyn SOMA London|vi=quý tộc hóa đô thị,gentrification|en=gentrification|zh=士绅化`},
		{"URBANISM_SMART_CITY",3,`label=thành phố thông minh|desc=smart city IoT sensor data governance Songdo Singapore Barcelona mobility energy|vi=thành phố thông minh,smart city|en=smart city|zh=智慧城市`},
		{"URBANISM_TRANSPORT",3,`label=giao thông đô thị|desc=urban transport BRT metro cycling walkability mode share Jakarta Bogotá congestion|vi=giao thông đô thị,urban transport|en=urban transport|zh=城市交通`},

		// ── NGHỆ THUẬT THỊ GIÁC (VISART_) ───────────────────────
		{"VISART_IMPRESSIONISM",3,`label=trường phái Ấn tượng|desc=Impressionism Monet Renoir Degas light color atmosphere open air 1874 Paris|vi=trường phái Ấn tượng,Impressionism|en=Impressionism|zh=印象派`},
		{"VISART_RENAISSANCE2",3,`label=nghệ thuật Phục Hưng|desc=Renaissance art Leonardo Michelangelo Raphael Florence perspective human anatomy|vi=nghệ thuật Phục Hưng,Renaissance art|en=Renaissance art|zh=文艺复兴艺术`},
		{"VISART_PHOTOGRAPHY",3,`label=nhiếp ảnh|desc=photography Daguerre 1839 film digital DSLR mirrorless composition light aperture shutter|vi=nhiếp ảnh,photography|en=photography|zh=摄影`},
		{"VISART_GRAPHIC_DESIGN",3,`label=thiết kế đồ họa|desc=graphic design Bauhaus typography grid layout color Pentagram Milton Glaser branding|vi=thiết kế đồ họa,graphic design|en=graphic design|zh=平面设计`},

		// ── NÔNG NGHIỆP VIỆT NAM (VNAGR_) ───────────────────────
		{"VNAGR_RICE",       3,`label=lúa gạo Việt Nam|desc=rice Vietnam xuất khẩu thứ 3 thế giới đồng bằng sông Cửu Long Mekong IR50404 ST25|vi=lúa gạo Việt Nam,Vietnam rice|en=Vietnam rice|zh=越南大米`},
		{"VNAGR_COFFEE",     3,`label=cà phê Việt Nam|desc=Robusta Arabica xuất khẩu thứ 2 thế giới Đắk Lắk Buôn Ma Thuột Highland|vi=cà phê Việt Nam,Vietnam coffee|en=Vietnam coffee|zh=越南咖啡`},
		{"VNAGR_AQUACULTURE",3,`label=nuôi trồng thủy sản VN|desc=aquaculture Vietnam cá tra cá basa tôm sú ĐBSCL 10 tỷ USD xuất khẩu|vi=nuôi trồng thủy sản,aquaculture|en=Vietnam aquaculture|zh=越南水产养殖`},

		// ── VẬT LÝ NHIỆT (THERMOPHYS_) ──────────────────────────
		{"THERMOPHYS_ENTROPY",3,`label=entropy|desc=entropy disorder thermodynamics second law heat death Boltzmann information Shannon|vi=entropy|en=entropy|zh=熵`},
		{"THERMOPHYS_CARNOT",3,`label=chu trình Carnot|desc=Carnot cycle heat engine efficiency Sadi Carnot 1824 maximum efficiency thermodynamics|vi=chu trình Carnot,Carnot cycle|en=Carnot cycle|zh=卡诺循环`},
		{"THERMOPHYS_PHASE", 3,`label=chuyển pha|desc=phase transition solid liquid gas plasma triple point critical point latent heat|vi=chuyển pha,phase transition|en=phase transition|zh=相变`},

		// ── KHOA HỌC DỮ LIỆU BỔ SUNG (DATASCI2_) ────────────────
		{"DATASCI2_CLEANING",3,`label=làm sạch dữ liệu|desc=data cleaning missing values outlier normalization encoding tidy data Hadley Wickham|vi=làm sạch dữ liệu,data cleaning|en=data cleaning|zh=数据清洗`},
		{"DATASCI2_SQL",     3,`label=SQL|desc=Structured Query Language SELECT JOIN WHERE GROUP BY aggregate relational database Edgar Codd|vi=SQL|en=SQL|zh=SQL`},
		{"DATASCI2_TABLEAU", 3,`label=trực quan hóa dữ liệu nâng cao|desc=Tableau Power BI D3.js Plotly dashboard KPI storytelling chart type|vi=trực quan hóa dữ liệu nâng cao,Tableau|en=data visualization tools|zh=数据可视化工具`},

		// ── TIẾP THỊ (MARKETING_) ────────────────────────────────
		{"MARKETING_4P",     3,`label=4P Marketing|desc=Marketing Mix Product Price Place Promotion McCarthy Kotler strategy positioning|vi=4P Marketing,Marketing Mix|en=marketing mix 4P|zh=4P营销组合`},
		{"MARKETING_SEO",    3,`label=SEO|desc=Search Engine Optimization Google ranking keyword backlink PageRank on-page off-page|vi=SEO,tối ưu công cụ tìm kiếm|en=SEO|zh=搜索引擎优化`},
		{"MARKETING_CONTENT",3,`label=tiếp thị nội dung|desc=content marketing blog video podcast storytelling Hubspot inbound lead generation|vi=tiếp thị nội dung,content marketing|en=content marketing|zh=内容营销`},
		{"MARKETING_BRAND",  3,`label=xây dựng thương hiệu|desc=branding brand equity Aaker Keller logo tagline positioning Nike Apple brand loyalty|vi=xây dựng thương hiệu,branding|en=branding|zh=品牌建设`},

		// ── PHÁP LÝ VÀ CÔNG NGHỆ (LEGALTECH_) ───────────────────
		{"LEGALTECH_IP",     3,`label=sở hữu trí tuệ|desc=intellectual property patent trademark copyright trade secret WIPO innovation|vi=sở hữu trí tuệ,IP|en=intellectual property|zh=知识产权`},
		{"LEGALTECH_GDPR",   3,`label=GDPR|desc=General Data Protection Regulation EU 2018 data privacy consent fine right to erasure|vi=GDPR,bảo vệ dữ liệu cá nhân|en=GDPR|zh=通用数据保护条例`},
		{"LEGALTECH_CYBER",  3,`label=luật an ninh mạng|desc=cybersecurity law CFAA Computer Fraud Abuse Act hacking jurisdiction cybercrime|vi=luật an ninh mạng,cyber law|en=cyber law|zh=网络安全法`},

		// ── LỊCH SỬ HÀN QUỐC (KORHIST_) ─────────────────────────
		{"KORHIST_THREE_KING",3,`label=Tam Quốc Triều Tiên|desc=Three Kingdoms Korea Goguryeo Baekje Silla 57 BCE Buddhism art Silla unification|vi=Tam Quốc Triều Tiên,Three Kingdoms Korea|en=Three Kingdoms of Korea|zh=朝鲜三国时代`},
		{"KORHIST_JOSEON",   3,`label=Triều Joseon|desc=Joseon dynasty 1392-1897 Confucian Neo-Confucianism Hangul 1443 King Sejong|vi=Triều Joseon,Joseon|en=Joseon dynasty|zh=朝鲜王朝`},
		{"KORHIST_KOREAN_WAR",3,`label=Chiến tranh Triều Tiên|desc=Korean War 1950-1953 38th parallel UN China armistice DMZ 3 triệu|vi=Chiến tranh Triều Tiên,Korean War|en=Korean War|zh=朝鲜战争`},

		// ── KHOA HỌC VẬT LIỆU BỔ SUNG (MATEQ_) ──────────────────
		{"MATEQ_ALLOY",      3,`label=hợp kim|desc=alloy steel stainless iron carbon tungsten titanium shape memory nickel superalloy|vi=hợp kim,alloy|en=alloy|zh=合金`},
		{"MATEQ_POLYMER",    3,`label=polymer|desc=polymer chain monomer nylon polyester rubber silicone thermoplastic thermoset Bakelite|vi=polymer|en=polymer|zh=聚合物`},
		{"MATEQ_CERAMIC2",   3,`label=gốm sứ tiên tiến|desc=advanced ceramics alumina zirconia silicon carbide armor heat shield dental implant|vi=gốm sứ tiên tiến,advanced ceramics|en=advanced ceramics|zh=先进陶瓷`},

		// ── TIẾN HÓA XÃ HỘI (SOCEVOL_) ──────────────────────────
		{"SOCEVOL_COOP",     3,`label=hợp tác và tiến hóa|desc=cooperative evolution kin selection reciprocal altruism group selection Hamilton Axelrod|vi=hợp tác và tiến hóa,cooperative evolution|en=cooperative evolution|zh=合作进化`},
		{"SOCEVOL_CULTURE_EVOL",3,`label=tiến hóa văn hóa|desc=cultural evolution meme Dawkins memetics Richerson Boyd gene-culture coevolution|vi=tiến hóa văn hóa,cultural evolution|en=cultural evolution|zh=文化进化`},
		{"SOCEVOL_LANG_EVOL",3,`label=tiến hóa ngôn ngữ|desc=language evolution Chomsky universal grammar proto-language gesture hypothesis social brain|vi=tiến hóa ngôn ngữ,language evolution|en=language evolution|zh=语言进化`},

		// ── CÁC VẤN ĐỀ TOÀN CẦU (GLOBAL_ISS_) ───────────────────
		{"GLOBAL_ISS_REFUGEE",3,`label=người tị nạn|desc=refugee UNHCR 100 triệu displaced Syria Afghanistan Myanmar Rohingya camp|vi=người tị nạn,refugee|en=refugee|zh=难民`},
		{"GLOBAL_ISS_FOOD_SEC",3,`label=an ninh lương thực|desc=food security FAO hunger 800 triệu climate crop failure supply chain resilience|vi=an ninh lương thực,food security|en=food security|zh=粮食安全`},
		{"GLOBAL_ISS_WATER",  3,`label=khủng hoảng nước|desc=water crisis 2 tỷ thiếu nước sạch aquifer depletion climate conflict water war|vi=khủng hoảng nước,water crisis|en=water crisis|zh=水资源危机`},
		{"GLOBAL_ISS_PANDEM", 3,`label=đại dịch|desc=pandemic COVID-19 influenza 1918 Ebola preparedness WHO surveillance zoonotic|vi=đại dịch,pandemic|en=pandemic|zh=大流行病`},

		// ── VĂN HỌC VIỆT NAM MỞ RỘNG (VNLIT3_) ──────────────────
		{"VNLIT3_TRUYEN_KIEU",3,`label=Truyện Kiều|desc=Nguyễn Du 3254 câu lục bát 1820 Thúy Kiều tài hoa bất hạnh kiệt tác văn học|vi=Truyện Kiều,Kim Vân Kiều|en=The Tale of Kieu|zh=金云翘传`},
		{"VNLIT3_NAM_QUOC",  3,`label=Nam quốc sơn hà|desc=thơ tứ tuyệt độc lập chủ quyền Lý Thường Kiệt 1077 chống Tống sông Như Nguyệt|vi=Nam quốc sơn hà|en=Nam Quoc Son Ha|zh=南国山河`},
		{"VNLIT3_HO_XUAN",   3,`label=Hồ Xuân Hương|desc=Bà chúa thơ Nôm thế kỷ 18-19 thơ ẩn dụ phụ nữ xã hội phong kiến nổi loạn|vi=Hồ Xuân Hương|en=Ho Xuan Huong|zh=胡春香`},

		// ── KỸ THUẬT ĐIỀU KHIỂN (CTRL_ENG_) ─────────────────────
		{"CTRL_ENG_PID",     3,`label=bộ điều khiển PID|desc=PID controller Proportional Integral Derivative feedback control industrial automation|vi=bộ điều khiển PID,PID|en=PID controller|zh=PID控制器`},
		{"CTRL_ENG_FEEDBACK",3,`label=vòng phản hồi điều khiển|desc=feedback loop closed-loop control error signal setpoint actuator sensor stability|vi=vòng phản hồi điều khiển,feedback loop|en=control feedback loop|zh=控制反馈回路`},
		{"CTRL_ENG_ROBOT_CTRL",3,`label=điều khiển robot|desc=robot control kinematics dynamics trajectory planning ROS2 inverse kinematics|vi=điều khiển robot,robot control|en=robot control|zh=机器人控制`},

		// ── XỬ LÝ NGÔN NGỮ TỰ NHIÊN NÂNG CAO (NLP2_) ────────────
		{"NLP2_BERT",        3,`label=BERT|desc=Bidirectional Encoder Representations from Transformers Google 2018 pre-training fine-tuning|vi=BERT|en=BERT|zh=BERT`},
		{"NLP2_GPT",         3,`label=GPT|desc=Generative Pre-trained Transformer OpenAI GPT-1 2 3 4 autoregressive language model|vi=GPT|en=GPT|zh=GPT`},
		{"NLP2_RAG",         3,`label=RAG|desc=Retrieval Augmented Generation vector database semantic search LLM knowledge grounding|vi=RAG,Retrieval Augmented Generation|en=RAG|zh=检索增强生成`},
		{"NLP2_AGENT",       3,`label=AI agent|desc=autonomous AI agent LLM tool use planning memory reflection ReAct chain-of-thought|vi=AI agent,tác nhân AI|en=AI agent|zh=AI智能体`},

		// ── MỐI QUAN HỆ QUỐC TẾ (IR_) ───────────────────────────
		{"IR_REALISM",       3,`label=chủ nghĩa hiện thực QT|desc=realism IR Morgenthau Waltz power balance national interest security dilemma anarchy|vi=chủ nghĩa hiện thực quốc tế,realism|en=realism IR|zh=国际关系现实主义`},
		{"IR_LIBERALISM",    3,`label=chủ nghĩa tự do QT|desc=liberalism IR Kant democratic peace Woodrow Wilson institutions cooperation interdependence|vi=chủ nghĩa tự do quốc tế,liberalism IR|en=liberalism IR|zh=国际关系自由主义`},
		{"IR_SOFT_POWER",    3,`label=sức mạnh mềm|desc=soft power Joseph Nye attraction culture values foreign policy K-pop Confucius Institute|vi=sức mạnh mềm,soft power|en=soft power|zh=软实力`},

		// ── SINH THÁI NÔNG NGHIỆP (AGROECO_) ─────────────────────
		{"AGROECO_PERMACULTURE",3,`label=nông nghiệp bền vững|desc=permaculture Bill Mollison David Holmgren design principle zone sector edge|vi=nông nghiệp bền vững,permaculture|en=permaculture|zh=永续农业`},
		{"AGROECO_ORGANIC",  3,`label=nông nghiệp hữu cơ|desc=organic farming no synthetic pesticide herbicide GMO certification soil health|vi=nông nghiệp hữu cơ,organic farming|en=organic farming|zh=有机农业`},
		{"AGROECO_AGROFOREST",3,`label=nông lâm kết hợp|desc=agroforestry trees crops livestock integrated carbon sequestration shade coffee|vi=nông lâm kết hợp,agroforestry|en=agroforestry|zh=农林复合系统`},

		// ── THIÊN VĂN HỌC BỔ SUNG (ASTRO6_) ─────────────────────
		{"ASTRO6_NEBULA",    3,`label=tinh vân|desc=nebula star-forming region Orion Eagle pillars of creation Hubble supernova remnant|vi=tinh vân,nebula|en=nebula|zh=星云`},
		{"ASTRO6_SUPERNOVAE",3,`label=siêu tân tinh|desc=supernova stellar explosion type Ia core-collapse nucleosynthesis heavy elements gold|vi=siêu tân tinh,supernova|en=supernova|zh=超新星`},
		{"ASTRO6_MULTIVERSE",3,`label=đa vũ trụ|desc=multiverse many-worlds interpretation inflation eternal bubble universe string landscape|vi=đa vũ trụ,multiverse|en=multiverse|zh=多重宇宙`},

		// ── NGHỆ THUẬT DIỄN XUẤT (FILM_) ─────────────────────────
		{"FILM_DIRECTING",   3,`label=đạo diễn phim|desc=film directing mise-en-scène auteur theory Kurosawa Kubrick Nolan cinematography|vi=đạo diễn phim,film directing|en=film directing|zh=电影导演`},
		{"FILM_SCREENPLAY",  3,`label=viết kịch bản|desc=screenplay three-act structure Joseph Campbell hero's journey Syd Field beat sheet|vi=viết kịch bản,screenplay|en=screenplay|zh=电影剧本`},
		{"FILM_CGI",         3,`label=CGI điện ảnh|desc=CGI computer generated imagery ILM Weta Digital Avatar Jurassic Park VFX motion capture|vi=CGI điện ảnh,CGI|en=film CGI|zh=电影CGI`},

		// ── KINH TẾ VI MÔ BỔ SUNG (MICRO2_) ─────────────────────
		{"MICRO2_MONOPOLY",  3,`label=độc quyền|desc=monopoly market power pricing barrier to entry natural deadweight loss antitrust|vi=độc quyền,monopoly|en=monopoly|zh=垄断`},
		{"MICRO2_OLIGOPOLY", 3,`label=thị trường thiểu độc quyền|desc=oligopoly few firms interdependent Cournot Bertrand Nash collusion OPEC|vi=thị trường thiểu độc quyền,oligopoly|en=oligopoly|zh=寡头垄断`},
		{"MICRO2_ASYMM_INFO",3,`label=thông tin bất cân xứng|desc=asymmetric information Akerlof market for lemons adverse selection moral hazard signaling|vi=thông tin bất cân xứng,asymmetric information|en=asymmetric information|zh=信息不对称`},

		// ── VN BỔ SUNG (VN3_) ─────────────────────────────────────
		{"VN3_HANOI",        3,`label=Hà Nội|desc=thủ đô 1010 năm lịch sử Lý Thái Tổ phố cổ 36 phường hồ Gươm Ba Đình|vi=Hà Nội,Hanoi|en=Hanoi|zh=河内`},
		{"VN3_HCMC",         3,`label=Hồ Chí Minh|desc=Sài Gòn thành phố kinh tế 13 triệu dân GDP 25% cả nước khu chế xuất|vi=Hồ Chí Minh,Sài Gòn,HCMC|en=Ho Chi Minh City|zh=胡志明市`},
		{"VN3_DANANG",       3,`label=Đà Nẵng|desc=thành phố đáng sống biển Mỹ Khê cầu Rồng Bà Nà Hills du lịch tech hub|vi=Đà Nẵng,Da Nang|en=Da Nang|zh=岘港`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
		fmt.Printf("  ✚ %-26s %q\n", nd.name, extractLabel(nd.dna))
	}
	fmt.Printf("\n✚ %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes\n", nn)
	if nn >= 3100 { fmt.Println("🎉 MILESTONE 3100!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
