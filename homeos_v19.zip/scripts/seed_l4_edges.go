//go:build ignore

// scripts/seed_l4_edges.go
// Silk edges cho L4 Objects ↔ L6 Perception ↔ L3 Life
// Chạy: go run scripts/seed_l4_edges.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const l4Path = "homeos.olang"
const l4LIE  = 64 + 9*24 // layerIdxEnd

type l4Edge struct{ from, to string; typ uint8; note string }

var l4Edges = []l4Edge{
	// ── HOME_LIGHT_ON ↔ Perception ─────────────────────────────
	{"HOME_LIGHT_ON",  "PERCEPT_BRIGHT",  0x0A, "đèn bật → sáng"},
	{"HOME_LIGHT_ON",  "PERCEPT_WARM",    0x0C, "đèn bật → ấm áp"},
	{"HOME_LIGHT_OFF", "PERCEPT_DARK",    0x0A, "đèn tắt → tối"},
	{"HOME_LIGHT_OFF", "PERCEPT_QUIET",   0x0C, "đèn tắt → yên tĩnh"},
	{"HOME_LIGHT_ON",  "HOME_LIGHT_OFF",  0x0D, "bật đối lập tắt"},

	// ── HOME_HVAC ↔ Perception ──────────────────────────────────
	{"HOME_HVAC",      "PERCEPT_COLD",    0x0A, "máy lạnh → lạnh"},
	{"HOME_HVAC",      "PERCEPT_QUIET",   0x0C, "máy lạnh → ồn/yên"},
	{"HOME_HVAC",      "PERCEPT_FRESH",   0x0C, "máy lạnh → không khí mát"},

	// ── HOME_FAN ↔ Perception ───────────────────────────────────
	{"HOME_FAN",       "PERCEPT_FRESH",   0x0A, "quạt → gió mát"},
	{"HOME_FAN",       "PERCEPT_LOUD",    0x0A, "quạt → tiếng ồn"},
	{"HOME_FAN",       "PERCEPT_COLD",    0x0C, "quạt → mát lạnh"},

	// ── HOME_BED ↔ Life + Perception ────────────────────────────
	{"HOME_BED",       "LIFE_SLEEP",      0x0C, "giường → ngủ"},
	{"HOME_BED",       "PERCEPT_SOFT",    0x0C, "giường → mềm"},
	{"HOME_BED",       "PERCEPT_WARM",    0x0C, "giường → ấm"},
	{"HOME_BED",       "PERCEPT_QUIET",   0x0C, "giường → yên tĩnh"},

	// ── HOME_CHAIR ↔ Perception ─────────────────────────────────
	{"HOME_CHAIR",     "PERCEPT_SOFT",    0x0C, "ghế → mềm"},
	{"HOME_CHAIR",     "PERCEPT_HARD",    0x0C, "ghế cứng → cứng"},
	{"HOME_CHAIR",     "LIFE_SLEEP",      0x0C, "ghế → nghỉ ngơi"},

	// ── HOME_TABLE ↔ Perception ─────────────────────────────────
	{"HOME_TABLE",     "PERCEPT_HARD",    0x0C, "bàn → cứng"},
	{"HOME_TABLE",     "PERCEPT_SMOOTH",  0x0C, "bàn → nhẵn"},
	{"HOME_TABLE",     "LIFE_EAT",        0x0C, "bàn → ăn uống"},

	// ── HOME_FRIDGE ↔ Perception ────────────────────────────────
	{"HOME_FRIDGE",    "PERCEPT_COLD",    0x0A, "tủ lạnh → lạnh"},
	{"HOME_FRIDGE",    "PERCEPT_FRESH",   0x0C, "tủ lạnh → tươi mát"},
	{"HOME_FRIDGE",    "LIFE_EAT",        0x0C, "tủ lạnh → thức ăn"},

	// ── HOME_TV ↔ Perception ────────────────────────────────────
	{"HOME_TV",        "PERCEPT_BRIGHT",  0x0A, "TV → ánh sáng"},
	{"HOME_TV",        "PERCEPT_LOUD",    0x0A, "TV → âm thanh"},
	{"HOME_TV",        "PERCEPT_VOICE",   0x0C, "TV → giọng nói"},
	{"HOME_TV",        "LIFE_LEARN",      0x0C, "TV → học hỏi"},

	// ── HOME_COMPUTER ↔ Life + Prog ─────────────────────────────
	{"HOME_COMPUTER",  "PERCEPT_BRIGHT",  0x0C, "máy tính → màn hình sáng"},
	{"HOME_COMPUTER",  "PERCEPT_HARD",    0x0C, "máy tính → vỏ cứng"},
	{"HOME_COMPUTER",  "LIFE_THINK",      0x0C, "máy tính → suy nghĩ"},
	{"HOME_COMPUTER",  "LIFE_LEARN",      0x0C, "máy tính → học tập"},
	{"HOME_COMPUTER",  "PROG_LLM",        0x0C, "máy tính chạy LLM"},
	{"HOME_COMPUTER",  "PROG_HOMEOS",     0x0C, "máy tính chạy HomeOS"},

	// ── HOME_PHONE ↔ Life + Perception ─────────────────────────
	{"HOME_PHONE",     "PERCEPT_VOICE",   0x0A, "điện thoại → giọng nói"},
	{"HOME_PHONE",     "LIFE_TALK",       0x0C, "điện thoại → giao tiếp"},
	{"HOME_PHONE",     "PERCEPT_BRIGHT",  0x0C, "điện thoại → màn hình"},

	// ── HOME_SENSOR ↔ Prog + Perception ────────────────────────
	{"HOME_SENSOR",    "PROG_SENSOR",     0x0C, "sensor vật lý ≈ sensor phần mềm"},
	{"HOME_SENSOR",    "PERCEPT_SHARP",   0x0C, "sensor → độ nhạy"},
	{"HOME_SENSOR",    "PERCEPT_HOT",     0x0C, "sensor đo nhiệt độ"},

	// ── HOME_WINDOW ↔ Perception ────────────────────────────────
	{"HOME_WINDOW",    "PERCEPT_BRIGHT",  0x0C, "cửa sổ → ánh sáng"},
	{"HOME_WINDOW",    "PERCEPT_FRESH",   0x0C, "cửa sổ mở → gió"},
	{"HOME_WINDOW",    "PERCEPT_FAR",     0x0C, "cửa sổ → nhìn ra xa"},

	// ── HOME_DOOR ↔ Perception ──────────────────────────────────
	{"HOME_DOOR",      "PERCEPT_HARD",    0x0C, "cửa → cứng"},
	{"HOME_DOOR",      "PERCEPT_NEAR",    0x0C, "cửa → lối vào gần"},
	{"HOME_DOOR",      "LIFE_WALK",       0x0C, "cửa → đi vào ra"},

	// ── HOME_KITCHEN ↔ Life + Perception ───────────────────────
	{"HOME_KITCHEN",   "LIFE_EAT",        0x0C, "bếp → nấu ăn"},
	{"HOME_KITCHEN",   "PERCEPT_HOT",     0x0C, "bếp → nóng"},
	{"HOME_KITCHEN",   "PERCEPT_FRAGRANT",0x0A, "bếp → mùi thơm thức ăn"},
	{"HOME_KITCHEN",   "PERCEPT_SALTY",   0x0C, "bếp → vị mặn"},

	// ── HOME_ROOM ↔ Perception ──────────────────────────────────
	{"HOME_ROOM",      "PERCEPT_QUIET",   0x0C, "phòng → yên tĩnh"},
	{"HOME_ROOM",      "PERCEPT_WARM",    0x0C, "phòng → ấm áp"},
	{"HOME_ROOM",      "PERCEPT_CLEAN",   0x0C, "phòng → sạch sẽ"},

	// ── FOOD ↔ Life + Perception ────────────────────────────────
	{"FOOD_RICE",      "LIFE_EAT",        0x0C, "cơm → ăn"},
	{"FOOD_RICE",      "PERCEPT_HUNGER",  0x0D, "cơm xóa đói"},
	{"FOOD_RICE",      "PERCEPT_WARM",    0x0C, "cơm → ấm"},
	{"FOOD_PHO",       "LIFE_EAT",        0x0C, "phở → ăn"},
	{"FOOD_PHO",       "PERCEPT_HOT",     0x0C, "phở → nóng"},
	{"FOOD_PHO",       "PERCEPT_FRAGRANT",0x0C, "phở → thơm"},
	{"FOOD_PHO",       "PERCEPT_SALTY",   0x0C, "phở → mặn"},
	{"FOOD_COFFEE",    "LIFE_BREATHE",    0x0C, "cà phê → thở hít hương thơm"},
	{"FOOD_COFFEE",    "PERCEPT_FRAGRANT",0x0A, "cà phê → thơm"},
	{"FOOD_COFFEE",    "PERCEPT_BITTER",  0x0C, "cà phê → đắng"},
	{"FOOD_COFFEE",    "PERCEPT_HOT",     0x0C, "cà phê → nóng"},
	{"FOOD_TEA",       "PERCEPT_FRAGRANT",0x0A, "trà → thơm"},
	{"FOOD_TEA",       "PERCEPT_WARM",    0x0C, "trà → ấm"},
	{"FOOD_TEA",       "PERCEPT_BITTER",  0x0C, "trà → vị đắng"},
	{"FOOD_WATER",     "LIFE_BREATHE",    0x0C, "nước → sự sống"},
	{"FOOD_WATER",     "PERCEPT_THIRST",  0x0D, "nước xóa khát"},
	{"FOOD_WATER",     "PERCEPT_CLEAN",   0x0C, "nước → sạch"},
	{"FOOD_WATER",     "PERCEPT_COLD",    0x0C, "nước → mát lạnh"},

	// ── VEHICLE ↔ Perception + Life ─────────────────────────────
	{"VEHICLE_CAR",    "PERCEPT_FAST",    0x0A, "xe hơi → nhanh"},
	{"VEHICLE_CAR",    "PERCEPT_LOUD",    0x0A, "xe hơi → ồn ào"},
	{"VEHICLE_CAR",    "PERCEPT_HARD",    0x0C, "xe hơi → vỏ cứng"},
	{"VEHICLE_CAR",    "LIFE_WALK",       0x0D, "xe hơi đối lập đi bộ"},
	{"VEHICLE_MOTO",   "PERCEPT_FAST",    0x0A, "xe máy → nhanh"},
	{"VEHICLE_MOTO",   "PERCEPT_LOUD",    0x0A, "xe máy → tiếng động"},
	{"VEHICLE_BIKE",   "PERCEPT_SLOW",    0x0C, "xe đạp → chậm hơn"},
	{"VEHICLE_BIKE",   "PERCEPT_QUIET",   0x0C, "xe đạp → yên lặng"},
	{"VEHICLE_BIKE",   "LIFE_WALK",       0x0C, "xe đạp ≈ đi bộ nhanh hơn"},
}

func main() {
	if _, err := os.Stat(l4Path); err != nil {
		log.Fatalf("file not found: %s", l4Path)
	}
	names := l4ReadNames(l4Path)
	fmt.Printf("Nodes: %d\n", len(names))
	existing := l4ReadEdges(l4Path)
	fmt.Printf("Existing edges: %d\n", len(existing))

	added, skipped, errs := 0, 0, 0
	for _, e := range l4Edges {
		typ := e.typ
		if typ == 0 { typ = 0x0C }

		src, srcOK := names[e.from]
		dst, dstOK := names[e.to]
		if !srcOK { fmt.Printf("  MISS src %s\n", e.from); errs++; continue }
		if !dstOK { fmt.Printf("  MISS dst %s\n", e.to);   errs++; continue }

		key := l4Key(src, dst, typ)
		if existing[key] { skipped++; continue }

		if err := l4AppendEdge(l4Path, src, dst, typ); err != nil {
			fmt.Printf("  ERR %s→%s: %v\n", e.from, e.to, err)
			errs++; continue
		}
		existing[key] = true
		fmt.Printf("  +%s  %-22s → %s\n", edgeSym(typ), e.from, e.to)
		added++
	}
	fmt.Printf("\n✅ seed_l4_edges: +%d edges, %d skip, %d err\n", added, skipped, errs)

	if err := l4Verify(l4Path); err != nil {
		log.Fatalf("VERIFY FAIL: %v", err)
	}
	fmt.Println("✅ SHA256 OK")
}

func edgeSym(t uint8) string {
	switch t {
	case 0x08: return "∈"
	case 0x09: return "⊂"
	case 0x0A: return "∘"
	case 0x0C: return "≈"
	case 0x0D: return "⊥"
	}
	return fmt.Sprintf("%02x", t)
}

func l4ReadNames(path string) map[string][8]byte {
	raw, _ := os.ReadFile(path)
	m := map[string][8]byte{}
	for off := 0; off+20 < len(raw); {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 3
		var isl [8]byte; copy(isl[:], raw[off:off+8]); off += 8
		off += 4
		dl := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nl := int(raw[off]); off++
		ns := off+dl; ne := ns+nl
		if ne > len(raw) { break }
		m[string(raw[ns:ne])] = isl
		off = ne
	}
	return m
}

func l4ReadEdges(path string) map[string]bool {
	raw, _ := os.ReadFile(path)
	m := map[string]bool{}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	start := len(raw) - nedges*17
	if start < l4LIE { return m }
	for i := start; i+17 <= len(raw); i += 17 {
		var s, d [8]byte
		copy(s[:], raw[i:i+8]); copy(d[:], raw[i+8:i+16])
		m[l4Key(s, d, raw[i+16])] = true
	}
	return m
}

func l4Key(s, d [8]byte, t uint8) string {
	return fmt.Sprintf("%x:%x:%02x", s, d, t)
}

func l4AppendEdge(path string, s, d [8]byte, t uint8) error {
	raw, err := os.ReadFile(path)
	if err != nil { return err }
	rb := make([]byte, len(raw)+17)
	copy(rb, raw)
	copy(rb[len(raw):], s[:])
	copy(rb[len(raw)+8:], d[:])
	rb[len(raw)+16] = t
	n := binary.BigEndian.Uint32(rb[16:20])
	binary.BigEndian.PutUint32(rb[16:20], n+1)
	h := sha256.Sum256(rb[l4LIE:])
	copy(rb[28:60], h[:])
	tmp := path + ".l4tmp"
	if err := os.WriteFile(tmp, rb, 0644); err != nil { return err }
	return os.Rename(tmp, path)
}

func l4Verify(path string) error {
	raw, _ := os.ReadFile(path)
	var st [32]byte; copy(st[:], raw[28:60])
	cm := sha256.Sum256(raw[l4LIE:])
	if st != cm { return fmt.Errorf("mismatch") }
	return nil
}
