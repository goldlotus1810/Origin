//go:build ignore
// Seed domain sinh học / thực vật học vào homeos.olang
// L3 nodes (đời sống / sinh vật): đây là QR knowledge bất biến
// Chạy: go run scripts/seed_biology.go
package main
import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)
const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct {
	name  string
	layer uint8
	dna   string
}

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ Đọc %s: %d bytes, %d nodes, %d edges\n",
		filePath, len(raw), be32(raw[12:16]), be32(raw[16:20]))

	existing := readNames(raw)

	// ── L3 nodes: sinh học / thực vật học ──────────────────────
	nodes := []Node{
		// Quang hợp và thành phần
		{"PHOTO_SYNTHESIS", 3,
			`label=quang hợp|desc=quá trình cây xanh dùng ánh sáng CO2 và nước tạo glucose và oxy|vi=quang hợp,photosynthesis|en=photosynthesis|zh=光合作用`},
		{"PHOTO_CHLOROPHYLL", 3,
			`label=diệp lục|desc=sắc tố xanh trong lá cây hấp thụ ánh sáng mặt trời cho quang hợp|vi=diệp lục,chlorophyll|en=chlorophyll|zh=叶绿素`},
		{"PHOTO_CHLOROPLAST", 3,
			`label=lục lạp|desc=bào quan chứa diệp lục thực hiện quang hợp trong tế bào thực vật|vi=lục lạp,chloroplast|en=chloroplast|zh=叶绿体`},
		{"PHOTO_GLUCOSE", 3,
			`label=glucose|desc=đường đơn C6H12O6 sản phẩm của quang hợp nguồn năng lượng tế bào|vi=glucose,đường glucose,đường đơn|en=glucose|zh=葡萄糖`},
		{"PHOTO_OXYGEN", 3,
			`label=oxy|desc=khí O2 sản phẩm phụ của quang hợp cần thiết cho hô hấp|vi=oxy,oxygen,oxi|en=oxygen|zh=氧气`},
		{"PHOTO_CO2", 3,
			`label=CO2|desc=carbon dioxide khí nhà kính nguyên liệu cho quang hợp|vi=CO2,carbon dioxide,khí carbonic|en=carbon dioxide|zh=二氧化碳`},

		// Tế bào và cấu trúc
		{"BIO_CELL", 3,
			`label=tế bào|desc=đơn vị cơ bản của sự sống có màng tế bào nhân và tế bào chất|vi=tế bào,cell|en=cell|zh=细胞`},
		{"BIO_ORGANELLE", 3,
			`label=bào quan|desc=cấu trúc chức năng bên trong tế bào có nhân mitochondria ribosome|vi=bào quan,organelle|en=organelle|zh=细胞器`},
		{"BIO_NUCLEUS", 3,
			`label=nhân tế bào|desc=bào quan chứa DNA điều khiển mọi hoạt động tế bào|vi=nhân tế bào,nucleus|en=nucleus|zh=细胞核`},
		{"BIO_MITOCHONDRIA", 3,
			`label=ti thể|desc=bào quan tạo ra ATP năng lượng cho tế bào được gọi là nhà máy điện|vi=ti thể,mitochondria|en=mitochondria|zh=线粒体`},
		{"BIO_MEMBRANE", 3,
			`label=màng tế bào|desc=lớp phospholipid kép bao bọc tế bào kiểm soát vào ra chất|vi=màng tế bào,cell membrane|en=cell membrane|zh=细胞膜`},

		// Thực vật
		{"PLANT_ROOT", 3,
			`label=rễ cây|desc=bộ phận hút nước và khoáng chất từ đất giữ cây vững chắc|vi=rễ cây,rễ,root|en=root|zh=根`},
		{"PLANT_STEM", 3,
			`label=thân cây|desc=bộ phận dẫn nước từ rễ lên lá và chất dinh dưỡng ngược lại|vi=thân cây,thân,stem|en=stem|zh=茎`},
		{"PLANT_LEAF", 3,
			`label=lá cây|desc=bộ phận chính thực hiện quang hợp có chứa diệp lục|vi=lá cây,lá,leaf|en=leaf|zh=叶`},
		{"PLANT_FLOWER", 3,
			`label=hoa|desc=cơ quan sinh sản của thực vật hạt kín chứa nhị và nhụy|vi=hoa,flower,bông|en=flower|zh=花`},
		{"PLANT_FRUIT", 3,
			`label=quả|desc=bộ phận chứa hạt phát triển từ bầu nhụy sau thụ phấn|vi=quả,trái,fruit|en=fruit|zh=果实`},
		{"PLANT_SEED", 3,
			`label=hạt giống|desc=cấu trúc phát triển thành cây mới chứa phôi và dự trữ dinh dưỡng|vi=hạt giống,hạt,seed|en=seed|zh=种子`},

		// Sinh học phân tử
		{"MOL_DNA", 3,
			`label=ADN|desc=axit deoxyribonucleic chuỗi xoắn kép mang thông tin di truyền|vi=ADN,DNA,axit deoxyribonucleic|en=DNA|zh=脱氧核糖核酸`},
		{"MOL_RNA", 3,
			`label=ARN|desc=axit ribonucleic truyền thông tin từ DNA để tổng hợp protein|vi=ARN,RNA|en=RNA|zh=核糖核酸`},
		{"MOL_PROTEIN", 3,
			`label=protein|desc=đại phân tử chuỗi amino acid thực hiện hầu hết chức năng tế bào|vi=protein,chất đạm|en=protein|zh=蛋白质`},
		{"MOL_CELLULOSE", 3,
			`label=cellulose|desc=polysaccharide cấu trúc thành tế bào thực vật cứng và bền|vi=cellulose,xenlulozơ|en=cellulose|zh=纤维素`},
		{"MOL_STARCH", 3,
			`label=tinh bột|desc=polysaccharide dự trữ năng lượng trong cây từ glucose|vi=tinh bột,starch|en=starch|zh=淀粉`},

		// Quá trình sinh học
		{"BIO_RESPIRATION", 3,
			`label=hô hấp|desc=quá trình tế bào phân giải glucose tạo ATP CO2 và nước|vi=hô hấp,hô hấp tế bào,respiration|en=respiration|zh=呼吸作用`},
		{"BIO_EVOLUTION", 3,
			`label=tiến hóa|desc=quá trình biến đổi di truyền tích lũy qua các thế hệ tạo ra đa dạng sinh học|vi=tiến hóa,evolution|en=evolution|zh=进化`},
		{"BIO_GENETICS", 3,
			`label=di truyền|desc=sự truyền đặc điểm từ thế hệ này sang thế hệ khác qua gen|vi=di truyền,genetics|en=genetics|zh=遗传学`},
		{"BIO_METABOLISM", 3,
			`label=trao đổi chất|desc=tổng hợp các phản ứng hóa học duy trì sự sống trong cơ thể|vi=trao đổi chất,chuyển hóa,metabolism|en=metabolism|zh=新陈代谢`},
		{"BIO_ECOSYSTEM", 3,
			`label=hệ sinh thái|desc=cộng đồng sinh vật và môi trường phi sinh học tương tác với nhau|vi=hệ sinh thái,ecosystem|en=ecosystem|zh=生态系统`},
	}

	// ── Silk edges giữa các nodes ──────────────────────────────
	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Quang hợp
		{"PHOTO_SYNTHESIS",   "PHOTO_CHLOROPLAST", "uses"},
		{"PHOTO_SYNTHESIS",   "PHOTO_CHLOROPHYLL", "uses"},
		{"PHOTO_SYNTHESIS",   "PHOTO_GLUCOSE",     "produces"},
		{"PHOTO_SYNTHESIS",   "PHOTO_OXYGEN",      "produces"},
		{"PHOTO_SYNTHESIS",   "PHOTO_CO2",         "consumes"},
		{"PHOTO_CHLOROPLAST", "PHOTO_CHLOROPHYLL", "contains"},
		{"PHOTO_CHLOROPLAST", "BIO_ORGANELLE",     "is-a"},
		// Tế bào
		{"BIO_ORGANELLE",    "BIO_CELL",          "part-of"},
		{"BIO_NUCLEUS",      "BIO_ORGANELLE",     "is-a"},
		{"BIO_MITOCHONDRIA", "BIO_ORGANELLE",     "is-a"},
		{"BIO_MITOCHONDRIA", "BIO_RESPIRATION",   "performs"},
		{"BIO_MEMBRANE",     "BIO_CELL",          "part-of"},
		// DNA → protein
		{"MOL_DNA",          "MOL_RNA",           "transcribes-to"},
		{"MOL_RNA",          "MOL_PROTEIN",       "translates-to"},
		// Thực vật
		{"PLANT_LEAF",       "PHOTO_SYNTHESIS",   "performs"},
		{"PLANT_LEAF",       "PHOTO_CHLOROPHYLL", "contains"},
		{"PLANT_ROOT",       "PLANT_STEM",        "connected-to"},
		{"PLANT_STEM",       "PLANT_LEAF",        "connected-to"},
		{"PLANT_FLOWER",     "PLANT_FRUIT",       "develops-into"},
		{"PLANT_FRUIT",      "PLANT_SEED",        "contains"},
		// Quá trình
		{"BIO_RESPIRATION",  "PHOTO_GLUCOSE",     "consumes"},
		{"BIO_RESPIRATION",  "PHOTO_OXYGEN",      "consumes"},
		{"BIO_EVOLUTION",    "BIO_GENETICS",      "uses"},
		{"BIO_ECOSYSTEM",    "BIO_METABOLISM",    "involves"},
		// Polysaccharides
		{"MOL_CELLULOSE",    "PHOTO_GLUCOSE",     "built-from"},
		{"MOL_STARCH",       "PHOTO_GLUCOSE",     "built-from"},
		{"MOL_CELLULOSE",    "BIO_CELL",          "forms-wall-of"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] {
			fmt.Printf("   skip (exist) %s\n", nd.name)
			skipped++
			continue
		}
		isl := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, isl, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		lbl := extractLabel(nd.dna)
		fmt.Printf("  ✚  L%d %-22s label=%q\n", nd.layer, nd.name, lbl)
	}

	// Edges
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		fromISLU, ok1 := nodeISLMap[e.from]
		toISLU, ok2   := nodeISLMap[e.to]
		if !ok1 || !ok2 {
			fmt.Printf("  skip edge %s→%s (node missing)\n", e.from, e.to)
			continue
		}
		raw = appendEdge(raw, fromISLU, toISLU, e.rel)
		edgeAdded++
	}

	fmt.Printf("\n✚  Thêm: %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, raw, 0644); err != nil { log.Fatal(err) }
	if err := os.Rename(tmp, filePath); err != nil { log.Fatal(err) }
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n",
		len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i
		for j < len(dna) && dna[j] != '|' { j++ }
		part := dna[i:j]
		if len(part) > 6 && part[:6] == "label=" { return part[6:] }
		i = j + 1
	}
	return ""
}

func buildRecord(layer uint8, isl [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], isl[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)
	return rec
}

func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0]=layer; isl[1]=h[0]%200+1; isl[2]=h[1]%200+1; isl[3]=h[2]%200+1
	isl[4]=h[3]; isl[5]=h[4]; isl[6]=h[5]; isl[7]=h[6]
	return isl
}

func insertNode(raw []byte, rec []byte) []byte {
	nedges := int(be32(raw[16:20]))
	nodeEnd := len(raw) - nedges*17
	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:nodeEnd]...)
	out = append(out, rec...)
	out = append(out, raw[nodeEnd:]...)
	n := be32(out[12:16]) + 1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}

func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(be32be(raw[i+15:i+19]))
		nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne := i+20+dl+nl
		if ne > end { break }
		name := string(raw[i+20+dl : ne])
		var isl8 [8]byte
		copy(isl8[:], raw[i+3:i+11])
		m[name] = isl8
		i = ne
	}
	return m
}

func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	// Edge format: from_islu(8) + to_islu(8) + rel(1) = 17 bytes
	relByte := relToByte(rel)
	edge := make([]byte, 17)
	binary.BigEndian.PutUint64(edge[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(edge[8:16], binary.BigEndian.Uint64(to[:]))
	edge[16] = relByte
	raw = append(raw, edge...)
	n := be32(raw[16:20]) + 1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}

func relToByte(rel string) uint8 {
	switch rel {
	case "is-a":          return 1
	case "part-of":       return 2
	case "member-of":     return 3
	case "similar":       return 4
	case "opposite":      return 5
	case "causes":        return 6
	case "uses":          return 7
	case "produces":      return 8
	case "consumes":      return 9
	case "contains":      return 10
	case "connected-to":  return 11
	case "develops-into": return 12
	case "transcribes-to":return 13
	case "translates-to": return 14
	case "performs":      return 15
	case "built-from":    return 16
	case "forms-wall-of": return 17
	}
	return 0
}

func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	end := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(be32be(raw[i+15:i+19]))
		nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne := i+20+dl+nl
		if ne > end { break }
		m[string(raw[i+20+dl:ne])] = true
		i = ne
	}
	return m
}

func be32(b []byte) uint32   { return binary.BigEndian.Uint32(b) }
func be32be(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
