//go:build ignore
// go run scripts/seed_sport_food.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── THỂ THAO / SỨC KHỎE ──────────────────────────────────
		{"SPORT_FOOTBALL",   3, `label=bóng đá|desc=môn thể thao đồng đội phổ biến nhất thế giới 11 người mỗi đội ghi bàn vào lưới đối phương|vi=bóng đá,football,soccer|en=football,soccer|zh=足球`},
		{"SPORT_BASKETBALL", 3, `label=bóng rổ|desc=môn thể thao đồng đội 5 người mỗi đội ném bóng vào rổ NBA là giải đấu hàng đầu|vi=bóng rổ,basketball|en=basketball|zh=篮球`},
		{"SPORT_SWIMMING",   3, `label=bơi lội|desc=môn thể thao và kỹ năng sống còn dưới nước thi đấu Olympic bướm ếch sải tự do|vi=bơi lội,swimming|en=swimming|zh=游泳`},
		{"SPORT_YOGA",       3, `label=yoga|desc=bộ môn kết hợp tư thế thể chất thở và thiền định nguồn gốc Ấn Độ cổ đại tăng linh hoạt|vi=yoga|en=yoga|zh=瑜伽`},
		{"SPORT_RUNNING",    3, `label=chạy bộ|desc=môn thể thao aerobic đơn giản nhất cải thiện tim mạch marathon 42.195 km|vi=chạy bộ,chạy,running|en=running,jogging|zh=跑步`},
		{"SPORT_TENNIS",     3, `label=quần vợt|desc=môn thể thao dùng vợt đánh bóng qua lưới Grand Slam Wimbledon Roland Garros|vi=quần vợt,tennis|en=tennis|zh=网球`},
		{"SPORT_MARTIAL",    3, `label=võ thuật|desc=hệ thống kỹ thuật chiến đấu và rèn luyện thân thể karate taekwondo judo kung fu|vi=võ thuật,martial arts|en=martial arts|zh=武术`},
		{"SPORT_CYCLING",    3, `label=đạp xe|desc=môn thể thao và phương tiện di chuyển thân thiện môi trường Tour de France|vi=đạp xe,xe đạp,cycling|en=cycling,biking|zh=骑行`},
		{"SPORT_FITNESS",    3, `label=thể dục|desc=hoạt động thể chất có kế hoạch để cải thiện sức mạnh sức bền linh hoạt|vi=thể dục,fitness,gym|en=fitness|zh=健身`},
		{"SPORT_NUTRITION",  3, `label=dinh dưỡng thể thao|desc=khoa học tối ưu hóa dinh dưỡng cho hiệu suất thể thao protein carb chất béo thời điểm ăn|vi=dinh dưỡng thể thao,sports nutrition|en=sports nutrition|zh=运动营养`},
		{"SPORT_OLYMPICS",   3, `label=Olympic|desc=sự kiện thể thao quốc tế lớn nhất 4 năm một lần mùa hè mùa đông hơn 200 quốc gia|vi=Olympic,thế vận hội|en=Olympics|zh=奥运会`},
		{"SPORT_MEDITATION", 3, `label=thiền định|desc=thực hành tập trung tâm trí để đạt trạng thái bình an giảm stress cải thiện sức khỏe tâm lý|vi=thiền định,meditation|en=meditation|zh=冥想`},

		// ── ẨM THỰC / NẤU ĂN ─────────────────────────────────────
		{"FOOD_VN_PHO",      3, `label=phở|desc=món ăn quốc dân Việt Nam nước dùng xương bò ninh lâu bánh phở thịt bò hoặc gà|vi=phở,pho|en=pho|zh=越南河粉`},
		{"FOOD_VN_BANH_MI",  3, `label=bánh mì|desc=bánh mì kiểu Pháp biến tấu Việt nhân phong phú chả lụa thịt nguội trứng rau|vi=bánh mì|en=banh mi|zh=越南法棍`},
		{"FOOD_VN_BUN_BO",   3, `label=bún bò Huế|desc=món bún nước dùng sả mắm ruốc đặc trưng Huế thịt bò chả heo giò heo|vi=bún bò,bún bò Huế|en=bun bo hue|zh=顺化牛肉米线`},
		{"FOOD_RICE",        3, `label=cơm|desc=lương thực chủ yếu của người Á Đông hạt gạo nấu chín nền tảng của bữa ăn Việt Nam|vi=cơm,gạo,rice|en=rice|zh=米饭`},
		{"FOOD_PROTEIN",     3, `label=protein thực phẩm|desc=đại diện các nguồn protein thực phẩm thịt cá trứng đậu phụ đậu hạt|vi=protein thực phẩm,protein ăn|en=food protein|zh=食物蛋白质`},
		{"FOOD_SPICE",       3, `label=gia vị|desc=các loại thảo mộc và hương liệu thêm hương vị cho món ăn tiêu ớt gừng nghệ tỏi|vi=gia vị,spices|en=spices|zh=香料`},
		{"FOOD_FERMENT",     3, `label=lên men|desc=quá trình vi sinh vật biến đổi thực phẩm tạo hương vị và bảo quản dưa cà muối mắm|vi=lên men,fermentation|en=fermentation|zh=发酵`},
		{"FOOD_NUTRITION",   3, `label=dinh dưỡng thực phẩm|desc=khoa học nghiên cứu thành phần dinh dưỡng trong thực phẩm carb protein chất béo vitamin khoáng|vi=dinh dưỡng thực phẩm,food nutrition|en=food nutrition|zh=食品营养`},
		{"FOOD_COOKING",     3, `label=nấu ăn|desc=nghệ thuật và khoa học chế biến thực phẩm bằng nhiệt hoặc hóa học luộc xào chiên hấp|vi=nấu ăn,cooking|en=cooking|zh=烹饪`},
		{"FOOD_COFFEE",      3, `label=cà phê|desc=thức uống từ hạt cà phê rang xay cafein chất kích thích phổ biến nhất thế giới|vi=cà phê,coffee|en=coffee|zh=咖啡`},
		{"FOOD_TEA",         3, `label=trà|desc=thức uống từ lá cây trà Camellia sinensis xanh đen ô long trà thảo mộc|vi=trà,chè,tea|en=tea|zh=茶`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Thể thao nội bộ
		{"SPORT_FOOTBALL",   "SPORT_OLYMPICS",  "featured-in"},
		{"SPORT_SWIMMING",   "SPORT_OLYMPICS",  "featured-in"},
		{"SPORT_RUNNING",    "SPORT_FITNESS",   "type-of"},
		{"SPORT_YOGA",       "SPORT_MEDITATION","combines"},
		{"SPORT_FITNESS",    "SPORT_NUTRITION", "requires"},
		{"SPORT_MEDITATION", "SPORT_YOGA",      "part-of"},
		// Thể thao ↔ Tâm lý / Y học
		{"SPORT_RUNNING",    "PSY_STRESS",      "reduces"},
		{"SPORT_MEDITATION", "PSY_STRESS",      "reduces"},
		{"SPORT_MEDITATION", "MED_MENTAL",      "improves"},
		{"SPORT_NUTRITION",  "MED_NUTRITION",   "related-to"},
		{"SPORT_FITNESS",    "MED_MUSCLE",      "strengthens"},
		// Ẩm thực nội bộ
		{"FOOD_VN_PHO",      "FOOD_RICE",       "alternative-to"},
		{"FOOD_COOKING",     "FOOD_SPICE",      "uses"},
		{"FOOD_FERMENT",     "FOOD_VN_PHO",     "technique-in"},
		{"FOOD_NUTRITION",   "FOOD_PROTEIN",    "studies"},
		{"FOOD_COFFEE",      "FOOD_TEA",        "similar"},
		// Ẩm thực ↔ Hóa học / Sinh học
		{"FOOD_FERMENT",     "CHEM_REACTION",   "is-a"},
		{"FOOD_PROTEIN",     "CHEM_PROTEIN",    "food-form-of"},
		{"FOOD_SPICE",       "CHEM_MOLECULE",   "contains"},
		{"FOOD_NUTRITION",   "MED_NUTRITION",   "related-to"},
		// Cà phê/trà ↔ Tâm lý
		{"FOOD_COFFEE",      "PSY_MOTIVATION",  "boosts"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"related-to":3,"reduces":4,"features":5,
		"featured-in":6,"type-of":7,"combines":8,"requires":9,
		"improves":10,"strengthens":11,"alternative-to":12,"uses":13,
		"technique-in":14,"studies":15,"similar":16,"food-form-of":17,
		"contains":18,"boosts":19,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
