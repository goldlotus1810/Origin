//go:build ignore

// scripts/seed_milestone3600.go — MILESTONE 3600
// Domains: MATERIAL2_ ENERGY2_ SPACE2_ OCEAN2_ EVOLUTION_
//          COGN3_ MUSIC2_ DESIGN3_ URBAN2_ FOOD2_
//          MATH2_ LOGIC_ GAME2_ SPORT3_ HEALTH3_
//          INDO2_ CHINA2_ JAPAN2_ KOREA2_ AFRICA2_
//          VNFOLK_ VNMUSIC_ VNDANCE_ VNCUISINE2_ VNBUSINESS_
//          ROBOT3_ IOT_ CYBER2_ CLOUD2_ AI2_

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	existing := readNames(raw)

	type nodeDef struct { name string; layer uint8; dna string }
	nodes := []nodeDef{

		// ── MATERIALS SCIENCE 2 (MATERIAL2_) ────────────────────────
		{"MATERIAL2_GRAPHENE",    3, `label=graphene|desc=graphene single carbon layer hexagonal lattice sp2 bond Nobel 2010 Geim Novoselov conductor flexible transparent strength|vi=graphene,graphene|en=graphene`},
		{"MATERIAL2_CERAMIC",     3, `label=vật liệu gốm sứ|desc=ceramics alumina zirconia silicon carbide high temperature refractory piezoelectric bioceramics dental implant cutting tool|vi=vật liệu gốm sứ,ceramics|en=ceramics`},
		{"MATERIAL2_POLYMER",     3, `label=polymer tổng hợp|desc=polymer synthesis addition condensation thermoplastic thermoset elastomer rubber plastic recyclability lifecycle|vi=polymer tổng hợp,polymer|en=polymer`},
		{"MATERIAL2_COMPOSITE",   3, `label=vật liệu composite|desc=composite material carbon fiber CFRP fiberglass matrix reinforcement aerospace Boeing 787 rule of mixtures|vi=vật liệu composite,composite|en=composite material`},
		{"MATERIAL2_SUPERCOND",   3, `label=siêu dẫn điện|desc=superconductor Meissner effect BCS theory Cooper pair critical temperature Tc YBCO LK-99 claim room temperature|vi=siêu dẫn điện,superconductor|en=superconductor`},

		// ── ENERGY 2 (ENERGY2_) ─────────────────────────────────────
		{"ENERGY2_FUSION",        3, `label=năng lượng nhiệt hạch|desc=nuclear fusion ITER tokamak NIF inertial confinement D-T reaction Q>1 December 2022 ignition plasma|vi=năng lượng nhiệt hạch,nuclear fusion|en=nuclear fusion`},
		{"ENERGY2_HYDROGEN",      3, `label=kinh tế hydrogen|desc=hydrogen economy green blue grey electrolysis steam reforming fuel cell PEM AFC storage pipeline ammonia|vi=kinh tế hydrogen,hydrogen economy|en=hydrogen economy`},
		{"ENERGY2_STORAGE",       3, `label=lưu trữ năng lượng|desc=energy storage lithium-ion solid state flow battery pumped hydro CAES gravity storage grid-scale LCOS|vi=lưu trữ năng lượng,energy storage|en=energy storage`},
		{"ENERGY2_GRID",          3, `label=lưới điện thông minh|desc=smart grid demand response distributed generation microgrid SCADA AMI V2G EV charging flexibility aggregator|vi=lưới điện thông minh,smart grid|en=smart grid`},
		{"ENERGY2_GEOTHERMAL",    3, `label=địa nhiệt|desc=geothermal energy EGS enhanced geothermal Iceland binary cycle flash steam dry steam magma depth drilling|vi=địa nhiệt,geothermal|en=geothermal energy`},

		// ── SPACE SCIENCE 2 (SPACE2_) ───────────────────────────────
		{"SPACE2_EXOPLANET",      3, `label=ngoại hành tinh|desc=exoplanet transit radial velocity direct imaging Kepler TESS JWST habitable zone rocky super-Earth hot Jupiter|vi=ngoại hành tinh,exoplanet|en=exoplanet`},
		{"SPACE2_DARK_MATTER",    3, `label=vật chất tối|desc=dark matter rotation curve gravitational lensing WIMP axion CDM 27% universe no electromagnetic interaction detection|vi=vật chất tối,dark matter|en=dark matter`},
		{"SPACE2_BLACKHOLE",      3, `label=lỗ đen|desc=black hole event horizon singularity Hawking radiation EHT image M87 2019 Sgr A* 2022 tidal disruption LIGO merger|vi=lỗ đen,black hole|en=black hole`},
		{"SPACE2_MARS",           3, `label=sao Hỏa|desc=Mars colonization SpaceX Starship Perseverance rover MOXIE oxygen production terraforming radiation 687 days year|vi=sao Hỏa,Mars|en=Mars`},
		{"SPACE2_GRAVITATIONAL",  3, `label=sóng hấp dẫn|desc=gravitational waves LIGO Virgo LISA merger neutron star black hole chirp strain h~10⁻²¹ Nobel 2017|vi=sóng hấp dẫn,gravitational waves|en=gravitational waves`},

		// ── OCEAN SCIENCE 2 (OCEAN2_) ───────────────────────────────
		{"OCEAN2_CURRENTS",       3, `label=dòng hải lưu|desc=ocean currents thermohaline circulation AMOC Gulf Stream conveyor belt heat transport climate regulation salinity|vi=dòng hải lưu,ocean currents|en=ocean currents`},
		{"OCEAN2_DEEP",           3, `label=đại dương sâu|desc=deep ocean hadal zone bioluminescence chemosynthesis hydrothermal vent Mariana Trench pressure adaptation|vi=đại dương sâu,deep ocean|en=deep ocean`},
		{"OCEAN2_PLASTIC",        3, `label=ô nhiễm nhựa biển|desc=ocean plastic Great Pacific Garbage Patch microplastic food chain bioaccumulation ghost fishing cleanup Ocean Cleanup|vi=ô nhiễm nhựa biển,ocean plastic|en=ocean plastic`},
		{"OCEAN2_TIDAL",          3, `label=năng lượng thủy triều|desc=tidal energy barrage tidal stream turbine MeyGen Swansea Bay lunar gravity predictable renewable resource|vi=năng lượng thủy triều,tidal energy|en=tidal energy`},
		{"OCEAN2_SEAGRASS",       3, `label=thảm cỏ biển|desc=seagrass meadow blue carbon sink CO2 sequestration dugong seahorse nursery habitat loss restoration|vi=thảm cỏ biển,seagrass|en=seagrass`},

		// ── EVOLUTION (EVOLUTION_) ───────────────────────────────────
		{"EVOLUTION_NATURAL_SEL", 3, `label=chọn lọc tự nhiên|desc=natural selection Darwin Wallace fitness adaptation variation heredity On Origin of Species 1859 survival|vi=chọn lọc tự nhiên,natural selection|en=natural selection`},
		{"EVOLUTION_SPECIATION",  3, `label=hình thành loài|desc=speciation allopatric sympatric reproductive isolation geographic barrier ring species hybrid zone gene flow|vi=hình thành loài,speciation|en=speciation`},
		{"EVOLUTION_CONVERGENT",  3, `label=tiến hóa hội tụ|desc=convergent evolution independent similar traits dolphin ichthyosaur echolocation eye camera marsupial placental analogy|vi=tiến hóa hội tụ,convergent evolution|en=convergent evolution`},
		{"EVOLUTION_EVODEV",      3, `label=tiến hóa phát triển|desc=evo-devo evolutionary developmental biology Hox genes body plan toolkit Cambrian explosion regulatory network|vi=tiến hóa phát triển,evo-devo|en=evo-devo`},
		{"EVOLUTION_HUMAN",       3, `label=tiến hóa người|desc=human evolution Homo sapiens African origin 300ka Neanderthal interbreeding FOXP2 language bipedalism brain size|vi=tiến hóa người,human evolution|en=human evolution`},

		// ── COGNITION 3 (COGN3_) ────────────────────────────────────
		{"COGN3_METACOGNITION",   3, `label=siêu nhận thức|desc=metacognition thinking about thinking Dunning-Kruger effect calibration self-monitoring regulation Flavell|vi=siêu nhận thức,metacognition|en=metacognition`},
		{"COGN3_SPATIAL",         3, `label=nhận thức không gian|desc=spatial cognition mental rotation navigation hippocampus place cell grid cell cognitive map O'Keefe Moser Nobel|vi=nhận thức không gian,spatial cognition|en=spatial cognition`},
		{"COGN3_NUMBER",          3, `label=nhận thức số học|desc=numerical cognition approximate number system ANS subitizing Weber fraction math anxiety acalculia dyscalculia|vi=nhận thức số học,numerical cognition|en=numerical cognition`},
		{"COGN3_SOCIAL",          3, `label=nhận thức xã hội|desc=social cognition theory of mind mentalizing mirror neuron empathy autism spectrum disorder social brain hypothesis|vi=nhận thức xã hội,social cognition|en=social cognition`},
		{"COGN3_EMBODIED",        3, `label=nhận thức hiện thân|desc=embodied cognition grounded perception action coupling body schema affordance Gibson ecological enactivism Merleau-Ponty|vi=nhận thức hiện thân,embodied cognition|en=embodied cognition`},

		// ── MUSIC 2 (MUSIC2_) ───────────────────────────────────────
		{"MUSIC2_HARMONY",        3, `label=hòa âm|desc=harmony consonance dissonance chord progression functional harmony ii-V-I tritone substitution voice leading part writing|vi=hòa âm,harmony|en=harmony music`},
		{"MUSIC2_RHYTHM",         3, `label=nhịp điệu|desc=rhythm meter syncopation polyrhythm cross-rhythm Afrobeat groove swing quantization onset timing perception|vi=nhịp điệu,rhythm|en=rhythm`},
		{"MUSIC2_ACOUSTIC",       3, `label=âm học nhạc cụ|desc=musical acoustics resonance standing wave Fourier timbre overtone formant instrument body radiation|vi=âm học nhạc cụ,musical acoustics|en=musical acoustics`},
		{"MUSIC2_GENERATIVE",     3, `label=âm nhạc tạo sinh|desc=generative music algorithmic composition Xenakis stochastic Eno ambient Brian Eno Music for Airports AI music|vi=âm nhạc tạo sinh,generative music|en=generative music`},
		{"MUSIC2_COGNITION",      3, `label=nhận thức âm nhạc|desc=music cognition absolute pitch chills ASMR reward dopamine earworm memory emotion universal cross-cultural|vi=nhận thức âm nhạc,music cognition|en=music cognition`},

		// ── MATHEMATICS 2 (MATH2_) ──────────────────────────────────
		{"MATH2_TOPOLOGY",        3, `label=tô pô học|desc=topology homeomorphism homotopy fundamental group Euler characteristic Möbius strip Klein bottle knot theory Poincaré conjecture|vi=tô pô học,topology|en=topology`},
		{"MATH2_NUMBER_THEORY",   3, `label=lý thuyết số|desc=number theory prime Riemann hypothesis Goldbach conjecture modular arithmetic Fermat last theorem Wiles 1995 cryptography|vi=lý thuyết số,number theory|en=number theory`},
		{"MATH2_GRAPH",           3, `label=lý thuyết đồ thị|desc=graph theory vertex edge Eulerian Hamiltonian path coloring planar graph four color theorem network flow matching|vi=lý thuyết đồ thị,graph theory|en=graph theory`},
		{"MATH2_FRACTAL",         3, `label=fractal|desc=fractal self-similarity Mandelbrot set Julia set Hausdorff dimension coastline paradox IFS chaos attractor Lorenz|vi=fractal,fractal|en=fractal`},
		{"MATH2_CATEGORY",        3, `label=lý thuyết phạm trù|desc=category theory functor natural transformation monad adjunction Haskell type theory Curry-Howard correspondence|vi=lý thuyết phạm trù,category theory|en=category theory`},

		// ── INDONESIA / SEA (INDO2_) ─────────────────────────────────
		{"INDO2_BATIK",           3, `label=batik Indonesia|desc=batik wax-resist dyeing UNESCO 2009 Javanese Solo Yogyakarta court motif meaning pesisir coastal trade cloth|vi=batik Indonesia,batik|en=batik`},
		{"INDO2_GAMELAN",         3, `label=nhạc gamelan|desc=gamelan ensemble bronze metallophone gong bonang kendang Javanese Balinese court music UNESCO intangible 2021|vi=nhạc gamelan,gamelan|en=gamelan`},
		{"INDO2_WAYANG",          3, `label=múa rối bóng wayang|desc=wayang shadow puppet Ramayana Mahabharata dalang narrator gamelan UNESCO 2003 Javanese cultural identity|vi=múa rối bóng wayang,wayang|en=wayang`},
		{"INDO2_BOROBUDUR",       3, `label=Borobudur|desc=Borobudur Buddhist monument Java 9th century UNESCO mandala stupa 504 Buddha statues largest Buddhist temple world|vi=Borobudur,Borobudur|en=Borobudur`},
		{"INDO2_SPICE",           3, `label=lịch sử hương liệu|desc=spice trade nutmeg clove pepper Maluku Banda Islands VOC Dutch colonialism history European exploration|vi=lịch sử hương liệu,spice trade|en=spice trade`},

		// ── CHINA 2 (CHINA2_) ───────────────────────────────────────
		{"CHINA2_TANG",           3, `label=nhà Đường|desc=Tang Dynasty 618-907 golden age Li Bai Du Fu poetry Silk Road Chang'an cosmopolitan Buddhism examination system|vi=nhà Đường,Tang Dynasty|en=Tang Dynasty`},
		{"CHINA2_MING",           3, `label=nhà Minh|desc=Ming Dynasty 1368-1644 Forbidden City Zheng He voyages Great Wall rebuild porcelain blue-white Ming treasure fleet|vi=nhà Minh,Ming Dynasty|en=Ming Dynasty`},
		{"CHINA2_CALLIGRAPHY",    3, `label=thư pháp Trung Hoa|desc=Chinese calligraphy regular clerical cursive seal script brush ink stone four treasures Wang Xizhi Jin|vi=thư pháp Trung Hoa,Chinese calligraphy|en=Chinese calligraphy`},
		{"CHINA2_TCM",            3, `label=y học cổ truyền Trung Hoa|desc=traditional Chinese medicine qi meridian acupuncture herbal moxibustion pulse diagnosis yin yang five elements|vi=y học cổ truyền Trung Hoa,TCM|en=traditional Chinese medicine`},
		{"CHINA2_MODERN",         3, `label=Trung Quốc hiện đại|desc=modern China Deng Xiaoping reform 1978 opening up Belt Road Initiative GDP growth tech innovation BATX|vi=Trung Quốc hiện đại,modern China|en=modern China`},

		// ── JAPAN 2 (JAPAN2_) ───────────────────────────────────────
		{"JAPAN2_WABI_SABI",      3, `label=wabi-sabi|desc=wabi-sabi Japanese aesthetic imperfection impermanence incompleteness kintsugi moss tea ceremony Sen no Rikyu侘び寂び|vi=wabi-sabi,wabi-sabi|en=wabi-sabi`},
		{"JAPAN2_MANGA",          3, `label=manga và anime|desc=manga anime Tezuka Osamu Astro Boy shōnen shōjo seinen seinen Ghibli Miyazaki soft power cultural export otaku|vi=manga và anime,manga anime|en=manga anime`},
		{"JAPAN2_BUSHIDO",        3, `label=bushido|desc=bushido way of warrior samurai code honor loyalty rectitude courage benevolence Hagakure Miyamoto Musashi Book of Five Rings|vi=bushido,bushido|en=bushido`},
		{"JAPAN2_KAIZEN",         3, `label=kaizen|desc=kaizen continuous improvement Toyota Production System lean manufacturing Taiichi Ohno waste muda PDCA cycle 5S|vi=kaizen,kaizen|en=kaizen`},
		{"JAPAN2_SHINTO",         3, `label=Thần đạo Shinto|desc=Shinto kami nature spirit torii gate shrine matsuri festival purification Amaterasu Izanagi creation myth Japan|vi=Thần đạo Shinto,Shinto|en=Shinto`},

		// ── KOREA 2 (KOREA2_) ───────────────────────────────────────
		{"KOREA2_HANGUL",         3, `label=chữ Hangul|desc=Hangul Korean alphabet King Sejong 1443 phonemic syllabic block featural scientific design literacy UNESCO memory|vi=chữ Hangul,Hangul|en=Hangul`},
		{"KOREA2_HALLYU",         3, `label=làn sóng Hallyu|desc=Korean Wave hallyu K-pop BTS BLACKPINK K-drama Squid Game Parasite Bong Joon-ho soft power global cultural|vi=làn sóng Hallyu,Korean Wave|en=Korean Wave`},
		{"KOREA2_JOSEON",         3, `label=triều đại Joseon|desc=Joseon Dynasty 1392-1897 Confucianism Neo Yi Sunsin turtle ship Imjin War Japanese invasion celadon|vi=triều đại Joseon,Joseon Dynasty|en=Joseon Dynasty`},
		{"KOREA2_TECH",           3, `label=công nghệ Hàn Quốc|desc=Korea tech Samsung LG SK Hynix TSMC rival semiconductor display shipbuilding Hyundai chaebol model|vi=công nghệ Hàn Quốc,Korea tech|en=Korea technology`},
		{"KOREA2_FOOD",           3, `label=ẩm thực Hàn Quốc|desc=Korean food kimchi fermentation bibimbap bulgogi tteokbokki doenjang jjigae banchan jeong culture sharing|vi=ẩm thực Hàn Quốc,Korean food|en=Korean food`},

		// ── VIETNAM FOLK CULTURE (VNFOLK_) ──────────────────────────
		{"VNFOLK_TRUYEN_CO_TICH",  3, `label=truyện cổ tích Việt|desc=truyện cổ tích Tấm Cám Thạch Sanh Sơn Tinh Thủy Tinh Sự tích Hồ Gươm bài học đạo đức nhân quả|vi=truyện cổ tích Việt,Vietnamese fairy tales|en=Vietnamese folk tales`},
		{"VNFOLK_TRUYEN_CUOI",     3, `label=truyện cười dân gian|desc=truyện cười dân gian Trạng Quỳnh Ba Giai Tú Xuất trào lộng châm biếm xã hội phong kiến trí tuệ bình dân|vi=truyện cười dân gian,Vietnamese humor folk|en=Vietnamese humor folk`},
		{"VNFOLK_CA_DAO",          3, `label=ca dao tục ngữ|desc=ca dao tục ngữ kho tàng dân gian kinh nghiệm sống ứng xử thiên nhiên lao động tình cảm lục bát truyền miệng|vi=ca dao tục ngữ,ca dao tuc ngu|en=Vietnamese proverbs`},
		{"VNFOLK_LE_HOI",          3, `label=lễ hội dân gian|desc=lễ hội dân gian đền Hùng Lim hội Gióng Chùa Hương chọi trâu đua thuyền không khí cộng đồng tâm linh|vi=lễ hội dân gian,Vietnamese festivals|en=Vietnamese folk festivals`},
		{"VNFOLK_TRANG_NGUYEN",    3, `label=truyền thống khoa bảng|desc=khoa bảng Văn Miếu Quốc Tử Giám trạng nguyên thi hội thi đình học vấn Nho giáo tôn sư trọng đạo|vi=truyền thống khoa bảng,Vietnamese scholar tradition|en=Vietnamese scholar tradition`},

		// ── VIETNAM MUSIC (VNMUSIC_) ─────────────────────────────────
		{"VNMUSIC_NHAC_DAN_TOC",   3, `label=nhạc dân tộc Việt Nam|desc=nhạc dân tộc đàn bầu đàn tranh đàn nguyệt đàn tứ đàn nhị trống ngũ âm cồng chiêng ngũ cung|vi=nhạc dân tộc Việt Nam,Vietnamese traditional music|en=Vietnamese traditional music`},
		{"VNMUSIC_NHAC_TRE",       3, `label=nhạc trẻ Việt Nam|desc=nhạc trẻ Việt Nam V-pop indie folk Sơn Tùng MTP Mỹ Tâm Đen Vâu Tùng Dương Hà Anh Tuấn thế hệ mới|vi=nhạc trẻ Việt Nam,Vietnamese pop|en=Vietnamese pop music`},
		{"VNMUSIC_CHEO",           3, `label=hát chèo|desc=hát chèo nghệ thuật sân khấu truyền thống đồng bằng Bắc Bộ tích trò nhân vật điển hình phê phán xã hội hài hước|vi=hát chèo,hat cheo|en=Cheo theater`},
		{"VNMUSIC_NHAC_VANG",      3, `label=nhạc vàng nhạc xưa|desc=nhạc vàng bolero nhạc tiền chiến Trịnh Công Sơn Phạm Duy Đoàn Chuẩn hoài niệm sến thị trường miền Nam|vi=nhạc vàng nhạc xưa,nhac vang|en=Vietnamese golden music`},
		{"VNMUSIC_HO_VAN",         3, `label=hò vè dân ca|desc=hò vè dân ca Bắc Trung Nam hò mái nhì hò khoan Quảng Bình ví giặm Nghệ Tĩnh hò đối đáp lao động|vi=hò vè dân ca,Vietnamese folk songs|en=Vietnamese folk songs`},

		// ── VIETNAM CUISINE 2 (VNCUISINE2_) ─────────────────────────
		{"VNCUISINE2_BUN",         3, `label=các món bún Việt|desc=bún bò Huế bún riêu cua bún mắm bún đậu mắm tôm bún chả Hà Nội bún thịt nướng miền Trung đa dạng vùng miền|vi=các món bún Việt,Vietnamese noodle soup|en=Vietnamese bun dishes`},
		{"VNCUISINE2_COM",         3, `label=cơm tấm và cơm Việt|desc=cơm tấm Sài Gòn sườn nướng bì chả trứng ốp la cơm chiên dương châu cơm gà Hội An cơm Bắc|vi=cơm tấm và cơm Việt,com tam|en=Vietnamese rice dishes`},
		{"VNCUISINE2_BANH",        3, `label=bánh Việt Nam|desc=bánh cuốn bánh xèo bánh bèo bánh nậm bánh lọc bánh căn bánh tráng nướng văn hóa bánh đặc trưng vùng miền|vi=bánh Việt Nam,Vietnamese banh|en=Vietnamese banh`},
		{"VNCUISINE2_CHE",         3, `label=chè Việt Nam|desc=chè ba màu chè khúc bạch chè bưởi chè đậu đỏ chè trôi nước đồ ngọt truyền thống Bắc Trung Nam|vi=chè Việt Nam,Vietnamese sweet soup|en=Vietnamese che`},
		{"VNCUISINE2_NUOC_MAM",    3, `label=nước mắm văn hóa|desc=nước mắm Phú Quốc Phan Thiết cá cơm muối lên men UNESCO ứng viên bản sắc ẩm thực Việt toàn cầu|vi=nước mắm văn hóa,nuoc mam|en=Vietnamese fish sauce`},

		// ── AI 2 (AI2_) ─────────────────────────────────────────────
		{"AI2_TRANSFORMER",       3, `label=kiến trúc Transformer|desc=Transformer attention is all you need Vaswani 2017 self-attention multi-head positional encoding GPT BERT T5 foundation model|vi=kiến trúc Transformer,Transformer|en=Transformer architecture`},
		{"AI2_RL",                 3, `label=học tăng cường|desc=reinforcement learning reward policy Q-learning PPO RLHF AlphaGo AlphaZero MuZero Atari DQN sparse reward|vi=học tăng cường,reinforcement learning|en=reinforcement learning`},
		{"AI2_DIFFUSION",         3, `label=mô hình khuếch tán|desc=diffusion model DDPM score matching denoising Stable Diffusion DALL-E Midjourney latent space image generation|vi=mô hình khuếch tán,diffusion model|en=diffusion model`},
		{"AI2_MULTIMODAL",        3, `label=AI đa phương thức|desc=multimodal AI vision language GPT-4V Gemini CLIP image text audio video joint embedding cross-modal retrieval|vi=AI đa phương thức,multimodal AI|en=multimodal AI`},
		{"AI2_AGENT",             3, `label=AI agent|desc=AI agent autonomous LLM tool use ReAct chain-of-thought planning memory RAG retrieval augmented generation AutoGPT|vi=AI agent,AI agent|en=AI agent`},

		// ── ROBOTICS 3 (ROBOT3_) ────────────────────────────────────
		{"ROBOT3_LEGGED",         3, `label=robot chân|desc=legged robot Boston Dynamics Spot Atlas bipedal quadruped dynamic walking ZMP balance reinforcement learning terrain|vi=robot chân,legged robot|en=legged robot`},
		{"ROBOT3_SURGICAL",       3, `label=robot phẫu thuật|desc=surgical robot da Vinci laparoscopic telesurgery haptic feedback tremor filter precision microsurgery FDA|vi=robot phẫu thuật,surgical robot|en=surgical robot`},
		{"ROBOT3_SWARM",          3, `label=bầy robot|desc=swarm robotics stigmergy decentralized emergence collective behavior drone swarm Kilobot construction inspection|vi=bầy robot,swarm robotics|en=swarm robotics`},
		{"ROBOT3_SOFT",           3, `label=robot mềm|desc=soft robotics silicone actuator pneumatic hydraulic compliant gripper bio-inspired octopus worm medical navigation|vi=robot mềm,soft robotics|en=soft robotics`},
		{"ROBOT3_COBOT",          3, `label=robot cộng tác|desc=collaborative robot cobot UR KUKA force torque sensing ISO 10218 safety speed force limiting human robot workspace|vi=robot cộng tác,cobot|en=collaborative robot`},

		// ── CYBERSECURITY 2 (CYBER2_) ───────────────────────────────
		{"CYBER2_ZERO_TRUST",     3, `label=zero trust security|desc=zero trust never trust always verify microsegmentation identity BeyondCorp NIST 800-207 ZTNA SDP least privilege|vi=zero trust security,zero trust|en=zero trust`},
		{"CYBER2_RANSOMWARE",     3, `label=ransomware|desc=ransomware WannaCry NotPetya REvil double extortion crypto payment incident response backup air gap recovery|vi=ransomware,ransomware|en=ransomware`},
		{"CYBER2_THREAT_INTEL",   3, `label=threat intelligence|desc=cyber threat intelligence CTI STIX TAXII IOC TTP MITRE ATT&CK threat actor APT attribution diamond model|vi=threat intelligence,threat intelligence|en=threat intelligence`},
		{"CYBER2_QUANTUM_CRYPTO", 3, `label=mật mã hậu lượng tử|desc=post-quantum cryptography NIST PQC CRYSTALS-Kyber CRYSTALS-Dilithium lattice-based Shor threat harvest now decrypt later|vi=mật mã hậu lượng tử,post-quantum cryptography|en=post-quantum cryptography`},
		{"CYBER2_DEVSECOPS",      3, `label=DevSecOps|desc=DevSecOps shift left SAST DAST SCA SBOM supply chain attack Log4Shell dependency confusion pipeline security|vi=DevSecOps,DevSecOps|en=DevSecOps`},

		// ── CLOUD 2 (CLOUD2_) ───────────────────────────────────────
		{"CLOUD2_SERVERLESS",     3, `label=serverless computing|desc=serverless FaaS AWS Lambda Azure Functions GCP Cloud Run event-driven cold start stateless cost per invocation|vi=serverless computing,serverless|en=serverless`},
		{"CLOUD2_KUBERNETES",     3, `label=Kubernetes|desc=Kubernetes K8s container orchestration pod deployment service ingress HPA KEDA Helm operator cloud native CNCF|vi=Kubernetes,Kubernetes|en=Kubernetes`},
		{"CLOUD2_OBSERVABILITY",  3, `label=quan sát hệ thống|desc=observability three pillars metrics logs traces OpenTelemetry Prometheus Grafana Jaeger distributed tracing SLO SLI|vi=quan sát hệ thống,observability|en=observability`},
		{"CLOUD2_MULTICLOUD",     3, `label=đa đám mây|desc=multi-cloud strategy AWS Azure GCP vendor lock-in data gravity egress cost FinOps cloud cost optimization|vi=đa đám mây,multi-cloud|en=multi-cloud`},
		{"CLOUD2_WASM",           3, `label=WebAssembly|desc=WebAssembly Wasm near-native performance browser edge cloud WASI component model Spin Fermyon portable bytecode|vi=WebAssembly,WebAssembly|en=WebAssembly`},

		// ── IOT (IOT_) ───────────────────────────────────────────────
		{"IOT_PROTOCOL",          3, `label=giao thức IoT|desc=IoT protocol MQTT CoAP Zigbee Z-Wave LoRaWAN NB-IoT Thread Matter Bluetooth LE low power mesh|vi=giao thức IoT,IoT protocol|en=IoT protocol`},
		{"IOT_EDGE",              3, `label=edge computing IoT|desc=edge computing IoT latency bandwidth local inference TinyML NVIDIA Jetson AWS IoT Greengrass fog|vi=edge computing IoT,edge IoT|en=edge computing IoT`},
		{"IOT_SECURITY",          3, `label=bảo mật IoT|desc=IoT security Mirai botnet default credential firmware update OTA PKI certificate trust anchor secure boot TEE|vi=bảo mật IoT,IoT security|en=IoT security`},

		// ── URBAN SCIENCE 2 (URBAN2_) ────────────────────────────────
		{"URBAN2_15MIN_CITY",     3, `label=thành phố 15 phút|desc=15-minute city Carlos Moreno Paris proximity mixed-use walkable cycling access work school health food|vi=thành phố 15 phút,15-minute city|en=15-minute city`},
		{"URBAN2_GENTRIFICATION", 3, `label=quý tộc hóa đô thị|desc=gentrification displacement affordable housing rent burden incumbent resident culture erasure investment|vi=quý tộc hóa đô thị,gentrification|en=gentrification`},
		{"URBAN2_INFORMAL",       3, `label=khu đô thị phi chính thức|desc=informal settlement slum favela kampung incremental housing self-built tenure security upgrading|vi=khu đô thị phi chính thức,informal settlement|en=informal settlement`},

		// ── HEALTH 3 (HEALTH3_) ─────────────────────────────────────
		{"HEALTH3_LONGEVITY",     3, `label=khoa học trường thọ|desc=longevity science caloric restriction mTOR rapamycin senolytics NAD+ NMN sirtuins hallmarks aging Sinclair|vi=khoa học trường thọ,longevity science|en=longevity science`},
		{"HEALTH3_GUT_BRAIN",     3, `label=trục ruột não|desc=gut-brain axis vagus nerve enteric nervous system microbiome serotonin 90% gut mood anxiety probiotic intervention|vi=trục ruột não,gut-brain axis|en=gut-brain axis`},
		{"HEALTH3_SLEEP_HYGIENE", 3, `label=vệ sinh giấc ngủ|desc=sleep hygiene blue light circadian temperature wind-down consistent schedule power nap cognitive performance|vi=vệ sinh giấc ngủ,sleep hygiene|en=sleep hygiene`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3600 { fmt.Println(" MILESTONE 3600! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
