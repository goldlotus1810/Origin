//go:build ignore
// go run scripts/seed_psych_ecology.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── TÂM LÝ HỌC ────────────────────────────────────────────
		{"PSY_EMOTION",      3, `label=cảm xúc|desc=trạng thái tâm lý chủ quan đi kèm phản ứng sinh lý và hành vi vui buồn sợ tức giận|vi=cảm xúc,emotion|en=emotion|zh=情感`},
		{"PSY_COGNITION",    3, `label=nhận thức|desc=quá trình tâm lý xử lý thông tin bao gồm tri giác trí nhớ tư duy ngôn ngữ ra quyết định|vi=nhận thức,cognition|en=cognition|zh=认知`},
		{"PSY_MEMORY",       3, `label=trí nhớ|desc=khả năng lưu giữ và truy xuất thông tin ngắn hạn dài hạn làm việc hồi ký|vi=trí nhớ,memory|en=memory|zh=记忆`},
		{"PSY_SLEEP",        3, `label=giấc ngủ|desc=trạng thái nghỉ ngơi tự nhiên chu kỳ REM và non-REM thiết yếu cho sức khỏe não|vi=giấc ngủ,sleep|en=sleep|zh=睡眠`},
		{"PSY_STRESS",       3, `label=căng thẳng|desc=phản ứng tâm lý sinh lý trước áp lực cortisol adrenaline mãn tính gây hại sức khỏe|vi=căng thẳng,stress|en=stress|zh=压力`},
		{"PSY_MOTIVATION",   3, `label=động lực|desc=lực nội tâm thúc đẩy hành động hướng đến mục tiêu nội sinh ngoại sinh|vi=động lực,motivation|en=motivation|zh=动机`},
		{"PSY_PERSONALITY",  3, `label=tính cách|desc=tập hợp các đặc điểm tư duy cảm xúc hành vi ổn định theo thời gian BigFive MBTI|vi=tính cách,personality|en=personality|zh=性格`},
		{"PSY_BEHAVIOR",     3, `label=hành vi|desc=cách thức phản ứng và hành động của sinh vật trước kích thích môi trường|vi=hành vi,behavior|en=behavior|zh=行为`},
		{"PSY_THERAPY",      3, `label=trị liệu tâm lý|desc=điều trị rối loạn tâm lý qua nói chuyện nhận thức hành vi CBT psychoanalysis|vi=trị liệu tâm lý,therapy|en=psychotherapy|zh=心理治疗`},
		{"PSY_IQ",           3, `label=chỉ số IQ|desc=thước đo trí thông minh nhận thức chuẩn hóa theo độ tuổi trung bình 100|vi=IQ,chỉ số thông minh|en=IQ,intelligence quotient|zh=智商`},
		{"PSY_LEARNING",     3, `label=học tập tâm lý|desc=quá trình thay đổi hành vi kiến thức kỹ năng bền vững do kinh nghiệm điều kiện hóa|vi=học tập tâm lý,learning|en=learning|zh=学习`},
		{"PSY_ANXIETY",      3, `label=lo âu|desc=cảm giác lo lắng bất an về tương lai có thể trở thành rối loạn nếu mãn tính|vi=lo âu,anxiety|en=anxiety|zh=焦虑`},
		{"PSY_PERCEPTION",   3, `label=tri giác|desc=quá trình não tổ chức và diễn giải thông tin cảm giác từ giác quan|vi=tri giác,perception|en=perception|zh=知觉`},

		// ── MÔI TRƯỜNG / SINH THÁI ────────────────────────────────
		{"ENV_CLIMATE_CHANGE",3,`label=biến đổi khí hậu|desc=sự thay đổi dài hạn nhiệt độ và thời tiết toàn cầu chủ yếu do hoạt động con người khí CO2|vi=biến đổi khí hậu,climate change|en=climate change|zh=气候变化`},
		{"ENV_POLLUTION",    3, `label=ô nhiễm|desc=sự hiện diện chất độc hại trong môi trường không khí nước đất ảnh hưởng sức khỏe sinh vật|vi=ô nhiễm,pollution|en=pollution|zh=污染`},
		{"ENV_RECYCLE",      3, `label=tái chế|desc=chuyển đổi chất thải thành vật liệu mới giảm tiêu thụ tài nguyên bảo vệ môi trường|vi=tái chế,recycling|en=recycling|zh=回收`},
		{"ENV_RENEWABLE",    3, `label=năng lượng tái tạo|desc=năng lượng từ nguồn tự nhiên tái tạo mặt trời gió thủy điện địa nhiệt|vi=năng lượng tái tạo,renewable energy|en=renewable energy|zh=可再生能源`},
		{"ENV_BIODIVERSITY", 3, `label=đa dạng sinh học|desc=sự phong phú của các loài sinh vật gen và hệ sinh thái trên Trái Đất|vi=đa dạng sinh học,biodiversity|en=biodiversity|zh=生物多样性`},
		{"ENV_CARBON",       3, `label=carbon dioxide|desc=khí CO2 sản phẩm đốt cháy nhiên liệu hóa thạch khí nhà kính chính gây nóng lên toàn cầu|vi=CO2,carbon dioxide,khí carbon|en=carbon dioxide|zh=二氧化碳`},
		{"ENV_SOLAR",        3, `label=năng lượng mặt trời|desc=điện từ tấm pin quang điện PV biến đổi ánh sáng mặt trời thành điện năng|vi=năng lượng mặt trời,solar energy|en=solar energy|zh=太阳能`},
		{"ENV_DEFORESTATION",3, `label=phá rừng|desc=chặt phá rừng quy mô lớn mất môi trường sống đe dọa đa dạng sinh học|vi=phá rừng,deforestation|en=deforestation|zh=森林砍伐`},
		{"ENV_OCEAN_ACID",   3, `label=axit hóa đại dương|desc=giảm pH đại dương do hấp thụ CO2 đe dọa san hô và sinh vật biển|vi=axit hóa đại dương,ocean acidification|en=ocean acidification|zh=海洋酸化`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Tâm lý nội bộ
		{"PSY_EMOTION",     "PSY_BEHAVIOR",    "influences"},
		{"PSY_COGNITION",   "PSY_MEMORY",      "includes"},
		{"PSY_COGNITION",   "PSY_PERCEPTION",  "includes"},
		{"PSY_SLEEP",       "PSY_MEMORY",      "consolidates"},
		{"PSY_STRESS",      "PSY_ANXIETY",     "causes"},
		{"PSY_MOTIVATION",  "PSY_BEHAVIOR",    "drives"},
		{"PSY_THERAPY",     "PSY_ANXIETY",     "treats"},
		{"PSY_THERAPY",     "PSY_STRESS",      "treats"},
		{"PSY_LEARNING",    "PSY_MEMORY",      "requires"},
		{"PSY_IQ",          "PSY_COGNITION",   "measures"},
		{"PSY_PERSONALITY", "PSY_BEHAVIOR",    "shapes"},
		// Tâm lý ↔ Y học / Não
		{"PSY_SLEEP",       "MED_BRAIN",       "restores"},
		{"PSY_STRESS",      "MED_IMMUNE",      "weakens"},
		{"PSY_ANXIETY",     "MED_MENTAL",      "part-of"},
		{"PSY_THERAPY",     "MED_MENTAL",      "treats"},
		// Môi trường nội bộ
		{"ENV_CLIMATE_CHANGE","ENV_CARBON",    "caused-by"},
		{"ENV_CARBON",      "ENV_POLLUTION",   "is-a"},
		{"ENV_SOLAR",       "ENV_RENEWABLE",   "is-a"},
		{"ENV_DEFORESTATION","ENV_BIODIVERSITY","threatens"},
		{"ENV_OCEAN_ACID",  "ENV_CARBON",      "caused-by"},
		{"ENV_RECYCLE",     "ENV_POLLUTION",   "reduces"},
		{"ENV_RENEWABLE",   "ENV_CLIMATE_CHANGE","mitigates"},
		// Môi trường ↔ cross-domain
		{"ENV_CLIMATE_CHANGE","GEO_CLIMATE",   "changes"},
		{"ENV_BIODIVERSITY","BIO_ECOSYSTEM",   "is-a"},
		{"ENV_SOLAR",       "ASTRO_SUN",       "powered-by"},
		{"ENV_CARBON",      "CHEM_CARBON",     "compound-of"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"related-to":3,"causes":4,"includes":5,
		"consolidates":6,"drives":7,"treats":8,"requires":9,"measures":10,
		"shapes":11,"restores":12,"weakens":13,"caused-by":14,"threatens":15,
		"reduces":16,"mitigates":17,"changes":18,"influences":19,
		"powered-by":20,"compound-of":21,"similar":22,"opposite":23,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
