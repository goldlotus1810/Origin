//go:build ignore
// go run scripts/seed_ocean_space.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── ĐẠI DƯƠNG / MÔI TRƯỜNG BIỂN ────────────────────────
		{"OCEAN_CORAL",     3, `label=rạn san hô|desc=hệ sinh thái biển đa dạng nhất hành tinh Great Barrier Reef tẩy trắng san hô nước biển ấm|vi=rạn san hô,san hô,coral reef|en=coral reef|zh=珊瑚礁`},
		{"OCEAN_DEEP",      3, `label=đại dương sâu|desc=vùng biển sâu dưới 200m ánh sáng không tới sinh vật phát quang Mariana Trench|vi=đại dương sâu,biển sâu|en=deep ocean,deep sea|zh=深海`},
		{"OCEAN_TIDE",      3, `label=thủy triều|desc=sự lên xuống mực nước biển do lực hấp dẫn mặt trăng và mặt trời triều cường|vi=thủy triều,tides|en=tide,tidal|zh=潮汐`},
		{"OCEAN_CURRENT",  3, `label=dòng hải lưu|desc=dòng chảy nước biển quy mô lớn liên tục Gulf Stream Kuroshio vận chuyển nhiệt|vi=dòng hải lưu,hải lưu|en=ocean current|zh=洋流`},
		{"OCEAN_PLASTIC",  3, `label=ô nhiễm nhựa biển|desc=rác thải nhựa tích tụ trong đại dương microplastic ảnh hưởng sinh vật biển|vi=ô nhiễm nhựa biển,rác biển|en=ocean plastic pollution|zh=海洋塑料污染`},
		{"OCEAN_WHALE",    3, `label=cá voi|desc=động vật có vú lớn nhất trái đất sống trong biển cá voi xanh cá heo humpback|vi=cá voi,whale|en=whale|zh=鲸鱼`},
		{"OCEAN_TSUNAMI",  3, `label=sóng thần|desc=sóng biển khổng lồ do động đất núi lửa dưới biển gây ra tàn phá bờ biển|vi=sóng thần,tsunami|en=tsunami|zh=海啸`},
		{"OCEAN_MANGROVE", 3, `label=rừng ngập mặn|desc=hệ sinh thái ven biển bảo vệ bờ biển lưu trữ carbon nơi sinh sản cá|vi=rừng ngập mặn,mangrove|en=mangrove forest|zh=红树林`},
		{"OCEAN_PLANKTON", 3, `label=plankton|desc=sinh vật phù du vi nhỏ nền tảng chuỗi thức ăn biển sản xuất 50% oxy trái đất|vi=plankton,sinh vật phù du|en=plankton|zh=浮游生物`},

		// ── VŨ TRỤ / KHÁM PHÁ KHÔNG GIAN ────────────────────────
		{"SPACE_ISS",      3, `label=Trạm vũ trụ quốc tế|desc=ISS trạm vũ trụ lớn nhất quỹ đạo thấp Trái Đất hợp tác NASA ESA nghiên cứu vi trọng lực|vi=Trạm vũ trụ quốc tế,ISS|en=International Space Station,ISS|zh=国际空间站`},
		{"SPACE_ROCKET",   3, `label=tên lửa|desc=phương tiện đẩy dùng phản lực khí phụt Saturn V Falcon 9 SpaceX phóng vệ tinh|vi=tên lửa,rocket|en=rocket|zh=火箭`},
		{"SPACE_MARS",     3, `label=sao Hỏa|desc=hành tinh thứ 4 từ mặt trời màu đỏ NASA Mars rover Perseverance tìm kiếm sự sống|vi=sao Hỏa,Mars|en=Mars|zh=火星`},
		{"SPACE_MOON",     3, `label=mặt trăng|desc=vệ tinh tự nhiên duy nhất của Trái Đất Apollo 11 Neil Armstrong 1969 thủy triều|vi=mặt trăng,trăng,moon|en=moon,lunar|zh=月球`},
		{"SPACE_SATELLITE",3, `label=vệ tinh nhân tạo|desc=thiết bị nhân tạo quay quanh Trái Đất GPS viễn thông thời tiết Starlink|vi=vệ tinh nhân tạo,satellite|en=satellite,artificial satellite|zh=人造卫星`},
		{"SPACE_TELESCOPE",3, `label=kính thiên văn|desc=thiết bị quan sát thiên thể kính Hubble James Webb hồng ngoại phân tích ánh sáng xa|vi=kính thiên văn,telescope|en=telescope|zh=望远镜`},
		{"SPACE_NEBULA",   3, `label=tinh vân|desc=đám mây khí và bụi trong vũ trụ nơi hình thành sao Orion Nebula Pillars of Creation|vi=tinh vân,nebula|en=nebula|zh=星云`},
		{"SPACE_GRAVITY",  3, `label=trọng lực|desc=lực hút giữa các vật thể có khối lượng định luật Newton Einstein cong không-thời gian|vi=trọng lực,lực hấp dẫn,gravity|en=gravity,gravitational force|zh=引力`},
		{"SPACE_EXOPLANET",3, `label=ngoại hành tinh|desc=hành tinh ngoài hệ mặt trời Kepler James Webb tìm kiếm sự sống vùng ở được|vi=ngoại hành tinh,exoplanet|en=exoplanet|zh=系外行星`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Đại dương
		{"OCEAN_CORAL",    "ENV_OCEAN_ACID",    "threatened-by"},
		{"OCEAN_CORAL",    "ENV_CLIMATE_CHANGE","threatened-by"},
		{"OCEAN_PLASTIC",  "ENV_POLLUTION",     "type-of"},
		{"OCEAN_PLASTIC",  "OCEAN_CORAL",       "harms"},
		{"OCEAN_WHALE",    "OCEAN_DEEP",        "lives-in"},
		{"OCEAN_PLANKTON", "OCEAN_CORAL",       "feeds"},
		{"OCEAN_TIDE",     "SPACE_MOON",        "caused-by"},
		{"OCEAN_TSUNAMI",  "PHYS_WAVE",         "type-of"},
		{"OCEAN_CURRENT",  "GEO_CLIMATE",       "affects"},
		{"OCEAN_MANGROVE", "ENV_CARBON",        "absorbs"},
		// Vũ trụ
		{"SPACE_MARS",     "ASTRO_PLANET",      "is-a"},
		{"SPACE_MOON",     "ASTRO_PLANET",      "orbits"},
		{"SPACE_ROCKET",   "SPACE_ISS",         "delivers-to"},
		{"SPACE_SATELLITE","SPACE_ROCKET",      "launched-by"},
		{"SPACE_TELESCOPE","SPACE_NEBULA",      "observes"},
		{"SPACE_TELESCOPE","ASTRO_BLACKHOLE",   "observes"},
		{"SPACE_GRAVITY",  "ASTRO_BLACKHOLE",   "extreme-near"},
		{"SPACE_GRAVITY",  "PHYS_ENERGY",       "form-of"},
		{"SPACE_EXOPLANET","ASTRO_STAR",        "orbits"},
		{"SPACE_MOON",     "OCEAN_TIDE",        "causes"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"threatened-by":1,"type-of":2,"harms":3,"lives-in":4,
		"feeds":5,"caused-by":6,"affects":7,"absorbs":8,
		"is-a":9,"orbits":10,"delivers-to":11,"launched-by":12,
		"observes":13,"extreme-near":14,"form-of":15,"causes":16,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
