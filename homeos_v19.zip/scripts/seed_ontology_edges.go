//go:build ignore

// scripts/seed_ontology_edges.go
//
// Thêm silk edges nối L3 Life ↔ L6 Perception ↔ L5 Programs
//
// Edge types (theo olang_graph.go):
//   0x08 ∈  — is-a / thuộc về
//   0x09 ⊂  — subset of
//   0x0C ≈  — similar / tương đồng
//   0x0D ⊥  — opposite / đối lập
//   0x0A ∘  — causes / dẫn đến
//   0x0B ≡  — equivalent
//
// Chạy: go run scripts/seed_ontology_edges.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"sync"
)

const ePath = "homeos.olang"
const eLayerIdxEnd = 64 + 9*24

var eMu sync.Mutex

// edgeDef — một silk edge có nghĩa
type edgeDef struct {
	from string // tên node nguồn
	to   string // tên node đích
	typ  uint8  // edge type
	note string // mô tả ngắn (comment)
}

// 0x0C = ≈ similar/liên quan
// 0x0A = ∘ causes/dẫn đến
// 0x0D = ⊥ opposite
// 0x08 = ∈ is-a
// 0x09 = ⊂ part-of

var ontologyEdges = []edgeDef{

	// ── L3 LIFE emotion → L6 PERCEPT sensation ──────────────────
	// Cảm xúc gây ra cảm giác vật lý tương ứng

	// FEAR → PAIN (sợ hãi → đau)
	{"LIFE_FEAR",     "PERCEPT_PAIN",    0x0A, "sợ hãi dẫn đến đau đớn"},
	{"LIFE_FEAR",     "PERCEPT_COLD",    0x0A, "sợ hãi dẫn đến lạnh toát"},
	{"LIFE_FEAR",     "PERCEPT_FAST",    0x0A, "sợ hãi → tim đập nhanh"},

	// JOY → BRIGHT (vui vẻ → sáng sủa)
	{"LIFE_JOY",      "PERCEPT_BRIGHT",  0x0C, "vui vẻ liên quan đến ánh sáng"},
	{"LIFE_JOY",      "PERCEPT_WARM",    0x0C, "vui vẻ gây cảm giác ấm áp"},
	{"LIFE_JOY",      "PERCEPT_FAST",    0x0C, "vui vẻ → năng lượng cao"},

	// SADNESS → DARK/SLOW
	{"LIFE_SADNESS",  "PERCEPT_DARK",    0x0C, "buồn bã liên quan đến bóng tối"},
	{"LIFE_SADNESS",  "PERCEPT_SLOW",    0x0C, "buồn bã → chậm chạp"},
	{"LIFE_SADNESS",  "PERCEPT_COLD",    0x0C, "buồn bã → cảm giác lạnh"},

	// ANGER → HOT/LOUD
	{"LIFE_ANGER",    "PERCEPT_HOT",     0x0A, "tức giận → nóng bừng"},
	{"LIFE_ANGER",    "PERCEPT_LOUD",    0x0A, "tức giận → to tiếng"},
	{"LIFE_ANGER",    "PERCEPT_RED",     0x0C, "tức giận liên quan đến đỏ"},

	// LOVE → WARM/SWEET
	{"LIFE_LOVE",     "PERCEPT_WARM",    0x0C, "tình yêu → ấm áp"},
	{"LIFE_LOVE",     "PERCEPT_SWEET",   0x0C, "tình yêu liên quan đến ngọt ngào"},
	{"LIFE_LOVE",     "PERCEPT_SOFT",    0x0C, "tình yêu → nhẹ nhàng"},

	// CURIOSITY → BRIGHT/SHARP
	{"LIFE_CURIOSITY","PERCEPT_BRIGHT",  0x0C, "tò mò → tinh thần sáng suốt"},
	{"LIFE_CURIOSITY","PERCEPT_SHARP",   0x0C, "tò mò → nhạy bén"},

	// SURPRISE → FAST/LOUD
	{"LIFE_SURPRISE", "PERCEPT_FAST",    0x0A, "ngạc nhiên → phản ứng nhanh"},
	{"LIFE_SURPRISE", "PERCEPT_LOUD",    0x0C, "ngạc nhiên → kêu to"},

	// DISGUST → BITTER/SOUR
	{"LIFE_DISGUST",  "PERCEPT_BITTER",  0x0C, "ghê tởm liên quan đến vị đắng"},
	{"LIFE_DISGUST",  "PERCEPT_SOUR",    0x0C, "ghê tởm liên quan đến vị chua"},

	// TRUST → SMOOTH/WARM
	{"LIFE_TRUST",    "PERCEPT_SMOOTH",  0x0C, "tin tưởng → cảm giác trơn tru"},
	{"LIFE_TRUST",    "PERCEPT_WARM",    0x0C, "tin tưởng → ấm áp"},

	// ── L3 LIFE action/state → L6 PERCEPT ───────────────────────

	// EAT → SWEET/SALTY/BITTER/SOUR
	{"LIFE_EAT",      "PERCEPT_SWEET",   0x0C, "ăn → vị ngọt"},
	{"LIFE_EAT",      "PERCEPT_SALTY",   0x0C, "ăn → vị mặn"},
	{"LIFE_EAT",      "PERCEPT_HUNGER",  0x0D, "ăn đối lập với đói"},

	// SLEEP → QUIET/DARK/SLOW
	{"LIFE_SLEEP",    "PERCEPT_QUIET",   0x0C, "ngủ → yên tĩnh"},
	{"LIFE_SLEEP",    "PERCEPT_DARK",    0x0C, "ngủ → bóng tối"},
	{"LIFE_SLEEP",    "PERCEPT_SLOW",    0x0C, "ngủ → chậm lại"},
	{"LIFE_SLEEP",    "PERCEPT_TIRED",   0x0D, "ngủ xóa đi mệt mỏi"},
	{"LIFE_SLEEP",    "PERCEPT_AWAKE",   0x0D, "ngủ đối lập với tỉnh thức"},

	// RUN → FAST/LOUD
	{"LIFE_RUN",      "PERCEPT_FAST",    0x0A, "chạy → nhanh"},
	{"LIFE_RUN",      "PERCEPT_LOUD",    0x0A, "chạy → tiếng ồn"},
	{"LIFE_RUN",      "PERCEPT_TIRED",   0x0A, "chạy → mệt mỏi"},

	// WALK → SLOW (tương đối)
	{"LIFE_WALK",     "PERCEPT_SLOW",    0x0C, "đi bộ → chậm hơn chạy"},
	{"LIFE_WALK",     "PERCEPT_NEAR",    0x0C, "đi bộ → khoảng cách gần"},

	// THINK → SHARP/QUIET
	{"LIFE_THINK",    "PERCEPT_SHARP",   0x0C, "suy nghĩ → sắc bén"},
	{"LIFE_THINK",    "PERCEPT_QUIET",   0x0C, "suy nghĩ → cần yên tĩnh"},

	// BREATHE → FRESH/FRAGRANT
	{"LIFE_BREATHE",  "PERCEPT_FRESH",   0x0C, "thở → không khí trong lành"},
	{"LIFE_BREATHE",  "PERCEPT_FRAGRANT",0x0A, "thở → hương thơm"},

	// HEAL → CLEAN/SMOOTH
	{"LIFE_HEAL",     "PERCEPT_CLEAN",   0x0C, "lành bệnh → sạch sẽ"},
	{"LIFE_HEAL",     "PERCEPT_SMOOTH",  0x0C, "lành → mịn màng"},
	{"LIFE_HEAL",     "PERCEPT_PAIN",    0x0D, "lành bệnh đối lập với đau"},

	// HUNGER → PAIN (đói → đau bụng)
	{"LIFE_EAT",      "PERCEPT_HUNGER",  0x0D, "ăn đối lập đói"},

	// GROW → BIG/HEAVY
	{"LIFE_GROW",     "PERCEPT_BIG",     0x0A, "lớn lên → to hơn"},
	{"LIFE_GROW",     "PERCEPT_HEAVY",   0x0A, "lớn lên → nặng hơn"},

	// TALK → VOICE/LOUD
	{"LIFE_TALK",     "PERCEPT_VOICE",   0x0A, "nói → giọng nói"},
	{"LIFE_TALK",     "PERCEPT_LOUD",    0x0C, "nói → âm thanh"},

	// LEARN → SHARP/CURIOSITY
	{"LIFE_LEARN",    "PERCEPT_SHARP",   0x0A, "học → sắc bén hơn"},

	// ── L3 LIFE organism → L6 PERCEPT sensory ───────────────────

	// EYE → BRIGHT/DARK/COLOR
	{"LIFE_EYE",      "PERCEPT_BRIGHT",  0x0C, "mắt cảm nhận ánh sáng"},
	{"LIFE_EYE",      "PERCEPT_DARK",    0x0C, "mắt nhận ra bóng tối"},
	{"LIFE_EYE",      "PERCEPT_RED",     0x0C, "mắt nhìn màu đỏ"},
	{"LIFE_EYE",      "PERCEPT_BLUE",    0x0C, "mắt nhìn màu xanh"},

	// HAND → HARD/SOFT/SMOOTH/ROUGH
	{"LIFE_HAND",     "PERCEPT_HARD",    0x0C, "tay cảm nhận cứng"},
	{"LIFE_HAND",     "PERCEPT_SOFT",    0x0C, "tay cảm nhận mềm"},
	{"LIFE_HAND",     "PERCEPT_SMOOTH",  0x0C, "tay cảm nhận trơn"},
	{"LIFE_HAND",     "PERCEPT_ROUGH",   0x0C, "tay cảm nhận nhám"},
	{"LIFE_HAND",     "PERCEPT_NEAR",    0x0C, "tay với tới vật gần"},

	// FOOT → HARD/FAST/SLOW
	{"LIFE_FOOT",     "PERCEPT_HARD",    0x0C, "chân đạp mặt cứng"},
	{"LIFE_FOOT",     "PERCEPT_FAST",    0x0C, "chân quyết định tốc độ"},

	// BRAIN → THINK/SHARP
	{"LIFE_BRAIN",    "LIFE_THINK",      0x0A, "não → suy nghĩ"},
	{"LIFE_BRAIN",    "PERCEPT_SHARP",   0x0C, "não → nhạy bén"},
	{"LIFE_BRAIN",    "LIFE_LEARN",      0x0A, "não cho phép học"},
	{"LIFE_BRAIN",    "LIFE_CURIOSITY",  0x0A, "não tạo ra tò mò"},

	// HEART → LOVE/FEAR (tim đập)
	{"LIFE_HEART",    "LIFE_LOVE",       0x0C, "tim liên quan đến tình yêu"},
	{"LIFE_HEART",    "LIFE_FEAR",       0x0C, "tim đập nhanh khi sợ"},
	{"LIFE_HEART",    "PERCEPT_FAST",    0x0A, "tim đập nhanh"},

	// FLOWER → FRAGRANT/SOFT/COLOR
	{"LIFE_FLOWER",   "PERCEPT_FRAGRANT",0x0A,"hoa → hương thơm"},
	{"LIFE_FLOWER",   "PERCEPT_SOFT",    0x0C, "hoa → mềm mại"},
	{"LIFE_FLOWER",   "PERCEPT_PINK",    0x0C, "hoa → màu hồng"},

	// TREE → BIG/GREEN/FRESH
	{"LIFE_TREE",     "PERCEPT_BIG",     0x0C, "cây → to lớn"},
	{"LIFE_TREE",     "PERCEPT_GREEN",   0x0C, "cây → màu xanh lá"},
	{"LIFE_TREE",     "PERCEPT_FRESH",   0x0C, "cây → không khí trong lành"},

	// ── L3 LIFE opposites ────────────────────────────────────────
	{"LIFE_JOY",      "LIFE_SADNESS",    0x0D, "vui đối lập buồn"},
	{"LIFE_FEAR",     "LIFE_TRUST",      0x0D, "sợ đối lập tin tưởng"},
	{"LIFE_LOVE",     "LIFE_DISGUST",    0x0D, "yêu đối lập ghê tởm"},
	{"LIFE_RUN",      "LIFE_SLEEP",      0x0D, "chạy đối lập ngủ"},
	{"LIFE_GROW",     "LIFE_HEAL",       0x0C, "lớn và lành bệnh tương đồng"},

	// ── L6 PERCEPT opposites ─────────────────────────────────────
	{"PERCEPT_HOT",   "PERCEPT_COLD",    0x0D, "nóng đối lập lạnh"},
	{"PERCEPT_BRIGHT","PERCEPT_DARK",    0x0D, "sáng đối lập tối"},
	{"PERCEPT_LOUD",  "PERCEPT_QUIET",   0x0D, "ồn đối lập yên tĩnh"},
	{"PERCEPT_FAST",  "PERCEPT_SLOW",    0x0D, "nhanh đối lập chậm"},
	{"PERCEPT_BIG",   "PERCEPT_SMALL",   0x0D, "to đối lập nhỏ"},
	{"PERCEPT_HARD",  "PERCEPT_SOFT",    0x0D, "cứng đối lập mềm"},
	{"PERCEPT_HEAVY", "PERCEPT_LIGHT_W", 0x0D, "nặng đối lập nhẹ"},
	{"PERCEPT_NEAR",  "PERCEPT_FAR",     0x0D, "gần đối lập xa"},
	{"PERCEPT_CLEAN", "PERCEPT_DIRTY",   0x0D, "sạch đối lập bẩn"},
	{"PERCEPT_SWEET", "PERCEPT_BITTER",  0x0D, "ngọt đối lập đắng"},
	{"PERCEPT_AWAKE", "PERCEPT_TIRED",   0x0D, "tỉnh thức đối lập mệt mỏi"},
	{"PERCEPT_PAIN",  "PERCEPT_FRESH",   0x0D, "đau đối lập tươi mới"},
	{"PERCEPT_SMOOTH","PERCEPT_ROUGH",   0x0D, "trơn đối lập nhám"},

	// ── L5 PROG internal structure ───────────────────────────────
	// HomeOS components
	{"PROG_HOMEOS",   "PROG_ISL",        0x09, "HomeOS chứa ISL"},
	{"PROG_HOMEOS",   "PROG_SILK",       0x09, "HomeOS chứa Silk Tree"},
	{"PROG_HOMEOS",   "PROG_NCA",        0x09, "HomeOS chứa NCA"},
	{"PROG_HOMEOS",   "PROG_OLANG",      0x09, "HomeOS dùng Olang"},
	{"PROG_HOMEOS",   "PROG_SDF",        0x09, "HomeOS dùng SDF"},
	{"PROG_NCA",      "PROG_MEMORY",     0x09, "NCA có bộ nhớ"},
	{"PROG_NCA",      "PROG_AGENT",      0x09, "NCA quản lý agents"},
	{"PROG_LLM",      "PROG_NEURAL_NET", 0x08, "LLM là neural network"},
	{"PROG_LLM",      "PROG_EMBEDDING",  0x09, "LLM dùng embedding"},
	{"PROG_LLM",      "PROG_ATTENTION",  0x09, "LLM dùng attention"},
	{"PROG_LLM",      "PROG_INFERENCE",  0x09, "LLM chạy inference"},
	{"PROG_AGENT",    "PROG_MEMORY",     0x09, "agent có bộ nhớ"},
	{"PROG_AGENT",    "PROG_SKILL",      0x09, "agent có skill"},
	{"PROG_SILK",     "PROG_ENCRYPT",    0x09, "Silk Tree dùng mã hóa"},
	{"PROG_SILK",     "PROG_MEMORY",     0x0C, "Silk tương đồng bộ nhớ dài hạn"},

	// L5 ↔ L3 (AI learns from Life)
	{"PROG_NCA",      "LIFE_LEARN",      0x0C, "NCA mô phỏng quá trình học"},
	{"PROG_NCA",      "LIFE_BRAIN",      0x0C, "NCA mô phỏng não"},
	{"PROG_MEMORY",   "LIFE_BRAIN",      0x0C, "memory tương đồng não"},
	{"PROG_AGENT",    "LIFE_HUMAN",      0x0C, "agent tương đồng con người"},
	{"PROG_LLM",      "LIFE_THINK",      0x0C, "LLM mô phỏng suy nghĩ"},
	{"PROG_SENSOR",   "LIFE_EYE",        0x0C, "sensor tương đồng mắt"},

	// L5 ↔ L6 (program perception)
	{"PROG_SENSOR",   "PERCEPT_SHARP",   0x0C, "sensor → độ nhạy"},
	{"PROG_INFERENCE","PERCEPT_FAST",    0x0C, "inference → tốc độ"},
	{"PROG_ENCRYPT",  "PERCEPT_HARD",    0x0C, "mã hóa → cứng rắn"},
	{"PROG_EMBEDDING","PERCEPT_SMOOTH",  0x0C, "embedding → không gian trơn"},
}

func main() {
	if _, err := os.Stat(ePath); err != nil {
		log.Fatalf("không tìm thấy %s", ePath)
	}

	names := eReadNames(ePath)
	fmt.Printf("Nodes loaded: %d\n", len(names))

	existing := eReadEdges(ePath)
	fmt.Printf("Existing edges: %d\n", len(existing))

	added, skipped, errs := 0, 0, 0
	for _, e := range ontologyEdges {
		// Fix string edge types (0x0A bị viết nhầm thành "0x0C" string)
		typ := e.typ
		if typ == 0 { typ = 0x0C }

		srcISL, srcOK := names[e.from]
		dstISL, dstOK := names[e.to]
		if !srcOK {
			fmt.Printf("  MISS src %-25s\n", e.from)
			errs++; continue
		}
		if !dstOK {
			fmt.Printf("  MISS dst %-25s\n", e.to)
			errs++; continue
		}
		key := eKey(srcISL, dstISL, typ)
		if existing[key] {
			skipped++; continue
		}
		if err := eAppendEdge(ePath, srcISL, dstISL, typ); err != nil {
			fmt.Printf("  ERR %s→%s: %v\n", e.from, e.to, err)
			errs++; continue
		}
		existing[key] = true
		fmt.Printf("  +%s  %s → %s  (%s)\n", edgeName(typ), e.from, e.to, e.note)
		added++
	}

	fmt.Printf("\n✅ seed_ontology_edges: +%d edges, %d skip, %d err\n", added, skipped, errs)

	if err := eVerify(ePath); err != nil {
		log.Fatalf("SHA256 FAIL: %v", err)
	}
	fmt.Println("✅ SHA256 OK")
}

func edgeName(t uint8) string {
	switch t {
	case 0x08: return "∈ "
	case 0x09: return "⊂ "
	case 0x0A: return "∘ "
	case 0x0B: return "≡ "
	case 0x0C: return "≈ "
	case 0x0D: return "⊥ "
	}
	return fmt.Sprintf("%02x", t)
}

func eReadNames(path string) map[string][8]byte {
	raw, _ := os.ReadFile(path)
	m := map[string][8]byte{}
	for off := 0; off+20 < len(raw); {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2; off++ // lid
		var isl [8]byte; copy(isl[:], raw[off:off+8]); off += 8
		off += 4
		dl := int(binary.BigEndian.Uint32(raw[off : off+4])); off += 4
		nl := int(raw[off]); off++
		ns := off + dl; ne := ns + nl
		if ne > len(raw) { break }
		m[string(raw[ns:ne])] = isl
		off = ne
	}
	return m
}

func eReadEdges(path string) map[string]bool {
	raw, _ := os.ReadFile(path)
	m := map[string]bool{}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	start := len(raw) - nedges*17
	if start < eLayerIdxEnd { return m }
	for i := start; i+17 <= len(raw); i += 17 {
		var src, dst [8]byte
		copy(src[:], raw[i:i+8])
		copy(dst[:], raw[i+8:i+16])
		t := raw[i+16]
		m[eKey(src, dst, t)] = true
	}
	return m
}

func eKey(src, dst [8]byte, t uint8) string {
	return fmt.Sprintf("%x:%x:%02x", src, dst, t)
}

func eAppendEdge(path string, src, dst [8]byte, t uint8) error {
	eMu.Lock(); defer eMu.Unlock()
	raw, err := os.ReadFile(path)
	if err != nil { return err }
	rb := make([]byte, len(raw)+17)
	copy(rb, raw)
	copy(rb[len(raw):], src[:])
	copy(rb[len(raw)+8:], dst[:])
	rb[len(raw)+16] = t
	nedges := binary.BigEndian.Uint32(rb[16:20])
	binary.BigEndian.PutUint32(rb[16:20], nedges+1)
	h := sha256.Sum256(rb[eLayerIdxEnd:])
	copy(rb[28:60], h[:])
	tmp := path + ".etmp"
	if err := os.WriteFile(tmp, rb, 0644); err != nil { return err }
	return os.Rename(tmp, path)
}

func eVerify(path string) error {
	raw, err := os.ReadFile(path)
	if err != nil { return err }
	var stored [32]byte; copy(stored[:], raw[28:60])
	computed := sha256.Sum256(raw[eLayerIdxEnd:])
	if stored != computed { return fmt.Errorf("SHA256 mismatch") }
	return nil
}
