//go:build ignore
// go run scripts/seed_materials_build.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── VẬT LIỆU / KỸ THUẬT ──────────────────────────────────
		{"MATL_STEEL",      3, `label=thép|desc=hợp kim sắt và carbon vật liệu xây dựng và công nghiệp quan trọng nhất độ bền cao chịu lực|vi=thép,sắt thép|en=steel,iron alloy|zh=钢铁`},
		{"MATL_CONCRETE",   3, `label=bê tông|desc=vật liệu xây dựng từ xi măng cát đá nước cốt thép bê tông cốt thép rất phổ biến|vi=bê tông,beton|en=concrete|zh=混凝土`},
		{"MATL_WOOD",       3, `label=gỗ|desc=vật liệu tự nhiên từ thân cây được dùng trong xây dựng nội thất trang trí|vi=gỗ,wood,timber|en=wood,timber|zh=木材`},
		{"MATL_PLASTIC",    3, `label=nhựa|desc=vật liệu polymer tổng hợp nhẹ bền dễ tạo hình ứng dụng rộng rãi từ bao bì đến linh kiện|vi=nhựa,plastic|en=plastic,polymer|zh=塑料`},
		{"MATL_GLASS",      3, `label=thủy tinh|desc=vật liệu vô cơ trong suốt cứng dòn làm từ cát silica ứng dụng cửa sổ màn hình quang học|vi=thủy tinh,kính|en=glass|zh=玻璃`},
		{"MATL_CERAMIC",    3, `label=gốm sứ|desc=vật liệu vô cơ phi kim loại nung ở nhiệt độ cao gốm đất nung sứ men chịu nhiệt|vi=gốm sứ,gốm,sứ|en=ceramic,pottery|zh=陶瓷`},
		{"MATL_ALUMINUM",   3, `label=nhôm|desc=kim loại nhẹ dẫn điện tốt chống ăn mòn dùng trong hàng không ô tô đồ gia dụng|vi=nhôm,aluminum|en=aluminum,aluminium|zh=铝`},
		{"MATL_COPPER",     3, `label=đồng|desc=kim loại dẫn điện tốt nhất trong số kim loại phổ biến dây điện mạch PCB ống nước|vi=đồng,copper|en=copper|zh=铜`},
		{"MATL_SILICON",    3, `label=silicon|desc=bán dẫn quan trọng nhất nền tảng của công nghệ vi mạch chip CPU GPU|vi=silicon,silic|en=silicon|zh=硅`},
		{"MATL_COMPOSITE",  3, `label=vật liệu composite|desc=vật liệu kết hợp từ hai hay nhiều thành phần sợi carbon CFRP vật liệu hàng không|vi=vật liệu composite,composite|en=composite material|zh=复合材料`},
		{"MATL_RUBBER",     3, `label=cao su|desc=vật liệu đàn hồi tự nhiên hoặc tổng hợp lốp xe găng tay đệm chống rung|vi=cao su,rubber|en=rubber|zh=橡胶`},

		// ── KIẾN TRÚC / XÂY DỰNG ─────────────────────────────────
		{"BUILD_HOUSE",     3, `label=nhà ở|desc=công trình kiến trúc cung cấp nơi trú ngụ và sinh hoạt cho con người nhà phố biệt thự chung cư|vi=nhà ở,nhà,house|en=house,home,residence|zh=住宅`},
		{"BUILD_TOWER",     3, `label=tòa nhà cao tầng|desc=công trình kiến trúc nhiều tầng dùng cho văn phòng thương mại hoặc ở cao ốc skyscraper|vi=tòa nhà,cao ốc,building|en=tower,skyscraper,building|zh=高楼`},
		{"BUILD_BRIDGE",    3, `label=cầu|desc=công trình kỹ thuật bắc qua sông hay thung lũng cầu dây văng cầu vòm cầu treo|vi=cầu,bridge|en=bridge|zh=桥梁`},
		{"BUILD_ROAD",      3, `label=đường|desc=công trình hạ tầng giao thông nối liền các địa điểm đường bộ cao tốc quốc lộ|vi=đường,road,highway|en=road,highway|zh=道路`},
		{"BUILD_FOUNDATION",3, `label=móng|desc=bộ phận dưới cùng của công trình xây dựng truyền tải trọng xuống đất nền móng cọc bê tông|vi=móng,foundation|en=foundation|zh=地基`},
		{"BUILD_ARCH",      3, `label=vòm|desc=kết cấu kiến trúc cong phân phối lực theo hình vòm được dùng từ thời La Mã|vi=vòm,arch|en=arch|zh=拱门`},
		{"BUILD_URBAN",     3, `label=quy hoạch đô thị|desc=khoa học và nghệ thuật thiết kế sắp xếp các thành phần đô thị đất đai hạ tầng giao thông|vi=quy hoạch đô thị,urban planning|en=urban planning|zh=城市规划`},
		{"BUILD_INTERIOR",  3, `label=nội thất|desc=thiết kế và trang trí bên trong không gian sống làm việc đồ đạc màu sắc ánh sáng|vi=nội thất,interior design|en=interior design|zh=室内设计`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Vật liệu nội bộ
		{"MATL_STEEL",      "MATL_CONCRETE",   "used-with"},
		{"MATL_SILICON",    "TECH_SEMICONDUCTOR","is-a"},
		{"MATL_COPPER",     "TECH_ENCRYPTION",  "enables"},
		{"MATL_ALUMINUM",   "MATL_COMPOSITE",   "component-of"},
		{"MATL_PLASTIC",    "CHEM_MOLECULE",    "made-of"},
		{"MATL_GLASS",      "CHEM_CARBON",      "component-of"},
		{"MATL_RUBBER",     "CHEM_MOLECULE",    "is-a"},
		// Vật liệu ↔ Vật lý / Hóa học
		{"MATL_STEEL",      "CHEM_REACTION",    "product-of"},
		{"MATL_SILICON",    "PHYS_ELECTRON",    "conducts"},
		{"MATL_COPPER",     "PHYS_ELECTRON",    "conducts"},
		// Xây dựng nội bộ
		{"BUILD_HOUSE",     "BUILD_FOUNDATION", "requires"},
		{"BUILD_TOWER",     "BUILD_FOUNDATION", "requires"},
		{"BUILD_TOWER",     "MATL_STEEL",       "uses"},
		{"BUILD_BRIDGE",    "MATL_STEEL",       "uses"},
		{"BUILD_BRIDGE",    "MATL_CONCRETE",    "uses"},
		{"BUILD_ROAD",      "MATL_CONCRETE",    "uses"},
		{"BUILD_INTERIOR",  "ART_ARCHITECTURE", "part-of"},
		{"BUILD_URBAN",     "PLACE_HANOI",      "applies-to"},
		{"BUILD_URBAN",     "PLACE_SAIGON",     "applies-to"},
		// Vật liệu ↔ Công nghệ
		{"MATL_SILICON",    "TECH_CPU",         "makes"},
		{"MATL_SILICON",    "TECH_GPU",         "makes"},
		// Kiến trúc ↔ Nghệ thuật / Địa danh
		{"BUILD_ARCH",      "ART_ARCHITECTURE", "technique-in"},
		{"PLACE_ANGKOR",    "BUILD_ARCH",       "features"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"used-with":3,"enables":4,"component-of":5,
		"made-of":6,"conducts":7,"product-of":8,"requires":9,"uses":10,
		"applies-to":11,"makes":12,"technique-in":13,"features":14,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
