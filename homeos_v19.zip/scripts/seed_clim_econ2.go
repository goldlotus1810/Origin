//go:build ignore
// go run scripts/seed_clim_econ2.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── BIẾN ĐỔI KHÍ HẬU / MÔI TRƯỜNG CHI TIẾT ─────────────
		{"CLIM_GREENHOUSE",  3, `label=khí nhà kính|desc=khí giữ nhiệt trong khí quyển CO2 CH4 N2O hơi nước hiệu ứng nhà kính toàn cầu|vi=khí nhà kính,greenhouse gas,CO2,khí CO2|en=greenhouse gas,CO2|zh=温室气体`},
		{"CLIM_SEA_RISE",    3, `label=nước biển dâng|desc=mực nước biển toàn cầu tăng do băng tan và giãn nở nhiệt đe dọa vùng ven biển đảo nhỏ|vi=nước biển dâng,sea level rise|en=sea level rise|zh=海平面上升`},
		{"CLIM_WILDFIRE",    3, `label=cháy rừng|desc=đám cháy lan rộng trong rừng hoặc thảm thực vật khô do nhiệt độ cao hạn hán California Australia|vi=cháy rừng,wildfire|en=wildfire,forest fire|zh=野火`},
		{"CLIM_DROUGHT",     3, `label=hạn hán|desc=thiếu hụt lượng mưa trong thời gian dài ảnh hưởng nông nghiệp nguồn nước sinh thái|vi=hạn hán,drought|en=drought|zh=干旱`},
		{"CLIM_FLOOD",       3, `label=lũ lụt|desc=ngập nước bất thường do mưa lớn bão vỡ đê sóng thần thiệt hại người tài sản|vi=lũ lụt,flood|en=flood|zh=洪水`},
		{"CLIM_CORAL_BLEACH",3, `label=san hô tẩy trắng|desc=san hô mất tảo cộng sinh do nước biển ấm lên khiến san hô trắng và chết Rạn Great Barrier|vi=san hô tẩy trắng,coral bleaching|en=coral bleaching|zh=珊瑚白化`},
		{"CLIM_CARBON_TAX",  3, `label=thuế carbon|desc=chính sách đánh thuế lên lượng khí thải CO2 nhằm giảm phát thải khuyến khích năng lượng sạch|vi=thuế carbon,carbon tax,carbon pricing|en=carbon tax,carbon pricing|zh=碳税`},
		{"CLIM_NET_ZERO",    3, `label=net zero|desc=mục tiêu cân bằng phát thải và hấp thụ khí nhà kính về 0 trước năm 2050 cam kết quốc gia|vi=net zero,phát thải ròng bằng 0|en=net zero,carbon neutral|zh=净零排放`},
		{"CLIM_PARIS",       3, `label=Hiệp định Paris|desc=thỏa thuận khí hậu quốc tế 2015 giới hạn nhiệt độ tăng dưới 1.5°C COP21 Liên Hợp Quốc|vi=Hiệp định Paris,Paris Agreement,COP21|en=Paris Agreement,COP21|zh=巴黎协定`},
		{"CLIM_ICECAP",      3, `label=băng địa cực|desc=lớp băng bao phủ vùng cực Bắc Nam Cực Greenland tan chảy do ấm lên toàn cầu|vi=băng địa cực,ice cap,Bắc Cực băng|en=ice cap,polar ice|zh=极地冰盖`},

		// ── KINH TẾ VĨ MÔ ────────────────────────────────────────
		{"ECON2_INFLATION",  3, `label=lạm phát|desc=mức giá chung tăng theo thời gian sức mua giảm CPI ngân hàng trung ương lãi suất|vi=lạm phát,inflation,CPI|en=inflation|zh=通货膨胀`},
		{"ECON2_RECESSION",  3, `label=suy thoái kinh tế|desc=GDP giảm liên tiếp 2 quý thất nghiệp tăng tiêu dùng giảm khủng hoảng tài chính|vi=suy thoái kinh tế,recession|en=recession|zh=经济衰退`},
		{"ECON2_TRADE",      3, `label=thương mại quốc tế|desc=trao đổi hàng hóa dịch vụ giữa các quốc gia xuất nhập khẩu WTO chuỗi cung ứng|vi=thương mại quốc tế,trade,xuất nhập khẩu|en=international trade|zh=国际贸易`},
		{"ECON2_FISCAL",     3, `label=chính sách tài khóa|desc=chính phủ điều tiết nền kinh tế qua thuế và chi tiêu công ngân sách nhà nước thâm hụt|vi=chính sách tài khóa,fiscal policy|en=fiscal policy|zh=财政政策`},
		{"ECON2_MONETARY",   3, `label=chính sách tiền tệ|desc=ngân hàng trung ương kiểm soát cung tiền lãi suất Fed ECB NHNN lạm phát mục tiêu|vi=chính sách tiền tệ,monetary policy|en=monetary policy|zh=货币政策`},
		{"ECON2_INEQUALITY", 3, `label=bất bình đẳng kinh tế|desc=khoảng cách thu nhập tài sản giữa nhóm giàu nghèo hệ số Gini 1% nắm giữ 50% tài sản|vi=bất bình đẳng kinh tế,economic inequality,Gini|en=economic inequality|zh=经济不平等`},
		{"ECON2_STARTUP",    3, `label=khởi nghiệp|desc=doanh nghiệp mới thành lập tiềm năng tăng trưởng nhanh Silicon Valley unicorn venture capital|vi=khởi nghiệp,startup|en=startup|zh=创业`},
		{"ECON2_SUPPLY_CHAIN",3,`label=chuỗi cung ứng|desc=mạng lưới sản xuất phân phối từ nguyên liệu đến người tiêu dùng toàn cầu hóa COVID gián đoạn|vi=chuỗi cung ứng,supply chain|en=supply chain|zh=供应链`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Khí hậu
		{"CLIM_GREENHOUSE",  "ENV_CLIMATE_CHANGE",  "causes"},
		{"CLIM_SEA_RISE",    "NAT_ARCTIC",          "caused-by"},
		{"CLIM_SEA_RISE",    "OCEAN_CORAL",         "threatens"},
		{"CLIM_WILDFIRE",    "CLIM_DROUGHT",        "worsened-by"},
		{"CLIM_WILDFIRE",    "NAT_FOREST",          "destroys"},
		{"CLIM_CORAL_BLEACH","OCEAN_CORAL",         "damages"},
		{"CLIM_CARBON_TAX",  "CLIM_NET_ZERO",       "advances"},
		{"CLIM_NET_ZERO",    "ENERGY_RENEWABLE",    "requires"},
		{"CLIM_PARIS",       "CLIM_NET_ZERO",       "targets"},
		{"CLIM_ICECAP",      "CLIM_SEA_RISE",       "feeds"},
		{"CLIM_FLOOD",       "AGR_DROUGHT",         "alternates-with"},
		// Kinh tế vĩ mô
		{"ECON2_INFLATION",  "ECON2_MONETARY",      "controlled-by"},
		{"ECON2_RECESSION",  "ECON2_FISCAL",        "addressed-by"},
		{"ECON2_TRADE",      "ECON2_SUPPLY_CHAIN",  "depends-on"},
		{"ECON2_MONETARY",   "ECON2_INFLATION",     "targets"},
		{"ECON2_INEQUALITY", "SOC_POVERTY",         "causes"},
		{"ECON2_STARTUP",    "TECH_AI",             "uses"},
		{"ECON2_SUPPLY_CHAIN","TRANS_SHIP",         "uses"},
		{"ECON2_FISCAL",     "ECON_GDP",            "influences"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-28s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	fmt.Printf("✅ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"causes":1,"caused-by":2,"threatens":3,"worsened-by":4,"destroys":5,
		"damages":6,"advances":7,"requires":8,"targets":9,"feeds":10,
		"alternates-with":11,"controlled-by":12,"addressed-by":13,"depends-on":14,
		"influences":15,"uses":16,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
