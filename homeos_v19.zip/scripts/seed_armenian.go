//go:build ignore

// scripts/seed_armenian.go
//
// Seed Armenian Unicode block U+0530–U+058F vào L1 (UTF-32) trong homeos.olang.
//
// Nguồn: https://www.unicode.org/charts/PDF/U0530.pdf (Unicode 17.0)
//
// Phân loại theo SILK ISL (QT5: bản chất quyết định vị trí):
//   L1 = UTF-32 layer — ký tự ngôn ngữ · QR · bất biến
//
// Armenian gồm 5 nhóm bản chất:
//   uppercase  — chữ hoa (capital letters) 0531–0556
//   lowercase  — chữ thường (small letters) 0560–0588
//   ligature   — chữ ghép (ligature) 0587
//   punct      — dấu câu (punctuation) 0589–058A, 055A–055F
//   symbol     — ký hiệu (religious, currency) 058D–058F
//
// DNA format cho L1 Armenian:
//   [0x01][script:0x10=armenian][group:uppercase=0x01,lowercase=0x02,
//          ligature=0x03,punct=0x04,symbol=0x05]
//   [cp_b0][cp_b1][cp_b2][cp_b3][0x00][0x00][0x00]
//
// ISL address:
//   [0x01=L1][0x0A=armenian][group][id][0x00 0x00 0x00 0x00]
//
// Chạy:
//   cd <repo root>
//   go run scripts/seed_armenian.go
//   ./olang verify homeos.olang
//   ./olang dump homeos.olang | grep ARM | wc -l

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const (
	armPath = "homeos.olang"
	armHdr  = 64
	armEnt  = 24
	armNL   = 9
	armIdx  = armHdr + armNL*armEnt // 280
)

type armISL [8]byte

// ── Phân loại Armenian characters ────────────────────────────────

type armChar struct {
	cp    rune
	name  string
	group uint8 // 0x01=upper 0x02=lower 0x03=ligature 0x04=punct 0x05=symbol
	id    uint8
}

func armenianChars() []armChar {
	var chars []armChar

	// Uppercase letters 0531–0556
	upper := []struct {
		cp   rune
		name string
	}{
		{0x0531, "AYB"}, {0x0532, "BEN"}, {0x0533, "GIM"}, {0x0534, "DA"},
		{0x0535, "ECH"}, {0x0536, "ZA"}, {0x0537, "EH"}, {0x0538, "ET"},
		{0x0539, "TO"}, {0x053A, "ZHE"}, {0x053B, "INI"}, {0x053C, "LIWN"},
		{0x053D, "XEH"}, {0x053E, "CA"}, {0x053F, "KEN"}, {0x0540, "HO"},
		{0x0541, "JA"}, {0x0542, "GHAD"}, {0x0543, "CHEH"}, {0x0544, "MEN"},
		{0x0545, "YI"}, {0x0546, "NOW"}, {0x0547, "SHA"}, {0x0548, "VO"},
		{0x0549, "CHA"}, {0x054A, "PEH"}, {0x054B, "JHEH"}, {0x054C, "RA"},
		{0x054D, "SEH"}, {0x054E, "VEW"}, {0x054F, "TIWN"}, {0x0550, "REH"},
		{0x0551, "CO"}, {0x0552, "YIWN"}, {0x0553, "PIWR"}, {0x0554, "KEH"},
		{0x0555, "OH"}, {0x0556, "FEH"},
	}
	for i, u := range upper {
		chars = append(chars, armChar{
			cp:    u.cp,
			name:  fmt.Sprintf("ARM_CAP_%s", u.name),
			group: 0x01,
			id:    uint8(i + 1),
		})
	}

	// Modifier letters 0559–055F
	mods := []struct {
		cp   rune
		name string
	}{
		{0x0559, "MOD_LEFT_HALF_RING"},
		{0x055A, "APOSTROPHE"},
		{0x055B, "EMPHASIS_MARK"},
		{0x055C, "EXCLAMATION_MARK"},
		{0x055D, "COMMA"},
		{0x055E, "QUESTION_MARK"},
		{0x055F, "ABBREVIATION_MARK"},
	}
	for i, m := range mods {
		chars = append(chars, armChar{
			cp:    m.cp,
			name:  fmt.Sprintf("ARM_PUNCT_%s", m.name),
			group: 0x04,
			id:    uint8(i + 1),
		})
	}

	// Lowercase letters 0560–0588
	lower := []struct {
		cp   rune
		name string
	}{
		{0x0560, "TURNED_AYB"}, {0x0561, "AYB"}, {0x0562, "BEN"}, {0x0563, "GIM"},
		{0x0564, "DA"}, {0x0565, "ECH"}, {0x0566, "ZA"}, {0x0567, "EH"},
		{0x0568, "ET"}, {0x0569, "TO"}, {0x056A, "ZHE"}, {0x056B, "INI"},
		{0x056C, "LIWN"}, {0x056D, "XEH"}, {0x056E, "CA"}, {0x056F, "KEN"},
		{0x0570, "HO"}, {0x0571, "JA"}, {0x0572, "GHAD"}, {0x0573, "CHEH"},
		{0x0574, "MEN"}, {0x0575, "YI"}, {0x0576, "NOW"}, {0x0577, "SHA"},
		{0x0578, "VO"}, {0x0579, "CHA"}, {0x057A, "PEH"}, {0x057B, "JHEH"},
		{0x057C, "RA"}, {0x057D, "SEH"}, {0x057E, "VEW"}, {0x057F, "TIWN"},
		{0x0580, "REH"}, {0x0581, "CO"}, {0x0582, "YIWN"}, {0x0583, "PIWR"},
		{0x0584, "KEH"}, {0x0585, "OH"}, {0x0586, "FEH"},
		{0x0588, "YI_WITH_STROKE"}, // phonetic notation
	}
	for i, l := range lower {
		chars = append(chars, armChar{
			cp:    l.cp,
			name:  fmt.Sprintf("ARM_SM_%s", l.name),
			group: 0x02,
			id:    uint8(i + 1),
		})
	}

	// Ligature 0587
	chars = append(chars, armChar{
		cp:    0x0587,
		name:  "ARM_LIG_ECH_YIWN", // և = ե + ւ
		group: 0x03,
		id:    0x01,
	})

	// Punctuation 0589–058A
	chars = append(chars, armChar{cp: 0x0589, name: "ARM_FULL_STOP", group: 0x04, id: 0x08})
	chars = append(chars, armChar{cp: 0x058A, name: "ARM_HYPHEN", group: 0x04, id: 0x09})

	// Religious + currency symbols 058D–058F
	chars = append(chars, armChar{cp: 0x058D, name: "ARM_ETERNITY_RIGHT", group: 0x05, id: 0x01})
	chars = append(chars, armChar{cp: 0x058E, name: "ARM_ETERNITY_LEFT", group: 0x05, id: 0x02})
	chars = append(chars, armChar{cp: 0x058F, name: "ARM_DRAM_SIGN", group: 0x05, id: 0x03}) // ֏ currency

	return chars
}

// ── ISL builder ──────────────────────────────────────────────────
// [0x01=L1][0x0A=armenian][group][id][0x00 0x00 0x00 0x00]
func buildISL(group, id uint8) armISL {
	var isl armISL
	isl[0] = 0x01 // L1
	isl[1] = 0x0A // armenian script
	isl[2] = group
	isl[3] = id
	// isl[4..7] = 0x00
	return isl
}

// ── DNA builder ──────────────────────────────────────────────────
// [0x01=L1_CHAR][script:0x0A][group][cp_b0..b3][pad pad pad]
func buildDNA(group uint8, cp rune) []byte {
	dna := make([]byte, 10)
	dna[0] = 0x01  // opcode: L1_CHAR
	dna[1] = 0x0A  // script: armenian
	dna[2] = group // group
	binary.BigEndian.PutUint32(dna[3:], uint32(cp))
	// dna[7..9] = padding 0x00
	return dna
}

// ── main ─────────────────────────────────────────────────────────
func main() {
	if _, err := os.Stat(armPath); err != nil {
		log.Fatalf("không tìm thấy %s — chạy từ thư mục gốc repo", armPath)
	}

	chars := armenianChars()
	fmt.Printf("Armenian block: %d chars to seed\n", len(chars))

	added := 0
	skipped := 0
	for _, c := range chars {
		isl := buildISL(c.group, c.id)
		dna := buildDNA(c.group, c.cp)
		err := appendL1Armenian(armPath, isl, c.cp, dna, c.name)
		if err != nil {
			if err.Error() == "duplicate ISL" {
				skipped++
				fmt.Printf("  SKIP (dup ISL) U+%04X %s\n", c.cp, c.name)
			} else {
				log.Printf("  ERR U+%04X %s: %v\n", c.cp, c.name, err)
			}
		} else {
			added++
			fmt.Printf("  OK  U+%04X %-30s group=%02X id=%02X\n", c.cp, c.name, c.group, c.id)
		}
	}

	fmt.Printf("\nDone: %d added, %d skipped\n", added, skipped)
	fmt.Println("Chạy: ./olang verify homeos.olang")
}

// ── appendL1Armenian — ghi node L1 vào homeos.olang ──────────────
func appendL1Armenian(filePath string, isl armISL, cp rune, dna []byte, name string) error {
	raw, err := os.ReadFile(filePath)
	if err != nil {
		return err
	}
	if len(raw) < armIdx || string(raw[0:4]) != "OLNG" {
		return fmt.Errorf("bad file")
	}

	nb := []byte(name)
	if len(nb) > 255 {
		nb = nb[:255]
	}

	// Kiểm tra trùng ISL trong toàn file
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*17
	for i := armIdx; i+20 < edgeStart; {
		if i+1 >= len(raw) || raw[i] != 'N' || raw[i+1] != 'D' {
			i++
			continue
		}
		if i+19 >= edgeStart {
			break
		}
		existISL := raw[i+3 : i+11]
		if string(existISL) == string(isl[:]) {
			return fmt.Errorf("duplicate ISL")
		}
		if i+19 > edgeStart {
			break
		}
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		i += 20 + dl + nl
	}

	// Build node record
	rec := make([]byte, 2+1+8+4+4+1+len(dna)+len(nb))
	p := 0
	rec[p] = 'N'; p++
	rec[p] = 'D'; p++
	rec[p] = 0x01; p++ // Layer 1
	copy(rec[p:], isl[:]); p += 8
	binary.BigEndian.PutUint32(rec[p:], uint32(cp)); p += 4
	binary.BigEndian.PutUint32(rec[p:], uint32(len(dna))); p += 4
	rec[p] = uint8(len(nb)); p++
	copy(rec[p:], dna); p += len(dna)
	copy(rec[p:], nb)

	// Tìm insertAt: sau L1 data section
	type li struct{ offset, size uint64 }
	layers := [armNL]li{}
	for i := 0; i < armNL; i++ {
		o := armHdr + i*armEnt
		layers[i].offset = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].size = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}

	var insertAt uint64
	if layers[1].size > 0 {
		insertAt = layers[1].offset + layers[1].size
	} else {
		insertAt = uint64(armIdx)
		for i := 0; i >= 0; i-- {
			if layers[i].size > 0 {
				insertAt = layers[i].offset + layers[i].size
				break
			}
		}
	}

	// Insert vào raw
	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:insertAt]...)
	out = append(out, rec...)
	out = append(out, raw[insertAt:]...)

	// Cập nhật L1 layer index
	o1 := armHdr + 1*armEnt
	if layers[1].size == 0 {
		binary.BigEndian.PutUint64(out[o1+4:], insertAt)
	}
	binary.BigEndian.PutUint64(out[o1+12:], layers[1].size+uint64(len(rec)))
	nnodes := binary.BigEndian.Uint32(out[o1+20:])
	binary.BigEndian.PutUint32(out[o1+20:], nnodes+1)

	// Shift offsets layers sau L1
	for i := 2; i < armNL; i++ {
		o := armHdr + i*armEnt
		if layers[i].size > 0 {
			off := binary.BigEndian.Uint64(out[o+4:])
			binary.BigEndian.PutUint64(out[o+4:], off+uint64(len(rec)))
		}
	}

	// Cập nhật header nnodes tổng
	totalNodes := binary.BigEndian.Uint32(out[9:13])
	binary.BigEndian.PutUint32(out[9:13], totalNodes+1)

	// Cập nhật SHA256 = hash(out[280:])
	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	// Atomic write
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, filePath)
}
