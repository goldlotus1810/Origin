//go:build ignore

// scripts/seed_pos_symbols.go
// Seed 16 ký hiệu loại từ (POS) vào L0 theo origin.md Phần III
// Chạy: go run scripts/seed_pos_symbols.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const (
	posFilePath     = "homeos.olang"
	posHdrSize      = 64
	posLayerEntSize = 24
	posNLayers      = 9
	posLayerIdxEnd  = posHdrSize + posNLayers*posLayerEntSize // 280
)

type posSymbolDef struct {
	name  string
	sym   rune
	isl   [8]byte
	label string
	posEN string
	desc  string
}

var posSymbols = []posSymbolDef{
	{name: "POS_NOUN",   sym: '\uA708', isl: [8]byte{0x00, 0x10, 0x01, 0x01}, label: "danh từ",       posEN: "noun",           desc: "ky hieu loai tu danh tu dung truoc danh tu trong cau"},
	{name: "POS_VERB",   sym: '\uA709', isl: [8]byte{0x00, 0x10, 0x01, 0x02}, label: "dong tu",        posEN: "verb",           desc: "ky hieu loai tu dong tu dung truoc dong tu trong cau"},
	{name: "POS_ADJ",    sym: '\uA70A', isl: [8]byte{0x00, 0x10, 0x01, 0x03}, label: "tinh tu",        posEN: "adjective",      desc: "ky hieu loai tu tinh tu dung truoc tinh tu trong cau"},
	{name: "POS_ADV",    sym: '\uA70B', isl: [8]byte{0x00, 0x10, 0x01, 0x04}, label: "trang tu",       posEN: "adverb",         desc: "ky hieu loai tu trang tu dung truoc trang tu trong cau"},
	{name: "POS_PRN1",   sym: '\u25D4', isl: [8]byte{0x00, 0x10, 0x02, 0x01}, label: "dai tu ngoi 1",  posEN: "pronoun 1st",    desc: "toi chung toi ngoi thu nhat"},
	{name: "POS_PRN2",   sym: '\u25D5', isl: [8]byte{0x00, 0x10, 0x02, 0x02}, label: "dai tu ngoi 2",  posEN: "pronoun 2nd",    desc: "ban cac ban ngoi thu hai"},
	{name: "POS_PRN3",   sym: '\u25D1', isl: [8]byte{0x00, 0x10, 0x02, 0x03}, label: "dai tu ngoi 3",  posEN: "pronoun 3rd",    desc: "anh ay ho no ngoi thu ba"},
	{name: "POS_CONJ",   sym: '\u2E12', isl: [8]byte{0x00, 0x10, 0x03, 0x01}, label: "lien tu",        posEN: "conjunction",    desc: "va hoac nhung noi cac menh de"},
	{name: "POS_PREP",   sym: '\u2E13', isl: [8]byte{0x00, 0x10, 0x03, 0x02}, label: "gioi tu",        posEN: "preposition",    desc: "trong tren cua chi quan he khong gian va so huu"},
	{name: "POS_INTERJ", sym: '\u2E14', isl: [8]byte{0x00, 0x10, 0x03, 0x03}, label: "than tu",        posEN: "interjection",   desc: "o oi bieu dat cam xuc tuc thoi"},
	{name: "POS_DET",    sym: '\u2E16', isl: [8]byte{0x00, 0x10, 0x03, 0x04}, label: "tu han dinh",    posEN: "determiner",     desc: "the a mot gioi han danh tu"},
	{name: "POS_NUM",    sym: '\uA70C', isl: [8]byte{0x00, 0x10, 0x04, 0x01}, label: "so tu",          posEN: "numeral",        desc: "mot hai thu ba bieu thi so luong hoac thu tu"},
	{name: "POS_QUANT",  sym: '\uA70D', isl: [8]byte{0x00, 0x10, 0x04, 0x02}, label: "luong tu",       posEN: "quantifier",     desc: "nhieu it moi chi luong khong xac dinh"},
	{name: "POS_DEMO",   sym: '\uA70E', isl: [8]byte{0x00, 0x10, 0x04, 0x03}, label: "chi tu",         posEN: "demonstrative",  desc: "nay do kia chi vao doi tuong cu the"},
	{name: "POS_PART",   sym: '\uA70F', isl: [8]byte{0x00, 0x10, 0x04, 0x04}, label: "pho tu",         posEN: "particle",       desc: "da dang se chi thi the cua dong tu"},
	{name: "POS_MODAL",  sym: '\uA710', isl: [8]byte{0x00, 0x10, 0x04, 0x05}, label: "tinh thai tu",   posEN: "modal particle", desc: "nhe nhi a u bieu dat thai do nguoi noi"},
}

func main() {
	existing := posReadNames(posFilePath)
	fmt.Printf("Existing nodes: %d\n", len(existing))

	added, skipped := 0, 0
	for _, s := range posSymbols {
		if existing[s.name] {
			fmt.Printf("  skip  %s\n", s.name)
			skipped++
			continue
		}
		dna := fmt.Sprintf("label=%s|en=%s|sym=%s|desc=%s", s.label, s.posEN, string(s.sym), s.desc)
		if err := posAppendNode(posFilePath, 0, s.isl, s.sym, dna, s.name); err != nil {
			log.Printf("  ERR  %s: %v", s.name, err)
			continue
		}
		fmt.Printf("  + [L0] %-16s  %s  (%s)\n", s.name, string(s.sym), s.label)
		added++
		existing[s.name] = true
	}

	fmt.Printf("\n+%d nodes, %d skip\n", added, skipped)
	if err := posVerify(posFilePath); err != nil {
		log.Fatalf("VERIFY FAIL: %v", err)
	}
	raw, _ := os.ReadFile(posFilePath)
	total := binary.BigEndian.Uint32(raw[12:16])
	fmt.Printf("✅ done — total nodes: %d\n", total)
}

func posReadNames(path string) map[string]bool {
	raw, err := os.ReadFile(path)
	if err != nil { log.Fatalf("read: %v", err) }
	m := map[string]bool{}
	type linfo struct{ offset, size uint64 }
	li := [posNLayers]linfo{}
	for i := 0; i < posNLayers; i++ {
		o := posHdrSize + i*posLayerEntSize
		li[i].offset = binary.BigEndian.Uint64(raw[o+4 : o+12])
		li[i].size   = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}
	for i := 0; i < posNLayers; i++ {
		if li[i].size == 0 { continue }
		start := int(li[i].offset)
		end   := start + int(li[i].size)
		if end > len(raw) { end = len(raw) }
		for off := start; off+20 < end; {
			if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
			base := off; off += 2
			if off+15 > len(raw) { break }
			off += 1 + 8 + 4 // layerID + isl + codepoint
			dl := int(binary.BigEndian.Uint32(raw[off : off+4])); off += 4
			nl := int(raw[off]); off++
			if off+dl+nl > len(raw) { off = base+1; break }
			name := string(raw[off+dl : off+dl+nl])
			m[name] = true
			off += dl + nl
		}
	}
	return m
}

func posAppendNode(filePath string, layerID uint8, isl [8]byte, cp rune, dna, name string) error {
	raw, err := os.ReadFile(filePath)
	if err != nil { return fmt.Errorf("read: %w", err) }
	if len(raw) < posLayerIdxEnd { return fmt.Errorf("file too small") }
	if string(raw[0:4]) != "OLNG" { return fmt.Errorf("bad magic") }

	type linfo struct{ offset, size uint64; nnodes uint32 }
	li := [posNLayers]linfo{}
	for i := 0; i < posNLayers; i++ {
		o := posHdrSize + i*posLayerEntSize
		li[i].offset = binary.BigEndian.Uint64(raw[o+4 : o+12])
		li[i].size   = binary.BigEndian.Uint64(raw[o+12 : o+20])
		li[i].nnodes = binary.BigEndian.Uint32(raw[o+20 : o+24])
	}

	dnaB  := []byte(dna)
	nameB := []byte(name)
	if len(nameB) > 255 { nameB = nameB[:255] }
	rec := make([]byte, 2+1+8+4+4+1+len(dnaB)+len(nameB))
	p := 0
	rec[p] = 'N'; p++
	rec[p] = 'D'; p++
	rec[p] = layerID; p++
	copy(rec[p:], isl[:]); p += 8
	binary.BigEndian.PutUint32(rec[p:], uint32(cp)); p += 4
	binary.BigEndian.PutUint32(rec[p:], uint32(len(dnaB))); p += 4
	rec[p] = uint8(len(nameB)); p++
	copy(rec[p:], dnaB); p += len(dnaB)
	copy(rec[p:], nameB)

	tgt := int(layerID)
	var insertAt uint64
	if li[tgt].size > 0 {
		insertAt = li[tgt].offset + li[tgt].size
	} else {
		insertAt = uint64(posLayerIdxEnd)
		for i := tgt - 1; i >= 0; i-- {
			if li[i].size > 0 { insertAt = li[i].offset + li[i].size; break }
		}
	}

	newRaw := make([]byte, 0, len(raw)+len(rec))
	newRaw = append(newRaw, raw[:insertAt]...)
	newRaw = append(newRaw, rec...)
	newRaw = append(newRaw, raw[insertAt:]...)

	oldN := binary.BigEndian.Uint32(newRaw[12:16])
	binary.BigEndian.PutUint32(newRaw[12:], oldN+1)

	for i := 0; i < posNLayers; i++ {
		o   := posHdrSize + i*posLayerEntSize
		lo  := binary.BigEndian.Uint64(newRaw[o+4 : o+12])
		ls  := binary.BigEndian.Uint64(newRaw[o+12 : o+20])
		ln  := binary.BigEndian.Uint32(newRaw[o+20 : o+24])
		if i == tgt {
			if ls == 0 { binary.BigEndian.PutUint64(newRaw[o+4:], insertAt) }
			binary.BigEndian.PutUint64(newRaw[o+12:], ls+uint64(len(rec)))
			binary.BigEndian.PutUint32(newRaw[o+20:], ln+1)
		} else if lo > 0 && lo >= insertAt {
			binary.BigEndian.PutUint64(newRaw[o+4:], lo+uint64(len(rec)))
		}
	}

	sum := sha256.Sum256(newRaw[posLayerIdxEnd:])
	copy(newRaw[28:60], sum[:])

	tmp := filePath + ".postmp"
	if err := os.WriteFile(tmp, newRaw, 0644); err != nil { return fmt.Errorf("write tmp: %w", err) }
	return os.Rename(tmp, filePath)
}

func posVerify(path string) error {
	raw, _ := os.ReadFile(path)
	var stored [32]byte
	copy(stored[:], raw[28:60])
	computed := sha256.Sum256(raw[posLayerIdxEnd:])
	if stored != computed { return fmt.Errorf("hash mismatch") }
	return nil
}
