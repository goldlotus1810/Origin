//go:build ignore
// go run scripts/seed_law_digital.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── PHÁP LUẬT / TƯ PHÁP ──────────────────────────────────
		{"LAW_CONTRACT",    3, `label=hợp đồng|desc=thỏa thuận pháp lý ràng buộc giữa hai hay nhiều bên quyền nghĩa vụ điều khoản|vi=hợp đồng,contract|en=contract,agreement|zh=合同`},
		{"LAW_CRIME",       3, `label=tội phạm|desc=hành vi vi phạm pháp luật hình sự bị pháp luật nghiêm cấm truy tố xét xử bỏ tù|vi=tội phạm,crime,criminal|en=crime,criminal|zh=犯罪`},
		{"LAW_COURT",       3, `label=tòa án|desc=cơ quan tư pháp xét xử tranh chấp và tội phạm thẩm phán bồi thẩm đoàn phán quyết|vi=tòa án,court|en=court,tribunal|zh=法院`},
		{"LAW_CONSTITUTION",3, `label=hiến pháp|desc=văn bản pháp lý tối cao của quốc gia xác định quyền lực nhà nước quyền công dân|vi=hiến pháp,constitution|en=constitution|zh=宪法`},
		{"LAW_IP",          3, `label=sở hữu trí tuệ|desc=quyền bảo hộ sáng tạo trí tuệ bằng sáng chế bản quyền nhãn hiệu WIPO|vi=sở hữu trí tuệ,intellectual property,IP|en=intellectual property,IP,patent,copyright|zh=知识产权`},
		{"LAW_TAX",         3, `label=thuế|desc=khoản thu bắt buộc nhà nước thu từ công dân doanh nghiệp thuế thu nhập VAT|vi=thuế,tax|en=tax,taxation|zh=税收`},
		{"LAW_HUMAN_LAW",   3, `label=luật quốc tế|desc=hệ thống quy tắc điều chỉnh quan hệ giữa các quốc gia Liên Hợp Quốc điều ước quốc tế|vi=luật quốc tế,international law|en=international law|zh=国际法`},
		{"LAW_PRIVACY",     3, `label=quyền riêng tư|desc=quyền kiểm soát thông tin cá nhân GDPR bảo vệ dữ liệu cá nhân|vi=quyền riêng tư,privacy|en=privacy,data privacy|zh=隐私权`},

		// ── CÔNG NGHỆ SỐ / INTERNET ──────────────────────────────
		{"DIG_INTERNET",    3, `label=internet|desc=mạng lưới toàn cầu kết nối hàng tỷ thiết bị TCP/IP HTTP thế giới số|vi=internet,mạng internet|en=internet|zh=互联网`},
		{"DIG_5G",          3, `label=mạng 5G|desc=thế hệ mạng di động thứ 5 tốc độ cực cao độ trễ thấp kết nối IoT|vi=mạng 5G,5G|en=5G network,5G|zh=5G网络`},
		{"DIG_CLOUD",       3, `label=điện toán đám mây|desc=cung cấp dịch vụ máy tính qua internet AWS Azure Google Cloud SaaS PaaS|vi=điện toán đám mây,cloud computing|en=cloud computing,cloud|zh=云计算`},
		{"DIG_BIG_DATA",    3, `label=dữ liệu lớn|desc=tập dữ liệu quá lớn để xử lý thông thường volume velocity variety Hadoop Spark|vi=dữ liệu lớn,big data|en=big data|zh=大数据`},
		{"DIG_CYBERSEC",    3, `label=an ninh mạng|desc=bảo vệ hệ thống mạng và dữ liệu khỏi tấn công mạng hack phần mềm độc hại|vi=an ninh mạng,cybersecurity|en=cybersecurity,cyber security|zh=网络安全`},
		{"DIG_IOT",         3, `label=Internet vạn vật|desc=mạng lưới thiết bị vật lý kết nối internet cảm biến nhà thông minh SmartHome|vi=Internet vạn vật,IoT|en=Internet of Things,IoT|zh=物联网`},
		{"DIG_METAVERSE",   3, `label=metaverse|desc=thế giới ảo ba chiều kết hợp thực tế ảo thực tế tăng cường VR AR tương tác|vi=metaverse,vũ trụ ảo|en=metaverse|zh=元宇宙`},
		{"DIG_OPEN_SOURCE", 3, `label=mã nguồn mở|desc=phần mềm có mã nguồn công khai tự do sử dụng sửa đổi Linux Git Python|vi=mã nguồn mở,open source|en=open source|zh=开源`},
		{"DIG_DATABASE",    3, `label=cơ sở dữ liệu|desc=hệ thống lưu trữ và quản lý dữ liệu có cấu trúc SQL MySQL PostgreSQL MongoDB|vi=cơ sở dữ liệu,database|en=database|zh=数据库`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Pháp luật
		{"LAW_COURT",       "LAW_CRIME",         "prosecutes"},
		{"LAW_CONSTITUTION","LAW_HUMAN_LAW",     "basis-of"},
		{"LAW_IP",          "TECH_AI",           "governs"},
		{"LAW_IP",          "ART_MUSIC",         "protects"},
		{"LAW_TAX",         "ECON_GDP",          "funds"},
		{"LAW_CONTRACT",    "ECON_MARKET",       "enables"},
		{"LAW_PRIVACY",     "DIG_CYBERSEC",      "related-to"},
		{"LAW_HUMAN_LAW",   "SOC_HUMAN_RIGHTS",  "codifies"},
		// Digital
		{"DIG_INTERNET",    "DIG_CLOUD",         "enables"},
		{"DIG_5G",          "DIG_IOT",           "connects"},
		{"DIG_CLOUD",       "DIG_BIG_DATA",      "processes"},
		{"DIG_BIG_DATA",    "TECH_ML",           "feeds"},
		{"DIG_CYBERSEC",    "DIG_INTERNET",      "protects"},
		{"DIG_IOT",         "TECH_SMARTHOME",    "enables"},
		{"DIG_METAVERSE",   "TECH_VR",           "uses"},
		{"DIG_OPEN_SOURCE", "TECH_LINUX",        "includes"},
		{"DIG_DATABASE",    "DIG_BIG_DATA",      "stores"},
		{"DIG_5G",          "TRANS_DRONE",       "enables"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	fmt.Printf("✅ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"prosecutes":1,"basis-of":2,"governs":3,"protects":4,"funds":5,
		"enables":6,"related-to":7,"codifies":8,"connects":9,"processes":10,
		"feeds":11,"stores":12,"uses":13,"includes":14,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
