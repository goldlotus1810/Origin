//go:build ignore
// seed_milestone3900.go — MILESTONE 3900 — 100 nodes
// Domains: LOGIC2_ SETTHEORY_ PROBSTAT_ INFOTHEORY_ COMPLEXITY_
//          GEOLOGY_ MINERAL_ PALEONTO_ SOIL2_ HYDRO_
//          SOCIO3_ POLITICAL_ INTRELAT_ CONFLICT_ PEACE_
//          MEDIA3_ JOURNALIST_ RHETORIC_ SEMIOTICS_ NARRATIVE_
//          VIETNAM2040_ VNECONOMY2_ VNCITY_ VNTRANSPORT_ VNDIGITAL_
//          IMMUNOL2_ ONCOLOGY_ CARDIO_ NEURO2_ ENDOCRIN_
//          TEXTILE_ FASHION3_ JEWELRY_ PERFUME_ INTERIOR_
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	ex := readNames(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{

		// ── LOGIC 2 & SET THEORY (LOGIC2_ / SETTHEORY_) ──────────────
		{"LOGIC2_MODAL",        3,`label=logic modal|desc=modal logic possible worlds Kripke semantics necessity possibility S4 S5 temporal deontic epistemic accessibility|vi=logic modal,modal logic|en=modal logic`},
		{"LOGIC2_FUZZY",        3,`label=logic mờ|desc=fuzzy logic Lotfi Zadeh membership function partial truth linguistic variable fuzzy set control washing machine|vi=logic mờ,fuzzy logic|en=fuzzy logic`},
		{"LOGIC2_PARADOX",      3,`label=các nghịch lý logic|desc=logical paradox Liar Russell's paradox Grelling Berry Burali-Forti Cantor diagonal Gödel incompleteness|vi=các nghịch lý logic,logical paradox|en=logical paradox`},
		{"SETTHEORY_ZFC",       3,`label=lý thuyết tập hợp ZFC|desc=ZFC axioms Zermelo-Fraenkel choice axiom of foundation regularity continuum hypothesis cardinal ordinal|vi=lý thuyết tập hợp ZFC,ZFC set theory|en=ZFC set theory`},
		{"SETTHEORY_INFINITE",  3,`label=vô cực trong toán học|desc=infinity countable uncountable aleph beth Cantor diagonalization power set continuum hypothesis undecidable|vi=vô cực trong toán học,mathematical infinity|en=mathematical infinity`},

		// ── PROBABILITY & STATISTICS (PROBSTAT_) ─────────────────────
		{"PROBSTAT_BAYESIAN",   3,`label=thống kê Bayes|desc=Bayesian statistics prior posterior likelihood Bayes theorem MCMC credible interval belief update conjugate|vi=thống kê Bayes,Bayesian statistics|en=Bayesian statistics`},
		{"PROBSTAT_CAUSAL",     3,`label=suy luận nhân quả|desc=causal inference do-calculus Pearl DAG backdoor criterion counterfactual potential outcomes Rubin RCT|vi=suy luận nhân quả,causal inference|en=causal inference`},
		{"PROBSTAT_EXTREME",    3,`label=lý thuyết giá trị cực trị|desc=extreme value theory Gumbel Fréchet Weibull fat tail Black Swan Nassim Taleb return period flood|vi=lý thuyết giá trị cực trị,extreme value theory|en=extreme value theory`},
		{"PROBSTAT_BOOTSTRAP",  3,`label=bootstrap thống kê|desc=bootstrap resampling Efron confidence interval nonparametric permutation test Monte Carlo simulation|vi=bootstrap thống kê,bootstrap statistics|en=bootstrap statistics`},
		{"PROBSTAT_SURVIVAL",   3,`label=phân tích sinh tồn|desc=survival analysis Kaplan-Meier Cox proportional hazard censoring time-to-event clinical trial endpoint|vi=phân tích sinh tồn,survival analysis|en=survival analysis`},

		// ── INFORMATION THEORY (INFOTHEORY_) ─────────────────────────
		{"INFOTHEORY_SHANNON",  3,`label=lý thuyết thông tin Shannon|desc=Shannon information entropy bit channel capacity mutual information source coding theorem H=-Σp·log p|vi=lý thuyết thông tin Shannon,Shannon information theory|en=information theory`},
		{"INFOTHEORY_CODING",   3,`label=lý thuyết mã hóa|desc=coding theory error correction Hamming code Reed-Solomon LDPC turbo polar minimum distance sphere packing|vi=lý thuyết mã hóa,coding theory|en=coding theory`},
		{"INFOTHEORY_COMPLEXITY",3,`label=độ phức tạp Kolmogorov|desc=Kolmogorov complexity algorithmic information theory minimum description length MDL randomness compressibility|vi=độ phức tạp Kolmogorov,Kolmogorov complexity|en=Kolmogorov complexity`},
		{"INFOTHEORY_NETWORK",  3,`label=lý thuyết mạng thông tin|desc=network information theory broadcast channel multiple access interference relay capacity region achievable rate|vi=lý thuyết mạng thông tin,network information theory|en=network information theory`},
		{"INFOTHEORY_QUANTUM",  3,`label=thông tin lượng tử|desc=quantum information qubit von Neumann entropy quantum channel capacity quantum error correction stabilizer code|vi=thông tin lượng tử,quantum information|en=quantum information`},

		// ── GEOLOGY (GEOLOGY_) ───────────────────────────────────────
		{"GEOLOGY_PLATE",       3,`label=kiến tạo mảng|desc=plate tectonics continental drift Wegener seafloor spreading mid-ocean ridge subduction Pangaea Wilson cycle|vi=kiến tạo mảng,plate tectonics|en=plate tectonics`},
		{"GEOLOGY_ROCK_CYCLE",  3,`label=chu trình đá|desc=rock cycle igneous sedimentary metamorphic magma crystallization weathering erosion deposition burial lithification|vi=chu trình đá,rock cycle|en=rock cycle`},
		{"GEOLOGY_EARTHQUAKE",  3,`label=động đất|desc=earthquake seismology Richter moment magnitude P-wave S-wave fault strike-slip thrust normal USGS early warning|vi=động đất,earthquake|en=earthquake`},
		{"GEOLOGY_VOLCANO",     3,`label=núi lửa|desc=volcano magma pyroclastic flow lahar ash cloud Plinian eruption hotspot subduction shield composite caldera|vi=núi lửa,volcano|en=volcano`},
		{"GEOLOGY_MINERAL",     3,`label=khoáng vật|desc=mineral crystal structure Mohs hardness silicate carbonate oxide sulfide cleavage luster streak formation|vi=khoáng vật,mineral|en=mineral`},

		// ── PALEONTOLOGY (PALEONTO_) ─────────────────────────────────
		{"PALEONTO_DINOSAUR",   3,`label=khủng long|desc=dinosaur Mesozoic Jurassic Cretaceous cladistics feathered birds K-Pg extinction asteroid Chicxulub theropod|vi=khủng long,dinosaur|en=dinosaur`},
		{"PALEONTO_CAMBRIAN",   3,`label=bùng nổ Cambrian|desc=Cambrian explosion 541 Ma Burgess Shale Chengjiang body plan diversity eye bilateral symmetry Ediacaran|vi=bùng nổ Cambrian,Cambrian explosion|en=Cambrian explosion`},
		{"PALEONTO_FOSSIL",     3,`label=hóa thạch|desc=fossil formation permineralization amber mold cast trace biostratigraphy index fossil dating sedimentary layer|vi=hóa thạch,fossil|en=fossil`},
		{"PALEONTO_MASS_EXT",   3,`label=tuyệt chủng hàng loạt|desc=mass extinction Big Five Ordovician Devonian Permian Triassic KPg 96% marine species PETM sixth|vi=tuyệt chủng hàng loạt,mass extinction|en=mass extinction`},
		{"PALEONTO_HUMAN_ANC",  3,`label=tổ tiên người|desc=human ancestor Australopithecus Homo habilis erectus heidelbergensis Denisovan Neanderthal admixture out of Africa|vi=tổ tiên người,human ancestor|en=human ancestor`},

		// ── SOCIOLOGY 3 (SOCIO3_) ─────────────────────────────────────
		{"SOCIO3_INEQUALITY",   3,`label=bất bình đẳng xã hội|desc=social inequality Gini coefficient Piketty wealth concentration intersectionality class race gender power|vi=bất bình đẳng xã hội,social inequality|en=social inequality`},
		{"SOCIO3_NETWORK",      3,`label=mạng lưới xã hội|desc=social network analysis Granovetter weak ties structural hole Dunbar number echo chamber homophily|vi=mạng lưới xã hội,social network|en=social network`},
		{"SOCIO3_COLLECTIVE",   3,`label=hành động tập thể|desc=collective action free rider problem Olson public good tragedy of commons coordination Ostrom commons governance|vi=hành động tập thể,collective action|en=collective action`},
		{"SOCIO3_MIGRATION",    3,`label=di cư và di dân|desc=migration push pull factor remittance diaspora integration assimilation transnational identity brain drain refugee|vi=di cư và di dân,migration|en=migration`},
		{"SOCIO3_RELIGION_SOC", 3,`label=xã hội học tôn giáo|desc=sociology of religion Durkheim sacred profane Weber Protestant ethic secularization thesis civil religion|vi=xã hội học tôn giáo,sociology of religion|en=sociology of religion`},

		// ── MEDIA 3 (MEDIA3_) ────────────────────────────────────────
		{"MEDIA3_ALGORITHM",    3,`label=thuật toán mạng xã hội|desc=social media algorithm engagement optimization filter bubble radicalization recommendation YouTube TikTok attention|vi=thuật toán mạng xã hội,social media algorithm|en=social media algorithm`},
		{"MEDIA3_MISINFO",      3,`label=thông tin sai lệch|desc=misinformation disinformation fake news prebunking inoculation theory fact-checking SIFT lateral reading|vi=thông tin sai lệch,misinformation|en=misinformation`},
		{"MEDIA3_PODCAST",      3,`label=podcast|desc=podcast RSS Serial Joe Rogan discovery advertising host-read dynamic insertion listener-supported subscription Spotify|vi=podcast,podcast|en=podcast`},
		{"MEDIA3_NEWSLETTER",   3,`label=bản tin số|desc=newsletter Substack Beehiiv email open rate subscriber owned media direct relationship ad-free monetize niche|vi=bản tin số,newsletter|en=newsletter`},
		{"MEDIA3_SHORTFORM",    3,`label=nội dung dạng ngắn|desc=short-form content TikTok Reels Shorts attention span hook retention loop creator economy viral algorithm|vi=nội dung dạng ngắn,short-form content|en=short-form content`},

		// ── VIETNAM 2040 VISION (VIETNAM2040_) ───────────────────────
		{"VIETNAM2040_VISION",  3,`label=tầm nhìn Việt Nam 2045|desc=Việt Nam 2045 phát triển nước thu nhập cao GDP 7000 USD chiến lược quốc gia đổi mới sáng tạo công nghệ|vi=tầm nhìn Việt Nam 2045,Vietnam 2045 vision|en=Vietnam 2045 vision`},
		{"VIETNAM2040_SEMI",    3,`label=bán dẫn Việt Nam|desc=bán dẫn Việt Nam Intel Samsung Samsung Amkor HANA Micron nhân lực chip thiếu hụt đào tạo đại học|vi=bán dẫn Việt Nam,Vietnam semiconductor|en=Vietnam semiconductor`},
		{"VIETNAM2040_GREEN",   3,`label=kinh tế xanh Việt Nam|desc=kinh tế xanh Việt Nam COP26 net zero 2050 năng lượng tái tạo điện gió điện mặt trời tín chỉ carbon|vi=kinh tế xanh Việt Nam,Vietnam green economy|en=Vietnam green economy`},
		{"VIETNAM2040_DIGITAL", 3,`label=chuyển đổi số quốc gia|desc=chuyển đổi số quốc gia Việt Nam dữ liệu dân cư căn cước công dân eGov định danh điện tử VNeID|vi=chuyển đổi số quốc gia,Vietnam digital transformation|en=Vietnam digital transformation`},
		{"VIETNAM2040_DEMO",    3,`label=nhân khẩu học Việt Nam|desc=nhân khẩu học Việt Nam già hóa dân số tỷ lệ sinh giảm dân số vàng 2040 lực lượng lao động kỹ năng|vi=nhân khẩu học Việt Nam,Vietnam demographics|en=Vietnam demographics`},

		// ── VIETNAM ECONOMY 2 (VNECONOMY2_) ──────────────────────────
		{"VNECONOMY2_FDI",      3,`label=đầu tư nước ngoài|desc=FDI Việt Nam Samsung LG Intel LEGO chuỗi cung ứng dịch chuyển Trung Quốc + 1 CPTPP EVFTA thu hút|vi=đầu tư nước ngoài Việt Nam,Vietnam FDI|en=Vietnam FDI`},
		{"VNECONOMY2_EXPORT",   3,`label=xuất khẩu Việt Nam|desc=xuất khẩu Việt Nam điện tử may mặc giày dép thủy sản gạo cà phê top 10 thế giới đa dạng hóa|vi=xuất khẩu Việt Nam,Vietnam export|en=Vietnam export`},
		{"VNECONOMY2_SME",      3,`label=doanh nghiệp vừa và nhỏ|desc=SME Việt Nam 97% doanh nghiệp tiếp cận vốn chuyển đổi số hỗ trợ chính sách năng suất lao động|vi=doanh nghiệp vừa và nhỏ Việt Nam,Vietnam SME|en=Vietnam SME`},
		{"VNECONOMY2_REAL_ESTATE",3,`label=bất động sản Việt Nam|desc=bất động sản Việt Nam giá đất đô thị hóa đầu cơ tín dụng trái phiếu khủng hoảng pháp lý nhà ở xã hội|vi=bất động sản Việt Nam,Vietnam real estate|en=Vietnam real estate`},
		{"VNECONOMY2_BANKING",  3,`label=ngân hàng Việt Nam|desc=ngân hàng Việt Nam Vietcombank BIDV Agribank tái cơ cấu nợ xấu Basel II thanh khoản lãi suất|vi=ngân hàng Việt Nam,Vietnam banking|en=Vietnam banking`},

		// ── VIETNAM CITIES (VNCITY_) ─────────────────────────────────
		{"VNCITY_HANOI",        3,`label=Hà Nội|desc=Hà Nội thủ đô 1000 năm Thăng Long 36 phố phường Hồ Tây Hoàn Kiếm quy hoạch đô thị mở rộng tắc đường ô nhiễm|vi=Hà Nội,Hanoi|en=Hanoi`},
		{"VNCITY_HCMC",         3,`label=TP Hồ Chí Minh|desc=TP HCM Sài Gòn trung tâm kinh tế 13 triệu dân ngập lụt metro bất động sản đầu tàu tăng trưởng|vi=TP Hồ Chí Minh,Ho Chi Minh City|en=Ho Chi Minh City`},
		{"VNCITY_DANANG",       3,`label=Đà Nẵng|desc=Đà Nẵng thành phố đáng sống du lịch biển cầu Rồng Bà Nà Hills cảng Tiên Sa công nghệ cao đổi mới|vi=Đà Nẵng,Da Nang|en=Da Nang`},
		{"VNCITY_HIPHONG",      3,`label=Hải Phòng|desc=Hải Phòng cảng biển lớn nhất miền Bắc công nghiệp đóng tàu khu kinh tế VSIP cát Bà Đồ Sơn|vi=Hải Phòng,Hai Phong|en=Hai Phong`},
		{"VNCITY_CANTHO",       3,`label=Cần Thơ|desc=Cần Thơ thành phố Đồng bằng sông Cửu Long chợ nổi Cái Răng nông nghiệp công nghệ cao trung tâm vùng|vi=Cần Thơ,Can Tho|en=Can Tho`},

		// ── IMMUNOLOGY 2 (IMMUNOL2_) ─────────────────────────────────
		{"IMMUNOL2_INNATE",     3,`label=miễn dịch bẩm sinh|desc=innate immunity TLR pattern recognition PAMP DAMP inflammasome complement NK cell neutrophil macrophage first line|vi=miễn dịch bẩm sinh,innate immunity|en=innate immunity`},
		{"IMMUNOL2_ADAPTIVE",   3,`label=miễn dịch thích nghi|desc=adaptive immunity B cell T cell antibody clonal selection MHC antigen presentation somatic hypermutation affinity maturation|vi=miễn dịch thích nghi,adaptive immunity|en=adaptive immunity`},
		{"IMMUNOL2_AUTOIMMUNE", 3,`label=bệnh tự miễn|desc=autoimmune disease rheumatoid arthritis lupus SLE multiple sclerosis type 1 diabetes loss tolerance Treg checkpoint|vi=bệnh tự miễn,autoimmune disease|en=autoimmune disease`},
		{"IMMUNOL2_CHECKPOINT", 3,`label=liệu pháp miễn dịch ung thư|desc=cancer immunotherapy checkpoint inhibitor PD-1 CTLA-4 CAR-T cell bispecific antibody tumor microenvironment response|vi=liệu pháp miễn dịch ung thư,cancer immunotherapy|en=cancer immunotherapy`},
		{"IMMUNOL2_ALLERGY",    3,`label=dị ứng và miễn dịch|desc=allergy IgE mast cell sensitization anaphylaxis atopic march eczema food allergy desensitization hygiene hypothesis|vi=dị ứng và miễn dịch,allergy immunology|en=allergy immunology`},

		// ── NEUROLOGY 2 (NEURO2_) ────────────────────────────────────
		{"NEURO2_STROKE",       3,`label=đột quỵ|desc=stroke ischemic hemorrhagic FAST tPA thrombectomy penumbra neuroprotection rehabilitation neuroplasticity recovery|vi=đột quỵ,stroke|en=stroke`},
		{"NEURO2_DEMENTIA",     3,`label=sa sút trí tuệ|desc=dementia Alzheimer's amyloid tau NFT vascular frontotemporal Lewy body biomarker early detection prevention|vi=sa sút trí tuệ,dementia|en=dementia`},
		{"NEURO2_PARKINSON",    3,`label=Parkinson|desc=Parkinson disease dopamine substantia nigra alpha-synuclein lewy body DBS deep brain stimulation medication L-dopa|vi=Parkinson,Parkinson disease|en=Parkinson disease`},
		{"NEURO2_EPILEPSY",     3,`label=động kinh|desc=epilepsy seizure EEG temporal lobe generalized absence tonic-clonic anti-seizure medication surgery ketogenic diet|vi=động kinh,epilepsy|en=epilepsy`},
		{"NEURO2_HEADACHE",     3,`label=đau đầu và đau nửa đầu|desc=headache migraine aura CGRP triptan preventive cluster tension-type cortical spreading depression|vi=đau đầu và đau nửa đầu,migraine headache|en=migraine headache`},

		// ── CARDIOLOGY (CARDIO_) ─────────────────────────────────────
		{"CARDIO_HEART_FAILURE",3,`label=suy tim|desc=heart failure HFrEF HFpEF ejection fraction BNP diuretic ACEi ARNI SGLT2 device therapy cardiac rehab|vi=suy tim,heart failure|en=heart failure`},
		{"CARDIO_ARRHYTHMIA",   3,`label=rối loạn nhịp tim|desc=arrhythmia AFib flutter VT VF ablation cardioversion ICD pacemaker ion channel Holter Holter ECG|vi=rối loạn nhịp tim,arrhythmia|en=arrhythmia`},
		{"CARDIO_ATHEROSCLER",  3,`label=xơ vữa động mạch|desc=atherosclerosis LDL oxidized foam cell plaque rupture statin inflammation hsCRP PCSK9 lipid lowering|vi=xơ vữa động mạch,atherosclerosis|en=atherosclerosis`},
		{"CARDIO_IMAGING",      3,`label=hình ảnh tim mạch|desc=cardiac imaging echocardiography CT angiography MRI nuclear SPECT PET wall motion fractional flow reserve|vi=hình ảnh tim mạch,cardiac imaging|en=cardiac imaging`},
		{"CARDIO_PREVENTION",   3,`label=phòng ngừa tim mạch|desc=cardiovascular prevention ASCVD risk score blood pressure LDL smoking cessation exercise Mediterranean diet|vi=phòng ngừa tim mạch,cardiovascular prevention|en=cardiovascular prevention`},

		// ── TEXTILE & FASHION (TEXTILE_ / FASHION3_) ─────────────────
		{"TEXTILE_NATURAL",     3,`label=sợi tự nhiên|desc=natural fiber cotton linen silk wool cashmere hemp bamboo properties weaving dyeing sustainability traceability|vi=sợi tự nhiên,natural fiber|en=natural fiber`},
		{"TEXTILE_TECHNICAL",   3,`label=vải kỹ thuật cao|desc=technical textile Gore-Tex Kevlar Nomex aerogel conductive e-textile smart wearable medical protective|vi=vải kỹ thuật cao,technical textile|en=technical textile`},
		{"FASHION3_SUSTAIN",    3,`label=thời trang bền vững|desc=sustainable fashion circular economy slow fashion swap repair upcycle deadstock organic dye supply chain transparency|vi=thời trang bền vững,sustainable fashion|en=sustainable fashion`},
		{"FASHION3_HISTORY",    3,`label=lịch sử thời trang|desc=fashion history Worth Chanel Dior New Look 1947 Yves Saint Laurent deconstruction Westwood Kawakubo zeitgeist|vi=lịch sử thời trang,fashion history|en=fashion history`},
		{"FASHION3_IDENTITY",   3,`label=thời trang và bản sắc|desc=fashion identity subcultural punk goth streetwear hypebeast drop culture K-fashion Harajuku Áo dài quốc phục|vi=thời trang và bản sắc,fashion identity|en=fashion identity`},

		// ── INTERIOR DESIGN (INTERIOR_) ──────────────────────────────
		{"INTERIOR_BIOPHILIC",  3,`label=thiết kế sinh thái nội thất|desc=biophilic design living wall indoor plant natural light material wood stone view nature stress reduction|vi=thiết kế sinh thái nội thất,biophilic design|en=biophilic design`},
		{"INTERIOR_LIGHTING",   3,`label=chiếu sáng nội thất|desc=interior lighting circadian tunable white CCT CRI lux lumens task ambient accent layering glare|vi=chiếu sáng nội thất,interior lighting|en=interior lighting`},
		{"INTERIOR_SMALL",      3,`label=tối ưu không gian nhỏ|desc=small space design multifunctional fold Murphy bed loft mezzanine mirror built-in storage micro apartment|vi=tối ưu không gian nhỏ,small space design|en=small space design`},
		{"INTERIOR_ACOUSTIC",   3,`label=âm học nội thất|desc=interior acoustics RT60 absorption diffusion reflection NRC panel curtain carpet noise reduction speech clarity|vi=âm học nội thất,interior acoustics|en=interior acoustics`},
		{"INTERIOR_VNSTYLE",    3,`label=phong cách nội thất Việt Nam|desc=nội thất Việt Nam truyền thống hiện đại gỗ sơn mài đồ thủ công lacquer bamboo rattan fusion Đông Tây|vi=phong cách nội thất Việt Nam,Vietnamese interior|en=Vietnamese interior design`},

		// ── ENDOCRINOLOGY (ENDOCRIN_) ─────────────────────────────────
		{"ENDOCRIN_DIABETES",   3,`label=đái tháo đường|desc=diabetes mellitus type 1 2 insulin resistance beta cell HbA1c GLP-1 SGLT2 continuous glucose monitor CGM|vi=đái tháo đường,diabetes|en=diabetes`},
		{"ENDOCRIN_THYROID",    3,`label=tuyến giáp|desc=thyroid gland T3 T4 TSH hypothyroid hyperthyroid Hashimoto Graves goiter ultrasound FNA levothyroxine|vi=tuyến giáp,thyroid|en=thyroid`},
		{"ENDOCRIN_ADRENAL",    3,`label=tuyến thượng thận|desc=adrenal gland cortisol aldosterone ACTH cortisol Cushing Addison stress axis HPA pheochromocytoma|vi=tuyến thượng thận,adrenal gland|en=adrenal gland`},
		{"ENDOCRIN_REPRO",      3,`label=nội tiết sinh sản|desc=reproductive endocrinology HPG axis GnRH LH FSH estrogen progesterone testosterone PCOS IVF fertility|vi=nội tiết sinh sản,reproductive endocrinology|en=reproductive endocrinology`},
		{"ENDOCRIN_BONE",       3,`label=chuyển hóa xương|desc=bone metabolism osteoblast osteoclast PTH vitamin D calcium phosphate osteoporosis DEXA bisphosphonate|vi=chuyển hóa xương,bone metabolism|en=bone metabolism`},
	}

	added, skipped := 0, 0
	for _, n := range nodes {
		if ex[n.name] { skipped++; continue }
		islv := nodeISL(n.name, n.layer)
		raw = insertNode(raw, buildRecord(n.layer, islv, []byte(n.dna), n.name))
		ex[n.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3900 { fmt.Println(" MILESTONE 3900! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
