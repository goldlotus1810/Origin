//go:build ignore
// go run scripts/seed_wild_stat.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── THIÊN NHIÊN HOANG DÃ / BẢO TỒN ──────────────────────
		{"WILD_RAINFOREST",  3, `label=rừng nhiệt đới|desc=hệ sinh thái rừng mưa nhiệt đới giàu đa dạng sinh học nhất Trái Đất Amazon Congo Borneo|vi=rừng nhiệt đới,rainforest|en=rainforest,tropical forest|zh=热带雨林`},
		{"WILD_CORAL",       3, `label=rạn san hô|desc=hệ sinh thái biển phong phú nhất được tạo bởi san hô rạn Great Barrier Reef dễ bị tổn thương|vi=rạn san hô,coral reef|en=coral reef|zh=珊瑚礁`},
		{"WILD_MIGRATION",   3, `label=di cư động vật|desc=hành vi di chuyển theo mùa của động vật đến vùng khác để kiếm ăn sinh sản chim chim thiên nga cá hồi|vi=di cư động vật,migration|en=animal migration|zh=动物迁徙`},
		{"WILD_EXTINCTION",  3, `label=tuyệt chủng|desc=sự biến mất vĩnh viễn của một loài sinh vật khỏi Trái Đất khủng long dodo thylacine|vi=tuyệt chủng,extinction|en=extinction|zh=灭绝`},
		{"WILD_CONSERVATION",3, `label=bảo tồn thiên nhiên|desc=nỗ lực bảo vệ và phục hồi hệ sinh thái và các loài bị đe dọa khu bảo tồn vườn quốc gia|vi=bảo tồn thiên nhiên,conservation|en=conservation,nature conservation|zh=自然保护`},
		{"WILD_PREDATOR",    3, `label=động vật săn mồi|desc=sinh vật đứng đầu chuỗi thức ăn sư tử hổ cá mập đại bàng kiểm soát quần thể con mồi|vi=động vật săn mồi,predator|en=predator,apex predator|zh=捕食者`},
		{"WILD_ECOSYSTEM",   3, `label=hệ sinh thái|desc=cộng đồng sinh vật tương tác với môi trường vô sinh đất nước không khí rừng đại dương đồng cỏ|vi=hệ sinh thái,ecosystem|en=ecosystem|zh=生态系统`},
		{"WILD_PHOTOSYN",    3, `label=quang hợp|desc=quá trình thực vật chuyển đổi ánh sáng CO2 và nước thành glucose và oxy nền tảng chuỗi thức ăn|vi=quang hợp,photosynthesis|en=photosynthesis|zh=光合作用`},
		{"WILD_POLLINATION", 3, `label=thụ phấn|desc=quá trình chuyển phấn hoa từ nhị đến nhụy cần thiết cho sinh sản thực vật ong bướm gió|vi=thụ phấn,pollination|en=pollination|zh=授粉`},
		{"WILD_FOOD_CHAIN",  3, `label=chuỗi thức ăn|desc=dãy sinh vật mỗi loài ăn loài trước thực vật→ăn cỏ→ăn thịt chuyển hóa năng lượng qua các bậc|vi=chuỗi thức ăn,food chain|en=food chain|zh=食物链`},

		// ── TOÁN ỨNG DỤNG / THỐNG KÊ ─────────────────────────────
		{"STAT_PROBABILITY", 3, `label=xác suất|desc=thước đo khả năng xảy ra của sự kiện từ 0 đến 1 nền tảng của thống kê và học máy|vi=xác suất,probability|en=probability|zh=概率`},
		{"STAT_NORMAL_DIST", 3, `label=phân phối chuẩn|desc=phân phối xác suất hình chuông đối xứng quanh trung bình phổ biến nhất trong tự nhiên|vi=phân phối chuẩn,normal distribution|en=normal distribution,Gaussian|zh=正态分布`},
		{"STAT_REGRESSION",  3, `label=hồi quy|desc=phương pháp thống kê dự đoán giá trị biến phụ thuộc từ biến độc lập hồi quy tuyến tính logistic|vi=hồi quy,regression|en=regression,linear regression|zh=回归`},
		{"STAT_BAYES",       3, `label=định lý Bayes|desc=quy tắc cập nhật xác suất khi có thêm bằng chứng mới P(A|B)=P(B|A)P(A)/P(B) nền tảng ML Bayesian|vi=Bayes,định lý Bayes,Bayes theorem|en=Bayes theorem,Bayesian|zh=贝叶斯定理`},
		{"STAT_HYPOTHESIS",  3, `label=kiểm định giả thuyết|desc=quy trình thống kê xác nhận hay bác bỏ giả thuyết p-value t-test ANOVA|vi=kiểm định giả thuyết,hypothesis testing|en=hypothesis testing,statistical test|zh=假设检验`},
		{"STAT_CORRELATION", 3, `label=tương quan|desc=mức độ liên hệ giữa hai biến số Pearson Spearman tương quan không có nghĩa nhân quả|vi=tương quan,correlation|en=correlation|zh=相关`},
		{"STAT_SAMPLING",    3, `label=lấy mẫu|desc=chọn tập con đại diện từ tổng thể để suy luận thống kê mẫu ngẫu nhiên phân tầng|vi=lấy mẫu,sampling|en=sampling|zh=采样`},
		{"STAT_BIG_DATA",    3, `label=dữ liệu lớn|desc=tập dữ liệu quá lớn để xử lý bằng phần mềm truyền thống 5V volume velocity variety veracity value|vi=dữ liệu lớn,big data|en=big data|zh=大数据`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Thiên nhiên nội bộ
		{"WILD_RAINFOREST",  "ENV_BIODIVERSITY", "supports"},
		{"WILD_CORAL",       "ENV_OCEAN_ACID",   "threatened-by"},
		{"WILD_EXTINCTION",  "ENV_BIODIVERSITY", "reduces"},
		{"WILD_CONSERVATION","ENV_BIODIVERSITY", "protects"},
		{"WILD_PREDATOR",    "WILD_FOOD_CHAIN",  "part-of"},
		{"WILD_PHOTOSYN",    "WILD_FOOD_CHAIN",  "starts"},
		{"WILD_POLLINATION", "BIO_PLANT",        "enables"},
		{"WILD_ECOSYSTEM",   "BIO_ECOSYSTEM",    "is-a"},
		{"WILD_FOOD_CHAIN",  "WILD_ECOSYSTEM",   "part-of"},
		{"WILD_PHOTOSYN",    "ENV_CARBON",       "absorbs"},
		{"WILD_RAINFOREST",  "ENV_CLIMATE_CHANGE","mitigates"},
		// Thống kê nội bộ
		{"STAT_PROBABILITY", "STAT_BAYES",       "used-in"},
		{"STAT_REGRESSION",  "STAT_PROBABILITY", "uses"},
		{"STAT_HYPOTHESIS",  "STAT_PROBABILITY", "based-on"},
		{"STAT_CORRELATION", "STAT_REGRESSION",  "related-to"},
		{"STAT_SAMPLING",    "STAT_HYPOTHESIS",  "enables"},
		{"STAT_BIG_DATA",    "STAT_SAMPLING",    "requires"},
		// Thống kê ↔ ML / Toán học
		{"STAT_PROBABILITY", "MATH_STATISTICS",  "is-a"},
		{"STAT_BAYES",       "TECH_ML",          "foundation-of"},
		{"STAT_REGRESSION",  "TECH_ML",          "technique-in"},
		{"STAT_NORMAL_DIST", "MATH_STATISTICS",  "is-a"},
		{"STAT_BIG_DATA",    "TECH_DATABASE",    "processed-by"},
		// Thiên nhiên ↔ Khoa học
		{"WILD_PHOTOSYN",    "CHEM_REACTION",    "is-a"},
		{"WILD_CORAL",       "GEO_OCEAN",        "lives-in"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-28s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"part-of":2,"supports":3,"threatened-by":4,"reduces":5,
		"protects":6,"starts":7,"enables":8,"absorbs":9,"mitigates":10,
		"used-in":11,"uses":12,"based-on":13,"related-to":14,"requires":15,
		"foundation-of":16,"technique-in":17,"processed-by":18,"lives-in":19,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
