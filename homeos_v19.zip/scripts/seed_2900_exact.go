//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	existing := readNames(raw)
	nodes := []Node{
		{"MEDIA_JOURNALISM",3,`label=báo chí|desc=journalism phóng viên điều tra tự do báo chí Fourth Estate watchdog chủ nghĩa khách quan|vi=báo chí,journalism|en=journalism|zh=新闻业`},
		{"MEDIA_PODCAST",   3,`label=podcast|desc=nội dung âm thanh trực tuyến Spotify Apple Podcasts NPR Serial Joe Rogan|vi=podcast|en=podcast|zh=播客`},
		{"MEDIA_STREAMING", 3,`label=streaming video|desc=Netflix Disney+ YouTube Prime Video nội dung số original series cord-cutting|vi=streaming,phát video trực tuyến|en=video streaming|zh=视频流媒体`},
		{"SPACE4_ARTEMIS",  3,`label=Artemis|desc=NASA chương trình quay lại Mặt Trăng 2024+ SLS Orion Gateway lunar station|vi=Artemis,chương trình Mặt Trăng|en=Artemis program|zh=阿尔忒弥斯计划`},
		{"SPACE4_STARSHIP", 3,`label=Starship|desc=SpaceX Elon Musk tên lửa lớn nhất lịch sử 120m tái sử dụng hoàn toàn sao Hỏa|vi=Starship,SpaceX|en=Starship|zh=星舰`},
		{"NEURO2_DOPAMINE", 3,`label=dopamine|desc=neurotransmitter phần thưởng động lực nghiện ngập Parkinson L-DOPA nucleus accumbens|vi=dopamine|en=dopamine|zh=多巴胺`},
		{"NEURO2_SEROTONIN",3,`label=serotonin|desc=neurotransmitter hạnh phúc tâm trạng SSRIs ruột brain-gut axis thiếu hụt trầm cảm|vi=serotonin|en=serotonin|zh=血清素`},
		{"NEURO2_CORTISOL", 3,`label=cortisol|desc=hormone stress cortex tuyến thượng thận fight-or-flight glucose metabolism chronic|vi=cortisol,hormone stress|en=cortisol|zh=皮质醇`},
		{"ECON3_CRYPTO",    3,`label=tiền mã hóa|desc=cryptocurrency Bitcoin Ethereum market cap volatility regulation SEC ETF 2024|vi=tiền mã hóa,cryptocurrency|en=cryptocurrency|zh=加密货币`},
		{"ECON3_INFLATION", 3,`label=lạm phát|desc=inflation CPI tăng giá tiêu dùng Fed lãi suất 2022 Ukraine energy food|vi=lạm phát,inflation|en=inflation|zh=通货膨胀`},
		{"ECON3_RECESSION", 3,`label=suy thoái kinh tế|desc=recession GDP giảm 2 quý liên tiếp thất nghiệp 2008 2020 COVID recovery|vi=suy thoái kinh tế,recession|en=recession|zh=经济衰退`},
		{"VN_SPORT_E",      3,`label=thể thao điện tử VN|desc=esports Việt Nam Liên Quân Mobile PUBG SEA Games huy chương vàng|vi=thể thao điện tử Việt Nam,esports VN|en=Vietnam esports|zh=越南电竞`},
		{"TECH5_QUANTUM_COM",3,`label=máy tính lượng tử|desc=quantum computer qubit superposition entanglement IBM Google D-Wave 1000+ qubit|vi=máy tính lượng tử,quantum computer|en=quantum computer|zh=量子计算机`},
	}
	added := 0
	for _, nd := range nodes {
		if existing[nd.name] { continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
		fmt.Printf("  + %-24s %q\n", nd.name, extractLabel(nd.dna))
	}
	fmt.Printf("\n+%d\n", added)
	h := sha256.Sum256(raw[layerIdxEnd:]); copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644); os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes\n", nn)
	if nn >= 2900 { fmt.Println("🎉 MILESTONE 2900!") }
}
func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
