//go:build ignore
// seed_milestone6100.go — MILESTONE 6100 — 100 nodes
// Chủ đề: AI/ML/DL sâu + Neuroscience + Cognitive Science
// Mục đích: SilkWalk trả lời tốt về AI, não bộ, nhận thức
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const fp6100    = "homeos.olang"
const li6100End = 64 + 9*24

func main() {
	raw, err := os.ReadFile(fp6100)
	if err != nil { log.Fatal(err) }
	fmt.Printf("▶ start: %d nodes\n", be32r(raw[12:16]))
	ex := readNames6100(raw)
	type nd struct{ name string; layer uint8; dna string }
	nodes := []nd{
		// ── MACHINE LEARNING CORE ──────────────────────────────────────────
		{"SUPERVISED_LEARNING",  3, `label=học có giám sát|desc=supervised learning labeled data input-output mapping regression classification gradient descent loss function training validation|vi=học có giám sát,supervised learning|en=supervised learning`},
		{"UNSUPERVISED_LEARNING",3, `label=học không giám sát|desc=unsupervised learning clustering dimensionality reduction PCA k-means GMM autoencoder latent representation|vi=học không giám sát,unsupervised learning|en=unsupervised learning`},
		{"REINFORCEMENT_LEARNING",3,`label=học tăng cường|desc=reinforcement learning agent environment reward policy Q-learning DQN PPO actor-critic Bellman equation exploration exploitation|vi=học tăng cường,reinforcement learning|en=reinforcement learning`},
		{"TRANSFER_LEARNING",    3, `label=học chuyển giao|desc=transfer learning pretrained models fine-tuning domain adaptation feature extraction ImageNet BERT GPT zero-shot few-shot|vi=học chuyển giao,transfer learning|en=transfer learning`},
		{"META_LEARNING",        3, `label=siêu học|desc=meta-learning learning to learn MAML prototypical networks few-shot adaptation task distribution inner outer loop|vi=siêu học,meta-learning|en=meta-learning`},
		{"SELF_SUPERVISED",      3, `label=học tự giám sát|desc=self-supervised learning contrastive SimCLR BYOL masked autoencoder BERT pretext task representation learning|vi=học tự giám sát,self-supervised learning|en=self-supervised learning`},
		{"FEDERATED_LEARNING",   3, `label=học liên kết|desc=federated learning distributed privacy-preserving local models aggregation FedAvg differential privacy edge devices|vi=học liên kết,federated learning|en=federated learning`},

		// ── DEEP LEARNING ARCHITECTURES ───────────────────────────────────
		{"TRANSFORMER",          3, `label=transformer|desc=transformer architecture attention is all you need multi-head attention encoder decoder positional encoding BERT GPT T5|vi=transformer|en=transformer`},
		{"ATTENTION_MECHANISM",  3, `label=cơ chế chú ý|desc=attention mechanism query key value softmax scaled dot-product self-attention cross-attention context window long-range dependency|vi=cơ chế chú ý,attention mechanism|en=attention mechanism`},
		{"CNN",                  3, `label=mạng tích chập|desc=convolutional neural network convolution pooling stride padding feature map receptive field AlexNet VGG ResNet|vi=mạng tích chập,CNN,convolutional network|en=convolutional neural network`},
		{"RNN",                  3, `label=mạng hồi quy|desc=recurrent neural network sequential data hidden state LSTM GRU vanishing gradient time series language modeling|vi=mạng hồi quy,RNN,recurrent network|en=recurrent neural network`},
		{"GAN",                  3, `label=mạng sinh đối nghịch|desc=generative adversarial network generator discriminator minimax game mode collapse training instability StyleGAN DCGAN deepfake|vi=mạng sinh đối nghịch,GAN|en=generative adversarial network`},
		{"VAE",                  3, `label=autoencoder biến phân|desc=variational autoencoder encoder decoder latent space reparameterization KL divergence reconstruction loss generative model|vi=autoencoder biến phân,VAE|en=variational autoencoder`},
		{"DIFFUSION_MODEL",      3, `label=mô hình khuếch tán|desc=diffusion model denoising score matching DDPM noise schedule reverse process Stable Diffusion DALL-E image generation|vi=mô hình khuếch tán,diffusion model|en=diffusion model`},
		{"GRAPH_NEURAL_NET",     3, `label=mạng nơ-ron đồ thị|desc=graph neural network node classification link prediction GCN GraphSAGE GAT message passing molecular property prediction|vi=mạng nơ-ron đồ thị,GNN|en=graph neural network`},

		// ── LARGE LANGUAGE MODELS ─────────────────────────────────────────
		{"LLM",                  3, `label=mô hình ngôn ngữ lớn|desc=large language model GPT BERT LLaMA Claude pretraining fine-tuning RLHF scaling law emergent capability instruction following|vi=mô hình ngôn ngữ lớn,LLM|en=large language model`},
		{"PROMPT_ENGINEERING",   3, `label=kỹ thuật nhắc|desc=prompt engineering chain-of-thought few-shot zero-shot system prompt instruction tuning jailbreak adversarial prompting|vi=kỹ thuật nhắc,prompt engineering|en=prompt engineering`},
		{"RLHF",                 3, `label=học tăng cường từ phản hồi người|desc=reinforcement learning human feedback reward model preference data InstructGPT ChatGPT alignment Constitutional AI|vi=học tăng cường từ phản hồi người,RLHF|en=reinforcement learning from human feedback`},
		{"RAG",                  3, `label=sinh tăng cường truy xuất|desc=retrieval augmented generation vector database embedding similarity search grounding hallucination reduction context injection|vi=sinh tăng cường truy xuất,RAG|en=retrieval augmented generation`},
		{"HALLUCINATION",        3, `label=ảo giác AI|desc=hallucination confabulation factual errors LLM overconfidence knowledge boundary calibration grounding verification|vi=ảo giác AI,hallucination|en=AI hallucination`},
		{"ALIGNMENT",            3, `label=điều chỉnh AI|desc=AI alignment value alignment reward hacking specification gaming Goodhart law corrigibility shutdown problem mesa-optimizer|vi=điều chỉnh AI,AI alignment|en=AI alignment`},
		{"EMERGENT_ABILITIES",   3, `label=khả năng nổi sinh|desc=emergent abilities scale phase transition in-context learning chain of thought arithmetic reasoning few-shot BIG-bench|vi=khả năng nổi sinh,emergent abilities|en=emergent abilities`},

		// ── OPTIMIZATION & TRAINING ───────────────────────────────────────
		{"GRADIENT_DESCENT",     3, `label=giảm gradient|desc=gradient descent SGD Adam AdamW momentum learning rate schedule warm-up cosine annealing batch size convergence|vi=giảm gradient,gradient descent|en=gradient descent`},
		{"BACKPROPAGATION",      3, `label=lan truyền ngược|desc=backpropagation chain rule automatic differentiation computational graph Rumelhart Hinton Williams credit assignment|vi=lan truyền ngược,backpropagation|en=backpropagation`},
		{"REGULARIZATION",       3, `label=chính quy hóa|desc=regularization overfitting dropout L1 L2 weight decay batch normalization early stopping data augmentation generalization|vi=chính quy hóa,regularization|en=regularization`},
		{"LOSS_FUNCTION",        3, `label=hàm mất mát|desc=loss function cross-entropy MSE KL divergence contrastive hinge focal ELBO reward shaping optimization objective|vi=hàm mất mát,loss function|en=loss function`},
		{"HYPERPARAMETER",       3, `label=siêu tham số|desc=hyperparameter tuning learning rate batch size epochs architecture search Bayesian optimization NAS random search grid search|vi=siêu tham số,hyperparameter|en=hyperparameter`},
		{"SCALING_LAW",          3, `label=quy luật tỷ lệ|desc=scaling law Chinchilla compute-optimal parameters data tokens power law neural network performance Kaplan Hoffmann|vi=quy luật tỷ lệ,scaling law|en=neural scaling law`},

		// ── REPRESENTATION LEARNING ───────────────────────────────────────
		{"EMBEDDING",            3, `label=nhúng vector|desc=embedding word2vec GloVe sentence embedding semantic similarity dense retrieval high-dimensional space cosine similarity|vi=nhúng vector,embedding|en=vector embedding`},
		{"LATENT_SPACE",         3, `label=không gian tiềm ẩn|desc=latent space representation disentanglement interpolation manifold hypothesis generative model compression feature|vi=không gian tiềm ẩn,latent space|en=latent space`},
		{"FEATURE_ENGINEERING",  3, `label=kỹ thuật đặc trưng|desc=feature engineering selection extraction normalization one-hot encoding imputation domain knowledge handcrafted vs learned|vi=kỹ thuật đặc trưng,feature engineering|en=feature engineering`},
		{"CONTRASTIVE_LEARNING", 3, `label=học đối chiếu|desc=contrastive learning SimCLR MoCo positive negative pairs InfoNCE loss temperature representation uniformity alignment|vi=học đối chiếu,contrastive learning|en=contrastive learning`},

		// ── AI SAFETY & INTERPRETABILITY ──────────────────────────────────
		{"INTERPRETABILITY",     3, `label=khả năng giải thích|desc=interpretability explainability SHAP LIME attention visualization saliency map mechanistic probing feature attribution|vi=khả năng giải thích,interpretability|en=AI interpretability`},
		{"ROBUSTNESS",           3, `label=tính bền vững|desc=robustness adversarial examples distribution shift out-of-distribution generalization certified defense input perturbation Carlini Wagner|vi=tính bền vững,robustness|en=model robustness`},
		{"FAIRNESS_ML",          3, `label=công bằng ML|desc=fairness machine learning bias demographic parity equalized odds disparate impact proxy feature debiasing audit|vi=công bằng ML,ML fairness|en=ML fairness`},
		{"SAFETY_AI",            3, `label=an toàn AI|desc=AI safety existential risk superintelligence instrumental convergence paperclip maximizer MIRI Anthropic OpenAI alignment research|vi=an toàn AI,AI safety|en=AI safety`},

		// ── NEUROSCIENCE FUNDAMENTALS ─────────────────────────────────────
		{"NEURON",               3, `label=tế bào thần kinh|desc=neuron soma axon dendrite synapse action potential myelin Hodgkin-Huxley model resting potential depolarization|vi=tế bào thần kinh,neuron|en=neuron`},
		{"SYNAPSE",              3, `label=khớp thần kinh|desc=synapse neurotransmitter receptor presynaptic postsynaptic GABA glutamate dopamine LTP LTD plasticity Hebb|vi=khớp thần kinh,synapse|en=synapse`},
		{"NEUROPLASTICITY",      3, `label=tính dẻo thần kinh|desc=neuroplasticity LTP LTD Hebbian learning synaptic pruning critical period adult neurogenesis recovery cortical remapping|vi=tính dẻo thần kinh,neuroplasticity|en=neuroplasticity`},
		{"CEREBRAL_CORTEX",      3, `label=vỏ não|desc=cerebral cortex frontal parietal temporal occipital primary sensory motor association cortex columns layers Brodmann areas|vi=vỏ não,cerebral cortex|en=cerebral cortex`},
		{"HIPPOCAMPUS",          3, `label=hải mã|desc=hippocampus memory consolidation spatial navigation place cells grid cells HM patient declarative memory encoding retrieval|vi=hải mã,hippocampus|en=hippocampus`},
		{"PREFRONTAL_CORTEX",    3, `label=vỏ não trán trước|desc=prefrontal cortex executive function working memory decision making inhibition planning theory of mind DLPFC OFC|vi=vỏ não trán trước,prefrontal cortex|en=prefrontal cortex`},
		{"AMYGDALA",             3, `label=hạch hạnh nhân|desc=amygdala fear conditioning emotional memory threat detection Klüver-Bucy syndrome anxiety PTSD basolateral central nucleus|vi=hạch hạnh nhân,amygdala|en=amygdala`},
		{"BASAL_GANGLIA",        3, `label=hạch nền|desc=basal ganglia striatum caudate putamen nucleus accumbens dopamine reward learning habit motor control Parkinson|vi=hạch nền,basal ganglia|en=basal ganglia`},
		{"CEREBELLUM",           3, `label=tiểu não|desc=cerebellum motor coordination timing balance proprioception Purkinje cells granule cells climbing fibers mossy fibers motor learning|vi=tiểu não,cerebellum|en=cerebellum`},
		{"BRAINSTEM",            3, `label=thân não|desc=brainstem medulla pons midbrain reticular formation vital functions breathing heartbeat sleep arousal cranial nerves|vi=thân não,brainstem|en=brainstem`},

		// ── NEUROTRANSMITTERS ─────────────────────────────────────────────
		{"DOPAMINE",             3, `label=dopamine|desc=dopamine reward prediction error motivation salience ventral tegmental area nucleus accumbens Parkinson addiction reinforcement|vi=dopamine|en=dopamine`},
		{"SEROTONIN",            3, `label=serotonin|desc=serotonin mood regulation raphe nuclei SSRIs depression anxiety gut-brain axis sleep appetite social behavior|vi=serotonin|en=serotonin`},
		{"ACETYLCHOLINE",        3, `label=acetylcholine|desc=acetylcholine motor neuron attention memory Alzheimer cholinergic system nicotinic muscarinic NMJ basal forebrain|vi=acetylcholine|en=acetylcholine`},
		{"NOREPINEPHRINE",       3, `label=norepinephrine|desc=norepinephrine locus coeruleus arousal attention stress fight-or-flight sympathetic nervous system blood pressure|vi=norepinephrine|en=norepinephrine`},
		{"GABA_NEURO",           3, `label=GABA|desc=GABA gamma-aminobutyric acid inhibitory neurotransmitter anxiolytics benzodiazepines inhibitory interneurons balance excitation|vi=GABA|en=GABA`},

		// ── COGNITIVE SCIENCE ─────────────────────────────────────────────
		{"WORKING_MEMORY",       3, `label=bộ nhớ làm việc|desc=working memory Baddeley phonological loop visuospatial sketchpad central executive capacity limits Miller 7 cognitive load|vi=bộ nhớ làm việc,working memory|en=working memory`},
		{"LONG_TERM_MEMORY",     3, `label=bộ nhớ dài hạn|desc=long-term memory declarative episodic semantic procedural implicit explicit consolidation retrieval reconsolidation|vi=bộ nhớ dài hạn,long-term memory|en=long-term memory`},
		{"COGNITIVE_BIAS",       3, `label=thiên kiến nhận thức|desc=cognitive bias confirmation bias anchoring availability heuristic Kahneman Tversky framing effect hindsight|vi=thiên kiến nhận thức,cognitive bias|en=cognitive bias`},
		{"PERCEPTION",           3, `label=tri giác|desc=perception bottom-up top-down Gestalt figure-ground binding problem multisensory integration predictive coding Bayesian brain|vi=tri giác,perception|en=perception`},
		{"ATTENTION_COG",        3, `label=chú ý|desc=attention selective focused divided sustained spotlight cocktail party effect Posner cueing inattentional blindness change blindness|vi=chú ý,attention|en=cognitive attention`},
		{"EXECUTIVE_FUNCTION",   3, `label=chức năng điều hành|desc=executive function inhibition updating shifting cognitive flexibility planning goal-directed behavior frontal lobe prefrontal|vi=chức năng điều hành,executive function|en=executive function`},
		{"DECISION_MAKING",      3, `label=ra quyết định|desc=decision making prospect theory Kahneman dual process System 1 System 2 heuristics biases expected utility rationality|vi=ra quyết định,decision making|en=decision making`},
		{"LANGUAGE_COGNITION",   3, `label=ngôn ngữ và nhận thức|desc=language cognition Broca Wernicke area grammar acquisition Chomsky universal grammar embodied cognition|vi=ngôn ngữ và nhận thức,language cognition|en=language and cognition`},
		{"EMOTION_COG",          3, `label=cảm xúc|desc=emotion Ekman basic emotions appraisal theory James-Lange somatic marker Damasio limbic system affective computing|vi=cảm xúc,emotion|en=emotion cognition`},
		{"CONSCIOUSNESS_COG",    3, `label=ý thức|desc=consciousness global workspace theory integrated information Tononi IIT phi neural correlates Crick Koch binding problem hard problem|vi=ý thức,consciousness cognitive|en=cognitive consciousness`},

		// ── COMPUTATIONAL NEUROSCIENCE ────────────────────────────────────
		{"NEURAL_CODING",        3, `label=mã hóa thần kinh|desc=neural coding rate coding temporal coding population coding place cells grid cells sparse coding efficient coding|vi=mã hóa thần kinh,neural coding|en=neural coding`},
		{"PREDICTIVE_CODING",    3, `label=mã hóa dự đoán|desc=predictive coding Helmholtz Friston free energy principle prediction error top-down expectation bottom-up surprise|vi=mã hóa dự đoán,predictive coding|en=predictive coding`},
		{"HEBBIAN_LEARNING",     3, `label=học Hebbian|desc=Hebbian learning cells that fire together wire together LTP Hebb rule synaptic plasticity correlation unsupervised|vi=học Hebbian,Hebbian learning|en=Hebbian learning`},
		{"SPIKING_NEURAL_NET",   3, `label=mạng nơ-ron xung|desc=spiking neural network third generation integrate-and-fire STDP temporal coding neuromorphic Intel Loihi IBM TrueNorth|vi=mạng nơ-ron xung,SNN|en=spiking neural network`},
		{"NEURAL_OSCILLATION",   3, `label=dao động thần kinh|desc=neural oscillation alpha beta gamma theta delta EEG synchrony binding brain rhythms sleep wave cognitive function|vi=dao động thần kinh,neural oscillation|en=neural oscillation`},

		// ── AI & BRAIN CONNECTIONS ────────────────────────────────────────
		{"NEUROMORPHIC",         3, `label=điện toán thần kinh hình thái|desc=neuromorphic computing brain-inspired hardware Intel Loihi IBM TrueNorth analog spike-based energy efficient edge|vi=điện toán thần kinh hình thái,neuromorphic|en=neuromorphic computing`},
		{"BCI",                  3, `label=giao diện não-máy tính|desc=brain-computer interface EEG ECoG Utah array Neuralink BrainGate motor imagery P300 speller locked-in|vi=giao diện não-máy tính,BCI|en=brain-computer interface`},
		{"COGNITIVE_ARCHITECTURE",3,`label=kiến trúc nhận thức|desc=cognitive architecture ACT-R SOAR global workspace unified theory of mind production rules declarative procedural memory|vi=kiến trúc nhận thức,cognitive architecture|en=cognitive architecture`},
		{"AGI",                  3, `label=trí tuệ tổng quát nhân tạo|desc=artificial general intelligence human-level AI capability breadth transfer reasoning common sense planning Turing test|vi=trí tuệ tổng quát nhân tạo,AGI|en=artificial general intelligence`},
		{"EMBODIED_AI",          3, `label=AI thể hiện|desc=embodied AI robotics sensorimotor loop environment interaction situated cognition enactivism morphological computation|vi=AI thể hiện,embodied AI|en=embodied AI`},

		// ── DATA SCIENCE ──────────────────────────────────────────────────
		{"STATISTICAL_LEARNING", 3, `label=học thống kê|desc=statistical learning theory VC dimension Rademacher complexity PAC learning bias-variance tradeoff generalization bound|vi=học thống kê,statistical learning|en=statistical learning`},
		{"BAYESIAN_ML",          3, `label=học Bayes|desc=Bayesian machine learning prior posterior likelihood MCMC variational inference Gaussian process uncertainty quantification|vi=học Bayes,Bayesian ML|en=Bayesian machine learning`},
		{"ENSEMBLE_METHOD",      3, `label=phương pháp tập hợp|desc=ensemble method bagging boosting random forest gradient boosting XGBoost stacking diversity variance reduction|vi=phương pháp tập hợp,ensemble method|en=ensemble method`},
		{"DIMENSIONALITY",       3, `label=giảm chiều|desc=dimensionality reduction PCA t-SNE UMAP autoencoders manifold learning curse of dimensionality feature selection|vi=giảm chiều,dimensionality reduction|en=dimensionality reduction`},
		{"ANOMALY_DETECTION",    3, `label=phát hiện bất thường|desc=anomaly detection outlier isolation forest autoencoder one-class SVM statistical threshold fraud detection cybersecurity|vi=phát hiện bất thường,anomaly detection|en=anomaly detection`},
		{"TIME_SERIES_ML",       3, `label=chuỗi thời gian ML|desc=time series machine learning LSTM temporal convolutional network N-BEATS forecasting seasonality trend decomposition|vi=chuỗi thời gian ML,time series ML|en=time series machine learning`},
		{"NLP",                  3, `label=xử lý ngôn ngữ tự nhiên|desc=natural language processing tokenization POS tagging NER parsing sentiment analysis machine translation question answering|vi=xử lý ngôn ngữ tự nhiên,NLP|en=natural language processing`},
		{"COMPUTER_VISION",      3, `label=thị giác máy tính|desc=computer vision image classification detection segmentation tracking optical flow depth estimation stereo 3D reconstruction|vi=thị giác máy tính,computer vision|en=computer vision`},
		{"MULTIMODAL_AI",        3, `label=AI đa phương thức|desc=multimodal AI vision-language CLIP DALL-E Flamingo visual question answering image captioning audio-visual cross-modal|vi=AI đa phương thức,multimodal AI|en=multimodal AI`},

		// ── SYSTEMS & INFRASTRUCTURE ──────────────────────────────────────
		{"GPU_COMPUTING",        3, `label=điện toán GPU|desc=GPU computing CUDA parallel computation tensor operations NVIDIA deep learning accelerator TPU distributed training|vi=điện toán GPU,GPU computing|en=GPU computing`},
		{"DISTRIBUTED_TRAINING", 3, `label=huấn luyện phân tán|desc=distributed training data parallelism model parallelism pipeline gradient communication AllReduce Megatron Deepspeed|vi=huấn luyện phân tán,distributed training|en=distributed training`},
		{"MODEL_COMPRESSION",    3, `label=nén mô hình|desc=model compression pruning quantization INT8 knowledge distillation weight sharing TinyML edge deployment efficient inference|vi=nén mô hình,model compression|en=model compression`},
		{"MLOPS",                3, `label=MLOps|desc=MLOps machine learning operations CI/CD model versioning experiment tracking data versioning monitoring drift detection deployment|vi=MLOps|en=MLOps`},

		// ── SPECIAL TOPICS ────────────────────────────────────────────────
		{"CAUSALITY_ML",         3, `label=nhân quả trong ML|desc=causality machine learning Pearl do-calculus intervention counterfactual Judea Pearl causal graph backdoor criterion|vi=nhân quả trong ML,causality ML|en=causal machine learning`},
		{"WORLD_MODEL",          3, `label=mô hình thế giới|desc=world model internal simulation Dreamer RSSM model-based RL mental simulation prediction planning Yann LeCun|vi=mô hình thế giới,world model|en=world model`},
		{"MEMORY_ARCHITECTURE",  3, `label=kiến trúc bộ nhớ|desc=memory architecture external memory neural Turing machine differentiable memory content-addressable LSTM working memory|vi=kiến trúc bộ nhớ,memory architecture|en=memory architecture AI`},
		{"ACTIVE_LEARNING",      3, `label=học chủ động|desc=active learning query strategy uncertainty sampling diversity human-in-the-loop annotation labeling efficiency pool-based|vi=học chủ động,active learning|en=active learning`},
		{"CONTINUAL_LEARNING",   3, `label=học liên tục|desc=continual learning catastrophic forgetting EWC progressive neural network replay memory lifelong learning task incremental|vi=học liên tục,continual learning|en=continual learning`},
		{"SYMBOLIC_AI",          3, `label=AI tượng trưng|desc=symbolic AI logic rules knowledge representation ontology reasoning GOFAI expert system neuro-symbolic integration|vi=AI tượng trưng,symbolic AI|en=symbolic AI`},
		{"NEUROSYMBOLIC",        3, `label=AI thần kinh-tượng trưng|desc=neuro-symbolic AI combining neural networks symbolic reasoning DeepMind AlphaCode logic neural theorem proving|vi=AI thần kinh-tượng trưng,neuro-symbolic|en=neuro-symbolic AI`},
	}

	var added int
	var buf []byte
	for _, n := range nodes {
		if ex[n.name] {
			continue
		}
		buf = append(buf, encodeNode6100(n.name, n.layer, n.dna)...)
		added++
	}

	raw = append(raw, buf...)
	cnt := be32r(raw[12:16]) + uint32(added)
	binary.BigEndian.PutUint32(raw[12:16], cnt)
	h := sha256.Sum256(raw[li6100End:])
	copy(raw[32:64], h[:])

	if err := os.WriteFile(fp6100, raw, 0644); err != nil {
		log.Fatal(err)
	}
	fmt.Printf("✅ added %d nodes → total %d\n", added, cnt)
}

func encodeNode6100(name string, layer uint8, dna string) []byte {
	nb := []byte(name)
	db := []byte(dna)
	dnaLen := uint32(len(db))
	size := 2 + 1 + 8 + 4 + 4 + 1 + len(nb) + len(db)
	buf := make([]byte, 0, size)
	buf = append(buf, 'N', 'D')
	buf = append(buf, layer)
	// ISL 8 bytes: derive từ sha256(name)
	h := sha256.Sum256(nb)
	buf = append(buf, h[:8]...)
	// codepoint 4 bytes
	buf = append(buf, h[8:12]...)
	// dnaLen 4 bytes BE
	buf = append(buf, byte(dnaLen>>24), byte(dnaLen>>16), byte(dnaLen>>8), byte(dnaLen))
	// nameLen 1 byte
	buf = append(buf, byte(len(nb)))
	buf = append(buf, db...)   // dna trước
	buf = append(buf, nb...)   // name sau
	return buf
}

func be32r(b []byte) uint32 { return binary.BigEndian.Uint32(b) }

func readNames6100(raw []byte) map[string]bool {
	ex := map[string]bool{}
	// Format: ND(2)+layer(1)+isl(8)+flags(4)+dnaLen(4)+nameLen(1)+dna+name
	i := li6100End
	for i+20 < len(raw) {
		if raw[i] != 'N' || raw[i+1] != 'D' {
			i++
			continue
		}
		base := i
		i += 2 + 1 + 8 + 4 // skip ND+layer+isl+flags
		if i+5 >= len(raw) { break }
		dnaLen := int(binary.BigEndian.Uint32(raw[i : i+4])); i += 4
		nameLen := int(raw[i]); i++
		end := i + dnaLen + nameLen
		if end > len(raw) { i = base + 1; break }
		name := string(raw[i+dnaLen : end])
		ex[name] = true
		i = end
	}
	return ex
}
