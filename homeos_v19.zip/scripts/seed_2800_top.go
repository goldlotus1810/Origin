//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("start: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		{"ASIA2_INDIA",     3, `label=Ấn Độ|desc=1.4 tỷ dân nền kinh tế thứ 5 thế giới IT Bangalore Modi dân chủ lớn nhất không gian vũ trụ|vi=Ấn Độ,India|en=India|zh=印度`},
		{"ASIA2_KOREA",     3, `label=Hàn Quốc|desc=kinh tế 4 con rồng châu Á Samsung Hyundai K-pop K-drama Kpop chaebol|vi=Hàn Quốc,Korea|en=South Korea|zh=韩国`},
		{"ASIA2_TAIWAN",    3, `label=Đài Loan|desc=TSMC chip bán dẫn 90% chip tiên tiến toàn cầu căng thẳng Trung Quốc|vi=Đài Loan,Taiwan|en=Taiwan|zh=台湾`},
		{"ASIA2_AUSTRALIA", 3, `label=Australia|desc=lục địa đảo tài nguyên khoáng sản than đá iron ore kangaroo AUKUS|vi=Australia,Úc|en=Australia|zh=澳大利亚`},
		{"EU2_GERMANY",     3, `label=Đức|desc=kinh tế lớn nhất châu Âu kỹ thuật ô tô BMW Mercedes-Benz Volkswagen Siemens|vi=Đức,Germany|en=Germany|zh=德国`},
		{"EU2_FRANCE",      3, `label=Pháp|desc=cường quốc hạt nhân G7 thời trang Louis Vuitton Airbus nông nghiệp hạt nhân dân số|vi=Pháp,France|en=France|zh=法国`},
		{"EU2_UKRAINE",     3, `label=Ukraine|desc=chiến tranh Nga-Ukraine 2022 NATO EU lúa mì ngũ cốc vựa lúa châu Âu|vi=Ukraine|en=Ukraine|zh=乌克兰`},
		{"OCEAN2_CORAL",    3, `label=rạn san hô|desc=đa dạng sinh học biển Great Barrier Reef tẩy trắng nhiệt độ nước CO2 axit hóa|vi=rạn san hô,coral reef|en=coral reef|zh=珊瑚礁`},
		{"OCEAN2_TIDES",    3, `label=thủy triều|desc=lực hấp dẫn Mặt Trăng Mặt Trời nước lên xuống điện thủy triều năng lượng|vi=thủy triều,tides|en=tides|zh=潮汐`},
		{"CS2_CLOUD",       3, `label=điện toán đám mây|desc=cloud computing AWS Azure GCP IaaS PaaS SaaS scalability pay-as-you-go|vi=điện toán đám mây,cloud computing|en=cloud computing|zh=云计算`},
		{"CS2_IOT",         3, `label=Internet of Things|desc=IoT thiết bị kết nối cảm biến smart home MQTT edge computing 15 tỷ|vi=IoT,Internet of Things|en=IoT|zh=物联网`},
		{"CS2_EDGE",        3, `label=edge computing|desc=xử lý dữ liệu gần nguồn độ trễ thấp autonomous vehicle factory IoT|vi=edge computing,điện toán biên|en=edge computing|zh=边缘计算`},
		{"VNPOL_DOIMO",     3, `label=Đổi Mới|desc=cải cách kinh tế Việt Nam 1986 mở cửa thị trường FDI tăng trưởng GDP xóa đói giảm nghèo|vi=Đổi Mới,Doi Moi|en=Doi Moi reform|zh=越南革新开放`},
	}

	added := 0
	for _, nd := range nodes {
		if existing[nd.name] { continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true
		added++
		fmt.Printf("  + %-22s %q\n", nd.name, extractLabel(nd.dna))
	}
	fmt.Printf("\n+%d nodes\n", added)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2800 { fmt.Println("🎉 MILESTONE 2800!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
