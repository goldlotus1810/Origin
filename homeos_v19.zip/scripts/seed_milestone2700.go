//go:build ignore
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── KIẾN TRÚC & XÂY DỰNG (BUILD2_) ──────────────────────
		{"BUILD2_GOTHIC",     3, `label=kiến trúc Gothic|desc=phong cách kiến trúc Châu Âu 12-16 thế kỷ cung nhọn vòm bay trụ đỡ nhà thờ Đức Bà Paris|vi=kiến trúc Gothic,Gothic|en=Gothic architecture|zh=哥特式建筑`},
		{"BUILD2_MODERNISM",  3, `label=kiến trúc hiện đại|desc=phong cách thế kỷ 20 hình thức theo chức năng thép kính bê tông Le Corbusier Bauhaus|vi=kiến trúc hiện đại,modernism|en=modernist architecture|zh=现代主义建筑`},
		{"BUILD2_SKYSCRAPER", 3, `label=nhà chọc trời|desc=tòa nhà trên 150m Burj Khalifa 828m Empire State Building thép kính thang máy đô thị|vi=nhà chọc trời,skyscraper|en=skyscraper|zh=摩天大楼`},
		{"BUILD2_SUSTAINABLE",3, `label=kiến trúc bền vững|desc=công trình xanh LEED năng lượng mặt trời vật liệu tái chế BIM carbon neutral|vi=kiến trúc bền vững,green building|en=sustainable architecture|zh=可持续建筑`},

		// ── KHOA HỌC THỰC PHẨM (FOODSCI_) ────────────────────────
		{"FOODSCI_FERMENT",   3, `label=lên men|desc=quá trình vi sinh vật phân giải đường thành cồn hoặc axit lactic yogurt bia rượu dưa cải|vi=lên men,fermentation|en=fermentation|zh=发酵`},
		{"FOODSCI_NUTRITION", 3, `label=dinh dưỡng học|desc=protein carbohydrate lipid vitamin khoáng chất macronutrient micronutrient chế độ ăn|vi=dinh dưỡng học,nutrition science|en=nutrition science|zh=营养科学`},
		{"FOODSCI_PRESERVATION",3,`label=bảo quản thực phẩm|desc=tiệt trùng Pasteur đóng hộp đông lạnh sấy khô chiếu xạ chất bảo quản|vi=bảo quản thực phẩm,food preservation|en=food preservation|zh=食品保藏`},
		{"FOODSCI_FOOD_SAFETY",3,`label=an toàn thực phẩm|desc=HACCP vệ sinh thực phẩm ngộ độc Salmonella E.coli kiểm tra chất lượng FDA|vi=an toàn thực phẩm,food safety|en=food safety|zh=食品安全`},

		// ── TÂM LÝ XÃ HỘI (SOCPSYCH_) ────────────────────────────
		{"SOCPSYCH_CONFORM",  3, `label=tính tuân thủ|desc=áp lực xã hội thay đổi hành vi Asch experiment groupthink đám đông chuẩn mực|vi=tính tuân thủ,conformity|en=conformity|zh=从众`},
		{"SOCPSYCH_PERSUADE", 3, `label=thuyết phục|desc=Cialdini 6 nguyên tắc có đi có lại khan hiếm uy quyền nhất quán thích quần chúng|vi=thuyết phục,persuasion|en=persuasion|zh=说服`},
		{"SOCPSYCH_PREJUDICE",3, `label=định kiến|desc=thái độ tiêu cực vô căn cứ về nhóm khác phân biệt đối xử implicit bias stereotype|vi=định kiến,prejudice|en=prejudice|zh=偏见`},
		{"SOCPSYCH_EMPATHY",  3, `label=đồng cảm|desc=khả năng hiểu cảm xúc người khác affective cognitive empathy mirror neurons|vi=đồng cảm,empathy|en=empathy|zh=共情`},

		// ── TÀI CHÍNH CÁ NHÂN (FINPERSONAL_) ─────────────────────
		{"FINPERSONAL_BUDGET",3, `label=ngân sách cá nhân|desc=quản lý thu chi tiết kiệm quy tắc 50-30-20 thu nhập chi phí đầu tư|vi=ngân sách cá nhân,budget|en=personal budget|zh=个人预算`},
		{"FINPERSONAL_INVEST",3, `label=đầu tư cá nhân|desc=cổ phiếu trái phiếu quỹ ETF bất động sản lãi kép Warren Buffett đa dạng hóa|vi=đầu tư cá nhân,investment|en=personal investment|zh=个人投资`},
		{"FINPERSONAL_RETIRE",3, `label=hưu trí|desc=tiết kiệm hưu trí 401k IRA lương hưu Social Security annuity quỹ hưu kế hoạch|vi=hưu trí,retirement|en=retirement|zh=退休`},
		{"FINPERSONAL_INSURE",3, `label=bảo hiểm|desc=phòng ngừa rủi ro y tế nhân thọ tài sản xe cộ premia phí bảo hiểm|vi=bảo hiểm,insurance|en=insurance|zh=保险`},

		// ── VĂN HÓA VIỆT NAM BỔ SUNG (VNCULTURE_) ────────────────
		{"VNCULTURE_TET",     3, `label=Tết Nguyên Đán|desc=tết cổ truyền lớn nhất Việt Nam âm lịch hoa đào mai bao lì xì thăm hỏi|vi=Tết Nguyên Đán,Tết|en=Vietnamese New Year,Tet|zh=越南春节`},
		{"VNCULTURE_AO_DAI",  3, `label=áo dài|desc=trang phục truyền thống Việt Nam dài tà lụa quốc phục nữ sinh UNESCO di sản|vi=áo dài|en=ao dai|zh=越南长衫`},
		{"VNCULTURE_BANH_CHUNG",3,`label=bánh chưng|desc=món ăn truyền thống Tết gạo nếp đậu xanh thịt lợn lá dong 4 góc vuông|vi=bánh chưng,bánh tét|en=banh chung|zh=粽子`},
		{"VNCULTURE_PHO",     3, `label=phở|desc=món súp nước dùng xương bò bánh phở thịt bò gà hành ngò gai đặc sản Hà Nội toàn thế giới|vi=phở|en=pho|zh=越南河粉`},

		// ── THIÊN VĂN CƠ BẢN (ASTRO4_) ──────────────────────────
		{"ASTRO4_PULSAR",     3, `label=pulsar|desc=sao neutron quay nhanh phát sóng radio đều đặn đồng hồ vũ trụ Jocelyn Bell 1967|vi=pulsar,sao xung|en=pulsar|zh=脉冲星`},
		{"ASTRO4_COMET",      3, `label=sao chổi|desc=thiên thể băng bụi đuôi sáng Halley Hale-Bopp vành đai Oort hệ Mặt Trời|vi=sao chổi,comet|en=comet|zh=彗星`},
		{"ASTRO4_DARK_MATTER",3, `label=vật chất tối|desc=27% vũ trụ không phát sáng giữ thiên hà WIMP axion LHC Rubin dark energy|vi=vật chất tối,dark matter|en=dark matter|zh=暗物质`},
		{"ASTRO4_DARK_ENERGY",3, `label=năng lượng tối|desc=68% vũ trụ đẩy nhanh giãn nở hằng số vũ trụ Λ cosmological constant Nobel 2011|vi=năng lượng tối,dark energy|en=dark energy|zh=暗能量`},

		// ── KHOA HỌC NHẬN THỨC MÁY (ML2_) ───────────────────────
		{"ML2_TRANSFORMER",   3, `label=Transformer|desc=kiến trúc self-attention Attention is All You Need Vaswani 2017 nền tảng GPT BERT|vi=Transformer,kiến trúc Transformer|en=Transformer architecture|zh=Transformer架构`},
		{"ML2_DIFFUSION",     3, `label=mô hình khuếch tán|desc=diffusion model DDPM Stable Diffusion DALL-E 2 Midjourney tạo ảnh AI|vi=mô hình khuếch tán,diffusion model|en=diffusion model|zh=扩散模型`},
		{"ML2_RAG",           3, `label=RAG|desc=Retrieval-Augmented Generation kết hợp retrieval LLM cơ sở tri thức hallucination|vi=RAG,retrieval augmented generation|en=RAG,Retrieval Augmented Generation|zh=检索增强生成`},
		{"ML2_FINETUNING",    3, `label=fine-tuning|desc=tinh chỉnh mô hình pretrained RLHF LoRA QLoRA PEFT dataset riêng|vi=fine-tuning,tinh chỉnh mô hình|en=fine-tuning|zh=微调`},
		{"ML2_MULTIMODAL",    3, `label=AI đa phương thức|desc=multimodal AI xử lý text hình ảnh âm thanh video GPT-4V Gemini|vi=AI đa phương thức,multimodal|en=multimodal AI|zh=多模态AI`},

		// ── LUẬT QUỐC TẾ (INTLAW_) ────────────────────────────────
		{"INTLAW_TREATIES",   3, `label=điều ước quốc tế|desc=hiệp ước thỏa thuận giữa các quốc gia ràng buộc pháp lý Vienna Convention|vi=điều ước quốc tế,treaty|en=international treaty|zh=国际条约`},
		{"INTLAW_ICC",        3, `label=Tòa án Hình sự Quốc tế|desc=ICC xét xử tội ác chiến tranh diệt chủng chống nhân loại Rome Statute 2002|vi=Tòa án Hình sự Quốc tế,ICC|en=ICC,International Criminal Court|zh=国际刑事法院`},
		{"INTLAW_MARITIME",   3, `label=luật biển|desc=UNCLOS vùng đặc quyền kinh tế EEZ thềm lục địa tranh chấp biển Đông|vi=luật biển,maritime law|en=maritime law|zh=海洋法`},

		// ── GIÁO DỤC HIỆN ĐẠI (MODEDU_) ─────────────────────────
		{"MODEDU_ELEARNING",  3, `label=học trực tuyến|desc=e-learning Coursera edX Khan Academy MOOCs LMS Zoom hybrid flipped classroom|vi=học trực tuyến,e-learning|en=e-learning|zh=在线学习`},
		{"MODEDU_GAMIFICATION",3,`label=game hóa giáo dục|desc=gamification points badges leaderboard Duolingo engagement học tập|vi=game hóa giáo dục,gamification|en=gamification in education|zh=游戏化学习`},
		{"MODEDU_MONTESSORI", 3, `label=phương pháp Montessori|desc=Maria Montessori tự học khám phá môi trường chuẩn bị tự do có kỷ luật|vi=Montessori,phương pháp Montessori|en=Montessori method|zh=蒙台梭利教育`},
		{"MODEDU_CRITICAL",   3, `label=tư duy phê phán|desc=critical thinking phân tích đánh giá lập luận logic fallacy Bloom's taxonomy|vi=tư duy phê phán,critical thinking|en=critical thinking|zh=批判性思维`},

		// ── KHOA HỌC DỮ LIỆU (DATASCI_) ─────────────────────────
		{"DATASCI_STATS",     3, `label=thống kê ứng dụng|desc=p-value hypothesis testing confidence interval regression ANOVA Bayesian inference|vi=thống kê ứng dụng,applied statistics|en=applied statistics|zh=应用统计学`},
		{"DATASCI_VISUAL",    3, `label=trực quan hóa dữ liệu|desc=data visualization Tableau D3.js matplotlib chart graph dashboard storytelling|vi=trực quan hóa dữ liệu,data visualization|en=data visualization|zh=数据可视化`},
		{"DATASCI_BIG_DATA",  3, `label=dữ liệu lớn|desc=Big Data 5V volume velocity variety veracity value Hadoop Spark NoSQL|vi=dữ liệu lớn,big data|en=big data|zh=大数据`},
		{"DATASCI_PIPELINE",  3, `label=data pipeline|desc=ETL ELT data engineering Airflow Spark ingestion transformation loading warehouse|vi=data pipeline,ETL|en=data pipeline|zh=数据管道`},

		// ── Y TẾ CỘNG ĐỒNG (PUBHEALTH2_) ─────────────────────────
		{"PUBHEALTH2_EPIDEM", 3, `label=dịch tễ học|desc=nghiên cứu phân bố bệnh tật trong dân số incidence prevalence R0 outbreak|vi=dịch tễ học,epidemiology|en=epidemiology|zh=流行病学`},
		{"PUBHEALTH2_SANIT",  3, `label=vệ sinh môi trường|desc=cung cấp nước sạch xử lý chất thải WASH nhà vệ sinh bệnh dịch phòng chống|vi=vệ sinh môi trường,sanitation|en=environmental sanitation|zh=环境卫生`},
		{"PUBHEALTH2_ONE_HEALTH",3,`label=One Health|desc=sức khỏe con người động vật môi trường liên kết COVID zoonosis|vi=One Health,sức khỏe toàn diện|en=One Health|zh=同一健康`},

		// ── CÁC ĐỊA DANH NỔI TIẾNG (LANDMARK_) ─────────────────
		{"LANDMARK_GREAT_WALL",3,`label=Vạn Lý Trường Thành|desc=công trình phòng thủ Trung Quốc 21196 km thế kỷ 7 TCN nhà Tần Minh UNESCO|vi=Vạn Lý Trường Thành,Great Wall|en=Great Wall of China|zh=万里长城`},
		{"LANDMARK_MACHU",    3, `label=Machu Picchu|desc=thành phố cổ Inca Peru 1450 Andes 2430m UNESCO kỳ quan thế giới du lịch|vi=Machu Picchu|en=Machu Picchu|zh=马丘比丘`},
		{"LANDMARK_ANGKOR",   3, `label=Angkor Wat|desc=đền thờ Hindu Khmer Campuchia thế kỷ 12 Suryavarman II lớn nhất thế giới UNESCO|vi=Angkor Wat,đền Angkor|en=Angkor Wat|zh=吴哥窟`},
		{"LANDMARK_COLOSSEUM",3, `label=đấu trường Colosseum|desc=đấu trường La Mã 80 SCN 50000 khán giả gladiator công trình kỳ diệu|vi=Colosseum,đấu trường La Mã|en=Colosseum|zh=罗马斗兽场`},
		{"LANDMARK_SAHARA",   3, `label=sa mạc Sahara|desc=sa mạc nóng lớn nhất thế giới 9.2 triệu km2 Bắc Phi Algeria Libya Ai Cập|vi=sa mạc Sahara|en=Sahara desert|zh=撒哈拉沙漠`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"BUILD2_GOTHIC",       "WORLD_RENAISSANCE",    "preceded"},
		{"BUILD2_SUSTAINABLE",  "SDG_GOALS",            "supports"},
		{"FOODSCI_FERMENT",     "FOODSCI_NUTRITION",    "enables"},
		{"SOCPSYCH_PERSUADE",   "SOCPSYCH_CONFORM",     "related-to"},
		{"FINPERSONAL_INVEST",  "FINPERSONAL_RETIRE",   "builds"},
		{"VNCULTURE_TET",       "VNFOOD_CHE",           "includes"},
		{"VNCULTURE_PHO",       "VNTRAVEL_HANOI",       "from"},
		{"ML2_TRANSFORMER",     "AI2_LLM",              "enables"},
		{"ML2_RAG",             "AI2_LLM",              "enhances"},
		{"ML2_DIFFUSION",       "AI2_COMPUTER_VISION",  "part-of"},
		{"ML2_FINETUNING",      "ML2_TRANSFORMER",      "applied-to"},
		{"ASTRO4_DARK_MATTER",  "ASTRO4_DARK_ENERGY",   "coexists-with"},
		{"ASTRO4_DARK_ENERGY",  "ASTROPHYS_HUBBLE",     "explains"},
		{"INTLAW_MARITIME",     "GEOPOLIT_INDO_PACIFIC","governs"},
		{"DATASCI_BIG_DATA",    "AI2_LLM",              "feeds"},
		{"DATASCI_STATS",       "DATASCI_VISUAL",       "combines-with"},
		{"MODEDU_CRITICAL",     "MODEDU_ELEARNING",     "taught-via"},
		{"PUBHEALTH2_EPIDEM",   "MODMED_VACCINE",       "guides"},
		{"LANDMARK_ANGKOR",     "ASIAHIST_CHINA_HIST",  "influenced-by"},
		{"LANDMARK_GREAT_WALL", "ASIAHIST_CHINA_HIST",  "part-of"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2700 { fmt.Println("🎉 MILESTONE 2700!") }
}

func extractLabel(d string) string {
	for i := 0; i < len(d); {
		j := i; for j < len(d) && d[j] != '|' { j++ }
		p := d[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j + 1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'; rec[1] = 'D'; rec[2] = layer; copy(rec[3:], islv[:])
	rec[15] = byte(len(dna)>>24); rec[16] = byte(len(dna)>>16)
	rec[17] = byte(len(dna)>>8); rec[18] = byte(len(dna)); rec[19] = uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0] = layer; v[1] = h[0]%200+1; v[2] = h[1]%200+1; v[3] = h[2]%200+1
	v[4] = h[3]; v[5] = h[4]; v[6] = h[5]; v[7] = h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw) - ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16]) + 1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2 > end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])] = v; i = ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20]) + 1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"preceded":1,"supports":2,"enables":3,"related-to":4,"builds":5,
		"includes":6,"from":7,"part-of":8,"enhances":9,"applied-to":10,
		"coexists-with":11,"explains":12,"governs":13,"feeds":14,
		"combines-with":15,"taught-via":16,"guides":17,"influenced-by":18,
	}
	if b, ok := m[r]; ok { return b }; return 0
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl > 10000 || nl > 200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2 > end { break }
		m[string(raw[i+20+dl:ne2])] = true; i = ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
