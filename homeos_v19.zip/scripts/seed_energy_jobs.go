//go:build ignore
// go run scripts/seed_energy_jobs.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
	existing := readNames(raw)

	nodes := []Node{
		// ── NĂNG LƯỢNG / VẬT LÝ ỨNG DỤNG ───────────────────────
		{"ENERGY_ELECTRIC",  3, `label=điện|desc=dạng năng lượng từ chuyển động electron tạo ra dòng điện áp điện xoay chiều một chiều|vi=điện,điện năng,electricity|en=electricity,electric power|zh=电力`},
		{"ENERGY_BATTERY",   3, `label=pin|desc=thiết bị lưu trữ năng lượng điện hóa học lithium-ion chì axit pin mặt trời|vi=pin,battery|en=battery|zh=电池`},
		{"ENERGY_FUEL",      3, `label=nhiên liệu|desc=chất cháy được để tạo ra năng lượng xăng dầu diesel than đốt khí đốt tự nhiên|vi=nhiên liệu,xăng dầu|en=fuel|zh=燃料`},
		{"ENERGY_NUCLEAR",   3, `label=năng lượng hạt nhân|desc=năng lượng từ phản ứng phân hạch hoặc tổng hợp hạt nhân nhà máy điện nguyên tử uranium|vi=năng lượng hạt nhân,hạt nhân|en=nuclear energy,nuclear power|zh=核能`},
		{"ENERGY_WIND",      3, `label=năng lượng gió|desc=điện từ tua-bin gió chuyển đổi động năng gió thành điện năng offshore onshore|vi=năng lượng gió,điện gió|en=wind energy,wind power|zh=风能`},
		{"ENERGY_HYDRO",     3, `label=thủy điện|desc=điện từ sức nước đập thủy điện tua-bin nước nguồn năng lượng tái tạo lớn nhất thế giới|vi=thủy điện,hydroelectric|en=hydroelectric power,hydro power|zh=水电`},
		{"ENERGY_GRID",      3, `label=lưới điện|desc=hệ thống truyền tải và phân phối điện từ nhà máy đến người tiêu dùng đường dây cao thế|vi=lưới điện,electric grid|en=power grid,electric grid|zh=电网`},
		{"ENERGY_FOSSIL",    3, `label=nhiên liệu hóa thạch|desc=than dầu mỏ khí đốt tự nhiên hình thành từ xác sinh vật qua hàng triệu năm|vi=nhiên liệu hóa thạch,fossil fuel|en=fossil fuel|zh=化石燃料`},
		{"ENERGY_HYDROGEN",  3, `label=hydro|desc=nguyên tố nhẹ nhất khí hydro nhiên liệu sạch pin nhiên liệu hydrogen không thải CO2|vi=hydro,hydrogen|en=hydrogen|zh=氢能`},
		{"ENERGY_STORAGE",   3, `label=lưu trữ năng lượng|desc=công nghệ tích trữ điện cho sau pin lưu điện supercapacitor bơm nước tích trữ|vi=lưu trữ năng lượng,energy storage|en=energy storage|zh=储能`},

		// ── NGÀNH NGHỀ / CÔNG VIỆC ───────────────────────────────
		{"JOB_ENGINEER",     3, `label=kỹ sư|desc=chuyên gia áp dụng khoa học và toán học để thiết kế xây dựng và vận hành hệ thống|vi=kỹ sư,engineer|en=engineer|zh=工程师`},
		{"JOB_DOCTOR",       3, `label=bác sĩ|desc=chuyên gia y tế được đào tạo để chẩn đoán điều trị bệnh bảo vệ sức khỏe con người|vi=bác sĩ,doctor,physician|en=doctor,physician|zh=医生`},
		{"JOB_TEACHER",      3, `label=giáo viên|desc=nhà giáo dục truyền đạt kiến thức và kỹ năng cho học sinh sinh viên ở mọi cấp độ|vi=giáo viên,thầy giáo,cô giáo,teacher|en=teacher,educator|zh=教师`},
		{"JOB_PROGRAMMER",   3, `label=lập trình viên|desc=chuyên gia viết mã nguồn phần mềm ứng dụng hệ thống developer software engineer|vi=lập trình viên,developer,coder|en=programmer,developer,software engineer|zh=程序员`},
		{"JOB_SCIENTIST",    3, `label=nhà khoa học|desc=người nghiên cứu và mở rộng kiến thức khoa học qua quan sát thí nghiệm và lý thuyết|vi=nhà khoa học,scientist|en=scientist,researcher|zh=科学家`},
		{"JOB_ARTIST",       3, `label=nghệ sĩ|desc=người sáng tác và biểu diễn nghệ thuật hội họa âm nhạc điêu khắc điện ảnh|vi=nghệ sĩ,artist|en=artist|zh=艺术家`},
		{"JOB_ENTREPRENEUR", 3, `label=doanh nhân|desc=người khởi nghiệp và điều hành doanh nghiệp chấp nhận rủi ro để tạo ra giá trị kinh tế|vi=doanh nhân,entrepreneur|en=entrepreneur,business owner|zh=企业家`},
		{"JOB_LAWYER",       3, `label=luật sư|desc=chuyên gia pháp lý tư vấn và bảo vệ quyền lợi khách hàng trước tòa án|vi=luật sư,lawyer,attorney|en=lawyer,attorney|zh=律师`},
		{"JOB_FARMER",       3, `label=nông dân|desc=người canh tác đất sản xuất lương thực rau quả chăn nuôi nông nghiệp truyền thống|vi=nông dân,farmer|en=farmer|zh=农民`},
		{"JOB_CHEF",         3, `label=đầu bếp|desc=chuyên gia nấu ăn thiết kế thực đơn và chuẩn bị món ăn trong nhà hàng hoặc khách sạn|vi=đầu bếp,chef,cook|en=chef,cook|zh=厨师`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		// Năng lượng nội bộ
		{"ENERGY_ELECTRIC",  "ENERGY_GRID",      "transmitted-by"},
		{"ENERGY_BATTERY",   "ENERGY_STORAGE",   "type-of"},
		{"ENERGY_WIND",      "ENV_RENEWABLE",    "is-a"},
		{"ENERGY_HYDRO",     "ENV_RENEWABLE",    "is-a"},
		{"ENERGY_NUCLEAR",   "ENERGY_ELECTRIC",  "generates"},
		{"ENERGY_FOSSIL",    "ENV_CARBON",       "emits"},
		{"ENERGY_FOSSIL",    "ENV_CLIMATE_CHANGE","contributes-to"},
		{"ENERGY_HYDROGEN",  "ENERGY_STORAGE",   "used-for"},
		{"ENERGY_SOLAR",     "ENERGY_STORAGE",   "needs"},
		// Năng lượng ↔ Vật lý / Hóa học
		{"ENERGY_ELECTRIC",  "PHYS_ELECTRON",    "carried-by"},
		{"ENERGY_NUCLEAR",   "PHYS_ENERGY",      "form-of"},
		{"ENERGY_BATTERY",   "CHEM_REACTION",    "uses"},
		// Ngành nghề nội bộ
		{"JOB_PROGRAMMER",  "TECH_AI",           "builds"},
		{"JOB_SCIENTIST",   "MATH_EQUATION",     "uses"},
		{"JOB_ENGINEER",    "BUILD_BRIDGE",      "designs"},
		{"JOB_DOCTOR",      "MED_BRAIN",         "studies"},
		{"JOB_CHEF",        "FOOD_COOKING",      "masters"},
		{"JOB_ARTIST",      "ART_PAINTING",      "creates"},
		{"JOB_ENTREPRENEUR","ECON_STARTUP",      "creates"},
		{"JOB_FARMER",      "FOOD_RICE",         "grows"},
		{"JOB_TEACHER",     "PSY_LEARNING",      "facilitates"},
		{"JOB_LAWYER",      "PHIL_ETHICS",       "applies"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ L%d %-26s %q\n", nd.layer, nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	tmp := filePath + ".tmp"
	os.WriteFile(tmp, raw, 0644)
	os.Rename(tmp, filePath)
	fmt.Printf("✅ Done: %d bytes, %d nodes, %d edges\n", len(raw), be32(raw[12:16]), be32(raw[16:20]))
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer
	copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8);  rec[18]=byte(len(dna))
	rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb)
	return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n)
	return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n)
	return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"is-a":1,"type-of":2,"transmitted-by":3,"generates":4,"emits":5,
		"contributes-to":6,"used-for":7,"needs":8,"carried-by":9,
		"form-of":10,"uses":11,"builds":12,"designs":13,"studies":14,
		"masters":15,"creates":16,"grows":17,"facilitates":18,"applies":19,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
