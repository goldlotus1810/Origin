//go:build ignore
// go run scripts/seed_to2500.go
package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24

type Node struct{ name string; layer uint8; dna string }

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf("○ bắt đầu: %d nodes\n", be32(raw[12:16]))
	existing := readNames(raw)

	nodes := []Node{
		// ── SỨC KHỎE / Y TẾ BỔ SUNG (HEALTH2_) ─────────────────
		{"HEALTH2_SLEEP",    3, `label=giấc ngủ|desc=trạng thái nghỉ ngơi thiết yếu của cơ thể 7-9 tiếng người lớn REM NREM hormone cortisol|vi=giấc ngủ,sleep|en=sleep|zh=睡眠`},
		{"HEALTH2_STRESS",   3, `label=căng thẳng|desc=phản ứng sinh lý tâm lý trước áp lực cortisol adrenaline mạn tính sức khỏe tim mạch|vi=căng thẳng,stress|en=stress|zh=压力`},
		{"HEALTH2_DIABETES", 3, `label=tiểu đường|desc=rối loạn chuyển hóa glucose insulin type 1 type 2 gestational HbA1c chế độ ăn|vi=tiểu đường,đái tháo đường,diabetes|en=diabetes|zh=糖尿病`},
		{"HEALTH2_OBESITY",  3, `label=béo phì|desc=tích tụ mỡ thừa BMI >30 nguy cơ tim mạch tiểu đường khớp chế độ ăn vận động|vi=béo phì,obesity|en=obesity|zh=肥胖症`},
		{"HEALTH2_MENTAL",   3, `label=sức khỏe tâm thần|desc=trạng thái tâm lý cảm xúc xã hội khỏe mạnh phòng ngừa trầm cảm lo âu trị liệu|vi=sức khỏe tâm thần,mental health|en=mental health|zh=心理健康`},
		{"HEALTH2_AGING2",   3, `label=lão hóa cơ thể|desc=quá trình tế bào suy giảm xương khớp yếu thị lực trí nhớ dinh dưỡng vận động|vi=lão hóa cơ thể,aging|en=aging|zh=衰老`},

		// ── KINH TẾ VIỆT NAM (VNECON_) ───────────────────────────
		{"VNECON_GDP",       3, `label=GDP Việt Nam|desc=tổng sản phẩm nội địa Việt Nam tăng trưởng 6-7% top ASEAN sản xuất xuất khẩu FDI|vi=GDP Việt Nam,tăng trưởng kinh tế|en=Vietnam GDP|zh=越南GDP`},
		{"VNECON_EXPORT",    3, `label=xuất khẩu Việt Nam|desc=hàng hóa bán ra nước ngoài điện tử may mặc giày dép Samsung Apple Foxconn|vi=xuất khẩu Việt Nam,hàng xuất khẩu|en=Vietnam exports|zh=越南出口`},
		{"VNECON_FDI",       3, `label=đầu tư nước ngoài vào Việt Nam|desc=FDI vốn từ nước ngoài Samsung LG Intel khu công nghiệp|vi=FDI,đầu tư nước ngoài,vốn ngoại|en=Vietnam FDI|zh=越南外商直接投资`},
		{"VNECON_STARTUP",   3, `label=khởi nghiệp Việt Nam|desc=ecosystem startup VinGroup VNG MoMo Tiki Grab Southeast Asia unicorn|vi=khởi nghiệp Việt Nam,startup,đổi mới sáng tạo|en=Vietnam startup|zh=越南创业`},

		// ── GIÁO DỤC VIỆT NAM (VNEDU_) ───────────────────────────
		{"VNEDU_UNIV",       3, `label=đại học Việt Nam|desc=ĐHQG Hà Nội TP.HCM Bách Khoa Y Dược hệ thống giáo dục đại học tuyển sinh|vi=đại học Việt Nam,trường đại học|en=Vietnam university|zh=越南大学`},
		{"VNEDU_STEM",       3, `label=STEM Việt Nam|desc=giáo dục khoa học công nghệ kỹ thuật toán học trường chuyên Olympic quốc tế|vi=STEM,khoa học công nghệ giáo dục|en=STEM Vietnam|zh=越南STEM教育`},
		{"VNEDU_REFORM",     3, `label=cải cách giáo dục|desc=đổi mới chương trình phổ thông 2018 năng lực phẩm chất học sinh giảm tải|vi=cải cách giáo dục,đổi mới giáo dục|en=education reform|zh=教育改革`},

		// ── LỊCH SỬ VIỆT NAM (VNHIST_) ───────────────────────────
		{"VNHIST_1975",      3, `label=thống nhất Việt Nam 1975|desc=30/4/1975 giải phóng Sài Gòn kết thúc chiến tranh thống nhất đất nước|vi=30/4/1975,thống nhất,giải phóng Sài Gòn|en=Vietnam reunification 1975|zh=越南统一1975`},
		{"VNHIST_DIENBIEN",  3, `label=Điện Biên Phủ|desc=chiến thắng lịch sử 1954 Điện Biên Phủ kết thúc thực dân Pháp Đại tướng Võ Nguyên Giáp|vi=Điện Biên Phủ,chiến thắng Điện Biên Phủ|en=Dien Bien Phu|zh=奠边府战役`},
		{"VNHIST_REFORM",    3, `label=Đổi Mới Việt Nam|desc=cải cách kinh tế 1986 chuyển từ kế hoạch hóa sang thị trường định hướng XHCN|vi=Đổi Mới,cải cách 1986|en=Doi Moi reform|zh=革新开放越南`},

		// ── DU LỊCH VIỆT NAM (VNTRAVEL_) ─────────────────────────
		{"VNTRAVEL_HCMC",    3, `label=Thành phố Hồ Chí Minh|desc=thành phố lớn nhất Việt Nam trung tâm kinh tế Bến Thành Bùi Viện Củ Chi|vi=TP.HCM,Sài Gòn,Thành phố Hồ Chí Minh|en=Ho Chi Minh City,Saigon|zh=胡志明市`},
		{"VNTRAVEL_HANOI",   3, `label=Hà Nội|desc=thủ đô Việt Nam Hồ Hoàn Kiếm Phố cổ Văn Miếu lịch sử 1000 năm văn hóa|vi=Hà Nội,Hanoi,thủ đô|en=Hanoi|zh=河内`},
		{"VNTRAVEL_DANANG",  3, `label=Đà Nẵng|desc=thành phố biển miền Trung Cầu Rồng Bà Nà Hills Mỹ Khê Non Nước du lịch|vi=Đà Nẵng,Da Nang|en=Da Nang|zh=岘港`},
		{"VNTRAVEL_HOIAN",   3, `label=Hội An|desc=phố cổ UNESCO Quảng Nam đèn lồng kiến trúc Hoa-Nhật-Việt du lịch văn hóa|vi=Hội An,Hoi An|en=Hoi An|zh=会安`},
		{"VNTRAVEL_SAPA",    3, `label=Sa Pa|desc=huyện vùng cao Lào Cai ruộng bậc thang dân tộc H'Mông Dao mây núi Fansipan|vi=Sa Pa,Sapa|en=Sapa|zh=沙坝`},

		// ── VĂN HỌC VIỆT NAM (VNLIT_) ────────────────────────────
		{"VNLIT_KIEU",       3, `label=Truyện Kiều|desc=kiệt tác văn học Việt Nam Nguyễn Du 3254 câu thơ lục bát nhân vật Thúy Kiều|vi=Truyện Kiều,Nguyễn Du|en=Tale of Kieu|zh=金云翘传`},
		{"VNLIT_NAM_QUOC",   3, `label=Nam Quốc Sơn Hà|desc=bài thơ thần Lý Thường Kiệt 1077 tuyên ngôn độc lập đầu tiên của Việt Nam|vi=Nam Quốc Sơn Hà,Lý Thường Kiệt|en=Nam Quoc Son Ha|zh=南国山河`},

		// ── MÔI TRƯỜNG VIỆT NAM (VNENV_) ─────────────────────────
		{"VNENV_MEKONG",     3, `label=đồng bằng sông Cửu Long|desc=vựa lúa Việt Nam sông Mê Kông lúa gạo cá tôm biến đổi khí hậu xâm nhập mặn|vi=đồng bằng sông Cửu Long,ĐBSCL,Mê Kông|en=Mekong Delta|zh=湄公河三角洲`},
		{"VNENV_RED_RIVER",  3, `label=đồng bằng sông Hồng|desc=châu thổ sông Hồng Hà Nội lúa gạo lịch sử văn minh nông nghiệp 4000 năm|vi=đồng bằng sông Hồng,sông Hồng|en=Red River Delta|zh=红河三角洲`},

		// ── KHOA HỌC MÁY TÍNH BỔ SUNG (CS2_) ────────────────────
		{"CS2_ML_ALGO",      3, `label=thuật toán học máy|desc=random forest gradient boosting SVM neural network K-means clustering supervised unsupervised|vi=thuật toán học máy,ML algorithm|en=machine learning algorithm|zh=机器学习算法`},
		{"CS2_WEB",          3, `label=lập trình web|desc=HTML CSS JavaScript React Vue Angular Node.js REST API frontend backend fullstack|vi=lập trình web,web development|en=web development|zh=网页开发`},
		{"CS2_DEVOPS",       3, `label=DevOps|desc=kết hợp phát triển và vận hành phần mềm CI/CD Docker Kubernetes pipeline tự động hóa|vi=DevOps,CI/CD|en=DevOps|zh=DevOps`},
		{"CS2_MOBILE",       3, `label=lập trình di động|desc=iOS Android Flutter React Native Swift Kotlin ứng dụng điện thoại app store|vi=lập trình di động,mobile development|en=mobile development|zh=移动开发`},
		{"CS2_BLOCKCHAIN",   3, `label=blockchain|desc=chuỗi khối phi tập trung bất biến Bitcoin Ethereum smart contract DeFi Web3|vi=blockchain,chuỗi khối|en=blockchain|zh=区块链`},

		// ── TRÍ TUỆ NHÂN TẠO CHI TIẾT (AI2_) ────────────────────
		{"AI2_LLM",          3, `label=mô hình ngôn ngữ lớn|desc=LLM GPT Claude Gemini Llama transformer attention pretrain finetune RLHF|vi=mô hình ngôn ngữ lớn,LLM,GPT,Claude|en=LLM,large language model|zh=大语言模型`},
		{"AI2_COMPUTER_VISION",3,`label=thị giác máy tính|desc=nhận dạng hình ảnh object detection segmentation YOLO CNN ResNet autonomous driving|vi=thị giác máy tính,computer vision|en=computer vision|zh=计算机视觉`},
		{"AI2_NLP",          3, `label=xử lý ngôn ngữ tự nhiên|desc=NLP phân tích văn bản sentiment dịch máy BERT tokenization named entity|vi=xử lý ngôn ngữ tự nhiên,NLP|en=NLP,natural language processing|zh=自然语言处理`},
		{"AI2_REINFORCE",    3, `label=học tăng cường|desc=reinforcement learning agent reward environment policy Q-learning AlphaGo PPO|vi=học tăng cường,reinforcement learning,RL|en=reinforcement learning|zh=强化学习`},
		{"AI2_ETHICS",       3, `label=đạo đức AI|desc=bias công bằng minh bạch giải thích được AI Act EU safety alignment Anthropic|vi=đạo đức AI,AI ethics,AI safety|en=AI ethics,AI safety|zh=人工智能伦理`},

		// ── VẬT LÝ LÝ THUYẾT (PHYS4_) ───────────────────────────
		{"PHYS4_STRING",     3, `label=lý thuyết dây|desc=unified theory hạt cơ bản là dây dao động 10-11 chiều siêu đối xứng M-theory|vi=lý thuyết dây,string theory|en=string theory|zh=弦理论`},
		{"PHYS4_LOOP",       3, `label=hấp dẫn lượng tử vòng|desc=LQG lý thuyết không gian rời rạc spin network loop quantum gravity Planck|vi=hấp dẫn lượng tử vòng,LQG|en=loop quantum gravity|zh=圈量子引力`},

		// ── KINH TẾ TOÀN CẦU (ECON4_) ───────────────────────────
		{"ECON4_GLOBALIZ",   3, `label=toàn cầu hóa|desc=hội nhập kinh tế thương mại tự do WTO chuỗi cung ứng toàn cầu FDI văn hóa|vi=toàn cầu hóa,globalization|en=globalization|zh=全球化`},
		{"ECON4_CRYPTO",     3, `label=tiền điện tử|desc=cryptocurrency Bitcoin Ethereum tài sản kỹ thuật số blockchain phi tập trung biến động|vi=tiền điện tử,cryptocurrency,Bitcoin|en=cryptocurrency|zh=加密货币`},
		{"ECON4_GREEN",      3, `label=kinh tế xanh|desc=mô hình tăng trưởng thân thiện môi trường carbon neutral năng lượng tái tạo ESG|vi=kinh tế xanh,green economy|en=green economy|zh=绿色经济`},

		// ── XÃ HỘI SỐ (DIGITAL2_) ────────────────────────────────
		{"DIGITAL2_SOCIAL",  3, `label=mạng xã hội|desc=Facebook TikTok YouTube Instagram kết nối người dùng nội dung thuật toán bubble|vi=mạng xã hội,social media|en=social media|zh=社交媒体`},
		{"DIGITAL2_PRIV",    3, `label=quyền riêng tư số|desc=GDPR dữ liệu cá nhân tracking cookie end-to-end encryption quyền được quên|vi=quyền riêng tư số,digital privacy|en=digital privacy|zh=数字隐私`},
		{"DIGITAL2_MISINFO", 3, `label=thông tin sai lệch|desc=fake news deepfake disinformation kiểm chứng fact-check mạng xã hội lan truyền|vi=thông tin sai lệch,fake news,tin giả|en=misinformation|zh=虚假信息`},

		// ── TRIẾT HỌC ĐÔNG PHƯƠNG (EASPHIL_) ─────────────────────
		{"EASPHIL_CONFUCIUS",3, `label=Nho giáo|desc=hệ thống tư tưởng Khổng Tử nhân lễ nghĩa trí tín gia đình xã hội giáo dục Châu Á|vi=Nho giáo,Khổng Tử,Confucianism|en=Confucianism|zh=儒学`},
		{"EASPHIL_TAOIST",   3, `label=Đạo giáo|desc=tư tưởng Lão Tử Trang Tử Đạo vô vi tự nhiên hòa hợp âm dương|vi=Đạo giáo,Lão Tử,Taoism|en=Taoism|zh=道教`},
		{"EASPHIL_BUDDHISM", 3, `label=Phật giáo triết học|desc=tứ diệu đế bát chánh đạo vô thường vô ngã Đức Phật Thích Ca Thiền tông|vi=Phật giáo,triết học Phật giáo|en=Buddhist philosophy|zh=佛教哲学`},

		// ── VŨ KHÍ / AN NINH (SEC2_) ─────────────────────────────
		{"SEC2_CYBER",       3, `label=an ninh mạng|desc=bảo vệ hệ thống số khỏi tấn công ransomware phishing zero-day SOC SIEM|vi=an ninh mạng,cybersecurity|en=cybersecurity|zh=网络安全`},
		{"SEC2_NUCLEAR",     3, `label=vũ khí hạt nhân|desc=bom nguyên tử hydro NPT kiểm soát vũ khí Hiroshima Nagasaki ngăn chặn hạt nhân|vi=vũ khí hạt nhân,nuclear weapon|en=nuclear weapon|zh=核武器`},

		// ── KHOA HỌC VẬT LIỆU (MATER2_) ─────────────────────────
		{"MATER2_GRAPHENE",  3, `label=graphene|desc=vật liệu carbon 2D một lớp nguyên tử siêu bền dẫn điện tốt Nobel 2010 ứng dụng tương lai|vi=graphene|en=graphene|zh=石墨烯`},
		{"MATER2_NANO",      3, `label=vật liệu nano|desc=vật liệu kích thước 1-100 nm tính chất đặc biệt y tế điện tử năng lượng|vi=vật liệu nano,nanotechnology,nano|en=nanomaterial|zh=纳米材料`},
		{"MATER2_SUPERCOND", 3, `label=siêu dẫn|desc=điện trở bằng không dưới nhiệt độ tới hạn Meissner MRI máy gia tốc siêu dẫn nhiệt độ phòng|vi=siêu dẫn,superconductor|en=superconductor|zh=超导体`},
	}

	type Edge struct{ from, to, rel string }
	edges := []Edge{
		{"HEALTH2_SLEEP",    "PSY2_MEMORY",        "supports"},
		{"HEALTH2_STRESS",   "ANAT_HEART",         "harms"},
		{"HEALTH2_DIABETES", "HEALTH2_OBESITY",    "related-to"},
		{"HEALTH2_MENTAL",   "PSYCH2_ANXIETY",     "includes"},
		{"VNECON_EXPORT",    "VNECON_FDI",         "drives"},
		{"VNECON_STARTUP",   "FINTECH_DEFI",       "includes"},
		{"VNTRAVEL_HCMC",    "VN_PHO",             "known-for"},
		{"VNTRAVEL_HANOI",   "VN_HO_CHI_MINH",    "home-of"},
		{"VNTRAVEL_HOIAN",   "ANTH_ARCHAEOLOGY",   "site-of"},
		{"VNLIT_KIEU",       "LIT_NOVEL",          "type-of"},
		{"VNENV_MEKONG",     "AGR_RICE",           "produces"},
		{"VNENV_MEKONG",     "CLIM_FLOOD",         "threatened-by"},
		{"CS2_BLOCKCHAIN",   "FINTECH_DEFI",       "enables"},
		{"CS2_ML_ALGO",      "TECH_ML",            "implements"},
		{"AI2_LLM",          "TECH_AI",            "type-of"},
		{"AI2_LLM",          "AI2_NLP",            "uses"},
		{"AI2_COMPUTER_VISION","AI2_LLM",         "combined-with"},
		{"AI2_ETHICS",       "PHIL2_ETHICS",       "applies"},
		{"ECON4_CRYPTO",     "CS2_BLOCKCHAIN",     "built-on"},
		{"ECON4_GREEN",      "ENERGY_RENEWABLE",   "promotes"},
		{"DIGITAL2_SOCIAL",  "DIGITAL2_MISINFO",   "spreads"},
		{"DIGITAL2_PRIV",    "DIG_CYBERSEC",       "related-to"},
		{"EASPHIL_CONFUCIUS","EASPHIL_BUDDHISM",   "coexists-with"},
		{"MATER2_GRAPHENE",  "TECH_AI",            "enables"},
		{"MATER2_NANO",      "BIO2_GENE_THERAPY",  "used-in"},
		{"SEC2_CYBER",       "CS_SECURITY",        "implements"},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		rec := buildRecord(nd.layer, islv, []byte(nd.dna), nd.name)
		raw = insertNode(raw, rec)
		existing[nd.name] = true
		added++
		fmt.Printf("  ✚ %-28s %q\n", nd.name, extractLabel(nd.dna))
	}
	nodeISLMap := buildISLMap(raw)
	edgeAdded := 0
	for _, e := range edges {
		from, ok1 := nodeISLMap[e.from]
		to,   ok2 := nodeISLMap[e.to]
		if !ok1 || !ok2 { fmt.Printf("  skip edge %s→%s\n", e.from, e.to); continue }
		raw = appendEdge(raw, from, to, e.rel)
		edgeAdded++
	}
	fmt.Printf("\n✚ %d nodes, %d edges (skip %d)\n", added, edgeAdded, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf("✅ %d nodes, %d edges\n", nn, be32(raw[16:20]))
	if nn >= 2500 { fmt.Println("🎉 MILESTONE 2500!") }
}

func extractLabel(dna string) string {
	for i := 0; i < len(dna); {
		j := i; for j < len(dna) && dna[j] != '|' { j++ }
		p := dna[i:j]; if len(p) > 6 && p[:6] == "label=" { return p[6:] }
		i = j+1
	}; return ""
}
func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb)>255 { nb=nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func buildISLMap(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		var v [8]byte; copy(v[:], raw[i+3:i+11])
		m[string(raw[i+20+dl:ne2])]=v; i=ne2
	}; return m
}
func appendEdge(raw []byte, from, to [8]byte, rel string) []byte {
	e := make([]byte, 17)
	binary.BigEndian.PutUint64(e[0:8], binary.BigEndian.Uint64(from[:]))
	binary.BigEndian.PutUint64(e[8:16], binary.BigEndian.Uint64(to[:]))
	e[16] = relByte(rel); raw = append(raw, e...)
	n := be32(raw[16:20])+1
	raw[16]=byte(n>>24); raw[17]=byte(n>>16); raw[18]=byte(n>>8); raw[19]=byte(n); return raw
}
func relByte(r string) uint8 {
	m := map[string]uint8{
		"supports":1,"harms":2,"related-to":3,"includes":4,"drives":5,
		"known-for":6,"home-of":7,"site-of":8,"type-of":9,"produces":10,
		"threatened-by":11,"enables":12,"implements":13,"uses":14,"applies":15,
		"combined-with":16,"built-on":17,"promotes":18,"spreads":19,"coexists-with":20,
	}
	if b,ok:=m[r];ok{return b}; return 0
}
func readNames(raw []byte) map[string]bool {
	m:=map[string]bool{}
	ne:=int(be32(raw[16:20])); end:=len(raw)-ne*17; i:=layerIdxEnd
	for i<end-25 {
		if raw[i]!='N'||raw[i+1]!='D' { i++; continue }
		dl:=int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl:=int(raw[i+19])
		if dl>10000||nl>200 { i++; continue }
		ne2:=i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
