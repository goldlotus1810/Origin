//go:build ignore

// scripts/cleanup_and_seed.go
//
// MỤC TIÊU (1 script, 1 lần chạy):
//   1. Xóa 28 garbage nodes L7 (key=value entries từ test/demo)
//   2. Thêm SKILL nodes còn thiếu (user_input_watch, knowledge_forward,
//      home_chief, vision, audio)
//   3. Thêm 23 bird/concept/intent nodes (PERCEPT_IMAGE, CONCEPT_STORY, ...)
//
// Format đúng: ND(2) + layer(1) + isl(8) + cp(4) + dnaLen(4) + nameLen(1) + dna + name
// SHA256 đúng: sha256(raw[280:]) → raw[28:60]  (không phải raw[4:36])
// Header:      raw[12:16] = nnodes, raw[16:20] = nedges
//
// Chạy: go run scripts/cleanup_and_seed.go

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath = "homeos.olang"
const layerIdxEnd = 64 + 9*24 // 280

// ── Garbage: các tên cần xóa khỏi L7 ──────────────────────────
var garbageNames = map[string]bool{
	"he dieu hanh = Linux":        true,
	"test=ok":                     true,
	"số yêu thích = 7":            true,
	"màu yêu thích = tím":         true,
	"AAM_NAME=Nova":                true,
	"số may mắn = 42":              true,
	"AAM_NAME=Luna":                true,
	"color = red":                  true,
	"AAM_NAME=Zeta":                true,
	"thức ăn yêu thích = phở":     true,
	"ngon ngu lap trinh = Go":      true,
	"số yêu thích = 42":            true,
	"AAM_NAME=Sigma":               true,
	"the sky = blue":               true,
	"x=1":                          true,
	"framework yêu thích = gin":    true,
	"AAM_NAME=Orio":                true,
	"test=benchmark":               true,
	"màu yêu thích = xanh lam":    true,
	"số may mắn = 7":               true,
	"framework yeu thich = gin":    true,
	"abc":                          true,
	"ngôn ngữ yêu thích = tiếng việt": true,
	"ngôn ngữ lập trình = Go":     true,
	"AAM_NAME=Echo":                true,
	"thủ đô việt nam = hà nội":    true,
	"mau nen = den":                true,
	"test key = test value":        true,
}

// ── Nodes cần thêm ────────────────────────────────────────────
type nodeDef struct {
	layer uint8
	name  string
	dna   string // "label=...|desc=...|vi=..."
}

var newNodes = []nodeDef{
	// ── SKILL nodes còn thiếu trong L7 ─────────────────────────
	{7, "SKILL_USER_INPUT_WATCH",
		"label=lắng nghe input|desc=LeoAI lắng nghe mọi MsgUserInput học concept mới vào ĐN|vi=user_input_watch,watch,lắng nghe"},
	{7, "SKILL_KNOWLEDGE_FORWARD",
		"label=forward kiến thức|desc=AAM nhận MsgKnowledge từ LeoAI forward đến Chief đúng layer|vi=knowledge_forward,forward,kiến thức"},
	{7, "SKILL_HOME_CHIEF",
		"label=điều phối nhà|desc=HomeChief route ISL message đến Worker đúng theo ISL address|vi=home_chief,chief,điều phối"},
	{7, "SKILL_VISION",
		"label=thị giác SDF|desc=PENDING nhận diện vật thể qua ray marching SDF Fibonacci chưa wire vào agent|vi=vision,nhìn,SDF"},
	{7, "SKILL_AUDIO",
		"label=âm thanh formant|desc=PENDING phân tích âm thanh FormantSpline ISL address chưa wire vào agent|vi=audio,nghe,formant"},

	// ── L6 Perception — visual/audio/beauty ─────────────────────
	{6, "PERCEPT_IMAGE",
		"label=hình ảnh|desc=biểu diễn thị giác của vật thể hoặc cảnh vật|vi=hình,ảnh,picture,image,bức ảnh"},
	{6, "PERCEPT_VISUAL",
		"label=thị giác|desc=cảm quan nhận biết ánh sáng màu sắc hình dạng qua mắt|vi=nhìn thấy,visual,thị giác"},
	{6, "PERCEPT_BEAUTY",
		"label=đẹp|desc=cảm nhận thẩm mỹ về hình dạng màu sắc tỷ lệ hài hòa|vi=đẹp,xinh,beautiful"},
	{6, "PERCEPT_SOUND",
		"label=âm thanh|desc=dao động áp suất không khí lan truyền qua môi trường|vi=tiếng,âm,sound"},
	{6, "PERCEPT_SINGING",
		"label=hót|desc=âm thanh du dương do chim tạo ra để giao tiếp|vi=hót,chim hót,sing"},
	{6, "PERCEPT_FLYING",
		"label=bay lượn|desc=di chuyển trong không khí bằng cánh|vi=bay,fly,lượn,cánh bay"},
	{6, "PERCEPT_COLOR",
		"label=màu sắc|desc=đặc tính quang học phản xạ bước sóng ánh sáng nhất định|vi=màu,color,sắc"},

	// ── L5 Concept — ngôn ngữ / tư duy ─────────────────────────
	{5, "CONCEPT_STORY",
		"label=câu chuyện|desc=chuỗi sự kiện có cấu trúc nhân vật diễn biến kết thúc|vi=chuyện,story,truyện,narrative"},
	{5, "CONCEPT_DESCRIBE",
		"label=mô tả|desc=trình bày chi tiết đặc điểm hình dạng màu sắc tính chất|vi=mô tả,miêu tả,describe,tả"},
	{5, "CONCEPT_NARRATE",
		"label=kể|desc=truyền đạt chuỗi sự kiện theo trình tự thời gian|vi=kể,kể lại,narrate,tell"},
	{5, "CONCEPT_EXPLAIN",
		"label=giải thích|desc=làm rõ nghĩa nguyên nhân cách thức để người khác hiểu|vi=giải thích,explain,lý giải"},

	// ── L3 Life — hành động ngôn ngữ + chim ─────────────────────
	{3, "LIFE_DESCRIBE",
		"label=miêu tả|desc=dùng ngôn ngữ trình bày đặc điểm hình dạng của vật thể|vi=mô tả,miêu tả,describe,tả"},
	{3, "LIFE_NARRATE",
		"label=kể chuyện|desc=truyền đạt chuỗi sự kiện nhân vật bằng lời hoặc văn bản|vi=kể,kể chuyện,narrate"},
	{3, "LIFE_ASK",
		"label=hỏi|desc=đặt câu hỏi để thu thập thông tin hoặc hiểu rõ vấn đề|vi=hỏi,ask,question,thắc mắc"},
	{3, "LIFE_FLY",
		"label=bay|desc=di chuyển trong không khí bằng cánh hai chi trên biến đổi|vi=bay,chim bay,fly"},
	{3, "LIFE_SING",
		"label=hót|desc=phát âm thanh du dương có nhịp điệu thể hiện cảm xúc|vi=hót,hát,sing,ca hát"},
	{3, "LIFE_NEST",
		"label=làm tổ|desc=xây nơi trú ẩn và ấp trứng từ cành lá vật liệu tự nhiên|vi=làm tổ,tổ chim,nest"},

	// ── L4 Objects — bộ phận chim ───────────────────────────────
	{4, "OBJ_FEATHER",
		"label=lông vũ|desc=cấu trúc keratin nhẹ phủ thân chim giữ ấm hỗ trợ bay|vi=lông,lông chim,feather"},
	{4, "OBJ_WING",
		"label=cánh|desc=chi trên biến đổi của chim tạo lực nâng và đẩy để bay|vi=cánh,wing,cánh chim"},
	{4, "OBJ_BEAK",
		"label=mỏ|desc=phần xương hàm có sừng của chim dùng để ăn và giao tiếp|vi=mỏ,beak,bill"},
	{4, "OBJ_EGG",
		"label=trứng|desc=tế bào sinh sản bao bọc trong vỏ cứng của chim bò sát|vi=trứng,egg,trứng chim"},
	{4, "OBJ_NEST",
		"label=tổ chim|desc=nơi chim xây để ấp trứng và nuôi con từ cành lá|vi=tổ,tổ chim,nest"},
}

// ── Edges cần thêm ─────────────────────────────────────────────
type edgeDef struct{ from, to string; typ uint8 }

var newEdges = []edgeDef{
	// LIFE_BIRD ↔ body parts & actions
	{"LIFE_BIRD", "OBJ_FEATHER",    0x0A},
	{"LIFE_BIRD", "OBJ_WING",       0x0A},
	{"LIFE_BIRD", "OBJ_BEAK",       0x0A},
	{"LIFE_BIRD", "OBJ_EGG",        0x0A},
	{"LIFE_BIRD", "OBJ_NEST",       0x0A},
	{"LIFE_BIRD", "LIFE_FLY",       0x0A},
	{"LIFE_BIRD", "LIFE_SING",      0x0A},
	{"LIFE_BIRD", "PERCEPT_FLYING", 0x0A},
	{"LIFE_BIRD", "PERCEPT_SINGING",0x0A},
	{"LIFE_BIRD", "PERCEPT_BEAUTY", 0x0C},
	{"LIFE_BIRD", "PERCEPT_COLOR",  0x0C},
	{"LIFE_BIRD", "LIFE_ANIMAL",    0x09},
	// CONCEPT_DESCRIBE ↔ visual
	{"CONCEPT_DESCRIBE", "PERCEPT_IMAGE",  0x0A},
	{"CONCEPT_DESCRIBE", "PERCEPT_VISUAL", 0x0A},
	{"CONCEPT_DESCRIBE", "PERCEPT_COLOR",  0x0C},
	{"CONCEPT_DESCRIBE", "LIFE_DESCRIBE",  0x09},
	// CONCEPT_NARRATE ↔ story
	{"CONCEPT_NARRATE", "CONCEPT_STORY",   0x0A},
	{"CONCEPT_NARRATE", "LIFE_NARRATE",    0x09},
	{"LIFE_NARRATE",    "CONCEPT_STORY",   0x0A},
	// perception chains
	{"PERCEPT_IMAGE",   "PERCEPT_VISUAL",  0x0C},
	{"PERCEPT_IMAGE",   "PERCEPT_COLOR",   0x0C},
	{"PERCEPT_SINGING", "PERCEPT_SOUND",   0x09},
	{"PERCEPT_FLYING",  "OBJ_WING",        0x0C},
	{"OBJ_WING",        "LIFE_FLY",        0x0A},
	{"CONCEPT_STORY",   "LIFE_CURIOSITY",  0x0C},
	// SKILL nodes ↔ context
	{"SKILL_USER_INPUT_WATCH",  "SKILL_LEARN_FIRE",   0x09},
	{"SKILL_KNOWLEDGE_FORWARD", "SKILL_ROUTE",        0x09},
	{"SKILL_HOME_CHIEF",        "SKILL_ROUTE",        0x09},
	{"SKILL_VISION",            "PROG_SDF",           0x0A},
	{"SKILL_AUDIO",             "PERCEPT_SOUND",      0x0A},
}

// ─────────────────────────────────────────────────────────────

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	if string(raw[:4]) != "OLNG" { log.Fatal("bad magic") }

	fmt.Printf("○ Bắt đầu: %d nodes, %d edges, %d bytes\n",
		be32(raw[12:16]), be32(raw[16:20]), len(raw))

	// ── BƯỚC 1: Xóa garbage nodes ─────────────────────────────
	raw, nDeleted := deleteNodes(raw, garbageNames)
	fmt.Printf("✂  Đã xóa: %d garbage nodes\n", nDeleted)

	// ── BƯỚC 2: Thêm nodes mới ────────────────────────────────
	existing := readNames(raw)
	nAdded := 0
	for _, d := range newNodes {
		if existing[d.name] {
			fmt.Printf("   skip %-28s (đã có)\n", d.name)
			continue
		}
		isl := nodeISL(d.name, d.layer)
		rec := buildRecord(d.layer, isl, []byte(d.dna), d.name)
		raw  = insertNode(raw, rec)
		existing[d.name] = true
		fmt.Printf("  +L%d  %-28s\n", d.layer, d.name)
		nAdded++
	}
	fmt.Printf("✚  Đã thêm: %d nodes\n", nAdded)

	// ── BƯỚC 3: Thêm edges ────────────────────────────────────
	nameToISL := readNameToISL(raw)
	existEdges := readEdges(raw)
	nEdgesAdded := 0
	for _, e := range newEdges {
		src, ok1 := nameToISL[e.from]
		dst, ok2 := nameToISL[e.to]
		if !ok1 { fmt.Printf("   edge MISS src %s\n", e.from); continue }
		if !ok2 { fmt.Printf("   edge MISS dst %s\n", e.to);   continue }
		key := edgeKey(src, dst, e.typ)
		if existEdges[key] { continue }
		raw = appendEdge(raw, src, dst, e.typ)
		existEdges[key] = true
		nEdgesAdded++
	}
	fmt.Printf("✚  Đã thêm: %d edges\n", nEdgesAdded)

	// ── BƯỚC 4: Cập nhật SHA256 đúng offset ──────────────────
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])

	// ── BƯỚC 5: Ghi file atomic ───────────────────────────────
	tmp := filePath + ".tmp"
	if err := os.WriteFile(tmp, raw, 0644); err != nil { log.Fatal(err) }
	if err := os.Rename(tmp, filePath); err != nil { log.Fatal(err) }

	fmt.Printf("\n✅ Kết quả: %d nodes, %d edges, %d bytes\n",
		be32(raw[12:16]), be32(raw[16:20]), len(raw))
}

// ─── deleteNodes: xóa nodes theo tên, giữ edges nguyên ──────

func deleteNodes(raw []byte, names map[string]bool) ([]byte, int) {
	nedges  := int(be32(raw[16:20]))
	edgeEnd := len(raw)
	nodeEnd := edgeEnd - nedges*17

	out := make([]byte, 0, len(raw))
	out  = append(out, raw[:layerIdxEnd]...) // header + layer index

	deleted := 0
	i := layerIdxEnd
	for i < nodeEnd {
		if i+2 < len(raw) && raw[i] == 'N' && raw[i+1] == 'D' {
			dl := int(be32(raw[i+15:i+19]))
			nl := int(raw[i+19])
			nameStart := i + 20 + dl
			nameEnd   := nameStart + nl
			if nameEnd > nodeEnd { break }
			name := string(raw[nameStart:nameEnd])
			recEnd := nameEnd
			if names[name] {
				deleted++
				i = recEnd
				continue
			}
			out = append(out, raw[i:recEnd]...)
			i = recEnd
		} else {
			out = append(out, raw[i])
			i++
		}
	}

	// Append edge table
	out = append(out, raw[nodeEnd:edgeEnd]...)

	// Update nnodes
	newCount := be32(raw[12:16]) - uint32(deleted)
	out[12] = byte(newCount >> 24)
	out[13] = byte(newCount >> 16)
	out[14] = byte(newCount >> 8)
	out[15] = byte(newCount)

	return out, deleted
}

// ─── insertNode: chèn record trước edge table ───────────────

func insertNode(raw []byte, rec []byte) []byte {
	nedges  := int(be32(raw[16:20]))
	edgeEnd := len(raw)
	nodeEnd := edgeEnd - nedges*17

	out := make([]byte, 0, len(raw)+len(rec))
	out  = append(out, raw[:nodeEnd]...)
	out  = append(out, rec...)
	out  = append(out, raw[nodeEnd:]...)

	// Update nnodes
	n := be32(out[12:16]) + 1
	out[12] = byte(n >> 24); out[13] = byte(n >> 16)
	out[14] = byte(n >> 8);  out[15] = byte(n)
	return out
}

// ─── appendEdge: thêm edge vào cuối ────────────────────────

func appendEdge(raw []byte, src, dst [8]byte, typ uint8) []byte {
	edge := make([]byte, 17)
	copy(edge[:8], src[:]); copy(edge[8:16], dst[:]); edge[16] = typ
	out := append(raw, edge...)
	n := be32(out[16:20]) + 1
	out[16] = byte(n>>24); out[17] = byte(n>>16); out[18] = byte(n>>8); out[19] = byte(n)
	return out
}

// ─── buildRecord ────────────────────────────────────────────

func buildRecord(layer uint8, isl [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 2+1+8+4+4+1+len(dna)+len(nb))
	p := 0
	rec[p]='N'; p++; rec[p]='D'; p++; rec[p]=layer; p++
	copy(rec[p:], isl[:]); p+=8
	// codepoint = 0
	p+=4
	// dnaLen
	rec[p]=byte(len(dna)>>24); rec[p+1]=byte(len(dna)>>16)
	rec[p+2]=byte(len(dna)>>8); rec[p+3]=byte(len(dna)); p+=4
	rec[p]=uint8(len(nb)); p++
	copy(rec[p:], dna); p+=len(dna)
	copy(rec[p:], nb)
	return rec
}

// ─── nodeISL: deterministic từ name+layer ───────────────────

func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0] = layer
	isl[1] = h[0]%200 + 1
	isl[2] = h[1]%200 + 1
	isl[3] = h[2]%200 + 1
	isl[4] = h[3]; isl[5] = h[4]; isl[6] = h[5]; isl[7] = h[6]
	return isl
}

// ─── helpers ─────────────────────────────────────────────────

func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	end    := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end {
		if raw[i]=='N' && raw[i+1]=='D' {
			dl := int(be32(raw[i+15:i+19]))
			nl := int(raw[i+19])
			ns := i + 20 + dl
			ne := ns + nl
			if ne > end { break }
			m[string(raw[ns:ne])] = true
			i = ne
		} else { i++ }
	}
	return m
}

func readNameToISL(raw []byte) map[string][8]byte {
	m := map[string][8]byte{}
	nedges := int(be32(raw[16:20]))
	end    := len(raw) - nedges*17
	i := layerIdxEnd
	for i < end {
		if raw[i]=='N' && raw[i+1]=='D' {
			var isl [8]byte
			copy(isl[:], raw[i+3:i+11])
			dl := int(be32(raw[i+15:i+19]))
			nl := int(raw[i+19])
			ns := i+20+dl; ne := ns+nl
			if ne > end { break }
			m[string(raw[ns:ne])] = isl
			i = ne
		} else { i++ }
	}
	return m
}

func readEdges(raw []byte) map[string]bool {
	m := map[string]bool{}
	nedges := int(be32(raw[16:20]))
	start  := len(raw) - nedges*17
	for i := start; i+17 <= len(raw); i += 17 {
		var s, d [8]byte
		copy(s[:], raw[i:i+8]); copy(d[:], raw[i+8:i+16])
		m[edgeKey(s,d,raw[i+16])] = true
	}
	return m
}

func edgeKey(s, d [8]byte, t uint8) string {
	return fmt.Sprintf("%x:%x:%02x", s, d, t)
}

func be32(b []byte) uint32 {
	return binary.BigEndian.Uint32(b)
}
