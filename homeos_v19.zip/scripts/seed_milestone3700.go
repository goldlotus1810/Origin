//go:build ignore

// scripts/seed_milestone3700.go — MILESTONE 3700
// Domains: PSYCH2_ SOCIO2_ ECON2_ LAW2_ MEDIA2_
//          SPORT4_ GAME3_ DESIGN4_ FASHION2_ CRAFT2_
//          ASTRO2_ GEOLOGY2_ CLIMATE3_ ECOLOGY2_ BOTANY2_
//          MEDIC2_ SURGERY_ PHARMA2_ MENTAL2_ NUTRI2_
//          HIST5_ RELIG2_ MYTH2_ ARCH2_ MUSEUM_
//          VNTECH_ VNENV_ VNSPORT_ VNFILM_ VNPAINT_
//          OLANG2_ VSDF2_ ISL2_ AGENT2_ HOMEOSYS_

package main

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"log"
	"os"
)

const filePath    = "homeos.olang"
const layerIdxEnd = 64 + 9*24

func main() {
	raw, err := os.ReadFile(filePath)
	if err != nil { log.Fatal(err) }
	fmt.Printf(" start: %d nodes\n\n", be32(raw[12:16]))
	existing := readNames(raw)

	type nodeDef struct { name string; layer uint8; dna string }
	nodes := []nodeDef{

		// ── PSYCHOLOGY 2 (PSYCH2_) ──────────────────────────────────
		{"PSYCH2_TRAUMA",         3, `label=chấn thương tâm lý|desc=trauma PTSD ACE adverse childhood experience polyvagal theory Porges window of tolerance somatic experiencing EMDR|vi=chấn thương tâm lý,trauma PTSD|en=trauma psychology`},
		{"PSYCH2_ATTACHMENT",     3, `label=lý thuyết gắn bó|desc=attachment theory Bowlby Ainsworth secure anxious avoidant disorganized internal working model adult romantic relationship|vi=lý thuyết gắn bó,attachment theory|en=attachment theory`},
		{"PSYCH2_POSITIVE",       3, `label=tâm lý học tích cực|desc=positive psychology Seligman PERMA flourishing character strength VIA flow Csikszentmihalyi authentic happiness|vi=tâm lý học tích cực,positive psychology|en=positive psychology`},
		{"PSYCH2_MOTIVATION",     3, `label=động lực và tự quyết|desc=self-determination theory Deci Ryan intrinsic extrinsic autonomy competence relatedness Maslow hierarchy drive|vi=động lực và tự quyết,motivation SDT|en=self-determination theory`},
		{"PSYCH2_PERSONALITY",    3, `label=tính cách Big Five|desc=Big Five personality OCEAN openness conscientiousness extraversion agreeableness neuroticism MBTI criticism trait|vi=tính cách Big Five,Big Five|en=Big Five personality`},

		// ── SOCIOLOGY 2 (SOCIO2_) ───────────────────────────────────
		{"SOCIO2_NETWORK",        3, `label=mạng xã hội và cấu trúc|desc=social network analysis SNA centrality betweenness clustering six degrees small world Watts Strogatz Barabasi|vi=mạng xã hội và cấu trúc,social network analysis|en=social network analysis`},
		{"SOCIO2_INEQUALITY",     3, `label=bất bình đẳng xã hội|desc=inequality Gini coefficient Lorenz curve wealth gap Piketty Capital intersectionality race class gender mobility|vi=bất bình đẳng xã hội,inequality|en=social inequality`},
		{"SOCIO2_COLLECTIVE",     3, `label=hành động tập thể|desc=collective action Olson free rider problem coordination game theory common pool resource Ostrom governance|vi=hành động tập thể,collective action|en=collective action`},
		{"SOCIO2_DEVIANCE",       3, `label=lệch chuẩn xã hội|desc=deviance labeling theory Becker outsiders stigma strain theory Merton anomie social control Durkheim suicide|vi=lệch chuẩn xã hội,deviance sociology|en=social deviance`},
		{"SOCIO2_MIGRATION",      3, `label=di cư và di dân|desc=migration push pull factor refugee diaspora remittance integration acculturation transnationalism brain drain|vi=di cư và di dân,migration|en=migration`},

		// ── ECONOMICS 2 (ECON2_) ────────────────────────────────────
		{"ECON2_BEHAVIORAL",      3, `label=kinh tế học hành vi|desc=behavioral economics Thaler Sunstein nudge bounded rationality loss aversion hyperbolic discounting present bias|vi=kinh tế học hành vi,behavioral economics|en=behavioral economics`},
		{"ECON2_DEVELOPMENT",     3, `label=kinh tế phát triển|desc=development economics Amartya Sen capability approach HDI poverty trap Sachs debt relief microfinance|vi=kinh tế phát triển,development economics|en=development economics`},
		{"ECON2_GAME_THEORY",     3, `label=lý thuyết trò chơi kinh tế|desc=game theory Nash equilibrium prisoner dilemma dominant strategy cooperative signaling auction mechanism design|vi=lý thuyết trò chơi kinh tế,game theory economics|en=game theory economics`},
		{"ECON2_MONETARY",        3, `label=chính sách tiền tệ|desc=monetary policy central bank interest rate QE quantitative easing Taylor rule inflation targeting Fed ECB|vi=chính sách tiền tệ,monetary policy|en=monetary policy`},
		{"ECON2_TRADE",           3, `label=thương mại quốc tế|desc=international trade comparative advantage Ricardo Heckscher-Ohlin WTO tariff trade deficit surplus FTA|vi=thương mại quốc tế,international trade|en=international trade`},

		// ── LAW 2 (LAW2_) ───────────────────────────────────────────
		{"LAW2_CONSTITUTION",     3, `label=luật hiến pháp|desc=constitutional law separation of powers judicial review Marbury Madison fundamental rights amendment federalism|vi=luật hiến pháp,constitutional law|en=constitutional law`},
		{"LAW2_CONTRACT",         3, `label=luật hợp đồng|desc=contract law offer acceptance consideration breach specific performance damages force majeure frustration|vi=luật hợp đồng,contract law|en=contract law`},
		{"LAW2_IP",               3, `label=sở hữu trí tuệ|desc=intellectual property patent copyright trademark trade secret fair use WIPO TRIPS digital copyright DMCA|vi=sở hữu trí tuệ,intellectual property|en=intellectual property`},
		{"LAW2_INTL",             3, `label=luật quốc tế|desc=international law treaty customary ICJ ICC UN Charter sovereignty R2P humanitarian law Geneva Convention|vi=luật quốc tế,international law|en=international law`},
		{"LAW2_DATA",             3, `label=luật bảo vệ dữ liệu|desc=data protection law GDPR CCPA personal data controller processor consent right to erasure privacy by design|vi=luật bảo vệ dữ liệu,data protection|en=data protection law`},

		// ── MEDIA & COMMUNICATION (MEDIA2_) ─────────────────────────
		{"MEDIA2_JOURNALISM",     3, `label=báo chí và truyền thông|desc=journalism fourth estate investigative data journalism fact-checking misinformation deepfake media literacy|vi=báo chí và truyền thông,journalism|en=journalism`},
		{"MEDIA2_SOCIAL",         3, `label=mạng xã hội kỹ thuật số|desc=social media algorithm filter bubble echo chamber engagement bait outrage addiction TikTok algorithm|vi=mạng xã hội kỹ thuật số,social media|en=social media`},
		{"MEDIA2_NARRATIVE",      3, `label=tường thuật và kể chuyện|desc=narrative structure hero's journey Campbell three act screenplay plot character arc conflict resolution|vi=tường thuật và kể chuyện,narrative storytelling|en=narrative storytelling`},
		{"MEDIA2_PODCAST",        3, `label=podcast và audio|desc=podcast RSS Spotify Apple dynamic ad insertion show notes transcript accessibility monetization audience|vi=podcast và audio,podcast|en=podcast`},
		{"MEDIA2_GAME_DESIGN",    3, `label=thiết kế game|desc=game design mechanics dynamics aesthetics MDA framework Schell lens fun flow state intrinsic reward game feel|vi=thiết kế game,game design|en=game design`},

		// ── SPORT 4 (SPORT4_) ───────────────────────────────────────
		{"SPORT4_SPORTS_SCIENCE", 3, `label=khoa học thể thao|desc=sports science VO2max lactate threshold periodization HRV recovery adaptation overtraining syndrome altitude|vi=khoa học thể thao,sports science|en=sports science`},
		{"SPORT4_ESPORT",         3, `label=thể thao điện tử|desc=esport competitive gaming League of Legends Dota2 CS2 tournament prize pool reaction time APM mental performance|vi=thể thao điện tử,esport|en=esport`},
		{"SPORT4_MARTIAL_ARTS",   3, `label=võ thuật|desc=martial arts philosophy wrestling boxing BJJ muay thai judo aikido Krav Maga self defense mental discipline|vi=võ thuật,martial arts|en=martial arts`},
		{"SPORT4_ANALYTICS",      3, `label=phân tích thể thao|desc=sports analytics Moneyball sabermetrics expected goals xG tracking data Statsbomb Opta heat map press|vi=phân tích thể thao,sports analytics|en=sports analytics`},
		{"SPORT4_CLIMBING",       3, `label=leo núi|desc=rock climbing bouldering sport trad lead free solo Alex Honnold El Capitan technique footwork mental game training|vi=leo núi,rock climbing|en=rock climbing`},

		// ── BOTANY 2 (BOTANY2_) ─────────────────────────────────────
		{"BOTANY2_PHOTOSYN",      3, `label=quang hợp chi tiết|desc=photosynthesis C3 C4 CAM Calvin cycle light reaction Z scheme chlorophyll carotenoid photorespiration|vi=quang hợp chi tiết,photosynthesis detail|en=photosynthesis detail`},
		{"BOTANY2_TROPISM",       3, `label=hướng động thực vật|desc=tropism phototropism gravitropism thigmotropism auxin distribution Darwin Went experiment hormone signal|vi=hướng động thực vật,plant tropism|en=plant tropism`},
		{"BOTANY2_MEDICINAL",     3, `label=cây thuốc dân gian|desc=medicinal plants ethnobotany artemisinin willow bark aspirin morphine taxol vinblastine secondary metabolites|vi=cây thuốc dân gian,medicinal plants|en=medicinal plants`},
		{"BOTANY2_SEED",          3, `label=hạt giống và nảy mầm|desc=seed dispersal germination dormancy imbibition radicle cotyledon Svalbard Global Seed Vault crop diversity|vi=hạt giống và nảy mầm,seed germination|en=seed germination`},
		{"BOTANY2_CARNIVORE",     3, `label=cây bắt côn trùng|desc=carnivorous plant Venus flytrap Nepenthes Drosera Utricularia nutrient-poor soil nitrogen trap mechanism|vi=cây bắt côn trùng,carnivorous plants|en=carnivorous plants`},

		// ── MEDICINE 2 (MEDIC2_) ────────────────────────────────────
		{"MEDIC2_CARDIO",         3, `label=tim mạch học|desc=cardiology EKG echocardiogram coronary artery disease MI stent CABG heart failure ejection fraction atrial fibrillation|vi=tim mạch học,cardiology|en=cardiology`},
		{"MEDIC2_NEURO",          3, `label=thần kinh học lâm sàng|desc=clinical neurology stroke TIA dementia Parkinson epilepsy multiple sclerosis MRI CT angiography|vi=thần kinh học lâm sàng,clinical neurology|en=clinical neurology`},
		{"MEDIC2_ONCOLOGY",       3, `label=ung thư học|desc=oncology TNM staging chemotherapy targeted therapy immunotherapy CAR-T checkpoint inhibitor PD-L1 liquid biopsy|vi=ung thư học,oncology|en=oncology`},
		{"MEDIC2_INFECTIOUS",     3, `label=bệnh truyền nhiễm|desc=infectious disease R0 reproduction number herd immunity contact tracing outbreak investigation epidemiology|vi=bệnh truyền nhiễm,infectious disease|en=infectious disease`},
		{"MEDIC2_DIAGNOSTIC",     3, `label=chẩn đoán hình ảnh|desc=medical imaging X-ray CT MRI PET ultrasound contrast agent resolution sensitivity specificity radiologist|vi=chẩn đoán hình ảnh,medical imaging|en=medical imaging`},

		// ── MENTAL HEALTH 2 (MENTAL2_) ──────────────────────────────
		{"MENTAL2_CBT",           3, `label=liệu pháp nhận thức hành vi|desc=cognitive behavioral therapy CBT cognitive distortion automatic thought thought record behavioral activation Beck|vi=liệu pháp nhận thức hành vi,CBT|en=cognitive behavioral therapy`},
		{"MENTAL2_MINDFULNESS",   3, `label=chánh niệm trị liệu|desc=mindfulness MBSR Kabat-Zinn MBCT DBT ACT acceptance defusion present moment non-judgment meditation|vi=chánh niệm trị liệu,mindfulness therapy|en=mindfulness therapy`},
		{"MENTAL2_SCHIZO",        3, `label=tâm thần phân liệt|desc=schizophrenia positive negative symptoms dopamine hypothesis antipsychotic clozapine cognitive remediation recovery|vi=tâm thần phân liệt,schizophrenia|en=schizophrenia`},
		{"MENTAL2_ADDICTION",     3, `label=nghiện và phục hồi|desc=addiction dopamine reward circuit tolerance withdrawal motivational interviewing 12 steps harm reduction MAT|vi=nghiện và phục hồi,addiction recovery|en=addiction recovery`},
		{"MENTAL2_GRIEF",         3, `label=đau buồn và mất mát|desc=grief Kubler-Ross five stages denial anger bargaining depression acceptance complicated grief meaning-making|vi=đau buồn và mất mát,grief|en=grief`},

		// ── HISTORY 5 (HIST5_) ──────────────────────────────────────
		{"HIST5_OTTOMAN",         3, `label=đế quốc Ottoman|desc=Ottoman Empire 1299-1922 Suleiman Magnificent Constantinople 1453 Janissary devshirme millet system decline|vi=đế quốc Ottoman,Ottoman Empire|en=Ottoman Empire`},
		{"HIST5_COLD_WAR",        3, `label=chiến tranh lạnh|desc=Cold War Truman Doctrine Marshall Plan Berlin Wall Cuban Missile Crisis arms race space race détente fall 1989|vi=chiến tranh lạnh,Cold War|en=Cold War`},
		{"HIST5_INDUSTRIAL",      3, `label=cách mạng công nghiệp|desc=Industrial Revolution steam engine Watt factory system child labor urbanization Engels Marx class bourgeoisie|vi=cách mạng công nghiệp,Industrial Revolution|en=Industrial Revolution`},
		{"HIST5_RENAISSANCE",     3, `label=Phục Hưng|desc=Renaissance 14th-17th century Florence Medici Leonardo da Vinci Michelangelo humanism perspective printing press|vi=Phục Hưng,Renaissance|en=Renaissance`},
		{"HIST5_DECOLONIAL",      3, `label=tư tưởng hậu thực dân|desc=postcolonial theory Frantz Fanon Wretched of Earth Said Orientalism subaltern Spivak Bhabha hybridity|vi=tư tưởng hậu thực dân,postcolonial theory|en=postcolonial theory`},

		// ── RELIGION 2 (RELIG2_) ────────────────────────────────────
		{"RELIG2_HINDUISM",       3, `label=Ấn Độ giáo|desc=Hinduism Brahman Atman dharma karma samsara moksha Vedas Upanishads Bhagavad Gita caste yoga tantra|vi=Ấn Độ giáo,Hinduism|en=Hinduism`},
		{"RELIG2_ABRAHAMIC",      3, `label=các tôn giáo Abraham|desc=Abrahamic religions Judaism Christianity Islam shared lineage prophets scripture monotheism covenant difference|vi=các tôn giáo Abraham,Abrahamic religions|en=Abrahamic religions`},
		{"RELIG2_ANIMISM",        3, `label=vạn vật hữu linh|desc=animism spirit natural world indigenous belief shamanism totem ancestor worship nature sacred trance ritual|vi=vạn vật hữu linh,animism|en=animism`},
		{"RELIG2_SECULAR",        3, `label=chủ nghĩa thế tục|desc=secularism separation church state Enlightenment atheism agnosticism humanism secular ethics public reason|vi=chủ nghĩa thế tục,secularism|en=secularism`},
		{"RELIG2_NEW_AGE",        3, `label=tâm linh mới|desc=New Age spirituality crystal healing astrology chakra energy healing mindfulness commodification wellness industry|vi=tâm linh mới,New Age spirituality|en=New Age spirituality`},

		// ── VIETNAM TECH (VNTECH_) ──────────────────────────────────
		{"VNTECH_STARTUP_SCENE",  3, `label=hệ sinh thái khởi nghiệp Việt|desc=Vietnam startup ecosystem VNG MoMo VNPay Tiki Sky Mavis Axie Infinity HCMC Hanoi unicorn|vi=hệ sinh thái khởi nghiệp Việt,Vietnam startup|en=Vietnam startup ecosystem`},
		{"VNTECH_VNPAY",          3, `label=thanh toán điện tử Việt Nam|desc=Vietnam digital payment VNPay MoMo ZaloPay banking fintech QR code cashless government push|vi=thanh toán điện tử Việt Nam,Vietnam digital payment|en=Vietnam digital payment`},
		{"VNTECH_IT_OUTSOURCE",   3, `label=gia công phần mềm Việt|desc=Vietnam IT outsourcing FPT Software TMA Harvey Nash NashTech nearshore Japan Korea talent cost|vi=gia công phần mềm Việt,Vietnam IT outsourcing|en=Vietnam IT outsourcing`},
		{"VNTECH_CHIP",           3, `label=công nghiệp chip Việt Nam|desc=Vietnam semiconductor Intel HCMC packaging assembly test Samsung electronics FDI talent training|vi=công nghiệp chip Việt Nam,Vietnam semiconductor|en=Vietnam semiconductor`},
		{"VNTECH_DIGITAL_GOV",    3, `label=chính phủ số Việt Nam|desc=Vietnam digital government VNeID Cổng dịch vụ công quốc gia chuyển đổi số 2025 Bộ TT&TT smart city|vi=chính phủ số Việt Nam,Vietnam digital government|en=Vietnam digital government`},

		// ── VIETNAM ENVIRONMENT (VNENV_) ────────────────────────────
		{"VNENV_MEKONG",          3, `label=đồng bằng sông Cửu Long|desc=Mekong Delta 9 rivers rice bowl Vietnam climate threat sea level rise saltwater intrusion dam upstream|vi=đồng bằng sông Cửu Long,Mekong Delta|en=Mekong Delta Vietnam`},
		{"VNENV_COAST",           3, `label=bờ biển Việt Nam|desc=Vietnam coastline 3260km mangrove coral reef seagrass fishery pollution plastic tourism pressure|vi=bờ biển Việt Nam,Vietnam coastline|en=Vietnam coastline`},
		{"VNENV_AIR",             3, `label=ô nhiễm không khí Việt Nam|desc=Vietnam air pollution HCMC Hanoi PM2.5 coal power motorbike traffic inversion winter health lung|vi=ô nhiễm không khí Việt Nam,Vietnam air pollution|en=Vietnam air pollution`},
		{"VNENV_FOREST",          3, `label=rừng Việt Nam|desc=Vietnam forest coverage deforestation reforestation Tây Nguyên Central Highlands biodiversity REDD+ illegal logging|vi=rừng Việt Nam,Vietnam forest|en=Vietnam forest`},
		{"VNENV_ENERGY_TRANS",    3, `label=chuyển dịch năng lượng Việt|desc=Vietnam energy transition solar wind PDP8 Just Energy Transition coal phase-out RE target 2030 2050|vi=chuyển dịch năng lượng Việt,Vietnam energy transition|en=Vietnam energy transition`},

		// ── VIETNAM FILM & VISUAL ARTS (VNFILM_) ────────────────────
		{"VNFILM_TRUOC_1975",     3, `label=điện ảnh Việt trước 1975|desc=điện ảnh Việt Nam Con chim vành khuyên Chị Tư Hậu Vĩ tuyến 17 ngày đêm kháng chiến phim tài liệu|vi=điện ảnh Việt trước 1975,Vietnamese pre-1975 film|en=Vietnamese pre-1975 film`},
		{"VNFILM_DOI_MOI",        3, `label=điện ảnh Đổi Mới|desc=điện ảnh Đổi Mới Thương nhớ đồng quê Mùa ổi Mùa len trâu Bùi Thạc Chuyên Đặng Nhật Minh phim nghệ thuật|vi=điện ảnh Đổi Mới,Vietnamese Doi Moi film|en=Vietnamese Doi Moi film`},
		{"VNFILM_MODERN",         3, `label=điện ảnh Việt hiện đại|desc=điện ảnh Việt hiện đại Bố già Nhà bà Nữ Lật mặt Trấn Thành Victor Vũ phòng vé tỷ đồng Việt kiều|vi=điện ảnh Việt hiện đại,modern Vietnamese film|en=modern Vietnamese film`},
		{"VNFILM_LACQUER",        3, `label=tranh sơn mài Việt Nam|desc=tranh sơn mài Việt Nam kỹ thuật lacquer Trường Mỹ thuật Đông Dương Nguyễn Gia Trí lớp phủ bóng màu|vi=tranh sơn mài Việt Nam,Vietnamese lacquer painting|en=Vietnamese lacquer painting`},
		{"VNFILM_DONG_HO",        3, `label=tranh Đông Hồ|desc=tranh Đông Hồ Bắc Ninh điệp giấy dó khắc gỗ gà lợn đám cưới chuột đề tài dân gian UNESCO ứng viên|vi=tranh Đông Hồ,Dong Ho painting|en=Dong Ho folk painting`},

		// ── HomeOS SYSTEM SELF-KNOWLEDGE (HOMEOSYS_) ────────────────
		// Đây là nodes mô tả chính bản thân hệ thống — quan trọng
		{"HOMEOSYS_VSDF",         7, `label=vSDF — Signed Distance Fields|desc=vSDF evaluate SDF primitives trực tiếp tại điểm p KHÔNG march rays SDFSphere SDFCapsule SDFBox SmoothUnion ISLAddr gắn vào result|vi=vSDF,signed distance field|en=vSDF primitives`},
		{"HOMEOSYS_ISL_STREAM",   7, `label=ISLStream binary DNA|desc=ISLStream 20B/token Token{ISLAddr+TokenType+float64} Streamable interface encode decode round-trip WorldScene snapshot|vi=ISLStream,ISL stream|en=ISLStream DNA`},
		{"HOMEOSYS_NODE_REG",     7, `label=NodeRegistry|desc=NodeRegistry name→ISLAddr 50 nodes 0 xung đột Lookup MustLookup AllEntries Op/World/Physics/Sensor/Know/Agent layers|vi=NodeRegistry,node registry|en=NodeRegistry`},
		{"HOMEOSYS_WORLD_SCENE",  7, `label=WorldScene|desc=WorldScene Sun Earth Creature GravityEdge WorldClock Tick SpatialNodes ProbeGrid EvalAt vSDF bridge Snapshot ISLStream|vi=WorldScene,world scene|en=WorldScene`},
		{"HOMEOSYS_SILK_TREE",    7, `label=Silk Web Tree|desc=Silk Tree append-only ED25519 THÂN CÀNH NHÁNH LÁ tơ semantic link UTF-32 tìm kiếm địa chỉ không scan toàn bộ|vi=Silk Web Tree,silk tree|en=Silk Web Tree`},
		{"HOMEOSYS_ORIGIN",       7, `label=○ Origin — nền tảng|desc=○ identity idempotent QT1-QT7 SDF ISL hữu hình vô hình ĐN QR vòng đời tri thức Skill Agent bất biến|vi=○ Origin,Origin foundation|en=Origin foundation`},
		{"HOMEOSYS_SECURITY",     7, `label=SecurityGate 🛡|desc=SecurityGate Rule1 không hại người Rule2 không vòng lặp vô hạn Rule3 không xóa bất biến chạy trước mọi thứ|vi=SecurityGate,security gate|en=SecurityGate`},
		{"HOMEOSYS_LEOAI",        7, `label=LeoAI — bộ não học|desc=LeoAI NCA Dendrites ShortTerm Axon LongTerm Dreaming cluster commit QR vòng N×T chu kỳ vi mô vĩ mô|vi=LeoAI,LeoAI brain|en=LeoAI NCA`},
		{"HOMEOSYS_AAM",          7, `label=AAM — điều phối viên|desc=AAM Decide4D Broadcast SecurityGate stateless User→AAM→Chief→Worker phân cấp không bỏ qua tầng|vi=AAM,AAM agent|en=AAM orchestrator`},
		{"HOMEOSYS_OLANG",        7, `label=○lang — ngôn ngữ bản thể|desc=○lang 12B/symbol opTable 48 entries UTF-32 mượn không đọc SDF ISL Spline Gene binary stream|vi=○lang,olang language|en=olang language`},

		// ── MYTHOLOGY 2 (MYTH2_) ────────────────────────────────────
		{"MYTH2_CREATION",        3, `label=thần thoại sáng tạo|desc=creation myth cosmogony ex nihilo Enuma Elish Genesis Popol Vuh Dreamtime Pangu Ymir comparative mythology|vi=thần thoại sáng tạo,creation myth|en=creation myth`},
		{"MYTH2_HERO",            3, `label=hành trình anh hùng|desc=hero's journey Campbell monomyth departure initiation return ordinary world call threshold mentor transformation|vi=hành trình anh hùng,hero's journey|en=hero's journey`},
		{"MYTH2_TRICKSTER",       3, `label=nhân vật lừa đảo thần thoại|desc=trickster myth Loki Coyote Anansi Hermes chaos order boundary culture hero subversion wisdom|vi=nhân vật lừa đảo thần thoại,trickster myth|en=trickster myth`},
		{"MYTH2_FLOOD",           3, `label=thần thoại lũ lụt|desc=flood myth Noah Gilgamesh Manu Deucalion universal distribution oral tradition geological memory catastrophe|vi=thần thoại lũ lụt,flood myth|en=flood myth`},
		{"MYTH2_AFTERLIFE",       3, `label=thế giới sau cái chết|desc=afterlife myth underworld Hades Duat Hel Naraka Tir na nOg soul judgment resurrection reincarnation|vi=thế giới sau cái chết,afterlife myth|en=afterlife myth`},

		// ── ARCHITECTURE 2 (ARCH2_) ─────────────────────────────────
		{"ARCH2_MODERNISM",       3, `label=kiến trúc hiện đại|desc=modernist architecture Le Corbusier Mies van der Rohe Bauhaus form follows function less is more international style|vi=kiến trúc hiện đại,modernist architecture|en=modernist architecture`},
		{"ARCH2_PARAMETRIC",      3, `label=kiến trúc tham số|desc=parametric architecture Zaha Hadid Gehry Calatrava algorithm Grasshopper Rhino BIM computational form generation|vi=kiến trúc tham số,parametric architecture|en=parametric architecture`},
		{"ARCH2_VERNACULAR",      3, `label=kiến trúc bản địa|desc=vernacular architecture climate response local material passive cooling wind tower earthen cave dwelling|vi=kiến trúc bản địa,vernacular architecture|en=vernacular architecture`},
		{"ARCH2_SACRED",          3, `label=kiến trúc thánh|desc=sacred architecture proportion golden ratio Chartres Gothic Pantheon Angkor Wat Hagia Sophia light symbolism|vi=kiến trúc thánh,sacred architecture|en=sacred architecture`},
		{"ARCH2_BIOPHILIC",       3, `label=kiến trúc sinh thái|desc=biophilic design nature connection Terrapin Bright Green living wall daylight view material natural pattern|vi=kiến trúc sinh thái,biophilic design|en=biophilic design`},

		// ── NUTRITION 2 (NUTRI2_) ───────────────────────────────────
		{"NUTRI2_MICRO",          3, `label=vi chất dinh dưỡng|desc=micronutrients vitamins minerals deficiency iron folate B12 iodine zinc vitamin D A scurvy rickets goiter|vi=vi chất dinh dưỡng,micronutrients|en=micronutrients`},
		{"NUTRI2_PLANT_BASED",    3, `label=chế độ ăn thực vật|desc=plant-based diet whole food vegan vegetarian cardiovascular cancer microbiome complete protein B12 supplement|vi=chế độ ăn thực vật,plant-based diet|en=plant-based diet`},
		{"NUTRI2_FASTING",        3, `label=nhịn ăn gián đoạn|desc=intermittent fasting 16:8 5:2 OMAD autophagy mTOR insulin metabolic health circadian alignment evidence|vi=nhịn ăn gián đoạn,intermittent fasting|en=intermittent fasting`},
		{"NUTRI2_FOOD_SYSTEM",    3, `label=hệ thống thực phẩm|desc=food system supply chain food desert food security loss waste SDG2 zero hunger urban agriculture vertical farm|vi=hệ thống thực phẩm,food system|en=food system`},
		{"NUTRI2_EPIGENETIC",     3, `label=dinh dưỡng biểu sinh|desc=nutritional epigenetics methyl donor folate SAM histone acetylation transgenerational Dutch Hunger Winter|vi=dinh dưỡng biểu sinh,nutritional epigenetics|en=nutritional epigenetics`},
	}

	added, skipped := 0, 0
	for _, nd := range nodes {
		if existing[nd.name] { skipped++; continue }
		islv := nodeISL(nd.name, nd.layer)
		raw = insertNode(raw, buildRecord(nd.layer, islv, []byte(nd.dna), nd.name))
		existing[nd.name] = true; added++
	}
	fmt.Printf(" %d nodes (skip %d)\n", added, skipped)
	h := sha256.Sum256(raw[layerIdxEnd:])
	copy(raw[28:60], h[:])
	os.WriteFile(filePath+".tmp", raw, 0644)
	os.Rename(filePath+".tmp", filePath)
	nn := be32(raw[12:16])
	fmt.Printf(" %d nodes\n", nn)
	if nn >= 3700 { fmt.Println(" MILESTONE 3700! 🎉") }
}

func buildRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name); if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0]='N'; rec[1]='D'; rec[2]=layer; copy(rec[3:], islv[:])
	rec[15]=byte(len(dna)>>24); rec[16]=byte(len(dna)>>16)
	rec[17]=byte(len(dna)>>8); rec[18]=byte(len(dna)); rec[19]=uint8(len(nb))
	copy(rec[20:], dna); copy(rec[20+len(dna):], nb); return rec
}
func nodeISL(name string, layer uint8) [8]byte {
	h := sha256.Sum256([]byte(name)); var v [8]byte
	v[0]=layer; v[1]=h[0]%200+1; v[2]=h[1]%200+1; v[3]=h[2]%200+1
	v[4]=h[3]; v[5]=h[4]; v[6]=h[5]; v[7]=h[6]; return v
}
func insertNode(raw []byte, rec []byte) []byte {
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n := be32(out[12:16])+1
	out[12]=byte(n>>24); out[13]=byte(n>>16); out[14]=byte(n>>8); out[15]=byte(n); return out
}
func readNames(raw []byte) map[string]bool {
	m := map[string]bool{}
	ne := int(be32(raw[16:20])); end := len(raw)-ne*17; i := layerIdxEnd
	for i < end-25 {
		if raw[i]!='N' || raw[i+1]!='D' { i++; continue }
		dl := int(binary.BigEndian.Uint32(raw[i+15:i+19])); nl := int(raw[i+19])
		if dl>10000 || nl>200 { i++; continue }
		ne2 := i+20+dl+nl; if ne2>end { break }
		m[string(raw[i+20+dl:ne2])]=true; i=ne2
	}; return m
}
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
