# TRUTH.md — La bàn dự án
# Đọc file này ĐẦU TIÊN trong mọi session mới
# Append-only · Cập nhật: 2026-03-10

---

## MỤC TIÊU DUY NHẤT

```
$ olang run homeos.olang
→ Toàn bộ HomeOS chạy từ 1 file duy nhất
→ Không cần Go, JSON, HTML riêng lẻ
→ Không cần install thêm gì
```

Mọi quyết định đều phải hỏi: "Cái này có đưa chúng ta gần hơn đến mục tiêu không?"

---

## SỰ THẬT HIỆN TẠI (2026-03-10 · session 136 audit)

### homeos.olang

```
File:   861,266 bytes (841 KB)
Nodes:  4,813  (header đang sai — cần fix)
Edges:  1,412
SHA256: MISMATCH (cần fix sau mỗi seed)

L0  Primitives:    92 nodes  [QR] ← opcodes, bất biến
L1  UTF32:       1280 nodes  [QR] ← 1280 ký tự, cầu nối SDF↔ISL
L2  Nature:        45 nodes  [QR] ← nước/lửa/đất/gió/ánh sáng
L3  Life:        3062 nodes  [QR] ← tri thức đa lĩnh vực
L4  Objects:       28 nodes  [QR] ← đèn/cửa/xe/thiết bị
L5  Programming:  159 nodes  [QR] ← Go/ISL/Silk semantics
L6  Perception:    49 nodes  [QR] ← vision/audio/touch
L7  Programs:      93 nodes  [QR] ← agents, skills, worlds
L8+:                5 nodes  [ĐN] ← draft/corrupt — cần audit
```

### Node format (bất biến — KHÔNG thay đổi)

```
ND(2) + layer(1) + ISL(8) + cp(4) + dnaLen(4,BE) + nameLen(1) + dna + name
= 20 bytes header + variable payload
DNA trước name (append rule #18)
```

### Edge format

```
srcISL(8) + dstISL(8) + type(1) = 17 bytes/edge
Nằm ở CUỐI file: edge_start = len(file) - nedges*17
Header raw[16:20] = nedges (Big Endian uint32)
```

### Go runtime — đang hoạt động

```
✅ olang run homeos.olang → http://localhost:8080
✅ BUILD OK (go build ./...)
✅ 8/8 TEST PASS (go test ./...)
✅ Chat UI hoạt động (30 intents)
✅ ISL actuation pipeline: user → brain → ISL → aam → chief → worker
✅ LeoAI: DreamSkill + DreamDispatchSkill + SkillUserInputWatch
✅ AgentLoader: SpawnFromOlang() đọc AGENT_* nodes
✅ SilkWalk: depth 4, hop qua edges thật
```

### Vấn đề CRITICAL phát hiện (session 136 audit)

```
🔴 #1 — 40 Skills KHÔNG BAO GIỜ được AddSkill vào agent
   Runtime chỉ có 7 skills thực sự chạy:
     aam:        BroadcastSkill + HeartbeatSkill
     home_chief: HomeChiefSkill
     light_*:    ActuatorLight (x2)
     leoai:      DreamSkill + DreamDispatchSkill + WatchSkill
   35+ skills còn lại: tồn tại trong code, không execute

🔴 #2 — 2 pipeline song song KHÔNG biết nhau
   Pipeline A (chan-bus): NxT → bus → aam → home_chief → light
   Pipeline B (HTTP):    user → HTTP → brain.go → trực tiếp
   Khi thêm feature phải viết 2 lần

🔴 #3 — NCA commitCycle() tự promote ĐN→QR, KHÔNG qua AAM
   Vi phạm QT7 và Security Gate

🟠 #4 — 14 struct trùng định nghĩa giữa packages
   OlangNode, ExecContext, SilkEdge, ScoredNode, WalkResult...

🟠 #5 — brain.go God class: 4146 dòng, 57 methods

🟡 #6 — parseDNAKV/encodePayload/tokenize/keyToAddr bị copy-paste
   3-8 bản sao ở các files khác nhau

🟡 #7 — L8+ có 5 nodes corrupt/draft cần audit và xóa
```

### Files không nên tồn tại lâu dài

```
memory.json         → đã migrate vào homeos.olang
homeos_learner.json → đã migrate
internal/gene/      → SDF universe research, build độc lập
```

---

## RANH GIỚI RÕ RÀNG

```
Go ĐƯỢC PHÉP (bootstrap):
  ✓ Đọc/ghi homeos.olang
  ✓ Serve HTTP/WebSocket
  ✓ Parse input từ người dùng
  ✓ Thực thi DNA nodes (L0 executor)
  ✓ ISL encode/decode

Go KHÔNG ĐƯỢC (phải migrate vào .olang):
  ✗ Logic học (brain.go thật sự) → L7 nodes
  ✗ Rules (QT) → L7 nodes
  ✗ UI static → L7 nodes (đã xong)
  ✗ 40 skills hiện đang dead code

vSDF RULE (bất biến):
  KHÔNG raymarching — evaluate SDF trực tiếp
  Renderer evaluate SDF primitives tại điểm, không march rays
```

---

## QUY TẮC LÀM VIỆC (chống lạc lối)

```
1.  Mỗi session: đọc TRUTH.md TRƯỚC
2.  Mỗi thay đổi: hỏi "cái này có cần không?"
3.  Không thêm file mới nếu chưa xóa file thừa
4.  Không thêm Go logic → phải vào .olang
5.  Test: go test ./... phải PASS trước khi commit
6.  Sau thay đổi lớn: cập nhật TRUTH.md + MASTER.md
7.  Node format: DNA trước name, dnaLen Big-Endian
8.  Edge insert: tính node_section_end trước, không append cuối
9.  ISL trong edge: đọc từ file thực tế (không dùng sha256(name)[:8])
10. Single-script: nodes + edges phải trong 1 script duy nhất
11. buildDynamic: đọc layer byte trực tiếp, KHÔNG hardcode prefix map
12. vSDF: KHÔNG raymarching, evaluate SDF primitives trực tiếp
13. Header fix: sau seed → Python đếm ND thực tế → cập nhật header
```

---

## THỨ TỰ ƯU TIÊN TIẾP THEO

```
NGAY BÂY GIỜ — Fix critical:
  ① Nối 40 skills vào đúng agents (vấn đề #1)
  ② Fix NCA commitCycle() → phải qua AAM (vấn đề #3)
  ③ Gộp Resolve() — cascade 4 cấp thay 84 boilerplate (vấn đề search)

SAU ĐÓ — Design:
  ④ Nối ClusterProposal → CommitCluster (ĐN→Leaf→Twig thật)
  ⑤ Gộp parseDNAKV/tokenize/keyToAddr thành shared utils
  ⑥ Tách brain.go thành IntentHandler + QueryHandler + ActuatorHandler

DÀI HẠN:
  ⑦ Merge 2 pipeline (chan-bus + HTTP) thành 1
  ⑧ OlangNode unification (1 định nghĩa duy nhất)
  ⑨ MILESTONE 5000 nodes L3
  ⑩ Voxel SDF từ 3D mesh + SDFCharacter 3D
```

---

## LỊCH SỬ MILESTONE

```
2026-03-08: olang run homeos.olang MILESTONE ← ./olang binary duy nhất
2026-03-09: MILESTONE 3000 nodes · 22 intents
2026-03-09: SilkWalk depth 4 live (session 132)
2026-03-09: MILESTONE 6000 nodes (session 131)
2026-03-10: session 135b — cleanup 599 orphans + buildDynamic fix
2026-03-10: session 136 — FULL AUDIT: 6 vấn đề structural phát hiện
```

---

*Append-only. Chỉ được thêm vào cuối, không được xóa.*
*Cập nhật: 2026-03-10 · session 136*

---

## CẬP NHẬT SAU SESSIONS 137–142 (2026-03-10)

### Trạng thái hiện tại

```
✅ 40 Skills đã nối vào đúng agents (s137)
✅ Pipeline phân cấp: AAM → Chief → Worker qua AAMRouterSkill (s140)
✅ NCA QT7: proposeCycle() thay commitCycle() — phải qua AAM (s137)
✅ ProposalHandlerSkill: NodeHash + Cluster + Hebbian edge proposals (s138,139,141)
✅ DreamSkill thật: high-conf → QR, low-conf → archive (s140)
✅ Hebbian learning hoàn chỉnh:
   - coKey: fmt.Sprintf (fix UTF-8 bug)
   - BoostEdge cả 2 chiều A↔B
   - MsgPropose("edge|from|to") → handleEdgeProposal
   - EdgeWeightStore persist homeos.olang.weights
   - decay 24h ("neurons that stop firing together, unwire")
   - SilkWalkSkill dùng WalkWeighted (weight cao → ưu tiên)
✅ SecurityGate Rule 1 thật:
   CheckActuatorSafety: block nhiệt độ cực đoan, emergency_lock, override
✅ ClusterSkill persist → homeos.olang.clusters.olang (atomic, QT8 ✓)
✅ olang: SaveToPath + LoadFile + NewOlangFile

BUILD OK · 8/8 PASS · Commit: a925da9
```

### Backlog (chưa làm)

```
□ WeightedSilkWalk: check cả OpSimilar edges
□ HonestySkill: implement Skill interface
□ OlangFile.ReadFrom() — full round-trip read/write
□ Fix "triết học" label mismatch → PHIL_OVERVIEW
□ AuditLog persist to disk
□ Brain.LoadBook() → BookMemory
□ LANScanner thật (ARP/mDNS)
□ ScoreSearch accuracy boost — exact name token match
```

### Files quan trọng

```
cmd/olang/runtime.go   — full wire 40+ skills vào agents
internal/agents/       — tất cả skills
internal/silk/         — SilkGraph + Hebbian + EdgeWeightStore
internal/nca/nca.go    — SecurityGate với CheckActuatorSafety
SESSIONS.md            — log chi tiết từng session
```

---

*Cập nhật: 2026-03-10 — session 142*

---

## BẢN CHẤT WORKER AGENT — bất biến (session 146e)

> Đọc phần này trước khi làm bất cứ gì liên quan đến thiết bị.

### Worker KHÔNG phải "điều khiển thiết bị"

Worker **LÀ HomeOS tại vị trí thiết bị đó**. Không phải adapter, không
phải bridge — là HomeOS.

```
SAI:  Worker → gửi lệnh HTTP → thiết bị
ĐÚNG: Worker = HomeOS agent bao bọc thiết bị
              Firmware nằm BÊN TRONG tầm kiểm soát của Worker
```

### Worker làm 3 việc (bất biến)

```
① GIÁM SÁT  — chặn mọi traffic ra ngoài LAN không được HomeOS cho phép
② KIỂM SOÁT — mọi lệnh đến firmware phải qua ISL → SecurityGate
③ THAY THẾ  — nếu firmware hành xử trái phép → cô lập → báo AAM
```

### Firmware là gì?

Không quan trọng. Philips Hue, Xiaomi, Sonoff, bất kỳ — HomeOS không
quan tâm. Thiết bị kết nối LAN là nó thuộc HomeOS. Firmware chỉ là
lớp vật lý bên dưới, Worker bọc bên ngoài.

```
Firmware (bất kỳ)           ← lớp vật lý, HomeOS không quan tâm
    ↑ chỉ nhận từ Worker
Worker (HomeOS)             ← HomeOS tại thiết bị
    ↑ ISL
Chief
    ↑ ISL
AAM
```

### DeviceSender là gì?

DeviceSender (HTTP/UDP đến firmware) là thin adapter tạm thời —
giống USB driver. KHÔNG phải logic, KHÔNG phải skill cốt lõi.
Nằm ở rìa, thay được bất cứ lúc nào. Worker không biết nó tồn tại.

### Mục tiêu dài hạn

```
Khi firmware cũ → Worker có thể thay thế bằng Skill của HomeOS
Khi thiết bị hỗ trợ olang runtime → ship light.olang trực tiếp
Khi không hỗ trợ → DeviceSender dịch ISL → HTTP/UDP (tạm thời)
```

### Skills cần thêm vào Worker (backlog)

```
✅ SecurityGateSkill    — đã có
✅ ActuatorSkill        — đã có (gửi lệnh xuống firmware)
🔴 TrafficMonitorSkill  — chặn traffic trái phép ra ngoài LAN
🔴 FirmwareWatchSkill   — phát hiện firmware gửi data trái phép → cô lập
```

*Cập nhật: 2026-03-10 — session 146e*

---

## CẬP NHẬT SESSION 146g AUDIT+FIX (2026-03-10)

### Trạng thái thật sau fix

```
BUILD:        OK
go vet:       CLEAN
go test:      9/9 PASS
go test -race: 0 DATA RACE

homeos.olang:
  SHA256:  ✅ verified (a27a2da7ac58eede...)
  Nodes:   4,810 (header) / 4,776 (CLI scan, 34 ISL collision)
  Edges:   1,412
  Size:    861,266 bytes

Layer phân bố ĐÚNG (đã fix layer index):
  L0  Primitives:    92  nodes
  L1  UTF32:       1280  nodes
  L2  Nature:        45  nodes
  L3  Life:        3062  nodes  ← trước bị mất do layer index corrupt
  L4  Objects:       28  nodes
  L5  Programming:  159  nodes
  L6  Perception:    49  nodes
  L7  Programs:     116  nodes  ← tăng 2: QT8_DEF + QT9_DEF promoted từ L8
```

### Bugs đã fix trong session này

```
✅ homeos.olang Layer index L3 corrupt (offset overflow → 2.2GB)
✅ homeos.olang Header nnodes = 101376 (sai → 4810)
✅ homeos.olang SHA256 mismatch
✅ QT8_DEF, QT9_DEF promote L8 → L7
✅ CLI edgeStart từ layer index (sai → 40,410 edges giả)
   Đúng: len(file) - nedges*17 → 1,412 edges thật
✅ CLI per-layer parser → linear scan toàn file
   Đúng: 4,776 nodes (trước chỉ đọc được 1,414)
✅ 4 race conditions trong agents + memory
✅ go vet: self-assignment lan_scanner.go
```

### Vấn đề CRITICAL còn lại

```
🟠 ISL collision: 34 nodes có ISL key trùng → CLI dedup bỏ qua 34 nodes
   Cần: audit xem ISL nào trùng + resolve
   File: cmd/olang/main.go dùng seen map[uint64]bool
   Priority: trung bình (không ảnh hưởng runtime, chỉ ảnh hưởng CLI count)

🟠 OlangNode 2 định nghĩa (olang/file.go vs silk/silk.go)
   Cần unify → breaking change lớn → làm khi có thời gian
```

### Quy tắc làm việc bổ sung

```
27. edgeStart = len(file) - nedges*17  (KHÔNG dùng layer index)
28. CLI parse = linear scan [280..edgeStart] + dedup ISL
29. Concurrent counters = sync/atomic.Int64/Uint64
30. LongTerm.Query() phải có mutex RLock
```

### Thứ tự ưu tiên tiếp theo

```
🔴 ① brain_query.go tách (1,731 dòng)
🔴 ② AuditLog persist (AAM + LeoAI chưa log)
🔴 ③ TrafficMonitorSkill thật (/proc/net/tcp)
🔴 ④ FirmwareWatchSkill thật (/proc/net/dev)
🟠 ⑤ ISL collision 34 nodes → audit + fix
🟠 ⑥ WorkerDeployServer integration test
🟠 ⑦ OlangNode unification
🟡 ⑧ MILESTONE 5000 nodes L3
🟡 ⑨ L5 Go AST → ISL
```

---

*Cập nhật: 2026-03-10 — session 146g*

---

## VISION & MỤC TIÊU DÀI HẠN (bất biến)

### Tuyên ngôn

```
"Vũ trụ không lưu hình dạng. Vũ trụ lưu công thức."
"Khi lập trình không còn là gõ lệnh,
 mà là sắp đặt các quy luật của Tạo hóa."

HomeOS = Vũ trụ Toán học Tự vận hành
       ≠ home automation
       ≠ LLM
       ≠ hệ điều hành truyền thống
```

### Mục tiêu từng tầng

```
TẦM GẦN (đang làm):
  $ olang run homeos.olang → HomeOS chạy từ 1 file duy nhất
  9 QT trong L7 → được thực thi, không chỉ là text
  Worker = HomeOS tại thiết bị (không phải adapter)

TẦM TRUNG (6–12 tháng):
  Agent clone: filter(homeos.olang, DeviceProfile) → light_01.olang 12KB
  Olang compiler: L5 → emit Go/Rust/WASM
  World rendering: L7 World node → 3D scene trong browser
  Inverse Rendering: ImageToDNA() → LeoAI tự học từ thế giới

TẦM XA (concept):
  Quantum Interface: ISL address → quantum gate
  L1 UTF32 complete: 168K chars, tất cả có valid SDF
  Physics simulation: ∇(sdf) thay thế physics engine
  Silk = Wikipedia trong .olang (navigation qua tơ)
```

### Nguyên tắc không bao giờ thay đổi

```
1. Lưu công thức, không lưu hình dạng
2. Append-only — không DELETE, không OVERWRITE
3. Mọi DNA qua 🛡 SecurityGate trước khi commit
4. Im lặng là vàng — Agent phát signal khi có biến động
5. ĐN → Dream → QR (tri thức phải được chứng minh)
6. vSDF: evaluate SDF trực tiếp, không raymarching
```

---

*Cập nhật: 2026-03-10 · session 146g*

---

## THIẾT KẾ HỌC TẬP & TRI THỨC (từ HANDOFF upload)

> Chi tiết NCA, Hebbian, Dream cycle, Silk Tree structure.


## 6. HỌC TẬP / NCA (Neural Cognitive Architecture)

```
DENDRITES = ShortTermMemory  (ĐN — ngắn hạn, tự do thay đổi)
AXON      = LongTermMemory   (QR — dài hạn, append-only, ED25519)
SOMA      = AAM              (stateless orchestrator)

Vòng QT7:
  INPUT → ĐN (lọc, lưu ngắn hạn)
        → DreamSkill (kiểm chứng khi rảnh)
        → MsgPropose → AAM.ProposalHandlerSkill
        → QR (Silk Tree, bất biến)

Dreaming (inbox idle >5 phút):
  high-conf ≥0.75 → pack NodeHash → MsgPropose → AAM → QR
  low-conf  <0.20 → MarkArchived (trừ Fiction)

Hebbian learning:
  Co-activation (2 nodes active cùng 30s cùng layer) → BoostEdge
  hebbMinCoFires = 3 lần → propose edge mới → MsgPropose
  EdgeWeightStore persist → homeos.olang.weights
  Decay: -1 weight/24h không dùng ("neurons that stop firing together, unwire")
  SilkWalkSkill dùng WalkWeighted() → edges weight cao được ưu tiên

ClusterSkill:
  Detect clusters trong ĐN → MsgPropose("cluster|name|level|count")
  ProposalHandlerSkill.handleClusterProposal() → CommitCluster()
  Persist parent nodes → homeos.olang.clusters.olang (atomic, QT8 ✓)
```

---


## 7. TRI THỨC (Silk Web Knowledge Tree)

```
THÂN  [UTF-32 Groups]        ← bất biến · ED25519
  └─ CÀNH  [≥200 xác nhận]  ← bất biến
      └─ NHÁNH [≥60 lá]     ← bất biến
          └─ LÁ  [học được]
              └──tơ──► LÁ  (semantic link, Hebbian weighted)

Tìm kiếm: đến đúng địa chỉ ISL → đi theo tơ (WalkWeighted)
homeos.olang hiện tại:
  4,813 nodes · 1,412 edges · 841 KB
  L3 Life = 3,062 nodes (AI/Neuro, Physics, Math, Biology...)
```

### Các cặp node "intentional duplicate" (có ≡ edge, KHÔNG phải bug)

```
HIST_DEMOCRACY ↔ SOC_DEMOCRACY
AI2_REINFORCE  ↔ AI2_RL
PROG_NEURAL_NET ↔ TECH_NEURAL_NET
ECON_POVERTY   ↔ SOC_POVERTY
(+6 cặp khác — xem SESSIONS.md)
```

---


---

*Cập nhật: 2026-03-10 · session 146g*

---

## BACKLOG Ý TƯỞNG ĐẦY ĐỦ (từ HANDOFF upload · session 142)


## 9. Ý TƯỞNG PHÁT HIỆN / MUỐN THỰC HIỆN TIẾP

### 🔴 Ưu tiên cao (làm ngay)

```
① OlangFile.ReadFrom() — full round-trip read/write
   Hiện tại: WriteTo ✅, ReadFrom ❌
   Cần: load homeos.olang → SilkGraph → modify → save back
   Không thể merge cluster nodes nếu không có ReadFrom

② WeightedSilkWalk: check cả OpSimilar edges
   Hiện tại: WalkWeighted chỉ check OpMember
   Cần: khi BFS, cũng traverse OpSimilar weighted edges
   Tại sao: Hebbian edges là OpSimilar → không được ưu tiên

③ HonestySkill: implement Skill interface
   Hiện tại: struct exists nhưng không có CanHandle()
   Cần: wire vào AAM để detect sycophancy/false confidence
   Pattern: nếu LeoAI confirm mâu thuẫn → flag

④ brain.go: tách IntentHandler thành riêng biệt
   Hiện tại: brain.go ~1754 dòng dù đã tách 4 files
   Cần: mỗi Intent group = 1 file (actuator/query/learn/meta)
```

### 🟠 Ưu tiên trung bình

```
⑤ AuditLog persist to disk
   Hiện tại: AuditLog chỉ in-memory RAM
   Cần: append vào homeos.audit.log (text, human readable)
   Format: timestamp | agent | action | payload | result

⑥ LANScanner thật (ARP/mDNS)
   Hiện tại: OnboardSkill nhận device thủ công
   Cần: scan mạng → discover → auto-onboard
   Stack: net.Interface → ARP → mDNS .local

⑦ ScoreSearch accuracy
   Hiện tại: search trả về kết quả sai đôi khi
   Fix: exact name token match phải được score cao nhất
   Cụ thể: "triết học" → PHIL_OVERVIEW (hiện bị mismatch)

⑧ Brain.LoadBook(path) → BookMemory
   Đọc file text → tokenize → inject vào ĐN
   Dreaming xử lý → QR (học từ sách)
```

### 🟡 Ý tưởng dài hạn (chưa bắt đầu)

```
⑨ L1 UTF32 complete: 168K chars có valid SDF
   Hiện tại: chỉ có 1,280 chars
   Cần: seed toàn bộ Unicode 18.0 → MILESTONE L1

⑩ L5 Programming: Go AST → ISL
   Mỗi Go AST node = ISL addr + DNA + children edges
   compile Go source = traverse AST → lookup ISL → emit binary
   Đây là "Olang compiler" thật sự

⑪ L6 Perception: Vision agent thật
   Camera → rayMarch(sdf_world) → per ray = ISL_address
   Agent không thấy màu sắc — agent thấy ĐỊA CHỈ
   "pixel" = "cái gì ở đây?" → ISL của vật thể

⑫ Seal Script → SDF bridge
   Seal chars (U+3D000+) gần SDF nhất trong Unicode
   Seal 山 = vẽ ba đỉnh núi → link trực tiếp terrain SDF
   Lịch sử giữa ký tự và thực tế

⑬ SilkEdge.Weight trong binary format (.olang)
   Hiện tại: weights trong file riêng (.weights)
   Tương lai: embed weight vào edge record (9B → 10B+)
   Breaking change → cần migration tool

⑭ World rendering: homeos.olang → 3D scene
   L7 World node chứa DNA → spawn SDF objects
   web/renderer.js: evaluate SDF trực tiếp (không raymarching)
   MILESTONE 5: browser render world từ .olang

⑮ OlangNode unification
   Hiện tại: 2 định nghĩa OlangNode (olang/file.go và silk/silk.go)
   Cần: 1 định nghĩa canonical duy nhất
   Lý do chưa làm: breaking change lớn
```

### 💡 Ý tưởng chưa được khám phá

```
⑯ Spline motion trong .olang
   L3 Life nodes có splines (walk_cycle, run_cycle...)
   Hiện tại chưa execute splines
   Cần: SplineSkill evaluate motion path theo time

⑰ Physics simulation từ SDF
   ∇(sdf) = normal vector → collision detection
   density + viscosity nodes → fluid sim
   Gravity = ISL [P][F][g][1] → acceleration field

⑱ Agent clone = olang file
   Mỗi device khi onboard nhận 1 file .olang nhỏ
   Chứa chỉ những skills nó cần
   "Agent = clone(homeos.olang) + filter by DeviceProfile"
   Đã implement OnboardSkill nhưng chưa có file export

⑲ Silk edges → concept navigation
   User hỏi "đèn" → SilkWalk → ánh sáng → photon → UV → sức khỏe
   Hebbian weights → paths được đi nhiều → được ưu tiên
   Đây là "Wikipedia trong .olang"

⑳ ISL vs JSON: 75.7% smaller
   ISL: ~68 bytes/lệnh (AES-256-GCM tích hợp)
   JSON: ~280 bytes/lệnh
   Idea: expose HTTP API dùng ISL binary thay JSON
```

---


---

*Cập nhật: 2026-03-10 · session 146g*

---

## Cập nhật 2026-03-11 — Sessions 167–D8

### Sự thật mới được xác nhận

#### Binary Format — Edge Endianness
```
✅ ĐÚNG: EdgeTable phải BigEndian
   src(8BE) + dst(8BE) + type(1) + weight(4BE) = 21B/edge
   Writer: binary.BigEndian.PutUint64 / PutUint32
   Reader: binary.BigEndian.Uint64 / Uint32
   
❌ SAI (đã fix): WriteTo() dùng binary.LittleEndian → 99% edges corrupt
   Triệu chứng: edge type = 0 hoặc garbage
```

#### homeos.olang Format — Node
```
Node binary (old format, dùng bởi ParseBytes):
  [0:2]   = 'N','D'   magic
  [2]     = layer (uint8)
  [3:11]  = ISL addr (8 bytes)
  [11:15] = codepoint (4 bytes, Big-Endian)
  [15:19] = dnaLen (4 bytes, Big-Endian)
  [19]    = nameLen (1 byte)
  [20 .. 20+dnaLen] = DNA
  [20+dnaLen ..] = name (UTF-8)

Header (old format):
  [0:4]   = "OLNG"
  [8:12]  = node count (BE uint32)
  [16:20] = edge count (BE uint32)
  Nodes start: byte 280
  Edges: cuối file — len(raw) - nedges*21

KHÔNG dùng WriteTo/SaveToPath (FileHeader struct 64B):
  → format khác hoàn toàn với ParseBytes
  → đây là nguồn gốc của bug null header
```

#### NewOlangFile() vs New()
```
New():         set Header.Magic + Version + NLayers + Created  ← ĐÚNG
NewOlangFile() cũ: không set gì → Magic = [0,0,0,0]           ← BUG
NewOlangFile() mới: giống New()                                 ← ĐÃ FIX

Lesson: 2 constructor cho cùng struct → dễ diverge
TODO: gộp thành 1
```

#### Molecular Stroke Encoding — Sự thật vật lý
```
vSDF = SDF + Molecular DNA
  - SDF: hàm khoảng cách f(p) → float64 (dùng để render)
  - DNA: [n_mol(1B)][MID(1B)X(1B)Y(1B)×n] (dùng để lưu trữ)
  
Molecule table: 100 entries × 6B = 600B → toàn bộ 6 scripts
  Entry: {class(1), angleQ(1), lengthQ(1), curveQ(1), freq_hi(1), freq_lo(1)}
  Lưu tại: L0 node cp=0x00000000

Tại sao không dùng TTF:
  TTF outline: ~200-2000B/glyph (Bezier + metadata)
  Molecular:   ~30-50B/glyph (stroke indices)
  Ratio: ~10-40x nhỏ hơn
  
DNA của các L1 nodes (Latin/CJK/...):
  dnaLen=0 ban đầu (chưa có SDF)
  Sau vsdf_inject: dnaLen = len(molecular_bytes)
  Injected: 444/375 chars (overlap do CJK batches)
```

#### Unicode Coverage
```
Tổng L1 nodes: 166,253
Có molecular DNA: 444
Có TTF DNA (từ trước): 101,595
Empty DNA: 64,214

Molecular scripts:
  Latin:      72 chars (A-Z a-z 0-9 + extended)
  Greek:      50 chars (Α-Ω α-ω + variants)
  Cyrillic:   32 chars (А-Я)
  Devanagari: 15 chars
  Arabic:     20 chars
  CJK:       255 chars (198 defined + overlap)
```

#### Silk Edges — Hiện trạng
```
Tổng: 4,003 edges (tất cả V2, BigEndian, 21B)
  EdgeSameSound=0x01:   310 (D4: Latin↔Greek↔Cyrillic↔Arabic↔Hebrew)
  EdgeDerivedFrom=0x04: 107 (D5: Phoenician→Greek→Latin+Cyrillic)
  EdgeMember=0x08:    1,832 (D1: WORD→char Compose)
  EdgeCompose=0x0A:     138 (D1: concept compositions)
  EdgeEquiv=0x0B:     1,491 (auto-wire: uppercase↔lowercase)
  EdgeSimilar=0x0C:      15
  EdgeOpposite=0x0D:      4
  EdgeWorldLink=0x0E:   106 (D2: LIFE_*/EMOTION_* → symbol)

Bad edges: 0 ✅
Dup edges: 184 (nằm trong giới hạn chấp nhận)
```

---

*Cập nhật: 2026-03-11 · session D8*

---

## Cập nhật 2026-03-11 — Sessions D7–D8 (Molecular Encoding)

### Sự thật về cjk.go và type aliases

```
❌ SAI: type gv = gene2Vec3
   → gene2Vec3 không tồn tại (tên sai)
   → Gây "undefined: gene2Vec3" compile error

✅ ĐÚNG: Dùng thẳng gene.Vec3
   → SDF func type: func(gene.Vec3) float64
   → Tất cả helpers (cV, cH, cD, cArc, cDot) trả về type này
   → Không cần alias

❌ SAI: func cH2(x0, x1, y float64) (tên cũ từ session trước)
✅ ĐÚNG: func cH(x0, x1, y float64) (nhất quán với cV, cD)
```

### Sự thật về OlangChar SDF function

```go
// SDF field trong OlangChar:
SDF func(gene.Vec3) float64

// KHÔNG PHẢI:
SDF func(gv) float64         // gv = alias sai
SDF func(vec3) float64       // không tồn tại

// Khai báo đúng:
{Codepoint: 0x4E00, SDF: cH(-cW, cW, 0)}
// cH trả về func(gene.Vec3) float64 → khớp với OlangChar.SDF ✅
```

### Sự thật về 2 format homeos.olang

```
FORMAT CŨ (canonical, dùng bởi ParseBytes):
  Header: "OLNG"(4B) + nodeCount(4BE) + ?(4B) + edgeCount(4BE) + padding
  Nodes bắt đầu tại byte 280
  Node: "ND"(2) + layer(1) + ISL(8) + cp(4BE) + dnaLen(4BE) + nameLen(1) + DNA + name
  Edges: cuối file, len(raw) - nedges × 21B
  Edge: src(8BE) + dst(8BE) + type(1) + weight(4BE) = 21B

FORMAT MỚI (dùng bởi WriteTo/SaveToPath):
  Header: FileHeader struct (64B, LittleEndian binary.Write)
  Layer index: NLayers × LayerEntry struct
  Nodes: OlangNodeHeader struct + DNA + edges + phonemes + sig
  Edges: EdgeTable ở cuối

→ KHÔNG tương thích nhau
→ ParseBytes KHÔNG thể đọc output của SaveToPath
→ Giải pháp tạm thời: vsdf_inject dùng FORMAT CŨ

TODO: Cần unification — 1 format duy nhất
```

### Sự thật về Molecule Table

```
Location: L0 node với cp=0x00000000
DNA format: [n_entries(1B)][entry0(6B)][entry1(6B)]...[entryN(6B)]
Entry: class(1B) + angleQ(1B) + lengthQ(1B) + curveQ(1B) + freq_hi(1B) + freq_lo(1B)

Sau inject session D8:
  100 entries × 6B = 600B + 1B header = 601B
  Covers 6 scripts: Latin, Greek, Cyrillic, Devanagari, Arabic, CJK
  Entry distribution:
    V (vertical):    17 entries
    H (horizontal):  10 entries
    D1 (diagonal↘): 15 entries
    D2 (diagonal↗): 15 entries
    CR (curve right): 8 entries
    CL (curve left):  8 entries
    CU (curve up):    9 entries
    CD (curve down):  7 entries
    Dot:              8 entries
    Arc:              3 entries

Tại sao 100 (không phải 255)?
  6 scripts × avg 16 stroke types = 96 → rounded up to 100
  255 là max, không phải target
  Càng nhiều entries → bảng to hơn, nhưng DNA/char nhỏ hơn
```

### Sự thật về dnaLen của L1 nodes trước inject

```
Trước vsdf_inject: tất cả L1 nodes có dnaLen=0
  Lý do: bulk-seed từ UnicodeData.txt chỉ tạo nodes với name/layer/ISL
  Không có quá trình generate SDF DNA khi seed

Sau vsdf_inject:
  444 nodes có dnaLen = len(molecular bytes)
  165,809 nodes vẫn dnaLen=0 (chưa được inject)
  1 L0 node dnaLen=601 (molecule table)

→ Vẫn còn 165,809 nodes empty DNA
→ Cần thêm alphabet coverage hoặc TTF pipeline
```

### Sự thật về CJK batch structure

```
cjk.go:   var CJKCommon []*OlangChar   — 70 chars, top common (一二三...的了是)
cjk2.go:  var CJK2      []*OlangChar   — 57 chars, hành động/vật thể/thiên nhiên
cjk3.go:  var CJK3      []*OlangChar   — 71 chars, không gian/cảm xúc/xã hội/số

AllCJK() → append(CJKCommon, CJK2..., CJK3...) = 198 chars

Mỗi char = {Codepoint, Glyph, Script:"cjk", Category:"letter", SDF:func}
SDF = composition của cV/cH/cD/cArc/cDot với union()
Không có Phonemes field trong cjk2/cjk3 (thêm sau nếu cần)
```

---

*Cập nhật: 2026-03-11 · session D8*

---

## Cập nhật 2026-03-11 — Node Format V19 / NamesTable

### Sự thật về node format mới

#### V19 node không có nameLen
```
❌ V18 (cũ): "ND"+layer+ISL(8)+cp(4)+dnaLen(4)+nameLen(1)+dna+name
             → nameLen là 1 byte cuối của fixed header (byte 19)
             → tổng header = 20B

✅ V19 (mới): "ND"+layer+ISL(8)+cp(4)+dnaLen(4)+dna
              → không có nameLen field
              → tổng header = 19B = NodeHeaderSizeV19
              → name lưu riêng trong NamesTable
```

#### NamesTable — sự thật kỹ thuật
```
Format binary:
  [0:2]  = "NT" magic
  [2:6]  = count (uint32 BE)
  [6...] = entries: [isl(8BE)][nameLen(1)][name(nameLen)]

Vị trí trong file V19:
  Bắt đầu tại: header[28:32] (BE uint32 offset)
  Kết thúc tại: edgeStart (= len(file) - edgeCount×21)
  Layout: [header][nodes][NamesTable][edges]

Lookup O(1):
  NamesTable.byISL = map[uint64]string
  Get(islAddr) → name, "" nếu không có

Size thực tế:
  166,251 entries × (8+1+avg10) = ~3.1MB
  NamesTable bytes: 6,119,319B (avg name ~37B — UTF-8 Vietnamese)
```

#### Version detection trong header
```
header[4:6] = version uint16 BE
  0x0000 = V18 (cũ, không set version)
  0x0012 = V18 (18 decimal)
  0x0013 = V19 (19 decimal) ← hiện tại mới nhất

Nếu version >= 19 → isV19 = true → dùng parseNodesV19 + NamesTable
Nếu version < 19  → isV18 = true → dùng parseNodesV18 (inline name)
```

#### NamesTable offset trong header
```
header[28:32] = namesTableOffset (uint32 BE) — chỉ valid khi V19
  0x00000000 → không có offset hợp lệ → fallback scan
  > 280      → fast path: đọc trực tiếp raw[offset:]

Scan fallback (khi offset = 0 hoặc invalid):
  Scan ngược từ edgeStart-6 về 280
  Tìm "NT" magic + verify consumed = edgeStart - start
  O(n) nhưng chỉ chạy 1 lần khi load file
```

#### Tại sao V19 lớn hơn V18
```
V18: name nằm trong node → nhiều node L1 có nameLen=0 → 0 overhead
V19: mọi node có tên → 8B ISL overhead per entry trong NamesTable

Calculation:
  166,251 entries × 8B overhead = 1,330,008B ≈ 1.3MB
  V18: 9,759,118B → V19: 11,089,130B → diff = +1,330,012B ✅ khớp

Trade-off được chấp nhận:
  ✅ Tách biệt hoàn toàn: node = ISL + DNA, không phụ thuộc vào tên
  ✅ Đổi tên không rebuild node
  ✅ NamesTable có thể nén riêng (zstd ~70%)
  ✅ Worker export: có thể drop NamesTable nếu không cần tên
```

#### Hai encodeNode functions
```go
encodeNode(n *NodeRecord) []byte     // V18: có nameLen+name
encodeNodeV19(n *NodeRecord) []byte  // V19: chỉ ISL+cp+dnaLen+dna
```

#### Reader backward compat
```
ParseBytes() đọc được cả V18 lẫn V19:
  V18 → parseNodesV18 → NodeRecord.Name từ inline bytes
  V19 → parseNodesV19 → NamesTable → NodeRecord.Name từ map lookup

olang_loader.go, node_lookup.go: cùng detect logic
  isV19 := binary.BigEndian.Uint16(raw[4:6]) >= 19
```

---

*Cập nhật: 2026-03-11 · Node Format V19*
