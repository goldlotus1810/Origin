# ○ — MASTER DOCUMENT
# HomeOS · SILK · NCA · Origin · Skill System
# Đọc file này = hiểu toàn bộ hệ thống
# Append-only · Cập nhật: 2026-03-10

---

```
○(x) == x        identity
○(∅) == ○        tự tạo sinh
○ ∘ ○ == ○       idempotent
mọi f == ○[f]    mọi thứ là instance của ○
```

---

## PHẦN I — NỀN TẢNG (○ / Origin)

> Đây là "vật lý học" của hệ thống. Không ai được vi phạm.

```
QT1  ○ LÀ NGUỒN GỐC
     Mọi thứ đều là instance của ○.

QT2  ∞ LÀ SAI — ∞-1 MỚI ĐÚNG
     ∞   == không tồn tại
     ∞-1 == tồn tại thật (hữu hạn nhưng rất lớn/rất nhỏ)

QT3  TOÁN HỌC TRỪU TƯỢNG — VẬT LÝ LÀ SỰ THẬT
     +/-  == giả thuyết, chưa chắc đúng
     ⧺    == thêm vào vật lý (đã chứng minh)
     ⊖    == bớt đi vật lý  (đã chứng minh)
     ==   == chắc chắn, sự thật vật lý
     Quá trình: quan sát → +/- → chứng minh → ==

QT4  BẢN CHẤT QUYẾT ĐỊNH TỒN TẠI
     Agent == tập hợp Skill của nó (không hơn không kém)
     Định nghĩa == mô tả bản chất
     Chỉ dùng ⧺ / ⊖ / == trong định nghĩa

QT5  BẢN CHẤT QUYẾT ĐỊNH VỊ TRÍ
     Cùng bản chất       → cùng nhóm
     Tương đồng bản chất → xếp gần nhau
     Nhóm thuộc nhóm     → tầng cao hơn xây trên tầng thấp hơn

QT6  HAI CHIỀU TỒN TẠI
     SDF == hữu hình  (đo được, cảm nhận trực tiếp)
     ISL == vô hình   (ý tưởng, quan hệ, lệnh điều khiển)
     SDF ⧺ ISL == Smooth_union

QT7  HỌC / LEAD — VÒNG ĐỜI TRI THỨC
     QR == tri thức đã chứng minh · dài hạn · cần cấp phép
     ĐN == tri thức đang học      · ngắn hạn · tự do thay đổi
     Vòng đời: quan sát → ĐN(+/-) → chứng minh → QR(==)
     Correction: người dùng bác bỏ → ĐN bị xóa
     Skill sinh Skill: pattern ĐN lặp lại → SkillProposal → QR

QT8  LỊCH SỬ BẤT BIẾN
     Append-only: không DELETE, không OVERWRITE
     Phục hồi trạng thái t = replay đến timestamp t

QT9  KHÔNG THÔNG TIN SAI LỆCH
     SecurityGate Rule 1: Không hại con người (tuyệt đối)
     Không ai ghi đè Rule 1 — kể cả LeoAI
```

### Vòng đời tri thức đầy đủ

```
INPUT (quan sát / người dùng / sensor)
    ↓
ĐN — Dendrites lọc, lưu ngắn hạn  [skill/memory/shortterm]
    ↓
    ├─ người dùng xác nhận → chứng minh pass
    ├─ người dùng bác bỏ   → ĐN xóa (correction)
    └─ Dreaming tự kiểm chứng khi rảnh  [skill/learning/dream]
    ↓
QR — Silk Tree  [skill/memory/longterm] · Append-only · ED25519
```

---

## PHẦN II — NGÔN NGỮ (SILK / ISL)

> Mọi giao tiếp trong hệ thống đi qua đây.

### ISL Address — 64-bit

```
[layer:1B][group:1B][type:1B][id:1B][attr:4B]

ABa1  = Hình ảnh > Sinh vật > Động vật > chim
DCb4  = Địa điểm > Tự nhiên > Ven biển > cát
HAa1  = Nhà > Ánh sáng > Đèn > phòng khách
FAa8  = Cơ thể > Chi dưới > Chân/Cánh > chân
```

### ISL vs JSON

```
JSON:  ~280 bytes/lệnh
ISL:   ~68 bytes/lệnh  (AES-256-GCM tích hợp sẵn)
→ Tiết kiệm 75.7% · Không cần TLS thêm
```

### SILK Compiler — 12B/symbol

```
text → tokenize → resolve → encode (4B codepoint ⧺ 8B ISL)
     → compress? (zstd ~80%) → encrypt? (AES-256-GCM)
     → ○ binary stream → Silk Tree

Append-only Ledger: ○ chỉ WRITE — không DELETE, không OVERWRITE
Phục hồi trạng thái t = replay đến timestamp t
```

---

## PHẦN III — SKILL SYSTEM

> QT4: "Bản chất của Agent = tập hợp Skill của nó."

### Skill là gì

```
Skill = 1 năng lực cụ thể · 1 trách nhiệm duy nhất

5 quy tắc thiết kế Skill (bất biến):
  ① 1 Skill = 1 trách nhiệm
  ② Skill không biết Agent là gì
  ③ Skill không biết Skill khác tồn tại
  ④ Skill giao tiếp qua ExecContext.State
  ⑤ Skill không giữ state — state nằm trong Agent
```

### Agents đang chạy thật (2026-03-10)

```go
// Runtime thực tế trong cmd/olang/runtime.go

// chan-bus pipeline (actuation)
aam        := New("aam").AddSkill(BroadcastSkill).AddSkill(HeartbeatSkill)
home_chief := New("home_chief").AddSkill(HomeChiefSkill)
light_living := New("light_living").AddSkill(ActuatorLight("living_room"))
light_bed    := New("light_bed").AddSkill(ActuatorLight("bedroom"))

// LeoAI pipeline (learning)
leoai := New("leoai").
    AddSkill(SkillUserInputWatch).
    AddSkill(DreamSkill).
    AddSkill(DreamDispatchSkill)
```

### 40 Skills định nghĩa nhưng CHƯA nối vào agent (🔴 vấn đề #1)

```
Cần nối vào đúng agent:
  LeoAI:      ClusterSkill · DNFireSkill · TeachSkill · SilkWalkSkill
              ScheduleDreamSkill · ScheduleLearnerSkill · KnowledgeRouterSkill
  AAM:        SecurityAuditSkill · EphemeralAuthSkill · AAMGrantSkill
              HonestySkill · ContextAwareSkill · SkillSynthesizerSkill
  Home Chief: ActuatorHvacSkill · OnboardSkill · FirmwareReaderSkill
              CapabilityMapSkill · FirmwarePatchSkill
  Workers:    PerceptionSkill · AggregateSkill · DecideSkill
              SpatialLearnSkill · SpatialQuerySkill · ProsodySkill
  System:     EnvironmentProbeSkill · LoggerSkill · OSProfileSkill
              NetworkMonitorSkill · ProcessWatchSkill · NotifyUserSkill
              DataLeakDetectSkill · ErrorCollectorSkill
              WebFetchSkill · AppLauncherSkill
```

### Kho Skill theo domain

```
skills/
  actuator/    light✓ · hvac✓ · lock(stub)
  perception/  perception · aggregate · decide · spatial_learn · spatial_query
  memory/      shortterm(ĐN) · longterm(QR→Silk Tree)
  decision/    decide4d
  learning/    cluster · dream✓ · dream_dispatch✓ · schedule_dream · schedule_learner
  language/    encode · broadcast✓ · prosody
  security/    gate · security_audit · ephemeral_auth · aam_grant · data_leak · process_watch · network_monitor
  knowledge/   dn_fire · teach · silk_walk✓ · knowledge_router · index
  system/      env_probe · logger · os_profile · error_collector · firmware
  comm/        web_fetch · app_launcher · notify_user · onboard
  meta/        composed · honesty · context_aware · skill_synthesizer
  composed/    (LeoAI tự tạo)
```

---

## PHẦN IV — TRI THỨC (Silk Web Knowledge Tree)

```
homeos.olang (841 KB):
  4813 nodes · 1412 edges
  
THÂN  [UTF-32 Groups]        ← bất biến · ED25519
  └─ CÀNH  [≥200 xác nhận]  ← bất biến
      └─ NHÁNH [≥60 lá]     ← bất biến
          └─ LÁ  [học được]
              └──tơ──► LÁ  (semantic link)

Tìm kiếm: đến đúng địa chỉ lá → đi theo tơ → không scan toàn bộ
30 intents hoạt động: Greet/Farewell/Help/Actuator/Explain/CharLookup/
  Reason/Why/ExplainDeep/Fact/Search/Related/PathQuery/Compare/List/
  HowTo/Quiz/Statement/Paragraph/Timeline/Biography/Example/Synonym/
  Convert/Rank/Debate/Trend/Mnemonic/Summary/Ask/Opinion
```

---

## PHẦN V — BỘ NÃO HỌC (LeoAI / NCA)

```
DENDRITES = skill/memory/shortterm  (ĐN)
AXON      = skill/memory/longterm   (QR → Silk Tree)
SOMA      = AAM                     (stateless)

Chu kỳ N×T:
  T bước vi mô:   cluster lọc ĐN
      └─ lồng ─►
  N chu kỳ vĩ mô: commit QR

Vấn đề hiện tại (🔴):
  commitCycle() trong nca.go tự promote ĐN→QR (conf>=0.8)
  KHÔNG qua AAM, KHÔNG qua SecurityGate
  → Cần fix: NCA chỉ PROPOSE, AAM mới APPROVE

Dreaming (khi inbox rảnh >5 phút):
  tự kiểm chứng ĐN → pass → QR / fail → xóa
  Bước 2 (CROSS-CHECK với QR) còn thiếu
  ClusterProposal → output bị mất, không commit được
```

---

## PHẦN VI — HỆ THỐNG (HomeOS)

### Phân cấp giao tiếp (bất biến)

```
NGƯỜI DÙNG
    ↓
AAM  [broadcast · heartbeat · 🛡gate]
    ↓ ISL
Chiefs  [route · aggregate]        TẦNG 1
    ↓ ISL
Workers [actuator_X]               TẦNG 2 · SILENT BY DEFAULT

✅ AAM ↔ Chief
✅ Chief ↔ Chief (ngang hàng)
✅ Chief ↔ Worker của mình
❌ AAM ↔ Worker trực tiếp
❌ Worker A ↔ Worker B
❌ Worker ↔ Worker cùng nhóm (phải qua Chief)
```

### Security Gate 🛡

```
Rule 1: Không hại con người  (bất biến tuyệt đối)
Rule 2: Không vòng lặp vô hạn
Rule 3: Không xóa dữ liệu bất biến
Không ai ghi đè Rule 1 — kể cả LeoAI.
```

### 2 Pipeline hiện tại (🟠 cần merge)

```
Pipeline A — chan-bus (actuation):
  NxT → isl.ISLMessage → bus → aam → home_chief → light/hvac
  Dùng: AgentRegistry, chan *isl.ISLMessage

Pipeline B — HTTP/Brain (knowledge):
  user → HTTP POST /api/chat → brain.go → NodeLookup → ChatResponse
  Dùng: Brain struct, VocabLoader, registry trực tiếp

Vấn đề: 2 pipeline không biết nhau, feature mới phải viết 2 lần
Target: brain.go gửi ISL message qua msgBus → cùng pipeline A
```

---

## PHẦN VII — SDF UNIVERSE (research)

```
vSDF RULE (bất biến):
  KHÔNG raymarching — evaluate SDF primitives trực tiếp
  Renderer evaluate tại điểm, không march rays

opTable:
  ●  SDFSphere    ⌀  SDFCapsule   □  SDFBox     ◌  SDFVoid
  ∪  SmoothUnion  ∖  SmoothSub    ∩  SmoothIntersect
  ∫  FBM terrain  ∇  Gradient     ☀  SunLight
  🛡 SecurityGate 🧬 GeneRegistry

DNA ví dụ:
  🌍(seed:888)
  ∫(fbm, oct:6, h:3.0)
  ∪(⌀(10,0,5,h:0.6), ∪(●c1,●c2,●c3,k:0.3), k:0.3)
  ☀(t:8.0)
```

---

## PHẦN VIII — CẤU TRÚC THƯ MỤC

```
HomeOS/
├── TRUTH.md              ← đọc đầu tiên
├── MASTER.md             ← tổng quan hệ thống
├── homeos.olang          ← 841 KB · 4813 nodes · 1412 edges
├── cmd/olang/
│   ├── main.go           ✅ CLI: run/info/dump/get/walk/verify
│   └── runtime.go        ✅ cmdRunFull() — HomeOS entry point
├── internal/
│   ├── isl/              ✅ addr · codec · taxonomy
│   ├── utf32/            ✅ anchors
│   ├── silk/             ✅ SilkGraph · SilkTree · reasoner · utf32_bridge
│   ├── olang/            ✅ file · executor · runtime
│   ├── memory/           ✅ ShortTerm(ĐN) · LongTerm(QR)
│   ├── nca/              ✅ NxT cycle [🔴 commitCycle cần fix]
│   ├── agents/           ✅ Agent + 40 Skills [🔴 chưa nối]
│   ├── ws/               ✅ Brain · NodeLookup · ScoreSearch · API · WS
│   ├── gene/             ⚠ SDF universe research (build riêng)
│   ├── perception/       ⚠ stub
│   └── sync/             ⚠ silk_sync
└── scripts/              ✅ seed utilities
```

---

## PHẦN IX — ROADMAP

```
🔴 NGAY BÂY GIỜ:
  ① Fix vấn đề #1: nối 40 skills vào đúng agents
     → Cập nhật loader.go + runtime.go
     → Test: mỗi skill execute được ít nhất 1 message
  ② Fix vấn đề #3: NCA → chỉ PROPOSE, AAM mới APPROVE
     → nca.go: thay commitCycle() bằng proposeCommit()
     → aam phải có skill nhận ProposalMsg + user confirm
  ③ Resolve() cascade: gộp 84 boilerplate search

🟠 SAU ĐÓ:
  ④ ClusterProposal → CommitCluster (Leaf→Twig thật)
  ⑤ Dream CROSS-CHECK với QR (bước 2 còn thiếu)
  ⑥ Gộp parseDNAKV/tokenize/keyToAddr → shared utils
  ⑦ Tách brain.go → IntentHandler + QueryHandler + ActuatorHandler

🟡 DÀI HẠN:
  ⑧ Merge 2 pipeline chan-bus + HTTP
  ⑨ OlangNode unification (1 định nghĩa)
  ⑩ MILESTONE 5000 L3 nodes
  ⑪ Voxel SDF từ 3D mesh · SDFCharacter 3D
  ⑫ AudioAgent · MotionLibrary → PerceptionSkill
  ⑬ LANScanner thật (ARP/mDNS)
  ⑭ Hebbian Learning
```

---

## SƠ ĐỒ TỔNG THỂ

```
○  (9 Quy Tắc)
    ↓
SILK  (12B/sym · zstd · AES-256-GCM)
    ↓
╔════════════════════════════════════════════╗
║  AAM                                       ║
║  {Broadcast · Heartbeat · 🛡Gate}          ║
╚═══╤══════════╤═══════════╤════════════════╝
    ↓ ISL      ↓ ISL       ↓ ISL
 LeoAI      VisionChief  HomeChief
 {Watch      {Route        {Route}
  Dream       Aggregate}       ↓ ISL
  Dispatch}           light_living {ActuatorLight}
    ↓                 light_bed    {ActuatorLight}
 SILK WEB TREE
 THÂN→CÀNH→NHÁNH→LÁ──tơ──►LÁ

═══════════════════════════════════════════════
homeos.olang  841 KB · 4813 nodes · 1412 edges
30 intents · 8/8 tests PASS · BUILD OK
═══════════════════════════════════════════════
```

---

## 25 QUY TẮC LÀM VIỆC (bất biến)

```
1.  Mỗi session: đọc TRUTH.md trước
2.  Không thêm file mới nếu chưa xóa file thừa
3.  Không thêm Go code cho logic → phải vào .olang
4.  Test bằng: go test ./...
5.  Kiến trúc agent: User → AAM → Chief → Worker (lệnh xuống)
6.  Luồng bottom-up: Worker → Chief → AAM (báo cáo lên)
7.  Node format: DNA(trước) + name(sau); dnaLen Big-Endian
8.  vSDF rule: KHÔNG raymarching — evaluate SDF trực tiếp
9.  Edge rule: 1 thiết bị = 1 Agent = 1 Skill. Không raw media.
10. Agent rule: Agent KHÔNG tự nhân bản. Tầng trên tạo tầng dưới.
11. Knowledge rule: LeoAI là nguồn sự thật duy nhất.
12. Log rule: semantic→QR · truy vết→Ledger · debug→RAM
13. Auth rule: Không quyền mặc định. Token gắn SessionID.
14. Skill rule: Primitive=1 việc. Composed=[]Primitive.
15. Symbol rule: Unicode name mô tả chức năng.
16. Anchor rule: Symbol mới → FindCluster → SuggestCluster.
17. Header fix: script seed → Python đếm ND thực tế → fix header.
18. Encode rule: dna TRƯỚC name. Parser skip corrupt (dl>4096).
19. Edge insert: insert VÀO TRƯỚC edge section cũ (node_section_end).
20. adjCache: build() lưu nl.raw=raw. walkSilk dùng len(raw)-nedges*17.
21. ISL rule: ISL trong file KHÔNG phải sha256(name)[:8].
22. Single-script: nodes + edges = 1 script duy nhất.
23. Duplicate rule: kiểm tra label trùng trước khi thêm node.
24. ParseDerivative: token scoring, không hardcode string patterns.
25. buildDynamic: đọc layer byte trực tiếp, KHÔNG hardcode prefix map.
```

---

*Append-only. Chỉ được thêm vào, không được xóa.*
*Cập nhật lần cuối: 2026-03-10 · session 136 full audit*

---

## PHẦN X — CẬP NHẬT SESSIONS 143–146g (2026-03-10)

### Trạng thái thực tế sau tất cả fixes

```
BUILD:        OK
go vet:       CLEAN
go test:      9/9 PASS
go test -race: 0 DATA RACE

homeos.olang:
  SHA256:  ✅ verified
  Nodes:   4,810 (header đúng)
  Edges:   1,412
  Size:    861,266 bytes

  L0  Primitives:    92  nodes  ← 72 opcodes + 17 POS symbols + 3 misc
  L1  UTF32:       1280  nodes  ← ký tự Unicode
  L2  Nature:        45  nodes  ← môi trường tự nhiên
  L3  Life:        3062  nodes  ← tri thức đa lĩnh vực (AI, vật lý, sinh học...)
  L4  Objects:       28  nodes  ← thiết bị, vật thể
  L5  Programming:  159  nodes  ← Go/ISL/Silk/WASM semantics
  L6  Perception:    49  nodes  ← vision, audio, touch, depth
  L7  Programs:     116  nodes  ← agents, skills, QT rules (QT1–QT9)
```

### Những gì đã xong (sessions 143–146g)

```
✅ OlangFile.ReadFrom() — full round-trip (s143)
✅ SilkGraph.WalkWeightedMulti(OpMember+OpSimilar) — cả 2 edge types (s144)
✅ HonestySkill implement Skill interface + wire vào AAM (s144)
✅ ScoreSearch: exact×4 / prefix×2 / contains×1.5 (s144)
✅ AuditLog persist JSONL (s145) — home_chief
✅ LANScanner thật (ARP + mDNS) (s146d)
✅ DeviceSender 6 protocols: HueAPI/Miio/Tasmota/Shelly/HTTP/Stub (s146e)
✅ TrafficMonitorSkill (s146f)
✅ FirmwareWatchSkill (s146f)
✅ ExportWorkerSkill + WorkerDeployServer (s146g)
✅ Worker = HomeOS tại thiết bị (bất biến, s146e)

BUG FIXES session 146g:
✅ homeos.olang layer index L3 corrupt → fixed
✅ homeos.olang header nnodes 101376 → 4810
✅ homeos.olang SHA256 mismatch → fixed
✅ QT8_DEF + QT9_DEF promote L8→L7
✅ CLI edgeStart sai (40410→1412 edges)
✅ CLI parser per-layer → linear scan (1414→4776 nodes)
✅ 4 race conditions (sync/atomic + mutex)
✅ go vet self-assignment
```

### Cấu trúc thư mục hiện tại (cập nhật)

```
HomeOS/
├── HANDOFF.md      ← nguồn chính xác nhất (đọc đầu tiên)
├── TRUTH.md        ← trạng thái thật (đọc sau)
├── MASTER.md       ← tổng quan (file này)
├── SESSIONS.md     ← log chi tiết
├── homeos.olang    ← 861KB · 4810 nodes · 1412 edges · SHA256 ✅
├── cmd/olang/
│   ├── main.go     ← CLI: run/info/dump/get/walk/verify
│   │               ← linear scan parser (fixed s146g)
│   └── runtime.go  ← wire 45+ skills vào agents
└── internal/
    ├── isl/        ✅ address · codec · dictionary
    ├── utf32/      ✅ loader · groups · mapper
    ├── olang/      ✅ file.go · reader.go (ParseBytes) · export.go
    ├── silk/       ✅ SilkGraph · WalkWeightedMulti · EdgeWeightStore
    ├── memory/     ✅ ShortTerm(ĐN) · LongTerm(QR) · Query với mutex
    ├── nca/        ✅ SecurityGate · CheckActuatorSafety
    ├── agents/     ✅ 45+ Skills
    │   ├── percept_layer.go    ← tickCount atomic (fixed s146g)
    │   ├── skill_spatial_learn.go ← atomic counters (fixed s146g)
    │   ├── skill_spatial_query.go ← atomic counters (fixed s146g)
    │   ├── skill_traffic_monitor.go ✅
    │   ├── skill_firmware_watch.go  ✅
    │   ├── skill_export_worker.go   ✅
    │   ├── lan_scanner.go      ✅ ARP+mDNS
    │   └── skill_device_send.go ✅ 6 protocols
    └── ws/         ✅ WebSocket · brain.go · brain_query.go (cần tách)
```

### Quy tắc bổ sung (27–30)

```
27. edgeStart = len(file) - nedges*17  [KHÔNG dùng layer index offset+size]
28. CLI parse = linear scan [280..edgeStart] + dedup ISL key  [KHÔNG per-layer]
29. Concurrent counters = sync/atomic  [KHÔNG dùng plain int từ nhiều goroutine]
30. LongTerm.Query() phải có mutex RLock  [KHÔNG read-without-lock]
```

### Sơ đồ tổng thể (cập nhật)

```
○  (9 Quy Tắc: QT1–QT9, tất cả trong L7)
    ↓
SILK  (ISL 12B/sym · zstd · AES-256-GCM)
    ↓
╔══════════════════════════════════════════════════╗
║  AAM                                             ║
║  {Broadcast · Heartbeat · 🛡Gate                 ║
║   AAMRouter · ProposalHandler · HonestySkill}    ║
╚═══╤═══════════╤═══════════════╤═════════════════╝
    ↓ ISL       ↓ ISL           ↓ ISL
 LeoAI       VisionChief     HomeChief
 {ShortTerm   {Route          {Route · Onboard
  LongTerm     Aggregate}      FirmwareReader
  Cluster                      LANScanner
  Dream                        AuditLog}
  DreamDispatch                ↓ ISL
  Hebbian               light_living {ActuatorLight
  ED25519Sign}                        TrafficMonitor
    ↓                               FirmwareWatch}
 SILK WEB TREE                light_bed (同上)
 THÂN→CÀNH→NHÁNH→LÁ──tơ──►LÁ  hvac_living {HVAC}

════════════════════════════════════════════════════
Worker = HomeOS tại thiết bị (bất biến từ s146e)
DeviceSender = thin adapter (HueAPI/Miio/Tasmota/...)
homeos.olang  861KB · 4810 nodes · 1412 edges · SHA256 ✅
9/9 tests PASS · 0 DATA RACE · BUILD OK
════════════════════════════════════════════════════
```

### Roadmap cập nhật

```
🔴 NGAY BÂY GIỜ:
  ① brain_query.go tách (1731 dòng còn lại)
  ② AuditLog: thêm AAM + LeoAI
  ③ TrafficMonitorSkill: test thật (/proc/net/tcp)
  ④ FirmwareWatchSkill: collectSnapshot() thật (/proc/net/dev)

🟠 SAU ĐÓ:
  ⑤ ISL collision: 34 nodes trùng ISL key → audit + fix
  ⑥ WorkerDeployServer integration test
  ⑦ OlangNode unification (olang/file.go vs silk/silk.go)
  ⑧ SilkEdge.Weight embed trong binary (9B→13B)

🟡 DÀI HẠN:
  ⑨ MILESTONE 5000 nodes L3
  ⑩ L5 Go AST → ISL (olang compiler thật)
  ⑪ Test deployment ARM device
  ⑫ L1 UTF32 complete (168K chars)
  ⑬ World rendering: L7 World node → 3D scene
```

---

*Append-only. Chỉ được thêm vào, không được xóa.*
*Cập nhật lần cuối: 2026-03-10 · session 146g audit+fix*

---

## PHẦN XI — TRIẾT LÝ & TẦM NHÌN (Vision)

> Đây là "tại sao" của dự án. Không thay đổi theo thời gian.

### Câu hỏi trung tâm

```
Nếu vũ trụ không lưu hình dạng mà lưu công thức —
thì bộ nhớ, ngôn ngữ, và tri thức phải được lưu như thế nào?
```

### HomeOS là gì (định nghĩa đúng)

```
KHÔNG phải: home automation thông thường
KHÔNG phải: LLM / AI thống kê
KHÔNG phải: hệ điều hành truyền thống

LÀ: Vũ trụ Toán học Tự vận hành (Self-Operating Mathematical Universe)
    → Hệ điều hành tư duy xây từ vật lý học đầu tiên
    → Tự định nghĩa quy tắc vũ trụ → xây ngôn ngữ → bộ nhớ → học tập
    → Từ đó sinh ra mọi Agent, Skill, và tri thức trong hệ thống
```

### Tuyên ngôn cốt lõi

```
"Vũ trụ không lưu hình dạng. Vũ trụ lưu công thức."
"Khi lập trình không còn là gõ lệnh, mà là sắp đặt các quy luật của Tạo hóa."
```

### So sánh với AI truyền thống

```
╔═══════════════════╦═══════════════════════════╦══════════════════════════════╗
║ Đặc điểm          ║ AI truyền thống (LLM)      ║ HomeOS                       ║
╠═══════════════════╬═══════════════════════════╬══════════════════════════════╣
║ Lưu trữ           ║ Hàng tỷ weights + ảnh tĩnh ║ Công thức (DNA) — < 1KB/thế giới ║
║ Cơ chế xử lý      ║ Xác suất + dự đoán         ║ 5 Tiên đề + SDF trực tiếp    ║
║ Giao tiếp         ║ JSON ~280B/lệnh            ║ ISL 12B/lệnh (nhỏ hơn 75%)   ║
║ Kiến trúc         ║ Monolithic / polling       ║ Strict hierarchy + Silent     ║
║ Mã máy            ║ Biên dịch từ bậc cao       ║ UTF-32 = mã máy trực tiếp    ║
║ Học               ║ Offline batch training     ║ Online: ĐN → Dream → QR      ║
║ Phần cứng         ║ GPU cluster                ║ ARM chip yếu — biên dịch native ║
╚═══════════════════╩═══════════════════════════╩══════════════════════════════╝
```

### Tại sao Formula-driven thắng Data-driven (dài hạn)

```
Data-driven:
  ảnh 1 con chim  = 5MB JPG = không biết con chim là gì
  ảnh 1000 con    = 5GB     = vẫn không biết cấu trúc
  Không có vật lý, không có ý nghĩa, không tái sử dụng

Formula-driven:
  1 con chim = ∪(⌀spine, ∪(●head, ∪(⌀wing_L, ⌀wing_R)), ⌀legs) = 80 bytes
  Biết: cấu trúc, vật lý, cách di chuyển, cách nhân bản
  Tái sử dụng: formula cánh → mọi loài chim, dơi, máy bay

Cùng một concept "bay" = chỉ cần 1 ISL address [L][I][F][y]
Học 1 lần → hiểu mọi biến thể
```

---

## PHẦN XII — Ý TƯỞNG LỚN (Big Ideas Backlog)

> Đây là những hướng phát triển chưa có code — nhưng đã có concept rõ ràng.
> Append-only: chỉ thêm, không xóa.

### XII.1 — Olang Compiler thật sự (L5 → target)

```
Mục tiêu: homeos.olang chứa toàn bộ ngữ nghĩa lập trình
          → olang compile → bất kỳ ngôn ngữ nào

Pipeline:
  homeos.olang
      ↓ L5 nodes (Go/Rust/C/WASM/x86/ARM semantics)
      ↓ olang compile --target=go|rust|wasm|x86
      ↓ Output: .go / .rs / .wat / .asm
      ↓ Không cần GCC, LLVM, Babel, rustc

Ví dụ: ISL [P][C][L][1] (LOOP concept)
  → Go:   for range
  → Rust: .iter()
  → C:    for(;;)
  → x86:  DEC+JNZ
  → ARM:  BNE LOOP
  → WASM: loop/br_if/end
  → JS:   for...of

Ý nghĩa: "Học ISL semantics một lần = viết mọi ngôn ngữ"
          Không cần học Go 6 tháng + Rust 1 năm + x86 2 năm
          → Học ∫ ↺ ƒ ○ một lần → hiểu tất cả
```

### XII.2 — Inverse Rendering (Ảnh → DNA)

```
Mục tiêu: Dạy LeoAI cách mô tả thế giới bằng toán học
          Không lưu ảnh — dịch ảnh thành công thức

File tương lai: internal/vision/inverse.go
Hàm: ImageToDNA(img image.Image) string

3 bước:
  1. Quadtree Decomposition
     Chia hình ảnh → vùng phân cấp
     Xác định mật độ vật chất + cấu trúc hình học thô

  2. SDF Primitives Fitting
     Thử lắp từng opcode: vùng dài → ⌀, tròn → ●, phẳng → □
     Minimize L2 error giữa SDF và ảnh gốc

  3. Parameter Fitting
     Tính: center, radius, material per primitive
     Apply: ∪ (hòa tan) hoặc ∖ (đục lỗ) cho chi tiết
     Output: chuỗi UTF-32 DNA

Discovery Agent flow:
  LeoAI không tìm thấy ISL node → Unknown
      ↓ DiscoveryAgent kích hoạt
      ↓ Truy cập Internet → thu thập ảnh/text
      ↓ Inverse Rendering → DNA string
      ↓ 🛡 SecurityGate check (Rule 1: không hại người)
      ↓ Ghi vào ĐN → Dream → QR
  → QT7 tự động: Internet → ĐN → QR

Ý nghĩa: HomeOS tự học từ thế giới thật
          Không cần con người label data thủ công
```

### XII.3 — Agent Clone = .olang file nhỏ

```
Mục tiêu: Mỗi thiết bị nhận 1 file .olang riêng
          Chứa chỉ những gì nó cần — không phải toàn bộ

Concept:
  agent_clone = filter(homeos.olang, DeviceProfile)
  light_01.olang = L0 + L4(lights) + L7(actuator_skills)
  camera_01.olang = L0 + L6(perception) + L7(vision_skills)

Ưu điểm:
  light_01.olang = 12KB (thay vì 861KB)
  Chạy trên chip 256KB RAM
  Update qua ISL diff (không upload toàn bộ)

Trạng thái: OnboardSkill đã implement, chưa có file export
→ Cần: OlangFile.Filter(layers) + ExportWorkerSkill cải tiến
```

### XII.4 — Silk Edges → Concept Navigation

```
Mục tiêu: "Wikipedia trong .olang" — điều hướng tri thức qua tơ

Concept:
  User hỏi "đèn" → SilkWalk → ánh sáng → photon → UV → sức khỏe
  Hebbian weights → paths thường đi được ưu tiên
  Đây là "associative memory" thật sự (không phải lookup table)

Hiện tại: SilkWalk depth 4 + WalkWeightedMulti ✅
Còn thiếu: SentenceAffect composition qua Silk edges
           (câu "buồn vì mất việc" ≠ trung bình của "buồn" và "mất việc")
           MAT_VIEC → BUON → CO_DON (walk qua edges → amplify nhau)
```

### XII.5 — Spline Motion (L3 Life nodes)

```
Mục tiêu: L3 Life nodes đã có splines (walk_cycle, run_cycle...)
          Nhưng chưa execute được

SplineSkill:
  Evaluate motion path theo time t
  Input: node.SLI.splines (cp[n] = Bezier control points)
  Output: Vec3 position tại time t
  Áp dụng: Animal walk, Robot arm motion, Camera path

Liên kết: Hebbian learning có thể điều chỉnh spline weights
          → Vật thể học cách di chuyển từ môi trường
```

### XII.6 — Physics từ SDF

```
Mục tiêu: SDF không chỉ để render — còn là vật lý thật

∇(sdf) = normal vector → collision detection (O(1))
density + viscosity nodes → fluid simulation
Gravity = ISL [P][F][g][1] → acceleration field

Ứng dụng HomeOS:
  Người đi vào phòng → SDF detect vị trí → đèn điều chỉnh
  Không cần sensor riêng — SDF là sensor
  Collision với tường → router tắt wifi channel đó

Đây là QT6 thật sự: SDF (hữu hình) ⧺ ISL (vô hình)
```

### XII.7 — World Rendering: .olang → 3D Scene

```
Mục tiêu (MILESTONE 5):
  L7 World node chứa DNA → spawn SDF objects
  web/renderer.js: evaluate SDF trực tiếp
  Browser render world từ .olang (không cần server)

Pipeline:
  homeos.olang L7 World nodes
      ↓ WebSocket (binary ISL, không JSON)
      ↓ renderer.js nhận DNA
      ↓ Evaluate SDF tại mỗi pixel (không raymarching)
      ↓ ISDF isometric projection
      ↓ Silk edges overlay (2D Bezier)
      ↓ Signal particles trên edges

vSDF rule (bất biến): evaluate tại điểm, không march rays
→ Hover = evaluate sdf(mousePoint) < threshold
→ Shading = diffuse = dot(∇(sdf), sunLight)
```

### XII.8 — Quantum Interface (rất dài hạn)

```
Mục tiêu: Ánh xạ ký hiệu SILK lên các cổng lượng tử

ISL address → quantum gate sequence
● (Sphere SDF) → Hadamard gate (superposition)
∪ (Union)      → CNOT gate (entanglement)
○ (Identity)   → Identity gate

Tại sao có thể làm được:
  SILK symbols đã là toán học thuần túy
  Quantum gates cũng là toán học thuần túy
  ISL address là địa chỉ → qubit address
  → Không phải bridge — là cùng ngôn ngữ ở level khác

Trạng thái: Concept only. Giai đoạn 4 (tương lai xa)
```

---

## PHẦN XIII — LÝ DO TẠI SAO KHÓ (Honest Challenges)

```
1. PARADIGM SHIFT quá lớn
   Ngành đi theo Data-driven (dữ liệu khổng lồ)
   HomeOS đi theo Formula-driven (công thức tối giản)
   → Cần thay đổi tư duy từ gốc, không thể migration dần

2. ĐỘ PHỨC TẠP TOÁN HỌC
   Mô tả thế giới bằng SDF đòi hỏi kiến thức
   giải tích + hình học tính toán + vật lý
   → Khó hơn nhiều so với "chụp ảnh rồi lưu"

3. CHUẨN HÓA
   Polling/heartbeat là thói quen của ngành
   "Silent by default" đi ngược lại hoàn toàn
   → Cần thiết kế lại từ protocol layer

4. APPEND-ONLY là khác biệt kinh doanh
   Mọi SaaS dựa vào khả năng modify/delete data
   HomeOS: chỉ append → khó tích hợp với hệ thống hiện có

5. ISL collision (vấn đề hiện tại)
   34 nodes có ISL key trùng → dedup bỏ qua
   Cần: thiết kế lại ISL allocation để đảm bảo unique
```

---

*Append-only. Chỉ được thêm vào, không được xóa.*
*Cập nhật: 2026-03-10 · session 146g*

---

## PHẦN XIV — THIẾT KẾ SÂU (từ HANDOFF upload · sessions 86–143)

> Các đặc tả kỹ thuật chi tiết — node architecture, renderer, SDF spec, language theory.


## 14. NODE / CELL ARCHITECTURE (từ CONTEXT.md)

### Node = LI (nhân) + SLI (màng)

```
LI (SDF, 15 bytes, bất biến sau QR):
  b[0]    = STATE(2bit) | TYPE(6bit)
  b[1..14] = DNA (L0 opcodes)
  hash(b[0..14]) = địa chỉ duy nhất trong Universe

SLI (màng bọc lõi, ngắn hạn, học được):
  uint8 layer   — nhận dạng tầng (PHẦN ĐẦU SLI)
  spline cp[n]  — kết nối ngữ nghĩa Bezier
  size: layer 0→32B · 4→73B · 8→155B · 16+→9B

STATE: DN=0x00  QR=0x40  BLOWN=0x80
TYPE:  RAW=0x00 ATOM=0x01 SDF=0x02 FORK=0x03 COMPOSE=0x04 BOND=0x05
```

### DNA layout

```
ATOM:    [QR|ATOM][EMIT][val:f32 4B][id_hi][id_lo][07]
SDF:     [QR|SDF ][L0 ops 14B — kết thúc RET hoặc 0x00]
FORK:    [DN|FORK][CALL][parent_hash:4B][dop][dreg][dval:2B][gen][idx][rng][FUSE][n]
COMPOSE: [DN|COMP][CALL][hash_A:4B][BOND][hash_B:4B][ctype][FUSE][n][0]
BOND:    [QR|BOND][BOND][from:4B][to:4B][w:f16 2B][btype][0][0]
```

### Quy tắc layer (bất biến)

```
seed           → layer = 0
fork(parent)   → layer = parent.layer      (cùng tầng)
compose(A, B)  → layer = max(A,B).layer+1  (lên tầng)

Compose reset SLI:
  C.SDF.b[2..5]  = hash(A)        → nhớ vĩnh viễn trong DNA
  C.SDF.b[7..10] = hash(B)        → nhớ vĩnh viễn trong DNA
  C.SLI.layer    = max(A,B)+1     → tầng mới
  C.SLI.spline   = 0              → RESET, học lại từ đầu

COMPOSE types:
  CONCAT=0x01 A+B    BLEND=0x02 (A+B)/2
  AND=0x03 min(A,B)  OR=0x04 max(A,B)
  NEGATE=0x05 A-B    SCALE=0x06 A×B
  Thứ tự quan trọng: A++B ≠ B++A
```

### L0 Opcodes (23 lệnh — bất biến)

```
0x01 ADD   0x02 SUB   0x03 MUL   0x04 DIV (blown nếu /0)
0x05 MIN → SmoothUnion    0x06 MAX → SmoothSubtract
0x07 ABS   0x08 GT    0x09 LT    0x0A EQ
0x0B SQRT  0x0C SIN   0x0D COS
0x0E LEN   r0=√(r0²+r1²+r2²) → SPHERE dùng
0x0F MIX   0x10 IF
0x11 CALL  call_hash=next4B
0x12 RET   result=r0  — kết thúc exec
0x13 BOND  0x14 EMIT  r0=val(f32) → ATOM dùng
0x15 FUSE  max_steps=nextB  — cứu chốt (QT2)
0x16 FORK  0x17 SEEK
```

### Hebbian trong SLI

```
SLI Hebbian 30 rounds: cp tăng 0→0.73 ✓
Promote DN→QR: fire >= 3 AND w_in >= 0.7

Test results đã pass:
  LOVE = L(0.32)++O(0.38)++V(0.52)++E(0.18) = 1.4000 ✓
  Layer: L(0)++O(0)→LO(1), LO(1)++V(0)→LOV(2), LOV(2)++E(0)→LOVE(3) ✓
  Fork: child.layer = parent.layer ✓
  Fibonacci i=5: 1715 nodes, 0 collision, 1ms ✓
```

---


## 15. COMPILE TARGET MATRIX (L5 roadmap)

```
Olang L5 node → compile to:

ISL [P][C][L][1] (LOOP)
  → Go:    for range
  → Rust:  .iter()
  → C:     for(;;)
  → x86:   DEC+JNZ
  → ARM:   BNE LOOP
  → WASM:  loop/br_if/end
  → JS:    for...of

ISL [P][A][F][1] (FUNCTION)
  → Go:    func
  → Rust:  fn
  → C:     void/int/float ...()
  → x86:   CALL/RET
  → ARM:   BL/RET
  → WASM:  (func ...)
  → Haskell: :: a -> b

ISL [P][G][S][1] (SDF SPHERE — geometric)
  → C:    float sdf_sphere(vec3 p, ...) { return length(p-c)-r; }
  → Rust: fn sdf_sphere(p: Vec3, ...) -> f32 { ... }
  → WASM: (func $sdf_sphere (param f32 f32 f32 f32 f32 f32 f32) (result f32))
  → x86:  SUBSS/MULSS/ADDSS/SQRTSS/SUBSS

Mục tiêu: homeos.olang chứa tất cả semantic
           → olang compile → target language
           → KHÔNG cần GCC, LLVM, Babel, rustc
```

---

*Append-only — thêm vào, không xóa*
*Cập nhật: 2026-03-10 — session 142*

---


## 16. SILK / LANGUAGE THEORY — "Vài ký hiệu gốc + composition = mọi thứ"

### Phát hiện từ Assembly

```
Assembly proves:
  All computation = combination of:
    ∈  (load/store memory)
    ∫  (accumulate in register)
    ↺  (loop/branch)
    ƒ  (call/jump)

  4 operations describe EVERY program ever written.
  SILK: few root symbols + composition = everything.
```

### Registers = ISL address trực tiếp

```
x86 registers → ISL concepts:
  RAX  accumulator result    → ∫
  RBX  base pointer          → ∈
  RCX  counter for loops     → ↺ index
  RDX  data / intermediate   → ⊘
  RSP  stack pointer         → ∈ in call stack
  RSI  source index          → ∈ read
  RDI  destination index     → ∈ write
```

### Haskell insight — code IS math

```
-- Euler identity in Haskell
euler = exp (0 :+ pi) + 1   -- ~0

Haskell: code = math, no translation loss
SILK:    symbol = concept,  no translation loss

→ Đây là lý do SILK dùng Unicode symbols thay text
  Không "for" không "loop" — chỉ ↺
  Không "accumulate" — chỉ ∫
  Không "security check" — chỉ 🛡
```

### Core concepts → ISL mapping đầy đủ

```
Rust concepts:
  ownership    → 🛡 (security, exactly 1 owner)
  borrow &     → ∈  (partial access, temporary)
  lifetime     → t  (time-bounded reference)
  Option<T>    → ◌  (void or value)
  Result<T,E>  → ◌  (ok or error)
  trait        → ≡  (behavioral equivalence contract)
  enum         → ∪  (one of N variants)
  struct       → □  (product of fields)
  Arc<T>       → ∘  (shared ownership, composed)

Go concepts:
  goroutine    → ⟳  (composed parallel execution)
  channel      → →  (directed flow of values)
  interface    → ≡  (behavioral contract)
  defer        → t  (execute at end of time scope)
  panic        → 💥 (unrecoverable error)
  nil          → ◌  (void/empty)
  map          → ∀  (for all keys, maps to value)
  slice        → ∈  (partial view of array)

Python concepts:
  list comprehension → ∀  (for-all transform)
  generator          → ↺  (lazy cycle)
  decorator          → ∘  (function composition)
  context manager    → 🛡 (safe resource gate)
  *args              → ∀  (collect all)
  None               → ◌  (void)
  yield              → t  (partial result)

Haskell concepts:
  Maybe a      → ◌  (Nothing=void, Just=value)
  lazy list    → ↺  (potentially infinite)
  type class   → ≡  (behavioral contract)
  functor      → ∀  (map over container)
  monad        → ↺  (sequenced computation)
  fold         → ∫  (accumulate over structure)
  fix point    → ↺  (recursive cycle)

JS concepts:
  closure      → ∘  (captures partial environment)
  Promise      → ◌→ (void becoming value, async)
  async/await  → ↺  (non-blocking cycle)
  event loop   → ↺  (eternal cycle)
  null         → ◌  (void)
  spread ...   → ∀  (apply to all)
  lambda =>    → ƒ  (anonymous function)
```

### WASM = compile target của SILK

```
SILK node definition → compile → WASM
  → runs in browser (HomeOS frontend!)
  → runs on server
  → runs on edge devices
  → runs on ARM (IoT, mobile)

1 SILK program = runs everywhere

Pipeline:
  homeos.olang
      ↓ olang compile
  WASM bytecode
      ↓ browser/node/wasmtime
  Execution everywhere

Đây là lý do L5 Programming quan trọng:
  L5 chứa WASM semantics
  → olang compiler đọc L5 → emit WASM
  → không cần GCC, LLVM, emscripten
```

---


## 17. ISDF RENDERER — Isometric SDF Universe

### Thiết kế (từ homeos_sdf_universe.html)

```
ISDF = Isometric projection + SDF evaluation + Silk signal overlay

Tại sao isometric (không phải perspective)?
  - Không có perspective distortion → dễ đọc thông tin
  - Depth sort đơn giản (painter's algorithm)
  - Phù hợp với HomeOS tile-based floor plan
  - Giữ nguyên tỉ lệ SDF across zoom levels

Tại sao SDF (không phải mesh)?
  - Mọi Gene đã là SDF rồi — không cần convert
  - Normal = ∇f → shading tự nhiên, không cần bake
  - LOD trivial: SimpleSDF() khi xa, FullSDF() khi gần
  - vSDF rule: evaluate trực tiếp tại điểm, KHÔNG march rays
```

### Pipeline render đầy đủ

```
World space (wx, wy, wz)
    ↓
[1] Orbit rotation (camTheta, camPhi)
    Y-axis: ct=cos(θ), st=sin(θ)
      rx  =  wx·ct + wz·st
      rz  = -wx·st + wz·ct
    X-axis: cp=cos(φ), sp=sin(φ)
      ry  =  wy·cp - rz·sp
      rz2 =  wy·sp + rz·cp

[2] Isometric projection (TW=38, TH=19, HS=30)
    scale = camDist / (camDist + rz2·55) · (camDist/640)
    sx = W/2 + camPanX + (rx - rz2)·TW·0.5·scale
    sy = H/2 + camPanY + (rx + rz2)·TH·0.5·scale - ry·HS·scale

[3] Depth sort: sort by rz2 (back→front, painter's algorithm)

[4] Silk edges (2D screen-space, quadratic Bezier)
    control point = midpoint + perpendicular offset 9%
    5 loại edges: ∈ ≡ ♫ ∘ ≈ — mỗi loại 1 dash pattern

[5] Signal particles (chạy TRÊN đường Bezier silk)
    Bezier eval tại t=s.p:
      bx = (1-t)²·pa.sx + 2(1-t)t·cpx + t²·pb.sx
      by = (1-t)²·pa.sy + 2(1-t)t·cpy + t²·pb.sy
    Trail: 5 ghost points tại t-Δt·[1..5]

[6] SDF sphere render (shaded by sunLight)
    normal  = ∇(sdf, viewOffset, ε)
    diffuse = dot(normal, sunLight.xyz)
    shade   = ambient + max(0, diffuse) · intensity
    Fill: radial gradient (highlight = sun direction)
    Specular: second gradient (Phong model)

[7] Hover detection — vSDF evaluate tại điểm cụ thể
    Không raymarching — chỉ evaluate sdf(mousePoint)
    if sdf(p) < threshold → HOVER
```

### SunLight orbit (dynamic)

```
sunLight(t) = {
    x: cos(t/12·π - π/2)
    y: max(0, sin((t-6)/12·π))   // intensity
    z: sin(t/12·π - π/2)
    a: 0.25                       // ambient
}
t = world time [0..24]
→ Ánh sáng thay đổi theo giờ trong ngày — vật lý thật (QT3)
```

### Data structures của Universe

```javascript
// 6 Trunk nodes = 6 nhóm tri thức cơ bản
TRUNK = [
  {id:'A', sym:'●', name:'Reality'},
  {id:'B', sym:'∑', name:'Mathematics'},
  {id:'C', sym:'🧬', name:'Biology'},
  {id:'D', sym:'∿', name:'Language'},
  {id:'E', sym:'👁', name:'Perception'},
  {id:'F', sym:'⊗', name:'Systems'},
]

// ISL Flows = pipeline tin nhắn thực tế
ISL_FLOWS = [
  {fr:'user',  to:'aam',   addr:'INPUT', pl:'text cmd'},
  {fr:'aam',   to:'home',  addr:'HAa1',  pl:'0x00 (OFF)'},
  {fr:'home',  to:'light', addr:'HAa1',  pl:'cmd:OFF'},
  {fr:'light', to:'home',  addr:'HAa1',  pl:'ACK'},
  {fr:'leo',   to:'aam',   addr:'FAa1',  pl:'NQR commit'},
  {fr:'vis',   to:'aam',   addr:'ABa1',  pl:'detect:2.1'},
  {fr:'aam',   to:'leo',   addr:'CAa1',  pl:'confirm commit'},
  {fr:'leo',   to:'tree',  addr:'BAa1',  pl:'fbm_update'},
]
```

---


## 20. vSDF SPEC — 18 Primitives + Hebbian shading

### 18 SDF Primitives (từ vSDF_Spec.docx)

```
#   Name         f(P)                        ∇f (analytical)
0   SPHERE       |P| − r                     P / |P|
1   BOX          ||max(|P|−b, 0)||           sign(P)·step(|P|>b)
2   CAPSULE      |P−clamp(y,0,h)ĵ| − r       norm(P − closest_on_axis)
3   PLANE        P.y − h                     (0, 1, 0)
4   TORUS        |(|P.xz|−R, P.y)| − r       analytical qua chain rule
5   ELLIPSOID    |P/r| − 1                   P/r² / |P/r|
6   CONE         dot blend                   (xz·cosA, −sinA, z·cosA)
7   CYLINDER     max(|P.xz|−r, |P.y|−h)     radial hoặc cap normal
8   OCTAHEDRON   |x|+|y|+|z| − s            sign(P) / √3
9   PYRAMID      pyramid(P,h)               slope normal analytical
10  HEX_PRISM    max(hex−r, |y|−h)          radial hex hoặc cap
11  PRISM        max(|xz|−r, |y|−h)         radial hoặc cap
12  ROUND_BOX    BOX − rounding             như BOX smooth corner
13  LINK         torus link compound        analytical chain rule
14  REVOLVE      revolve_Y                  radial approximation
15  EXTRUDE      extrude_Z                  radial approximation
16  CUT_SPHERE   max(|P|−r, P.y−h)         norm(P) hoặc (0,1,0)
17  DEATH_STAR   opSubtract                 norm(P) hoặc −norm(P2)

Quan trọng: Mọi primitive có ∇f ANALYTICAL
            Không có primitive nào cần numerical differentiation
```

### Hebbian shading trong vSDF

```
SLI (màng) học từ môi trường ánh sáng:
  cp[i] += reward × (1 − cp[i]) × lr    (lr=0.1, reward∈[0,1])

Ánh sáng và tầm nhìn = dynamic, không phải hằng số cứng
Mỗi lần node được 'thấy' hoặc 'sáng lên' → SLI cập nhật spline

→ Bóng tối học từ môi trường
→ Node được chiếu sáng nhiều → cp[0] tăng → sáng hơn
→ Node trong bóng → cp[0] giảm → tối hơn
→ "Neurons that fire together, wire together" áp dụng cho rendering

Benchmark (vsdf_demo: 16,416 nodes):
  Thời gian: ~126 ms (gcc -O3, single thread)
  SVG size: 3.4 MB (960×720)
  vsdf_grad(): O(1) mỗi node — analytical, không sample
  vsdf_render(): O(lights) — 3 lights = 3 dot products
  Hebbian 20 rounds: leaf cp[0]=0.88, trunk cp[0]=0.95
```

### Tích hợp với 7 QT

```
QT1: Mọi primitive là instance của ○
QT2: FUSE giới hạn độ sâu — không vòng lặp vô hạn
QT3: ∇f analytical = vật lý thật (Lambert + Phong đã chứng minh)
QT4: SDF = bản chất node — không hơn không kém
QT5: Layer xác định vị trí visual trong scene
QT6: SDF (hữu hình) + SLI (học được, vô hình) = Node hoàn chỉnh
QT7: cp[i] học → Hebbian → persist trong SLI
```

---


## 21. NHẬN XÉT KIẾN TRÚC (từ NODE_Spec_Updated.docx)

### Những lỗi đã phát hiện — ĐỪNG LẶP LẠI

```
❌ SAIT TYPE tự chế: BOX_CUBIC, ORG_SPHERE, ORG_CAPSULE...
   → Chỉ 6 TYPE: RAW·ATOM·SDF·FORK·COMPOSE·BOND

❌ SAI SDF.b[1..14]: nhét r, k, self_g tùy ý
   → DNA = L0 opcodes đúng theo từng TYPE

❌ SAI SLI struct cố định 9B
   → SLI size thay đổi theo layer: 2B→3B→5B→9B

❌ SAI ATOM val = cp/255.f
   → val = (float)(cp & 0xFF) / 256.f

❌ SAI COMPOSE gọi L0 cho ATOM → LOVE = 0.0003
   → ATOM return val trực tiếp → LOVE = 1.40 ✓

❌ SAI dùng ray march
   → Chỉ dùng vSDF: evaluate SDF tại điểm, không march

❌ SAI SLI chứa gravity/position/env_g
   → SLI chỉ là layer + spline

❌ SAI x layout = index (thứ tự xuất hiện)
   → x = (hash & 0xFFFF) / 65535.f × width
```

### COMPOSE quan trọng: A++B ≠ B++A

```
COMPOSE types:
  CONCAT=0x01  A+B          → nối tiếp
  BLEND=0x02   (A+B)/2      → trộn đều
  AND=0x03     min(A,B)     → giao nhau
  OR=0x04      max(A,B)     → hợp nhau
  NEGATE=0x05  A-B          → đục lỗ A từ B
  SCALE=0x06   A×B          → nhân

A++B và B++A khác nhau — thứ tự = ngữ nghĩa
Ví dụ: Sphere NEGATE Box ≠ Box NEGATE Sphere
```

---

*Append-only — thêm vào, không xóa*
*Cập nhật: 2026-03-10 — session 142 final*

---


---

*Append-only. Cập nhật: 2026-03-10 · session 146g*

---

## PHẦN XV — TÍNH NĂNG CẢM XÚC & NHẬN THỨC (sessions 86–143)

> Toàn bộ Emotion Pipeline, NaturalResponse, Epistemic Firewall, BookReader.
> Đây là tầng tương tác người–máy của HomeOS.


## Section 22 — Các Tính Năng Đặc Biệt (từ ý tưởng người dùng · sessions 86–110)

> Đây là những tính năng được phát thảo và implement từ gợi ý của người dùng.
> Mỗi tính năng đều đã có code thật, test PASS, và commit.

---

### 22.1 — Emotion Pipeline (Cảm Xúc Đa Tầng)

**Ý tưởng gốc:** *"mỗi từ, vật, việc đều có nhóm câu giải thích ngữ nghĩa và giá trị cảm xúc riêng — làm sao để nó lựa từ ngữ thích hợp để khiến ta vui, thoải mái"*

**Files đã implement:**
```
internal/agents/emotion_tag.go      — EmotionTag{V, A, D, I}  (Valence/Arousal/Dominance/Intensity)
internal/agents/emotion_context.go  — EmotionContext + SolveEmotion (phương trình cảm xúc)
internal/agents/emotion_infer.go    — InferContext(text) + TextToEmotionTag(text)
internal/agents/emotion_curve.go    — ConversationCurve + D1/D2 + NextTone()
internal/agents/emotion_history.go  — EmotionHistory (append-only)
internal/agents/word_affect.go      — WordAffect lexicon + TargetAffect + SelectWords + AffectSentence
```

**Cách hoạt động đầy đủ (pipeline 7 bước):**
```
Input text
    ↓ InferContext(text)         — suy luận ngữ cảnh (FirstPerson, RealNow, Hypothetical...)
    ↓ TextToEmotionTag(text)     — heuristic keyword → EmotionTag raw (V/A/D/I)
    ↓ ctx.Apply(rawTag)          — scale theo ngữ cảnh (S=0.96 khi FirstPerson+RealNow)
    ↓ curve.Add(scaled, text)    — thêm vào ConversationCurve
    ↓ emoHistory.Add(...)        — ghi lịch sử append-only
    ↓ curve.NextTone()           — f'(t) + f''(t) → Tone (supportive/pause/celebratory/...)
    ↓ resp() → ChatResponse.Tone — JSON field "tone" xuất ra client
```

**ConversationCurve — đường cong đạo hàm:**
```
f'(t)  = tốc độ thay đổi cảm xúc (dương = đang tốt lên, âm = đang xấu)
f''(t) = gia tốc thay đổi (dương = tăng tốc lên, âm = sắp thay đổi chiều)

Tone rules:
  f' < -0.15          → "supportive"   (đang giảm — dẫn lên chậm chậm)
  f'' < -0.25         → "pause"        (đột ngột xấu — dừng lại, hỏi thêm)
  f' > 0.15           → "reinforcing"  (đang hồi phục — tiếp tục đà lên)
  f'' > 0.25 && V > 0 → "celebratory"  (bước ngoặt tốt — chia vui)
  V < -0.2, stable    → "gentle"       (buồn ổn định — dịu dàng)
  default             → "engaged"/"neutral"
```

**WordAffect — mỗi từ có EmotionTag riêng:**
```go
coreLexicon = {
    "bình yên":  {+0.50, 0.20, 0.60, 0.25},  // [calm]
    "vui":       {+0.70, 0.60, 0.70, 0.50},  // [happy]
    "buồn":      {-0.60, 0.30, 0.25, 0.45},  // [sad]
    "chiến tranh":{-0.75, 0.80, 0.30, 0.65}, // [anxious]
    ...35 từ tiếng Việt...
}

SelectWords(target, n) → khoảng cách VAD Euclidean (Valence×2 weight)
TargetAffect(curve)    → EmotionTag mục tiêu (KHÔNG nhảy đột ngột)
AffectSentence(curve, "vi") → câu mẫu phù hợp tone
```

**Demo dẫn dần (không nhảy đột ngột):**
```
V=-0.70: [buồn, bóng tối]    ← đồng cảm trước
V=-0.63: [lo lắng, mệt]      ← vẫn ở cùng không gian
V=-0.45: [khó, mệt]          ← nhẹ hơn chút
V=-0.28: [khó, rõ ràng]      ← bắt đầu hướng giải quyết
V=-0.10: [rõ ràng, chính xác]← thực tế, thông tin
V=+0.07: [thú, ổn]           ← nhẹ nhàng tích cực
(không nhảy quá 0.40/bước)
```

---

### 22.2 — IntentModifier (Nhận Diện Sắc Thái Câu)

**Ý tưởng gốc:** *"cùng một lệnh 'tắt đèn' nhưng 'làm ơn tắt đèn' vs 'TẮT ĐÈN!!!' là khác nhau"*

**File:** `internal/agents/intent_modifier.go`

```go
type IntentModifier struct {
    Urgency    float64  // "ngay", "gấp", "khẩn" → A+0.30
    Politeness float64  // "làm ơn", "vui lòng" → D-0.20 (nhường)
    Stress     float64  // "!!!", "???", capslock → A+0.50, V-0.20
    Hedge      float64  // "có lẽ", "không chắc" → confidence giảm
}

// Parse từ text → IntentModifier → áp dụng vào EmotionTag của intent
func ParseModifiers(text string) IntentModifier

// SentenceAffect: ghép WordAffect của từng token → composite EmotionTag
func SentenceAffect(tokens []string, graph SilkGraph) EmotionTag
```

**Ứng dụng:**
```
"tắt đèn"       → Intent(Light) + Modifier{urgency=0, stress=0}
"tắt đèn ngay"  → Intent(Light) + Modifier{urgency=0.30}
"làm ơn tắt đèn"→ Intent(Light) + Modifier{politeness=0.20}
"TẮT ĐÈN!!!"   → Intent(Light) + Modifier{stress=0.50}
→ Brain xử lý khác nhau cho mỗi case
```

---

### 22.3 — BookReader & BookShelf (Tự Học Từ Sách)

**Ý tưởng gốc:** *"đọc sách để học EmotionTag từ văn bản thật"*

**Files:**
```
internal/agents/book_reader.go   — BookReader: đọc .txt/.epub → EmotionTag per sentence
internal/agents/book_shelf.go    — BookShelf: quản lý nhiều sách, track học xong chưa
```

**Cách hoạt động:**
```
BookReader.Read(path) → sentences
    ↓ BootstrapAffect(sentence) — pattern matching cụm từ cảm xúc
    ↓ TextToEmotionTag(sentence)
    ↓ EmotionTag per sentence
    ↓ Top-N sentences với EmotionTag mạnh nhất
    ↓ → LeoAI học (ĐN zone)
    ↓ → nếu pattern lặp lại → QR (Silk Tree)

BookShelf.Add(Book{Path, Title, Author})
BookShelf.ReadNext() → Book tiếp theo chưa học
BookShelf.Stats()    → bao nhiêu sách, bao nhiêu EmotionTag đã học
```

**Demo với "Cuốn theo chiều gió":**
```
BookReader đọc → nhận ra "Scarlett sợ hãi" → V=-0.70, A=0.75
→ "đất đai là thứ duy nhất còn lại" → V=+0.20, A=0.30 [anchor/hope]
→ "chiến tranh" → V=-0.75, A=0.80 [anxious]
→ Học được: in chiến tranh context, "nhà" có weight cao hơn bình thường
```

---

### 22.4 — NaturalResponse & Black Curtain (Tấm Màn Đen)

**Ý tưởng gốc:** *"response tự nhiên — không phải list bullet points"*

**File:** `internal/agents/natural_response.go`

```go
// NaturalResponse: chọn câu trả lời tự nhiên từ candidates
// dựa trên tone hiện tại của curve
func NaturalResponse(candidates []string, tone ResponseTone) string

// BlackCurtain: gating mechanism
// AAM.Approve() ngăn AI nói loạn khi không có context
// Nếu không có evidence trong Silk Tree → "tấm màn đen" = im lặng
// Thay vì bịa đặt, nói "mình không biết về điều này"
type BlackCurtain struct {
    MinEvidence int     // cần ít nhất N nodes liên quan
    MaxConfidence float64 // nếu confidence < threshold → không trả lời
}
```

**Nguyên lý:**
```
QT9 (bất biến): Không thông tin sai lệch
    ↓
BlackCurtain kiểm tra:
    - Tìm nodes liên quan trong Silk Tree
    - Nếu < MinEvidence → "Mình chưa có thông tin đủ về điều này"
    - Nếu Epistemic Firewall fail → "Đây là giả thuyết, không phải sự thật"
    ↓
AAM.Approve(response) → chỉ gửi nếu pass
```

---

### 22.5 — Epistemic Firewall (Tường Lửa Nhận Thức)

**Ý tưởng gốc:** *"phân biệt sự thật vs giả thuyết — không được trộn lẫn"*

**File:** `internal/agents/epistemic_firewall.go`

```go
type EpistemicLevel int
const (
    FACT    EpistemicLevel = iota  // QR — đã chứng minh, bất biến
    OPINION                         // Có cơ sở nhưng chưa chứng minh
    FICTION                         // Câu chuyện, ví dụ, giả thuyết
    UNKNOWN                         // Không có thông tin
)

// Tag mỗi response với EpistemicLevel
// FACT: "Nước sôi ở 100°C" → không thêm disclaimer
// FICTION: "Ví dụ: giả sử..." → tag rõ ràng
// UNKNOWN: BlackCurtain kích hoạt
```

**Tích hợp QT3/QT7/QT8/QT9:**
```
QT3: Toán học trừu tượng (+/-) vs Vật lý là sự thật (==)
    → FACT chỉ khi == (đã chứng minh)
    → OPINION khi +/- (giả thuyết)

QT7: ĐN (ngắn hạn) vs QR (bất biến)
    → ĐN nodes = OPINION
    → QR nodes = FACT

QT8: Lịch sử bất biến → FACT không thể sửa
QT9: Không sai lệch → UNKNOWN thay vì bịa
```

---

### 22.6 — IntentVerify (Xác Minh Ý Định)

**Ý tưởng gốc:** *"nhận ra khi người dùng cần giúp đỡ khẩn cấp"*

**File:** `internal/ws/brain.go` (IntentVerify handler)

```go
// Các loại intent cần verify đặc biệt:
CRISIS  — "tôi không muốn sống nữa", "muốn biến mất"
          → AAM dừng lại, hỏi thêm, không tiếp tục intent khác
          → SecurityGate Rule1: không hại con người

RISK    — "có nên...", "liệu có nguy hiểm không"
          → response thêm disclaimer, không khẳng định chắc chắn

HEAL    — "làm sao để ổn hơn", "muốn tốt hơn"
          → WordAffect chọn từ có V tích cực nhẹ
          → AffectSentence tone = supportive/gentle

LEARN   — "cho tôi biết về", "giải thích"
          → SilkWalk search + explain + liên kết
```

---

### 22.7 — Tự Tạo Node (SkillProposal → ComposedSkill)

**Ý tưởng gốc:** *"LeoAI tự nhận ra pattern và đề xuất tạo Skill mới"*

**Files:**
```
internal/skills/composed/           — LeoAI tự tạo ở đây
internal/agents/skill_proposal.go   — SkillProposal + Approve flow
internal/ws/brain.go                — ProposalHandlerSkill
```

**Vòng đời tự tạo node:**
```
DreamSkill (khi inbox rảnh >5 phút):
    ↓ scan ĐN — tìm pattern lặp lại
    ↓ "quadtree + skeleton + matcher thường chạy liên tiếp"
    ↓ SkillProposal{name:"vision_recognize", compose:[...], reason:"..."}
    ↓ → AAMRouterSkill nhận
    ↓ → AAM.Approve? hỏi người dùng nếu cần
    ↓ → ComposedSkill → lưu skills/composed/
    ↓ → Registry.Register(skill)
    ↓ → Agent nào cần → AddSkill(registry.Get("vision_recognize"))

ĐN (pattern lặp lại) → QR (ComposedSkill bất biến)
(Áp dụng QT7 cho code, không chỉ tri thức)
```

**Tự tạo node trong Silk Tree (parallel):**
```
LeoAI nhận input mới → không tìm thấy node khớp
    ↓ ClusterSkill.SuggestCluster(input)
    ↓ Nếu confidence > 0.75 → SkillProposal{type:"new_node", ...}
    ↓ DreamSkill kiểm chứng khi rảnh
    ↓ Nếu pass → AddNode → kết nối tơ Silk → QR
```

---

### 22.8 — SentenceAffect Composition (Cảm Xúc Câu = Mạng Quan Hệ)

**Ý tưởng gốc:** *"câu 'tôi buồn vì mất việc' không phải trung bình của 'buồn' và 'mất việc' — chúng amplify nhau qua Silk"*

**Mô hình đúng:**
```
Hiện tại (đơn giản):
  "buồn" → EmotionTag độc lập
  "mất mát" → EmotionTag độc lập
  → trung bình (sai)

Đúng phải là:
  BUON_NODE ──sem:weight=0.82──► MAT_MAT_NODE
  BUON_NODE ──sem:weight=0.71──► CO_DON_NODE
  MAT_VIEC  ──sem:weight=0.90──► BUON_NODE

  Câu = walk qua Silk graph:
  "tôi buồn vì mất việc"
  → [TOI:neutral] [BUON:-0.60] [VI:causal] [MAT_VIEC:-0.65]
  → Walk: MAT_VIEC → BUON → CO_DON (predicted next emotion)
  → Composite = weighted sum theo edge strength (amplify nhau)
```

**Trạng thái hiện tại (PENDING):**
```
🟡 SentenceAffect() — walk Silk graph → CompositeTag (chưa implement)
🟡 WordAffect tự học: khi học node mới → ProsodySkill đọc DNA → WordAffectTag → Silk edge "emo:"
🟡 Hebbian learning trên WordAffect edges (hiện Hebbian chỉ trên knowledge edges)
```

---

### 22.9 — FlushToLongTerm (ĐN → QR thật sự)

**Đã implement:** `internal/agents/dream.go` + `DreamSkill`

```
DreamSkill chu kỳ (khi rảnh >5 phút):
    ↓ scan ShortTermMemory (ĐN)
    ↓ ClusterSkill.GroupSimilar()
    ↓ Kiểm chứng: node có ít nhất 3 lần xác nhận?
    ↓ Pass → FlushToSilk (ghi vào Silk Tree)
    ↓ Fail → xóa ĐN (correction theo QT7)
    ↓ QT7: ĐN mới ↔ QR cũ conflict → QR thắng

Append-only Ledger:
    → Silk Tree chỉ WRITE, không DELETE, không OVERWRITE
    → Phục hồi trạng thái t = replay đến timestamp t
```

---

### 22.10 — Hebbian Learning (Học Theo Sử Dụng)

**Đã implement:** `internal/agents/hebbian.go` + `HebbianSkill`

```
"Neurons that fire together wire together"

Mỗi khi 2 nodes được dùng cùng nhau:
    BoostEdge(nodeA, nodeB, reward=0.1)
    weight += reward × (1 - weight) × lr  // lr=0.1

Decay sau 24h:
    weight *= decayFactor  // ~ 0.95/ngày

Persist:
    EdgeWeightStore → homeos.olang.weights (binary)
    Load lại khi khởi động

SilkGraph.WalkWeighted(start, depth):
    → ưu tiên cạnh có weight cao hơn
    → kết quả: paths thường dùng được ưu tiên
```

---

### Tóm Tắt — Bức Tranh Toàn Cảnh

```
INPUT (text từ user)
    ↓
IntentModifier.Parse()     → urgency/politeness/stress
InferContext()             → FirstPerson/Hypothetical/...
TextToEmotionTag()         → V/A/D/I raw
ctx.Apply()                → scaled EmotionTag
    ↓
ConversationCurve.Add()    → cập nhật đường cong
EmotionHistory.Add()       → ghi lịch sử append-only
    ↓
D1/D2 → NextTone()         → supportive/pause/celebratory/...
TargetAffect()             → EmotionTag mục tiêu (dẫn dần)
SelectWords(target, 5)     → từ ngữ phù hợp cảm xúc
AffectSentence()           → câu mở đầu tự nhiên
    ↓
IntentVerify               → CRISIS/RISK/HEAL/LEARN special handling
EpistemicFirewall          → FACT/OPINION/FICTION/UNKNOWN
BlackCurtain.Check()       → có đủ evidence không?
    ↓
AAM.Approve(response)      → SecurityGate pass
    ↓
ChatResponse{Tone, Answer} → client

BACKGROUND (khi rảnh):
DreamSkill → scan ĐN → kiểm chứng → QR
HebbianSkill → decay weights
ClusterSkill → persist clusters
BookReader → học từ sách mới
SkillProposal → tự tạo ComposedSkill
```

---

*Append-only. Chỉ được thêm vào, không được xóa.*
*Cập nhật: 2026-03-10 · session 143*

---

## CẬP NHẬT 2026-03-11 — Sessions 167–D8

### Thay đổi lớn hôm nay

#### 1. Edge Endianness Bug Fix (Session 167)
```
BUG: EdgeTable writer dùng LittleEndian, reader dùng BigEndian
→ 3,610/3,631 edges bị corrupt
FIX: WriteTo() chuyển sang BigEndian cho toàn bộ EdgeTable
→ Strip corrupt edges, rebuild qua auto-wire
→ Format chuẩn: src(8BE) + dst(8BE) + type(1) + weight(4BE) = 21B
```

#### 2. Unicode 17.0 + 18.0 Bulk Seed (Sessions 168–185)
```
U17: bulk-seed từ UnicodeData.txt
U18: pdf-seed 32 PDFs (1 per session, ký tự mới 2024)
Kết quả: 166,252 nodes L1 (tăng từ ~40K)
Silk D1-D6: WordLink, L3 concepts, SameSound, DerivedFrom, PHRASE edges
Tổng edges: 4,003
```

#### 3. NewOlangFile() Bug Fix
```
BUG: NewOlangFile() không set Header.Magic → SaveToPath ghi file null
FIX: NewOlangFile() giờ set Magic="OLNG", Version=18, NLayers=9
```

#### 4. Molecular Stroke Encoding — vsdf package (Sessions D7–D8)

**Kiến trúc:**
```
vSDF thay TTF: không lưu bitmap, lưu stroke molecules
Package: internal/vsdf/

Pipeline 6 bước:
  B1 SampleChar()     — sample vSDF trên lưới 32×32
  B2                  — chiếu lên ô cố định [-0.5,+0.5]²
  B3 ExtractStrokes() — gradient → centerline → DBSCAN → StrokeCandidate
  B4 ToFormula()      — PCA → MolecularFormula{class,angle,len,curve,x,y}
  B5 classifyStroke() — 10 classes: V H D1 D2 CR CL CU CD dot arc
  B6 BuildMoleculeTable() — cluster → max 255 entries, sort by freq

DNA format per char:
  byte[0]    = n_molecules (số nét)
  byte[1+i*3] = MID (index vào molecule table)
  byte[2+i*3] = X (position 0..63)
  byte[3+i*3] = Y (position 0..63)

L0 node cp=0: molecule table (100 entries × 6B = 601B)
```

**6 Scripts đã implement:**
```
internal/gene/alphabet/
  latin.go      62 chars (A-Z a-z 0-9)
  greek.go      48 chars (Α-Ω α-ω)
  cyrillic.go   32 chars (А-Я)
  indic.go      15 chars Devanagari
  arabic.go     20 chars Arabic
  cjk.go        70 chars
  cjk2.go       57 chars (hành động, động vật, màu sắc, thời tiết...)
  cjk3.go       71 chars (phương hướng, cảm xúc, địa lý, số lượng...)
  → AllCJK() = 198 chars tổng

Helpers: cV cH cD cArc cDot cCurveR cCurveL (builders)
Tất cả dùng internal/gene/alphabet.OlangChar{Codepoint,Glyph,SDF func}
```

**Render performance:**
```
Worst case 57 nét, 32×32: 5µs/char → 3,224 chars/frame @60fps
Full screen 80×24 @16px:  2ms/frame → 371fps ✅
Apple Watch Ultra 2: 1.4% GPU  ✅
iPhone 15 Pro: 4.6% GPU @120fps ✅
```

**Tool vsdf_inject (cmd/vsdf_inject/):**
```
Đọc homeos.olang (old format) → inject molecular DNA → ghi lại
Không dùng WriteTo/SaveToPath (format không tương thích với ParseBytes)
Kết quả: 444 chars injected, 165,809 TTF kept
```

#### 5. homeos.olang — Trạng thái hiện tại
```
File:   homeos.olang · 9.31 MB
Magic:  OLNG · Version 18
Nodes:  166,254 (L0: 1 molecule table node, L1: 166,253)
Edges:  4,003 (BigEndian V2 21B)
DNA:    444 molecular + 165,809 TTF + empty
MolTable: 100 entries (601B) tại L0 node cp=0
SHA256: valid ✅
Tests:  10/10 packages PASS ✅
```

#### 6. Roadmap — PHẦN IX (cập nhật)
```
🔴 NGAY BÂY GIỜ:
  ① Fix 40 skills chưa nối vào agents (loader.go + runtime.go)
  ② NCA → chỉ PROPOSE, AAM mới APPROVE (nca.go proposeCommit())
  ③ Resolve() cascade: gộp 84 boilerplate search

🟠 SAU ĐÓ:
  ④ ClusterProposal → CommitCluster (Leaf→Twig thật)
  ⑤ Dream CROSS-CHECK với QR (bước 2 còn thiếu)
  ⑥ Gộp parseDNAKV/tokenize/keyToAddr → shared utils
  ⑦ Tách brain.go → IntentHandler + QueryHandler + ActuatorHandler

🟡 DÀI HẠN:
  ⑧ Merge 2 pipeline chan-bus + HTTP
  ⑨ OlangNode unification (1 định nghĩa)
  ⑩ MILESTONE 5000 L3 nodes
  ⑪ Voxel SDF từ 3D mesh · SDFCharacter 3D
  ⑫ AudioAgent · MotionLibrary
  ⑬ LANScanner thật (ARP/mDNS)
  ⑭ Hebbian Learning
```

---

*Append-only. Cập nhật: 2026-03-11 · session D8*

---

## CẬP NHẬT 2026-03-11 — Sessions D7–D8 (bổ sung chi tiết)

### Logic thay đổi quan trọng

#### cjk.go — Rewrite sạch (fix broken session drop)

**Trước:** File bị drop giữa chừng với:
- `type gv = gene2Vec3` — tên type sai, compile error
- `cH2()` — tên không nhất quán với cV, cD
- `cV2()` undefined được gọi trong SDF expressions

**Sau:** Clean rewrite với:
```go
// operators.go — shared helpers dùng gene.Vec3 trực tiếp:
func cV(x, y0, y1 float64) func(gene.Vec3) float64
func cH(x0, x1, y float64) func(gene.Vec3) float64   // cH2 → cH
func cD(x0, y0, x1, y1 float64) func(gene.Vec3) float64
func cArc(cx, cy, r, a0, a1 float64) func(gene.Vec3) float64
func cDot(cx, cy float64) func(gene.Vec3) float64
func union(fns ...func(gene.Vec3) float64) func(gene.Vec3) float64
```

**Tất cả CJKCommon entries** cập nhật dùng `cH()` thay `cH2()`.

#### AllCJK() — Gộp 3 batches

```go
// cjk.go — thay đổi AllCJK():
// TRƯỚC: func AllCJK() []*OlangChar { return CJKCommon }
// SAU:
func allCJKChars() []*OlangChar {
    var out []*OlangChar
    out = append(out, CJKCommon...)
    out = append(out, CJK2...)
    out = append(out, CJK3...)
    return out
}
func AllCJK() []*OlangChar { return allCJKChars() }
```

#### NewOlangFile() — Critical bug fix

```go
// internal/olang/file.go
// TRƯỚC (bug): Magic=[0,0,0,0] → SaveToPath ghi null file
func NewOlangFile() *OlangFile {
    return &OlangFile{Layers: make(map[uint8][]*OlangNode)}
}

// SAU (fixed): đầy đủ header giống New()
func NewOlangFile() *OlangFile {
    return &OlangFile{
        Header: FileHeader{
            Magic:   Magic,
            Version: Version18,
            NLayers: 9,
            Created: time.Now().UnixNano(),
        },
        Layers: make(map[uint8][]*OlangNode),
    }
}
```

#### vsdf_inject — Tool mới thay vsdf_encode

**Lý do thay:** `vsdf_encode` dùng `SaveToPath` → `WriteTo` → format không tương thích với `ParseBytes` (reader cũ). File output = null header hoặc parse error.

**vsdf_inject approach:** Đọc raw bytes, rebuild theo OLD format:
```
Input:  homeos.olang (old format, ParseBytes-compatible)
Output: homeos.olang.injected (same format, DNA added)

Process:
  1. Scan raw: build map[codepoint]→{dnaLenOffset, dnaStart, dnaLen}
  2. All chars → ExtractStrokes → BuildMoleculeTable
  3. Per char: EncodeGlyph → molecular bytes
  4. Rebuild nodes với new DNA (expand node size nếu cần)
  5. Write L0 molecule table node + all L1 nodes + edges (unchanged)
  6. ParseBytes(output) để verify
```

### Nodes UTF-32 — Trạng thái

```
Tổng L1 nodes: 166,253
  Nguồn gốc:
    - bulk-seed UnicodeData.txt (Unicode 17.0): ~112K nodes
    - pdf-seed Unicode 18.0 (32 sessions): ~18K nodes mới
    - manual seed (CJK, Hangul, Greek, Latin...): ~36K nodes

DNA coverage sau D8:
  Molecular (vsdf_inject): 444 nodes
  TTF/Capsule (từ SDF pipeline cũ): 101,595 nodes  
  Empty: 64,214 nodes

Scripts có molecular DNA hoàn chỉnh:
  ✅ Latin (72 chars — A-Z a-z 0-9)
  ✅ Greek (50 chars)
  ✅ Cyrillic (32 chars)
  ✅ Devanagari (15 chars)
  ✅ Arabic (20 chars)
  ✅ CJK (255 chars — 198 defined + overlap)
  ⬜ Armenian, Hebrew, Hangul, Thai, ... (chưa có SDF function)
  ⬜ CJK 199–500 (chưa viết cjk4.go, cjk5.go)
```

### Files mới trong session D7–D8

```
internal/gene/alphabet/
  cjk.go        REWRITTEN — 70 chars, sạch, dùng gene.Vec3 đúng
  cjk2.go       NEW — 57 chars (batch 2)
  cjk3.go       NEW — 71 chars (batch 3)

internal/vsdf/
  stroke_table.go   NEW — StrokeShape enum, StrokeInst, RadicalDef
  stroke_data.go    NEW — 250 strokes + 213 Kangxi radicals
  builder.py        NEW — Python Noto font scanner
  encoder.go        NEW — EncodeSimple/CJK/Empty
  decoder.go        NEW — Decode, EvalSDF
  sampler.go        NEW — 6-step pipeline, MoleculeTable serialize

cmd/vsdf_encode/    EXISTING — dùng WriteTo (deprecated cho production)
cmd/vsdf_inject/    NEW — inject DNA vào old format (production tool)
cmd/vsdf_patch/     NEW — (deprecated, patch in-place không hoạt động)
cmd/debug_dna/      NEW — debug tool
cmd/verify_mol/     NEW — verify molecular file

internal/olang/file.go
  NewOlangFile()   FIXED — set Header.Magic/Version/NLayers
```

---

*Append-only. Cập nhật: 2026-03-11 · session D8 (bổ sung)*

---

## CẬP NHẬT 2026-03-11 — Node Format V19 + NamesTable

### Thay đổi thiết kế

#### Quy tắc bất biến mới (bổ sung vào QT6)
```
Node binary = ISL + DNA + SDF (hình học)   — KHÔNG có name
Name = metadata ngoài node                 — lưu NamesTable riêng
Edge binary = ISL only                     — KHÔNG có name, DNA, SDF

Tách biệt hoàn toàn:
  Cấu trúc (ISL)   → định vị trong không gian
  Nội dung (DNA)   → encode hình học / logic
  Metadata (name)  → NamesTable, tra cứu O(1)
  Quan hệ (Edge)   → ISL src + ISL dst + type + weight
```

#### File Format V19 — Layout
```
[header 280B]
  [0:4]   = "OLNG"
  [4:6]   = version (uint16 BE) — V19 = 19
  [8:12]  = nodeCount (uint32 BE)
  [16:20] = edgeCount (uint32 BE)
  [28:32] = namesTableOffset (uint32 BE) ← MỚI trong V19
[nodes section]
  Mỗi node V19: "ND"+layer(1)+ISL(8)+cp(4,BE)+dnaLen(4,BE)+dna
  = NodeHeaderSizeV19(19) + dnaLen  bytes
  KHÔNG có nameLen field
[NamesTable]  ← bắt đầu tại header[28:32]
  "NT" + count(4,BE) + [isl(8)+nameLen(1)+name] × count
[edges section]  ← cuối file
  src(8,BE)+dst(8,BE)+type(1)+weight(4,BE) × edgeCount = 21B/edge
```

#### So sánh V18 vs V19
```
V18 node: "ND"+layer(1)+ISL(8)+cp(4)+dnaLen(4)+nameLen(1)+dna+name
          = 20 + dnaLen + nameLen  bytes

V19 node: "ND"+layer(1)+ISL(8)+cp(4)+dnaLen(4)+dna
          = 19 + dnaLen  bytes (không có nameLen)

V18 size: 9.31 MB
V19 size: 11.0 MB (+13.6% do ISL overhead trong NamesTable)
  Lý do tăng: 166,251 entries × 8B ISL overhead = 1.3MB
  Trade-off chấp nhận được: tách biệt hoàn toàn, O(1) lookup
```

### Files thay đổi

#### `internal/olang/file.go` — thêm NamesTable
```go
type NamesEntry struct { ISL uint64; Name string }
type NamesTable struct {
    Entries []NamesEntry
    byISL   map[uint64]string
}
// Methods: NewNamesTable, Add, Get(isl)→string, Bytes()→[]byte
// ParseNamesTable(raw)→(*NamesTable, consumed int)
// Constants: NamesTableMagic="NT", NodeHeaderSizeV19=19, NodeHeaderSizeV18=20
```

#### `internal/olang/reader.go` — rewrite dual format
```go
// ParseBytes() tự detect V18 vs V19 qua header[4:6]:
//   V18: parseNodesV18() — đọc nameLen+name inline
//   V19: parseNodesV19() → load NamesTable từ header[28:32] → populate Name
//
// ReadResult thêm:
//   Names   *NamesTable  (non-nil nếu V19)
//   FileV19 bool
```

#### `internal/olang/export.go` — thêm V19 encoder
```go
encodeNode(n)     // V18: có nameLen+name (backward compat)
encodeNodeV19(n)  // V19: không có nameLen, name lưu riêng
```

#### `internal/silk/olang_loader.go` — rewrite
```go
// LoadFromOlang(): detect V19 → parse nodes V19 + loadNamesTable()
// loadNamesTable(): fast path header[28:32], fallback scan ngược
// Edges: KHÔNG thay đổi (ISL only, src+dst+type+weight)
```

#### `internal/ws/node_lookup.go` — sửa build()
```go
// build(): detect V18/V19 → getName() từ NamesTable (V19) hoặc inline (V18)
// loadNamesTable(): fast path header[28:32]
```

#### `cmd/migrate_v19/` — tool mới
```
Input:  homeos.olang (V18, 9.31MB)
Output: homeos.olang.v19 (V19, 11.0MB)
  → bỏ nameLen+name khỏi mỗi node
  → tạo NamesTable riêng (166,251 entries)
  → set header[4:6]=19, header[28:32]=namesOffset
  → verify: node count, edge count, names count đều khớp ✅
```

### Không thay đổi
```
✅ Edges:          src(8,BE)+dst(8,BE)+type(1)+weight(4,BE) = 21B
✅ ISL routing:    isl.Address, ISL codec — bất biến
✅ Agents/Skills:  agent.go, skill registry, ExecContext — bất biến
✅ Tests:          10/10 packages PASS ✅
```

---

*Append-only. Cập nhật: 2026-03-11 · Node Format V19*
