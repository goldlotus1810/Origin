// vsdf_patch: patch DNA trực tiếp vào homeos.olang (old binary format)
package main

import (
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene/alphabet"
	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/vsdf"
)

func allChars() []*alphabet.OlangChar {
	var out []*alphabet.OlangChar
	out = append(out, alphabet.AllLatin()...)
	out = append(out, alphabet.AllGreek()...)
	out = append(out, alphabet.AllCyrillic()...)
	out = append(out, alphabet.AllDevanagari()...)
	out = append(out, alphabet.AllArabic()...)
	out = append(out, alphabet.AllCJK()...)
	return out
}

type nodeMeta struct{ dnaLenOff, dnaOff, dnaLen int }

func main() {
	path := "homeos.olang"
	if len(os.Args) > 1 { path = os.Args[1] }

	log.Printf("Loading %s...", path)
	raw, err := os.ReadFile(path)
	if err != nil { log.Fatal(err) }
	if len(raw) < 20 || string(raw[0:4]) != "OLNG" { log.Fatal("bad magic") }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	log.Printf("edgeStart=%d nedges=%d", edgeStart, nedges)

	// Scan nodes by codepoint
	nodeMap := map[uint32]*nodeMeta{}
	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
		dnaLenOff := pos + 15
		dnaLen := int(binary.BigEndian.Uint32(raw[dnaLenOff:]))
		nameLen := int(raw[pos+19])
		if dnaLen < 0 || dnaLen > 100000 { pos++; continue }
		nodeMap[cp] = &nodeMeta{dnaLenOff, pos + 20, dnaLen}
		pos += 20 + dnaLen + nameLen
	}
	log.Printf("Mapped %d nodes", len(nodeMap))

	// Build strokes → molecule table
	t0 := time.Now()
	chars := allChars()
	log.Printf("Alphabet: %d chars", len(chars))
	var strokes []vsdf.StrokeCandidate
	for _, ch := range chars {
		if ch.SDF == nil { continue }
		strokes = append(strokes, vsdf.ExtractStrokes(vsdf.SampleChar(ch.Codepoint, ch.SDF))...)
	}
	mt := vsdf.BuildMoleculeTable(strokes)
	log.Printf("Molecule table: %d entries", len(mt.Entries))

	// Patch in-place
	patched := make([]byte, len(raw))
	copy(patched, raw)

	mol, kept, notFound := 0, 0, 0
	perScript := map[string][2]int{}

	for _, ch := range chars {
		if ch.SDF == nil { continue }
		meta, ok := nodeMap[ch.Codepoint]
		if !ok { notFound++; continue }

		g := vsdf.EncodeGlyph(ch.Codepoint, ch.SDF, mt)
		newDNA := g.Bytes()

		if len(newDNA) == 0 || len(newDNA) > meta.dnaLen {
			kept++
			continue
		}

		copy(patched[meta.dnaOff:], newDNA)
		for i := len(newDNA); i < meta.dnaLen; i++ {
			patched[meta.dnaOff+i] = 0
		}
		binary.BigEndian.PutUint32(patched[meta.dnaLenOff:], uint32(len(newDNA)))
		mol++

		s := perScript[ch.Script]
		s[0]++
		s[1] += len(newDNA)
		perScript[ch.Script] = s
	}

	log.Printf("Done in %v: mol=%d kept=%d notFound=%d", time.Since(t0), mol, kept, notFound)

	outPath := path + ".patched"
	if err := os.WriteFile(outPath, patched, 0644); err != nil { log.Fatal(err) }
	fi, _ := os.Stat(outPath)

	fmt.Printf("\n=== DONE ===\n")
	fmt.Printf("Output:    %s (%.2fMB → original %.2fMB)\n",
		outPath, float64(fi.Size())/1024/1024, float64(len(raw))/1024/1024)
	fmt.Printf("Molecular: %d | Kept TTF: %d | NotFound: %d\n", mol, kept, notFound)
	fmt.Printf("\nPer-script:\n")
	for _, sc := range []string{"latin","greek","cyrillic","devanagari","arabic","cjk"} {
		v := perScript[sc]
		if v[0] > 0 { fmt.Printf("  %-12s %3d chars  avg=%dB\n", sc, v[0], v[1]/v[0]) }
	}
}
