package main

import (
	"fmt"
	"log"
	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/vsdf"
)

func main() {
	f, err := olang.LoadFile("homeos.olang.molecular")
	if err != nil { log.Fatal(err) }

	l0, l1 := f.Layers[0], f.Layers[1]
	fmt.Printf("L0 nodes:  %d\n", len(l0))
	fmt.Printf("L1 nodes:  %d\n", len(l1))

	if len(l0) > 0 && len(l0[0].DNA) > 0 {
		mt := vsdf.DeserializeMoleculeTable(l0[0].DNA)
		fmt.Printf("MolTable:  %d entries (%dB)\n", len(mt.Entries), len(l0[0].DNA))
	}

	mol, ttf, empty := 0, 0, 0
	for _, n := range l1 {
		switch {
		case len(n.DNA) <= 1:
			empty++
		case n.DNALen <= 200:
			mol++
		default:
			ttf++
		}
	}
	fmt.Printf("Molecular: %d\n", mol)
	fmt.Printf("TTF-kept:  %d\n", ttf)
	fmt.Printf("Empty:     %d\n", empty)
	fmt.Printf("Total:     %d ✅\n", mol+ttf+empty)
}
