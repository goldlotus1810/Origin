package main

import (
	"fmt"
	"log"
	"os"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

func main() {
	raw, _ := os.ReadFile("homeos.olang")
	res, err := olang.ParseBytes(raw)
	if err != nil { log.Fatal(err) }
	l1 := res.ByLayer[1]
	hasDNA, empty := 0, 0
	for _, n := range l1 {
		if len(n.DNA) >= 2 { hasDNA++ } else { empty++ }
	}
	fmt.Printf("L1: %d total | with DNA: %d | empty: %d\n", len(l1), hasDNA, empty)
}
