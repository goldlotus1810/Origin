package main

import (
	"fmt"
	"log"
	"os"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene/alphabet"
	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/vsdf"
)

func allChars() []*alphabet.OlangChar {
	var out []*alphabet.OlangChar
	out = append(out, alphabet.AllLatin()...)
	out = append(out, alphabet.AllGreek()...)
	out = append(out, alphabet.AllCyrillic()...)
	out = append(out, alphabet.AllDevanagari()...)
	out = append(out, alphabet.AllArabic()...)
	out = append(out, alphabet.AllCJK()...)
	return out
}

func main() {
	path := "homeos.olang"
	if len(os.Args) > 1 { path = os.Args[1] }

	log.Printf("Loading %s...", path)
	f, err := olang.LoadFile(path)
	if err != nil { log.Fatal(err) }
	l1 := f.Layers[1]
	log.Printf("L1: %d nodes", len(l1))

	chars := allChars()
	log.Printf("Alphabet: %d chars (6 scripts)", len(chars))

	log.Printf("Building molecule table...")
	var strokes []vsdf.StrokeCandidate
	for _, ch := range chars {
		if ch.SDF == nil { continue }
		strokes = append(strokes, vsdf.ExtractStrokes(vsdf.SampleChar(ch.Codepoint, ch.SDF))...)
	}
	mt := vsdf.BuildMoleculeTable(strokes)
	log.Printf("Molecule table: %d entries (%dB)", len(mt.Entries), len(mt.Entries)*6)

	// Ghi molecule table vào L0
	tableBytes := mt.Serialize()
	if len(f.Layers[0]) > 0 {
		f.Layers[0][0].DNA = tableBytes
		f.Layers[0][0].DNALen = uint32(len(tableBytes))
	} else {
		f.Layers[0] = append(f.Layers[0], &olang.OlangNode{
			OlangNodeHeader: olang.OlangNodeHeader{DNALen: uint32(len(tableBytes))},
			DNA: tableBytes,
		})
	}
	log.Printf("L0: molecule table = %dB", len(tableBytes))

	sdfMap := make(map[uint32]*alphabet.OlangChar)
	for _, ch := range chars {
		if ch.SDF != nil { sdfMap[ch.Codepoint] = ch }
	}

	start := time.Now()
	encoded, kept, emptied := 0, 0, 0
	totalDNA := 0
	for _, node := range l1 {
		if ch, ok := sdfMap[node.Codepoint]; ok {
			g := vsdf.EncodeGlyph(node.Codepoint, ch.SDF, mt)
			b := g.Bytes()
			node.DNA, node.DNALen = b, uint32(len(b))
			totalDNA += len(b); encoded++
		} else if len(node.DNA) >= 2 {
			totalDNA += len(node.DNA); kept++
		} else {
			node.DNA = vsdf.EncodeEmpty()
			node.DNALen = 1; totalDNA++; emptied++
		}
	}
	log.Printf("Encoded in %v: molecular=%d kept=%d empty=%d", time.Since(start), encoded, kept, emptied)

	out := path + ".molecular"
	if err := f.SaveToPath(out); err != nil { log.Fatal(err) }
	fi, _ := os.Stat(out)

	fmt.Printf("\n=== DONE ===\n")
	fmt.Printf("Output:    %s  (%.2fMB)\n", out, float64(fi.Size())/1024/1024)
	fmt.Printf("L0 table:  %dB (%d entries)\n", len(tableBytes), len(mt.Entries))
	fmt.Printf("Molecular: %d | Kept: %d | Empty: %d\n", encoded, kept, emptied)
	fmt.Printf("Total DNA: %.2fMB\n", float64(totalDNA)/1024/1024)

	fmt.Printf("\nPer-script:\n")
	for _, s := range []struct{n string; c []*alphabet.OlangChar}{
		{"Latin",alphabet.AllLatin()}, {"Greek",alphabet.AllGreek()},
		{"Cyrillic",alphabet.AllCyrillic()}, {"Devanagari",alphabet.AllDevanagari()},
		{"Arabic",alphabet.AllArabic()}, {"CJK",alphabet.AllCJK()},
	} {
		tot, byt := 0, 0
		for _, ch := range s.c {
			if ch.SDF == nil { continue }
			g := vsdf.EncodeGlyph(ch.Codepoint, ch.SDF, mt)
			byt += len(g.Bytes()); tot++
		}
		if tot > 0 { fmt.Printf("  %-12s %3d chars  avg=%dB\n", s.n, tot, byt/tot) }
	}

	classDist := make(map[vsdf.StrokeClass]int)
	for _, e := range mt.Entries { classDist[e.Class] += e.Freq }
	fmt.Printf("\nStroke class distribution:\n")
	for c := vsdf.StrokeClass(0); c < vsdf.ClassN; c++ {
		if classDist[c] > 0 { fmt.Printf("  %-6s: %d\n", c, classDist[c]) }
	}
}
