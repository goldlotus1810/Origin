// cmd/migrate_v19/main.go
//
// Migrate homeos.olang V18 → V19:
//   - Bỏ nameLen+name khỏi node binary
//   - Tạo NamesTable riêng: "NT" + count(4BE) + [isl(8)+nameLen(1)+name]×N
//   - Đặt NamesTable giữa nodes và edges
//   - Header: version[4:6]=19, namesOffset[28:32]=BE uint32
//
// File layout V19:
//   [header 280B][nodes (19B+dna)][NamesTable][edges]
//   header[28:32] = NamesTable start offset (BE uint32)

package main

import (
	"encoding/binary"
	"fmt"
	"log"
	"os"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

func main() {
	input  := "homeos.olang"
	output := "homeos.olang.v19"
	if len(os.Args) > 1 { input  = os.Args[1] }
	if len(os.Args) > 2 { output = os.Args[2] }

	log.Printf("migrate_v19: %s → %s", input, output)

	raw, err := os.ReadFile(input)
	if err != nil { log.Fatalf("read: %v", err) }

	res, err := olang.ParseBytes(raw)
	if err != nil { log.Fatalf("parse: %v", err) }
	log.Printf("Input: %s", res.Stats())

	if res.FileV19 {
		log.Printf("Đã là V19, không cần migrate")
		os.Exit(0)
	}

	// ── NamesTable ──────────────────────────────────────────────
	nt := olang.NewNamesTable()
	for _, n := range res.Nodes {
		if n.Name != "" {
			nt.Add(n.ISLAddr, n.Name)
		}
	}
	log.Printf("NamesTable: %d entries", nt.Len())

	// ── Rebuild nodes V19 (không có nameLen) ───────────────────
	var nodeBuf []byte
	for _, n := range res.Nodes {
		buf := make([]byte, olang.NodeHeaderSizeV19+len(n.DNA))
		pos := 0
		buf[pos] = 'N'; pos++
		buf[pos] = 'D'; pos++
		buf[pos] = n.Layer; pos++
		binary.BigEndian.PutUint64(buf[pos:pos+8], n.ISLAddr); pos += 8
		binary.BigEndian.PutUint32(buf[pos:pos+4], n.CP); pos += 4
		binary.BigEndian.PutUint32(buf[pos:pos+4], uint32(len(n.DNA))); pos += 4
		copy(buf[pos:], n.DNA)
		nodeBuf = append(nodeBuf, buf...)
	}

	// ── Edges (unchanged) ──────────────────────────────────────
	edgeStart := len(raw) - res.EdgeCount*olang.EdgeSize
	edgeBuf   := raw[edgeStart:]

	// ── Header: copy + set version=19 + namesOffset ─────────────
	header := make([]byte, 280)
	copy(header, raw[:280])
	binary.BigEndian.PutUint16(header[4:6], 19)                         // version = 19
	namesOffset := uint32(280 + len(nodeBuf))
	binary.BigEndian.PutUint32(header[28:32], namesOffset)              // NamesTable offset

	// ── Assemble: [header][nodes][NamesTable][edges] ────────────
	ntBytes := nt.Bytes()
	out := make([]byte, 0, 280+len(nodeBuf)+len(ntBytes)+len(edgeBuf))
	out = append(out, header...)
	out = append(out, nodeBuf...)
	out = append(out, ntBytes...)
	out = append(out, edgeBuf...)

	if err := os.WriteFile(output, out, 0644); err != nil {
		log.Fatalf("write: %v", err)
	}

	// ── Verify ──────────────────────────────────────────────────
	res2, err := olang.ParseBytes(out)
	if err != nil { log.Fatalf("verify: %v", err) }
	if res2.NodeCount != res.NodeCount {
		log.Fatalf("node count: got %d want %d", res2.NodeCount, res.NodeCount)
	}
	if res2.EdgeCount != res.EdgeCount {
		log.Fatalf("edge count: got %d want %d", res2.EdgeCount, res.EdgeCount)
	}
	if res2.Names == nil || res2.Names.Len() != nt.Len() {
		got := 0
		if res2.Names != nil { got = res2.Names.Len() }
		log.Fatalf("names: got %d want %d", got, nt.Len())
	}

	saved := len(raw) - len(out)
	pct   := float64(saved) / float64(len(raw)) * 100
	log.Printf("✅ Verify OK: %s", res2.Stats())
	log.Printf("   %dB → %dB  (saved %dB = %.1f%%)", len(raw), len(out), saved, pct)
	log.Printf("   NamesTable @ %d, size=%dB, entries=%d",
		namesOffset, len(ntBytes), nt.Len())
	fmt.Printf("output: %s\n", output)
}
