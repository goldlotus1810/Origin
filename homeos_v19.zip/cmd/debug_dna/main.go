package main
import (
	"encoding/binary"
	"fmt"
	"os"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)
func main() {
	raw, _ := os.ReadFile("homeos.olang")
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	targets := map[uint32]bool{
		0x7684:true, 0x4E86:true, 0x662F:true, 0x5728:true, 0x4E0D:true,
		0x0041:true, 0x0042:true, 0x03B1:true, 0x0430:true,
	}
	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		cp := binary.BigEndian.Uint32(raw[pos+11:pos+15])
		dnaLen := int(binary.BigEndian.Uint32(raw[pos+15:]))
		nameLen := int(raw[pos+19])
		if targets[cp] {
			fmt.Printf("U+%04X layer=%d dnaLen=%d\n", cp, raw[pos+2], dnaLen)
		}
		if dnaLen >= 0 && dnaLen < 100000 { pos += 20 + dnaLen + nameLen } else { pos++ }
	}
}
