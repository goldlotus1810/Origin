// cmd/olang/main.go
// Olang Runtime CLI
//
// Usage:
//   olang run   homeos.olang          — chạy file
//   olang info  homeos.olang          — xem thống kê
//   olang dump  homeos.olang          — dump tất cả nodes
//   olang get   homeos.olang A        — tìm node theo ký tự
//   olang walk  homeos.olang A 3      — walk silk edges depth 3
//   olang verify homeos.olang         — verify SHA256

package main

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math"
	"math/bits"
	"os"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/utf32"
	"github.com/goldlotus1810/HomeOS/internal/ws"
)

// ─── Binary format constants ────────────────────────────────────

const (
	Magic          = "OLNG"
	HeaderSize     = 64
	LayerEntrySize = 24
	LayerIndexSize = 9 * LayerEntrySize

	// Link types
	LinkSameShape   = 0x01
	LinkSameSound   = 0x02
	LinkSameMeaning = 0x03
	LinkDerivedFrom = 0x04
	LinkOpposite    = 0x05
	LinkPart        = 0x06
	LinkContext     = 0x07
	LinkWorldLink   = 0x08
	LinkLearned     = 0xFF
)

var layerNames = []string{
	"L0 Primitives", "L1 UTF32", "L2 Nature", "L3 Life",
	"L4 Objects", "L5 Programming", "L6 Perception", "L7 Programs", "L8 Build",
}

var linkNames = map[uint8]string{
	olang.EdgeSameSound:   "SameSound",   // 0x01: A≡α cùng âm
	olang.EdgeSameShape:   "SameShape",   // 0x02: O≡0 cùng hình
	olang.EdgeSameMeaning: "SameMeaning", // 0x03: +≡∪ cùng nghĩa
	olang.EdgeDerivedFrom: "DerivedFrom", // 0x04: A←𐤀 nguồn gốc
	olang.EdgeLowercase:   "Lowercase",   // 0x05: A→a
	olang.EdgeUppercase:   "Uppercase",   // 0x06: a→A
	olang.EdgeMirror:      "Mirror",      // 0x07: b↔d
	olang.EdgeMember:      "Member",      // 0x08: x∈S
	olang.EdgeSubset:      "Subset",      // 0x09: A⊂B
	olang.EdgeCompose:     "Compose",     // 0x0A: f∘g
	olang.EdgeEquiv:       "Equiv",       // 0x0B: a≡b
	olang.EdgeSimilar:     "Similar",     // 0x0C: a≈b
	olang.EdgeOpposite:    "Opposite",    // 0x0D: a⊥b
	olang.EdgeWorldLink:   "WorldLink",   // 0x0E: char→SDF
	olang.EdgePhoneme:     "Phoneme",     // 0x0F: char→IPA
	0xFF:                  "Learned",
}

// ─── Data structures ────────────────────────────────────────────

type Header struct {
	Version uint16
	Flags   uint16
	NLayers uint8
	NNodes  uint32
	NEdges  uint32
	Created int64
	SHA256  [32]byte
}

type LayerEntry struct {
	ID     uint8
	Status uint8
	Flags  uint16
	Offset uint64
	Size   uint64
	NNodes uint32
}

type Node struct {
	LayerID   uint8
	ISL       [8]byte
	Codepoint rune
	DNA       []byte
	Name      string
	Links     []Edge
}

type Edge struct {
	From   [8]byte
	To     [8]byte
	LType  uint8
}

type OlangFile struct {
	raw    []byte
	Header Header
	Layers [9]LayerEntry
	Nodes  []*Node
	Edges  []Edge
	ByCP   map[rune]*Node
	ByISL  map[uint64]*Node
}

// ─── Parser ─────────────────────────────────────────────────────

func load(path string) (*OlangFile, error) {
	raw, err := os.ReadFile(path)
	if err != nil { return nil, err }

	if len(raw) < HeaderSize+LayerIndexSize {
		return nil, fmt.Errorf("file too small (%d bytes)", len(raw))
	}
	if string(raw[0:4]) != Magic {
		return nil, fmt.Errorf("invalid magic %q (expected OLNG)", raw[0:4])
	}

	f := &OlangFile{
		raw:   raw,
		ByCP:  make(map[rune]*Node),
		ByISL: make(map[uint64]*Node),
	}

	// Header
	f.Header.Version = be16(raw[4:])
	f.Header.Flags   = be16(raw[6:])
	f.Header.NLayers = raw[8]
	f.Header.NNodes  = be32(raw[12:])
	f.Header.NEdges  = be32(raw[16:])
	f.Header.Created = int64(be64(raw[20:]))
	// V19: SHA tại [32:64] (vì [28:32] = namesTableOffset); V18: [28:60]
	if f.Header.Version >= 19 {
		copy(f.Header.SHA256[:], raw[32:64])
	} else {
		copy(f.Header.SHA256[:], raw[28:60])
	}

	// Layer index
	for i := 0; i < 9; i++ {
		off := HeaderSize + i*LayerEntrySize
		f.Layers[i] = LayerEntry{
			ID:     raw[off],
			Status: raw[off+1],
			Flags:  be16(raw[off+2:]),
			Offset: be64(raw[off+4:]),
			Size:   be64(raw[off+12:]),
			NNodes: be32(raw[off+20:]),
		}
	}

	// edgeStart = len(file) - nedges*olang.EdgeSize  (rule #20 / HANDOFF)
	nedgesHdr := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart  := uint64(len(raw)) - uint64(nedgesHdr)*olang.EdgeSize
	if edgeStart > uint64(len(raw)) {
		edgeStart = 0
	}

	// Parse nodes — linear scan toàn file từ byte 280 đến edgeStart
	// (layer windows chồng nhau nên không parse per-layer)
	nodeStart := uint64(HeaderSize + LayerIndexSize) // 280
	seen := make(map[uint64]bool) // dedup theo ISL key
	{
		pos := int(nodeStart)
		limit := int(edgeStart) - 20
		for pos < limit {
			if raw[pos] != 'N' || raw[pos+1] != 'D' {
				pos++
				continue
			}
			if pos+20 > len(raw) { break }
			lid     := raw[pos+2]
			var isl [8]byte
			copy(isl[:], raw[pos+3:pos+11])
			cp      := rune(be32(raw[pos+11:]))
			dnaLen  := int(be32(raw[pos+15:]))
			nameLen := int(raw[pos+19])

			if dnaLen > 4096 || nameLen > 255 || lid > 8 {
				pos++
				continue
			}
			end := pos + 20 + dnaLen + nameLen
			if end > int(edgeStart) { break }

			dna  := make([]byte, dnaLen)
			copy(dna, raw[pos+20:pos+20+dnaLen])
			name := string(raw[pos+20+dnaLen : end])

			islK := islKey(isl)
			if !seen[islK] {
				seen[islK] = true
				n := &Node{LayerID: lid, ISL: isl, Codepoint: cp, DNA: dna, Name: name}
				f.Nodes = append(f.Nodes, n)
				f.ByISL[islK] = n
				if cp != 0 { f.ByCP[cp] = n }
			}
			pos = end
		}
	}

	// Parse edges — V2 format: 21B per edge [src:8][dst:8][type:1][weight:4]
	edata := raw[edgeStart:]
	for len(edata) >= olang.EdgeSize {
		var e Edge
		copy(e.From[:], edata[0:8])
		copy(e.To[:], edata[8:16])
		e.LType = edata[16]
		// weight float32 ở edata[17:21] — bỏ qua hoặc lưu nếu cần
		f.Edges = append(f.Edges, e)
		edata = edata[olang.EdgeSize:]

		// Silk không có hướng — wire vào cả 2 endpoints
		if n, ok := f.ByISL[islKey(e.From)]; ok {
			n.Links = append(n.Links, e)
		}
		if n, ok := f.ByISL[islKey(e.To)]; ok {
			// Tránh duplicate nếu From == To
			if e.From != e.To {
				n.Links = append(n.Links, e)
			}
		}
	}

	return f, nil
}

func (f *OlangFile) verify() bool {
	content := f.raw[HeaderSize+LayerIndexSize:]
	sum := sha256.Sum256(content)
	return sum == f.Header.SHA256
}

// ─── ISL helpers ────────────────────────────────────────────────

func islKey(isl [8]byte) uint64 { return binary.BigEndian.Uint64(isl[:]) }

func islStr(isl [8]byte) string {
	L, G, T, I := isl[0], isl[1], isl[2], isl[3]
	attr := binary.BigEndian.Uint32(isl[4:])
	return fmt.Sprintf("[%c][%c][%c][%d] attr=0x%08X", L, G, T, I, attr)
}

func attrStr(isl [8]byte) string {
	attr := binary.BigEndian.Uint32(isl[4:])
	sh := attr >> 24 & 0xFF
	ph := attr >> 16 & 0xFF
	cg := attr >> 8 & 0xFF
	dv := attr & 0xFF
	return fmt.Sprintf("shape=0x%02X phoneme=0x%02X concept=0x%02X deriv=0x%02X", sh, ph, cg, dv)
}

func similarity(a, b [8]byte) float32 {
	aa := binary.BigEndian.Uint32(a[4:])
	ab := binary.BigEndian.Uint32(b[4:])

	score, weight := float32(0), float32(0)

	if a[0] == b[0] { score += 3; weight += 3 }
	if a[1] == b[1] { score += 2; weight += 2 }
	if a[2] == b[2] { score += 1; weight += 1 }

	shapeDiff := bits.OnesCount32(uint32(aa>>24&0xFF) ^ uint32(ab>>24&0xFF))
	score += float32(8-shapeDiff) / 8.0 * 4; weight += 4

	phoneShared := bits.OnesCount32(aa >> 16 & 0xFF & ab >> 16 & 0xFF)
	score += float32(phoneShared) / 8.0 * 3; weight += 3

	cDiff := math.Abs(float64(aa>>8&0xFF) - float64(ab>>8&0xFF))
	score += float32(32-min(cDiff, 32)) / 32.0 * 4; weight += 4

	if aa&0xF0 == ab&0xF0 { score += 1; weight += 1 }

	if weight == 0 { return 0 }
	return score / weight
}

func min(a, b float64) float64 {
	if a < b { return a }
	return b
}

func dnaSummary(dna []byte) string {
	return dnaSummaryForLayer(dna, 0)
}

func dnaSummaryForLayer(dna []byte, layer uint8) string {
	if len(dna) == 0 { return "(empty)" }

	// L1 UTF-32 nodes: DNA = metadata, không phải L0 SDF opcodes
	// Format: [0x01][script][group][cp_b0..b3][pad...]
	if layer == 1 && len(dna) >= 7 && dna[0] == 0x01 {
		scripts := map[byte]string{
			0x00:"latin", 0x01:"latin_ext", 0x02:"ipa",
			0x03:"greek", 0x04:"cyrillic",  0x05:"armenian_old",
			0x06:"hebrew",0x07:"arabic",    0x08:"hiragana",
			0x09:"katakana",0x0A:"armenian",0x0B:"cjk",
			0x0C:"hangul", 0x0D:"math",     0x0E:"digits",
		}
		groups := map[byte]string{
			0x01:"uppercase", 0x02:"lowercase", 0x03:"ligature",
			0x04:"punct",     0x05:"symbol",    0x06:"modifier",
			0x07:"combining", 0x08:"digit",
		}
		script := scripts[dna[1]]
		if script == "" { script = fmt.Sprintf("script_%02X", dna[1]) }
		group := groups[dna[2]]
		if group == "" { group = fmt.Sprintf("group_%02X", dna[2]) }
		return fmt.Sprintf("[L1-CHAR script=%s group=%s]  (%d bytes)", script, group, len(dna))
	}

	// L0/L2-L7: interpret như SDF/ISL opcodes
	ops := map[byte]string{
		0x01:"SPHERE", 0x02:"CAPSULE", 0x03:"BOX", 0x04:"TORUS", 0x05:"VOID",
		0x10:"UNION",  0x11:"SUB",     0x12:"INTERSECT",
		0x20:"FBM",    0x21:"GRADIENT",0x22:"LIGHT",     0x30:"SPLINE",
		0x40:"AND",    0x41:"OR",      0x42:"NOT",
		0x50:"GET",    0x51:"WALK",    0x52:"EMIT",       0x53:"BCAST",
		0x60:"SEQ",    0x61:"IF",      0x62:"LOOP",       0x63:"DREAM",  0x64:"SPAWN",
		0x70:"ADD",    0x71:"SUB_N",   0x72:"MUL",        0x73:"DIV",
		0x80:"SIN",    0x81:"COS",     0x90:"VEC3",       0x9A:"SCALE",
		0xA0:"LOAD",   0xA1:"STORE",   0xA4:"CALL",       0xA5:"RET",
		0xFF:"GATE",
	}
	var parts []string
	for _, b := range dna[:min2(len(dna), 10)] {
		if name, ok := ops[b]; ok {
			parts = append(parts, name)
		}
	}
	s := strings.Join(parts, " ")
	if len(dna) > 10 { s += "..." }
	return fmt.Sprintf("%s  (%d bytes)", s, len(dna))
}

func min2(a, b int) int {
	if a < b { return a }
	return b
}

// ─── Executor ───────────────────────────────────────────────────

type execCtx struct{ fuel int; output []string }

func execNode(node *Node, f *OlangFile) *execCtx {
	ctx := &execCtx{fuel: 10000}
	dna := node.DNA
	pc  := 0
	for pc < len(dna) {
		ctx.fuel--
		if ctx.fuel <= 0 { ctx.output = append(ctx.output, "BLOWN"); break }
		op := dna[pc]; pc++
		switch op {
		case 0x52: // EMIT
			if pc+4 <= len(dna) {
				pay := dna[pc:pc+4]; pc += 4
				ctx.output = append(ctx.output, fmt.Sprintf("EMIT[%02x%02x%02x%02x]", pay[0],pay[1],pay[2],pay[3]))
			}
		case 0x60: // SEQ
			if pc+4 <= len(dna) {
				pay := dna[pc:pc+4]; pc += 4
				ctx.output = append(ctx.output, fmt.Sprintf("SEQ[%02x%02x%02x%02x]", pay[0],pay[1],pay[2],pay[3]))
			}
		case 0x64: // SPAWN
			if pc+4 <= len(dna) {
				name := strings.TrimRight(string(dna[pc:pc+4]), "\x00"); pc += 4
				ctx.output = append(ctx.output, "SPAWN:"+name)
			}
		case 0x63: // DREAM
			ctx.output = append(ctx.output, "DREAM")
		case 0xff: // GATE
			ctx.output = append(ctx.output, "🛡GATE:pass")
		// SDF shapes — silent (geometry, không phải text output)
		case 0x01, 0x02, 0x03, 0x05, 0x10, 0x11, 0x12, 0x20, 0x22:
			// sphere/capsule/box/void/union/sub/intersect/fbm/light — tiêu thụ params
		}
	}
	return ctx
}

func printNode(node *Node, f *OlangFile) {
	ch := ""
	if node.Codepoint > 0 { ch = fmt.Sprintf(" '%c'", node.Codepoint) }
	fmt.Printf("  ○ L%d%s %s\n", node.LayerID, ch, node.Name)
	fmt.Printf("     ISL: %s\n", islStr(node.ISL))
	fmt.Printf("     DNA: %s\n", dnaSummary(node.DNA))
	for _, e := range node.Links {
		lt := linkNames[e.LType]
		if tn, ok := f.ByISL[islKey(e.To)]; ok {
			ch2 := ""
			if tn.Codepoint > 0 { ch2 = fmt.Sprintf("'%c'", tn.Codepoint) }
			fmt.Printf("     %-14s → %s %s\n", lt, ch2, tn.Name)
		}
	}
}

// ─── Commands ───────────────────────────────────────────────────

func cmdInfo(f *OlangFile, path string) {
	ok := f.verify()
	verified := "✅ verified"
	if !ok { verified = "❌ SHA256 MISMATCH" }

	fmt.Printf(`
○ OLANG FILE INFO
  ─────────────────────────────────────────
  File:     %s
  Magic:    OLNG
  Version:  Unicode %d.0
  Nodes:    %d
  Edges:    %d
  SHA256:   %s  %s
  ─────────────────────────────────────────
`,
		path,
		f.Header.Version,
		len(f.Nodes),
		len(f.Edges),
		fmt.Sprintf("%x", f.Header.SHA256)[:32]+"...",
		verified,
	)

	for i, le := range f.Layers {
		if le.NNodes == 0 && le.Size == 0 { continue }
		status := []string{"empty", "ĐN", "QR", "archived"}[min2(int(le.Status), 3)]
		fmt.Printf("  %-18s  %4d nodes  %6d B  [%s]\n",
			layerNames[i], le.NNodes, le.Size, status)
	}
	fmt.Println()
}

func cmdDump(f *OlangFile) {
	fmt.Printf("○ NODES (%d total)\n\n", len(f.Nodes))
	for _, n := range f.Nodes {
		ch := ""
		if n.Codepoint > 0 && n.Codepoint < 0x110000 {
			ch = fmt.Sprintf("'%c' U+%04X", n.Codepoint, n.Codepoint)
		}
		fmt.Printf("  [%s]  %-20s  %-12s  %s\n",
			layerNames[min2(int(n.LayerID), 8)][:2],
			n.Name[:min2(len(n.Name), 20)],
			ch,
			dnaSummaryForLayer(n.DNA, n.LayerID),
		)
		if len(n.Links) > 0 {
			for _, e := range n.Links {
				lt := linkNames[e.LType]
				to := ""
				if tn, ok := f.ByISL[islKey(e.To)]; ok {
					to = tn.Name
				}
				fmt.Printf("      └─ %-12s → %s\n", lt, to)
			}
		}
	}
}

func cmdGet(f *OlangFile, query string) {
	var n *Node

	// Thử tìm theo ký tự
	if utf8.RuneCountInString(query) == 1 {
		r, _ := utf8.DecodeRuneInString(query)
		n = f.ByCP[r]
	}

	// Thử tìm theo tên
	if n == nil {
		q := strings.ToUpper(query)
		for _, nd := range f.Nodes {
			if strings.Contains(strings.ToUpper(nd.Name), q) {
				n = nd; break
			}
		}
	}

	if n == nil {
		fmt.Printf("❌ not found: %q\n", query)
		return
	}

	ch := ""
	if n.Codepoint > 0 { ch = fmt.Sprintf("'%c' U+%04X", n.Codepoint, n.Codepoint) }

	fmt.Printf(`
○ NODE: %s
  ─────────────────────────────────────
  Layer:     %s
  Char:      %s
  ISL:       %s
  Attrs:     %s
  DNA:       %s
  Links:     %d
`,
		n.Name,
		layerNames[min2(int(n.LayerID), 8)],
		ch,
		islStr(n.ISL),
		attrStr(n.ISL),
		dnaSummary(n.DNA),
		len(n.Links),
	)

	if len(n.Links) > 0 {
		fmt.Println("  ─────────────────────────────────────")
		for _, e := range n.Links {
			lt := linkNames[e.LType]
			toName := fmt.Sprintf("ISL %x", e.To[:4])
			if tn, ok := f.ByISL[islKey(e.To)]; ok {
				toName = tn.Name
				if tn.Codepoint > 0 { toName += fmt.Sprintf(" '%c'", tn.Codepoint) }
			}
			fmt.Printf("  %-14s → %s\n", lt, toName)
		}
	}

	// Tìm similar nodes
	if len(f.Nodes) > 1 {
		fmt.Println()
		fmt.Println("  Similar nodes (≥ 0.6):")
		count := 0
		for _, other := range f.Nodes {
			if other == n { continue }
			sim := similarity(n.ISL, other.ISL)
			if sim >= 0.6 {
				ch2 := ""
				if other.Codepoint > 0 { ch2 = fmt.Sprintf("'%c'", other.Codepoint) }
				fmt.Printf("    %.3f  %-4s %s\n", sim, ch2, other.Name)
				count++
				if count >= 8 { break }
			}
		}
		if count == 0 { fmt.Println("    (none)") }
	}
	fmt.Println()
}

func cmdWalk(f *OlangFile, query string, depth int) {
	var start *Node
	if utf8.RuneCountInString(query) == 1 {
		r, _ := utf8.DecodeRuneInString(query)
		start = f.ByCP[r]
	}
	if start == nil {
		q := strings.ToUpper(query)
		for _, n := range f.Nodes {
			if strings.Contains(strings.ToUpper(n.Name), q) { start = n; break }
		}
	}
	if start == nil { fmt.Printf("❌ not found: %q\n", query); return }

	fmt.Printf("○ WALK from '%s' depth=%d\n\n", start.Name, depth)

	visited := map[uint64]bool{}
	var walk func(n *Node, d int, prefix string)
	walk = func(n *Node, d int, prefix string) {
		key := islKey(n.ISL)
		if visited[key] { return }
		visited[key] = true
		ch := ""
		if n.Codepoint > 0 { ch = fmt.Sprintf("'%c'", n.Codepoint) }
		fmt.Printf("%s● %-4s %s\n", prefix, ch, n.Name)
		if d <= 0 { return }
		for _, e := range n.Links {
			lt := linkNames[e.LType]
			if tn, ok := f.ByISL[islKey(e.To)]; ok {
				fmt.Printf("%s  └─[%s]─ ", prefix, lt)
				walk(tn, d-1, prefix+"     ")
			}
		}
	}
	walk(start, depth, "  ")
	fmt.Println()
}

func cmdRun(f *OlangFile, path string) {
	// Verify trước
	if !f.verify() {
		fmt.Fprintln(os.Stderr, "❌ SHA256 mismatch — file may be corrupted")
		os.Exit(1)
	}

	fmt.Printf(`
○ ─────────────────────────────────────────
○  OLANG RUNTIME
○  %s
○ ─────────────────────────────────────────
`, path)

	// Print layer summary
	for i, le := range f.Layers {
		if le.NNodes == 0 { continue }
		status := []string{"", "ĐN", "QR", "archived"}[min2(int(le.Status), 3)]
		fmt.Printf("  %-20s  %3d nodes  [%s]\n", layerNames[i], le.NNodes, status)
	}
	fmt.Printf("  Silk edges:           %3d\n", len(f.Edges))
	fmt.Println()

	// SecurityGate — Rule 1
	fmt.Println("  🛡 SecurityGate: ONLINE")
	fmt.Println("     Rule 1: Không hại con người  [ENFORCED]")
	fmt.Println("     Rule 2: Không vòng lặp vô hạn [ENFORCED]")
	fmt.Println("     Rule 3: Không xóa QR nodes   [ENFORCED]")
	fmt.Println()

	// Agents từ L7
	fmt.Println("  Agents:")
	for _, n := range f.Nodes {
		if n.LayerID == 7 {
			fmt.Printf("    ○ %s  [online · silent]\n", n.Name)
		}
	}
	fmt.Println()

	// Silk Web
	l1count := 0
	for _, n := range f.Nodes {
		if n.LayerID == 1 { l1count++ }
	}
	fmt.Printf("  Silk Web: %d chars · %d edges\n", l1count, len(f.Edges))
	fmt.Println()

	fmt.Println("○ HomeOS running.")
	fmt.Println("  Type a command:")
	fmt.Println()

	// ── Thực thi L7 agents ─────────────────────────────────────
	fmt.Println("  Executing L7 agents:")
	for _, node := range f.Nodes {
		if node.LayerID != 7 || len(node.DNA) == 0 { continue }
		ctx := execNode(node, f)
		if len(ctx.output) > 0 {
			fmt.Printf("    ○ %-20s → %s\n", node.Name, strings.Join(ctx.output, " | "))
		} else {
			fmt.Printf("    ○ %-20s → [online · silent]\n", node.Name)
		}
	}
	fmt.Println()
	fmt.Println("○ HomeOS running — type a command (exit để thoát):")
	fmt.Println()

	// REPL — thực thi input
	buf := make([]byte, 256)
	for {
		fmt.Print("  > ")
		n, err := os.Stdin.Read(buf)
		if err != nil { break }
		input := strings.TrimSpace(string(buf[:n]))
		if input == "" { continue }
		if input == "exit" || input == "quit" { break }

		// Tìm và execute node
		found := false

		// 1 ký tự → lookup codepoint
		if utf8.RuneCountInString(input) == 1 {
			r, _ := utf8.DecodeRuneInString(input)
			if node, ok := f.ByCP[r]; ok {
				printNode(node, f)
				if len(node.DNA) > 0 {
					ctx := execNode(node, f)
					if len(ctx.output) > 0 {
						fmt.Printf("  exec → %s\n", strings.Join(ctx.output, " | "))
					}
				}
				found = true
			}
		}

		// Tên node
		if !found {
			q := strings.ToUpper(input)
			for _, node := range f.Nodes {
				if strings.Contains(strings.ToUpper(node.Name), q) {
					printNode(node, f)
					if len(node.DNA) > 0 {
						ctx := execNode(node, f)
						if len(ctx.output) > 0 {
							fmt.Printf("  exec → %s\n", strings.Join(ctx.output, " | "))
						}
					}
					found = true
					break
				}
			}
		}

		if !found {
			fmt.Printf("  ? %q not found\n", input)
		}
		fmt.Println()
	}

	fmt.Println("\n○ shutdown.")
}

// ─── Byte helpers ────────────────────────────────────────────────

func be16(b []byte) uint16 { return binary.BigEndian.Uint16(b) }
func be32(b []byte) uint32 { return binary.BigEndian.Uint32(b) }
func be64(b []byte) uint64 { return binary.BigEndian.Uint64(b) }

// ─── Main ────────────────────────────────────────────────────────

func usage() {
	fmt.Print(`○ olang — Olang Runtime
Usage:
  olang run    <file.olang>           run HomeOS
  olang info   <file.olang>           show file info
  olang dump   <file.olang>           dump all nodes
  olang get    <file.olang> <char>    get node by char or name
  olang walk   <file.olang> <char> [depth]  walk silk edges
  olang verify   <file.olang>              verify SHA256
  olang seed-url <file.olang> <pdf_url>    seed Unicode PDF → SDF nodes
  olang seed-url <file.olang> <urls.txt>   batch seed multiple PDFs

Examples:
  olang run    homeos.olang
  olang info   homeos.olang
  olang get    homeos.olang A
  olang walk   homeos.olang A 3
  olang verify homeos.olang
  olang seed-url homeos.olang https://unicode.org/charts/PDF/U0530.pdf
  olang seed-url homeos.olang utf32.txt
`)
}

func main() {
	if len(os.Args) < 3 {
		usage()
		os.Exit(1)
	}

	cmd  := os.Args[1]

	// seed-url không cần load file trước
	if cmd == "delete-block" {
		if len(os.Args) < 5 {
			fmt.Println("Usage: olang delete-block <file.olang> <from_hex> <to_hex>")
			fmt.Println("Example: olang delete-block homeos.olang 0530 058F")
			os.Exit(1)
		}
		cmdDeleteBlock(os.Args[2], os.Args[3], os.Args[4])
		return
	}

	if cmd == "seed-url" {
		if len(os.Args) < 4 {
			fmt.Println("Usage: olang seed-url <file.olang> <pdf_url|urls.txt>")
			os.Exit(1)
		}
		cmdSeedURL(os.Args[2], os.Args[3])
		return
	}

	if cmd == "seed-l5" {
		// olang seed-l5 <file.olang> <go_package_dir> [go_package_dir...]
		if len(os.Args) < 4 {
			fmt.Println("Usage: olang seed-l5 <file.olang> <dir> [dir...]")
			os.Exit(1)
		}
		olangPath := os.Args[2]
		dirs := os.Args[3:]
		cmdSeedL5(olangPath, dirs)
		return
	}

	if cmd == "seed-cjk" {
		// olang seed-cjk <file.olang> [batch=500] [start=0]
		if len(os.Args) < 3 {
			fmt.Println("Usage: olang seed-cjk <file.olang> [batch=500] [start=0]")
			os.Exit(1)
		}
		olangPath := os.Args[2]
		batchSize := 500
		startOffset := 0
		if len(os.Args) >= 4 {
			batchSize, _ = strconv.Atoi(os.Args[3])
		}
		if len(os.Args) >= 5 {
			startOffset, _ = strconv.Atoi(os.Args[4])
		}
		cmdSeedCJK(olangPath, batchSize, startOffset)
		return
	}

	if cmd == "seed-hangul" {
		if len(os.Args) < 3 {
			fmt.Println("Usage: olang seed-hangul <file.olang> [batch=2000] [start=0]")
			os.Exit(1)
		}
		olangPath := os.Args[2]
		batchSize := 2000
		startOffset := 0
		if len(os.Args) >= 4 {
			batchSize, _ = strconv.Atoi(os.Args[3])
		}
		if len(os.Args) >= 5 {
			startOffset, _ = strconv.Atoi(os.Args[4])
		}
		cmdSeedHangul(olangPath, batchSize, startOffset)
		return
	}

	if cmd == "seed-context" {
		if len(os.Args) < 3 {
			fmt.Println("Usage: olang seed-context <file.olang>")
			os.Exit(1)
		}
		cmdSeedContext(os.Args[2])
		return
	}

	if cmd == "seed-symbols" {
		if len(os.Args) < 3 {
			fmt.Println("Usage: olang seed-symbols <file.olang>")
			os.Exit(1)
		}
		cmdSeedSymbols(os.Args[2])
		return
	}

	if cmd == "seed-qt" {
		if len(os.Args) < 3 {
			fmt.Println("Usage: olang seed-qt <file.olang>")
			os.Exit(1)
		}
		cmdSeedQT(os.Args[2])
		return
	}

	if cmd == "fix-layers" {
		if len(os.Args) < 3 {
			fmt.Println("Usage: olang fix-layers <file.olang>")
			os.Exit(1)
		}
		fixed, err := utf32.FixNodeLayers(os.Args[2])
		if err != nil {
			fmt.Fprintf(os.Stderr, "❌ fix-layers: %v\n", err)
			os.Exit(1)
		}
		fmt.Printf("✅ fix-layers: %d nodes corrected\n", fixed)
		return
	}

	path := os.Args[2]

	f, err := load(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ %v\n", err)
		os.Exit(1)
	}

	switch cmd {
	case "serve":
		// olang serve homeos.olang — khởi động HTTP server đầy đủ (:8080)
		cmdRunFull(path)

	case "run":
		cmdRun(f, path)

	case "info":
		cmdInfo(f, path)

	case "dump":
		cmdDump(f)

	case "get":
		if len(os.Args) < 4 { fmt.Println("usage: olang get <file> <char>"); os.Exit(1) }
		cmdGet(f, os.Args[3])

	case "walk":
		if len(os.Args) < 4 { fmt.Println("usage: olang walk <file> <char> [depth]"); os.Exit(1) }
		depth := 2
		if len(os.Args) >= 5 {
			depth, _ = strconv.Atoi(os.Args[4])
		}
		cmdWalk(f, os.Args[3], depth)

	case "auto-wire":
		res, err := utf32.AutoWireEdges(path)
		if err != nil {
			fmt.Fprintf(os.Stderr, "auto-wire: %v\n", err)
			os.Exit(1)
		}
		fmt.Println(res)

	case "bulk-seed":
		udPath := "/tmp/UnicodeData.txt"
		if len(os.Args) >= 4 { udPath = os.Args[3] }
		bsRes, bsErr := utf32.BulkSeed(path, udPath)
		if bsErr != nil { fmt.Fprintf(os.Stderr, "bulk-seed: %v\n", bsErr); os.Exit(1) }
		fmt.Println(bsRes)

	case "fix-scripts":
		// fix-scripts <file> [scripts.txt] [--all]
		scriptsPath := "/tmp/Scripts.txt"
		fixAll := false
		for _, arg := range os.Args[3:] {
			if arg == "--all" { fixAll = true } else { scriptsPath = arg }
		}
		fsRes, fsErr := utf32.FixScriptIDs(path, scriptsPath, fixAll)
		if fsErr != nil { fmt.Fprintf(os.Stderr, "fix-scripts: %v\n", fsErr); os.Exit(1) }
		fmt.Println(fsRes)

	case "sdf-math":
		added, skipped, failed := utf32.GenMathSDFAll(path)
		fmt.Printf("sdf-math: added=%d skipped=%d failed=%d total=%d\n",
			added, skipped, failed, utf32.MathSDFCount())

	case "sdf-gen":
		cfg := utf32.DefaultSDFGenConfig(path)
		for _, arg := range os.Args[3:] {
			if strings.HasPrefix(arg, "--script=") {
				for _, s := range strings.Split(strings.TrimPrefix(arg, "--script="), ",") {
					var sid uint64
					fmt.Sscanf(s, "0x%x", &sid)
					cfg.ScriptFilter = append(cfg.ScriptFilter, uint8(sid))
				}
			}
		}
		sgRes, sgErr := utf32.RunSDFGen(context.Background(), cfg)
		if sgErr != nil && sgErr != context.Canceled {
			fmt.Fprintf(os.Stderr, "sdf-gen: %v\n", sgErr)
			os.Exit(1)
		}
		fmt.Println(sgRes)

	case "migrate-dna":
		cmdMigrateDNA(path)
	case "verify":
		if f.verify() {
			fmt.Printf("✅ %s — SHA256 OK\n    %x\n", path, f.Header.SHA256)
		} else {
			fmt.Printf("❌ %s — SHA256 MISMATCH\n", path)
			os.Exit(1)
		}

	case "reseal":
		// Recalculate SHA256 sau migration hoặc thay đổi format
		raw, err := os.ReadFile(path)
		if err != nil {
			fmt.Printf("❌ read: %v\n", err); os.Exit(1)
		}
		if len(raw) < 280 {
			fmt.Println("❌ file too small"); os.Exit(1)
		}
		h := sha256.Sum256(raw[280:])
		// V19: SHA tại [32:64] vì [28:32] = namesTableOffset
		// V18: SHA tại [28:60]
		shaOff := 28
		if binary.BigEndian.Uint16(raw[4:6]) >= 19 { shaOff = 32 }
		copy(raw[shaOff:shaOff+32], h[:])
		tmp := path + ".tmp"
		if err := os.WriteFile(tmp, raw, 0644); err != nil {
			fmt.Printf("❌ write: %v\n", err); os.Exit(1)
		}
		os.Rename(tmp, path)
		fmt.Printf("✅ %s — SHA256 resealed\n    %x\n", path, h)

	case "pdf-seed":
		// pdf-seed <file> [--utf32=path] [--dpi=200] [--caps=5] [--filter=0x0000,0x0370]
		// Tự động gen vSDF thật từ tất cả Unicode chart PDFs trong utf32.txt
		cfg := utf32.DefaultPDFSeedConfig(path)
		for _, arg := range os.Args[3:] {
			switch {
			case strings.HasPrefix(arg, "--utf32="):
				cfg.UTF32TxtPath = arg[8:]
			case strings.HasPrefix(arg, "--dpi="):
				if v, e := strconv.Atoi(arg[6:]); e == nil {
					cfg.DPI = v
				}
			case strings.HasPrefix(arg, "--caps="):
				if v, e := strconv.Atoi(arg[7:]); e == nil {
					cfg.MaxCaps = v
				}
			case strings.HasPrefix(arg, "--filter="):
				// --filter=0x0000,0x0370,0x0400
				for _, s := range strings.Split(arg[9:], ",") {
					s = strings.TrimSpace(s)
					if v, e := strconv.ParseUint(strings.TrimPrefix(s, "0x"), 16, 32); e == nil {
						cfg.BlockFilter = append(cfg.BlockFilter, uint32(v))
					}
				}
			case arg == "--verbose":
				cfg.Verbose = true
			}
		}
		fmt.Printf("🖼  PDF Seed — olang=%s utf32=%s dpi=%d caps=%d\n",
			path, cfg.UTF32TxtPath, cfg.DPI, cfg.MaxCaps)
		ctx := context.Background()
		psRes, psErr := utf32.RunPDFSeed(ctx, cfg)
		if psErr != nil && psErr != context.Canceled {
			fmt.Fprintf(os.Stderr, "pdf-seed: %v\n", psErr)
			os.Exit(1)
		}
		fmt.Println(psRes)

	case "cangjie-sdf":
		// cangjie-sdf <file> [unihan_dict] [--caps=5]
		unihanDict := "/tmp/Unihan_DictionaryLikeData.txt"
		maxCapsCJ := 5
		for _, arg := range os.Args[3:] {
			if strings.HasPrefix(arg, "--caps=") {
				if v, e := strconv.Atoi(arg[7:]); e == nil { maxCapsCJ = v }
			} else if !strings.HasPrefix(arg, "--") {
				unihanDict = arg
			}
		}
		fmt.Printf("\U0001F004 Cangjie SDF — olang=%s caps=%d\n", path, maxCapsCJ)
		cjRes, cjErr := utf32.RunCangjieSDFSeed(path, unihanDict, maxCapsCJ)
		if cjErr != nil { fmt.Fprintf(os.Stderr, "cangjie-sdf: %v\n", cjErr); os.Exit(1) }
		fmt.Println(cjRes)

	default:
		fmt.Printf("❌ unknown command: %q\n", cmd)
		usage()
		os.Exit(1)
	}
}

// cmdSeedURL — seed Unicode PDF vào homeos.olang
func cmdSeedURL(olangPath, urlArg string) {
	ctx := context.Background()

	if strings.HasSuffix(strings.ToLower(urlArg), ".txt") {
		// Batch mode: đọc từng URL trong file
		data, err := os.ReadFile(urlArg)
		if err != nil {
			fmt.Printf("❌ đọc file URL: %v\n", err)
			os.Exit(1)
		}
		totalAdded, totalSkip, totalFail := 0, 0, 0
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(line)
			fields := strings.Fields(line)
			if len(fields) == 0 || !strings.HasPrefix(fields[0], "http") {
				continue
			}
			pdfURL := fields[0]
			res, err := utf32.SeedFromURL(ctx, olangPath, pdfURL)
			if err != nil {
				fmt.Printf("⚠️  %s: %v\n", pdfURL, err)
				continue
			}
			totalAdded += res.Added
			totalSkip += res.Skipped
			totalFail += res.Failed
			fmt.Printf("   → +%d nodes\n\n", res.Added)
		}
		fmt.Printf("\n🎉 Batch done: +%d added  %d skipped  %d failed\n",
			totalAdded, totalSkip, totalFail)
	} else {
		// Single URL
		res, err := utf32.SeedFromURL(ctx, olangPath, urlArg)
		if err != nil {
			fmt.Printf("❌ %v\n", err)
			os.Exit(1)
		}
		fmt.Printf("\n🎉 Done: +%d added  %d skipped  %d failed\n",
			res.Added, res.Skipped, res.Failed)
	}
}

// cmdDeleteBlock — xóa L1 nodes trong range codepoint [fromCP, toCP]
func cmdDeleteBlock(olangPath, fromHex, toHex string) {
	fromCP64, err := strconv.ParseUint(fromHex, 16, 32)
	if err != nil { fmt.Printf("❌ invalid from: %v\n", err); os.Exit(1) }
	toCP64, err := strconv.ParseUint(toHex, 16, 32)
	if err != nil { fmt.Printf("❌ invalid to: %v\n", err); os.Exit(1) }
	fromCP, toCP := uint32(fromCP64), uint32(toCP64)

	raw, err := os.ReadFile(olangPath)
	if err != nil { fmt.Printf("❌ %v\n", err); os.Exit(1) }
	if len(raw) < 280 { fmt.Println("❌ file too small"); os.Exit(1) }

	nedges   := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize

	out  := make([]byte, 0, len(raw))
	out   = append(out, raw[:280]...)
	removed := 0

	i := 280
	for i < edgeStart {
		if i+20 > edgeStart { out = append(out, raw[i:edgeStart]...); break }
		if raw[i] != 'N' || raw[i+1] != 'D' {
			// Tidak seharusnya terjadi
			i++; continue
		}
		layer := raw[i+2]
		cp    := binary.BigEndian.Uint32(raw[i+11:i+15])
		dl    := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
		nl    := int(raw[i+19])
		if dl > 65536 || nl > 255 { out = append(out, raw[i:edgeStart]...); break }
		end := i + 20 + dl + nl
		if layer == 1 && cp >= fromCP && cp <= toCP {
			removed++
		} else {
			out = append(out, raw[i:end]...)
		}
		i = end
	}
	out = append(out, raw[edgeStart:]...) // edges

	// Fix: total node count, L1 nnodes, L2-L8 offsets
	total := binary.BigEndian.Uint32(out[9:13])
	binary.BigEndian.PutUint32(out[9:13], total-uint32(removed))

	o1 := 64 + 1*24
	sz1 := binary.BigEndian.Uint64(out[o1+12:])
	nn1 := binary.BigEndian.Uint32(out[o1+20:])
	// Recalculate L1 size by scanning
	var newSz1 uint64
	j := 280; ne2 := int(binary.BigEndian.Uint32(out[16:20]))
	es2 := len(out) - ne2*17
	for j < es2 {
		if j+20 > es2 { break }
		if out[j] == 'N' && out[j+1] == 'D' && out[j+2] == 1 {
			dl2 := int(binary.BigEndian.Uint32(out[j+15:j+19]))
			nl2 := int(out[j+19])
			newSz1 += uint64(20 + dl2 + nl2)
			j += 20 + dl2 + nl2
		} else {
			dl2 := int(binary.BigEndian.Uint32(out[j+15:j+19]))
			nl2 := int(out[j+19])
			if dl2 > 65536 || nl2 > 255 { break }
			j += 20 + dl2 + nl2
		}
	}
	diff := sz1 - newSz1
	binary.BigEndian.PutUint64(out[o1+12:], newSz1)
	binary.BigEndian.PutUint32(out[o1+20:], nn1-uint32(removed))

	for li := 2; li < 9; li++ {
		o := 64 + li*24
		if binary.BigEndian.Uint64(out[o+12:]) > 0 {
			off := binary.BigEndian.Uint64(out[o+4:])
			binary.BigEndian.PutUint64(out[o+4:], off-diff)
		}
	}

	h := sha256.Sum256(out[280:])
	shaOff2 := 28
	if binary.BigEndian.Uint16(out[4:6]) >= 19 { shaOff2 = 32 }
	copy(out[shaOff2:shaOff2+32], h[:])

	tmp := olangPath + ".tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil {
		fmt.Printf("❌ write: %v\n", err); os.Exit(1)
	}
	os.Rename(tmp, olangPath)
	fmt.Printf("✅ Deleted %d L1 nodes (U+%04X–U+%04X) from %s\n",
		removed, fromCP, toCP, olangPath)
}

// cmdSeedL5 — index Go source packages → L5 nodes trong homeos.olang
func cmdSeedL5(olangPath string, dirs []string) {
	totalAdded := 0
	totalSkipped := 0
	totalFailed := 0

	for _, dir := range dirs {
		decls, err := olang.IndexGoPackage(dir)
		if err != nil {
			fmt.Fprintf(os.Stderr, "⚠️  %s: %v\n", dir, err)
			continue
		}

		added, skipped, failed := 0, 0, 0
		for _, d := range decls {
			// Bỏ qua exported names bắt đầu bằng chữ thường (unexported)
			if len(d.Name) == 0 { continue }
			first := d.Name[0]
			if first == '_' { skipped++; continue }

			if err := olang.AppendL5ToFile(olangPath, d); err != nil {
				if err.Error()[:9] == "duplicate" {
					skipped++
				} else {
					failed++
					fmt.Fprintf(os.Stderr, "  ✗ %s.%s: %v\n", d.Pkg, d.Name, err)
				}
			} else {
				added++
			}
		}

		fmt.Printf("  %s: +%d added  %d skipped  %d failed\n", dir, added, skipped, failed)
		totalAdded += added
		totalSkipped += skipped
		totalFailed += failed
	}

	fmt.Printf("🎉 L5 seed done: +%d added  %d skipped  %d failed\n",
		totalAdded, totalSkipped, totalFailed)
}

// cmdSeedCJK — batch seed CJK Unified Ideographs U+4E00–U+9FFF
// Dùng AppendL1Batch: O(1) I/O cho toàn bộ batch
func cmdSeedCJK(olangPath string, batchSize, startOffset int) {
	const cjkStart = 0x4E00
	const cjkEnd   = 0x9FFF
	const total    = cjkEnd - cjkStart + 1

	if startOffset >= total {
		fmt.Printf("start=%d >= total=%d, nothing to do\n", startOffset, total)
		return
	}

	endOffset := startOffset + batchSize
	if endOffset > total {
		endOffset = total
	}

	// Build batch
	var nodes []utf32.L1NodeSpec
	for offset := startOffset; offset < endOffset; offset++ {
		cp := rune(cjkStart + offset)

		var islAddr [8]byte
		islAddr[0] = 0x01 // layer 1
		islAddr[1] = 0x4E // CJK
		islAddr[2] = uint8(offset >> 8)
		islAddr[3] = uint8(offset & 0xFF)
		binary.BigEndian.PutUint32(islAddr[4:], uint32(cp))

		// DNA: codepoint(4B) + offset(4B) — SDF placeholder
		dna := make([]byte, 8)
		binary.BigEndian.PutUint32(dna[0:4], uint32(cp))
		binary.BigEndian.PutUint32(dna[4:8], uint32(offset))

		name := fmt.Sprintf("CJK_%04X", cp)
		nodes = append(nodes, utf32.L1NodeSpec{
			ISL:  islAddr,
			CP:   uint32(cp),
			DNA:  dna,
			Name: name,
		})
	}

	added, skipped, err := utf32.AppendL1Batch(olangPath, nodes)
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed-cjk: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("CJK [%d..%d): +%d added  %d skipped\n",
		startOffset, endOffset, added, skipped)
	fmt.Printf("  Range: U+%04X – U+%04X  (%.1f%% done)\n",
		cjkStart+startOffset, cjkStart+endOffset-1,
		float64(endOffset)*100.0/float64(total))
}

// cmdSeedHangul — batch seed Hangul Syllables U+AC00–U+D7A3
func cmdSeedHangul(olangPath string, batchSize, startOffset int) {
	const hangulStart = 0xAC00
	const hangulEnd   = 0xD7A3
	const total       = hangulEnd - hangulStart + 1

	if startOffset >= total {
		fmt.Printf("start=%d >= total=%d, nothing to do\n", startOffset, total)
		return
	}
	endOffset := startOffset + batchSize
	if endOffset > total {
		endOffset = total
	}

	var nodes []utf32.L1NodeSpec
	for offset := startOffset; offset < endOffset; offset++ {
		cp := rune(hangulStart + offset)

		var islAddr [8]byte
		islAddr[0] = 0x01 // layer 1
		islAddr[1] = 0xAC // Hangul group
		islAddr[2] = uint8(offset >> 8)
		islAddr[3] = uint8(offset & 0xFF)
		binary.BigEndian.PutUint32(islAddr[4:], uint32(cp))

		dna := make([]byte, 8)
		binary.BigEndian.PutUint32(dna[0:4], uint32(cp))
		binary.BigEndian.PutUint32(dna[4:8], uint32(offset))

		name := fmt.Sprintf("HANGUL_%04X", cp)
		nodes = append(nodes, utf32.L1NodeSpec{
			ISL:  islAddr,
			CP:   uint32(cp),
			DNA:  dna,
			Name: name,
		})
	}

	added, skipped, err := utf32.AppendL1Batch(olangPath, nodes)
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed-hangul: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("Hangul [%d..%d): +%d added  %d skipped\n",
		startOffset, endOffset, added, skipped)
	fmt.Printf("  Range: U+%04X – U+%04X  (%.1f%% done)\n",
		hangulStart+startOffset, hangulStart+endOffset-1,
		float64(endOffset)*100.0/float64(total))
}

// cmdSeedContext — seed context nodes và composition edges vào homeos.olang
// Tạo context disambiguation: HEART(biology) ≠ HEART(emotion)
// Tạo composition: HEATH = H∘E∘A∘T∘H = LOVE = YÊU
func cmdSeedContext(olangPath string) {
	allDefs := append(olang.HeartContexts, olang.EarthContexts...)
	specs := olang.BuildContextNodes(allDefs)

	// Chuyển ContextNodeSpec → L1NodeSpec batch
	var l1Specs []utf32.L1NodeSpec
	for _, s := range specs {
		l1Specs = append(l1Specs, utf32.L1NodeSpec{
			ISL:  s.ISL,
			CP:   0,
			DNA:  s.DNA,
			Name: s.Name,
		})
	}

	added, skipped, err := utf32.AppendL1Batch(olangPath, l1Specs)
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed-context nodes: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("Context nodes: +%d added  %d skipped\n", added, skipped)

	// Thêm HEATH composition node
	heathISL := olang.MakeWordISL("HEATH")
	loveISL  := olang.MakeWordISL("LOVE")
	yeuISL   := olang.MakeWordISL("YEU")

	wordSpecs := []utf32.L1NodeSpec{
		{ISL: heathISL, Name: "WORD_HEATH_LOVE",     DNA: []byte("heath:emotion:love")},
		{ISL: loveISL,  Name: "WORD_LOVE_EN",        DNA: []byte("love:emotion:en")},
		{ISL: yeuISL,   Name: "WORD_YEU_VI",         DNA: []byte("yeu:emotion:vi")},
		{ISL: olang.MakeWordISL("YÊU"),  Name: "WORD_YEU_VI_ACCENT", DNA: []byte("yêu:emotion:vi")},
		{ISL: olang.MakeWordISL("사랑"), Name: "WORD_SARANG_KO",     DNA: []byte("사랑:emotion:ko")},
		{ISL: olang.MakeWordISL("愛"),   Name: "WORD_AI_ZH",         DNA: []byte("愛:emotion:zh")},
	}

	added2, skipped2, err := utf32.AppendL1Batch(olangPath, wordSpecs)
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed-context words: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("Composition words: +%d added  %d skipped\n", added2, skipped2)

	// Seed silk edges: HEATH≡LOVE≡YEU + H→HEATH, E→HEATH, ...
	added3, err := seedContextEdges(olangPath,
		heathISL, loveISL, yeuISL,
		[]rune{'H', 'E', 'A', 'T', 'H'})
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed-context edges: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("Composition edges: +%d added\n", added3)
	fmt.Printf("✅ Context disambiguation seeded into %s\n", olangPath)
}

// seedContextEdges ghi silk edges V2 vào cuối file
func seedContextEdges(path string, heathISL, loveISL, yeuISL [8]byte, chars []rune) (int, error) {
	type edgeSpec struct {
		src  [8]byte
		dst  [8]byte
		etype uint8
		w    float32
	}

	var specs []edgeSpec
	charISLs := olang.LatinCharISLs()

	// H∘E∘A∘T∘H → HEATH (composition: ký tự là thành phần của từ)
	for _, c := range chars {
		if cISL, ok := charISLs[c]; ok {
			specs = append(specs, edgeSpec{cISL, heathISL, olang.EdgeMember, 1.0})
		}
	}
	// HEATH ≡ LOVE ≡ YEU ≡ YÊU (same meaning)
	specs = append(specs,
		edgeSpec{heathISL, loveISL, olang.EdgeEquiv, 1.0},
		edgeSpec{heathISL, yeuISL,  olang.EdgeEquiv, 1.0},
		edgeSpec{heathISL, olang.MakeWordISL("YÊU"),  olang.EdgeEquiv, 1.0},
		edgeSpec{heathISL, olang.MakeWordISL("사랑"),  olang.EdgeEquiv, 1.0},
		edgeSpec{heathISL, olang.MakeWordISL("愛"),    olang.EdgeEquiv, 1.0},
		edgeSpec{loveISL,  yeuISL,  olang.EdgeEquiv, 1.0},
	)

	added := 0
	for _, e := range specs {
		if err := ws.OlangAppendEdgeWeighted(path, e.src, e.dst, e.etype, e.w); err == nil {
			added++
		}
	}
	return added, nil
}

// cmdSeedSymbols — seed L1 nodes cho tất cả symbols trong SymbolTable
// và tạo EdgeWorldLink: symbol_L1 → opcode_L0
func cmdSeedSymbols(olangPath string) {
	// Bước 1: Seed L1 nodes (symbol với đúng codepoint)
	var l1Specs []utf32.L1NodeSpec
	for _, sym := range olang.SymbolTable {
		if sym.Codepoint == 0 { continue }
		isl := olang.SymbolL1ISL(sym.Codepoint)

		// DNA: [opcode:1B][cp:4B][langs...]
		dna := make([]byte, 6)
		dna[0] = sym.Opcode
		dna[1] = byte(sym.Codepoint >> 24)
		dna[2] = byte(sym.Codepoint >> 16)
		dna[3] = byte(sym.Codepoint >> 8)
		dna[4] = byte(sym.Codepoint & 0xFF)
		dna[5] = byte(len(sym.MathDef))
		// Thêm math def
		if len(sym.MathDef) > 0 && len(sym.MathDef) < 200 {
			dna = append(dna, []byte(sym.MathDef)...)
		}
		// Thêm langs
		for _, lang := range sym.Langs {
			lb := []byte(lang)
			if len(dna)+1+len(lb) < 4000 {
				dna = append(dna, uint8(len(lb)))
				dna = append(dna, lb...)
			}
		}

		name := fmt.Sprintf("SYM_%s_%s", sym.Symbol, sym.OpName)
		l1Specs = append(l1Specs, utf32.L1NodeSpec{
			ISL:  isl,
			CP:   sym.Codepoint,
			DNA:  dna,
			Name: name,
		})
	}

	added, skipped, err := utf32.AppendL1Batch(olangPath, l1Specs)
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed-symbols: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("Symbol L1 nodes: +%d added  %d skipped\n", added, skipped)

	// Bước 2: Wire EdgeWorldLink — symbol_L1 → opcode_L0
	edgeCount := 0
	for _, sym := range olang.SymbolTable {
		if sym.Codepoint == 0 || sym.Opcode == 0 { continue }
		
		srcISL := olang.SymbolL1ISL(sym.Codepoint)
		dstISL := olang.L0ISLFor(sym.Opcode)

		if err := ws.OlangAppendEdgeWeighted(
			olangPath, srcISL, dstISL,
			olang.EdgeWorldLink, // 0x0E
			1.0,
		); err == nil {
			edgeCount++
		}
	}
	fmt.Printf("WorldLink edges:  +%d added\n", edgeCount)

	// Bước 3: Wire EdgeEquiv cho math symbols đã tồn tại trong L1
	// ∪ (L1 seeded) → ∪ (L1 sym node mới) — hợp nhất nghĩa
	equivCount := 0
	for _, sym := range olang.SymbolTable {
		if sym.Codepoint == 0 { continue }
		newISL := olang.SymbolL1ISL(sym.Codepoint)
		// ISL cũ theo seeder format (nếu đã tồn tại)
		oldISL := seedISLFor(sym.Codepoint)
		if oldISL != newISL {
			if err := ws.OlangAppendEdgeWeighted(
				olangPath, newISL, oldISL,
				olang.EdgeEquiv, 1.0,
			); err == nil {
				equivCount++
			}
		}
	}
	fmt.Printf("Equiv edges:      +%d added\n", equivCount)
	fmt.Printf("✅ Symbols seeded và wired vào %s\n", olangPath)

	// Báo cáo chi tiết
	fmt.Println("\nKiểm tra nhất quán:")
	for _, sym := range olang.SymbolTable {
		opStr := fmt.Sprintf("0x%02x", sym.Opcode)
		if sym.Opcode == 0 { opStr = "concept" }
		fmt.Printf("  %s U+%04X ─[WorldLink]─► %s (%s)\n",
			sym.Symbol, sym.Codepoint, sym.OpName, opStr)
	}
}

// seedISLFor — ISL cũ của ký tự đã được seed bởi seeder unicode
// (dùng sha256-based hash của seeder, khác với SymbolL1ISL)
func seedISLFor(cp uint32) [8]byte {
	// Format seeder cũ (từ internal/utf32/seeder.go):
	// isl[0]=0x01, isl[1]=0x09, isl[2..3]=cp hi, isl[4..7]=cp lo (big endian)
	var isl [8]byte
	isl[0] = 0x01
	isl[1] = 0x09
	isl[2] = byte(cp >> 24)
	isl[3] = byte(cp >> 16)
	isl[4] = byte(cp >> 8)
	isl[5] = byte(cp & 0xFF)
	// Seeder dùng hash riêng — xem seeder.go để biết chính xác
	// Tạm thời dùng cùng format → sẽ match nếu SymbolL1ISL và seeder dùng cùng format
	isl[6] = byte(cp>>12) ^ byte(cp>>4)
	isl[7] = byte(cp) ^ byte(cp>>8)
	return isl
}

// cmdSeedQT — seed 9 QT concept nodes (L3) + missing symbols vào homeos.olang
// Đây là lần đầu tiên 9 QT được ghi vào file dưới dạng nodes chính thức
func cmdSeedQT(olangPath string) {
	totalAdded := 0
	totalSkipped := 0
	totalEdges := 0

	// ── Bước 1: Seed MissingQTSymbols (L1 nodes) ───────────────
	fmt.Println("=== BƯỚC 1: Seed Missing QT Symbols (L1) ===")
	var l1Specs []utf32.L1NodeSpec
	for _, sym := range olang.MissingQTSymbols {
		isl := olang.SymbolL1ISL(sym.CP)
		dna := buildSymDNA(sym.CP, sym.Meaning)
		l1Specs = append(l1Specs, utf32.L1NodeSpec{
			ISL:  isl,
			CP:   sym.CP,
			DNA:  dna,
			Name: sym.Name,
		})
	}
	if added, skipped, err := utf32.AppendL1Batch(olangPath, l1Specs); err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed missing symbols: %v\n", err)
	} else {
		totalAdded += added
		totalSkipped += skipped
		fmt.Printf("  L1 symbols: +%d added, %d skipped\n", added, skipped)
		for _, s := range l1Specs {
			if added > 0 {
				cp := s.CP
				sym := ""
				if cp > 0 && cp <= 0x10FFFF { sym = string(rune(cp)) }
				fmt.Printf("    %s U+%04X %s\n", sym, cp, s.Name)
			}
		}
	}

	// ── Bước 2: Seed QTConceptNodes (L3 nodes) ─────────────────
	fmt.Println("\n=== BƯỚC 2: Seed QT Concept Nodes (L3) ===")
	var qtL1Specs []utf32.L1NodeSpec
	for _, qt := range olang.QTConceptNodes {
		qtL1Specs = append(qtL1Specs, utf32.L1NodeSpec{
			ISL:  qt.ISL,
			CP:   qt.CP,
			DNA:  qt.DNA,
			Name: qt.Name,
		})
	}
	if added, skipped, err := utf32.AppendNodeBatch(olangPath, qtL1Specs); err != nil {
		fmt.Fprintf(os.Stderr, "❌ seed QT concept nodes: %v\n", err)
	} else {
		totalAdded += added
		totalSkipped += skipped
		fmt.Printf("  QT nodes: +%d added, %d skipped\n", added, skipped)
		for i, qt := range olang.QTConceptNodes {
			sym := ""
			if qt.CP > 0 && qt.CP <= 0x10FFFF { sym = string(rune(qt.CP)) }
			fmt.Printf("    QT%d %s %s  ISL:%x\n", i+1, sym, qt.Name, qt.ISL)
		}
	}

	// ── Bước 3: Wire QT Silk Edges ─────────────────────────────
	fmt.Println("\n=== BƯỚC 3: Wire QT Silk Edges ===")
	qtEdges := olang.BuildQTEdges()
	for _, edge := range qtEdges {
		if err := ws.OlangAppendEdgeWeighted(
			olangPath, edge.SrcISL, edge.DstISL,
			edge.Type, edge.Weight,
		); err == nil {
			totalEdges++
		}
	}
	fmt.Printf("  QT edges: +%d wired\n", totalEdges)

	// ── Verify ─────────────────────────────────────────────────
	fmt.Println("\n=== VERIFY ===")
	fmt.Printf("  Total nodes added: %d\n", totalAdded)
	fmt.Printf("  Total skipped:     %d\n", totalSkipped)
	fmt.Printf("  Total edges:       %d\n", totalEdges)
	fmt.Printf("\n✅ 9 QT seeded vào %s\n", olangPath)
}

func buildSymDNA(cp uint32, meaning string) []byte {
	m := []byte(meaning)
	if len(m) > 200 { m = m[:200] }
	d := []byte{0x01, 0x09, byte(cp>>24), byte(cp>>16), byte(cp>>8), byte(cp), byte(len(m))}
	return append(d, m...)
}

// cmdMigrateDNA — entry point cho migrate-dna command (gọi từ main)
func cmdMigrateDNA(path string) {
	res, err := utf32.MigrateDNAHeaders(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "migrate-dna: %v\n", err)
		os.Exit(1)
	}
	fmt.Printf("migrate-dna: total=%d patched=%d skipped=%d errors=%d\n",
		res.Total, res.Patched, res.Skipped, res.Errors)
}
