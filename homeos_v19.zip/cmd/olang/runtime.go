// cmd/olang/runtime.go
// cmdRunFull — chạy HomeOS thật từ homeos.olang
// Mục tiêu: `olang run homeos.olang` = toàn bộ hệ thống
//
// Session 137: nối đầy đủ 40 skills vào đúng agents (fix vấn đề #1)

package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"

	"github.com/goldlotus1810/HomeOS/internal/agents"
	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/nca"
	"github.com/goldlotus1810/HomeOS/internal/silk"
	"github.com/goldlotus1810/HomeOS/internal/utf32"
	"github.com/goldlotus1810/HomeOS/internal/ws"
)

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

// cmdRunFull — full HomeOS runtime
func cmdRunFull(path string) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// ── SecurityGate ───
	soma := nca.NewSoma()
	_ = soma
	log.Println("✅ SecurityGate: online")

	// ── SilkGraph + L7 từ olang ──
	graph := silk.NewSilkGraph()
	weightStore := silk.NewEdgeWeightStore(path + ".weights") // Hebbian weights persist
	weightStore.ApplyTo(graph) // restore weights từ lần chạy trước
	ledger := silk.NewLedger("", nil)
	silk.SeedUnicodeTree(graph)
	ne := silk.ApplyNameEdges(graph)
	ie := silk.ApplyIPAEdges(graph)
	un, ue := silk.SeedUTF32(graph)
	bn, be := silk.SeedUTF32Bridge(graph)
	log.Printf("✅ SilkGraph: %d nodes, %d edges (name:%d ipa:%d utf32:+%d/+%d bridge:+%d/+%d)",
		graph.NodeCount(), graph.EdgeCount(), ne, ie, un, ue, bn, be)

	if n7, _ := silk.LoadFromOlang(graph, path); n7 > 0 {
		log.Printf("✅ L7: %d nodes loaded", n7)
	}

	// ── Memory ĐN + QR ──
	dn := memory.NewShortTerm(512)
	qr := memory.NewLongTerm(graph, ledger)

	// QRWriter — bridge LongTerm.Commit() → homeos.olang (QT7 + QT8)
	// Inject appendFn từ utf32 để tránh import cycle
	qrWriter := memory.NewQRWriter(
		path,
		// appendFn: wrap utf32.AppendL1Batch
		func(p string, specs []memory.AppendSpec) (int, int, error) {
			l1specs := make([]utf32.L1NodeSpec, len(specs))
			for i, s := range specs {
				l1specs[i] = utf32.L1NodeSpec{ISL: s.ISL, CP: s.CP, DNA: s.DNA, Name: s.Name}
			}
			added, skipped, err := utf32.AppendL1Batch(p, l1specs)
			return added, skipped, err
		},
		// edgeFn: wrap ws.OlangAppendEdgeWeighted
		func(p string, src, dst [8]byte, etype uint8, w float32) error {
			return ws.OlangAppendEdgeWeighted(p, src, dst, etype, w)
		},
	)
	qr.WithQRWriter(qrWriter)

	dreamMem := memory.NewDream(dn, qr)
	go dreamMem.Run(ctx)

	// ── Shared infrastructure ──
	codec    := isl.NewPlainCodec()
	bus      := make(chan *isl.ISLMessage, 128)
	registry := agents.NewAgentRegistry()
	msgBus   := agents.NewMessageBus()
	actCh    := nca.NewActivityChan()

	// ── NxT cycle (actuation bus) ──
	go nca.RunCycle(ctx, nca.DefaultConfig, dn, qr, bus)
	log.Println("✅ NxT: running")

	// Shared skills (được wire vào nhiều agents)
	scheduleLearner := agents.NewScheduleLearnerSkill()
	// Load OlangFile để persister cluster nodes
	var olangFile *olang.OlangFile
	if f, err := olang.LoadFile(path); err == nil {
		olangFile = f
		log.Printf("OlangFile loaded: %d nodes for cluster persist", f.TotalNodes)
	} else {
		log.Printf("OlangFile load failed (new file?): %v — cluster persist disabled", err)
	}
	clusterSkill := agents.NewClusterSkill(dn, qr, graph)
	if olangFile != nil {
		clustersPath := path + ".clusters.olang"
		clusterSkill = clusterSkill.WithPersister(olangFile, clustersPath)
	}
	proposalHandler := agents.NewProposalHandlerSkill(dn, qr).WithClusterSkill(clusterSkill).WithGraph(graph)

	// ════════════════════════════════════════════════════════
	// AAM — Tier 0: tổng chỉ huy
	// ════════════════════════════════════════════════════════
	skillGraph := agents.NewSkillGraph()
	skillReg   := agents.NewSkillRegistry()
	aamInbox   := make(chan *isl.ISLMessage, 64)

	// ED25519 keys cho AuditLog (QT8: append-only, signed)
	// Production: load từ file; dev: generate ephemeral
	_, aamAuditKey, _ := ed25519.GenerateKey(rand.Reader)
	_, leoAuditKey, _ := ed25519.GenerateKey(rand.Reader)
	auditDir := filepath.Join(filepath.Dir(os.Args[2]), "audit")
	_ = os.MkdirAll(auditDir, 0755)
	aamLogger := agents.NewLoggerSkill("aam", aamAuditKey).
		WithAuditPath(filepath.Join(auditDir, "aam_audit.jsonl"))
	leoLogger := agents.NewLoggerSkill("leoai", leoAuditKey).
		WithAuditPath(filepath.Join(auditDir, "leoai_audit.jsonl"))
	msgBus.Register("aam", aamInbox, 0, agents.RoleAAM)

	aam := agents.New("aam", codec, aamInbox, bus).
		// Core
		AddSkill(&agents.BroadcastSkill{}).
		AddSkill(&agents.HeartbeatSkill{}).
		// Router: forward actuator commands xuống home_chief (QT5)
		AddSkill(agents.NewAAMRouterSkill(registry)).
		// Knowledge routing
		AddSkill(agents.NewKnowledgeRouterSkill("aam", agents.Tier(0))).
		// Proposal handler (QT7: NCA propose → AAM approve → commit ĐN→QR)
		AddSkill(proposalHandler).
		// Security
		AddSkill(agents.NewEphemeralAuthSkill("aam")).
		AddSkill(agents.NewAAMGrantSkill()).
		AddSkill(agents.NewSecurityAuditSkill()).
		// Intelligence
		AddSkill(agents.NewContextAwareSkill("aam")).
		AddSkill(agents.NewSkillSynthesizerSkill(skillGraph, skillReg)).
		// Notify
		AddSkill(agents.NewNotifyUserSkill()).
		AddSkill(agents.NewHonestySkill()).
		AddSkill(aamLogger).
		RegisterTo(registry)
	aam.Learner().OnPropose(func(p *agents.SkillProposal) {
		log.Printf("📝 SkillLearner: proposal [%s] conf=%.2f", p.Name, p.Confidence)
	})
	aam.Learner().OnActivate(func(p *agents.SkillProposal) {
		log.Printf("🚀 SkillLearner: activated [%s]", p.Name)
	})
	aam.RunAsync(ctx)
	log.Println("✅ AAM: online (11 skills)")

	// ════════════════════════════════════════════════════════
	// LeoAI — Tier 1: học + dream
	// ════════════════════════════════════════════════════════
	leoInbox := make(chan *isl.ISLMessage, 64)
	msgBus.Register("leoai", leoInbox, 1, agents.RoleLeoAI)


	leoai := agents.New("leoai", codec, leoInbox, bus).
		// Input
		AddSkill(agents.NewSkillUserInputWatch(msgBus, actCh)).
		// Immutable QR — "đây là Quy Tắc" → conf=1.0 → ghi ngay (ưu tiên cao nhất)
		AddSkill(agents.NewImmutableSkill(dn, qr)).
		// Memory write (ĐN) — normal learning path
		AddSkill(agents.NewDNFireSkill(dn, qr)).
		AddSkill(agents.NewTeachSkill(dn, qr)).
		// Learning
		AddSkill(clusterSkill).
		AddSkill(agents.NewHebbianSkill(dn, graph).WithWeightStore(weightStore)).
		AddSkill(agents.NewDreamSkill(dn, qr, graph).
			WithOlangPath(path).
			WithEdgeFlusher(func(src, dst [8]byte, etype uint8, w float32) error {
				return ws.OlangAppendEdgeWeighted(path, src, dst, etype, w)
			})).
		AddSkill(scheduleLearner).
		AddSkill(agents.NewScheduleDreamSkill(scheduleLearner)).
		// Knowledge walk
		AddSkill(agents.NewSilkWalkSkill(graph)).
		// Dispatch đến edge agents
		AddSkill(agents.NewDreamDispatchSkill(registry)).
		AddSkill(leoLogger).
		RegisterTo(registry)
	leoai.RunAsync(ctx)
	log.Println("✅ LeoAI: online (11 skills)")

	// NxT → LeoAI bridge
	go func() {
		leoNxTBus := make(chan *isl.ISLMessage, 32)
		go nca.RunCycle(ctx, nca.DefaultConfig, dn, qr, leoNxTBus, actCh)
		for {
			select {
			case <-ctx.Done():
				return
			case msg, ok := <-leoNxTBus:
				if !ok {
					return
				}
				if msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgDream {
					select {
					case leoInbox <- msg:
					default:
					}
				}
			}
		}
	}()

	// ════════════════════════════════════════════════════════
	// HomeChief — Tier 1: điều phối thiết bị nhà
	// ════════════════════════════════════════════════════════
	agents.New("home_chief", codec, make(chan *isl.ISLMessage, 32), bus).
		// Core routing
		AddSkill(agents.NewHomeChief(registry)).
		// Device management
		AddSkill(agents.NewOnboardSkill(agents.NewRealLANScanner())). // ARP + mDNS thật
		AddSkill(agents.NewFirmwareReaderSkill()).
		AddSkill(agents.NewCapabilityMapSkill()).
		AddSkill(agents.NewFirmwarePatchSkill()).
		// Worker export — Chief clone worker.olang → ship đến thiết bị
		AddSkill(agents.NewExportWorkerSkill(path, filepath.Join(filepath.Dir(path), "workers"))).
		// System monitoring
		AddSkill(agents.NewEnvironmentProbeSkill()).
		AddSkill(agents.NewNetworkMonitorSkill()).
		AddSkill(agents.NewProcessWatchSkill()).
		AddSkill(agents.NewOSProfileSkill()).
		AddSkill(agents.NewErrorCollectorSkill()).
		AddSkill(agents.NewLoggerSkill("home_chief", nil).WithAuditPath(path+".audit.log")).
		// External
		AddSkill(agents.NewWebFetchSkill()).
		AddSkill(agents.NewAppLauncherSkill()).
		AddSkill(agents.NewDataLeakDetectSkill()).
		RegisterTo(registry).RunAsync(ctx)
	log.Println("✅ HomeChief: online (15 skills + ExportWorker)")

	// ════════════════════════════════════════════════════════
	// Light workers — Tier 2
	// Worker = HomeOS tại thiết bị: Actuator + Monitor + Watch
	// ════════════════════════════════════════════════════════
	agents.New("light_living", codec, make(chan *isl.ISLMessage, 32), bus).
		AddSkill(agents.NewActuatorLight("living_room")).
		AddSkill(agents.NewTrafficMonitorSkill("light_living", "")).
		AddSkill(agents.NewFirmwareWatchSkill("light_living", "")).
		RegisterTo(registry).RunAsync(ctx)
	agents.New("light_bed", codec, make(chan *isl.ISLMessage, 32), bus).
		AddSkill(agents.NewActuatorLight("bedroom")).
		AddSkill(agents.NewTrafficMonitorSkill("light_bed", "")).
		AddSkill(agents.NewFirmwareWatchSkill("light_bed", "")).
		RegisterTo(registry).RunAsync(ctx)
	log.Println("✅ Light workers: online (living_room + bedroom) + TrafficMonitor + FirmwareWatch")

	// ════════════════════════════════════════════════════════
	// HVAC worker — Tier 2
	// ════════════════════════════════════════════════════════
	agents.New("hvac_living", codec, make(chan *isl.ISLMessage, 32), bus).
		AddSkill(agents.NewActuatorHvacSkill("hvac_living", gene.SpaceType("living_room"))).
		AddSkill(agents.NewTrafficMonitorSkill("hvac_living", "")).
		AddSkill(agents.NewFirmwareWatchSkill("hvac_living", "")).
		RegisterTo(registry).RunAsync(ctx)
	log.Println("✅ HVAC: online + TrafficMonitor + FirmwareWatch")

	// ════════════════════════════════════════════════════════
	// VisionChief — Tier 1: nhận diện vật thể
	// ════════════════════════════════════════════════════════
	agents.New("vision_chief", codec, make(chan *isl.ISLMessage, 32), bus).
		AddSkill(agents.NewPerceptionSkill("camera_01", "human")).
		AddSkill(agents.NewAggregateSkill()).
		AddSkill(agents.NewDecideSkill()).
		AddSkill(agents.NewSpatialLearnSkill(dn, qr)).
		AddSkill(agents.NewSpatialQuerySkill(dn, qr)).
		AddSkill(agents.NewProsodySkill(16000)).
		RegisterTo(registry).RunAsync(ctx)
	log.Println("✅ VisionChief: online (6 skills)")

	log.Printf("✅ Total: %d agents online", len(registry.IDs()))

	// ── HTTP/WS Server ──
	qrCount := graph.NodeCount()
	dnCount := 0
	world   := ws.NewWorld(888, graph)
	server  := ws.NewServer(world, &qrCount, &dnCount, envOr("HOMEOS_STATIC", "web/static"))
	server.SetBus(bus)
	server.SetMessageBus(msgBus)
	server.SetRegistry(registry)
	server.SetAAMInbox(aamInbox) // QT5: actuator commands qua AAM
	server.SetShortTerm(dn)

	addr := envOr("HOMEOS_ADDR", ":8080")
	log.Printf("🌐 http://localhost%s  (api/tree · api/edges · ws/sse)", addr)
	log.Printf("✅ olang run %s → HomeOS ready", path)

	go func() {
		if err := server.Serve(addr); err != nil {
			log.Fatalf("server: %v", err)
		}
	}()

	// ── Graceful shutdown ──
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Println("🛑 shutdown")
	cancel()
}
