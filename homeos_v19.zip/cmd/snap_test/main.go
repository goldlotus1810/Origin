package main

import (
	"fmt"
	"github.com/goldlotus1810/HomeOS/internal/gene"
)

func main() {
	ws := gene.NewWorldScene()
	ws.Clock.HourOfDay = 12.0
	ws.Clock.YearT = 0.5

	snap := ws.Snapshot()
	fmt.Printf("Snapshot: %d streams, %d bytes\n", len(snap.Streams), snap.TotalBytes())

	payload := gene.SnapshotPayload(snap)
	fmt.Printf("Payload:  %d bytes  magic=%c%c%c%c\n",
		len(payload), payload[0], payload[1], payload[2], payload[3])

	snap2, err := gene.DecodeSnapshotPayload(payload)
	if err != nil { fmt.Println("FAIL:", err); return }
	fmt.Printf("Decode:   %d streams\n", len(snap2.Streams))
	for i, s := range snap2.Streams {
		orig := snap.Streams[i]
		mark := "✓"
		if s.Len() != orig.Len() { mark = "✗" }
		fmt.Printf("  stream %d: %d tokens %s\n", i, s.Len(), mark)
	}

	name, err := gene.SaveSnapshot(snap)
	if err != nil { fmt.Println("SaveSnapshot ERR:", err); return }
	fmt.Printf("\nSaved → %s\n", name)

	infos, _ := gene.ListSnapshots()
	for _, info := range infos {
		fmt.Printf("  %-38s streams=%d tokens=%d %dB\n",
			info.Name, info.NStreams, info.TotalTokens, info.PayloadB)
	}

	snap3, err := gene.LoadSnapshot(name)
	if err != nil { fmt.Println("LoadSnapshot ERR:", err); return }
	fmt.Printf("Loaded: %d streams\n", len(snap3.Streams))

	if len(snap3.Streams) > 0 && snap3.Streams[0].Len() > 0 {
		tok := snap3.Streams[0].Tokens[0]
		fmt.Printf("Sun stream[0]: addr=%016x", uint64(tok.Addr))
		if uint64(tok.Addr) == uint64(gene.ISL_Sun) {
			fmt.Print("  = ISL_Sun ✓")
		}
		fmt.Println()
	}
	fmt.Println("\nISLStream → homeos.olang node payload ✓")
}
