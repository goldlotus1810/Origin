package main

import (
	"fmt"
	"log"
	"os"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/vsdf"
)

func main() {
	path := "homeos.olang"
	if len(os.Args) > 1 { path = os.Args[1] }

	log.Printf("Loading %s...", path)
	raw, err := os.ReadFile(path)
	if err != nil { log.Fatal(err) }

	res, err := olang.ParseBytes(raw)
	if err != nil { log.Fatal(err) }

	l1 := res.ByLayer[1]
	log.Printf("L1 nodes: %d", len(l1))

	hasDNA, empty := 0, 0
	for _, n := range l1 {
		if len(n.DNA) >= 2 { hasDNA++ } else { empty++ }
	}
	log.Printf("  with DNA: %d  empty: %d", hasDNA, empty)

	// Demo
	demo := []vsdf.RawStroke{
		{Type:'L', X0:0.1,Y0:0.0, X1:0.1,Y1:1.0, DX:0.0,DY:1.0, Len:1.0},
		{Type:'L', X0:0.9,Y0:0.0, X1:0.9,Y1:1.0, DX:0.0,DY:1.0, Len:1.0},
		{Type:'L', X0:0.1,Y0:0.5, X1:0.9,Y1:0.5, DX:0.8,DY:0.0, Len:0.8},
	}
	data := vsdf.EncodeSimple(demo)
	fmt.Printf("\nDemo 'H': %d strokes → %d bytes\n", len(demo), len(data))
	fmt.Printf("Stroke table: %d/255 entries\n", countTable())
	fmt.Printf("Radical table: %d/214 entries\n", countRadicals())
	fmt.Printf("\nEst full encoding:\n")
	fmt.Printf("  Latin 7K chars × 11B  = %.0fKB\n", float64(7000*11)/1024)
	fmt.Printf("  CJK   80K chars × 14B = %.0fKB\n", float64(80000*14)/1024)
	fmt.Printf("  Other 73K chars × 2B  = %.0fKB\n", float64(73000*2)/1024)
	total := float64(7000*11 + 80000*14 + 73000*2) / 1024 / 1024
	fmt.Printf("  TOTAL 160K chars      = %.2fMB\n", total)
}

func countTable() int {
	n := 0
	for i := 1; i < 256; i++ {
		if vsdf.StrokeTable[i].Length > 0 { n++ }
	}
	return n
}
func countRadicals() int {
	n := 0
	for i := 1; i < 215; i++ {
		if vsdf.RadicalTable[i].NStroke > 0 { n++ }
	}
	return n
}
