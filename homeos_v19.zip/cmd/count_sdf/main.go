package main

import (
	"fmt"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

func main() {
	f, err := olang.LoadFile("homeos.olang")
	if err != nil { panic(err) }

	// SDF+TEXT dups — TEXT có nội dung gì?
	fmt.Println("=== SDF+TEXT duplicates (sample) ===")
	type nodeRef struct { n *olang.OlangNode; lid uint8 }
	dupMap := map[uint32][]nodeRef{}
	for lid := uint8(0); lid <= 7; lid++ {
		for i := range f.Layers[lid] {
			n := f.Layers[lid][i]
			dupMap[n.Codepoint] = append(dupMap[n.Codepoint], nodeRef{n, lid})
		}
	}

	shown := 0
	for cp, refs := range dupMap {
		if len(refs) < 2 { continue }
		hasSDF, hasTEXT := false, false
		for _, r := range refs {
			if len(r.n.DNA) > 0 {
				typ := r.n.DNA[0] & 0x3F
				if typ == 0x02 { hasSDF = true }
				if typ == 0x06 { hasTEXT = true }
			}
		}
		if !hasSDF || !hasTEXT { continue }
		fmt.Printf("  U+%04X '%c':\n", cp, rune(cp))
		for _, r := range refs {
			var typ byte
			if len(r.n.DNA) > 0 { typ = r.n.DNA[0] & 0x3F }
			dnaPreview := ""
			if typ == 0x06 && len(r.n.DNA) > 1 {
				dnaPreview = fmt.Sprintf("  text=%q", r.n.DNA[1:min(20,len(r.n.DNA))])
			}
			fmt.Printf("    L%d typ=0x%02x dnaLen=%d%s\n", r.lid, typ, len(r.n.DNA), dnaPreview)
		}
		shown++
		if shown >= 4 { break }
	}

	// L0/L4 bad summary
	fmt.Println("\n=== L0/L4 cp=0 bad nodes ===")
	for lid := uint8(0); lid <= 4; lid++ {
		for _, n := range f.Layers[lid] {
			if n.Codepoint != 0 { continue }
			var typ byte
			if len(n.DNA) > 0 { typ = n.DNA[0] & 0x3F }
			fmt.Printf("  L%d cp=0 typ=0x%02x dnaLen=%d name=%q\n", lid, typ, len(n.DNA), n.Name())
		}
	}
}
func min(a,b int) int { if a<b {return a}; return b }
