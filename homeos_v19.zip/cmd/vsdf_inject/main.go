// vsdf_inject: rebuild homeos.olang với molecular DNA injected vào mỗi node
package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene/alphabet"
	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/vsdf"
)

func allChars() []*alphabet.OlangChar {
	var out []*alphabet.OlangChar
	out = append(out, alphabet.AllLatin()...)
	out = append(out, alphabet.AllGreek()...)
	out = append(out, alphabet.AllCyrillic()...)
	out = append(out, alphabet.AllDevanagari()...)
	out = append(out, alphabet.AllArabic()...)
	out = append(out, alphabet.AllCJK()...)
	return out
}

func main() {
	path := "homeos.olang"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		log.Fatal(err)
	}
	if string(raw[0:4]) != "OLNG" {
		log.Fatal("bad magic")
	}

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	log.Printf("Loaded %s: %dB, %d edges, edgeStart=%d", path, len(raw), nedges, edgeStart)

	// Build molecular DNA map
	t0 := time.Now()
	chars := allChars()
	log.Printf("Building molecule table for %d chars...", len(chars))

	var strokes []vsdf.StrokeCandidate
	for _, ch := range chars {
		if ch.SDF == nil {
			continue
		}
		strokes = append(strokes, vsdf.ExtractStrokes(vsdf.SampleChar(ch.Codepoint, ch.SDF))...)
	}
	mt := vsdf.BuildMoleculeTable(strokes)
	log.Printf("Molecule table: %d entries", len(mt.Entries))

	dnaMap := map[uint32][]byte{}
	cpToScript := map[uint32]string{}
	for _, ch := range chars {
		if ch.SDF == nil {
			continue
		}
		g := vsdf.EncodeGlyph(ch.Codepoint, ch.SDF, mt)
		b := g.Bytes()
		if len(b) > 0 {
			dnaMap[ch.Codepoint] = b
			cpToScript[ch.Codepoint] = ch.Script
		}
	}
	log.Printf("Encoded %d glyphs in %v", len(dnaMap), time.Since(t0))

	tableBytes := mt.Serialize()

	// Rebuild file preserving exact old format
	// Header: bytes [0:280] (header + layer index)
	headerSection := make([]byte, 280)
	copy(headerSection, raw[:280])

	var nodeBuf bytes.Buffer

	// Node 0 in L0: molecule table (cp=0, layer=0, ISL=0)
	{
		b4 := make([]byte, 4)
		nodeBuf.WriteString("ND")
		nodeBuf.WriteByte(0)                                     // layer 0
		nodeBuf.Write(make([]byte, 8))                           // ISL = 0
		binary.BigEndian.PutUint32(b4, 0); nodeBuf.Write(b4)    // cp = 0
		binary.BigEndian.PutUint32(b4, uint32(len(tableBytes))); nodeBuf.Write(b4)
		nodeBuf.WriteByte(0) // nameLen = 0
		nodeBuf.Write(tableBytes)
	}

	// Rebuild all original nodes (preserve order, inject DNA where we have it)
	injected, kept, empty := 0, 0, 0
	perScript := map[string][2]int{}
	b4 := make([]byte, 4)

	for pos := 280; pos+20 <= edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' {
			pos++
			continue
		}
		layer := raw[pos+2]
		islBytes := raw[pos+3 : pos+11]
		cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
		dnaLen := int(binary.BigEndian.Uint32(raw[pos+15:]))
		nameLen := int(raw[pos+19])
		if dnaLen < 0 || dnaLen > 200000 {
			pos++
			continue
		}

		oldDNA := raw[pos+20 : pos+20+dnaLen]
		name := raw[pos+20+dnaLen : pos+20+dnaLen+nameLen]

		var useDNA []byte
		if nd, ok := dnaMap[cp]; ok {
			useDNA = nd
			injected++
			sc := cpToScript[cp]
			s := perScript[sc]
			s[0]++; s[1] += len(useDNA)
			perScript[sc] = s
		} else if len(oldDNA) > 0 {
			useDNA = oldDNA
			kept++
		} else {
			useDNA = []byte{0} // empty marker
			empty++
		}

		// Write node
		nodeBuf.WriteString("ND")
		nodeBuf.WriteByte(layer)
		nodeBuf.Write(islBytes)
		binary.BigEndian.PutUint32(b4, cp); nodeBuf.Write(b4)
		binary.BigEndian.PutUint32(b4, uint32(len(useDNA))); nodeBuf.Write(b4)
		nodeBuf.WriteByte(byte(nameLen))
		nodeBuf.Write(useDNA)
		nodeBuf.Write(name)

		pos += 20 + dnaLen + nameLen
	}

	// Update node count in header [8:12]
	totalNodes := 1 + injected + kept + empty // +1 for mol table node
	binary.BigEndian.PutUint32(headerSection[8:], uint32(totalNodes))

	// Assemble final file
	var out bytes.Buffer
	out.Write(headerSection)
	out.Write(nodeBuf.Bytes())
	out.Write(raw[edgeStart:]) // edges unchanged

	outPath := path + ".injected"
	if err := os.WriteFile(outPath, out.Bytes(), 0644); err != nil {
		log.Fatal(err)
	}

	// Verify it loads
	res, verr := olang.ParseBytes(out.Bytes())
	if verr != nil {
		log.Printf("⚠️  Verify failed: %v", verr)
	} else {
		log.Printf("✅ Verify OK: %d nodes, %d edges", res.NodeCount, res.EdgeCount)
	}

	fi, _ := os.Stat(outPath)
	fmt.Printf("\n=== DONE ===\n")
	fmt.Printf("Input:     %.2fMB → Output: %.2fMB\n",
		float64(len(raw))/1024/1024, float64(fi.Size())/1024/1024)
	fmt.Printf("Injected:  %d molecular | Kept: %d TTF | Empty: %d\n", injected, kept, empty)
	fmt.Printf("MolTable:  %d entries (%dB) in L0\n", len(mt.Entries), len(tableBytes))
	fmt.Printf("\nPer-script:\n")
	for _, sc := range []string{"latin", "greek", "cyrillic", "devanagari", "arabic", "cjk"} {
		v := perScript[sc]
		if v[0] > 0 {
			fmt.Printf("  %-12s %3d chars  avg=%dB\n", sc, v[0], v[1]/v[0])
		}
	}
}
