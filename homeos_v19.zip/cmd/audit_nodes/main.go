package main

import (
	"encoding/binary"
	"fmt"
	"math"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

func main() {
	rr, err := olang.ReadFile("homeos.olang")
	if err != nil {
		panic(err)
	}

	fmt.Printf("=== NODE AUDIT homeos.olang ===\n")
	fmt.Printf("  Total nodes: %d\n", rr.NodeCount)
	fmt.Printf("  Total edges: %d\n", rr.EdgeCount)
	fmt.Printf("  Corrupt:     %d\n\n", len(rr.Corrupt))

	nAtom, nSDF, nText, nZero, nOther, emptyDNA := 0, 0, 0, 0, 0, 0
	badDNA, noCaps, badCoord, dupCount := 0, 0, 0, 0
	capsuleCounts := map[int]int{}
	dupISL := map[uint64]int{}
	var sampleBad []string

	for _, n := range rr.Nodes {
		if prev, ok := dupISL[n.ISLAddr]; ok {
			dupCount++
			_ = prev
		} else {
			dupISL[n.ISLAddr] = 1
		}

		dna := n.DNA
		if len(dna) == 0 {
			emptyDNA++
			continue
		}

		b0 := dna[0]
		dnaType := b0 & 0x3F

		switch dnaType {
		case 0x41: // ATOM
			nAtom++
			if len(dna) < 6 {
				badDNA++
				if len(sampleBad) < 3 {
					sampleBad = append(sampleBad, fmt.Sprintf("ATOM too short: ISL=%016X len=%d", n.ISLAddr, len(dna)))
				}
			} else if dna[1] != 0x14 {
				badDNA++
				if len(sampleBad) < 3 {
					sampleBad = append(sampleBad, fmt.Sprintf("ATOM missing EMIT: ISL=%016X b[1]=0x%02X", n.ISLAddr, dna[1]))
				}
			}

		case 0x42: // SDF
			nSDF++
			j := 1
			if j < len(dna) && dna[j] == 0x9A {
				j += 5
			}
			if j >= len(dna) || dna[j] != 0x10 {
				badDNA++
				if len(sampleBad) < 3 {
					sampleBad = append(sampleBad, fmt.Sprintf("SDF missing 0x10: ISL=%016X j=%d", n.ISLAddr, j))
				}
				continue
			}
			nCaps := int(dna[j+1])
			capsuleCounts[nCaps]++
			if nCaps == 0 {
				noCaps++
				continue
			}
			capStart := j + 6 // skip 0x10 + nCaps(1) + k_f32(4)
			for c := 0; c < nCaps; c++ {
				base := capStart + c*29
				if base+1 > len(dna) {
					break
				}
				if dna[base] != 0x02 {
					badDNA++
					break
				}
				for ax := 0; ax < 6; ax++ {
					off := base + 1 + ax*4
					if off+4 > len(dna) {
						break
					}
					bits := binary.BigEndian.Uint32(dna[off:])
					f := math.Float32frombits(bits)
					if math.IsNaN(float64(f)) || math.IsInf(float64(f), 0) || f < -5 || f > 5 {
						badCoord++
						break
					}
				}
			}

		case 0x06:
			nText++
		case 0x00:
			nZero++
		default:
			nOther++
		}
	}

	fmt.Printf("=== DNA TYPES ===\n")
	fmt.Printf("  ATOM  (0x41): %8d\n", nAtom)
	fmt.Printf("  SDF   (0x42): %8d\n", nSDF)
	fmt.Printf("  TEXT  (0x06): %8d\n", nText)
	fmt.Printf("  ZERO  (0x00): %8d\n", nZero)
	fmt.Printf("  OTHER:        %8d\n", nOther)
	fmt.Printf("  EMPTY:        %8d\n\n", emptyDNA)

	fmt.Printf("=== ISSUES ===\n")
	fmt.Printf("  bad DNA:    %6d\n", badDNA)
	fmt.Printf("  SDF noCaps: %6d\n", noCaps)
	fmt.Printf("  bad coords: %6d\n", badCoord)
	fmt.Printf("  dup ISL:    %6d\n\n", dupCount)

	if len(sampleBad) > 0 {
		fmt.Printf("=== SAMPLES ===\n")
		for _, s := range sampleBad {
			fmt.Println(" ", s)
		}
		fmt.Println()
	}

	fmt.Printf("=== SDF CAPSULE DISTRIBUTION ===\n")
	for k := 0; k <= 7; k++ {
		if n := capsuleCounts[k]; n > 0 {
			fmt.Printf("  %d caps: %d\n", k, n)
		}
	}
	fmt.Println()

	fmt.Printf("=== EDGE TYPES ===\n")
	badEdge, dupEdge := 0, 0
	etypes := map[uint8]int{}
	seen := map[[2]uint64]bool{}
	for _, e := range rr.Edges {
		if e.Type == 0 || e.Type > 0x0F {
			badEdge++
		}
		etypes[e.Type]++
		key := [2]uint64{e.Src, e.Dst}
		if seen[key] {
			dupEdge++
		}
		seen[key] = true
	}
	fmt.Printf("  bad type:  %d | dup: %d\n", badEdge, dupEdge)
	fmt.Printf("  dist: ")
	for t := uint8(1); t <= 0x0F; t++ {
		if n := etypes[t]; n > 0 {
			fmt.Printf("0x%02X=%d ", t, n)
		}
	}
	fmt.Println()

	issues := badDNA + noCaps + badCoord + dupCount + nZero
	fmt.Printf("=== VERDICT ===\n")
	fmt.Printf("  SDF coverage: %d / %d (%.1f%%)\n", nSDF, rr.NodeCount, float64(nSDF)*100/float64(rr.NodeCount))
	if issues == 0 && len(rr.Corrupt) == 0 && badEdge == 0 {
		fmt.Println("  ✅ CLEAN — không có vấn đề")
	} else {
		fmt.Printf("  ⚠️  %d issue(s) cần xem xét\n", issues+badEdge+len(rr.Corrupt))
	}
}
