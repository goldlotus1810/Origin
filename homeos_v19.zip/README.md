# HomeOS · Origin

> `olang run homeos.olang` — Toan bo he thong chay tu 1 file duy nhat.

---

## Muc tieu

```
1 file  homeos.olang  chua tat ca:
  - Tri thuc (L0-L6 ontology)
  - Logic    (L7 intents, rules, agent DNA)
  - UI       (L5 web app)
  - Skills   (L7 skill nodes)
  - Ky uc    (L7 QR/DN nodes)

Go = bootstrap engine.  Khong phai logic.
```

---

## Cau truc thu muc

```
Origin/
|
+-- homeos.olang          FILE DUY NHAT — tri thuc + UI + agents + skills
|
+-- cmd/
|   +-- homeos/main.go    HTTP/WS server (bootstrap)
|   +-- olang/main.go     CLI: run · info · dump · get · walk · verify
|
+-- internal/
|   +-- isl/              ISL 8-byte address · codec · message bus
|   +-- silk/             SilkGraph — doc homeos.olang → in-memory tree
|   +-- olang/            Binary format parser · executor (DNA stack machine)
|   +-- agents/           Agent + Skill runtime
|   |   +-- agents.go     Agent · Skill interface · AgentRegistry
|   |   +-- composed_skill.go  SkillLearner · SkillProposal
|   +-- ws/               HTTP/WS layer (bootstrap)
|   |   +-- brain.go      NLP · intent detect · respond
|   |   +-- api.go        REST endpoints
|   |   +-- ws.go         SSE · World · dispatchActuator
|   |   +-- state.go      DN/QR memory (se merge vao .olang)
|   |   +-- append_olang.go  OlangAppendNode — ghi node vao .olang
|   |   +-- ui_loader.go  Serve L5 UI nodes
|   |   +-- ownership.go  ED25519 challenge-response
|   |   +-- ownership_api.go  /api/owner/* endpoints
|   |   +-- intent_matcher.go  Match intent tu L7 nodes
|   |   +-- qt_reader.go  Doc 7 quy tac tu L7 nodes
|   |   +-- node_lookup.go    Tim node theo ten/ISL
|   |   +-- olang_graph.go    /api/tree, /api/edges
|   +-- nca/              SecurityGate (3 rules bat bien)
|   +-- gene/             SDF universe · Vec3 · terrain
|
+-- web/static/           Fallback UI (neu L5 chua co)
|   +-- index.html
|
+-- TRUTH.md              LA BAN — doc truoc moi session
+-- docs/
    +-- MASTER.md         Kien truc toan he thong
    +-- OLANG.md          Binary format spec
```

---

## homeos.olang — layers

```
L0  Primitives    73 nodes  [QR]  73 opcodes bat bien
L1  UTF-32       121 nodes  [QR]  Co diem Unicode co ban
L2  Nature         5 nodes  [QR]  Nuoc / Lua / Dat / Gio / Anh sang
L3  Life               ---  [QR]  Sinh vat (pending)
L4  Objects        4 nodes  [QR]  Den / Cua / Xe / Thiet bi
L5  UI             6 nodes  [QR]  Web app (zlib)
L6  Perception         ---  [QR]  Cam nhan (pending)
L7  Programs      30+ nodes [QR+DN]
                              INTENT_* (9 intents)
                              QT1..QT7 (7 quy tac)
                              SKILL_*  (skills la nodes)
                              AGENT_*  (agent DNA)
                              OWNER_PUBKEY
                              + Ky uc hoc duoc
```

---

## Skills la Nodes (QT4)

"Agent == tap hop Skill cua no"

Moi Skill la 1 node L7:

```
SKILL_ACTUATOR_LIGHT    device=light  io=gpio
SKILL_HOME_CHIEF_ROUTE  tier=1  route=location→worker
SKILL_BROADCAST         scope=all
SKILL_SECURITY_GATE     rules=3  immutable=true
SKILL_SHORT_TERM_MEM    capacity=512  decay=0.1
SKILL_LONG_TERM_MEM     store=olang  verify=ed25519
SKILL_CLUSTER           window=100  threshold=0.7
SKILL_DREAM             idle=5min  verify=dn
```

Agent doc danh sach Skill tu olang khi khoi dong:

```
AGENT_HOME_CHIEF  →  [SKILL_HOME_CHIEF_ROUTE]
AGENT_AAM         →  [SKILL_BROADCAST, SKILL_SECURITY_GATE]
light_living      →  [SKILL_ACTUATOR_LIGHT · location=living_room]
light_bed         →  [SKILL_ACTUATOR_LIGHT · location=bedroom]
```

---

## Luong giao tiep (bat bien)

```
Nguoi dung
    |
    v  /api/chat
AAM  [Broadcast · SecurityGate]
    |
    |  ISL · MsgActuatorCmd
    v
home_chief  [HomeChiefRoute]              Tier 1
    |
    |  ISL · MsgActivate / MsgDeactivate
    v
light_living / light_bed  [ActuatorLight] Tier 2

Quy tac:
  OK  AAM  <->  Chief
  OK  Chief <-> Chief  (ngang hang)
  OK  Chief <-> Worker cua minh
  NO  AAM  <->  Worker  (vi pham kien truc)
  NO  Worker   <->  Worker
```

---

## Chay nhanh

```bash
go build -o homeos ./cmd/homeos/ && ./homeos
# http://localhost:8080

go build -o olang ./cmd/olang/
./olang verify homeos.olang   # kiem tra integrity
./olang dump   homeos.olang   # xem tat ca nodes
./olang info   homeos.olang   # tong quan
```

---

## SecurityGate (bat bien)

```
Rule 1: Khong hai con nguoi       (khong ai ghi de)
Rule 2: Khong vong lap vo han     (fuel=10000)
Rule 3: Khong xoa QR nodes        (append-only)
```

---

## Ownership — ED25519

```
Ai giu private key = chu so huu Olang.

First boot → sinh keypair → OWNER_PUBKEY vao L7 → download key
Login      → challenge (32B nonce) → sign → JWT 24h
```

---

## Roadmap

```
XONG:
  [x] homeos.olang binary format + CLI
  [x] L0 executor (stack machine)
  [x] L5 UI nodes (web app trong olang)
  [x] L7 intent nodes · QT nodes
  [x] ED25519 ownership
  [x] Agent + Skill runtime + AgentRegistry
  [x] AAM → Chief → Worker (kien truc dung)
  [x] IntentActuator (tat/bat den)

DANG LAM:
  [ ] Skill la node L7 (hien chi la Go struct)
  [ ] Agent doc skill list tu olang

SAU:
  [ ] skills/learning: cluster + dream
  [ ] L3 Life · L6 Perception nodes
  [ ] olang run = full runtime (khong can Go binary)
```

---

*Module: github.com/goldlotus1810/HomeOS*
*La ban chinh xac: TRUTH.md*
