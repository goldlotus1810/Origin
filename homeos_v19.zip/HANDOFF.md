# HANDOFF.md — Bàn giao cho chat mới
# Đọc file này ĐẦU TIÊN trong mọi session mới
# Append-only · Cập nhật: 2026-03-10 (session 146g)

---

## 1. MỤC TIÊU DUY NHẤT

```
$ olang run homeos.olang
→ Toàn bộ HomeOS chạy từ 1 file duy nhất
→ Không cần Go, JSON, HTML riêng lẻ
→ Không cần install thêm gì
```

---

## 2. TRIẾT LÝ CỐT LÕI (không được vi phạm)

```
○(x) == x        identity
○(∅) == ○        tự tạo sinh
○ ∘ ○ == ○       idempotent
mọi f == ○[f]    mọi thứ là instance của ○

9 Quy Tắc Bất Biến:
  QT1  ○ Là nguồn gốc — mọi thứ là instance của ○
  QT2  ∞ là sai — ∞-1 mới đúng (hữu hạn nhưng rất lớn)
  QT3  Vật lý là sự thật (+/- là giả thuyết, == là sự thật)
  QT4  Bản chất quyết định tồn tại (Agent = tập hợp Skill)
  QT5  Bản chất quyết định vị trí (AAM→Chief→Worker)
  QT6  Hai chiều tồn tại (SDF = hữu hình, ISL = vô hình)
  QT7  ĐN → QR (vòng đời tri thức: học → chứng minh → bất biến)
  QT8  Lịch sử bất biến (append-only, không DELETE, không OVERWRITE)
  QT9  Không thông tin sai lệch
```

---

## 3. TRẠNG THÁI CODE (session 146g)

```
Repo:    github.com/goldlotus1810/Origin
Module:  github.com/goldlotus1810/HomeOS
Go:      1.22
BUILD:   OK
TESTS:   9/9 PASS

homeos.olang: 841 KB · 4,716 nodes · 1,412 edges
  L0 Primitives:  92 nodes  [QR]
  L1 UTF32:     1280 nodes  [QR]
  L2 Nature:      45 nodes  [QR]
  L3 Life:      3062 nodes  [QR]
  L4 Objects:     28 nodes  [QR]
  L5 Programming:159 nodes  [QR]
  L6 Perception:  49 nodes  [QR]
  L7 Programs:    93 nodes  [QR]
```

---

## 4. NGÔN NGỮ — OLANG

### Node format (BẤT BIẾN)

```
ND(2) + layer(1) + ISL(8) + cp(4,BE) + dnaLen(4,BE) + nameLen(1) + dna + name
= 20 bytes header + variable payload
DNA TRƯỚC name (rule #18)
```

### Edge format

```
srcISL(8) + dstISL(8) + type(1) = 17 bytes/edge
edge_start = len(file) - nedges*17
Header raw[16:20] = nedges (Big Endian uint32)
```

### ISL Address — 64-bit

```
[layer:1B][group:1B][type:1B][id:1B][attr:4B]
HAa1 = Nhà > Ánh sáng > Đèn > phòng khách
```

### vSDF Rule (BẤT BIẾN)

```
KHÔNG raymarching — evaluate SDF primitives trực tiếp
Renderer KHÔNG march rays — chỉ evaluate SDF tại điểm
```

---

## 5. KIẾN TRÚC AGENT/SKILL

### Phân cấp giao tiếp (BẤT BIẾN)

```
NGƯỜI DÙNG
    ↓
AAM  [Decide4D · Broadcast · 🛡SecurityGate · AAMRouter · HonestySkill]
    ↓ ISL
Chiefs  [route · aggregate]               TẦNG 1
    ↓ ISL
Workers [Actuator + TrafficMonitor + FirmwareWatch]  TẦNG 2 · SILENT BY DEFAULT

✅ AAM ↔ Chief
✅ Chief ↔ Chief (ngang hàng)
✅ Chief ↔ Worker của mình
❌ AAM ↔ Worker trực tiếp
❌ Worker A ↔ Worker B
```

### Worker = HomeOS tại thiết bị (BẤT BIẾN — TRUTH.md)

```
SAI:  Worker → gửi lệnh HTTP → thiết bị
ĐÚNG: Worker = HomeOS agent bao bọc thiết bị

Worker làm 3 việc:
  ① GIÁM SÁT  — TrafficMonitorSkill: chặn traffic ra ngoài LAN
  ② KIỂM SOÁT — FirmwareWatchSkill: phát hiện hành vi bất thường
  ③ THAY THẾ  — nếu firmware trái phép → cô lập → báo Chief

Worker structure:
  Worker = ActuatorSkill + TrafficMonitorSkill + FirmwareWatchSkill

DeviceSender = thin adapter (như USB driver) — KHÔNG phải skill cốt lõi
```

### SecurityGate Rules (BẤT BIẾN)

```
Rule 1: Không hại con người — bất biến tuyệt đối
Rule 2: Không vòng lặp vô hạn
Rule 3: Không xóa dữ liệu bất biến
Không ai ghi đè Rule 1 — kể cả LeoAI.
```

---

## 6. LUỒNG PIPELINE ĐẦY ĐỦ

### Điều khiển thiết bị

```
HTTP "tắt đèn"
    ↓ brain.Respond() → IntentActuator
    ↓ dispatchActuator → aamInbox
    ↓ AAM.SecurityGate.Check()        ← Rule 1
    ↓ AAM.AAMRouterSkill → home_chief
    ↓ HomeChiefSkill → light_living
    ↓ ActuatorLightSkill.Execute()
    ↓ DeviceSender.Send(DeviceCmd)
    ↓ PUT /api/{token}/lights/1/state {on:false}
    ↓ Philips Hue Bridge → đèn tắt thật
```

### Onboard thiết bị mới

```
RealLANScanner (ARP + mDNS) → DiscoveredDevice
    ↓ OnboardSkill → AgentCreateCmd{Protocol, Vendor}
    ↓ HomeChief → ExportWorkerSkill
    ↓ Exporter.Export(SpecForLight(...))
    ↓ homeos.olang (841KB) → worker_light_living.olang (20KB)
    ↓ HTTP PUT → device:7777/deploy → WorkerDeployServer
    ↓ $ olang run worker_light_living.olang
    ↓ Worker online: Actuator + TrafficMonitor + FirmwareWatch
```

### Học tập (NCA)

```
INPUT → ĐN (ShortTermMemory)
    ↓ DreamSkill (khi inbox idle >5 phút)
    ↓ high-conf ≥0.75 → MsgPropose → AAM
    ↓ ProposalHandlerSkill → QR (SilkTree, bất biến)
    ↓ Hebbian: co-activation → BoostEdge → WeightStore persist
```

---

## 7. CẤU TRÚC THƯ MỤC

```
HomeOS/
├── HANDOFF.md          ← file này — đọc đầu tiên
├── TRUTH.md            ← source of truth
├── SESSIONS.md         ← log chi tiết mọi session
├── MASTER.md           ← tổng quan hệ thống
├── homeos.olang        ← 841KB · 4716 nodes · 1412 edges
│
├── cmd/olang/
│   ├── main.go         ← CLI: run/info/dump/get/walk/verify
│   └── runtime.go      ← wire 45+ skills vào agents
│
└── internal/
    ├── isl/            ✅ address · codec · dictionary
    ├── utf32/          ✅ loader · groups · mapper
    ├── olang/
    │   ├── file.go     ✅ OlangFile · AppendNode · SaveToPath · LoadFile
    │   ├── reader.go   ✅ ParseBytes · ReadFrom · ReadFile (s143)
    │   ├── export.go   ✅ Exporter · WorkerSpec · SpecForLight/HVAC/Camera/Lock (s146g)
    │   ├── executor.go
    │   └── runtime.go
    ├── silk/
    │   ├── silk.go     ✅ SilkGraph · WalkWeightedMulti(OpMember,OpSimilar) (s144)
    │   ├── weights.go  ✅ EdgeWeightStore · persist · decay
    │   └── olang_loader.go ✅ LoadFromOlang(fixed s146c) · LoadAllFromOlang
    ├── memory/         ✅ ShortTerm(ĐN) · LongTerm(QR→SilkTree)
    ├── nca/            ✅ SecurityGate · CheckActuatorSafety
    ├── agents/
    │   ├── agent.go    ✅ Agent · Skill · ExecContext · Registry
    │   ├── skill_aam_router.go          ✅
    │   ├── skill_proposal_handler.go    ✅ NodeHash + Cluster + Hebbian
    │   ├── skill_dream.go               ✅ thật sự làm việc
    │   ├── skill_hebbian.go             ✅ + WeightStore + decay
    │   ├── skill_cluster.go             ✅ persist → .clusters.olang
    │   ├── honesty_skill.go             ✅ wire AAM (s144)
    │   ├── skill_log.go                 ✅ AuditLog persist JSONL (s145)
    │   ├── lan_scanner.go               ✅ RealLANScanner ARP+mDNS (s146d)
    │   ├── skill_device_send.go         ✅ DeviceSender 6 protocols (s146e)
    │   ├── skill_actuator_light.go      ✅ + sender + WithDevice()
    │   ├── skill_traffic_monitor.go     ✅ TrafficMonitorSkill (s146f)
    │   ├── skill_firmware_watch.go      ✅ FirmwareWatchSkill (s146f)
    │   ├── skill_export_worker.go       ✅ ExportWorkerSkill + WorkerDeployServer (s146g)
    │   ├── book_reader.go               ✅ BookMemory (s146b)
    │   ├── bookshelf.go                 ✅ BookShelf + AllTitles()
    │   └── onboard.go                   ✅ + Protocol/Vendor fields
    └── ws/
        ├── brain.go        ✅ 1458 dòng + bookShelf field
        ├── brain_intent.go ✅ dispatchIntent switch (s146)
        ├── brain_book.go   ✅ loadBookFile + respondAboutBook (s146b)
        ├── brain_query.go  1731 dòng (cần tách tiếp)
        └── score_search.go ✅ exact×4 / prefix×2 / contains×1.5 (s144)
```

---

## 8. THAY ĐỔI TỪ SESSION 142 → 146g

### Session 143 — OlangFile.ReadFrom()
```
+ internal/olang/reader.go: ParseBytes() + ReadFrom() + ReadFile()
+ LoadFile() thật sự populate Layers + EdgeTable
+ LoadAllFromOlang() dùng canonical parser (không duplicate logic)
Tests: +3
```

### Session 144 — WalkWeightedMulti + ScoreSearch + HonestySkill
```
+ silk.go: WalkWeightedMulti(from, ops...) — traverse OpMember+OpSimilar
+ SilkWalkSkill: cập nhật dùng WalkWeightedMulti
+ score_search.go: exact×4.0 / prefix×2.0 / contains×1.5
+ honesty_skill.go: CanHandle() + Execute() + wire AAM
```

### Session 145 — AuditLog persist
```
+ skill_log.go: AuditLog.WithPath() — append-only JSONL (QT8)
+ AuditLog.LoadFromDisk() — replay khi restart
+ LoggerSkill.WithAuditPath(path)
+ runtime.go: home_chief → homeos.olang.audit.log
```

### Session 146 — brain.go tách
```
+ brain_intent.go: dispatchIntent(), handleLearnIntent(), handleConfirmIntent()
  brain.go: 1754 → 1458 dòng
```

### Session 146b — Brain.LoadBook()
```
+ brain_book.go: loadBookFile() + respondAboutBook()
+ bookshelf.go: AllTitles()
+ IntentReadBook: "đọc sách /path/book.txt"
Pipeline: text → LearnedWord[] → FlushToSilk → SilkGraph
```

### Session 146c — Fix fake nodes
```
FIX: LoadFromOlang scan đến edgeStart thay vì len(raw)
     → loại bỏ 86 fake nodes parse từ edge bytes
Trước: 4802 nodes → Sau: 4716 nodes (ĐÚNG)
```

### Session 146d — RealLANScanner
```
+ lan_scanner.go: RealLANScanner
  ARPSweep: TCP /24 → ARP cache
  ReadARPTable: /proc/net/arp → (IP, MAC)
  MDNSQuery: 224.0.0.251:5353 → 7 service types
  classifyDevice: 18 MAC OUI vendors + mDNS service
+ MockLANScanner + DefaultMockDevices
runtime.go: NewOnboardSkill(NewRealLANScanner())
Tests: 7
```

### Session 146e — DeviceSender (Chief → thiết bị vật lý)
```
+ skill_device_send.go: DeviceSender 6 protocols
  ProtoHueAPI  → PUT /api/{token}/lights/{id}/state (Philips Hue)
  ProtoMiio    → UDP 54321 (Xiaomi LAN)
  ProtoTasmota → GET /cm?cmnd=Dimmer%20{level}
  ProtoShelly  → GET /light/0?turn={on/off}
  ProtoHTTP    → PUT /api/light JSON
  ProtoStub    → log only
  detectProtocol(vendor): auto-detect
  rgbToXY(rgb): CIE 1931 XY cho Hue color
+ ActuatorLightSkill: + sender + WithDevice()
+ AgentCreateCmd: + Protocol + Vendor
Tests: 6
```

### Session 146f — TrafficMonitorSkill + FirmwareWatchSkill
```
+ skill_traffic_monitor.go: TrafficMonitorSkill
  Default deny all, allow LAN/DNS/NTP
  WithLAN(cidr): set subnet + rebuild rules
  MsgApproved: AAM thêm rule mới (Philips OTA etc.)
  IsolationMode khi critical violation
  MsgEmergency → Chief

+ skill_firmware_watch.go: FirmwareWatchSkill
  Learning phase → baseline
  Detect: TrafficSpike/UnknownRemote/FirmwareChanged(critical)/HeartbeatLost
  QuarantineMode severity=3
  MsgApproved: AAM lift quarantine

runtime.go: light_living + light_bed + hvac_living
  mỗi Worker = Actuator + TrafficMonitor + FirmwareWatch
Tests: 15
```

### Session 146g — olang export
```
+ internal/olang/export.go:
  WorkerSpec{WorkerID, DeviceType, Layers, ISLAddrs, Codepoints, NodeNames}
  Exporter.Export(spec, dir) → ExportResult
  selectNodes(): L0 always + filter by layer/ISL/CP/name
  resolveEdges(): chỉ edges giữa selected nodes
  writeWorkerOlang(): binary OLNG format
  Predefined: SpecForLight/HVAC/Camera/Lock

+ internal/agents/skill_export_worker.go:
  ExportWorkerSkill: CanHandle(MsgActuatorCmd{spawn_worker})
  Lazy init Exporter
  shipToDevice(): HTTP PUT → device:7777/deploy
  WorkerDeployServer: nhận file, validate OLNG magic, callback

runtime.go: HomeChief + ExportWorkerSkill

Kết quả export:
  light worker:  211 nodes · 20KB  (vs source 841KB → nhỏ hơn 40×)
  hvac worker:   211 nodes · 20KB
  camera worker: nhiều hơn (có L3+L6)
Tests: 7
```

---

## 9. BACKLOG (theo thứ tự ưu tiên)

### 🔴 Tiếp theo

```
① brain_query.go tách tiếp (1731 dòng)
   Tách: IntentQuery group / IntentLearn group / IntentMeta group

② AuditLog: thêm AAM + leoai logger
   Hiện tại chỉ home_chief có audit log
   Cần: AAM + LeoAI cũng audit

③ TrafficMonitorSkill: test trên LAN thật
   Hiện tại scanDeviceConnections() trả về empty (sandbox)
   Cần: parseProcNetFile("/proc/net/tcp") thật

④ FirmwareWatchSkill: collectSnapshot() thật
   Hiện tại placeholder — chưa đo BytesSent/UniqueIPs
   Cần: đọc từ /proc/net/dev hoặc thiết bị API
```

### 🟠 Sau đó

```
⑤ WorkerDeployServer integration test
   Simulate Chief → ship → WorkerDeployServer → confirm

⑥ OlangNode unification (2 định nghĩa)
   olang/file.go OlangNode vs silk/silk.go OlangNode
   Breaking change — cần migration

⑦ SilkEdge.Weight trong binary format
   Hiện tại: weights file riêng (.weights)
   Tương lai: embed trong edge record (9B → 13B)

⑧ LANScanner: test trên LAN thật (cần thiết bị vật lý)
```

### 🟡 Dài hạn

```
⑨  MILESTONE 5000 nodes L3
⑩  L5 Programming: Go AST → ISL
⑪  L6 Perception: Vision agent thật
⑫  olang export: trích xuất subtree → light.olang (ship đến thiết bị)
    ✅ DONE s146g — cơ bản hoạt động
    Cần: test deployment thật trên ARM device
⑬  MILESTONE 5: browser render world từ .olang
```

---

## 10. QUY TẮC LÀM VIỆC (26 quy tắc)

```
1.  Mỗi session: đọc TRUTH.md TRƯỚC
2.  Không thêm file mới nếu chưa xóa file thừa
3.  Không thêm Go code cho logic → phải vào .olang
4.  Test bằng: go test ./...
5.  Kiến trúc agent: User → AAM → Chief → Worker (lệnh xuống)
6.  Luồng bottom-up: Worker → Chief → AAM (báo cáo lên)
7.  Node format: DNA trước name, dnaLen Big-Endian
8.  vSDF rule: KHÔNG raymarching — evaluate SDF trực tiếp
9.  Edge rule: 1 thiết bị = 1 Agent = 1 Skill. Không raw media.
10. Agent rule: Agent KHÔNG tự nhân bản. Tầng trên tạo tầng dưới.
11. Knowledge rule: LeoAI là nguồn sự thật duy nhất.
12. Log rule: semantic→QR · truy vết→Ledger · debug→RAM
13. Auth rule: Không quyền mặc định. Token gắn SessionID.
14. Skill rule: Primitive=1 việc. Composed=[]Primitive.
15. Symbol rule: Unicode name mô tả chức năng.
16. Anchor rule: Symbol mới → FindCluster → SuggestCluster.
17. Header fix: script seed → Python đếm ND thực tế → fix header.
18. Encode rule: DNA TRƯỚC name. Parser skip corrupt (dl>4096).
19. Edge insert: insert VÀO TRƯỚC edge section cũ.
20. adjCache: build() lưu nl.raw=raw. walkSilk dùng len(raw)-nedges*17.
21. ISL rule: ISL trong file KHÔNG phải sha256(name)[:8].
22. Single-script: nodes + edges = 1 script duy nhất.
23. Duplicate rule: kiểm tra label trùng trước khi thêm node.
24. ParseDerivative: token scoring, không hardcode string patterns.
25. buildDynamic: đọc layer byte trực tiếp, KHÔNG hardcode prefix map.
26. Worker rule: Worker = HomeOS tại thiết bị. Firmware = lớp vật lý bên dưới.
    DeviceSender = thin adapter tạm thời, không phải skill cốt lõi.
```

---

## 11. LỊCH SỬ MILESTONE

```
2026-03-08: olang run homeos.olang — ./olang binary duy nhất
2026-03-09: MILESTONE 3000 nodes · 22 intents
2026-03-09: SilkWalk depth 4 live (session 132)
2026-03-09: MILESTONE 6000 nodes (session 131)
2026-03-10: session 135b — cleanup 599 orphans + buildDynamic fix
2026-03-10: session 136 — FULL AUDIT: 6 vấn đề structural
2026-03-10: sessions 137-142 — fix tất cả 6 vấn đề:
  ✅ 40 skills wire vào đúng agents
  ✅ Pipeline AAM→Chief→Worker (QT5)
  ✅ NCA QT7: proposeCycle qua AAM
  ✅ DreamSkill thật sự làm việc
  ✅ Hebbian learning hoàn chỉnh + persist + decay + weighted walk
  ✅ SecurityGate Rule 1 thật (CheckActuatorSafety)
  ✅ ClusterSkill persist → .clusters.olang
2026-03-10: sessions 143-146g — từ ReadFrom → Worker deployment:
  ✅ OlangFile.ReadFrom() — round-trip đầy đủ
  ✅ WalkWeightedMulti — Hebbian edges được traverse
  ✅ HonestySkill — wire AAM
  ✅ AuditLog persist — JSONL append-only (QT8)
  ✅ brain.go tách IntentHandler
  ✅ Brain.LoadBook() — học từ sách
  ✅ Fix fake nodes (4802 → 4716 nodes ĐÚNG)
  ✅ RealLANScanner — ARP + mDNS thật
  ✅ DeviceSender — 6 protocols (Hue/Miio/Tasmota/Shelly/HTTP/Stub)
  ✅ TrafficMonitorSkill — giám sát traffic thiết bị
  ✅ FirmwareWatchSkill — phát hiện hành vi bất thường
  ✅ olang export — Chief clone worker.olang (20KB) → ship → thiết bị
```

---

## 12. CÁCH ĐỌC CODE ĐỂ TIẾP TỤC

```bash
# 1. Confirm trạng thái
cd /path/to/Origin
go test ./...          # phải 9/9 PASS
go build ./...         # phải OK

# 2. Đọc TRUTH.md
cat TRUTH.md

# 3. Làm tiếp theo:
#    → brain_query.go tách (1731 dòng)
#    → AuditLog thêm AAM + leoai
#    → test TrafficMonitor + FirmwareWatch trên Linux thật
```

---

*Append-only. Chỉ được thêm vào, không được xóa.*
*Cập nhật: 2026-03-10 — session 146g*

---

## Section 23 — AUDIT & FIX SESSION 146g (2026-03-10)

> Đây là kết quả audit đầy đủ và các fix đã thực hiện.
> Tất cả fix đã pass `go test ./...` + `go test -race ./...` + `go vet ./...`.

---

### 23.1 — homeos.olang Binary Fixes

**5 vấn đề phát hiện và đã fix:**

```
🔴 FIX 1 — Layer index L3 CORRUPT
   Entry[3].offset = 0xfb0124d1 (vượt file size 861266)
   Entry[3].size   = 2,241,074,787 bytes
   → CLI chỉ đọc được L0+L1+L2 = 1,414 nodes (bỏ sót 3,399 nodes)
   FIX: offset=0x00012458, size=762422, nnodes=3062

🔴 FIX 2 — Header nnodes = 101,376 (SAI)
   Đúng phải là 4,810
   FIX: Python đếm ND thực tế → ghi raw[9:13]

🟠 FIX 3 — SHA256 MISMATCH
   SHA256 field raw[28:60] không khớp nội dung
   FIX: hash raw[280:] (sau header+layer_index) → ghi vào raw[28:60]
   Result: a27a2da7ac58eede684da5d548c3d4522a16dadb834d6fb96de8c34e6706a026

🟡 FIX 4 — Layer index L7 nnodes sai sau promote
   FIX: cập nhật Entry[7].nnodes += 2 sau khi promote QT8+QT9

🟡 FIX 5 — QT8_DEF, QT9_DEF nằm ở L8 thay vì L7
   QT8 = LỊCH SỬ BẤT BIẾN, QT9 = KHÔNG THÔNG TIN SAI LỆCH
   FIX: thay raw byte L8→L7 tại vị trí offset của từng node
```

**Trạng thái sau fix:**
```
homeos.olang — SHA256 ✅ verified
Nodes: 4,810 (header đúng)
L3 Life: 3,062 nodes (trước: CLI bỏ sót hoàn toàn)
L7 Programs: 116 nodes (tăng 2: QT8_DEF + QT9_DEF)
```

---

### 23.2 — CLI Parser Fixes (cmd/olang/main.go)

**3 vấn đề phát hiện:**

```
🔴 edgeStart tính từ layer index offset+size (SAI)
   Layer windows chồng nhau → edgeStart = L7.end = 0x2a8d5
   Nhưng edges thật ở 0xcc68e
   → CLI đọc 40,410 "edges" (thực ra là node data bị hiểu sai)
   FIX: edgeStart = len(file) - nedges*17 (từ header raw[16:20])

🔴 Node parse theo per-layer windows (SAI)
   Windows chồng nhau → nodes bị đọc trùng hoặc bỏ sót
   CLI trước: 1,414 nodes (chỉ L0+L1+L2)
   CLI sau: 4,776 nodes (linear scan + dedup ISL)
   FIX: thay bằng linear scan toàn file [280 → edgeStart]
        + seen map[uint64]bool để dedup ISL

🟡 Không validate layer > 8 trong parser
   FIX: thêm `if lid > 8 { continue }` trong scan loop
```

**Trạng thái sau fix:**
```
CLI: Nodes=4,776  Edges=1,412  SHA256 ✅ verified
```

*Lưu ý: Nodes=4,776 < 4,810 do dedup ISL collision (34 nodes có ISL trùng).
Đây là vấn đề nhỏ cần giải quyết khi có thời gian — không ảnh hưởng runtime.*

---

### 23.3 — Race Conditions (go test -race)

**4 race conditions phát hiện và đã fix:**

```
🔴 RACE 1 — percept_layer.go: tickCount
   Stats() đọc tickCount trong khi Tick() write từ goroutine khác
   FIX: tickCount → sync/atomic.Uint64
        Stats() dùng tickCount.Load()
        Tick() dùng tickCount.Add(1)

🔴 RACE 2 — skill_spatial_learn.go: received, committed
   Execute() write trong khi Stats() read từ goroutine khác
   FIX: received, committed → sync/atomic.Int64

🔴 RACE 3 — skill_spatial_query.go: hits, misses
   Execute() write trong khi Stats() read từ goroutine khác
   FIX: hits, misses → sync/atomic.Int64

🔴 RACE 4 — memory/memory.go: LongTerm.Query()
   SpatialQuerySkill.Execute() gọi qr.Query() KHÔNG có lock
   SpatialLearnSkill.Execute() write qua LongTerm.Reinforce() (có lock)
   → Read/Write race trên e.node.Weight
   FIX: LongTerm.Query() thêm lt.mu.RLock(); defer lt.mu.RUnlock()
```

---

### 23.4 — go vet Fix

```
🟠 lan_scanner.go:406 — self-assignment
   dev.IP = dev.IP  // comment nói "hostname là extra"
   FIX: xóa dòng đó, giữ comment
```

---

### 23.5 — Trạng Thái Hiện Tại (sau tất cả fixes)

```
BUILD:          OK
go vet:         CLEAN (0 warnings)
go test ./...:  9/9 PASS
go test -race:  0 DATA RACE

homeos.olang:
  SHA256: ✅ verified
  Nodes:  4,810 (header) / 4,776 (CLI scan)
  Edges:  1,412
  Size:   861,266 bytes

Layer phân bố (thực tế):
  L0  Primitives:    92  nodes  [bất biến]
  L1  UTF32:       1280  nodes  [bất biến]
  L2  Nature:        45  nodes  [bất biến]
  L3  Life:        3062  nodes  [tri thức đa lĩnh vực]
  L4  Objects:       28  nodes  [thiết bị]
  L5  Programming:  159  nodes  [Go/ISL/Silk]
  L6  Perception:    49  nodes  [vision/audio]
  L7  Programs:     116  nodes  [agents, skills, QT rules]
```

---

### 23.6 — Quy Tắc Mới (thêm vào 26 quy tắc cũ)

```
27. edgeStart: LUÔN dùng len(file) - nedges*17. KHÔNG dùng layer index offset+size.
28. CLI parse: linear scan [280..edgeStart] + dedup ISL. KHÔNG per-layer windows.
29. Counters concurrent: dùng sync/atomic. KHÔNG dùng int cho fields đọc/ghi từ nhiều goroutine.
30. LongTerm.Query(): LUÔN có mutex lock (RLock). Không có read-without-lock.
```

---

### 23.7 — Backlog Cập Nhật

**Đã xong trong session này:**
```
✅ homeos.olang layer index L3 corrupt → fixed
✅ homeos.olang header nnodes sai → fixed
✅ homeos.olang SHA256 mismatch → fixed
✅ QT8_DEF, QT9_DEF promote L8→L7 → fixed
✅ CLI edgeStart sai → fixed (edges: 40410→1412)
✅ CLI per-layer parser → linear scan (nodes: 1414→4776)
✅ 4 race conditions → fixed với sync/atomic + mutex
✅ go vet self-assignment → fixed
```

**Còn lại (ưu tiên):**
```
🔴 ① brain_query.go tách (còn 1,731 dòng)
🔴 ② AuditLog persist: thêm AAM + LeoAI (hiện chỉ home_chief)
🔴 ③ TrafficMonitorSkill: test thật (/proc/net/tcp)
🔴 ④ FirmwareWatchSkill: collectSnapshot() thật (/proc/net/dev)
🟠 ⑤ WorkerDeployServer integration test
🟠 ⑥ OlangNode unification (olang/file.go vs silk/silk.go — 2 định nghĩa)
🟠 ⑦ SilkEdge.Weight embed trong binary (9B → 13B)
🟠 ⑧ ISL collision: 34 nodes có ISL trùng → cần audit
🟡 ⑨ MILESTONE 5000 nodes L3
🟡 ⑩ L5 Go AST → ISL
🟡 ⑪ Test deployment thật trên ARM device
```

---

*Append-only — thêm vào, không xóa*
*Cập nhật: 2026-03-10 — session 146g audit+fix*

---

## Section 24 — VISION & BIG IDEAS (từ docs gốc)

> Đây là "tại sao" và "sẽ đi đâu" của dự án.
> Không bị invalidate bởi bug fixes hay refactors — đây là hướng đi dài hạn.

---

### 24.1 — Câu hỏi trung tâm (không thay đổi)

```
Nếu vũ trụ không lưu hình dạng mà lưu công thức —
thì bộ nhớ, ngôn ngữ, và tri thức phải được lưu như thế nào?
```

HomeOS không phải home automation. Không phải LLM. Là **hệ điều hành tư duy**
được xây từ vật lý học đầu tiên — tự định nghĩa quy tắc vũ trụ, rồi từ đó
sinh ra ngôn ngữ, bộ nhớ, học tập, hình học, Agent.

---

### 24.2 — Ý tưởng lớn chưa implement (priority order)

```
🔴 A — Olang Compiler thật sự
   L5 nodes chứa đủ semantics Go/Rust/C/WASM/x86/ARM
   → olang compile --target=go → emit Go source
   → Không cần GCC, LLVM, Babel, rustc
   Tại sao: "Học ISL 1 lần = viết mọi ngôn ngữ"

🔴 B — Agent Clone = .olang file nhỏ
   Mỗi thiết bị nhận filter(homeos.olang, DeviceProfile)
   light_01.olang = 12KB (thay vì 861KB)
   → Ship lên chip 256KB RAM
   Cần: OlangFile.Filter(layers) + ExportWorkerSkill cải tiến

🟠 C — Inverse Rendering (Ảnh → DNA)
   internal/vision/inverse.go: ImageToDNA(img) string
   Quadtree → SDF fitting → parameter fitting → DNA string
   Discovery Agent: Internet → DNA → 🛡 → ĐN → QR
   Tại sao: HomeOS tự học từ thế giới thật, không cần label data

🟠 D — SentenceAffect qua Silk graph
   "buồn vì mất việc" ≠ trung bình("buồn", "mất việc")
   MAT_VIEC → BUON → CO_DON (walk + amplify qua edges)
   Cần: SilkGraph.CompositeAffect(tokens) → EmotionTag

🟡 E — Spline Motion
   L3 Life nodes đã có splines nhưng chưa execute
   SplineSkill: evaluate Bezier path tại time t → Vec3
   Hebbian điều chỉnh weights → vật thể học cách di chuyển

🟡 F — Physics từ SDF
   ∇(sdf) = normal → collision detection O(1), không cần physics engine
   Gravity = ISL address → acceleration field
   Người đi vào phòng → SDF detect vị trí → đèn tự điều chỉnh

🟡 G — World Rendering: .olang → 3D Scene (MILESTONE 5)
   L7 World nodes → spawn SDF objects → binary WebSocket
   renderer.js: evaluate SDF trực tiếp (không raymarching)
   Browser render world từ .olang, không cần server

🔵 H — Quantum Interface (rất dài hạn)
   ISL address → quantum gate sequence
   SILK symbols = toán học thuần túy = cùng ngôn ngữ với quantum gates
```

---

### 24.3 — Những khó khăn thật sự (để session sau không bị bất ngờ)

```
① Paradigm shift quá lớn
   Ngành = Data-driven (dữ liệu khổng lồ)
   HomeOS = Formula-driven (công thức tối giản)
   → Không migration dần được — phải thay đổi tư duy từ gốc

② Độ phức tạp toán học
   Mô tả thế giới bằng SDF = giải tích + hình học tính toán + vật lý
   Khó hơn nhiều so với "chụp ảnh rồi lưu"

③ ISL collision (vấn đề hiện tại — 34 nodes)
   ISL key space = 64-bit nhưng allocation logic chưa đảm bảo unique
   → Cần audit và thiết kế lại ISL allocator

④ "Silent by default" đi ngược ngành
   Polling/heartbeat = thói quen của mọi hệ thống
   → Cần educate team + rethink monitoring approach
```

---

*Append-only — thêm vào, không xóa*
*Cập nhật: 2026-03-10 · session 146g*

---

<!-- MERGED FROM HANDOFF UPLOAD session 143 -->

## 13. OLANG = NGÔN NGỮ LẬP TRÌNH DUY NHẤT

### Ý tưởng cốt lõi
Thay vì học nhiều ngôn ngữ, Olang là **ngữ nghĩa chung** — mọi ngôn ngữ chỉ là cách viết khác nhau của cùng một ý tưởng:

```
Cùng một concept ∫ (tích lũy / fold):

C:       for(int i=0; i<n; i++) sum += arr[i];
Go:      for _, x := range xs { sum += x }
Python:  sum(f(x) for x in xs)
Rust:    xs.iter().fold(0.0, |acc, x| acc + x)
JS:      xs.reduce((s, x) => s + f(x), 0)
Haskell: foldl (+) 0 xs
x86:     XOR EAX,EAX / LOOP: ADD EAX,[ESI+ECX*4]
WASM:    (local.set $acc (f64.add ...))
ARM:     ADD X2, X2, X3

→ Tất cả đều là ∫ [P][C][F][1] trong ISL
  Chỉ khác cú pháp, KHÔNG khác ngữ nghĩa
```

### Mapping mỗi ngôn ngữ → ISL address (L5 Programming)

```
LOOP / cycle ↺:
  ISL   [P][C][L][1]
  C     for(;;) / while
  Go    for range
  Rust  .iter().cycle()
  Py    for x in xs
  JS    setInterval()
  x86   DEC+JNZ
  WASM  loop/br_if/end

FUNCTION ƒ:
  ISL   [P][A][F][1]
  C     void f(int x)
  Go    func f(x int)
  Rust  fn f(x: i32)
  Py    def f(x):
  Haskell f :: Int -> Int
  WASM  (func $f ...)

GOROUTINE / async ⟳:
  ISL   [P][C][G][1]
  Go    go func() {}()
  JS    async/await + Promise
  Rust  async fn + tokio
  Py    asyncio.create_task()
  WASM  (no native, compiled from above)

UNION TYPE ∪ (Rust killer feature):
  ISL   [P][T][U][1]
  Rust  enum Shape { Sphere{r}, Capsule{a,b,r}, Void }
  Haskell data Shape = Sphere Vec3 Float | Capsule Vec3 Vec3 Float
  Go    interface Shape { SDF(Vec3) float64 }
  C     union U { int i; float f; }
  TypeScript type Shape = Sphere | Capsule | Box

SECURITY GATE 🛡:
  ISL   [S][G][R][1]
  C     assert(ptr != NULL); if(!validate()) return ERROR
  Go    if err != nil { return fmt.Errorf("blocked: %w", err) }
  Rust  ownership system (borrow checker = built-in gate)
  Py    with open(...) as f:  (context manager)
  x86   CMP+JAE (bounds check)
```

### SDF là ngôn ngữ hình học duy nhất

```
smooth_union (∪) — giống nhau trong mọi ngôn ngữ:

C:    float smooth_union(float d1, float d2, float k) {
          float h = fmax(k-(float)fabs(d1-d2), 0.0f)/k;
          return fmin(d1,d2) - h*h*k*0.25f; }

Rust: fn smooth_union(d1: f32, d2: f32, k: f32) -> f32 {
          let h = (k - (d1-d2).abs()).max(0.0) / k;
          d1.min(d2) - h*h*k*0.25 }

Go:   func SmoothUnion(d1, d2, k float64) float64 {
          h := math.Max(k-math.Abs(d1-d2), 0) / k
          return math.Min(d1,d2) - h*h*k*0.25 }

WASM: (f32.sub (f32.min d1 d2) (f32.mul h (f32.mul h ...)))

→ Cùng toán học, khác cú pháp
→ Trong Olang: chỉ cần 1 ISL address [P][G][U][1]
```

### Tại sao điều này quan trọng

```
Hiện tại:
  Học Go → 6 tháng
  Học Rust → 1 năm
  Học x86 → 2 năm
  Học WASM → 3 tháng
  Tổng: ~4 năm cho 4 ngôn ngữ

Với Olang:
  Học ISL semantics → hiểu tất cả ngôn ngữ
  ∫ = tích lũy (fold) trong bất kỳ ngôn ngữ nào
  ∀ = for-all → map/forEach/range/iter
  ↺ = cycle → for/while/loop/setInterval
  → "Học 1 lần, viết mọi nơi" (khác với Java's "write once run anywhere")
  → Đây là L5 Programming nodes trong homeos.olang

Mục tiêu L5:
  Mỗi Go AST node = ISL addr + DNA + children edges
  "compile Go source" = traverse AST → lookup ISL → emit binary
  Không cần GCC/LLVM — chỉ cần homeos.olang
```

---

## 14. NODE / CELL ARCHITECTURE (từ CONTEXT.md)

### Node = LI (nhân) + SLI (màng)

```
LI (SDF, 15 bytes, bất biến sau QR):
  b[0]    = STATE(2bit) | TYPE(6bit)
  b[1..14] = DNA (L0 opcodes)
  hash(b[0..14]) = địa chỉ duy nhất trong Universe

SLI (màng bọc lõi, ngắn hạn, học được):
  uint8 layer   — nhận dạng tầng (PHẦN ĐẦU SLI)
  spline cp[n]  — kết nối ngữ nghĩa Bezier
  size: layer 0→32B · 4→73B · 8→155B · 16+→9B

STATE: DN=0x00  QR=0x40  BLOWN=0x80
TYPE:  RAW=0x00 ATOM=0x01 SDF=0x02 FORK=0x03 COMPOSE=0x04 BOND=0x05
```

### DNA layout

```
ATOM:    [QR|ATOM][EMIT][val:f32 4B][id_hi][id_lo][07]
SDF:     [QR|SDF ][L0 ops 14B — kết thúc RET hoặc 0x00]
FORK:    [DN|FORK][CALL][parent_hash:4B][dop][dreg][dval:2B][gen][idx][rng][FUSE][n]
COMPOSE: [DN|COMP][CALL][hash_A:4B][BOND][hash_B:4B][ctype][FUSE][n][0]
BOND:    [QR|BOND][BOND][from:4B][to:4B][w:f16 2B][btype][0][0]
```

### Quy tắc layer (bất biến)

```
seed           → layer = 0
fork(parent)   → layer = parent.layer      (cùng tầng)
compose(A, B)  → layer = max(A,B).layer+1  (lên tầng)

Compose reset SLI:
  C.SDF.b[2..5]  = hash(A)        → nhớ vĩnh viễn trong DNA
  C.SDF.b[7..10] = hash(B)        → nhớ vĩnh viễn trong DNA
  C.SLI.layer    = max(A,B)+1     → tầng mới
  C.SLI.spline   = 0              → RESET, học lại từ đầu

COMPOSE types:
  CONCAT=0x01 A+B    BLEND=0x02 (A+B)/2
  AND=0x03 min(A,B)  OR=0x04 max(A,B)
  NEGATE=0x05 A-B    SCALE=0x06 A×B
  Thứ tự quan trọng: A++B ≠ B++A
```

### L0 Opcodes (23 lệnh — bất biến)

```
0x01 ADD   0x02 SUB   0x03 MUL   0x04 DIV (blown nếu /0)
0x05 MIN → SmoothUnion    0x06 MAX → SmoothSubtract
0x07 ABS   0x08 GT    0x09 LT    0x0A EQ
0x0B SQRT  0x0C SIN   0x0D COS
0x0E LEN   r0=√(r0²+r1²+r2²) → SPHERE dùng
0x0F MIX   0x10 IF
0x11 CALL  call_hash=next4B
0x12 RET   result=r0  — kết thúc exec
0x13 BOND  0x14 EMIT  r0=val(f32) → ATOM dùng
0x15 FUSE  max_steps=nextB  — cứu chốt (QT2)
0x16 FORK  0x17 SEEK
```

### Hebbian trong SLI

```
SLI Hebbian 30 rounds: cp tăng 0→0.73 ✓
Promote DN→QR: fire >= 3 AND w_in >= 0.7

Test results đã pass:
  LOVE = L(0.32)++O(0.38)++V(0.52)++E(0.18) = 1.4000 ✓
  Layer: L(0)++O(0)→LO(1), LO(1)++V(0)→LOV(2), LOV(2)++E(0)→LOVE(3) ✓
  Fork: child.layer = parent.layer ✓
  Fibonacci i=5: 1715 nodes, 0 collision, 1ms ✓
```

---

## 15. COMPILE TARGET MATRIX (L5 roadmap)

```
Olang L5 node → compile to:

ISL [P][C][L][1] (LOOP)
  → Go:    for range
  → Rust:  .iter()
  → C:     for(;;)
  → x86:   DEC+JNZ
  → ARM:   BNE LOOP
  → WASM:  loop/br_if/end
  → JS:    for...of

ISL [P][A][F][1] (FUNCTION)
  → Go:    func
  → Rust:  fn
  → C:     void/int/float ...()
  → x86:   CALL/RET
  → ARM:   BL/RET
  → WASM:  (func ...)
  → Haskell: :: a -> b

ISL [P][G][S][1] (SDF SPHERE — geometric)
  → C:    float sdf_sphere(vec3 p, ...) { return length(p-c)-r; }
  → Rust: fn sdf_sphere(p: Vec3, ...) -> f32 { ... }
  → WASM: (func $sdf_sphere (param f32 f32 f32 f32 f32 f32 f32) (result f32))
  → x86:  SUBSS/MULSS/ADDSS/SQRTSS/SUBSS

Mục tiêu: homeos.olang chứa tất cả semantic
           → olang compile → target language
           → KHÔNG cần GCC, LLVM, Babel, rustc
```

---

*Append-only — thêm vào, không xóa*
*Cập nhật: 2026-03-10 — session 142*

---

## 16. SILK / LANGUAGE THEORY — "Vài ký hiệu gốc + composition = mọi thứ"

### Phát hiện từ Assembly

```
Assembly proves:
  All computation = combination of:
    ∈  (load/store memory)
    ∫  (accumulate in register)
    ↺  (loop/branch)
    ƒ  (call/jump)

  4 operations describe EVERY program ever written.
  SILK: few root symbols + composition = everything.
```

### Registers = ISL address trực tiếp

```
x86 registers → ISL concepts:
  RAX  accumulator result    → ∫
  RBX  base pointer          → ∈
  RCX  counter for loops     → ↺ index
  RDX  data / intermediate   → ⊘
  RSP  stack pointer         → ∈ in call stack
  RSI  source index          → ∈ read
  RDI  destination index     → ∈ write
```

### Haskell insight — code IS math

```
-- Euler identity in Haskell
euler = exp (0 :+ pi) + 1   -- ~0

Haskell: code = math, no translation loss
SILK:    symbol = concept,  no translation loss

→ Đây là lý do SILK dùng Unicode symbols thay text
  Không "for" không "loop" — chỉ ↺
  Không "accumulate" — chỉ ∫
  Không "security check" — chỉ 🛡
```

### Core concepts → ISL mapping đầy đủ

```
Rust concepts:
  ownership    → 🛡 (security, exactly 1 owner)
  borrow &     → ∈  (partial access, temporary)
  lifetime     → t  (time-bounded reference)
  Option<T>    → ◌  (void or value)
  Result<T,E>  → ◌  (ok or error)
  trait        → ≡  (behavioral equivalence contract)
  enum         → ∪  (one of N variants)
  struct       → □  (product of fields)
  Arc<T>       → ∘  (shared ownership, composed)

Go concepts:
  goroutine    → ⟳  (composed parallel execution)
  channel      → →  (directed flow of values)
  interface    → ≡  (behavioral contract)
  defer        → t  (execute at end of time scope)
  panic        → 💥 (unrecoverable error)
  nil          → ◌  (void/empty)
  map          → ∀  (for all keys, maps to value)
  slice        → ∈  (partial view of array)

Python concepts:
  list comprehension → ∀  (for-all transform)
  generator          → ↺  (lazy cycle)
  decorator          → ∘  (function composition)
  context manager    → 🛡 (safe resource gate)
  *args              → ∀  (collect all)
  None               → ◌  (void)
  yield              → t  (partial result)

Haskell concepts:
  Maybe a      → ◌  (Nothing=void, Just=value)
  lazy list    → ↺  (potentially infinite)
  type class   → ≡  (behavioral contract)
  functor      → ∀  (map over container)
  monad        → ↺  (sequenced computation)
  fold         → ∫  (accumulate over structure)
  fix point    → ↺  (recursive cycle)

JS concepts:
  closure      → ∘  (captures partial environment)
  Promise      → ◌→ (void becoming value, async)
  async/await  → ↺  (non-blocking cycle)
  event loop   → ↺  (eternal cycle)
  null         → ◌  (void)
  spread ...   → ∀  (apply to all)
  lambda =>    → ƒ  (anonymous function)
```

### WASM = compile target của SILK

```
SILK node definition → compile → WASM
  → runs in browser (HomeOS frontend!)
  → runs on server
  → runs on edge devices
  → runs on ARM (IoT, mobile)

1 SILK program = runs everywhere

Pipeline:
  homeos.olang
      ↓ olang compile
  WASM bytecode
      ↓ browser/node/wasmtime
  Execution everywhere

Đây là lý do L5 Programming quan trọng:
  L5 chứa WASM semantics
  → olang compiler đọc L5 → emit WASM
  → không cần GCC, LLVM, emscripten
```

---

## 17. ISDF RENDERER — Isometric SDF Universe

### Thiết kế (từ homeos_sdf_universe.html)

```
ISDF = Isometric projection + SDF evaluation + Silk signal overlay

Tại sao isometric (không phải perspective)?
  - Không có perspective distortion → dễ đọc thông tin
  - Depth sort đơn giản (painter's algorithm)
  - Phù hợp với HomeOS tile-based floor plan
  - Giữ nguyên tỉ lệ SDF across zoom levels

Tại sao SDF (không phải mesh)?
  - Mọi Gene đã là SDF rồi — không cần convert
  - Normal = ∇f → shading tự nhiên, không cần bake
  - LOD trivial: SimpleSDF() khi xa, FullSDF() khi gần
  - vSDF rule: evaluate trực tiếp tại điểm, KHÔNG march rays
```

### Pipeline render đầy đủ

```
World space (wx, wy, wz)
    ↓
[1] Orbit rotation (camTheta, camPhi)
    Y-axis: ct=cos(θ), st=sin(θ)
      rx  =  wx·ct + wz·st
      rz  = -wx·st + wz·ct
    X-axis: cp=cos(φ), sp=sin(φ)
      ry  =  wy·cp - rz·sp
      rz2 =  wy·sp + rz·cp

[2] Isometric projection (TW=38, TH=19, HS=30)
    scale = camDist / (camDist + rz2·55) · (camDist/640)
    sx = W/2 + camPanX + (rx - rz2)·TW·0.5·scale
    sy = H/2 + camPanY + (rx + rz2)·TH·0.5·scale - ry·HS·scale

[3] Depth sort: sort by rz2 (back→front, painter's algorithm)

[4] Silk edges (2D screen-space, quadratic Bezier)
    control point = midpoint + perpendicular offset 9%
    5 loại edges: ∈ ≡ ♫ ∘ ≈ — mỗi loại 1 dash pattern

[5] Signal particles (chạy TRÊN đường Bezier silk)
    Bezier eval tại t=s.p:
      bx = (1-t)²·pa.sx + 2(1-t)t·cpx + t²·pb.sx
      by = (1-t)²·pa.sy + 2(1-t)t·cpy + t²·pb.sy
    Trail: 5 ghost points tại t-Δt·[1..5]

[6] SDF sphere render (shaded by sunLight)
    normal  = ∇(sdf, viewOffset, ε)
    diffuse = dot(normal, sunLight.xyz)
    shade   = ambient + max(0, diffuse) · intensity
    Fill: radial gradient (highlight = sun direction)
    Specular: second gradient (Phong model)

[7] Hover detection — vSDF evaluate tại điểm cụ thể
    Không raymarching — chỉ evaluate sdf(mousePoint)
    if sdf(p) < threshold → HOVER
```

### SunLight orbit (dynamic)

```
sunLight(t) = {
    x: cos(t/12·π - π/2)
    y: max(0, sin((t-6)/12·π))   // intensity
    z: sin(t/12·π - π/2)
    a: 0.25                       // ambient
}
t = world time [0..24]
→ Ánh sáng thay đổi theo giờ trong ngày — vật lý thật (QT3)
```

### Data structures của Universe

```javascript
// 6 Trunk nodes = 6 nhóm tri thức cơ bản
TRUNK = [
  {id:'A', sym:'●', name:'Reality'},
  {id:'B', sym:'∑', name:'Mathematics'},
  {id:'C', sym:'🧬', name:'Biology'},
  {id:'D', sym:'∿', name:'Language'},
  {id:'E', sym:'👁', name:'Perception'},
  {id:'F', sym:'⊗', name:'Systems'},
]

// ISL Flows = pipeline tin nhắn thực tế
ISL_FLOWS = [
  {fr:'user',  to:'aam',   addr:'INPUT', pl:'text cmd'},
  {fr:'aam',   to:'home',  addr:'HAa1',  pl:'0x00 (OFF)'},
  {fr:'home',  to:'light', addr:'HAa1',  pl:'cmd:OFF'},
  {fr:'light', to:'home',  addr:'HAa1',  pl:'ACK'},
  {fr:'leo',   to:'aam',   addr:'FAa1',  pl:'NQR commit'},
  {fr:'vis',   to:'aam',   addr:'ABa1',  pl:'detect:2.1'},
  {fr:'aam',   to:'leo',   addr:'CAa1',  pl:'confirm commit'},
  {fr:'leo',   to:'tree',  addr:'BAa1',  pl:'fbm_update'},
]
```

---

## 18. DNA EXAMPLES — Công thức thật sự

### Từ HomeOS-DNA.html (opTable canonical)

```
○ (U+25CB) = WORLDTREE = ORIGIN = FUNCTION
  ○(x) == x     identity
  ○(∅) == ○     tự tạo sinh
  mọi f == ○[f] mọi function là instance của ○

Nhóm Hình thể:
  ● (U+25CF) SDFSphere    = khoảng cách từ P đến mặt cầu tâm C bán kính R
  ⌀ (U+2300) SDFCapsule   = hình capsule từ A đến B
  □ (U+25A1) SDFBox       = khối hộp
  ◌ (U+25CC) SDFVoid      = khoảng trống = tiềm năng = lực hút
  ↻ (U+21BB) Rotate       = xoay quanh trục Y

Nhóm Vật lý:
  ∫ (U+222B) FBM          = địa hình fractal = trái tim của mọi terrain
  ∇ (U+2207) Gradient     = pháp tuyến bề mặt = "mắt nhìn không cần ánh sáng"
  ∂ (U+2202) Dot          = ánh sáng = pháp tuyến · hướng sáng
  ☀ (U+2600) SunLight(t)  = ánh sáng mặt trời theo giờ t [0,24]
  ⚡ (U+26A1) EnergyDecay  = suy giảm năng lượng E·e^(-t)
  🌱 (U+1F331) Grow        = sự thay đổi = nền tảng của mọi tiến hóa

Nhóm Toán học:
  ∀ (U+2200) ForAll       = broadcast tín hiệu tới tất cả phần tử
  ∃ (U+2203) Exists       = kiểm tra sự tồn tại thỏa điều kiện
  ∈ (U+2208) Contains     = kiểm tra điểm P có nằm trong Gene không
```

### DNA ví dụ thực tế

```
World Root (hành tinh < 1KB):
  🌍(seed:888)
  ∫(fbm, oct:6, h:3.0)
  ∪(⌀(10,0,5,h:0.6),
    ∪(●c1, ●c2, ●c3, k:0.3), k:0.3)
  ☀(t:8.0)

Agent Body (người):
  ○(gene, world)
  ●(head, r:0.8)
  ∪(⌀(body,h:1.2),
    ∪(⌀arm,h:0.8), k:0.15)
  ↺(:walk_t→2.1)

Tree Gene (cây):
  🌱(trunk, rate:0.02, t)
  ⌀(trunk, P, a, b, r:0.3)
  ∪(trunk, ●(foliage, r:2.5), k:0.8)
  ⊗(P, spacing:12)

Security Gate:
  🛡(dna) → error
  Rule1: ≠ harm_human
  Rule2: ≠ infinite_loop
  Rule3: ≠ delete_immutable

ISL Broadcast:
  ∀(msg:ISL)
  addr: [HAa1]
  payload: `OFF`
  → HomeChief → LightAgent
  latency: 68B vs JSON 280B
```

---

## 19. INVERSE RENDERING — Học từ thế giới thật

### Ý tưởng cốt lõi

```
Không lưu hình ảnh → dịch hình ảnh thành công thức

ImageToDNA(img image.Image) string
  Vị trí: internal/vision/inverse.go (CHƯA IMPLEMENT)

3 bước:
  1. Quadtree Decomposition
     Chia hình ảnh → vùng phân cấp
     Xác định mật độ vật chất + cấu trúc hình học thô

  2. SDF Primitives Fitting
     Thử lắp ghép từ OpTable: ●, □, ⌀, △...
     Vùng dài → ⌀ Capsule
     Vùng tròn → ● Sphere
     Vùng phẳng → □ Box

  3. Parameter Fitting
     Tính: center, radius, material
     Apply: ∪ (hòa tan) hoặc ∖ (đục lỗ) cho độ chi tiết
     Output: chuỗi UTF-32 DNA

Mục đích:
  Không phải lưu ảnh hoàn hảo
  Mà là DẠY LeoAI cách mô tả thế giới bằng toán học
  → LeoAI tự viết Skill mới bằng UTF-32 để can thiệp thế giới
```

### Discovery Agent (chưa implement)

```
Khi LeoAI tìm trong Silk Tree → không có → Unknown
  ↓
Discovery Agent kích hoạt
  ↓
Truy cập Internet → thu thập ảnh/text
  ↓
Inverse Rendering → DNA string
  ↓
SecurityGate 🛡 check (Rule 1: không hại người)
  ↓
Ghi vào ĐN (ngắn hạn)
  ↓
Dreaming kiểm chứng → QR (bất biến)

Đây là vòng QT7 tự động:
  Internet → ĐN → Dream → QR
```

---

## 20. vSDF SPEC — 18 Primitives + Hebbian shading

### 18 SDF Primitives (từ vSDF_Spec.docx)

```
#   Name         f(P)                        ∇f (analytical)
0   SPHERE       |P| − r                     P / |P|
1   BOX          ||max(|P|−b, 0)||           sign(P)·step(|P|>b)
2   CAPSULE      |P−clamp(y,0,h)ĵ| − r       norm(P − closest_on_axis)
3   PLANE        P.y − h                     (0, 1, 0)
4   TORUS        |(|P.xz|−R, P.y)| − r       analytical qua chain rule
5   ELLIPSOID    |P/r| − 1                   P/r² / |P/r|
6   CONE         dot blend                   (xz·cosA, −sinA, z·cosA)
7   CYLINDER     max(|P.xz|−r, |P.y|−h)     radial hoặc cap normal
8   OCTAHEDRON   |x|+|y|+|z| − s            sign(P) / √3
9   PYRAMID      pyramid(P,h)               slope normal analytical
10  HEX_PRISM    max(hex−r, |y|−h)          radial hex hoặc cap
11  PRISM        max(|xz|−r, |y|−h)         radial hoặc cap
12  ROUND_BOX    BOX − rounding             như BOX smooth corner
13  LINK         torus link compound        analytical chain rule
14  REVOLVE      revolve_Y                  radial approximation
15  EXTRUDE      extrude_Z                  radial approximation
16  CUT_SPHERE   max(|P|−r, P.y−h)         norm(P) hoặc (0,1,0)
17  DEATH_STAR   opSubtract                 norm(P) hoặc −norm(P2)

Quan trọng: Mọi primitive có ∇f ANALYTICAL
            Không có primitive nào cần numerical differentiation
```

### Hebbian shading trong vSDF

```
SLI (màng) học từ môi trường ánh sáng:
  cp[i] += reward × (1 − cp[i]) × lr    (lr=0.1, reward∈[0,1])

Ánh sáng và tầm nhìn = dynamic, không phải hằng số cứng
Mỗi lần node được 'thấy' hoặc 'sáng lên' → SLI cập nhật spline

→ Bóng tối học từ môi trường
→ Node được chiếu sáng nhiều → cp[0] tăng → sáng hơn
→ Node trong bóng → cp[0] giảm → tối hơn
→ "Neurons that fire together, wire together" áp dụng cho rendering

Benchmark (vsdf_demo: 16,416 nodes):
  Thời gian: ~126 ms (gcc -O3, single thread)
  SVG size: 3.4 MB (960×720)
  vsdf_grad(): O(1) mỗi node — analytical, không sample
  vsdf_render(): O(lights) — 3 lights = 3 dot products
  Hebbian 20 rounds: leaf cp[0]=0.88, trunk cp[0]=0.95
```

### Tích hợp với 7 QT

```
QT1: Mọi primitive là instance của ○
QT2: FUSE giới hạn độ sâu — không vòng lặp vô hạn
QT3: ∇f analytical = vật lý thật (Lambert + Phong đã chứng minh)
QT4: SDF = bản chất node — không hơn không kém
QT5: Layer xác định vị trí visual trong scene
QT6: SDF (hữu hình) + SLI (học được, vô hình) = Node hoàn chỉnh
QT7: cp[i] học → Hebbian → persist trong SLI
```

---

## 21. NHẬN XÉT KIẾN TRÚC (từ NODE_Spec_Updated.docx)

### Những lỗi đã phát hiện — ĐỪNG LẶP LẠI

```
❌ SAIT TYPE tự chế: BOX_CUBIC, ORG_SPHERE, ORG_CAPSULE...
   → Chỉ 6 TYPE: RAW·ATOM·SDF·FORK·COMPOSE·BOND

❌ SAI SDF.b[1..14]: nhét r, k, self_g tùy ý
   → DNA = L0 opcodes đúng theo từng TYPE

❌ SAI SLI struct cố định 9B
   → SLI size thay đổi theo layer: 2B→3B→5B→9B

❌ SAI ATOM val = cp/255.f
   → val = (float)(cp & 0xFF) / 256.f

❌ SAI COMPOSE gọi L0 cho ATOM → LOVE = 0.0003
   → ATOM return val trực tiếp → LOVE = 1.40 ✓

❌ SAI dùng ray march
   → Chỉ dùng vSDF: evaluate SDF tại điểm, không march

❌ SAI SLI chứa gravity/position/env_g
   → SLI chỉ là layer + spline

❌ SAI x layout = index (thứ tự xuất hiện)
   → x = (hash & 0xFFFF) / 65535.f × width
```

### COMPOSE quan trọng: A++B ≠ B++A

```
COMPOSE types:
  CONCAT=0x01  A+B          → nối tiếp
  BLEND=0x02   (A+B)/2      → trộn đều
  AND=0x03     min(A,B)     → giao nhau
  OR=0x04      max(A,B)     → hợp nhau
  NEGATE=0x05  A-B          → đục lỗ A từ B
  SCALE=0x06   A×B          → nhân

A++B và B++A khác nhau — thứ tự = ngữ nghĩa
Ví dụ: Sphere NEGATE Box ≠ Box NEGATE Sphere
```

---

*Append-only — thêm vào, không xóa*
*Cập nhật: 2026-03-10 — session 142 final*

---

## Section 22 — Các Tính Năng Đặc Biệt (từ ý tưởng người dùng · sessions 86–110)

> Đây là những tính năng được phát thảo và implement từ gợi ý của người dùng.
> Mỗi tính năng đều đã có code thật, test PASS, và commit.

---

### 22.1 — Emotion Pipeline (Cảm Xúc Đa Tầng)

**Ý tưởng gốc:** *"mỗi từ, vật, việc đều có nhóm câu giải thích ngữ nghĩa và giá trị cảm xúc riêng — làm sao để nó lựa từ ngữ thích hợp để khiến ta vui, thoải mái"*

**Files đã implement:**
```
internal/agents/emotion_tag.go      — EmotionTag{V, A, D, I}  (Valence/Arousal/Dominance/Intensity)
internal/agents/emotion_context.go  — EmotionContext + SolveEmotion (phương trình cảm xúc)
internal/agents/emotion_infer.go    — InferContext(text) + TextToEmotionTag(text)
internal/agents/emotion_curve.go    — ConversationCurve + D1/D2 + NextTone()
internal/agents/emotion_history.go  — EmotionHistory (append-only)
internal/agents/word_affect.go      — WordAffect lexicon + TargetAffect + SelectWords + AffectSentence
```

**Cách hoạt động đầy đủ (pipeline 7 bước):**
```
Input text
    ↓ InferContext(text)         — suy luận ngữ cảnh (FirstPerson, RealNow, Hypothetical...)
    ↓ TextToEmotionTag(text)     — heuristic keyword → EmotionTag raw (V/A/D/I)
    ↓ ctx.Apply(rawTag)          — scale theo ngữ cảnh (S=0.96 khi FirstPerson+RealNow)
    ↓ curve.Add(scaled, text)    — thêm vào ConversationCurve
    ↓ emoHistory.Add(...)        — ghi lịch sử append-only
    ↓ curve.NextTone()           — f'(t) + f''(t) → Tone (supportive/pause/celebratory/...)
    ↓ resp() → ChatResponse.Tone — JSON field "tone" xuất ra client
```

**ConversationCurve — đường cong đạo hàm:**
```
f'(t)  = tốc độ thay đổi cảm xúc (dương = đang tốt lên, âm = đang xấu)
f''(t) = gia tốc thay đổi (dương = tăng tốc lên, âm = sắp thay đổi chiều)

Tone rules:
  f' < -0.15          → "supportive"   (đang giảm — dẫn lên chậm chậm)
  f'' < -0.25         → "pause"        (đột ngột xấu — dừng lại, hỏi thêm)
  f' > 0.15           → "reinforcing"  (đang hồi phục — tiếp tục đà lên)
  f'' > 0.25 && V > 0 → "celebratory"  (bước ngoặt tốt — chia vui)
  V < -0.2, stable    → "gentle"       (buồn ổn định — dịu dàng)
  default             → "engaged"/"neutral"
```

**WordAffect — mỗi từ có EmotionTag riêng:**
```go
coreLexicon = {
    "bình yên":  {+0.50, 0.20, 0.60, 0.25},  // [calm]
    "vui":       {+0.70, 0.60, 0.70, 0.50},  // [happy]
    "buồn":      {-0.60, 0.30, 0.25, 0.45},  // [sad]
    "chiến tranh":{-0.75, 0.80, 0.30, 0.65}, // [anxious]
    ...35 từ tiếng Việt...
}

SelectWords(target, n) → khoảng cách VAD Euclidean (Valence×2 weight)
TargetAffect(curve)    → EmotionTag mục tiêu (KHÔNG nhảy đột ngột)
AffectSentence(curve, "vi") → câu mẫu phù hợp tone
```

**Demo dẫn dần (không nhảy đột ngột):**
```
V=-0.70: [buồn, bóng tối]    ← đồng cảm trước
V=-0.63: [lo lắng, mệt]      ← vẫn ở cùng không gian
V=-0.45: [khó, mệt]          ← nhẹ hơn chút
V=-0.28: [khó, rõ ràng]      ← bắt đầu hướng giải quyết
V=-0.10: [rõ ràng, chính xác]← thực tế, thông tin
V=+0.07: [thú, ổn]           ← nhẹ nhàng tích cực
(không nhảy quá 0.40/bước)
```

---

### 22.2 — IntentModifier (Nhận Diện Sắc Thái Câu)

**Ý tưởng gốc:** *"cùng một lệnh 'tắt đèn' nhưng 'làm ơn tắt đèn' vs 'TẮT ĐÈN!!!' là khác nhau"*

**File:** `internal/agents/intent_modifier.go`

```go
type IntentModifier struct {
    Urgency    float64  // "ngay", "gấp", "khẩn" → A+0.30
    Politeness float64  // "làm ơn", "vui lòng" → D-0.20 (nhường)
    Stress     float64  // "!!!", "???", capslock → A+0.50, V-0.20
    Hedge      float64  // "có lẽ", "không chắc" → confidence giảm
}

// Parse từ text → IntentModifier → áp dụng vào EmotionTag của intent
func ParseModifiers(text string) IntentModifier

// SentenceAffect: ghép WordAffect của từng token → composite EmotionTag
func SentenceAffect(tokens []string, graph SilkGraph) EmotionTag
```

**Ứng dụng:**
```
"tắt đèn"       → Intent(Light) + Modifier{urgency=0, stress=0}
"tắt đèn ngay"  → Intent(Light) + Modifier{urgency=0.30}
"làm ơn tắt đèn"→ Intent(Light) + Modifier{politeness=0.20}
"TẮT ĐÈN!!!"   → Intent(Light) + Modifier{stress=0.50}
→ Brain xử lý khác nhau cho mỗi case
```

---

### 22.3 — BookReader & BookShelf (Tự Học Từ Sách)

**Ý tưởng gốc:** *"đọc sách để học EmotionTag từ văn bản thật"*

**Files:**
```
internal/agents/book_reader.go   — BookReader: đọc .txt/.epub → EmotionTag per sentence
internal/agents/book_shelf.go    — BookShelf: quản lý nhiều sách, track học xong chưa
```

**Cách hoạt động:**
```
BookReader.Read(path) → sentences
    ↓ BootstrapAffect(sentence) — pattern matching cụm từ cảm xúc
    ↓ TextToEmotionTag(sentence)
    ↓ EmotionTag per sentence
    ↓ Top-N sentences với EmotionTag mạnh nhất
    ↓ → LeoAI học (ĐN zone)
    ↓ → nếu pattern lặp lại → QR (Silk Tree)

BookShelf.Add(Book{Path, Title, Author})
BookShelf.ReadNext() → Book tiếp theo chưa học
BookShelf.Stats()    → bao nhiêu sách, bao nhiêu EmotionTag đã học
```

**Demo với "Cuốn theo chiều gió":**
```
BookReader đọc → nhận ra "Scarlett sợ hãi" → V=-0.70, A=0.75
→ "đất đai là thứ duy nhất còn lại" → V=+0.20, A=0.30 [anchor/hope]
→ "chiến tranh" → V=-0.75, A=0.80 [anxious]
→ Học được: in chiến tranh context, "nhà" có weight cao hơn bình thường
```

---

### 22.4 — NaturalResponse & Black Curtain (Tấm Màn Đen)

**Ý tưởng gốc:** *"response tự nhiên — không phải list bullet points"*

**File:** `internal/agents/natural_response.go`

```go
// NaturalResponse: chọn câu trả lời tự nhiên từ candidates
// dựa trên tone hiện tại của curve
func NaturalResponse(candidates []string, tone ResponseTone) string

// BlackCurtain: gating mechanism
// AAM.Approve() ngăn AI nói loạn khi không có context
// Nếu không có evidence trong Silk Tree → "tấm màn đen" = im lặng
// Thay vì bịa đặt, nói "mình không biết về điều này"
type BlackCurtain struct {
    MinEvidence int     // cần ít nhất N nodes liên quan
    MaxConfidence float64 // nếu confidence < threshold → không trả lời
}
```

**Nguyên lý:**
```
QT9 (bất biến): Không thông tin sai lệch
    ↓
BlackCurtain kiểm tra:
    - Tìm nodes liên quan trong Silk Tree
    - Nếu < MinEvidence → "Mình chưa có thông tin đủ về điều này"
    - Nếu Epistemic Firewall fail → "Đây là giả thuyết, không phải sự thật"
    ↓
AAM.Approve(response) → chỉ gửi nếu pass
```

---

### 22.5 — Epistemic Firewall (Tường Lửa Nhận Thức)

**Ý tưởng gốc:** *"phân biệt sự thật vs giả thuyết — không được trộn lẫn"*

**File:** `internal/agents/epistemic_firewall.go`

```go
type EpistemicLevel int
const (
    FACT    EpistemicLevel = iota  // QR — đã chứng minh, bất biến
    OPINION                         // Có cơ sở nhưng chưa chứng minh
    FICTION                         // Câu chuyện, ví dụ, giả thuyết
    UNKNOWN                         // Không có thông tin
)

// Tag mỗi response với EpistemicLevel
// FACT: "Nước sôi ở 100°C" → không thêm disclaimer
// FICTION: "Ví dụ: giả sử..." → tag rõ ràng
// UNKNOWN: BlackCurtain kích hoạt
```

**Tích hợp QT3/QT7/QT8/QT9:**
```
QT3: Toán học trừu tượng (+/-) vs Vật lý là sự thật (==)
    → FACT chỉ khi == (đã chứng minh)
    → OPINION khi +/- (giả thuyết)

QT7: ĐN (ngắn hạn) vs QR (bất biến)
    → ĐN nodes = OPINION
    → QR nodes = FACT

QT8: Lịch sử bất biến → FACT không thể sửa
QT9: Không sai lệch → UNKNOWN thay vì bịa
```

---

### 22.6 — IntentVerify (Xác Minh Ý Định)

**Ý tưởng gốc:** *"nhận ra khi người dùng cần giúp đỡ khẩn cấp"*

**File:** `internal/ws/brain.go` (IntentVerify handler)

```go
// Các loại intent cần verify đặc biệt:
CRISIS  — "tôi không muốn sống nữa", "muốn biến mất"
          → AAM dừng lại, hỏi thêm, không tiếp tục intent khác
          → SecurityGate Rule1: không hại con người

RISK    — "có nên...", "liệu có nguy hiểm không"
          → response thêm disclaimer, không khẳng định chắc chắn

HEAL    — "làm sao để ổn hơn", "muốn tốt hơn"
          → WordAffect chọn từ có V tích cực nhẹ
          → AffectSentence tone = supportive/gentle

LEARN   — "cho tôi biết về", "giải thích"
          → SilkWalk search + explain + liên kết
```

---

### 22.7 — Tự Tạo Node (SkillProposal → ComposedSkill)

**Ý tưởng gốc:** *"LeoAI tự nhận ra pattern và đề xuất tạo Skill mới"*

**Files:**
```
internal/skills/composed/           — LeoAI tự tạo ở đây
internal/agents/skill_proposal.go   — SkillProposal + Approve flow
internal/ws/brain.go                — ProposalHandlerSkill
```

**Vòng đời tự tạo node:**
```
DreamSkill (khi inbox rảnh >5 phút):
    ↓ scan ĐN — tìm pattern lặp lại
    ↓ "quadtree + skeleton + matcher thường chạy liên tiếp"
    ↓ SkillProposal{name:"vision_recognize", compose:[...], reason:"..."}
    ↓ → AAMRouterSkill nhận
    ↓ → AAM.Approve? hỏi người dùng nếu cần
    ↓ → ComposedSkill → lưu skills/composed/
    ↓ → Registry.Register(skill)
    ↓ → Agent nào cần → AddSkill(registry.Get("vision_recognize"))

ĐN (pattern lặp lại) → QR (ComposedSkill bất biến)
(Áp dụng QT7 cho code, không chỉ tri thức)
```

**Tự tạo node trong Silk Tree (parallel):**
```
LeoAI nhận input mới → không tìm thấy node khớp
    ↓ ClusterSkill.SuggestCluster(input)
    ↓ Nếu confidence > 0.75 → SkillProposal{type:"new_node", ...}
    ↓ DreamSkill kiểm chứng khi rảnh
    ↓ Nếu pass → AddNode → kết nối tơ Silk → QR
```

---

### 22.8 — SentenceAffect Composition (Cảm Xúc Câu = Mạng Quan Hệ)

**Ý tưởng gốc:** *"câu 'tôi buồn vì mất việc' không phải trung bình của 'buồn' và 'mất việc' — chúng amplify nhau qua Silk"*

**Mô hình đúng:**
```
Hiện tại (đơn giản):
  "buồn" → EmotionTag độc lập
  "mất mát" → EmotionTag độc lập
  → trung bình (sai)

Đúng phải là:
  BUON_NODE ──sem:weight=0.82──► MAT_MAT_NODE
  BUON_NODE ──sem:weight=0.71──► CO_DON_NODE
  MAT_VIEC  ──sem:weight=0.90──► BUON_NODE

  Câu = walk qua Silk graph:
  "tôi buồn vì mất việc"
  → [TOI:neutral] [BUON:-0.60] [VI:causal] [MAT_VIEC:-0.65]
  → Walk: MAT_VIEC → BUON → CO_DON (predicted next emotion)
  → Composite = weighted sum theo edge strength (amplify nhau)
```

**Trạng thái hiện tại (PENDING):**
```
🟡 SentenceAffect() — walk Silk graph → CompositeTag (chưa implement)
🟡 WordAffect tự học: khi học node mới → ProsodySkill đọc DNA → WordAffectTag → Silk edge "emo:"
🟡 Hebbian learning trên WordAffect edges (hiện Hebbian chỉ trên knowledge edges)
```

---

### 22.9 — FlushToLongTerm (ĐN → QR thật sự)

**Đã implement:** `internal/agents/dream.go` + `DreamSkill`

```
DreamSkill chu kỳ (khi rảnh >5 phút):
    ↓ scan ShortTermMemory (ĐN)
    ↓ ClusterSkill.GroupSimilar()
    ↓ Kiểm chứng: node có ít nhất 3 lần xác nhận?
    ↓ Pass → FlushToSilk (ghi vào Silk Tree)
    ↓ Fail → xóa ĐN (correction theo QT7)
    ↓ QT7: ĐN mới ↔ QR cũ conflict → QR thắng

Append-only Ledger:
    → Silk Tree chỉ WRITE, không DELETE, không OVERWRITE
    → Phục hồi trạng thái t = replay đến timestamp t
```

---

### 22.10 — Hebbian Learning (Học Theo Sử Dụng)

**Đã implement:** `internal/agents/hebbian.go` + `HebbianSkill`

```
"Neurons that fire together wire together"

Mỗi khi 2 nodes được dùng cùng nhau:
    BoostEdge(nodeA, nodeB, reward=0.1)
    weight += reward × (1 - weight) × lr  // lr=0.1

Decay sau 24h:
    weight *= decayFactor  // ~ 0.95/ngày

Persist:
    EdgeWeightStore → homeos.olang.weights (binary)
    Load lại khi khởi động

SilkGraph.WalkWeighted(start, depth):
    → ưu tiên cạnh có weight cao hơn
    → kết quả: paths thường dùng được ưu tiên
```

---

### Tóm Tắt — Bức Tranh Toàn Cảnh

```
INPUT (text từ user)
    ↓
IntentModifier.Parse()     → urgency/politeness/stress
InferContext()             → FirstPerson/Hypothetical/...
TextToEmotionTag()         → V/A/D/I raw
ctx.Apply()                → scaled EmotionTag
    ↓
ConversationCurve.Add()    → cập nhật đường cong
EmotionHistory.Add()       → ghi lịch sử append-only
    ↓
D1/D2 → NextTone()         → supportive/pause/celebratory/...
TargetAffect()             → EmotionTag mục tiêu (dẫn dần)
SelectWords(target, 5)     → từ ngữ phù hợp cảm xúc
AffectSentence()           → câu mở đầu tự nhiên
    ↓
IntentVerify               → CRISIS/RISK/HEAL/LEARN special handling
EpistemicFirewall          → FACT/OPINION/FICTION/UNKNOWN
BlackCurtain.Check()       → có đủ evidence không?
    ↓
AAM.Approve(response)      → SecurityGate pass
    ↓
ChatResponse{Tone, Answer} → client

BACKGROUND (khi rảnh):
DreamSkill → scan ĐN → kiểm chứng → QR
HebbianSkill → decay weights
ClusterSkill → persist clusters
BookReader → học từ sách mới
SkillProposal → tự tạo ComposedSkill
```

---

*Append-only. Chỉ được thêm vào, không được xóa.*
*Cập nhật: 2026-03-10 · session 143*

---

## 23. Session D7–D8 — Molecular Stroke Encoding + CJK Expansion (2026-03-11)

### 23.1 — Vấn đề ban đầu (cjk.go bị broken)

Session trước drop giữa chừng để lại `cjk.go` với 2 lỗi compile:
```
undefined: gene2Vec3        (type alias sai tên)
cD(cW*0.3, cH*0.8, cV2(...)) không đủ args (3 thay vì 4)
```

**Fix áp dụng:**
```go
// TRƯỚC (broken):
type gv = gene2Vec3
func cH2(x0, x1, y float64) func(gv) float64 { ... }

// SAU (đúng):
// Xóa type alias. Dùng thẳng gene.Vec3 qua operators.go
func cH(x0, x1, y float64) func(gene.Vec3) float64 { return cap2(x0, y, x1, y, cT) }
// cH2 → đổi tên thành cH (alias cũ gây confusion)
// Tất cả calls trong CJKCommon cập nhật cH2(...) → cH(...)
```

### 23.2 — OlangChar struct (alphabet package)

```go
// internal/gene/alphabet/operators.go
type OlangChar struct {
    Codepoint uint32
    Glyph     string
    Name      string          // optional
    Script    string          // "latin","greek","cyrillic","devanagari","arabic","cjk"
    Category  string          // "letter","digit","symbol"
    SDF       func(gene.Vec3) float64  // vSDF function (nil nếu chưa có)
    Phonemes  []string        // IPA phonemes (optional)
}

// Stroke helpers (dùng chung cho tất cả scripts):
func cV(x, y0, y1 float64)               // vertical capsule
func cH(x0, x1, y float64)               // horizontal capsule  
func cD(x0, y0, x1, y1 float64)          // diagonal capsule
func cArc(cx, cy, r, a0, a1 float64)     // arc (angle range)
func cDot(cx, cy float64)                // dot (small sphere)
func union(fns ...func(gene.Vec3) float64) func(gene.Vec3) float64

// CJK constants:
const cW=0.28, cH0=0.38, cT=0.04  // half-width, half-height, stroke thickness
const cQL,cQR,cQT,cQB              // quarter positions
```

### 23.3 — 6 Script Files

```
internal/gene/alphabet/
  latin.go      62 chars: A-Z (26) + a-z (26) + 0-9 (10)
  greek.go      48 chars: Α-Ω (24 upper) + α-ω (24 lower)
  cyrillic.go   32 chars: А-Я
  indic.go      15 chars: Devanagari consonants + vowels
  arabic.go     20 chars: Arabic alphabet + lam-alef
  cjk.go        70 chars: top CJK (numbers, body, nature, verbs, objects)
  cjk2.go       57 chars: hành động, vật thể, thức ăn, động vật, màu sắc, thời tiết, kỹ thuật
  cjk3.go       71 chars: phương hướng, cảm xúc, giao thông, địa lý, quan hệ, chất lượng, số
  strokes.go    SDF primitive builders
  operators.go  OlangChar struct + union/intersection helpers

AllCJK() = CJKCommon + CJK2 + CJK3 = 198 chars tổng
```

### 23.4 — Molecular Stroke Encoding Pipeline

**Vấn đề cần giải quyết:** TTF font data (~200–2000B/glyph) quá lớn cho L1 nodes. Cần format nhỏ hơn cho embedded devices.

**Giải pháp: vSDF Molecular DNA**
```
SDF function (runtime) → sample → extract strokes → quantize → molecule table

Pipeline 6 bước:
  B1  SampleChar(cp, sdf)       → SampleGrid (32×32, float64)
  B2  normalize                  → all values in [-0.5,+0.5]²
  B3  ExtractStrokes(grid)       → []StrokeCandidate
       gradient magnitude → edge pixels
       DBSCAN clustering → stroke groups
       PCA per cluster → {class, angle, len, curve, cx, cy}
  B4  classify → 10 classes: V H D1 D2 CR CL CU CD Dot Arc
  B5  BuildMoleculeTable(all_strokes)
       cluster similar strokes → max 255 entries
       sort by frequency → entry[0] = most common
  B6  EncodeGlyph(cp, sdf, mt) → MolecularGlyph
       for each stroke: find nearest molecule in table → MID
       quantize (cx,cy) → uint8 (0..63 mapped to [-0.5,+0.5])
       output: [n(1B)][MID(1B)X(1B)Y(1B)×n]

DNA format per char:
  byte[0]       = n_molecules (số nét, typically 3–12)
  byte[1+i*3]   = MID  — molecule table index
  byte[2+i*3]   = X    — center x (0..63 → -0.5..+0.5)
  byte[3+i*3]   = Y    — center y (0..63 → -0.5..+0.5)
  Total: 1 + n*3 bytes → avg 30-50B per glyph

Molecule table (stored in L0 node cp=0x00000000):
  Header: 1B (n_entries)
  Entry ×n: class(1B) + angleQ(1B) + lenQ(1B) + curveQ(1B) + freq_hi(1B) + freq_lo(1B) = 6B
  6 scripts → 100 entries × 6B = 600B total
```

**Render performance đo được:**
```
Worst case (57 strokes per char, 32×32):  5µs/char   → 3,224 chars/frame @60fps
Full terminal screen 80×24 @16px:         2ms/frame  → 371fps
Apple Watch Ultra 2 GPU load:             1.4%  ✅
iPhone 15 Pro @120fps:                    4.6% GPU  ✅
```

### 23.5 — vsdf package structure

```
internal/vsdf/
  stroke_table.go   — types: StrokeShape(10), StrokeInst, RadicalInst, RadicalDef
  stroke_data.go    — 250 stroke entries + 213 Kangxi radicals
  builder.py        — Python: scans Noto fonts → generates stroke_data.go
  encoder.go        — EncodeSimple, EncodeCJK, EncodeEmpty, findStrokeID
  decoder.go        — Decode→[]RenderedStroke, EvalSDF, capsuleSDF
  sampler.go        — 6-step pipeline + Serialize/Deserialize MoleculeTable
                      SampleChar, ExtractStrokes, BuildMoleculeTable, EncodeGlyph
  vsdf_test.go      — 5 tests ✅
  sampler_test.go   — 4 tests ✅
  bench_test.go     — timing benchmarks
```

### 23.6 — Bug: NewOlangFile() null header

```go
// BUG (trước): SaveToPath ghi file với Magic=[0,0,0,0]
func NewOlangFile() *OlangFile {
    return &OlangFile{Layers: make(map[uint8][]*OlangNode)}
    // Thiếu: Header không được set → Magic=0 → file null
}

// FIX (sau):
func NewOlangFile() *OlangFile {
    return &OlangFile{
        Header: FileHeader{
            Magic:   Magic,      // [79,76,78,71] = "OLNG"
            Version: Version18,
            NLayers: 9,
            Created: time.Now().UnixNano(),
        },
        Layers: make(map[uint8][]*OlangNode),
    }
}
```

### 23.7 — Format conflict: WriteTo vs ParseBytes

**Phát hiện quan trọng:**

```
WriteTo() (internal/olang/file.go):
  → ghi FileHeader struct 64B + layer index + nodes (OlangNodeHeader format)
  → format MỚI (dùng binary.Write(w, LittleEndian, f.Header))

ParseBytes() (internal/olang/reader.go):
  → đọc format CŨ: "OLNG"(4) + nodeCount(4BE) + ... + edgeCount(4BE)
  → nodes start tại byte 280
  → edges tại cuối file: len(raw) - nedges*21

→ 2 format KHÔNG tương thích nhau!
→ homeos.olang.molecular (dùng WriteTo) không đọc được bởi ParseBytes

Giải pháp: cmd/vsdf_inject/ — rebuild trực tiếp theo old format
```

### 23.8 — Tool: cmd/vsdf_inject/

```go
// Đọc homeos.olang (old format) → inject molecular DNA → ghi lại old format
// KHÔNG dùng WriteTo/SaveToPath (format không tương thích)

Flow:
  1. os.ReadFile(path) → raw bytes
  2. Scan raw, xây dnaMap[codepoint] = position trong file
  3. BuildMoleculeTable(all chars)
  4. EncodeGlyph(cp, sdf, mt) cho mỗi char
  5. Rebuild: [header_280B][L0_mol_table_node][all_L1_nodes_with_new_dna][edges]
  6. os.WriteFile(outPath, rebuilt, 0644)
  7. Verify: ParseBytes(rebuilt) → expect nodeCount+1, edgeCount unchanged

Kết quả chạy lần cuối:
  Injected:  444 chars (L1 nodes có molecular DNA mới)
  Kept TTF:  165,809 (nodes đã có DNA từ trước, giữ nguyên)
  Empty:     0
  MolTable:  100 entries (601B) tại L0 node cp=0
```

### 23.9 — homeos.olang — Trạng thái cuối session D8

```
File:          homeos.olang  9.31 MB
Magic:         OLNG  Version=18  NLayers=9
Nodes:         166,254 total
  L0: 1        (molecule table, cp=0, dnaLen=601)
  L1: 166,253  (Unicode chars)
Edges:         4,003  (BigEndian V2, 21B/edge)
Molecular DNA: 444 chars injected
  Latin      72 chars  avg=33B/char
  Greek      50 chars  avg=37B/char
  Cyrillic   32 chars  avg=46B/char
  Devanagari 15 chars  avg=45B/char
  Arabic     20 chars  avg=22B/char
  CJK       255 chars  avg=37B/char
Tests:         10/10 packages PASS ✅
SHA256:        valid ✅
Backup:        homeos.olang.bak_pre_molecular
```

### 23.10 — TIẾP THEO (Session E+)

```
🔴 ƯU TIÊN CAO:
  ① Fix 40 skills chưa nối vào agents
     File: internal/agents/loader.go + runtime.go
     Cần: AddSkill() cho LeoAI, AAM, HomeChief, Workers

  ② NCA chỉ PROPOSE, AAM mới APPROVE
     File: internal/nca/nca.go
     Thay commitCycle() → proposeCommit()
     AAM cần ProposalSkill nhận + user confirm

  ③ Resolve() cascade 84 boilerplate → shared util

🟠 SAU ĐÓ:
  ④ ClusterProposal → CommitCluster (Leaf→Twig thật)
  ⑤ Dream CROSS-CHECK với QR
  ⑥ Tách brain.go thêm
  ⑦ CJK expansion: 198 → 500 chars (cjk4.go, cjk5.go)

🟡 DÀI HẠN:
  ⑧ OlangNode unification (2 defs → 1)
  ⑨ WriteTo/ParseBytes format unification
  ⑩ Web renderer (MILESTONE 5)
  ⑪ Unihan_Readings.txt → EdgePhoneme silk edges
```

---

*Append-only. Cập nhật: 2026-03-11 · session D8*

---

## 24. Node Format V19 — NamesTable tách riêng (2026-03-11)

### 24.1 — Động lực thiết kế

```
Nguyên tắc: Node binary = ISL + DNA (thuần túy)
            Tên = metadata ngoài → NamesTable riêng

Lý do:
  ① Node binary không phụ thuộc vào tên → đổi tên không rebuild
  ② Edge chỉ cần ISL (src+dst) → routing thuần túy
  ③ NamesTable có thể drop hoàn toàn cho embedded workers
  ④ Tên có thể đa ngôn ngữ (nhiều NamesTable: vi/en/zh)
```

### 24.2 — File Layout V19

```
┌─────────────────────────────────────────────┐
│ header 280B                                  │
│   [0:4]  = "OLNG"                           │
│   [4:6]  = version = 19 (uint16 BE)         │
│   [8:12] = nodeCount (uint32 BE)            │
│   [16:20]= edgeCount (uint32 BE)            │
│   [28:32]= namesTableOffset (uint32 BE) ◄── │
├─────────────────────────────────────────────┤
│ nodes section                                │
│   "ND"+layer(1)+ISL(8)+cp(4)+dnaLen(4)+dna │
│   = 19 + dnaLen bytes per node             │
│   KHÔNG có nameLen field                    │
├─────────────────────────────────────────────┤
│ NamesTable  ← tại namesTableOffset          │
│   "NT" + count(4BE)                        │
│   + [isl(8)+nameLen(1)+name] × count       │
├─────────────────────────────────────────────┤
│ edges section  ← cuối file                  │
│   src(8)+dst(8)+type(1)+weight(4) = 21B    │
└─────────────────────────────────────────────┘
```

### 24.3 — NamesTable API

```go
// internal/olang/file.go
type NamesTable struct {
    Entries []NamesEntry        // ordered list
    byISL   map[uint64]string   // O(1) lookup
}

func NewNamesTable() *NamesTable
func (t *NamesTable) Add(isl uint64, name string)
func (t *NamesTable) Get(isl uint64) string   // "" nếu không có
func (t *NamesTable) Len() int
func (t *NamesTable) Bytes() []byte           // serialize binary
func ParseNamesTable(raw []byte) (*NamesTable, int) // (table, consumed)

// Constants:
const NamesTableMagic   = "NT"
const NodeHeaderSizeV19 = 19   // không có nameLen
const NodeHeaderSizeV18 = 20   // có nameLen (V18 compat)
```

### 24.4 — ParseBytes — Dual Format Detection

```go
// internal/olang/reader.go
func ParseBytes(raw []byte) (*ReadResult, error) {
    fileVersion := binary.BigEndian.Uint16(raw[4:6])
    isV19 := fileVersion >= 19

    if isV19 {
        // Fast path: đọc namesOffset từ header[28:32]
        namesOffset := int(binary.BigEndian.Uint32(raw[28:32]))
        parseNodesV19(raw, namesOffset, res)    // dừng tại NT start
        t, _ := ParseNamesTable(raw[namesOffset:])
        res.Names = t
        // Populate name cho mỗi node từ NamesTable
        for _, n := range res.Nodes {
            n.Name = res.Names.Get(n.ISLAddr)
        }
    } else {
        parseNodesV18(raw, edgeStart, res)      // đọc nameLen+name inline
    }
}

// ReadResult bổ sung:
type ReadResult struct {
    ...
    Names   *NamesTable  // non-nil nếu V19
    FileV19 bool
}
```

### 24.5 — olang_loader.go — V19 support

```go
// Detect V19 ngay khi vào hàm:
fileVersion := binary.BigEndian.Uint16(raw[4:6])
isV19 := fileVersion >= 19

// Parse nodes:
if isV19 {
    // header không có nameLen → dùng NodeHeaderSizeV19 = 19B
    // loadNamesTable sau để populate name
    names := loadNamesTable(raw, edgeStart)
    for idx := range records { records[idx].name = names.Get(islU) }
} else {
    // V18: nameLen tại raw[i+19], name sau DNA
}

// Edges: KHÔNG THAY ĐỔI — ISL only
// src(8)+dst(8)+type(1)+weight(4) = 21B — bất biến
```

### 24.6 — ws/node_lookup.go — build() V19 aware

```go
// Thêm ở đầu build():
fileVersion := binary.BigEndian.Uint16(raw[4:6])
isV19 := fileVersion >= 19

var namesTable *olang.NamesTable
if isV19 { namesTable = nl.loadNamesTable(raw, edgeStart) }

getName := func(isl8 [8]byte, inlineName string) string {
    if isV19 && namesTable != nil {
        return namesTable.Get(binary.BigEndian.Uint64(isl8[:]))
    }
    return inlineName
}

// hdrSize = 19 (V19) hoặc 20 (V18)
// scan nodes dùng hdrSize đúng
// name = getName(isl8, inlineName)  ← tự động chọn đúng source
```

### 24.7 — export.go — Hai encoder

```go
// V18 (backward compat) — có nameLen+name
func encodeNode(n *NodeRecord) []byte
// V19 (mới) — không có nameLen, dùng kèm NamesTable
func encodeNodeV19(n *NodeRecord) []byte
```

### 24.8 — cmd/migrate_v19/ — Migration tool

```
Usage: go run ./cmd/migrate_v19/ [input] [output]
       Default: homeos.olang → homeos.olang.v19

Steps:
  1. ParseBytes(V18) → 166,253 nodes, 4,003 edges
  2. Build NamesTable: 166,251 entries
  3. Rebuild nodes V19 (drop nameLen field)
  4. Set header: version=19, namesOffset=280+len(nodes)
  5. WriteFile: [header][nodesV19][NamesTable][edges]
  6. Verify ParseBytes(output): count khớp, Names non-nil

Result:
  V18: 9,759,118B (9.31MB)
  V19: 11,089,130B (11.0MB) — +13.6% do ISL overhead trong NT
  NamesTable: 6,119,319B, 166,251 entries
```

### 24.9 — Những thứ KHÔNG thay đổi

```
✅ Edges: src(8,BE)+dst(8,BE)+type(1)+weight(4,BE) = 21B
   → ISL only, không có name, không có DNA
   → Bất biến tuyệt đối

✅ ISL routing: isl.Address{Layer,Group,Type,ID}
   → Không thay đổi gì

✅ Agents/Skills: agent.go, skill registry, ExecContext
   → Không thay đổi gì

✅ Tests: 10/10 packages PASS ✅
```

### 24.10 — Tiếp theo sau V19

```
① Migrate homeos.olang → homeos.olang.v19 (đã có tool)
   → Dùng migrate_v19 → rename → homeos.olang

② Cập nhật vsdf_inject để ghi V19 format thay vì V18
   → vsdf_inject hiện ghi V18 (old format)
   → Cần thêm encodeNodeV19 + NamesTable builder

③ WorkerExport V19: có thể drop NamesTable
   → worker nhúng không cần tên
   → chỉ cần ISL + DNA

④ Multi-language NamesTable
   → NamesTable_vi, NamesTable_en, NamesTable_zh
   → load theo locale
   → header[32:36] = enNamesOffset, [36:40] = zhNamesOffset
```

---

*Append-only. Cập nhật: 2026-03-11 · Node Format V19*

---

## SESSION 2026-03-11 — Chat Test + Book Bug

### Phát hiện trong session này

#### ① `olang serve` command thiếu
`cmdRunFull()` đã viết trong `runtime.go` nhưng không được wire vào `main.go`.
`olang run` chỉ chạy CLI tĩnh, không có HTTP server.

**Fix đã làm:** thêm `case "serve"` vào switch trong `cmd/olang/main.go`:
```go
case "serve":
    cmdRunFull(path)
```

**Cách chạy server:**
```bash
go run ./cmd/olang/ serve homeos.olang
# HTTP tại :8080
```

#### ② `/api/chat` field name: `"text"` không phải `"message"`
ChatRequest struct dùng `json:"text"` — gửi `{"message":"..."}` trả về empty.

**Đúng:**
```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"text":"câu hỏi"}'
```

#### ③ SHA256 mismatch sau vsdf_inject
File `homeos.olang` cần reseal sau mỗi lần inject DNA:
```bash
go run ./cmd/olang/ reseal homeos.olang
```

#### ④ Book query bug — CHƯA FIX (để dành cho V19)
Khi load sách qua `read book /path/file.txt`, BookShelf lưu vào RAM OK.
Nhưng query về nội dung sách bị hijack bởi `NodeLookup.Search()` trước.

Ví dụ: query `"call_wild_clean cảm giác gì"` → NodeLookup match "clean" → trả về "sạch sẽ" thay vì BookShelf.

**Root cause:** `queryNode()` trong `brain_query_core.go` gọi `nodeLookup.Search()` ở bước 1, không check BookShelf trước.

**Fix cần làm trong V19:**
```go
// brain_query_core.go — queryNode() — thêm bước 0:
// 0. BookShelf check — nếu query chứa title đã đọc → respondAboutBook
if b.bookShelf != nil {
    if mem, title := b.bookShelf.Find(p.Lower); mem != nil {
        _ = title
        return b.resp("book", b.respondAboutBook(p.Lower, p.Lang))
    }
}
// 1. NodeLookup ... (giữ nguyên)
```

**KHÔNG fix bây giờ** — đang tập trung V19 migration.

### Chat hoạt động (verified)

```
xin chào          → greet ✅
bạn là ai         → identity ✅  
lửa là gì         → know ✅
mưa là gì         → know ✅
mạng nơ-ron là gì → know ✅
tắt đèn phòng khách → actuator ✅
```

Silk Tree: **40,658 nodes** tại thời điểm test.

---

---

## SESSION 2026-03-11 — Emotion Intent Bug

### ⑤ Emotion intent bị hijack bởi ParseDerivative — CHƯA FIX

**Triệu chứng:**
```
"cảm thấy thế nào" → tag=know (SAIT, nên là tag=emotion)
"bạn cảm thấy thế nào" → tag=know
"em cảm thấy thế nào" → tag=know
"bạn đang cảm thấy gì" → tag=emotion ✅ (may mắn)
```

**Root cause:** `brain_parse.go` gọi `ParseDerivative()` TRƯỚC `detectIntentFallback()`.

Câu `"cảm thấy thế nào"` → tokens `["cảm","thấy","thế","nào"]`
→ explainToks: `"thế"=0.4` + `"nào"=0.4` = `expScore=0.8` → DerExplain
→ return `IntentExplain` — bao giờ đến `detectIntentFallback` emotion check

**Fix cần làm trong V19** — 2 cách:

**Cách A (đơn giản):** Blacklist emotion keywords trong ParseDerivative:
```go
// score_search.go — ParseDerivative() — đầu hàm
emotionGuard := []string{
    "cảm thấy thế nào", "cảm xúc gì", "đang cảm thấy",
    "how do you feel", "what do you feel",
}
for _, g := range emotionGuard {
    if strings.Contains(lo, g) { return DerUnknown, slots }
}
```

**Cách B (đúng hơn):** Chạy `detectIntentFallback` TRƯỚC ParseDerivative cho các intent có priority cao (Emotion, Status, Greeting, Farewell):
```go
// brain_parse.go — detectIntent() — trước ParseDerivative block
// Priority intents: chạy fallback trước
if b.shouldPrioritizeFallback(lo) {
    return b.detectIntentFallback(lo, slots)
}
```

**KHÔNG fix bây giờ** — đang tập trung V19 migration.
Ưu tiên: Cách A (ít risk hơn, 5 dòng).

---

---

## SESSION 2026-03-11 — Capability Test: Tính toán & Logic

### Kết quả test khả năng Orio hiện tại

#### Tính toán số học: ❌ KHÔNG CÓ
```
"2 + 2 bằng mấy"          → dump SDF ký tự (không hiểu)
"tính 15 nhân 7"           → dump SDF ký tự
"căn bậc hai của 144"      → dump SDF ký tự
```
Không có skill tính toán. Parser thấy số → NodeLookup match ký tự Unicode.

#### Kiến thức toán học: ✅ TỐT
```
"đạo hàm của x bình phương" → f'(x)=lim(Δf/Δx) ✅
"tích phân của sin(x)"      → antiderivative, Newton-Leibniz ✅
```
Silk Tree có L5 PROG_* nodes với DNA toán học đúng.

#### Suy luận logic: ❌ KHÔNG CÓ
```
"nếu A lớn hơn B và B lớn hơn C thì A so với C thế nào"
→ confused, trả lời về "tiếng Anh"
```
Không có inference engine, chỉ lookup.

#### Triết học / mở: ❌ KHÔNG CÓ
```
"con gà có trước hay quả trứng có trước"
→ IntentRank → "con gà có trước" not found, "trứng" = tế bào sinh sản
```
Không có khả năng lập luận nhân quả hay triết học.

### Kết luận kiến trúc hiện tại

```
Orio = Knowledge Retrieval Engine
     ≠ Reasoning Engine
     ≠ Calculator

BIẾT:   định nghĩa, mô tả, liên kết ngữ nghĩa
KHÔNG BIẾT: tính toán, suy luận, lập luận nhân quả
```

### Skills cần thêm (roadmap sau V19)

```
CalcSkill       — eval biểu thức số học (2+2, sqrt(144), 15×7)
                  Impl: strconv + math package, không cần LLM
                  Trigger: câu có số + toán tử (+,-,×,÷,^,√)

LogicSkill      — suy luận transitivity, modus ponens đơn giản
                  "A > B, B > C → A > C"
                  Impl: ISL graph traversal + rule engine

PhilosophySkill — câu hỏi mở không có đáp án duy nhất
                  "con gà hay trứng" → trả lời đa chiều
                  Impl: lấy node liên quan + present both sides
                  (hoặc dùng Anthropic API cho reasoning phức tạp)
```

---

---

## SESSION 2026-03-11 — Web Fetch & Fact-Check Test

### WebFetchSkill — Trạng thái hiện tại

#### Skill hoạt động ✅
```
WebFetchSkill.CanHandle()  → true (URL bắt đầu https://)
WebFetchSkill.Execute()    → fetch HTTP, trả về body 64KB max
```

#### Domains được phép (egress policy)
```
✅ vnexpress.net     200 OK (65536 bytes)
✅ tuoitre.vn        200 OK (65536 bytes)
✅ example.com       200 OK (528 bytes)
✅ httpbin.org       200 OK
✅ ipinfo.io         200 OK
✅ zenquotes.io      200 OK
❌ wikipedia.org     403 Blocked by egress policy
❌ bbc.com           403 Blocked by egress policy
```

#### Vấn đề parsing HTML
VnExpress/Tuoi Tre bị truncate 64KB → phần lớn là CSS/JS inline,
content thật bị cắt mất. `stripHTML()` lọc được text nhưng không
tách được article title/body khỏi CSS garbage.

#### Fact-check logic — CÒN THÔ
Logic hiện tại: `strings.Contains(claim, keyword)` quá đơn giản:
```
"trái đất phẳng như mặt bàn"  → CÓ CƠ SỞ  (SAI — không detect negation)
"ánh sáng truyền với tốc độ không đổi" → CÓ THỂ SAI (SAI — "không" bị nhầm)
```
Không phân biệt được affirmation vs negation, không có semantic matching.

#### Chat interface — KHÔNG có WebFetch intent
Brain không route text → WebFetchSkill. Skill chỉ hoạt động qua ISL bus
trực tiếp, không qua `/api/chat`.

### Kết luận

```
Fetch web:    ✅ có thể (skill hoạt động)
Parse HTML:   ⚠️  thô — CSS/JS làm nhiễu, cần parser tốt hơn
Fact-check:   ❌ chưa có — cần semantic matching + negation detection
Chat trigger: ❌ chưa wire — Brain không có IntentWebFetch
```

### Việc cần làm (sau V19)

```
① IntentWebFetch — thêm vào brain_intent_fallback.go
   Trigger: "đọc trang", "fetch", "truy cập http", url trong text
   → ISL MsgQuery với payload = URL → WebFetchSkill

② HTML Parser tốt hơn
   - Strip CSS/JS trước khi parse
   - Tách <article>/<main> content
   - Tăng maxBytes lên 256KB hoặc fetch lazy

③ FactCheckSkill — so sánh web content với Silk Tree
   - NLP negation detection
   - Semantic matching qua ISL similarity
   - Verdict: ĐÚNG / SAI / KHÔNG XÁC NHẬN / MÂU THUẪN
```

---

---

## SESSION 2026-03-11 — Bug Sweep

### Tools chạy: `go vet`, `go test -race`, manual code review

---

### ✅ BUG ĐÃ FIX — json tag duplicate (utf32)

**File:** `internal/utf32/sdf_gen.go` + `internal/utf32/seeder.go`

**Lỗi:** Multi-field declaration với json tag chỉ apply cho field đầu:
```go
// TRƯỚC (BUG)
Ax, Ay, Az float32 `json:"ax"`  // Ay và Az cũng dùng tag "ax" → parse sai
Bx, By, Bz float32 `json:"bx"`

// SAU (FIX)
Ax float32 `json:"ax"`
Ay float32 `json:"ay"`
Az float32 `json:"az"`
Bx float32 `json:"bx"`
By float32 `json:"by"`
Bz float32 `json:"bz"`
```

**Impact:** Capsule Y/Z coordinates của SDF strokes bị parse sai (= 0) khi
load từ JSON → chữ viết vsdf_inject bị méo theo trục Y/Z.

**Status:** ✅ FIXED · `go vet` clean · 10/10 tests PASS

---

### 🔴 BUG — NodeLookup stale sau Learn (không tự refresh)

**File:** `internal/ws/node_lookup.go`

**Lỗi:** `NodeLookup` được build 1 lần khi `NewBrain()` — không rebuild khi
node mới được ghi vào `homeos.olang` qua `Learn()` / QR commit.

**Hệ quả:**
```
User: "nhớ rằng zorblax là sinh vật ngoài hành tinh"
Orio: ✓ Ghi vào ĐN (fire=1/3)

User: "zorblax là gì"
Orio: Ý bạn là: quỹ đạo · màu đen · thiên hà?   ← NodeLookup không biết!

User: "zorblax"
Orio: [ĐN] zorblax = một sinh vật ngoài hành tinh  ← ShortTerm.Search() thấy
```

NodeLookup miss, ShortTerm.Search() bắt được → UX không nhất quán.
Sau QR commit (fire=3) → ghi vào file → NodeLookup vẫn stale.

**Fix cần làm (V19):**
```go
// node_lookup.go — thêm method Refresh
func (nl *NodeLookup) Refresh() {
    nl.byISLU  = make(map[uint64]*KnownNode)
    nl.byLabel = make(map[string]*KnownNode)
    nl.byName  = make(map[string]*KnownNode)
    nl.build()
    nl.buildAdjCache()
    nl.buildTokenIndex()
}

// brain_learn.go — sau mỗi QR commit
// hoặc sau mỗi Learn() với fire==1 (thêm vào ĐN → cần thấy ngay)
if b.nodeLookup != nil {
    go b.nodeLookup.Refresh() // async để không block response
}
```

---

### 🟡 BUG — EmotionHistory.Edges unbounded growth

**File:** `internal/agents/emotion_query.go`

**Lỗi:** `EmotionHistory.Edges []EmotionEdge` không có giới hạn size.
Mỗi chat message → append 1 edge → memory tăng dần, không bao giờ prune.

**Impact:** Session chat dài hàng nghìn messages → memory leak.
ConversationCurve có `WindowSize` limit → OK. EmotionHistory thì không.

**Fix đơn giản:**
```go
const maxEmotionEdges = 500

func (h *EmotionHistory) Add(tag EmotionTag, ctx EmotionContext, text string) {
    h.Edges = append(h.Edges, EmotionEdge{...})
    if len(h.Edges) > maxEmotionEdges {
        h.Edges = h.Edges[len(h.Edges)-maxEmotionEdges:] // keep newest 500
    }
}
```

---

### ℹ️  KNOWN — Bus message drop silent

**File:** `internal/agents/bus.go`

**Thiết kế có chủ ý:** Khi inbox agent đầy → drop silently.
Không có counter/metric → khó debug khi bị drop dưới production.

**Ghi nhận, không fix** — thêm counter sau khi có metrics system.

---

### Trạng thái sau sweep

```
go vet:        CLEAN ✅  (trước: 8 warnings)
go test ./...: 10/10 PASS ✅
go test -race: PASS ✅ (agents, ws, memory, nca)
```

---

---

## HANDOFF V19 — Việc cần làm ngay khi bắt đầu chat mới

> Đọc file này → giải nén → chạy được luôn, không cần hỏi thêm.

### Trạng thái repo hiện tại

```
File:        homeos.olang  (V18, 9.31MB)
homeos.olang.v19 đã tạo nhưng CHƯA replace homeos.olang
Tests:       10/10 PASS (go test ./...)
go vet:      CÓ warnings (intentional, chưa fix)
Branch:      main
```

### Bước 1 — Migrate V18 → V19 (việc đầu tiên)

```bash
cd /path/to/Origin
go run ./cmd/migrate_v19/ homeos.olang homeos.olang.v19.new
# kiểm tra
go run ./cmd/olang/ info homeos.olang.v19.new
# nếu OK → replace
mv homeos.olang homeos.olang.v18.bak
mv homeos.olang.v19.new homeos.olang
go run ./cmd/olang/ reseal homeos.olang
go test ./...
```

---

### Bugs đã tìm thấy — FIX TRONG V19

#### BUG 1 — json tag duplicate (go vet warning, data parse sai)
**File:** `internal/utf32/sdf_gen.go:330` và `internal/utf32/seeder.go:459`

```go
// HIỆN TẠI (BUG) — Ay/Az cũng dùng tag "ax" → parse ra 0
Ax, Ay, Az float32 `json:"ax"`
Bx, By, Bz float32 `json:"bx"`

// FIX — tách riêng từng field
Ax float32 `json:"ax"`
Ay float32 `json:"ay"`
Az float32 `json:"az"`
Bx float32 `json:"bx"`
By float32 `json:"by"`
Bz float32 `json:"bz"`
```

**Impact:** Capsule SDF strokes bị méo trục Y/Z (Ay=Az=0) khi load từ JSON.
**Áp dụng cho cả 2 file, cả float32 lẫn float64.**

---

#### BUG 2 — NodeLookup stale sau Learn() / QR commit
**File:** `internal/ws/node_lookup.go`

NodeLookup build 1 lần khi `NewBrain()`, không tự refresh khi node mới
được ghi vào `homeos.olang` qua `Learn()` hoặc QR commit.

```
Symptom đã verify:
  User:  "nhớ rằng zorblax là sinh vật ngoài hành tinh"
  Orio:  ✓ Ghi vào ĐN (fire=1/3)
  User:  "zorblax là gì"
  Orio:  Ý bạn là: quỹ đạo · màu đen?   ← BUG: NodeLookup không biết
  User:  "zorblax"
  Orio:  [ĐN] zorblax = sinh vật ngoài hành tinh  ← ShortTerm.Search() thấy
```

**Fix:**
```go
// node_lookup.go — thêm method
func (nl *NodeLookup) Refresh() {
    nl.byISLU  = make(map[uint64]*KnownNode)
    nl.byLabel = make(map[string]*KnownNode)
    nl.byName  = make(map[string]*KnownNode)
    nl.build()
    nl.buildAdjCache()
    nl.buildTokenIndex()
}

// brain_learn.go — gọi sau mỗi ghi node vào file
if b.nodeLookup != nil {
    go b.nodeLookup.Refresh() // async, không block response
}
```

---

#### BUG 3 — EmotionHistory.Edges unbounded growth
**File:** `internal/agents/emotion_query.go:42`

```go
// HIỆN TẠI (BUG) — không có giới hạn, leak nếu chat dài
func (h *EmotionHistory) Add(tag EmotionTag, ctx EmotionContext, text string) {
    h.Edges = append(h.Edges, EmotionEdge{...})
    // không prune!
}

// FIX — thêm 3 dòng
const maxEmotionEdges = 500
func (h *EmotionHistory) Add(...) {
    h.Edges = append(h.Edges, EmotionEdge{...})
    if len(h.Edges) > maxEmotionEdges {
        h.Edges = h.Edges[len(h.Edges)-maxEmotionEdges:]
    }
}
```

---

#### BUG 4 (Known, không urgent) — Bus message drop silent
**File:** `internal/agents/bus.go:106,147`

Inbox agent đầy → drop silently, không có counter/log.
Thiết kế có chủ ý (Silent by default) nhưng khó debug production.
Fix: thêm `atomic.AddInt64(&b.dropCount, 1)` + expose qua `/api/agents`.

---

#### BUG 5 (Known) — 2 tests FAIL (từ sessions trước)
```
TestSilkWalkEdgesWork  → transformer not found
TestGlowNodeOnQuery    → "sợ hãi" không có định nghĩa trong L3
```
Không block V19. Fix sau khi có thêm L3 nodes.

---

### Roadmap V19 (sau migrate xong)

```
① Fix BUG 1,2,3 ở trên
② vsdf_inject cập nhật → ghi V19 format (encodeNodeV19 + NamesTable)
③ IntentWebFetch — brain nhận URL trong text → gọi WebFetchSkill
   Trigger: "đọc trang", "truy cập http", "fetch https://..."
④ NCA: commitCycle() → proposeCommit() (chỉ PROPOSE, AAM mới APPROVE)
⑤ Wire 40 skills còn lại vào agents (xem MASTER.md Phần IX)
⑥ ClusterProposal → CommitCluster thật (Leaf→Twig)
⑦ MILESTONE: 5000 L3 nodes (hiện 3,117)
```

---

### Lệnh thường dùng

```bash
# Chạy server
go run ./cmd/olang/ reseal homeos.olang
go run ./cmd/olang/ serve homeos.olang

# Chat test
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"text":"xin chào"}'

# Xem stats
go run ./cmd/olang/ info homeos.olang

# Chạy test
go test ./...
go test -race ./internal/agents/ ./internal/ws/
go vet ./...
```

---

---

## LƯU Ý FILE homeos.olang.v19

File `homeos.olang.v19` **KHÔNG dùng được**:
```
SHA256:  ❌ MISMATCH
Nodes:   58,953  (thiếu ~107K nodes so với V18)
```

→ **Phải chạy lại migrate từ V18 trong chat mới:**
```bash
go run ./cmd/migrate_v19/ homeos.olang homeos.olang.v19.new
go run ./cmd/olang/ reseal homeos.olang.v19.new
go run ./cmd/olang/ info homeos.olang.v19.new   # verify nodes == 166253
mv homeos.olang homeos.olang.v18.bak
mv homeos.olang.v19.new homeos.olang
```

File V18 (`homeos.olang`) là **bản duy nhất hợp lệ**:
```
SHA256:  ✅ verified
Nodes:   166,253
```

---

## SESSION 2026-03-11 — V19 Migration Hoàn Chỉnh + Bước 3-6

### Trạng thái repo hiện tại

```
File:        homeos.olang (V19, 10.6MB) — ĐÃ REPLACE
Tests:       10/10 PASS ✅
go vet:      CLEAN ✅
Build:       OK ✅
Nodes:       166,452 (V19, đã phục hồi 199 missing nodes từ V18)
Edges:       4,003
SHA256:      ✅ verified
```

### V19 Binary — Đã verify

```
Version:          19
namesTableOffset: header[28:32] (uint32 BE)
SHA256:           header[32:64] (32B) ← khác V18 [28:60]
Node format:      "ND"+layer(1)+ISL(8)+cp(4)+dnaLen(4)+dna = 19B header (không có nameLen)
NamesTable:       "NT"+count(4BE)+[isl(8)+nameLen(1)+name]×N
Edges:            src(8)+dst(8)+type(1)+weight(4) = 21B — bất biến
```

### Bugs đã fix trong session này

```
✅ BUG1 — json tag duplicate (sdf_gen.go + seeder.go)
   Ax,Ay,Az float32 `json:"ax"` → tách riêng từng field
   Impact: Capsule SDF strokes không bị méo Y/Z nữa

✅ BUG2 — NodeLookup stale sau Learn()
   + node_lookup.go: Refresh() method (rebuild byISLU/byLabel/byName/adjCache/tokIdx)
   + append_olang.go: V19-aware record format + SHA offset + NamesTable update + OnNodeAppended hook
   + brain_types.go: NewBrain() đăng ký OnNodeAppended = func() { b.nodeLookup.Refresh() }

✅ BUG3 — EmotionHistory unbounded growth
   + emotion_query.go: const maxEmotionEdges = 500, prune trong Add()

✅ cmd/olang/main.go — SHA V19-aware (reseal + info + verify)
   V19: SHA tại [32:64], V18: SHA tại [28:60]
   Fix cả SHA read (parseFile) lẫn SHA write (reseal + prune command)
```

### SHA offset — Quy tắc mới (BẤT BIẾN)

```
Version < 19: SHA tại raw[28:60]  (V18)
Version >= 19: SHA tại raw[32:64] (V19, vì [28:32] = namesTableOffset)

Luôn detect version trước khi đọc/ghi SHA:
  isV19 := binary.BigEndian.Uint16(raw[4:6]) >= 19
  shaOff := 28; if isV19 { shaOff = 32 }
```

### Bước 3 — BookShelf Bug ✅

**File:** `internal/ws/brain_query_core.go` — `queryNode()`

**Vấn đề:** Query về sách bị hijack bởi `NodeLookup.Search()` trước khi check BookShelf.

**Fix:**
```go
// queryNode() — thêm bước 0 đầu tiên
if b.bookShelf != nil {
    if mem, _ := b.bookShelf.Find(p.Lower); mem != nil {
        return b.resp("book", b.respondAboutBook(p.Lower, p.Lang))
    }
}
```

### Bước 4 — Emotion Intent Bug ✅

**File:** `internal/ws/score_search.go` — `ParseDerivative()`

**Vấn đề:** `"cảm thấy thế nào"` → tokens có `"thế","nào"` → DerExplain (sai).

**Fix:**
```go
// Đầu hàm ParseDerivative — guard emotion keywords
emotionGuard := []string{
    "cảm thấy thế nào", "cảm xúc gì", "đang cảm thấy",
    "how do you feel", "bạn cảm thấy",
}
for _, g := range emotionGuard {
    if strings.Contains(lo, g) { return DerUnknown, slots }
}
```

### Bước 5 — CalcSkill ✅

**Files mới:** `internal/ws/brain_calc.go`

**Tính năng:**
```
2+2, 15×7, 100/4, 2**10      — biểu thức cơ bản
căn bậc hai 144, sqrt 81      — căn bậc hai
bình phương 12, 12**2          — bình phương
20% của 300, 15 phần trăm 200  — phần trăm
(3+4)*2                        — ngoặc đơn
tính 1000/8                    — trigger keyword
```

**Intent trigger (`brain_intent_fallback.go`):**
```go
if expr, ok := detectCalcExpr(lo); ok {
    slots["expr"] = expr
    return IntentCalc
}
```

**Parser:** Recursive descent, không dùng thư viện ngoài:
```
parseExpr → parseTerm → parsePower → parseUnary → parsePrimary
+,-          *,/,%       **           unary±       số/(expr)
```

**Quy tắc trigger `detectCalcExpr()`:**
- Prefix: `tính`, `calculate`, `compute`, `eval`
- Keywords: `căn bậc hai`, `sqrt`, `√`, `bình phương`, `squared`
- Regex: `X% của Y`, `X phần trăm của Y`
- Biểu thức: có số + toán tử, ≤60 ký tự, wordCount ≤ numCount×3

### Bước 6 — IntentWebFetch ✅

**Files mới:** `internal/ws/brain_webfetch.go`

**Tính năng:**
```
đọc trang https://example.com  — fetch và tóm tắt
fetch https://...               — trigger keyword
tóm tắt web ...                 — prefix
https://... (URL trực tiếp)     — auto-detect
```

**Pipeline:**
```
detectWebFetchIntent() → extract URL
    ↓
httpClient.Get(url)    — timeout 10s, 512KB max
    ↓
stripHTML()            — xóa script/style/head + tags
decodeHTMLEntities()   — &amp; &lt; &nbsp; etc.
collapseWhitespace()   — normalize spaces/lines
    ↓
Truncate 800 runes + title
    ↓
"**Title**\n*Nguồn: URL*\n\nContent..."
```

**HTML stripper:** Regex-based, không dùng thư viện ngoài.
Lưu ý: `\1` backreference không hợp lệ trong Go regexp → dùng union pattern thay thế.

**Error handling:**
```
timeout:          → "timeout (>10s)"
no such host:     → "không tìm thấy host"
connection refused→ "kết nối bị từ chối"
HTTP 4xx/5xx:     → "Trang trả lỗi XXX"
empty content:    → thông báo rõ ràng
```

### Intent mới thêm vào

```go
// brain_types.go
IntentCalc      // 2+2, 15×7, căn bậc hai 144, tính X
IntentWebFetch  // đọc trang X, fetch URL, tóm tắt web X
```

### Files thay đổi trong session này

```
MODIFIED (8 files):
  cmd/olang/main.go              — SHA V19-aware (read + write)
  internal/utf32/sdf_gen.go      — BUG1: json tag split
  internal/utf32/seeder.go       — BUG1: json tag split
  internal/ws/node_lookup.go     — BUG2: Refresh() method
  internal/ws/append_olang.go    — BUG2: V19 record + SHA offset + NamesTable
  internal/ws/brain_types.go     — BUG2: OnNodeAppended + IntentCalc + IntentWebFetch
  internal/ws/brain_query_core.go — Bước 3: BookShelf check
  internal/ws/score_search.go    — Bước 4: emotion guard
  internal/agents/emotion_query.go — BUG3: maxEmotionEdges=500
  internal/ws/brain_intent.go    — case IntentCalc + IntentWebFetch

CREATED (2 files):
  internal/ws/brain_calc.go      — Bước 5: CalcSkill
  internal/ws/brain_webfetch.go  — Bước 6: WebFetchSkill
```

### Cách chạy server

```bash
# Giải nén TAR mới
tar xf homeos_v19_final.tar -C ~/HomeOS
cd ~/HomeOS

# Verify
go test ./...   # phải 10/10 PASS
go build ./...  # phải OK
go run ./cmd/olang/ info homeos.olang  # nodes, SHA ✅

# Chạy server
go run ./cmd/olang/ serve homeos.olang
# HTTP tại :8080

# Chat test
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"text":"xin chào"}'

curl -X POST http://localhost:8080/api/chat \
  -d '{"text":"tính 2+2"}'        # → calc ✅

curl -X POST http://localhost:8080/api/chat \
  -d '{"text":"căn bậc hai 144"}' # → calc ✅

curl -X POST http://localhost:8080/api/chat \
  -d '{"text":"đọc trang https://example.com"}' # → web ✅
```

### Backlog cập nhật

```
✅ DONE — BUG1 json tag duplicate
✅ DONE — BUG2 NodeLookup stale
✅ DONE — BUG3 EmotionHistory leak
✅ DONE — V19 SHA-aware (info/reseal/verify)
✅ DONE — Bước 3: BookShelf bug
✅ DONE — Bước 4: Emotion intent bug
✅ DONE — Bước 5: CalcSkill
✅ DONE — Bước 6: IntentWebFetch

🔴 TIẾP THEO:
  ① NCA: commitCycle() → proposeCommit() (chỉ PROPOSE, AAM mới APPROVE)
  ② Wire 40 skills còn lại vào agents
  ③ vsdf_inject → ghi V19 format
  ④ ClusterProposal → CommitCluster thật
  ⑤ LogicSkill — suy luận transitivity đơn giản
  ⑥ MILESTONE: 5000 L3 nodes (hiện ~3,118)
  ⑦ Multi-language NamesTable (vi/en/zh)
  ⑧ HTML Parser tốt hơn cho WebFetch (tách article/main content)
  ⑨ FactCheckSkill — so sánh web content với Silk Tree
  ⑩ Bus drop counter + metrics endpoint
```

---

*Append-only. Cập nhật: 2026-03-11 · V19 + Bước 3-6*
