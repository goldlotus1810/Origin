package memory

import (
	"testing"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// ─────────────────────────────────────────────────────────────────
// Helper: tạo SDF bytes 15B từ string (cho test)
// ─────────────────────────────────────────────────────────────────
func makeSDF(s string) []byte {
	b := make([]byte, 15)
	copy(b, []byte(s))
	return b
}

func hashOf(s string) isl.NodeHash {
	var sdf [15]byte
	copy(sdf[:], []byte(s))
	return isl.HashSDF(sdf)
}

// ─────────────────────────────────────────────────────────────────
// TEST 1: NodeHash là key duy nhất, không phải ISL
// ─────────────────────────────────────────────────────────────────

func TestIdentity_HashNotISL(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(nil, nil)

	// Hai observations: cùng ISL, khác nội dung SDF
	// → phải tạo 2 nodes riêng biệt (KHÔNG phải duplicate)
	sameISL := isl.Address{Layer: 0x03, Group: 1, Type: 1, ID: 1}

	r1 := dn.Observe(Observation{
		ISL:  sameISL,
		Data: makeSDF("BIRD_SDF_1"),
	}, qr)

	r2 := dn.Observe(Observation{
		ISL:  sameISL,
		Data: makeSDF("FISH_SDF_2"),
	}, qr)

	if r1 != ResultCreated {
		t.Errorf("observation 1: got %s, want Created", r1)
	}
	if r2 != ResultCreated {
		t.Errorf("observation 2 (same ISL, diff hash): got %s, want Created (NOT duplicate)", r2)
	}

	// Count phải là 2 — không phải 1
	nodes := dn.GetByISL(sameISL)
	if len(nodes) != 2 {
		t.Errorf("GetByISL: got %d nodes, want 2 (ISL là spatial coord, không phải unique key)", len(nodes))
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST 2: Hash trùng ĐN → REINFORCE (không tạo mới)
// ─────────────────────────────────────────────────────────────────

func TestReinforce_SameHash(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(nil, nil)

	data := makeSDF("LOVE_SDF_CONST")
	h    := hashOf("LOVE_SDF_CONST")

	// Lần 1: tạo mới
	r1 := dn.Observe(Observation{
		ISL:  isl.Address{Layer: 0x60, Group: 1, Type: 1, ID: 1},
		Data: data,
	}, qr)
	if r1 != ResultCreated {
		t.Errorf("lần 1: got %s, want Created", r1)
	}

	// Lần 2: cùng SDF content → reinforce
	r2 := dn.Observe(Observation{
		ISL:  isl.Address{Layer: 0x60, Group: 2, Type: 1, ID: 5}, // ISL khác cũng không quan trọng
		Data: data,
	}, qr)
	if r2 != ResultReinforced {
		t.Errorf("lần 2: got %s, want Reinforced", r2)
	}

	// Kiểm tra fire_count = 2
	obs, ok := dn.GetByHash(h)
	if !ok {
		t.Fatal("không tìm thấy observation")
	}
	if obs.FireCount != 2 {
		t.Errorf("FireCount=%d, want 2", obs.FireCount)
	}

	// Count vẫn là 1
	if dn.Count() != 1 {
		t.Errorf("Count=%d, want 1", dn.Count())
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST 3: Hash trùng QR → DISCARD (không học lại)
// ─────────────────────────────────────────────────────────────────

func TestDiscard_AlreadyInQR(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(newMockGraph(), nil)

	data := makeSDF("SPHERE_PRIMITIVE")
	h    := hashOf("SPHERE_PRIMITIVE")

	// Giả lập: SDF này đã có trong QR (đã chứng minh)
	qr.byHash[h] = &qrEntry{hash: h, weight: 100}

	// Gửi observation với SDF đó
	result := dn.Observe(Observation{
		ISL:  isl.Address{Layer: 0x00, Group: 1, Type: 1, ID: 1},
		Data: data,
	}, qr)

	if result != ResultDiscarded {
		t.Errorf("got %s, want Discarded (đã có trong QR)", result)
	}

	// ĐN vẫn rỗng — không tạo node mới
	if dn.Count() != 0 {
		t.Errorf("ĐN count=%d, want 0", dn.Count())
	}

	// QR node được reinforce
	if qr.byHash[h].weight <= 100 {
		t.Error("QR node phải được reinforce khi discard")
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST 4: Cùng SDF, khác ngữ cảnh = cùng node (KHÔNG tạo mới)
// ─────────────────────────────────────────────────────────────────

func TestSameContent_DifferentContext(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(nil, nil)

	// "Cây ở Đà Lạt" và "Cây ở Đà Nẵng" — SDF giống hệt
	treeSDF := makeSDF("CONIFER_TREE_SDF")
	h       := hashOf("CONIFER_TREE_SDF")

	dn.Observe(Observation{
		ISL:   isl.Address{Layer: 0x03, Group: 3, Type: 1, ID: 1},
		Data:  treeSDF,
		Label: "cây thông ở Đà Lạt",
	}, qr)

	// Cùng SDF, ngữ cảnh khác → reinforce, không tạo mới
	r := dn.Observe(Observation{
		ISL:   isl.Address{Layer: 0x03, Group: 3, Type: 1, ID: 1},
		Data:  treeSDF,
		Label: "cây thông ở Đà Nẵng",
	}, qr)

	if r != ResultReinforced {
		t.Errorf("cùng SDF khác ngữ cảnh: got %s, want Reinforced", r)
	}

	// Vẫn 1 node — ngữ cảnh = BOND edges, không phải node mới
	if dn.Count() != 1 {
		t.Errorf("Count=%d, want 1 (ngữ cảnh là edges, không phải nodes mới)", dn.Count())
	}

	// FireCount = 2 (thấy 2 lần)
	obs, _ := dn.GetByHash(h)
	if obs.FireCount != 2 {
		t.Errorf("FireCount=%d, want 2", obs.FireCount)
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST 5: Vòng đời đầy đủ ĐN → QR
// ─────────────────────────────────────────────────────────────────

func TestLifecycle_DN_to_QR(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(newMockGraph(), nil)

	data := makeSDF("LOVE_CONCEPT_SDF")
	h    := hashOf("LOVE_CONCEPT_SDF")

	// Bước 1: observe
	dn.Observe(Observation{
		ISL:   isl.Address{Layer: 0x60, Group: 1, Type: 1, ID: 1},
		Data:  data,
		Label: "LOVE",
	}, qr)

	// Bước 2: user confirm nhiều lần → confidence tăng
	for i := 0; i < 5; i++ {
		dn.Confirm(h)
	}

	obs, _ := dn.GetByHash(h)
	if obs.Confidence < 0.8 {
		t.Errorf("sau 5 confirms, confidence=%.2f phải >= 0.8", obs.Confidence)
	}

	// Bước 3: Dream promote lên QR
	err := qr.Commit(*obs)
	if err != nil {
		t.Fatalf("Commit error: %v", err)
	}
	dn.MarkArchived(h)

	// Kiểm tra:
	if !qr.HasHash(h) {
		t.Error("QR phải có hash sau commit")
	}

	// Bước 4: observe lại cùng SDF → DISCARD (đã trong QR)
	r := dn.Observe(Observation{Data: data}, qr)
	if r != ResultDiscarded {
		t.Errorf("sau khi promote: got %s, want Discarded", r)
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST 6: Confirm/Reject confidence
// ─────────────────────────────────────────────────────────────────

func TestConfidence_ConfirmReject(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(nil, nil)

	h := hashOf("SOME_NODE_SDF")
	dn.Observe(Observation{Data: makeSDF("SOME_NODE_SDF")}, qr)

	// Confirm nhiều → confidence tăng
	dn.Confirm(h); dn.Confirm(h); dn.Confirm(h)
	obs, _ := dn.GetByHash(h)
	confAfterConfirm := obs.Confidence

	// Reject nhiều → confidence giảm
	dn.Reject(h); dn.Reject(h); dn.Reject(h); dn.Reject(h); dn.Reject(h); dn.Reject(h)
	obs, _ = dn.GetByHash(h)
	confAfterReject := obs.Confidence

	if confAfterReject >= confAfterConfirm {
		t.Errorf("sau reject, conf=%.2f phải nhỏ hơn sau confirm=%.2f",
			confAfterReject, confAfterConfirm)
	}

	// Node bị reject nhiều → StateRefuted (nhưng vẫn còn trong ĐN — append-only)
	if obs.State != StateRefuted {
		t.Errorf("state=%v, want StateRefuted", obs.State)
	}
	// Vẫn còn trong map (không xóa)
	_, stillThere := dn.GetByHash(h)
	if !stillThere {
		t.Error("append-only: node bị refuted vẫn phải còn trong ĐN")
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST 7: GetByISL trả về nhiều nodes (hàng xóm ngữ nghĩa)
// ─────────────────────────────────────────────────────────────────

func TestGetByISL_MultipleNeighbors(t *testing.T) {
	dn := NewShortTerm(512)
	qr := NewLongTerm(nil, nil)

	// Cùng vùng ISL (layer=L3.Life, group=Animal)
	animalISL := isl.Address{Layer: 0x03, Group: 1, Type: 1, ID: 1}

	// 5 loài khác nhau, cùng vùng ISL
	species := []string{"CAT_SDF", "DOG_SDF", "BIRD_SDF", "FISH_SDF", "BEE_SDF"}
	for _, s := range species {
		dn.Observe(Observation{
			ISL:  animalISL,
			Data: makeSDF(s),
		}, qr)
	}

	neighbors := dn.GetByISL(animalISL)
	if len(neighbors) != 5 {
		t.Errorf("GetByISL: got %d hàng xóm, want 5", len(neighbors))
	}
}

// ─────────────────────────────────────────────────────────────────
// Helper: mock SilkGraph (không dùng file)
// ─────────────────────────────────────────────────────────────────

func newMockGraph() *silk.SilkGraph {
	return silk.NewSilkGraph()
}
