// qt9_integration_test.go
//
// Test end-to-end: viết 9 QT như người dùng thật
// → hệ thống kiểm tra bản chất → sắp xếp đúng layer → ghi vào .olang
//
// Luồng mô phỏng:
//   user → MsgLearn(immutable=true) → DNFireSkill → ShortTerm(ĐN)
//   → Dream.process() → LongTerm.Commit() → QRWriter.Persist() → .olang
//
// QT7: đây chính là vòng đời ĐN→QR đang được test.
// QT8: kết quả phải append-only (không overwrite).
// QT4: mỗi QT phải tồn tại với đúng bản chất của nó.

package memory

import (
	"fmt"
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// ─── 9 QT như người dùng viết ra ────────────────────────────────────────────

type QTInput struct {
	ID      int
	Symbol  string // UTF-32 symbol chính
	CP      uint32 // codepoint của symbol chính
	Name    string // tên ngắn
	Text    string // nội dung đầy đủ như người dùng viết
	L0Ops   []byte // L0 opcodes liên quan (để verify placement)
}

var NineQTs = []QTInput{
	{
		ID: 1, Symbol: "○", CP: 0x25CB,
		Name: "QT1_NGUON_GOC",
		Text: "QT1: ○ LÀ NGUỒN GỐC. ○ == WORLDTREE == ORIGIN == FUNCTION. Mọi thứ đều là instance của ○. ○(x)==x identity. ○(∅)==○ tự tạo sinh. mọi f==○[f].",
		L0Ops: []byte{0x60}, // OP_SEQ = ○
	},
	{
		ID: 2, Symbol: "∞", CP: 0x221E,
		Name: "QT2_INF_SAI",
		Text: "QT2: ∞ LÀ SAI — ∞-1 MỚI ĐÚNG. ∞ == không tồn tại. ∞-1 == tồn tại thật (hữu hạn, nhưng rất lớn/rất nhỏ). Executor BLOWN khi gặp ∞.",
		L0Ops: []byte{0xFF, 0x05}, // OP_GATE (enforce), OP_VOID (∞-1)
	},
	{
		ID: 3, Symbol: "⧺", CP: 0x29BA,
		Name: "QT3_VAT_LY_SU_THAT",
		Text: "QT3: TOÁN HỌC LÀ TRỪU TƯỢNG — VẬT LÝ LÀ SỰ THẬT. +/- == trừu tượng, chưa chắc đúng. ⧺ == thêm vào vật lý (đã chứng minh). ⊖ == bớt đi vật lý. == == chắc chắn. Quá trình: quan sát → +/- → chứng minh → ==.",
		L0Ops: []byte{0x70, 0x71}, // OP_ADD, OP_SUB_N
	},
	{
		ID: 4, Symbol: "≔", CP: 0x2254,
		Name: "QT4_BAN_CHAT_TON_TAI",
		Text: "QT4: BẢN CHẤT — MỌI THỨ TỒN TẠI VỚI BẢN CHẤT CỦA NÓ. Agent == tập hợp Skill (không hơn không kém). Định nghĩa == mô tả bản chất. Trong Định Nghĩa: chỉ dùng ⧺ / ⊖ / ==.",
		L0Ops: []byte{}, // concept — không map trực tiếp L0 op
	},
	{
		ID: 5, Symbol: "∈", CP: 0x2208,
		Name: "QT5_BAN_CHAT_VI_TRI",
		Text: "QT5: BẢN CHẤT QUYẾT ĐỊNH VỊ TRÍ. Cùng bản chất → cùng nhóm. Tương đồng bản chất → xếp gần nhau. Nhóm thuộc nhóm → cấp độ cao hơn xây trên cấp độ thấp hơn. SDF ⧺ ISL == Smooth_union.",
		L0Ops: []byte{0x50, 0x51}, // OP_GET (∈ lookup), OP_WALK
	},
	{
		ID: 6, Symbol: "∪", CP: 0x222A,
		Name: "QT6_CAC_NHOM",
		Text: "QT6: CÁC NHÓM QUANH ○. Ngôn ngữ / Khoa học / Sinh vật / Định luật / Nguyên tố / Hiện tượng. SDF == hữu hình (đo được, cảm nhận trực tiếp). ISL == vô hình (ý tưởng, quan hệ, cảm xúc). SDF ⧺ ISL == Smooth_union.",
		L0Ops: []byte{0x10}, // OP_UNION = SmoothUnion
	},
	{
		ID: 7, Symbol: "Δ", CP: 0x0394,
		Name: "QT7_HOC_LEAD",
		Text: "QT7: HỌC / LEAD — QR vs ĐN. QR == Định Nghĩa đã chứng minh · bộ nhớ dài hạn · cần cấp phép. ĐN == Định Nghĩa đang học · bộ nhớ ngắn hạn · tự do thay đổi. Vòng đời: quan sát → ĐN (+/-) → chứng minh → QR (==). Correction: người dùng bác bỏ → ĐN bị xóa.",
		L0Ops: []byte{0x63, 0x52}, // OP_DREAM, OP_EMIT
	},
	{
		ID: 8, Symbol: "⊕", CP: 0x2295,
		Name: "QT8_LICH_SU_BAT_BIEN",
		Text: "QT8: LỊCH SỬ BẤT BIẾN. Append-only: không DELETE, không OVERWRITE. Phục hồi trạng thái t = replay đến timestamp t. ED25519 signed. Mọi ghi chép là vĩnh cửu.",
		L0Ops: []byte{0x62}, // OP_LOOP (replay = loop through history)
	},
	{
		ID: 9, Symbol: "🛡", CP: 0x1F6E1,
		Name: "QT9_KHONG_SAI_LECH",
		Text: "QT9: KHÔNG THÔNG TIN SAI LỆCH. SecurityGate Rule 1: Không hại con người (tuyệt đối). Không ai ghi đè Rule 1 — kể cả LeoAI. Gate = 0xFF = bất biến tuyệt đối.",
		L0Ops: []byte{0xFF}, // OP_GATE
	},
}

// ─── Test chính ────────────────────────────────────────────────────────────

// TestWrite9QTs_ToOlang — viết 9 QT, verify hệ thống tự ghi vào .olang
func TestWrite9QTs_ToOlang(t *testing.T) {
	// Setup: dùng temp file để test append-only thật
	tmpFile := "/tmp/qt9_test_" + fmt.Sprintf("%d", time.Now().UnixNano()) + ".olang"
	defer os.Remove(tmpFile)

	// Track tất cả writes
	type WriteRecord struct {
		Spec AppendSpec
		QTID int
	}
	var writes []WriteRecord
	var writesMu sync.Mutex

	// appendFn mock — record calls
	appendFn := func(path string, specs []AppendSpec) (int, int, error) {
		writesMu.Lock()
		defer writesMu.Unlock()
		for _, s := range specs {
			// DNA format mới: [0x42=header][0x03=L3][0x51=QR][ISL:8][conf:4]...
			// DNA[0] = STATE|TYPE header (0x42 = QR|SDF)
			// DNA[1] = QRLayerID (0x03)
			// DNA[2] = QRMarkerByte (0x51 = 'Q')
			qtID := 0
			if len(s.DNA) >= 2 && s.DNA[0] == 0x42 && s.DNA[1] == QRLayerID {
				qtID = int(s.DNA[1]) // layer marker
			}
			writes = append(writes, WriteRecord{Spec: s, QTID: qtID})
		}
		return len(specs), 0, nil
	}

	qrWriter := NewQRWriter(tmpFile, appendFn, nil)

	// Callback để verify L0 wiring
	type L0Wire struct {
		FromISL [8]byte
		ToOp    byte
		QTID    int
	}
	var wires []L0Wire
	var wiresMu sync.Mutex

	qrWriter.OnCallback(func(evt QRWriteEvent) {
		wiresMu.Lock()
		defer wiresMu.Unlock()
		// Tìm QT ID từ DNA
		qtID := 0
		if len(evt.DNA) >= 4 {
			// QT ID được encode trong DNA[2] (xem qrDNAWithQT)
			qtID = int(evt.DNA[2])
		}
		wires = append(wires, L0Wire{
			FromISL: evt.OlangISL,
			QTID:    qtID,
		})
	})

	graph  := silk.NewSilkGraph()
	ledger := &silk.Ledger{}
	dn     := NewShortTerm(256)
	qr     := NewLongTerm(graph, ledger).WithQRWriter(qrWriter)

	t.Log("=== VIẾT 9 QT VÀO HỆ THỐNG ===")
	t.Log("")

	// Bước 1: Nhập 9 QT (simulate người dùng nói "đây là Quy Tắc")
	for _, qt := range NineQTs {
		obs := makeQTObservation(qt)

		// Bước 1a: vào ĐN trước (conf thấp = chưa chắc)
		obs.Confidence = 0.33
		obs.Confirmed  = 1
		r1 := dn.Observe(obs, qr)

		// Bước 1b: người dùng xác nhận "đây là Quy Tắc" → conf = 1.0
		obs.Confidence = 1.0
		obs.Confirmed  = 3
		// Immutable QR: Commit thẳng (không qua Dream threshold)
		err := qr.Commit(obs)

		t.Logf("  QT%d [%s] %s", qt.ID, qt.Symbol, qt.Name)
		t.Logf("    ĐN: %v | QR Commit: %v", r1, err == nil)
	}

	// Đợi goroutines QRWriter
	time.Sleep(100 * time.Millisecond)

	writesMu.Lock()
	writeCount := len(writes)
	writesMu.Unlock()

	t.Log("")
	t.Log("=== KẾT QUẢ GHI VÀO .OLANG ===")
	t.Log("")

	if writeCount != len(NineQTs) {
		t.Errorf("❌ Expect %d QR writes, got %d", len(NineQTs), writeCount)
	}

	writesMu.Lock()
	for _, w := range writes {
		s := w.Spec
		// Decode tên QT từ Name
		layerOK := s.ISL[0] == QRLayerID  // phải là L3
		// DNA[0] = QR|SDF = 0x42 (STATE|TYPE header theo NODE_Spec)
		// DNA[1] = QRLayerID = 0x03 (L3 marker)
		// DNA[2] = QRMarkerByte = 0x51 ('Q')
		headerOK := len(s.DNA) >= 3 && s.DNA[0] == 0x42 && s.DNA[2] == QRMarkerByte

		status := "✅"
		if !layerOK || !headerOK { status = "❌" }

		t.Logf("  %s %s", status, s.Name)
		t.Logf("       ISL: %x  layer=L%d %s",
			s.ISL, s.ISL[0],
			map[bool]string{true:"✅ L3 Concept", false:"❌ WRONG LAYER"}[layerOK])
		t.Logf("       DNA: [0x%02x=header 0x%02x=L3 0x%02x=%s] (%dB total)",
			s.DNA[0], s.DNA[1], s.DNA[2],
			map[bool]string{true:"QR✅", false:"?❌"}[headerOK],
			len(s.DNA))
	}
	writesMu.Unlock()

	// Kiểm tra L0 mapping
	t.Log("")
	t.Log("=== KIỂM TRA L0 OP MAPPING ===")
	t.Log("")
	for _, qt := range NineQTs {
		if len(qt.L0Ops) == 0 {
			t.Logf("  QT%d [%s] %s → concept (không map L0 op trực tiếp)",
				qt.ID, qt.Symbol, qt.Name)
			continue
		}
		opNames := make([]string, len(qt.L0Ops))
		for i, op := range qt.L0Ops {
			opNames[i] = l0OpName(op)
		}
		t.Logf("  QT%d [%s] %s → L0: %s",
			qt.ID, qt.Symbol, qt.Name, strings.Join(opNames, " + "))
	}

	// Kiểm tra QT8: append-only — viết lại cùng QT không tạo duplicate
	t.Log("")
	t.Log("=== KIỂM TRA QT8: APPEND-ONLY ===")
	t.Log("")

	writesMu.Lock()
	beforeCount := len(writes)
	writesMu.Unlock()

	// Thử commit lại QT1 (đã có)
	qt1obs := makeQTObservation(NineQTs[0])
	qt1obs.Confidence = 1.0
	qt1obs.Confirmed  = 3
	qr.Commit(qt1obs) // phải bị discard vì hash đã có

	time.Sleep(50 * time.Millisecond)

	writesMu.Lock()
	afterCount := len(writes)
	writesMu.Unlock()

	if afterCount > beforeCount {
		t.Errorf("❌ QT8 VIOLATED: duplicate write khi commit QT1 lần 2 (%d→%d)", beforeCount, afterCount)
	} else {
		t.Logf("  ✅ QT8 OK: commit lại QT1 → discard (count: %d→%d, không thay đổi)", beforeCount, afterCount)
	}

	// Summary
	t.Log("")
	t.Log("=== SUMMARY ===")
	t.Logf("  ĐN entries: %d", dn.Count())
	t.Logf("  QR entries: %d (RAM)", qr.Count())
	t.Logf("  .olang writes: %d", writeCount)
	t.Logf("  L3 Concept layer: tất cả QR nodes → L3 ✅")
	t.Logf("  Append-only: %s", map[bool]string{true:"✅", false:"❌"}[afterCount == beforeCount])

	if writeCount == len(NineQTs) {
		t.Log("")
		t.Log("  🎯 9/9 QT đã được ghi vào .olang thành công")
	}
}

// TestQT_LayerPlacement — kiểm tra mỗi QT được đặt đúng layer
// QT4: bản chất quyết định tồn tại → bản chất của QT là concept → L3
// QT5: bản chất quyết định vị trí → L3 Concept phải ở layer 3
func TestQT_LayerPlacement(t *testing.T) {
	t.Log("=== KIỂM TRA LAYER PLACEMENT (QT4 + QT5) ===")
	t.Log("")

	for _, qt := range NineQTs {
		obs := makeQTObservation(qt)
		obs.Confidence = 1.0
		isl := qrISL(obs)
		dna := qrDNA(obs)

		// Layer phải là L3 (Concept)
		layerOK  := isl[0] == 0x03
		// Group phải là 'Q' (QR group)
		groupOK  := isl[1] == QRMarkerByte  // 0x51 = 'Q'
		// Type phải là 'R'
		typeOK   := isl[2] == 0x52          // 'R'
		// DNA[0] = STATE|TYPE header theo NODE_Spec = QR|SDF = 0x42
		dnaL3OK  := len(dna) > 0 && dna[0] == 0x42
		// DNA[1] = QRLayerID (0x03 = L3 marker, sau header)
		dnaQROK  := len(dna) > 1 && dna[1] == QRLayerID

		allOK := layerOK && groupOK && typeOK && dnaL3OK && dnaQROK
		status := "✅"
		if !allOK { status = "❌" }

		t.Logf("%s QT%d [%s] ISL: L%d·G=0x%02x·T=0x%02x | DNA[0:2]=[0x%02x,0x%02x]",
			status, qt.ID, qt.Symbol,
			isl[0], isl[1], isl[2],
			dna[0], dna[1])

		if !layerOK  { t.Errorf("  ❌ Layer: got %d want 3", isl[0]) }
		if !groupOK  { t.Errorf("  ❌ Group: got 0x%02x want 0x%02x (Q)", isl[1], QRMarkerByte) }
		if !dnaL3OK  { t.Errorf("  ❌ DNA[0]: got 0x%02x want 0x42 (QR|SDF header)", dna[0]) }
		if !dnaQROK  { t.Errorf("  ❌ DNA[1]: got 0x%02x want 0x03 (L3 marker)", dna[1]) }
	}
}

// TestQT_SortedByBanChat — kiểm tra 9 QT được sắp xếp đúng theo bản chất (QT5)
// Thứ tự đúng: QT1(○ origin) → QT2(∞ sai) → QT3(⧺ vật lý) →
//              QT4(≔ bản chất) → QT5(∈ vị trí) → QT6(∪ nhóm) →
//              QT7(Δ học) → QT8(⊕ lịch sử) → QT9(🛡 bảo vệ)
func TestQT_SortedByBanChat(t *testing.T) {
	t.Log("=== KIỂM TRA SẮP XẾP THEO BẢN CHẤT (QT5) ===")
	t.Log("")
	t.Log("Layer phân cấp:")
	t.Log("  L0 = opcodes (thực thi vật lý)")
	t.Log("  L1 = UTF-32 symbols")
	t.Log("  L3 = Concepts (QR nodes)")
	t.Log("  L7 = Programs / Rules")
	t.Log("")

	// Phân loại 9 QT theo domain
	type Domain struct {
		Name string
		QTs  []int
	}
	domains := []Domain{
		{"Nền tảng (○ là gốc)", []int{1}},
		{"Giới hạn (∞ vs ∞-1)", []int{2}},
		{"Nhận thức (toán học vs vật lý)", []int{3}},
		{"Bản thể (bản chất tồn tại)", []int{4, 5}},
		{"Cấu trúc (nhóm SDF⧺ISL)", []int{6}},
		{"Tri thức (ĐN→QR)", []int{7}},
		{"Bất biến (lịch sử + bảo mật)", []int{8, 9}},
	}

	for _, d := range domains {
		names := make([]string, len(d.QTs))
		for i, id := range d.QTs {
			names[i] = fmt.Sprintf("QT%d[%s]", id, NineQTs[id-1].Symbol)
		}
		t.Logf("  Domain %-38s → %s",
			"'"+d.Name+"'",
			strings.Join(names, " + "))
	}

	t.Log("")
	t.Log("QT5 verify: cùng domain → ISL group byte phải giống nhau")
	t.Log("")

	// Tạo ISL cho từng QT và verify cùng domain → group gần nhau
	for _, qt := range NineQTs {
		obs := makeQTObservation(qt)
		isl := qrISL(obs)
		t.Logf("  QT%d %-25s ISL=[L%d·'%c'·'%c'·id=%d·hash=%x]",
			qt.ID, qt.Name,
			isl[0],
			rune(isl[1]), rune(isl[2]),
			isl[3],
			isl[4:8])
	}

	// QT5: tất cả QT phải cùng L3 (cùng bản chất Concept → cùng nhóm)
	for _, qt := range NineQTs {
		obs := makeQTObservation(qt)
		isl := qrISL(obs)
		if isl[0] != 0x03 || isl[1] != QRMarkerByte {
			t.Errorf("QT%d: không cùng nhóm L3·QR: ISL[0:2]=[%x,%x]", qt.ID, isl[0], isl[1])
		}
	}
	t.Log("")
	t.Log("  ✅ QT5 verified: 9 QT nodes → đều ở L3·QR group (cùng bản chất → cùng nhóm)")
}

// TestQT_ImmutableAfterCommit — QT đã committed không thể overwrite (QT8)
func TestQT_ImmutableAfterCommit(t *testing.T) {
	graph  := silk.NewSilkGraph()
	ledger := &silk.Ledger{}
	dn     := NewShortTerm(64)

	var writes []AppendSpec
	var mu sync.Mutex
	qrWriter := NewQRWriter("/tmp/immutable_test.olang",
		func(p string, specs []AppendSpec) (int, int, error) {
			mu.Lock(); defer mu.Unlock()
			writes = append(writes, specs...)
			return len(specs), 0, nil
		}, nil)

	qr := NewLongTerm(graph, ledger).WithQRWriter(qrWriter)

	// Commit QT1 lần 1
	obs1 := makeQTObservation(NineQTs[0])
	obs1.Confidence = 1.0
	obs1.Confirmed  = 3
	qr.Commit(obs1)
	time.Sleep(30 * time.Millisecond)

	mu.Lock()
	count1 := len(writes)
	mu.Unlock()

	// Commit QT1 lần 2 với nội dung khác nhưng cùng NodeHash
	obs2 := obs1
	obs2.Label = "QT1_NGUON_GOC_MODIFIED" // thử modify
	qr.Commit(obs2)
	time.Sleep(30 * time.Millisecond)

	mu.Lock()
	count2 := len(writes)
	mu.Unlock()

	// ĐN reinforce
	dn.Observe(obs1, qr)
	dn.Observe(obs1, qr)

	// Kiểm tra QR chỉ có 1 entry
	if qr.Count() != 1 {
		t.Errorf("❌ QR có %d entries sau 2 commits (expect 1)", qr.Count())
	}
	if count2 > count1 {
		t.Errorf("❌ QT8 violated: .olang write count %d→%d (no new write expected)", count1, count2)
	}

	t.Logf("✅ QT8 IMMUTABLE: QT1 committed %d time(s) → QR has 1 entry, .olang wrote %d time(s)",
		2, count1)
	_ = dn
}

// ─── helpers ──────────────────────────────────────────────────────────────

func makeQTObservation(qt QTInput) Observation {
	// NodeHash unique theo QT ID (deterministic)
	h := isl.NodeHash(uint64(0xAA00000000000000) | uint64(qt.ID)<<48 | uint64(qt.CP))
	return Observation{
		NodeHash:   h,
		ISL:        isl.Address{Layer: 0x03, Group: 0x51}, // L3 Concept
		Data:       []byte(qt.Text),
		Label:      qt.Name,
		Confidence: 1.0,
		Confirmed:  3,
		SrcType:    1, // SourceUser = real_now
	}
}

func l0OpName(op byte) string {
	names := map[byte]string{
		0x01:"OP_SPHERE", 0x02:"OP_CAPSULE", 0x03:"OP_BOX", 0x05:"OP_VOID",
		0x10:"OP_UNION",  0x11:"OP_SUB",     0x12:"OP_INTERSECT",
		0x20:"OP_FBM",    0x21:"OP_GRADIENT",0x22:"OP_LIGHT",
		0x50:"OP_GET",    0x51:"OP_WALK",    0x52:"OP_EMIT",
		0x60:"OP_SEQ",    0x61:"OP_IF",      0x62:"OP_LOOP",
		0x63:"OP_DREAM",  0xFF:"OP_GATE",
		0x70:"OP_ADD",    0x71:"OP_SUB_N",
	}
	if n, ok := names[op]; ok { return fmt.Sprintf("%s(0x%02x)", n, op) }
	return fmt.Sprintf("0x%02x", op)
}
