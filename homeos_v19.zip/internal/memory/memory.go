// internal/memory/memory.go
//
// Memory — ΔΨ ShortTerm (Dendrites) + QR LongTerm (Axon)
//
// ════════════════════════════════════════════════════════════════
// NGUYÊN TẮC CỐT LÕI (từ session 31):
//
//   IDENTITY = NodeHash = hash(SDF.b[0..14])   ← duy nhất, bất biến
//   POSITION = ISL address                      ← không unique, tọa độ
//   NAME     = string label                     ← human readable
//
//   Ba thứ này ĐỘC LẬP. "Đã tồn tại" = NodeHash đã có.
//
// BỐN TRƯỜNG HỢP KHI NODE MỚI ĐẾN:
//
//   Hash trùng QR  → DISCARD + reinforce QR node (đừng học lại)
//   Hash trùng ĐN  → REINFORCE ĐN node (fire_count++)
//   Hash mới       → TẠO MỚI trong ĐN (dù ISL có trùng hay không)
//   ISL trùng      → KHÔNG PHẢI duplicate — chỉ là hàng xóm ngữ nghĩa
//
// CÙng SDF + khác ngữ cảnh = cùng node + thêm BOND edges.
// Không tạo node mới chỉ vì ngữ cảnh khác.
//
// ════════════════════════════════════════════════════════════════

package memory

import (
	"context"
	"log"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// ─────────────────────────────────────────────────────────────────
// OBSERVATION — đơn vị tri thức chưa chứng minh
// ─────────────────────────────────────────────────────────────────

// Observation là một quan sát trong ĐN (Dendrites)
//
// NodeHash là key duy nhất — không phải ISL.
// ISL chỉ nói "vùng ngữ nghĩa nào", không phải "cái này là gì".
type Observation struct {
	NodeHash  isl.NodeHash  // hash(SDF) — IDENTITY, key duy nhất
	ISL       isl.Address   // tọa độ ngữ nghĩa — POSITION (không unique)
	Data      []byte        // nội dung SDF bytes (15B) hoặc semantic data
	Label     string        // human readable name (không unique)

	Confidence float64   // 0.0..1.0
	FireCount  int       // số lần kích hoạt (reinforcement)
	Confirmed  int       // số lần user xác nhận
	Rejected   int       // số lần user bác bỏ

	SrcType   uint8     // Source type: 0=unknown 1=real_now 2=real_past 3=real_other 4=fiction 5=music
	CreatedAt  time.Time
	UpdatedAt  time.Time
	State      ObsState
}

// ObsState là trạng thái của Observation
type ObsState byte

const (
	StatePending   ObsState = 0x00 // mới, chưa kiểm chứng
	StateConfirmed ObsState = 0x01 // đủ điều kiện promote
	StateArchived  ObsState = 0x02 // đã promote lên QR (giữ lại, không xóa)
	StateRefuted   ObsState = 0x03 // đã bác bỏ (giữ lại, không xóa)
)

// InputResult là kết quả khi thêm node mới vào memory
type InputResult byte

const (
	ResultCreated    InputResult = 0x00 // tạo mới trong ĐN
	ResultReinforced InputResult = 0x01 // hash đã có trong ĐN → reinforce
	ResultDiscarded  InputResult = 0x02 // hash đã có trong QR → discard
)

func (r InputResult) String() string {
	switch r {
	case ResultCreated:    return "Created(ĐN)"
	case ResultReinforced: return "Reinforced(ĐN)"
	case ResultDiscarded:  return "Discarded(QR exists)"
	default:               return "Unknown"
	}
}

// ─────────────────────────────────────────────────────────────────
// SHORT TERM — ΔΨ Dendrites
// Hash table O(1) theo NodeHash — không phải ISL
// ─────────────────────────────────────────────────────────────────

// ShortTerm là bộ nhớ ngắn hạn — Dendrites (ΔΨ)
//
// Key = NodeHash (hash của SDF content), không phải ISL address.
// Nhiều observations có thể share cùng ISL (hàng xóm ngữ nghĩa).
type ShortTerm struct {
	mu      sync.RWMutex
	byHash  map[isl.NodeHash]*Observation // O(1) lookup theo identity
	order   []isl.NodeHash                // insertion order (cho eviction)
	max     int
}

func NewShortTerm(maxSize int) *ShortTerm {
	return &ShortTerm{
		byHash: make(map[isl.NodeHash]*Observation, maxSize),
		order:  make([]isl.NodeHash, 0, maxSize),
		max:    maxSize,
	}
}

// Observe xử lý một observation mới theo 4 rules:
//   - hash đã có trong QR → DISCARD (caller cung cấp qr để check)
//   - hash đã có trong ĐN → REINFORCE
//   - hash mới            → CREATE
//
// ISL không phải unique key — không dùng để check duplicate.
func (st *ShortTerm) Observe(o Observation, qr *LongTerm) InputResult {
	// Tính hash nếu chưa có
	if o.NodeHash == 0 && len(o.Data) >= 15 {
		var sdf [15]byte
		copy(sdf[:], o.Data[:15])
		o.NodeHash = isl.HashSDF(sdf)
	}

	// Rule 1: check QR trước — đừng học lại điều đã biết
	if qr != nil && qr.HasHash(o.NodeHash) {
		qr.Reinforce(o.NodeHash) // tăng weight, không tạo mới
		return ResultDiscarded
	}

	st.mu.Lock()
	defer st.mu.Unlock()

	// Rule 2: hash đã có trong ĐN → reinforce
	if existing, ok := st.byHash[o.NodeHash]; ok {
		existing.FireCount++
		existing.UpdatedAt = time.Now()
		existing.Confidence = calcConfidence(existing)
		// ISL có thể update nếu mới hơn (học được vị trí tốt hơn)
		if o.ISL.Uint64() != 0 {
			existing.ISL = o.ISL
		}
		return ResultReinforced
	}

	// Rule 3: hash mới → tạo mới trong ĐN
	// ISL trùng với node khác? Không sao — chỉ là hàng xóm ngữ nghĩa
	o.CreatedAt = time.Now()
	o.UpdatedAt = time.Now()
	o.FireCount = 1
	o.State = StatePending
	if o.Confidence == 0 {
		o.Confidence = calcConfidence(&o)
	}

	// Evict nếu đầy — xóa entry cũ nhất (LRU)
	if len(st.byHash) >= st.max {
		st.evictOldest()
	}

	st.byHash[o.NodeHash] = &o
	st.order = append(st.order, o.NodeHash)
	return ResultCreated
}

// GetByHash tra cứu O(1) theo NodeHash
func (st *ShortTerm) GetByHash(h isl.NodeHash) (*Observation, bool) {
	st.mu.RLock(); defer st.mu.RUnlock()
	o, ok := st.byHash[h]
	if !ok { return nil, false }
	cp := *o // return copy
	return &cp, true
}

// GetByISL tìm TẤT CẢ observations trong cùng vùng ISL
// (nhiều observations có thể share cùng ISL — không phải lỗi)
func (st *ShortTerm) GetByISL(addr isl.Address) []*Observation {
	st.mu.RLock(); defer st.mu.RUnlock()
	key := addr.Uint64()
	var out []*Observation
	for _, o := range st.byHash {
		if o.ISL.Uint64() == key {
			cp := *o
			out = append(out, &cp)
		}
	}
	return out
}

// Confirm tăng confidence khi user xác nhận (theo NodeHash)
func (st *ShortTerm) Confirm(h isl.NodeHash) {
	st.mu.Lock(); defer st.mu.Unlock()
	if o, ok := st.byHash[h]; ok {
		o.Confirmed++
		o.FireCount++
		o.UpdatedAt = time.Now()
		o.Confidence = calcConfidence(o)
	}
}

// Reject bác bỏ — đánh dấu Refuted, KHÔNG xóa (append-only)
func (st *ShortTerm) Reject(h isl.NodeHash) {
	st.mu.Lock(); defer st.mu.Unlock()
	if o, ok := st.byHash[h]; ok {
		o.Rejected++
		o.UpdatedAt = time.Now()
		o.Confidence = calcConfidence(o)
		if o.Rejected >= o.Confirmed*2 && o.Rejected >= 3 {
			o.State = StateRefuted
		}
	}
}

// Candidates trả về observations đủ điều kiện promote (conf >= threshold)
func (st *ShortTerm) Candidates(minConf float64) []Observation {
	st.mu.RLock(); defer st.mu.RUnlock()
	var out []Observation
	for _, o := range st.byHash {
		if o.Confidence >= minConf && o.State == StatePending {
			out = append(out, *o)
		}
	}
	return out
}

// All trả về tất cả observations — dùng trong Dream cycle
func (st *ShortTerm) All() []Observation {
	st.mu.RLock(); defer st.mu.RUnlock()
	out := make([]Observation, 0, len(st.byHash))
	for _, o := range st.byHash {
		out = append(out, *o)
	}
	return out
}

// MarkArchived sau khi promote lên QR (không xóa — append-only)
func (st *ShortTerm) MarkArchived(h isl.NodeHash) {
	st.mu.Lock(); defer st.mu.Unlock()
	if o, ok := st.byHash[h]; ok {
		o.State = StateArchived
		o.UpdatedAt = time.Now()
	}
}

// Count trả về số observations đang active (không count archived/refuted)
// ForceInsert — chèn trực tiếp vào ĐN (dùng cho testing/seeding)
// Bỏ qua logic Observe, không check QR
func (st *ShortTerm) ForceInsert(o Observation) {
	st.mu.Lock()
	defer st.mu.Unlock()
	if o.CreatedAt.IsZero() { o.CreatedAt = time.Now() }
	if o.UpdatedAt.IsZero() { o.UpdatedAt = time.Now() }
	if _, exists := st.byHash[o.NodeHash]; !exists {
		if len(st.order) >= st.max { st.evictOldest() }
		st.order = append(st.order, o.NodeHash)
	}
	cp := o
	st.byHash[o.NodeHash] = &cp
}

// CountActive — đếm chỉ non-archived observations
func (st *ShortTerm) CountActive() int {
	st.mu.RLock()
	defer st.mu.RUnlock()
	n := 0
	for _, o := range st.byHash {
		if o.State != StateArchived { n++ }
	}
	return n
}

func (st *ShortTerm) Count() int {
	st.mu.RLock(); defer st.mu.RUnlock()
	n := 0
	for _, o := range st.byHash {
		if o.State == StatePending || o.State == StateConfirmed {
			n++
		}
	}
	return n
}

// evictOldest xóa entry cũ nhất (LRU eviction)
// Chỉ xóa Pending/Refuted — không bao giờ xóa Confirmed/Archived
func (st *ShortTerm) evictOldest() {
	for i, h := range st.order {
		if o, ok := st.byHash[h]; ok {
			if o.State == StatePending || o.State == StateRefuted {
				delete(st.byHash, h)
				st.order = append(st.order[:i], st.order[i+1:]...)
				return
			}
		} else {
			// đã bị xóa, dọn dẹp order
			st.order = append(st.order[:i], st.order[i+1:]...)
			return
		}
	}
}

// calcConfidence tính confidence từ fire/confirm/reject
func calcConfidence(o *Observation) float64 {
	total := o.Confirmed + o.Rejected + 1
	if o.Rejected > o.Confirmed {
		return 0.0
	}
	base := float64(o.Confirmed) / float64(total)
	// FireCount boost nhỏ — hệ thống thấy nhiều lần → tự tin hơn
	boost := float64(o.FireCount) * 0.02
	if boost > 0.3 { boost = 0.3 }
	c := base + boost
	if c > 1.0 { c = 1.0 }
	return c
}

// ─────────────────────────────────────────────────────────────────
// LONG TERM — QR Axon
// Hash table O(1) — append-only, ED25519 signed
// ─────────────────────────────────────────────────────────────────

// LongTerm là bộ nhớ dài hạn — Axon (QR)
//
// Key = NodeHash, không phải ISL.
// Nhiều QR nodes có thể share cùng ISL (hàng xóm ngữ nghĩa trong QR tree).
type LongTerm struct {
	mu      sync.RWMutex
	byHash  map[isl.NodeHash]*qrEntry // O(1) lookup
	graph   *silk.SilkGraph
	ledger  *silk.Ledger
	writer  *QRWriter // ghi QR vào homeos.olang (nil = chỉ RAM)
}

type qrEntry struct {
	hash   isl.NodeHash
	node   *silk.OlangNode
	weight int // số lần reinforce sau khi đã QR
}

func NewLongTerm(graph *silk.SilkGraph, ledger *silk.Ledger) *LongTerm {
	return &LongTerm{
		byHash: make(map[isl.NodeHash]*qrEntry),
		graph:  graph,
		ledger: ledger,
	}
}

// WithQRWriter inject QRWriter để persist QR vào homeos.olang
// QT7: khi Commit() xảy ra → QRWriter.Persist() → .olang (append-only)
func (lt *LongTerm) WithQRWriter(w *QRWriter) *LongTerm {
	lt.writer = w
	return lt
}

// HasHash kiểm tra O(1) — dùng trước khi tạo ĐN mới
func (lt *LongTerm) HasHash(h isl.NodeHash) bool {
	lt.mu.RLock(); defer lt.mu.RUnlock()
	_, ok := lt.byHash[h]
	return ok
}

// Reinforce tăng weight khi nhận input trùng với QR node đã có
// Không tạo node mới — đây là "ký ức được củng cố"
func (lt *LongTerm) Reinforce(h isl.NodeHash) {
	lt.mu.Lock(); defer lt.mu.Unlock()
	if e, ok := lt.byHash[h]; ok {
		e.weight++
		if e.node != nil {
			e.node.Weight++
		}
	}
}

// Commit ghi Observation vào QR — chỉ khi conf >= 0.8
// Trả về error nếu:
//   - confidence < 0.8
//   - hash đã có trong QR (không ghi đè)
func (lt *LongTerm) Commit(o Observation) error {
	if o.Confidence < 0.8 {
		return nil // chưa đủ confidence — không phải lỗi
	}

	lt.mu.Lock()
	defer lt.mu.Unlock()

	// Đã có trong QR → không ghi đè (append-only)
	if _, exists := lt.byHash[o.NodeHash]; exists {
		return nil
	}

	node := &silk.OlangNode{
		Addr:   o.ISL,
		Status: silk.StatusQR,
		Weight: o.Confirmed,
		Name:   o.Label,
	}
	if node.Name == "" {
		node.Name = o.ISL.String()
	}

	// Append vào ledger (ED25519 signed)
	if lt.ledger != nil {
		if err := lt.ledger.Append(node); err != nil {
			return err
		}
	}

	// Thêm vào SilkGraph
	lt.graph.AddNode(node)

	// Ghi vào hash table
	lt.byHash[o.NodeHash] = &qrEntry{
		hash:   o.NodeHash,
		node:   node,
		weight: o.Confirmed,
	}

	// Persist xuống homeos.olang (QT8: append-only · bất biến)
	// writer có thể nil nếu chưa inject — fallback về RAM-only
	if lt.writer != nil {
		go lt.writer.Persist(o) // goroutine: không block Commit
	}

	return nil
}

// GetByHash tra cứu QR node theo NodeHash
func (lt *LongTerm) GetByHash(h isl.NodeHash) (*silk.OlangNode, bool) {
	lt.mu.RLock(); defer lt.mu.RUnlock()
	if e, ok := lt.byHash[h]; ok {
		return e.node, true
	}
	return nil, false
}

// Query tìm QR node theo ISL address (có thể nhiều kết quả)
func (lt *LongTerm) Query(addr isl.Address) (*silk.OlangNode, bool) {
	lt.mu.RLock(); defer lt.mu.RUnlock()
	return lt.graph.Get(addr)
}

// Count trả về số QR nodes
func (lt *LongTerm) Count() int {
	lt.mu.RLock(); defer lt.mu.RUnlock()
	return len(lt.byHash)
}

// ─────────────────────────────────────────────────────────────────
// DREAM — kiểm chứng ΔΨ khi idle (QT7)
// Chạy khi inbox rảnh > 5 phút
// ─────────────────────────────────────────────────────────────────

// Dream là goroutine tự kiểm chứng khi rảnh
type Dream struct {
	dn       *ShortTerm
	qr       *LongTerm
	idleWait time.Duration
	lastMsg  time.Time
	mu       sync.Mutex
}

func NewDream(dn *ShortTerm, qr *LongTerm) *Dream {
	return &Dream{
		dn:       dn,
		qr:       qr,
		idleWait: 5 * time.Minute,
		lastMsg:  time.Now(),
	}
}

// Poke reset idle timer khi có message mới
func (d *Dream) Poke() {
	d.mu.Lock(); defer d.mu.Unlock()
	d.lastMsg = time.Now()
}

// Run vòng lặp dreaming — chạy như goroutine
func (d *Dream) Run(ctx context.Context) {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			d.mu.Lock()
			idle := time.Since(d.lastMsg)
			d.mu.Unlock()
			if idle >= d.idleWait {
				d.process()
			}
		}
	}
}

// process — kiểm chứng và promote ΔΨ → QR
//
// Logic:
//   conf >= 0.8  → promote lên QR, mark archived trong ĐN
//   conf < 0.3 && nhiều lần check → mark refuted (không xóa)
func (d *Dream) process() {
	candidates := d.dn.Candidates(0.5)
	promoted, refuted := 0, 0

	for _, o := range candidates {
		if o.Confidence >= 0.8 {
			if err := d.qr.Commit(o); err == nil {
				d.dn.MarkArchived(o.NodeHash) // không xóa — append-only
				promoted++
			}
		} else if o.Confidence < 0.3 && o.Confirmed+o.Rejected > 5 {
			d.dn.Reject(o.NodeHash) // mark refuted, không xóa
			refuted++
		}
	}

	if promoted+refuted > 0 {
		log.Printf("Dream: promoted=%d refuted=%d active=%d qr=%d",
			promoted, refuted, d.dn.Count(), d.qr.Count())
	}
}
