// internal/memory/qr_writer.go
//
// QRWriter — bridge: khi LongTerm.Commit() xảy ra → ghi vào homeos.olang
//
// QT7: ĐN(+/-) → chứng minh → QR(==) · QR là append-only · bất biến
//
// Luồng đầy đủ:
//
//   người dùng: "đây là Quy Tắc: X"
//       ↓ MsgLearn + immutable_flag=true
//       ↓ TeachSkill → Observation{conf=1.0, immutable=true}
//       ↓ ShortTerm.Observe() → ĐN entry
//       ↓ Dream.process() → conf≥0.8 → LongTerm.Commit()
//       ↓ QRWriter.OnCommit() ← callback được gọi ở đây
//       ↓ utf32.AppendL1Batch() → homeos.olang (append-only)
//       ↓ ws.OlangAppendEdgeWeighted() → silk edge → homeos.olang
//
// QRNode trong .olang:
//   Layer = 3 (L3 Concept — tri thức đã chứng minh)
//   DNA[0] = 0x03 (L3 marker)
//   DNA[1] = QR_MARKER = 0x51 = 'Q' (phân biệt với ĐN)
//   DNA[2..5] = codepoint (nếu có)
//   DNA[6..] = text nội dung QR
//
// ISL format QR node:
//   [0x03][0x51='Q'][0x52='R'][id:1B][hash:4B]
//   → tất cả QR nodes nằm trong L3 group 'QR'

package memory

import (
	"crypto/sha256"
	"encoding/binary"
	"log"
	"sync"
	"time"
)

const (
	QRMarkerByte = 0x51 // 'Q' — DNA[1] của mọi QR node
	QRLayerID    = 0x03 // L3 — Concept layer
)

// QRWriteEvent — thông tin khi một QR được commit
type QRWriteEvent struct {
	// Observation đã được promote
	Obs Observation

	// Thời điểm commit
	CommittedAt time.Time

	// ISL address trong .olang (8 bytes)
	OlangISL [8]byte

	// DNA đã được tính
	DNA []byte

	// Tên node trong .olang
	NodeName string
}

// QRWriteCallback — hàm được gọi sau khi QR được persist vào .olang
// Dùng để wire silk edges từ QR node đến các concept liên quan
type QRWriteCallback func(event QRWriteEvent)

// QRWriter — quản lý việc ghi QR vào homeos.olang
//
// Được inject vào LongTerm qua WithQRWriter().
// Không import agents/ hay ws/ để tránh import cycle.
// Dùng function injection cho I/O operations.
type QRWriter struct {
	mu sync.Mutex

	// olangPath — đường dẫn đến homeos.olang
	olangPath string

	// appendFn — function để append node vào .olang
	// Inject từ utf32 package để tránh import cycle
	appendFn func(path string, nodes []AppendSpec) (int, int, error)

	// edgeFn — function để append silk edge vào .olang
	edgeFn func(path string, src, dst [8]byte, etype uint8, w float32) error

	// callbacks — được gọi sau khi persist thành công
	callbacks []QRWriteCallback

	// stats
	written  int
	skipped  int
	errors   int
}

// AppendSpec — spec để append một L3 QR node vào .olang
type AppendSpec struct {
	ISL  [8]byte
	CP   uint32
	DNA  []byte
	Name string
}

// NewQRWriter tạo writer mới
// appendFn và edgeFn được inject — không hardcode import
func NewQRWriter(
	olangPath string,
	appendFn func(string, []AppendSpec) (int, int, error),
	edgeFn func(string, [8]byte, [8]byte, uint8, float32) error,
) *QRWriter {
	return &QRWriter{
		olangPath: olangPath,
		appendFn:  appendFn,
		edgeFn:    edgeFn,
	}
}

// OnCallback thêm callback được gọi sau khi QR được persist
func (w *QRWriter) OnCallback(fn QRWriteCallback) *QRWriter {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.callbacks = append(w.callbacks, fn)
	return w
}

// Persist ghi Observation đã được promote vào homeos.olang
//
// Được gọi từ LongTerm.Commit() ngay sau khi ghi vào RAM.
// QT8: Append-only — không DELETE, không OVERWRITE.
func (w *QRWriter) Persist(o Observation) error {
	if w == nil || w.appendFn == nil { return nil }

	w.mu.Lock()
	defer w.mu.Unlock()

	// Tính ISL cho QR node trong .olang
	isl := qrISL(o)

	// Tính DNA
	dna := qrDNA(o)

	// Tên node
	name := o.Label
	if name == "" {
		name = "QR_" + o.ISL.String()
	}

	// Ghi vào .olang
	_, _, err := w.appendFn(w.olangPath, []AppendSpec{{
		ISL:  isl,
		CP:   0, // QR nodes không có codepoint trực tiếp
		DNA:  dna,
		Name: name,
	}})
	if err != nil {
		w.errors++
		log.Printf("QRWriter.Persist: error writing '%s': %v", name, err)
		return err
	}

	w.written++
	log.Printf("QRWriter: ✅ QR persisted → .olang: '%s' ISL:%x", name, isl)

	// Fire callbacks (wiring edges etc.)
	evt := QRWriteEvent{
		Obs:         o,
		CommittedAt: time.Now(),
		OlangISL:    isl,
		DNA:         dna,
		NodeName:    name,
	}
	for _, cb := range w.callbacks {
		cb(evt)
	}

	return nil
}

// Stats trả về thống kê
func (w *QRWriter) Stats() (written, skipped, errors int) {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.written, w.skipped, w.errors
}

// ─── ISL calculation ──────────────────────────────────────────

// qrISL tính ISL 8-byte cho một QR node trong .olang
// Format: [L3=0x03][Q=0x51][R=0x52][id=0x01][hash:4B từ content]
func qrISL(o Observation) [8]byte {
	// Hash từ nội dung observation để tránh collision
	islBytes := make([]byte, 8)
	binary.BigEndian.PutUint64(islBytes, uint64(o.ISL.Uint64()))
	h := sha256.Sum256(append(islBytes, o.Data...))
	var isl [8]byte
	isl[0] = QRLayerID // L3
	isl[1] = QRMarkerByte // 'Q'
	isl[2] = 0x52 // 'R'
	isl[3] = 0x01
	copy(isl[4:], h[:4]) // 4 bytes hash suffix
	return isl
}

// ─── DNA construction ─────────────────────────────────────────

// qrDNA tạo DNA bytes cho QR node
//
// Format:
//   [0x03] L3 marker
//   [0x51] 'Q' = QR marker
//   [isl:8B] ISL address của Observation gốc
//   [conf:4B] confidence * 1000 (big endian uint32)
//   [confirmed:2B] số lần được confirmed
//   [label_len:1B] độ dài label
//   [label:NB] text label
//   [data_len:2B] độ dài data
//   [data:NB] payload gốc (tối đa 200 bytes)
func qrDNA(o Observation) []byte {
	label := []byte(o.Label)
	if len(label) > 100 { label = label[:100] }

	data := o.Data
	if len(data) > 200 { data = data[:200] }

	confInt := uint32(o.Confidence * 1000)

	size := 3 + 8 + 4 + 2 + 1 + len(label) + 2 + len(data)
	d := make([]byte, 0, size)

	// b[0] = STATE|TYPE theo NODE_Spec — QR(0x40)|SDF(0x02) = 0x42
	// QR = đã được chứng minh (commit vào LongTerm)
	// SDF = concept node có "hình dạng" trong không gian ngữ nghĩa
	d = append(d, 0x42) // QR|SDF header

	d = append(d, QRLayerID, QRMarkerByte)

	// ISL của observation gốc
	islBytes := o.ISL.Bytes()
	if len(islBytes) < 8 {
		islBytes = append(islBytes, make([]byte, 8-len(islBytes))...)
	}
	d = append(d, islBytes[:8]...)

	// Confidence
	var cbuf [4]byte
	binary.BigEndian.PutUint32(cbuf[:], confInt)
	d = append(d, cbuf[:]...)

	// Confirmed count
	d = append(d, byte(o.Confirmed>>8), byte(o.Confirmed))

	// Label
	d = append(d, byte(len(label)))
	d = append(d, label...)

	// Data
	d = append(d, byte(len(data)>>8), byte(len(data)))
	d = append(d, data...)

	return d
}
