// qr_writer_test.go — test QT7 end-to-end:
// "đây là Quy Tắc: X" → ĐN → Dream → QR → homeos.olang
package memory

import (
	"os"
	"sync"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// mockAppendFn — thay utf32.AppendL1Batch trong test
func mockAppendFn(calls *[]AppendSpec, mu *sync.Mutex) func(string, []AppendSpec) (int, int, error) {
	return func(path string, specs []AppendSpec) (int, int, error) {
		mu.Lock()
		defer mu.Unlock()
		*calls = append(*calls, specs...)
		return len(specs), 0, nil
	}
}

// TestQRWriter_Persist — QRWriter.Persist() gọi appendFn với đúng data
func TestQRWriter_Persist(t *testing.T) {
	var calls []AppendSpec
	var mu sync.Mutex

	w := NewQRWriter(
		"/tmp/test.olang",
		mockAppendFn(&calls, &mu),
		nil, // edgeFn không cần trong test này
	)

	obs := Observation{
		ISL:        isl.Address{Layer: 0x01, Group: 0x09},
		Data:       []byte(`{"key":"QT_TEST","value":"test rule"}`),
		Label:      "QT_TEST_RULE",
		Confidence: 1.0,
		Confirmed:  3,
	}

	if err := w.Persist(obs); err != nil {
		t.Fatalf("Persist failed: %v", err)
	}

	mu.Lock()
	defer mu.Unlock()

	if len(calls) != 1 {
		t.Fatalf("expected 1 appendFn call, got %d", len(calls))
	}
	spec := calls[0]

	// ISL phải có L3 layer marker
	if spec.ISL[0] != QRLayerID {
		t.Errorf("ISL[0] = 0x%02x, want L3=0x%02x", spec.ISL[0], QRLayerID)
	}
	// DNA[0] = STATE|TYPE header theo NODE_Spec = QR|SDF = 0x42
	// DNA[1] = QRLayerID = 0x03 (L3 marker, sau header)
	// DNA[2] = QRMarkerByte = 0x51 ('Q')
	if len(spec.DNA) < 3 || spec.DNA[0] != 0x42 || spec.DNA[1] != QRLayerID || spec.DNA[2] != QRMarkerByte {
		t.Errorf("DNA[0:3] = %x, want [0x42=QR|SDF 0x03=L3 0x51=QR]", spec.DNA[:min3(3,len(spec.DNA))])
	}
	// Name phải chứa label
	if spec.Name != "QT_TEST_RULE" {
		t.Errorf("Name = %q, want QT_TEST_RULE", spec.Name)
	}
	t.Logf("✅ QRWriter.Persist: ISL=%x DNA(%dB) Name=%s", spec.ISL, len(spec.DNA), spec.Name)
}

// TestLongTerm_CommitTriggersQRWriter — khi LongTerm.Commit() → QRWriter.Persist()
func TestLongTerm_CommitTriggersQRWriter(t *testing.T) {
	graph  := silk.NewSilkGraph()
	ledger := &silk.Ledger{} // mock

	var calls []AppendSpec
	var mu sync.Mutex

	qrWriter := NewQRWriter(
		"/tmp/test.olang",
		mockAppendFn(&calls, &mu),
		nil,
	)

	lt := NewLongTerm(graph, ledger).WithQRWriter(qrWriter)

	obs := Observation{
		NodeHash:   isl.NodeHash(0xDEADBEEF12345678),
		ISL:        isl.Address{Layer: 0x01, Group: 0x09},
		Data:       []byte("đây là Quy Tắc số 1"),
		Label:      "QT1_NGUON_GOC",
		Confidence: 1.0,
		Confirmed:  5,
	}

	if err := lt.Commit(obs); err != nil {
		t.Fatalf("Commit failed: %v", err)
	}

	// QRWriter.Persist chạy trong goroutine — đợi một chút
	time.Sleep(50 * time.Millisecond)

	mu.Lock()
	defer mu.Unlock()

	if len(calls) == 0 {
		t.Fatal("❌ QRWriter.Persist không được gọi sau LongTerm.Commit()")
	}
	t.Logf("✅ LongTerm.Commit → QRWriter.Persist: ISL=%x Name=%s",
		calls[0].ISL, calls[0].Name)
}

// TestQT7_FullFlow — "đây là Quy Tắc" → ĐN → Dream → QR → .olang
// End-to-end test không cần real file
func TestQT7_FullFlow(t *testing.T) {
	// Setup
	graph  := silk.NewSilkGraph()
	ledger := &silk.Ledger{}
	dn     := NewShortTerm(64)

	var written []AppendSpec
	var mu sync.Mutex
	qrWriter := NewQRWriter("/tmp/qt7_test.olang",
		mockAppendFn(&written, &mu), nil)

	qr := NewLongTerm(graph, ledger).WithQRWriter(qrWriter)

	// Input: "đây là Quy Tắc: QT1 ○ LÀ NGUỒN GỐC"
	userInput := []byte("QT1: ○ LÀ NGUỒN GỐC · mọi thứ là instance của ○")
	obs := Observation{
		NodeHash:   isl.NodeHash(0x1234567890ABCDEF),
		ISL:        isl.Address{Layer: 0x01, Group: 0x03}, // L1 Concept
		Data:       userInput,
		Label:      "QT1_ORIGIN",
		Confidence: 0.33, // ban đầu thấp
		Confirmed:  1,
	}

	// Bước 1: Observe → ĐN
	result := dn.Observe(obs, qr)
	if result != ResultCreated {
		t.Errorf("expected Created, got %v", result)
	}
	t.Logf("Step1: ĐN created (%d entries)", dn.Count())

	// Bước 2: Reinforce (người dùng xác nhận lại)
	obs.Confidence = 0.6
	obs.Confirmed  = 2
	dn.Observe(obs, qr)
	t.Logf("Step2: ĐN reinforced")

	// Bước 3: Confidence cao → người dùng xác nhận "đây là QR"
	obs.Confidence = 1.0
	obs.Confirmed  = 3

	// Bước 4: Dream.process() → Commit (simulate)
	if err := qr.Commit(obs); err != nil {
		t.Fatalf("QR Commit failed: %v", err)
	}
	t.Logf("Step3: QR committed → RAM")

	time.Sleep(50 * time.Millisecond) // đợi goroutine

	// Kiểm tra: QRWriter đã được gọi chưa?
	mu.Lock()
	defer mu.Unlock()

	if len(written) == 0 {
		t.Fatal("❌ QT7 BROKEN: LongTerm.Commit không ghi vào .olang")
	}

	spec := written[0]
	t.Logf("✅ QT7 WORKS:")
	t.Logf("   Input:  %q", string(userInput))
	t.Logf("   → ĐN  : ShortTerm entry created")
	t.Logf("   → QR  : LongTerm committed (RAM)")
	t.Logf("   → .olang: L%d node '%s' ISL=%x DNA(%dB)",
		spec.ISL[0], spec.Name, spec.ISL, len(spec.DNA))
	t.Logf("   DNA[0:2] = [L3=0x%02x, QR=0x%02x]", spec.DNA[0], spec.DNA[1])

	// Cleanup
	os.Remove("/tmp/qt7_test.olang")
}

// TestQRWriter_Callback — sau khi persist, callback được gọi để wire edges
func TestQRWriter_Callback(t *testing.T) {
	var calls []AppendSpec
	var mu sync.Mutex
	var cbEvents []QRWriteEvent
	var cbMu sync.Mutex

	w := NewQRWriter("/tmp/cb_test.olang",
		mockAppendFn(&calls, &mu), nil).
		OnCallback(func(e QRWriteEvent) {
			cbMu.Lock()
			cbEvents = append(cbEvents, e)
			cbMu.Unlock()
		})

	obs := Observation{
		ISL:        isl.Address{Layer: 0x01},
		Data:       []byte("QT6: SDF⧺ISL==SmoothUnion"),
		Label:      "QT6_SDF_ISL",
		Confidence: 1.0,
		Confirmed:  3,
	}

	w.Persist(obs)
	time.Sleep(10 * time.Millisecond)

	cbMu.Lock()
	defer cbMu.Unlock()
	if len(cbEvents) != 1 {
		t.Fatalf("expected 1 callback event, got %d", len(cbEvents))
	}
	if cbEvents[0].NodeName != "QT6_SDF_ISL" {
		t.Errorf("callback NodeName = %q", cbEvents[0].NodeName)
	}
	t.Logf("✅ Callback fired: NodeName=%s ISL=%x",
		cbEvents[0].NodeName, cbEvents[0].OlangISL)
}

func min3(a, b int) int { if a < b { return a }; return b }
