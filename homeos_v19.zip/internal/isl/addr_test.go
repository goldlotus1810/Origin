// internal/isl/addr_test.go
package isl

import (
	"testing"
)

// ─────────────────────────────────────────────────────────────────
// TEST NodeHash — content address
// ─────────────────────────────────────────────────────────────────

func TestHashSDF_Uint64(t *testing.T) {
	var sdf [15]byte
	sdf[0] = 0x42 // QR|SDF
	sdf[1] = 0x01 // SPHERE opcode

	h := HashSDF(sdf)
	if h == 0 {
		t.Fatal("hash không được là 0")
	}
	// Idempotent
	h2 := HashSDF(sdf)
	if h != h2 {
		t.Fatal("hash phải idempotent")
	}
}

func TestHashSDF_DifferentNodes(t *testing.T) {
	var a, b [15]byte
	a[0] = 0x42; a[1] = 0x01 // SPHERE
	b[0] = 0x42; b[1] = 0x02 // CAPSULE

	ha := HashSDF(a)
	hb := HashSDF(b)
	if ha == hb {
		t.Fatal("SPHERE và CAPSULE phải có hash khác nhau")
	}
}

func TestHashSDF_BirthdaySafe(t *testing.T) {
	// uint64: birthday collision ở √2^64 ≈ 4 tỷ — an toàn
	// uint32: birthday collision ở √2^32 ≈ 65K — nguy hiểm với Fibonacci đời 6
	var sdf [15]byte
	seen := make(map[NodeHash]bool, 1000)
	for i := 0; i < 1000; i++ {
		sdf[1] = byte(i)
		sdf[2] = byte(i >> 8)
		h := HashSDF(sdf)
		if seen[h] {
			t.Fatalf("collision tại i=%d — hash table không đủ rộng", i)
		}
		seen[h] = true
	}
}

func TestHashSDF32_Compat(t *testing.T) {
	// HashSDF32 phải nhất quán với HashSDF (upper 32 bits)
	var sdf [15]byte
	sdf[0] = 0x42
	h64 := HashSDF(sdf)
	h32 := HashSDF32(sdf)
	if uint32(h64>>32) != h32 {
		t.Fatal("HashSDF32 phải là upper 32 bits của HashSDF")
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST TierOf — tier detection từ byte đầu
// ─────────────────────────────────────────────────────────────────

func TestTierOf(t *testing.T) {
	cases := []struct {
		b    byte
		tier int
		name string
	}{
		{0x00, 1, "0x00 → Tier 1 (0xxxxxxx)"},
		{0x7F, 1, "0x7F → Tier 1 (0xxxxxxx)"},
		{0x80, 2, "0x80 → Tier 2 (10xxxxxx)"},
		{0xBF, 2, "0xBF → Tier 2 (10xxxxxx)"},
		{0xC0, 3, "0xC0 → Tier 3 (110xxxxx)"},
		{0xDF, 3, "0xDF → Tier 3 (110xxxxx)"},
		{0xE0, 4, "0xE0 → Tier 4 (111xxxxx)"},
		{0xFF, 4, "0xFF → Tier 4 (111xxxxx)"},
	}
	for _, c := range cases {
		got := TierOf(c.b)
		if got != c.tier {
			t.Errorf("%s: got %d, want %d", c.name, got, c.tier)
		}
	}
}

func TestTierSize(t *testing.T) {
	if TierSize(1) != 2  { t.Error("Tier 1 phải là 2B") }
	if TierSize(2) != 4  { t.Error("Tier 2 phải là 4B") }
	if TierSize(3) != 8  { t.Error("Tier 3 phải là 8B") }
	if TierSize(4) != 16 { t.Error("Tier 4 phải là 16B") }
}

// ─────────────────────────────────────────────────────────────────
// TEST ISL2 — Tier 1 (2 bytes, L0 primitives)
// ─────────────────────────────────────────────────────────────────

func TestISL2_Primitives(t *testing.T) {
	// 20 SDF nguyên thủy phải có địa chỉ Tier 1
	primitives := []ISL2{
		ISL2_SPHERE, ISL2_CAPSULE, ISL2_BOX,
		ISL2_CYLINDER, ISL2_CONE, ISL2_TORUS,
		ISL2_ELLIPSOID, ISL2_PLANE, ISL2_VOID, ISL2_ROUNDBOX,
	}
	seen := make(map[ISL2]bool)
	for _, p := range primitives {
		if seen[p] { t.Errorf("duplicate primitive address: %v", p) }
		seen[p] = true
		if p.Tier() != 1 { t.Errorf("%v: Tier phải là 1", p) }
		if TierOf(p.Bytes()[0]) != 1 {
			t.Errorf("%v: byte đầu 0x%02X không phải Tier 1", p, p.Bytes()[0])
		}
	}
}

func TestISL2_BytePattern(t *testing.T) {
	// Tier 1: bit 15 phải là 0
	p := ISL2_SPHERE
	b := p.Bytes()
	if b[0]>>7 != 0 {
		t.Errorf("ISL2 byte đầu 0x%02X không có bit 15=0", b[0])
	}
}

func TestISL2_Similarity(t *testing.T) {
	// Giống hệt = 1.0
	if ISL2_SPHERE.Similarity(ISL2_SPHERE) != 1.0 {
		t.Error("SPHERE.Similarity(SPHERE) phải là 1.0")
	}
	// Cùng type, khác id = 0.8
	s1 := ISL2From(1, 1)
	s2 := ISL2From(1, 2)
	if ISL2(s1).Similarity(ISL2(s2)) != 0.8 {
		t.Error("cùng type khác id phải là 0.8")
	}
	// Khác type = 0.0
	if ISL2_SPHERE.Similarity(ISL2_BOX) != 0.0 {
		t.Error("SPHERE vs BOX phải là 0.0")
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST ISL4 — Tier 2 (4 bytes, L1-L7 semantic universe)
// ─────────────────────────────────────────────────────────────────

func TestISL4_BytePattern(t *testing.T) {
	// Tier 2: bits 31-30 phải là 10
	addr := ISL4From(7, 'A', 'a', 1) // Layer 7, Group A, Type a, ID 1
	b := addr.Bytes()
	topBits := b[0] >> 6
	if topBits != 0b10 {
		t.Errorf("ISL4 top 2 bits 0x%02X phải là 10, got %02b", b[0], topBits)
	}
}

func TestISL4_Roundtrip(t *testing.T) {
	// Tạo → bytes → parse → giống nhau
	original := ISL4From(3, 'B', 'c', 42)
	b := original.Bytes()
	
	tier := TierOf(b[0])
	if tier != 2 {
		t.Fatalf("ParseISLAddr phải nhận ra Tier 2, got %d", tier)
	}
	
	parsed, n := ParseISLAddr(b)
	if n != 4 {
		t.Fatalf("phải đọc 4 bytes, got %d", n)
	}
	if parsed.Uint64() != original.Uint64() {
		t.Errorf("roundtrip thất bại: got %d, want %d", parsed.Uint64(), original.Uint64())
	}
}

func TestISL4_FromAddress_Compat(t *testing.T) {
	// Address cũ (8B) → ISL4 (4B) phải giữ nguyên layer, group, type, id
	old := Address{Layer: 'L', Group: 'I', Type: 'f', ID: 3}
	new4 := ISL4FromAddress(old)
	
	if new4.Tier() != 2 { t.Error("phải là Tier 2") }
	wantLayer := byte('L' - 'A') // = 11
	if byte(new4.Layer()) != wantLayer {
		t.Errorf("layer: got %d, want %d", new4.Layer(), wantLayer)
	}
}

func TestISL4_Capacity(t *testing.T) {
	// ISL4 phải chứa được ít nhất 1 tỷ địa chỉ khác nhau
	// 64 × 256 × 64 × 1024 = 1,073,741,824
	maxNodes := uint64(64) * 256 * 64 * 1024
	if maxNodes < 1_000_000_000 {
		t.Errorf("ISL4 capacity %d < 1 tỷ", maxNodes)
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST ISL8 — Tier 3 (8 bytes, 1000T+)
// ─────────────────────────────────────────────────────────────────

func TestISL8_BytePattern(t *testing.T) {
	// Tier 3: bits 63-61 phải là 110
	addr := ISL8From(100, 200, 300, 400)
	b := addr.Bytes()
	topBits := b[0] >> 5
	if topBits != 0b110 {
		t.Errorf("ISL8 top 3 bits 0x%02X phải là 110, got %03b", b[0], topBits)
	}
}

func TestISL8_Roundtrip(t *testing.T) {
	original := ISL8From(1000, 2000, 3000, 4000)
	b := original.Bytes()
	
	parsed, n := ParseISLAddr(b)
	if n != 8 { t.Fatalf("phải đọc 8 bytes, got %d", n) }
	if parsed.Uint64() != original.Uint64() {
		t.Errorf("roundtrip thất bại")
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST ISL16 — Tier 4 (16 bytes, planetary)
// ─────────────────────────────────────────────────────────────────

func TestISL16_BytePattern(t *testing.T) {
	// Tier 4: bits 127-125 phải là 111
	addr := ISL16From("HomeOS.Origin.LOVE.concept")
	b := addr.Bytes()
	topBits := b[0] >> 5
	if topBits != 0b111 {
		t.Errorf("ISL16 top 3 bits phải là 111, got %03b", topBits)
	}
}

func TestISL16_Deterministic(t *testing.T) {
	a := ISL16From("same_descriptor")
	b := ISL16From("same_descriptor")
	if a != b { t.Error("ISL16From phải deterministic") }
	
	c := ISL16From("different_descriptor")
	if a == c { t.Error("địa chỉ khác nhau cho descriptor khác") }
}

// ─────────────────────────────────────────────────────────────────
// TEST ParseISLAddr — auto-detect tier
// ─────────────────────────────────────────────────────────────────

func TestParseISLAddr_AllTiers(t *testing.T) {
	// Tạo một addr mỗi tier, encode, parse lại
	addrs := []ISLAddr{
		ISL2_SPHERE,
		ISL4From(5, 'A', 'b', 10),
		ISL8From(50, 100, 200, 300),
		ISL16From("test.planetary.node"),
	}
	expectedTiers := []int{1, 2, 3, 4}
	expectedSizes := []int{2, 4, 8, 16}

	for i, addr := range addrs {
		b := addr.Bytes()
		parsed, n := ParseISLAddr(b)
		if n != expectedSizes[i] {
			t.Errorf("Tier %d: đọc %d bytes, want %d", i+1, n, expectedSizes[i])
		}
		if parsed.Tier() != expectedTiers[i] {
			t.Errorf("Tier %d: got tier %d", i+1, parsed.Tier())
		}
		if parsed.Uint64() != addr.Uint64() {
			t.Errorf("Tier %d: roundtrip thất bại", i+1)
		}
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST CRYSTALLIZATION — QT7 cho địa chỉ
// ─────────────────────────────────────────────────────────────────

func TestCrystallize(t *testing.T) {
	// Node bắt đầu là ISL4 (Tier 2)
	original := ISL4From(3, 'L', 'i', 1) // Life.i.1
	var sdf [15]byte
	sdf[0] = 0x42
	hash := HashSDF(sdf)

	// Sau khi crystallize → ISL2 (Tier 1)
	alias := Crystallize(original, hash, 0x20, 1)

	if alias.Original.Tier() != 2 { t.Error("original phải Tier 2") }
	if alias.Crystal.Tier() != 1  { t.Error("crystal phải Tier 1") }
	if alias.Hash != hash         { t.Error("NodeHash không đổi khi crystallize") }
	
	// Content address không đổi
	if alias.Hash != hash {
		t.Error("hash phải giữ nguyên sau crystallize")
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST KHÔNG OVERLAP giữa các tier (quan trọng nhất)
// ─────────────────────────────────────────────────────────────────

func TestTierNoOverlap(t *testing.T) {
	// Tier marker bits phải không overlap — mọi address đều unambiguous
	tier1 := ISL2_SPHERE.Bytes()
	tier2 := ISL4From(0, 0, 0, 0).Bytes()
	tier3 := ISL8From(0, 0, 0, 0).Bytes()
	tier4 := ISL16From("").Bytes()

	if TierOf(tier1[0]) != 1 { t.Error("SPHERE phải Tier 1") }
	if TierOf(tier2[0]) != 2 { t.Error("ISL4 zero phải Tier 2") }
	if TierOf(tier3[0]) != 3 { t.Error("ISL8 zero phải Tier 3") }
	if TierOf(tier4[0]) != 4 { t.Error("ISL16 zero phải Tier 4") }
}

// ─────────────────────────────────────────────────────────────────
// BENCHMARK
// ─────────────────────────────────────────────────────────────────

func BenchmarkHashSDF(b *testing.B) {
	var sdf [15]byte
	sdf[0] = 0x42
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sdf[1] = byte(i)
		_ = HashSDF(sdf)
	}
}

func BenchmarkParseISLAddr_Tier2(b *testing.B) {
	addr := ISL4From(5, 'A', 'b', 10).Bytes()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = ParseISLAddr(addr)
	}
}
