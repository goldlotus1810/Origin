// internal/isl/taxonomy.go
//
// ISL Domain Taxonomy — Layer byte = bản chất của node
// ════════════════════════════════════════════════════════════════
//
// QT5: bản chất quyết định vị trí.
// Layer byte (bits [7-4]) = DOMAIN — LeoAI đọc 1 mask là biết.
// Layer byte (bits [3-0]) = SUB-TYPE trong domain.
//
// Mọi node trong homeos.olang phải có Layer đúng taxonomy.
// LeoAI không cần "hỏi" — địa chỉ tự nói bản chất.
//
// ────────────────────────────────────────────────────────────────
// DOMAIN MAP (bits [7-4]):
//
//  0x0_ — PHYSICAL: tri thức vũ trụ vật lý
//    0x00  L0 SDF primitives (20 seeds, QR, bất biến)
//    0x01  L1 UTF-32 atoms (1280 ký tự)
//    0x02  L2 Nature (lửa, nước, gió...)
//    0x03  L3 Life (sinh vật, hành động sống)
//    0x04  L4 Objects (vật thể)
//    0x05  L5 Programming (khái niệm lập trình)
//    0x06  L6 Perception (nhận thức)
//    0x07  L7 Programs/Concepts (đã implement)
//
//  0x1_ — AGENT: thực thể có agency
//    0x10  Agent generic
//    0x11  AgentAAM (master)
//    0x12  AgentChief (coordinator)
//    0x13  AgentWorker (actuator, silent)
//    0x14  AgentLeoAI (intelligence)
//    0x1F  AgentComposed (LeoAI tự tạo)
//
//  0x2_ — SKILL: năng lực thực thi
//    0x20  Skill generic
//    0x21  SkillMemory (shortterm/longterm)
//    0x22  SkillLearning (cluster/dream/teach)
//    0x23  SkillActuator (light/hvac/lock)
//    0x24  SkillSecurity (gate 🛡)
//    0x25  SkillLanguage (encode/broadcast)
//    0x26  SkillPerception (audio/vision)
//    0x27  SkillDecision (decide4d)
//    0x28  SkillRoute (home chief)
//    0x2F  SkillComposed (LeoAI tự tạo)
//
//  0x3_ — SYSTEM/META: cấu hình và vận hành
//    0x30  Config
//    0x31  Route/Intent
//    0x32  Device (actuator endpoint)
//    0x33  Location
//    0x34  Owner/Identity
//    0x35  UI component
//    0x36  WorldRule (QT1-QT7)
//
//  0x4_ — LEARNING (ĐN): đang học, chưa chứng minh
//    0x40  Observation (raw input)
//    0x41  Pattern (đã cluster)
//    0x42  Concept (đang promote)
//    0x43  Hypothesis (đang kiểm chứng)
//
//  0x5_ — KNOWLEDGE (QR): đã chứng minh, bất biến
//    0x50  QR atomic
//    0x51  QR composed
//    0x52  QR signed (ED25519, weight≥200)
//    0x53  QR crystallized (tầng cao → tầng thấp)
//
//  0x6_ — LANGUAGE: đa ngôn ngữ, cross-script
//    0x60  Term (từ đơn)
//    0x61  Phrase (cụm từ)
//    0x62  Symbol (ký hiệu ≈ ♥ ∞ ○)
//    0x63  Phoneme (âm vị)
//    0x64  Script family (Latin/CJK/Devanagari...)
//
//  0x7_ — RELATION: liên kết ngữ nghĩa (meta-nodes cho BOND)
//    0x70  Equivalence (≡)
//    0x71  Composition (∘ — compose ancestry)
//    0x72  Similarity (≈)
//    0x73  Opposition (⊥)
//    0x74  PartOf (∈)
//    0x75  CrossLang (≡ cross-language)
//    0x76  Phonetic (♫)
//    0x77  Symbol link (♥→heart)
//
// ────────────────────────────────────────────────────────────────
// LeoAI đọc domain:
//   DomainOf(layer) = layer >> 4
//   IsAgent(layer)  = layer >> 4 == 0x1
//   IsSkill(layer)  = layer >> 4 == 0x2
//   IsQR(layer)     = layer >> 4 == 0x5
//   IsDN(layer)     = layer >> 4 == 0x4

package isl

// Domain là nhóm bản chất của node (4 bit cao của Layer)
type Domain byte

const (
	DomainPhysical  Domain = 0x0 // vũ trụ vật lý
	DomainAgent     Domain = 0x1 // thực thể có agency
	DomainSkill     Domain = 0x2 // năng lực thực thi
	DomainSystem    Domain = 0x3 // cấu hình/vận hành
	DomainLearning  Domain = 0x4 // ĐN — đang học
	DomainKnowledge Domain = 0x5 // QR — đã chứng minh
	DomainLanguage  Domain = 0x6 // đa ngôn ngữ
	DomainRelation  Domain = 0x7 // liên kết (meta)
)

// Sub-types cho từng domain
const (
	// Physical sub-types (Layer = 0x00..0x07)
	LayerL0Primitives  byte = 0x00
	LayerL1UTF32       byte = 0x01
	LayerL2Nature      byte = 0x02
	LayerL3Life        byte = 0x03
	LayerL4Objects     byte = 0x04
	LayerL5Programming byte = 0x05
	LayerL6Perception  byte = 0x06
	LayerL7Programs    byte = 0x07

	// Agent sub-types (Layer = 0x10..0x1F)
	LayerAgent         byte = 0x10
	LayerAgentAAM      byte = 0x11
	LayerAgentChief    byte = 0x12
	LayerAgentWorker   byte = 0x13
	LayerAgentLeoAI    byte = 0x14
	LayerAgentComposed byte = 0x1F

	// Skill sub-types (Layer = 0x20..0x2F)
	LayerSkill           byte = 0x20
	LayerSkillMemory     byte = 0x21
	LayerSkillLearning   byte = 0x22
	LayerSkillActuator   byte = 0x23
	LayerSkillSecurity   byte = 0x24
	LayerSkillLanguage   byte = 0x25
	LayerSkillPerception byte = 0x26
	LayerSkillDecision   byte = 0x27
	LayerSkillRoute      byte = 0x28
	LayerSkillComposed   byte = 0x2F

	// System/Meta sub-types (Layer = 0x30..0x3F)
	LayerConfig    byte = 0x30
	LayerRoute     byte = 0x31
	LayerDevice    byte = 0x32
	LayerLocation  byte = 0x33
	LayerOwner     byte = 0x34
	LayerUI        byte = 0x35
	LayerWorldRule byte = 0x36

	// Learning sub-types (Layer = 0x40..0x4F)
	LayerObservation byte = 0x40
	LayerPattern     byte = 0x41
	LayerConcept     byte = 0x42
	LayerHypothesis  byte = 0x43

	// Knowledge sub-types (Layer = 0x50..0x5F)
	LayerQRAtomic      byte = 0x50
	LayerQRComposed    byte = 0x51
	LayerQRSigned      byte = 0x52
	LayerQRCrystal     byte = 0x53

	// Language sub-types (Layer = 0x60..0x6F)
	LayerTerm     byte = 0x60
	LayerPhrase   byte = 0x61
	LayerSymbol   byte = 0x62
	LayerPhoneme  byte = 0x63
	LayerScript   byte = 0x64

	// Relation sub-types (Layer = 0x70..0x7F)
	LayerRelEquiv     byte = 0x70
	LayerRelCompose   byte = 0x71
	LayerRelSimilar   byte = 0x72
	LayerRelOpposite  byte = 0x73
	LayerRelPartOf    byte = 0x74
	LayerRelCrossLang byte = 0x75
	LayerRelPhonetic  byte = 0x76
	LayerRelSymbol    byte = 0x77
)

// ─────────────────────────────────────────────────────────────────
// DOMAIN QUERY — O(1) mask operations
// LeoAI dùng các hàm này để đọc bản chất từ địa chỉ
// ─────────────────────────────────────────────────────────────────

// DomainOf trả về domain từ layer byte (O(1))
func DomainOf(layer byte) Domain {
	return Domain(layer >> 4)
}

// IsAgent: LeoAI biết đây là agent để routing đúng tầng
func IsAgent(layer byte) bool { return layer>>4 == 0x1 }

// IsSkill: LeoAI biết đây là skill để query capabilities
func IsSkill(layer byte) bool { return layer>>4 == 0x2 }

// IsSystem: config, device, location — không học, không thay đổi
func IsSystem(layer byte) bool { return layer>>4 == 0x3 }

// IsDN: đang học — có thể sửa, cần validate
func IsDN(layer byte) bool { return layer>>4 == 0x4 }

// IsQR: đã chứng minh — bất biến, chỉ đọc
func IsQR(layer byte) bool { return layer>>4 == 0x5 }

// IsPhysical: tri thức vũ trụ vật lý (L0-L7)
func IsPhysical(layer byte) bool { return layer>>4 == 0x0 }

// IsLanguage: node đa ngôn ngữ
func IsLanguage(layer byte) bool { return layer>>4 == 0x6 }

// IsRelation: meta-node liên kết
func IsRelation(layer byte) bool { return layer>>4 == 0x7 }

// DomainName trả về tên human-readable của domain
func DomainName(layer byte) string {
	switch DomainOf(layer) {
	case DomainPhysical:  return "Physical"
	case DomainAgent:     return "Agent"
	case DomainSkill:     return "Skill"
	case DomainSystem:    return "System"
	case DomainLearning:  return "Learning(ĐN)"
	case DomainKnowledge: return "Knowledge(QR)"
	case DomainLanguage:  return "Language"
	case DomainRelation:  return "Relation"
	default:              return "Unknown"
	}
}

// LayerName trả về tên chi tiết của layer byte
func LayerName(layer byte) string {
	names := map[byte]string{
		0x00: "L0.SDF",       0x01: "L1.UTF32",    0x02: "L2.Nature",
		0x03: "L3.Life",      0x04: "L4.Objects",  0x05: "L5.Programming",
		0x06: "L6.Perception",0x07: "L7.Programs",
		0x10: "Agent",        0x11: "Agent.AAM",   0x12: "Agent.Chief",
		0x13: "Agent.Worker", 0x14: "Agent.LeoAI", 0x1F: "Agent.Composed",
		0x20: "Skill",        0x21: "Skill.Memory",0x22: "Skill.Learning",
		0x23: "Skill.Actuator",0x24:"Skill.Security",0x25:"Skill.Language",
		0x26: "Skill.Perception",0x27:"Skill.Decision",0x28:"Skill.Route",
		0x2F: "Skill.Composed",
		0x30: "Sys.Config",   0x31: "Sys.Route",   0x32: "Sys.Device",
		0x33: "Sys.Location", 0x34: "Sys.Owner",   0x35: "Sys.UI",
		0x36: "Sys.Rule",
		0x40: "DN.Observation",0x41:"DN.Pattern",  0x42:"DN.Concept",
		0x50: "QR.Atomic",    0x51: "QR.Composed", 0x52: "QR.Signed",
		0x53: "QR.Crystal",
		0x60: "Lang.Term",    0x61: "Lang.Phrase",  0x62: "Lang.Symbol",
		0x63: "Lang.Phoneme", 0x64: "Lang.Script",
		0x70: "Rel.Equiv",    0x71: "Rel.Compose",  0x72: "Rel.Similar",
		0x73: "Rel.Opposite", 0x74: "Rel.PartOf",   0x75: "Rel.CrossLang",
		0x76: "Rel.Phonetic", 0x77: "Rel.Symbol",
	}
	if name, ok := names[layer]; ok {
		return name
	}
	return DomainName(layer)
}

// ─────────────────────────────────────────────────────────────────
// EDGE TYPES — bản chất của liên kết
// ─────────────────────────────────────────────────────────────────
//
// Phân loại theo chiều của liên kết:
//
//  STRUCTURAL (cây vật lý):
//    0x01  PartOf    (A ∈ B)     — A là bộ phận của B
//    0x02  IsA       (A ⊂ B)     — A là loại B (inheritance)
//    0x03  HasPart   (A ∋ B)     — A chứa B
//
//  COMPOSE ANCESTRY (DNA chain):
//    0x10  ComposeChild  (C → A)  — C được tạo từ A (A là cha)
//    0x11  ComposeParent (A → C)  — A tham gia vào C
//    0x12  ComposePeer   (A ↔ B)  — A và B là anh em trong cùng compose
//
//  SEMANTIC (ngữ nghĩa ngang):
//    0x20  Equivalent  (A ≡ B)   — tương đương bản chất
//    0x21  Similar     (A ≈ B)   — tương tự
//    0x22  Opposite    (A ⊥ B)   — đối lập
//    0x23  Causes      (A → B)   — A gây ra B
//    0x24  Enables     (A ⊢ B)   — A cho phép B
//
//  CROSS-LANGUAGE:
//    0x30  Translation (A ≡ B)   — LOVE ≡ Yêu ≡ 愛
//    0x31  Phonetic    (A ♫ B)   — cùng âm qua IPA
//    0x32  Script      (A≡B diff script) — A/α/А
//    0x33  SymbolOf    (A ≈ ♥)   — từ ≈ biểu tượng
//    0x34  Phoneme     (Yêu∈Y,Ê,U) — âm tiết → âm vị
//
//  LEGACY (giữ tương thích):
//    0x08  WorldLink   (legacy)
//    0x09  IsA-legacy  (legacy)
//    0x0A  HasPart-legacy
//    0x0C  Similar-legacy
//    0x0D  Context-legacy

type EdgeType byte

const (
	// Structural
	EdgePartOf   EdgeType = 0x01
	EdgeIsA      EdgeType = 0x02
	EdgeHasPart  EdgeType = 0x03

	// Compose ancestry — QUAN TRỌNG: tự động tạo khi compose
	EdgeComposeChild  EdgeType = 0x10 // C → A: C được tạo từ A
	EdgeComposeParent EdgeType = 0x11 // A → C: A tham gia vào C
	EdgeComposePeer   EdgeType = 0x12 // A ↔ B: anh em trong compose

	// Semantic
	EdgeEquivalent EdgeType = 0x20
	EdgeSimilar    EdgeType = 0x21
	EdgeOpposite   EdgeType = 0x22
	EdgeCauses     EdgeType = 0x23
	EdgeEnables    EdgeType = 0x24

	// Cross-language
	EdgeTranslation EdgeType = 0x30
	EdgePhonetic    EdgeType = 0x31
	EdgeScript      EdgeType = 0x32
	EdgeSymbolOf    EdgeType = 0x33
	EdgePhoneme     EdgeType = 0x34

	// Legacy — giữ tương thích ngược
	EdgeLegacyWorld   EdgeType = 0x08
	EdgeLegacyIsA     EdgeType = 0x09
	EdgeLegacyHasPart EdgeType = 0x0A
	EdgeLegacySimilar EdgeType = 0x0C
	EdgeLegacyContext EdgeType = 0x0D
)

// EdgeName trả về tên human-readable
func EdgeName(t EdgeType) string {
	names := map[EdgeType]string{
		EdgePartOf: "PartOf(∈)", EdgeIsA: "IsA(⊂)", EdgeHasPart: "HasPart(∋)",
		EdgeComposeChild: "ComposeChild(C→A)", EdgeComposeParent: "ComposeParent(A→C)",
		EdgeComposePeer: "ComposePeer(A↔B)",
		EdgeEquivalent: "Equivalent(≡)", EdgeSimilar: "Similar(≈)",
		EdgeOpposite: "Opposite(⊥)", EdgeCauses: "Causes(→)", EdgeEnables: "Enables(⊢)",
		EdgeTranslation: "Translation(≡lang)", EdgePhonetic: "Phonetic(♫)",
		EdgeScript: "Script(≡script)", EdgeSymbolOf: "SymbolOf(≈♥)",
		EdgePhoneme: "Phoneme(∈syllable)",
		EdgeLegacyWorld: "WorldLink", EdgeLegacyIsA: "IsA-legacy",
		EdgeLegacyHasPart: "HasPart-legacy", EdgeLegacySimilar: "Similar-legacy",
		EdgeLegacyContext: "Context-legacy",
	}
	if n, ok := names[t]; ok { return n }
	return "Unknown"
}

// ─────────────────────────────────────────────────────────────────
// COMPOSE EDGE RULES — tự động khi compose
// ─────────────────────────────────────────────────────────────────
//
// Khi compose(A, B) → C:
//   1. C ──ComposeChild──► A   "C được tạo từ A"
//   2. C ──ComposeChild──► B   "C được tạo từ B"
//   3. A ──ComposeParent──► C  "A tham gia vào C"
//   4. B ──ComposeParent──► C  "B tham gia vào C"
//   5. A ──ComposePeer──► B    "A và B là anh em"
//   6. B ──ComposePeer──► A    (ngược lại)
//
// VÍ DỤ: LOVE = L++O++V++E
//   compose(LOV, E) → LOVE:
//     LOVE ──ComposeChild──► LOV
//     LOVE ──ComposeChild──► E
//     LOV  ──ComposeParent──► LOVE
//     E    ──ComposeParent──► LOVE
//     LOV  ──ComposePeer──► E
//     E    ──ComposePeer──► LOV
//
//   compose(LO, V) → LOV:
//     LOV ──ComposeChild──► LO
//     LOV ──ComposeChild──► V
//     LO  ──ComposeParent──► LOV  → truy vết được: V biết nó là V trong LOV
//     ...
//
// LeoAI có thể WALK ngược:
//   LOVE.ComposeChild → LOV → LO → L, O
//   Biết LOVE cấu thành từ L, O, V, E

// ComposeEdges trả về 6 edges cần tạo khi compose(A, B) → C
type ComposeEdgePair struct {
	From, To   uint64   // ISL uint64
	Type       EdgeType
}

func ComposeEdges(hashA, hashB, hashC uint64) []ComposeEdgePair {
	return []ComposeEdgePair{
		{hashC, hashA, EdgeComposeChild},  // C biết A là cha
		{hashC, hashB, EdgeComposeChild},  // C biết B là cha
		{hashA, hashC, EdgeComposeParent}, // A biết C là con
		{hashB, hashC, EdgeComposeParent}, // B biết C là con
		{hashA, hashB, EdgeComposePeer},   // A và B là anh em
		{hashB, hashA, EdgeComposePeer},   // ngược lại
	}
}

// ─────────────────────────────────────────────────────────────────
// CROSS-LANGUAGE LINK RULES
// ─────────────────────────────────────────────────────────────────
//
// LOVE ──Translation──► Yêu ──Translation──► 愛
// Yêu  ──Phoneme──► Y ──Phoneme──► Ê ──Phoneme──► U
// Yêu  ──SymbolOf──► ♥
// ♥    ──SymbolOf──► heart
// heart ──Translation──► tim ──Translation──► coeur

// TranslationGroup là một nhóm node cùng nghĩa trong các ngôn ngữ khác nhau
// Silk edges được tạo theo ring: A→B→C→A (mọi node biết mọi node khác)
type TranslationGroup struct {
	Concept   string   // tên khái niệm (ví dụ: "love")
	Members   []uint64 // ISL uint64 của các node dịch thuật
	Lang      []string // ngôn ngữ tương ứng
}

// TranslationEdges trả về edges cho một translation group
// Ring topology: A→B, B→C, C→A (tránh O(n²) với n nhỏ)
func (g TranslationGroup) TranslationEdges() []ComposeEdgePair {
	n := len(g.Members)
	if n < 2 { return nil }
	edges := make([]ComposeEdgePair, n)
	for i := 0; i < n; i++ {
		edges[i] = ComposeEdgePair{
			From: g.Members[i],
			To:   g.Members[(i+1)%n],
			Type: EdgeTranslation,
		}
	}
	return edges
}

// WellKnownTranslations là các nhóm dịch thuật seed ban đầu
// Thêm dần khi hệ thống học
var WellKnownTranslations = []TranslationGroup{
	{
		Concept: "love",
		Members: []uint64{}, // sẽ fill khi LOVE, Yêu, 愛 có ISL
		Lang:    []string{"en", "vi", "zh"},
	},
	{
		Concept: "heart_symbol",
		Members: []uint64{}, // ♥, heart, tim, coeur
		Lang:    []string{"symbol", "en", "vi", "fr"},
	},
}
