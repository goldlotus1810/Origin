// internal/isl/addr.go
//
// ISL Variable-Length Address System
// ════════════════════════════════════════════════════════════════
//
// TRIẾT LÝ (QT5: bản chất quyết định vị trí):
//   Node đơn giản → địa chỉ ngắn
//   Node phức tạp → địa chỉ dài
//   Địa chỉ phản ánh bản chất, không phải thứ tự xuất hiện.
//
// HAI LOẠI ĐỊA CHỈ (QT6: SDF=hữu hình, ISL=vô hình):
//
//   NodeHash (uint64) = CONTENT ADDRESS = "node này là gì"
//     hash(SDF.b[0..14]) → uint64
//     Bất biến tuyệt đối. Birthday-safe đến ~4 tỷ nodes.
//     Dùng: COMPOSE nhớ A,B; Universe lookup O(1)
//
//   ISLAddr (interface) = SEMANTIC ADDRESS = "node này thuộc về đâu"
//     Tọa độ trong không gian ngữ nghĩa.
//     Size thay đổi theo tầng (như SLI — QT5 nhất quán).
//     Dùng: Silk walk, similarity search, routing
//
// BỐN TIER ISL:
//
//   Tier 1 — ISL2 (2 bytes, uint16):
//     bit pattern: 0xxxxxxxxxxxxxxx
//     [0][type:7bit][id:8bit]
//     Capacity: 128 types × 256 = 32,768 nodes
//     Dùng cho: L0 primitives (20 SDF gốc), crystallized atoms
//     Ví dụ: ● SPHERE = ISL2(0x0101)
//
//   Tier 2 — ISL4 (4 bytes, uint32):
//     bit pattern: 10xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
//     [10][layer:6bit][group:8bit][type:6bit][id:10bit]
//     Capacity: 64L × 256G × 64T × 1024 = 1,073,741,824 (~1 tỷ)
//     Dùng cho: L1-L7 semantic universe (hiện tại)
//     Ví dụ: LIFE.Animal.Bird.1 = ISL4(0x83_42_01_01)
//
//   Tier 3 — ISL8 (8 bytes, uint64):
//     bit pattern: 110xxxxx...
//     [110][layer:13bit][group:16bit][type:16bit][id:16bit][attr:3bit]
//     Capacity: ~10^18 — thực tế không giới hạn
//     Dùng cho: runtime-generated nodes, composed concepts, 1000T+
//
//   Tier 4 — ISL16 (16 bytes, [16]byte):
//     bit pattern: 111xxxxx...
//     Content-addressed: sha256(semantic_fingerprint)[0:16]
//     Capacity: 2^128 — planetary scale
//     Dùng cho: cross-system, federated knowledge graphs
//
// CRYSTALLIZATION (QT7 cho địa chỉ):
//   Khi node Tier 3/4 được promote đủ (fire≥3, w_in≥0.7) và
//   trở thành primitive của tầng đó → nhận thêm alias Tier 1/2.
//   Content address (NodeHash) không đổi.
//   ISL mới ngắn hơn = vai trò mới trong cây.
//
// TƯƠNG THÍCH NGƯỢC:
//   Address struct hiện tại = Tier 2 (ISL4) với encoding khác.
//   Mọi code dùng Address tiếp tục hoạt động.
//   ISLAddr interface bổ sung, không thay thế.

package isl

import (
	"crypto/sha256"
	"encoding/binary"
)

// ─────────────────────────────────────────────────────────────────
// NODE HASH — Content Address (QT1: hash(SDF) = địa chỉ trong Universe)
// ─────────────────────────────────────────────────────────────────

// NodeHash là fingerprint bất biến của một node — hash(SDF.b[0..14]).
// Khác với ISLAddr (semantic position), NodeHash là identity.
// Hai node khác nhau KHÔNG THỂ có cùng NodeHash.
//
// Dùng uint64 thay vì uint32:
//   uint32 → birthday collision ở ~65K nodes (√2^32)
//   uint64 → birthday collision ở ~4 tỷ nodes (√2^64)
//   Fibonacci đời 6 = 59K nodes → uint32 gần ngưỡng nguy hiểm
type NodeHash uint64

// HashSDF tính NodeHash từ 15 bytes SDF nhân.
// Thuật toán: sha256(sdf)[0:8] as big-endian uint64.
// SLI không tham gia hash — reset SLI không đổi địa chỉ.
func HashSDF(sdf [15]byte) NodeHash {
	// Padding theo SHA-256: message=120bits, pad đến 512bits
	var blk [64]byte
	copy(blk[:15], sdf[:])
	blk[15] = 0x80            // padding bit
	blk[62] = 0               // length high byte (120 < 256)
	blk[63] = 120             // length = 15*8 = 120 bits
	sum := sha256.Sum256(blk[:])
	return NodeHash(binary.BigEndian.Uint64(sum[:8]))
}

// HashSDF32 — tương thích ngược với code cũ dùng uint32.
// DEPRECATED: dùng HashSDF thay thế.
func HashSDF32(sdf [15]byte) uint32 {
	h := HashSDF(sdf)
	return uint32(h >> 32)
}

// ─────────────────────────────────────────────────────────────────
// ISLAddr INTERFACE — Semantic Address (variable length)
// ─────────────────────────────────────────────────────────────────

// ISLAddr là địa chỉ ngữ nghĩa — tọa độ trong không gian ý nghĩa.
// Khác với NodeHash (identity), ISLAddr là position.
// Cùng node có thể có nhiều ISLAddr (aliases khi crystallize).
type ISLAddr interface {
	// Tier trả về độ dài: 1=2B, 2=4B, 3=8B, 4=16B
	Tier() int

	// Layer trả về tầng ngữ nghĩa (tương đương SLI.layer)
	// Tier 1: 0-127, Tier 2: 0-63, Tier 3: 0-8191
	Layer() uint16

	// Bytes trả về binary representation (2, 4, 8, hoặc 16 bytes)
	Bytes() []byte

	// Uint64 trả về canonical form để dùng làm map key.
	// Tier 1: zero-extended. Tier 3/4: high bits.
	Uint64() uint64

	// Similarity đo độ gần ngữ nghĩa (0.0=khác hoàn toàn, 1.0=giống hệt)
	Similarity(other ISLAddr) float32

	// String trả về human-readable form
	String() string
}

// ─────────────────────────────────────────────────────────────────
// ISL2 — Tier 1 (2 bytes) — L0 primitives và crystallized atoms
// ─────────────────────────────────────────────────────────────────
//
// Layout: [0][type:7bit][id:8bit]
//   bit 15 = 0 (Tier 1 marker)
//   bits 14-8 = type (0-127): loại primitive
//   bits 7-0  = id (0-255): instance trong type
//
// 128 × 256 = 32,768 slots — đủ cho mọi L0 primitive có thể có
//
// Ví dụ:
//   ISL2(0x01_01) = type=1 (SPHERE), id=1
//   ISL2(0x02_01) = type=2 (CAPSULE), id=1
//   ISL2(0x10_01) = type=16 (LIFE.crystallized), id=1

type ISL2 uint16

// Predefined L0 primitive addresses (20 SDF gốc)
const (
	ISL2_SPHERE    ISL2 = 0x0101
	ISL2_CAPSULE   ISL2 = 0x0201
	ISL2_BOX       ISL2 = 0x0301
	ISL2_CYLINDER  ISL2 = 0x0401
	ISL2_CONE      ISL2 = 0x0501
	ISL2_TORUS     ISL2 = 0x0601
	ISL2_ELLIPSOID ISL2 = 0x0701
	ISL2_PLANE     ISL2 = 0x0801
	ISL2_VOID      ISL2 = 0x0901 // ◌ — khoảng trống, tiềm năng
	ISL2_ROUNDBOX  ISL2 = 0x0A01
	ISL2_HEXPRISM  ISL2 = 0x0B01
	// ... 9 primitives còn lại từ 0x0C-0x14
)

func (a ISL2) Tier() int   { return 1 }
func (a ISL2) Layer() uint16 {
	// Type byte encode domain layer: 0x01-0x0F = L0, 0x10-0x1F = L1 crystallized...
	return uint16(a>>8) >> 4
}
func (a ISL2) Bytes() []byte {
	return []byte{byte(a >> 8), byte(a)}
}
func (a ISL2) Uint64() uint64 { return uint64(a) }
func (a ISL2) String() string {
	typeNames := map[byte]string{
		1:"SPHERE", 2:"CAPSULE", 3:"BOX", 4:"CYLINDER",
		5:"CONE", 6:"TORUS", 7:"ELLIPSOID", 8:"PLANE",
		9:"VOID", 10:"ROUND_BOX", 11:"HEX_PRISM",
	}
	t := byte(a >> 8)
	name, ok := typeNames[t]
	if !ok { name = "?" }
	return name + "." + string(rune('0'+byte(a)))
}
func (a ISL2) Similarity(other ISLAddr) float32 {
	if b, ok := other.(ISL2); ok {
		// Cùng type = similarity 0.8, cùng id = 1.0
		if byte(a>>8) == byte(b>>8) {
			if a == b { return 1.0 }
			return 0.8
		}
	}
	return 0.0 // khác tier hoặc khác type
}

// ISL2From tạo ISL2 từ type và id
func ISL2From(typ, id byte) ISL2 {
	return ISL2(uint16(typ)<<8 | uint16(id))
}

// ─────────────────────────────────────────────────────────────────
// ISL4 — Tier 2 (4 bytes) — Semantic universe L0-L7 + Agent + Skill + System...
// ─────────────────────────────────────────────────────────────────
//
// Layout: [10][layer:7bit][group:7bit][type:6bit][id:10bit]
//   bits 31-30 = 10 (Tier 2 marker)
//   bits 29-23 = layer (0-127) ← 7 bits để fit taxonomy 0x00-0x7F
//   bits 22-16 = group (0-127) ← 7 bits
//   bits 15-10 = type (0-63)
//   bits 9-0   = id (0-1023)
//
// 128 × 128 × 64 × 1024 = 1,073,741,824 (~1 tỷ) slots — unchanged
//
// Layer 0x00-0x7F maps directly to taxonomy:
//   0x0x = Physical, 0x1x = Agent, 0x2x = Skill,
//   0x3x = System,   0x4x = Learning(ĐN), 0x5x = Knowledge(QR),
//   0x6x = Language, 0x7x = Relation

type ISL4 uint32

func (a ISL4) Tier() int { return 2 }
func (a ISL4) Layer() uint16 { return uint16((a >> 23) & 0x7F) } // 7 bits
func (a ISL4) Group() byte   { return byte((a >> 16) & 0x7F) }   // 7 bits
func (a ISL4) Type4() byte   { return byte((a >> 10) & 0x3F) }
func (a ISL4) ID4() uint16   { return uint16(a & 0x3FF) }

func (a ISL4) Bytes() []byte {
	b := make([]byte, 4)
	binary.BigEndian.PutUint32(b, uint32(a))
	return b
}
func (a ISL4) Uint64() uint64 { return uint64(a) }
func (a ISL4) String() string {
	return layerName4(byte(a.Layer())) + "." +
		string(rune('A'+a.Group()%26)) + "." +
		string(rune('a'+a.Type4()%26)) + "." +
		string(rune('0'+int(a.ID4()%10)))
}
func (a ISL4) Similarity(other ISLAddr) float32 {
	b, ok := other.(ISL4)
	if !ok { return 0 }
	score, weight := float32(0), float32(0)
	if a.Layer() == b.Layer() { score += 3; weight += 3 }
	if a.Group() == b.Group() { score += 2; weight += 2 }
	if a.Type4() == b.Type4() { score += 2; weight += 2 }
	if a == b               { score += 5; weight += 5 }
	if weight == 0 { return 0 }
	return score / weight
}

// ISL4From tạo ISL4 từ các thành phần
// layer: 0-127 (7 bits, fit taxonomy 0x00-0x7F)
// group: 0-127 (7 bits)
// typ:   0-63  (6 bits)
// id:    0-1023 (10 bits)
func ISL4From(layer, group, typ byte, id uint16) ISL4 {
	v := uint32(0x80000000) // bits 31-30 = 10
	v |= uint32(layer&0x7F) << 23
	v |= uint32(group&0x7F) << 16
	v |= uint32(typ&0x3F) << 10
	v |= uint32(id & 0x3FF)
	return ISL4(v)
}

// ISL4FromAddress chuyển Address cũ (8B) sang ISL4 (4B)
func ISL4FromAddress(a Address) ISL4 {
	layer := byte(0)
	if a.Layer >= 'A' && a.Layer <= 'Z' {
		layer = a.Layer - 'A' // A=0, Z=25 — fit trong 7 bits
	}
	group := a.Group & 0x7F
	typ   := byte(0)
	if a.Type >= 'a' && a.Type <= 'z' {
		typ = a.Type - 'a'
	}
	id := uint16(a.ID)
	return ISL4From(layer, group, typ, id)
}

func layerName4(l byte) string {
	names := []string{"L0","L1","L2","L3","L4","L5","L6","L7","L8","L9"}
	if int(l) < len(names) { return names[l] }
	return "L?"
}

// ─────────────────────────────────────────────────────────────────
// ISL8 — Tier 3 (8 bytes) — Runtime nodes, 1000T+ scale
// ─────────────────────────────────────────────────────────────────
//
// Layout: [110][layer:13bit][group:16bit][type:16bit][id:16bit][attr:2bit]
//   bits 63-61 = 110 (Tier 3 marker)
//   bits 60-48 = layer (0-8191)
//   bits 47-32 = group (0-65535)
//   bits 31-16 = type (0-65535)
//   bits 15-2  = id (0-16383)
//   bits 1-0   = attr (0-3): tinh chỉnh thêm
//
// ~10^18 slots — đủ cho 1000 tỷ nodes với room thừa

type ISL8 uint64

func (a ISL8) Tier() int { return 3 }
func (a ISL8) Layer() uint16 { return uint16((a >> 48) & 0x1FFF) }
func (a ISL8) Group() uint16 { return uint16((a >> 32) & 0xFFFF) }
func (a ISL8) Type8() uint16 { return uint16((a >> 16) & 0xFFFF) }
func (a ISL8) ID8() uint16   { return uint16((a >> 2) & 0x3FFF) }

func (a ISL8) Bytes() []byte {
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, uint64(a))
	return b
}
func (a ISL8) Uint64() uint64 { return uint64(a) }
func (a ISL8) String() string {
	return "T3.L" + fmt16(uint64(a.Layer())) + ".G" + fmt16(uint64(a.Group()))
}
func (a ISL8) Similarity(other ISLAddr) float32 {
	b, ok := other.(ISL8)
	if !ok { return 0 }
	score, weight := float32(0), float32(0)
	if a.Layer() == b.Layer() { score += 3; weight += 3 }
	if a.Group() == b.Group() { score += 2; weight += 2 }
	if a.Type8() == b.Type8() { score += 2; weight += 2 }
	if a == b               { score += 5; weight += 5 }
	if weight == 0 { return 0 }
	return score / weight
}

// ISL8From tạo ISL8 từ các thành phần
func ISL8From(layer, group, typ, id uint16) ISL8 {
	v := uint64(0xC000000000000000) // bits 63-61 = 110
	v |= uint64(layer&0x1FFF) << 48
	v |= uint64(group) << 32
	v |= uint64(typ) << 16
	v |= uint64(id&0x3FFF) << 2
	return ISL8(v)
}

// ─────────────────────────────────────────────────────────────────
// ISL16 — Tier 4 (16 bytes) — Planetary scale, content-addressed
// ─────────────────────────────────────────────────────────────────
//
// Layout: [111][...125bit semantic fingerprint...]
//   Computed as: sha256(semantic_descriptor)[0:16]
//   với bits 127-125 = 111 (Tier 4 marker, force-set)
//
// 2^128 slots — không bao giờ collision trong thực tế
// Dùng cho federated knowledge graphs, cross-system nodes

type ISL16 [16]byte

func (a ISL16) Tier() int { return 4 }
func (a ISL16) Layer() uint16 {
	// Layer encode trong bytes 1-2 (sau 3 tier bits)
	return uint16(a[1])<<5 | uint16(a[2]>>3)
}
func (a ISL16) Bytes() []byte { b := make([]byte, 16); copy(b, a[:]); return b }
func (a ISL16) Uint64() uint64 { return binary.BigEndian.Uint64(a[:8]) }
func (a ISL16) String() string { return "T4." + hex8(a[:4]) }
func (a ISL16) Similarity(other ISLAddr) float32 {
	b, ok := other.(ISL16)
	if !ok { return 0 }
	// So sánh từng byte — nhiều byte giống = similarity cao
	same := 0
	for i := 0; i < 16; i++ {
		if a[i] == b[i] { same++ }
	}
	return float32(same) / 16.0
}

// ISL16From tạo ISL16 từ semantic descriptor string
// sha256(descriptor)[0:16] với tier bits forced
func ISL16From(descriptor string) ISL16 {
	sum := sha256.Sum256([]byte(descriptor))
	var a ISL16
	copy(a[:], sum[:16])
	// Force bits 127-125 = 111 (Tier 4 marker)
	a[0] = (a[0] & 0x1F) | 0xE0
	return a
}

// ─────────────────────────────────────────────────────────────────
// TIER DETECTION — đọc tier từ bytes
// ─────────────────────────────────────────────────────────────────

// TierOf đọc tier từ byte đầu của một ISL address
// Gọi khi parse binary stream (homeos.olang, ISL messages)
func TierOf(firstByte byte) int {
	switch {
	case firstByte>>7 == 0:    return 1 // 0xxxxxxx → Tier 1 (2B)
	case firstByte>>6 == 0b10: return 2 // 10xxxxxx → Tier 2 (4B)
	case firstByte>>5 == 0b110:return 3 // 110xxxxx → Tier 3 (8B)
	default:                   return 4 // 111xxxxx → Tier 4 (16B)
	}
}

// TierSize trả về số bytes của tier
func TierSize(tier int) int {
	return []int{0, 2, 4, 8, 16}[tier]
}

// ParseISLAddr parse ISLAddr từ byte slice, trả về addr và số bytes đã đọc
func ParseISLAddr(b []byte) (ISLAddr, int) {
	if len(b) == 0 { return ISL2(0), 0 }
	tier := TierOf(b[0])
	size := TierSize(tier)
	if len(b) < size { return ISL2(0), 0 }
	switch tier {
	case 1:
		return ISL2(binary.BigEndian.Uint16(b[:2])), 2
	case 2:
		return ISL4(binary.BigEndian.Uint32(b[:4])), 4
	case 3:
		return ISL8(binary.BigEndian.Uint64(b[:8])), 8
	case 4:
		var a ISL16
		copy(a[:], b[:16])
		return a, 16
	}
	return ISL2(0), 0
}

// ─────────────────────────────────────────────────────────────────
// CRYSTALLIZATION — promote ISL sang tier thấp hơn (QT7)
// ─────────────────────────────────────────────────────────────────

// CrystalAlias là alias ngắn hơn được trao cho node khi crystallize.
// Node giữ NodeHash cũ (identity không đổi).
// ISL mới ngắn hơn = vai trò primitive trong tầng thấp hơn.
type CrystalAlias struct {
	Original ISLAddr // địa chỉ cũ (dài hơn)
	Crystal  ISLAddr // địa chỉ mới (ngắn hơn)
	Hash     NodeHash // content address — không đổi
}

// Crystallize tạo alias Tier 1 cho một node Tier 2+
// Gọi khi: fire>=3 AND w_in>=0.7 AND node là primitive domain của tầng đó
func Crystallize(original ISLAddr, hash NodeHash, primitiveType, id byte) CrystalAlias {
	return CrystalAlias{
		Original: original,
		Crystal:  ISL2From(primitiveType, id),
		Hash:     hash,
	}
}

// ─────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────

func hex8(b []byte) string {
	const h = "0123456789abcdef"
	out := make([]byte, len(b)*2)
	for i, c := range b {
		out[i*2]   = h[c>>4]
		out[i*2+1] = h[c&0xF]
	}
	return string(out)
}

func fmt16(v uint64) string {
	if v == 0 { return "0" }
	buf := [20]byte{}
	pos := 20
	for v > 0 {
		pos--
		buf[pos] = byte('0' + v%10)
		v /= 10
	}
	return string(buf[pos:])
}
