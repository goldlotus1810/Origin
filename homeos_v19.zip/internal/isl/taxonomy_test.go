// internal/isl/taxonomy_test.go
package isl

import "testing"

// ─────────────────────────────────────────────────────────────────
// TEST DOMAIN DETECTION — LeoAI đọc bản chất từ địa chỉ
// ─────────────────────────────────────────────────────────────────

func TestDomainOf_AllDomains(t *testing.T) {
	cases := []struct {
		layer  byte
		domain Domain
		name   string
	}{
		{0x00, DomainPhysical,  "L0 SDF"},
		{0x03, DomainPhysical,  "L3 Life"},
		{0x07, DomainPhysical,  "L7 Programs"},
		{0x10, DomainAgent,     "Agent generic"},
		{0x11, DomainAgent,     "Agent AAM"},
		{0x14, DomainAgent,     "Agent LeoAI"},
		{0x1F, DomainAgent,     "Agent Composed"},
		{0x20, DomainSkill,     "Skill generic"},
		{0x21, DomainSkill,     "Skill Memory"},
		{0x24, DomainSkill,     "Skill Security"},
		{0x2F, DomainSkill,     "Skill Composed"},
		{0x30, DomainSystem,    "System Config"},
		{0x32, DomainSystem,    "System Device"},
		{0x40, DomainLearning,  "ĐN Observation"},
		{0x42, DomainLearning,  "ĐN Concept"},
		{0x50, DomainKnowledge, "QR Atomic"},
		{0x52, DomainKnowledge, "QR Signed"},
		{0x60, DomainLanguage,  "Lang Term"},
		{0x62, DomainLanguage,  "Lang Symbol"},
		{0x70, DomainRelation,  "Rel Equiv"},
		{0x75, DomainRelation,  "Rel CrossLang"},
	}
	for _, c := range cases {
		got := DomainOf(c.layer)
		if got != c.domain {
			t.Errorf("Layer 0x%02X (%s): domain=%v, want %v", c.layer, c.name, got, c.domain)
		}
	}
}

func TestLeoAI_ReadAddress(t *testing.T) {
	// Mô phỏng LeoAI nhìn vào địa chỉ và hiểu bản chất

	// SKILL_BROADCAST → layer 0x25 = Skill.Language
	skillLayer := LayerSkillLanguage
	if !IsSkill(skillLayer) {
		t.Error("LayerSkillLanguage phải là Skill")
	}
	if DomainName(skillLayer) != "Skill" {
		t.Errorf("got %s, want Skill", DomainName(skillLayer))
	}
	if LayerName(skillLayer) != "Skill.Language" {
		t.Errorf("got %s, want Skill.Language", LayerName(skillLayer))
	}

	// AGENT_LEOAI → layer 0x14 = Agent.LeoAI
	agentLayer := LayerAgentLeoAI
	if !IsAgent(agentLayer) {
		t.Error("LayerAgentLeoAI phải là Agent")
	}
	if IsSkill(agentLayer) {
		t.Error("Agent không phải Skill")
	}

	// LIFE_BIRD → layer 0x03 = L3.Life
	lifeLayer := LayerL3Life
	if !IsPhysical(lifeLayer) {
		t.Error("L3.Life phải là Physical")
	}
	if IsAgent(lifeLayer) || IsSkill(lifeLayer) {
		t.Error("Life node không phải Agent hay Skill")
	}

	// Node đang học (ĐN)
	dnLayer := LayerObservation
	if !IsDN(dnLayer) { t.Error("Observation phải là ĐN") }
	if IsQR(dnLayer)  { t.Error("ĐN không phải QR") }

	// Node đã chứng minh (QR)
	qrLayer := LayerQRSigned
	if !IsQR(qrLayer) { t.Error("QR.Signed phải là QR") }
	if IsDN(qrLayer)  { t.Error("QR không phải ĐN") }
}

func TestLeoAI_O1_DomainCheck(t *testing.T) {
	// LeoAI kiểm tra 1 triệu addresses — phải xong trong < 10ms
	// Chứng minh: domain detection là O(1) bit mask, không phải lookup
	layers := []byte{
		LayerL3Life, LayerAgentAAM, LayerSkillSecurity,
		LayerQRSigned, LayerObservation, LayerRelCrossLang,
		LayerL0Primitives, LayerAgentWorker, LayerSkillActuator,
	}
	total := 0
	for i := 0; i < 1_000_000; i++ {
		layer := layers[i%len(layers)]
		_ = DomainOf(layer)
		_ = IsAgent(layer)
		_ = IsSkill(layer)
		total++
	}
	if total != 1_000_000 {
		t.Fail()
	}
	// Không cần time check — nếu chậm thì có vấn đề nghiêm trọng
}

// ─────────────────────────────────────────────────────────────────
// TEST COMPOSE EDGES — LOVE = L++O++V++E
// ─────────────────────────────────────────────────────────────────

func TestComposeEdges_LOVE(t *testing.T) {
	// Mô phỏng quá trình compose LOVE = L++O++V++E
	// compose(L, O) → LO
	// compose(LO, V) → LOV
	// compose(LOV, E) → LOVE

	// ISL addresses (giả lập)
	islL   := uint64(0x0100_0001_0000_0001) // L atom
	islO   := uint64(0x0100_0001_0000_0002) // O atom
	islV   := uint64(0x0100_0001_0000_0003) // V atom
	islE   := uint64(0x0100_0001_0000_0004) // E atom
	islLO  := uint64(0x0200_0002_0000_0001) // LO compose
	islLOV := uint64(0x0200_0002_0000_0002) // LOV compose
	islLOVE:= uint64(0x0200_0002_0000_0003) // LOVE compose

	// Step 1: compose(L, O) → LO
	edgesLO := ComposeEdges(islL, islO, islLO)
	if len(edgesLO) != 6 {
		t.Fatalf("compose(L,O): cần 6 edges, got %d", len(edgesLO))
	}
	// LO ──ComposeChild──► L
	// LO ──ComposeChild──► O
	checkEdge(t, edgesLO, islLO, islL, EdgeComposeChild, "LO→L ComposeChild")
	checkEdge(t, edgesLO, islLO, islO, EdgeComposeChild, "LO→O ComposeChild")
	// L ──ComposeParent──► LO
	// O ──ComposeParent──► LO
	checkEdge(t, edgesLO, islL, islLO, EdgeComposeParent, "L→LO ComposeParent")
	checkEdge(t, edgesLO, islO, islLO, EdgeComposeParent, "O→LO ComposeParent")
	// L ──ComposePeer──► O
	checkEdge(t, edgesLO, islL, islO, EdgeComposePeer, "L↔O ComposePeer")
	checkEdge(t, edgesLO, islO, islL, EdgeComposePeer, "O↔L ComposePeer")

	// Step 2: compose(LO, V) → LOV
	edgesLOV := ComposeEdges(islLO, islV, islLOV)
	if len(edgesLOV) != 6 {
		t.Fatalf("compose(LO,V): cần 6 edges, got %d", len(edgesLOV))
	}

	// Step 3: compose(LOV, E) → LOVE
	edgesLOVE := ComposeEdges(islLOV, islE, islLOVE)
	if len(edgesLOVE) != 6 {
		t.Fatalf("compose(LOV,E): cần 6 edges, got %d", len(edgesLOVE))
	}

	// Tổng cộng: 3 compose × 6 edges = 18 edges
	total := len(edgesLO) + len(edgesLOV) + len(edgesLOVE)
	if total != 18 {
		t.Errorf("LOVE cần 18 compose edges, got %d", total)
	}

	// Kiểm tra: từ LOVE có thể trace về L, O, V, E
	// LOVE ──ComposeChild──► LOV ──ComposeChild──► LO ──ComposeChild──► L
	// Walk ngược (giả lập):
	chain := traceComposeChain(edgesLOVE, edgesLOV, edgesLO, islLOVE)
	if len(chain) < 4 {
		t.Errorf("trace từ LOVE phải tìm được ≥4 atoms, got %d", len(chain))
	}
	t.Logf("LOVE ancestry chain: %d nodes traced", len(chain))
}

func checkEdge(t *testing.T, edges []ComposeEdgePair, from, to uint64, typ EdgeType, name string) {
	t.Helper()
	for _, e := range edges {
		if e.From == from && e.To == to && e.Type == typ {
			return
		}
	}
	t.Errorf("missing edge %s: from=0x%x to=0x%x type=%s",
		name, from, to, EdgeName(typ))
}

// traceComposeChain mô phỏng LeoAI walk ngược từ LOVE → L,O,V,E
func traceComposeChain(e3, e2, e1 []ComposeEdgePair, start uint64) []uint64 {
	// Build adjacency: ComposeChild edges
	adj := map[uint64][]uint64{}
	for _, edges := range [][]ComposeEdgePair{e1, e2, e3} {
		for _, e := range edges {
			if e.Type == EdgeComposeChild {
				adj[e.From] = append(adj[e.From], e.To)
			}
		}
	}
	// BFS walk
	visited := map[uint64]bool{start: true}
	queue := []uint64{start}
	result := []uint64{}
	for len(queue) > 0 {
		cur := queue[0]; queue = queue[1:]
		result = append(result, cur)
		for _, next := range adj[cur] {
			if !visited[next] {
				visited[next] = true
				queue = append(queue, next)
			}
		}
	}
	return result
}

// ─────────────────────────────────────────────────────────────────
// TEST CROSS-LANGUAGE LINKS — LOVE ≡ Yêu ≡ 愛
// ─────────────────────────────────────────────────────────────────

func TestTranslationGroup_LOVE(t *testing.T) {
	// LOVE (en) ≡ Yêu (vi) ≡ 愛 (zh)
	islLOVE  := uint64(0x6000_0001_0000_0001) // LOVE — Lang.Phrase
	islYeu   := uint64(0x6000_0001_0000_0002) // Yêu  — Lang.Phrase
	islAi    := uint64(0x6000_0001_0000_0003) // 愛   — Lang.Phrase

	group := TranslationGroup{
		Concept: "love",
		Members: []uint64{islLOVE, islYeu, islAi},
		Lang:    []string{"en", "vi", "zh"},
	}

	edges := group.TranslationEdges()
	if len(edges) != 3 {
		t.Fatalf("cần 3 translation edges (ring), got %d", len(edges))
	}

	// Ring: LOVE→Yêu, Yêu→愛, 愛→LOVE
	checkEdge(t, edges, islLOVE, islYeu,  EdgeTranslation, "LOVE→Yêu")
	checkEdge(t, edges, islYeu,  islAi,   EdgeTranslation, "Yêu→愛")
	checkEdge(t, edges, islAi,   islLOVE, EdgeTranslation, "愛→LOVE")
}

func TestPhonemeDecomposition_Yeu(t *testing.T) {
	// Yêu → Y + Ê + U (phoneme decomposition)
	islYeu := uint64(0x6000_0001_0000_0002) // Yêu
	islY   := uint64(0x6300_0001_0000_0001) // Y — Lang.Phoneme
	islE_  := uint64(0x6300_0001_0000_0002) // Ê — Lang.Phoneme
	islU   := uint64(0x6300_0001_0000_0003) // U — Lang.Phoneme

	// Edges: Yêu ──Phoneme──► Y, Ê, U
	phonemeEdges := []ComposeEdgePair{
		{islYeu, islY,  EdgePhoneme},
		{islYeu, islE_, EdgePhoneme},
		{islYeu, islU,  EdgePhoneme},
	}

	if len(phonemeEdges) != 3 {
		t.Fail()
	}
	for _, e := range phonemeEdges {
		if e.Type != EdgePhoneme {
			t.Errorf("phải là EdgePhoneme, got %s", EdgeName(e.Type))
		}
		if e.From != islYeu {
			t.Error("source phải là Yêu")
		}
	}
}

func TestSymbolLink_Heart(t *testing.T) {
	// Yêu ──SymbolOf──► ♥ ──SymbolOf──► heart ──Translation──► tim
	// Dùng ISL4From với layer taxonomy đúng
	islYeu   := ISL4From(LayerL3Life,    'L', 'l', 1).Uint64() // L3.Life
	islHeart := ISL4From(LayerSymbol,    'H', 's', 1).Uint64() // Lang.Symbol (0x62)
	islEn    := ISL4From(LayerTerm,      'H', 'e', 1).Uint64() // Lang.Term "heart"
	islVi    := ISL4From(LayerTerm,      'T', 'v', 1).Uint64() // Lang.Term "tim"

	symbolEdges := []ComposeEdgePair{
		{islYeu,   islHeart, EdgeSymbolOf},    // Yêu ≈ ♥
		{islHeart, islEn,    EdgeSymbolOf},    // ♥ ≈ heart
		{islEn,    islVi,    EdgeTranslation}, // heart ≡ tim
	}

	if len(symbolEdges) != 3 { t.Fail() }

	// Kiểm tra layer của ♥ = LayerSymbol (0x62 = Lang.Symbol)
	heartISL4 := ISL4From(LayerSymbol, 'H', 's', 1)
	heartLayer := byte(heartISL4.Layer())
	if heartLayer != LayerSymbol {
		t.Errorf("♥ layer 0x%02X phải là LayerSymbol 0x%02X", heartLayer, LayerSymbol)
	}
	if !IsLanguage(heartLayer) {
		t.Errorf("♥ layer 0x%02X phải là Language domain", heartLayer)
	}
	t.Logf("♥ layer=0x%02X domain=%s", heartLayer, DomainName(heartLayer))
	
	// Kiểm tra Yêu layer = L3.Life
	yeuLayer := byte(ISL4From(LayerL3Life, 'L', 'l', 1).Layer())
	if !IsPhysical(yeuLayer) {
		t.Errorf("Yêu layer 0x%02X phải là Physical domain", yeuLayer)
	}
}

// ─────────────────────────────────────────────────────────────────
// TEST EDGE TYPES — legacy compatibility
// ─────────────────────────────────────────────────────────────────

func TestEdgeName_AllTypes(t *testing.T) {
	types := []EdgeType{
		EdgePartOf, EdgeIsA, EdgeHasPart,
		EdgeComposeChild, EdgeComposeParent, EdgeComposePeer,
		EdgeEquivalent, EdgeSimilar, EdgeOpposite,
		EdgeTranslation, EdgePhonetic, EdgeScript, EdgeSymbolOf, EdgePhoneme,
		EdgeLegacyWorld, EdgeLegacyIsA, EdgeLegacyHasPart,
		EdgeLegacySimilar, EdgeLegacyContext,
	}
	for _, typ := range types {
		name := EdgeName(typ)
		if name == "Unknown" {
			t.Errorf("EdgeType 0x%02X không có tên", byte(typ))
		}
	}
}

func TestLegacyEdges_StillValid(t *testing.T) {
	// Edges cũ (0x08-0x0D) phải vẫn được nhận diện
	if EdgeName(EdgeLegacyWorld) == "Unknown"   { t.Error("0x08 WorldLink phải valid") }
	if EdgeName(EdgeLegacyIsA) == "Unknown"     { t.Error("0x09 IsA-legacy phải valid") }
	if EdgeName(EdgeLegacyHasPart) == "Unknown" { t.Error("0x0A HasPart-legacy phải valid") }
}
