// Quadtree — phân vùng không gian 2D để tìm skeleton nhanh
// Dùng bởi: FovealVision, MultiPersonTracker
// QT5: cùng vị trí → cùng nhóm
package gene

// Rect — vùng không gian
type Rect struct {
	X, Y, W, H float64
}

func (r Rect) Contains(x, y float64) bool {
	return x >= r.X && x <= r.X+r.W && y >= r.Y && y <= r.Y+r.H
}

func (r Rect) Intersects(o Rect) bool {
	return r.X < o.X+o.W && r.X+r.W > o.X &&
		r.Y < o.Y+o.H && r.Y+r.H > o.Y
}

// Point trong quadtree
type QPoint struct {
	X, Y float64
	Data interface{} // *SDFSkeleton hoặc bất kỳ
}

const qtMaxPoints = 4
const qtMaxDepth  = 8

type Quadtree struct {
	bounds   Rect
	points   []QPoint
	children [4]*Quadtree // NW NE SW SE
	divided  bool
	depth    int
}

func NewQuadtree(bounds Rect) *Quadtree {
	return &Quadtree{bounds: bounds}
}

func (q *Quadtree) Insert(p QPoint) bool {
	if !q.bounds.Contains(p.X, p.Y) {
		return false
	}
	if len(q.points) < qtMaxPoints || q.depth >= qtMaxDepth {
		q.points = append(q.points, p)
		return true
	}
	if !q.divided {
		q.subdivide()
	}
	for _, child := range q.children {
		if child.Insert(p) {
			return true
		}
	}
	return false
}

func (q *Quadtree) subdivide() {
	x, y, w, h := q.bounds.X, q.bounds.Y, q.bounds.W/2, q.bounds.H/2
	d := q.depth + 1
	q.children[0] = &Quadtree{bounds: Rect{x, y, w, h}, depth: d}         // NW
	q.children[1] = &Quadtree{bounds: Rect{x + w, y, w, h}, depth: d}     // NE
	q.children[2] = &Quadtree{bounds: Rect{x, y + h, w, h}, depth: d}     // SW
	q.children[3] = &Quadtree{bounds: Rect{x + w, y + h, w, h}, depth: d} // SE
	q.divided = true
}

// Query — lấy tất cả points trong vùng range
func (q *Quadtree) Query(r Rect) []QPoint {
	if !q.bounds.Intersects(r) {
		return nil
	}
	var found []QPoint
	for _, p := range q.points {
		if r.Contains(p.X, p.Y) {
			found = append(found, p)
		}
	}
	if q.divided {
		for _, child := range q.children {
			found = append(found, child.Query(r)...)
		}
	}
	return found
}

// Nearest — tìm point gần nhất với (x,y)
func (q *Quadtree) Nearest(x, y float64) *QPoint {
	all := q.Query(q.bounds)
	if len(all) == 0 {
		return nil
	}
	best := &all[0]
	bestD := dist2(x, y, best.X, best.Y)
	for i := 1; i < len(all); i++ {
		d := dist2(x, y, all[i].X, all[i].Y)
		if d < bestD {
			bestD = d
			best = &all[i]
		}
	}
	return best
}

// Clear — reset
func (q *Quadtree) Clear() {
	q.points = q.points[:0]
	q.children = [4]*Quadtree{}
	q.divided = false
}

func dist2(x1, y1, x2, y2 float64) float64 {
	dx, dy := x1-x2, y1-y2
	return dx*dx + dy*dy
}
