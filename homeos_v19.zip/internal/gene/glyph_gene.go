// internal/gene/glyph_gene.go
//
// GlyphGene — TYPE 2 Char Node
// =============================
// MASTER.md §1.4: "Olang mượn UTF-32, không đọc UTF-32"
// MASTER.md §1.5: "TYPE 2 — Char Node: Gene=GlyphGene{SDF}"
//
// Mỗi ký tự Unicode không lưu pixel, không lưu Bezier path.
// Nó được mã hóa thành:
//   GlyphSDF  — hình dạng ký tự trong [-0.5, 0.5]² (render mọi kích thước)
//   ConceptSDF — thực thể vật lý thật mà ký tự đại diện
//   ISLAddr    — địa chỉ trong SilkGraph
//
// Ví dụ:
//   '山' → GlyphSDF = 3 capsule đỉnh núi
//          ConceptSDF = ∫(fbm_terrain, 3_peaks) — ngọn núi THẬT
//
//   'A'  → GlyphSDF = ∪(⌀left, ⌀right, ⌀crossbar)
//          ConceptSDF = △(peak) — đỉnh, nguồn gốc Aleph = đầu bò

package gene

import (
	"fmt"
	"math"
)

// GlyphGene implement Gene interface cho một ký tự Unicode
// Đây là cầu nối giữa ngôn ngữ viết và thế giới SDF
type GlyphGene struct {
	Codepoint uint32
	Glyph     string  // UTF-8 display
	Name      string  // Unicode official name
	Script    string  // latin / cjk / math / ipa / ...

	// Hình dạng ký tự trong không gian [-0.5, 0.5]²
	// Render được ở mọi kích thước — không có aliasing
	GlyphSDF func(Vec3) float64

	// DNA = Olang notation — lưu vào SilkTree, đọc được không cần runtime
	// Ví dụ: "∪(⌀(-.28,-.38,.00,.44,T), ⌀(.00,.44,.28,-.38,T))"
	GlyphDNA string

	// Concept — thực thể vật lý thật mà ký tự đại diện
	// Khác GlyphSDF: ConceptSDF là thực tế vật lý, không phải chữ viết
	// '山' GlyphSDF = ký hiệu chữ viết CJK
	// '山' ConceptSDF = ngọn núi thật với FBM terrain
	ConceptSDF func(Vec3) float64
	ConceptDNA string // DNA của concept

	// Phonemes IPA — cầu nối âm thanh
	// 'A' → ["/eɪ/", "/æ/", "/ɑː/"]
	Phonemes []string

	// Fibonacci structure score [0..1]
	// Tính khi first access, cache lại
	fibScore float64
	fibCalc  bool

	// Animation state
	scale float64
	t     float64
}

// NewGlyphGene tạo GlyphGene với SDF function
func NewGlyphGene(cp uint32, glyph, name, script string,
	glyphSDF func(Vec3) float64, dna string) *GlyphGene {
	return &GlyphGene{
		Codepoint: cp,
		Glyph:     glyph,
		Name:      name,
		Script:    script,
		GlyphSDF:  glyphSDF,
		GlyphDNA:  dna,
		scale:     1.0,
	}
}

// ── Gene interface ────────────────────────────────────────────

func (g *GlyphGene) SDF(p Vec3) float64 {
	if g.GlyphSDF == nil {
		return math.MaxFloat64
	}
	// Scale p vào không gian ký tự [-0.5, 0.5]²
	scaled := Vec3{p.X / g.scale, p.Y / g.scale, p.Z}
	return g.GlyphSDF(scaled) * g.scale
}

func (g *GlyphGene) Normal(p Vec3) Vec3 {
	return SurfaceNormal(p, g.SDF, 0.001)
}

func (g *GlyphGene) Animate(t float64) {
	g.t = t
	// Glyphs không animate — nhưng có thể pulse nhẹ khi được nhắc đến
}

func (g *GlyphGene) DNA() string {
	return g.GlyphDNA
}

func (g *GlyphGene) SimpleSDF(p Vec3) float64 {
	// Bounding sphere đơn giản cho LOD
	return SDFSphere(p, Vec3{}, 0.35*g.scale)
}

// ── ConceptEval — thực thể vật lý thật ───────────────────────

// ConceptEval tính SDF của concept thật tại điểm p world-space
// Khác với SDF() chỉ cho hình dạng ký tự trong glyph-space
func (g *GlyphGene) ConceptEval(p Vec3) float64 {
	if g.ConceptSDF == nil {
		return math.MaxFloat64
	}
	return g.ConceptSDF(p)
}

// HasConcept trả về true nếu ký tự này có concept vật lý thật
func (g *GlyphGene) HasConcept() bool {
	return g.ConceptSDF != nil
}

// ── Fibonacci analysis ────────────────────────────────────────
// MASTER.md §1.3: "nhận diện = tìm ISLAddress có cấu trúc Fibonacci khớp"

const phi = 1.6180339887498948482

// FibScore tính điểm Fibonacci của GlyphSDF
// Cache lại sau lần đầu — expensive operation
func (g *GlyphGene) FibScore() float64 {
	if g.fibCalc {
		return g.fibScore
	}
	g.fibCalc = true
	if g.GlyphSDF == nil {
		g.fibScore = 0
		return 0
	}
	g.fibScore = computeFibScore(g.GlyphSDF)
	return g.fibScore
}

// computeFibScore — sample SDF theo golden angle, tìm cấu trúc φ
// Theo MASTER.md: detectSpiral = tích phân ∂sdf/∂θ theo θ ∈ [0, 2π]
func computeFibScore(sdf func(Vec3) float64) float64 {
	const steps = 64
	goldenAngle := 2 * math.Pi / (phi * phi) // 137.5°

	samples := make([]float64, steps)
	for i := 0; i < steps; i++ {
		theta := float64(i) * goldenAngle
		r := math.Sqrt(float64(i+1) / float64(steps)) * 0.4
		p := Vec3{r * math.Cos(theta), r * math.Sin(theta), 0}
		samples[i] = math.Abs(sdf(p))
	}

	// Tìm tỉ lệ φ giữa các cực trị liên tiếp
	hits := 0
	total := 0
	for i := 1; i < len(samples)-1; i++ {
		// Local extremum
		if samples[i] < samples[i-1] && samples[i] < samples[i+1] {
			if i+1 < len(samples) {
				total++
				if isFibRatio(samples[i+1], samples[i]) {
					hits++
				}
			}
		}
	}
	if total == 0 {
		return 0
	}
	return float64(hits) / float64(total)
}

func isFibRatio(a, b float64) bool {
	if b < 1e-10 {
		return false
	}
	r := a / b
	return math.Abs(r-phi) < 0.08 || math.Abs(r-1/phi) < 0.08
}

// ── String representation ─────────────────────────────────────

func (g *GlyphGene) String() string {
	concept := ""
	if g.HasConcept() {
		concept = fmt.Sprintf(" concept=%q", g.ConceptDNA)
	}
	return fmt.Sprintf("GlyphGene{U+%04X %s %q script=%s%s}",
		g.Codepoint, g.Glyph, g.Name, g.Script, concept)
}
