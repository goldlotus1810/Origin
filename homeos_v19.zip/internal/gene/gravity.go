// internal/gene/gravity.go
// Gravity — lực hấp dẫn giữa các thực thể
//
// Lực hấp dẫn KHÔNG thuộc về một thực thể đơn lẻ.
// Nó là Property trên ISL_edge(A → B):
//
//   F(t) = G × M_A × M_B / r(t)²
//   r(t) = |A.Orbit.Eval(t) - B.pos|  ← Spline biến thiên
//
// Hệ quả:
//   GravitySurface(Earth) = G × M_earth / R_earth² = 9.807 m/s²
//     → tính ra được, không hardcode
//   GravityBetween(Sun, Earth, t) → giữ quỹ đạo
//   GravityBetween(Earth, Moon, t) → thủy triều
//   GravityBetween(Earth, Human) → 9.807 m/s² × mass_human

package gene

import "math"

// Hằng số hấp dẫn Newton
// ISL = ISL_ConstG — bất biến tuyệt đối
const G = 6.674e-11 // N·m²/kg²

// Massive — interface cho thực thể có khối lượng
// SunGene, EarthGene, MoonGene, CreatureGene đều implement
type Massive interface {
	MassKg() float64     // khối lượng (kg)
	RadiusM() float64    // bán kính thật (m) — để tính surface gravity
	WorldPos() Vec3      // vị trí trong world space
	MassISL() ISLAddr    // ISL address của node khối lượng
}

// ─── GravityEdge — Property trên ISL edge ────────────────────────
// "Lực hấp dẫn giữa A và B" = 1 cạnh trong SilkGraph
// Cạnh này mang ScalarSpline F(t) biến thiên theo quỹ đạo

type GravityEdge struct {
	From    ISLAddr       // ISL của thực thể A
	To      ISLAddr       // ISL của thực thể B
	MassA   float64       // kg
	MassB   float64       // kg
	DistFn  func() float64 // hàm tính r(t) hiện tại — từ Orbit Spline
}

// Force trả về lực hấp dẫn hiện tại (N)
func (e *GravityEdge) Force() float64 {
	r := e.DistFn()
	if r < 1e-9 { return 0 }
	return G * e.MassA * e.MassB / (r * r)
}

// Accel trả về gia tốc của thực thể From về phía To (m/s²)
func (e *GravityEdge) Accel() float64 {
	r := e.DistFn()
	if r < 1e-9 { return 0 }
	return G * e.MassB / (r * r)
}

// ─── GravitySurface — gia tốc tại bề mặt ────────────────────────
// Tính từ M và R — không hardcode

// SurfaceGravity tính g tại bề mặt (m/s²)
// g = G × M / R²
func SurfaceGravity(massKg, radiusM float64) float64 {
	return G * massKg / (radiusM * radiusM)
}

// ─── Thực thể cụ thể ─────────────────────────────────────────────

// SunMass — khối lượng mặt trời
const SunMassKg   = 1.989e30
const SunRadiusM  = 6.957e8

// EarthMass — khối lượng trái đất
const EarthMassKg  = 5.972e24
const EarthRadiusM = 6.371e6

// MoonMass — khối lượng mặt trăng
const MoonMassKg   = 7.342e22
const MoonRadiusM  = 1.737e6

// HumanMassKg — khối lượng người trung bình
const HumanMassKg = 70.0

// ─── Implement Massive cho SunGene ───────────────────────────────

func (s *SunGene) MassKg() float64   { return SunMassKg }
func (s *SunGene) RadiusM() float64  { return SunRadiusM }
func (s *SunGene) WorldPos() Vec3    { return s.pos }
func (s *SunGene) MassISL() ISLAddr  { return ISL_SunMass }

// SurfaceGrav trả về g bề mặt mặt trời (m/s²) — tính ra không hardcode
func (s *SunGene) SurfaceGrav() float64 {
	return SurfaceGravity(SunMassKg, SunRadiusM)
}

// ─── Implement Massive cho EarthGene ─────────────────────────────

func (e *EarthGene) MassKg() float64  { return EarthMassKg }
func (e *EarthGene) RadiusM() float64 { return EarthRadiusM }
func (e *EarthGene) WorldPos() Vec3   { return e.pos }
func (e *EarthGene) MassISL() ISLAddr { return ISL_EarthMass }

// SurfaceGrav trả về g bề mặt trái đất (m/s²) — tính từ M và R
// = 9.8196... m/s² ✓ (gần đúng 9.807)
func (e *EarthGene) SurfaceGrav() float64 {
	return SurfaceGravity(EarthMassKg, EarthRadiusM)
}

// GravityTo tạo GravityEdge từ Earth đến một thực thể khác
// distFn = hàm trả về khoảng cách hiện tại (AU hoặc m)
func (e *EarthGene) GravityTo(other Massive, distFn func() float64) *GravityEdge {
	return &GravityEdge{
		From:   e.Addr,
		To:     other.MassISL(),
		MassA:  EarthMassKg,
		MassB:  other.MassKg(),
		DistFn: distFn,
	}
}

// ─── GravitySystem — tập hợp tất cả cạnh hấp dẫn ────────────────
// Đây là "mạng lực" trong SilkGraph — không phải node, là cạnh

type GravitySystem struct {
	Edges []*GravityEdge
}

func NewGravitySystem() *GravitySystem {
	return &GravitySystem{}
}

func (gs *GravitySystem) Add(e *GravityEdge) {
	gs.Edges = append(gs.Edges, e)
}

// TotalForceOn trả về tổng lực hấp dẫn tác dụng lên thực thể có ISL = target (N)
func (gs *GravitySystem) TotalForceOn(target ISLAddr) float64 {
	total := 0.0
	for _, e := range gs.Edges {
		if e.From == target {
			total += e.Force()
		}
	}
	return total
}

// WeightOf trả về trọng lượng (N) của vật có massKg tại bề mặt Earth
func WeightOf(massKg float64) float64 {
	g := SurfaceGravity(EarthMassKg, EarthRadiusM)
	return massKg * g
}

// EscapeVelocity tính vận tốc vũ trụ cấp 1 (m/s)
// v = sqrt(2GM/R)
func EscapeVelocity(massKg, radiusM float64) float64 {
	return math.Sqrt(2 * G * massKg / radiusM)
}

// OrbitalVelocity tính vận tốc quỹ đạo tròn tại khoảng cách r (m/s)
// v = sqrt(GM/r)
func OrbitalVelocity(centralMassKg, r float64) float64 {
	return math.Sqrt(G * centralMassKg / r)
}
