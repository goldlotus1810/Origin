package gene

import (
	"testing"
)

func TestWorkerBrain(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  WORKER BRAIN — Chief training, Worker tự quyết             ║")
	t.Log("╠══════════════════════════════════════════════════════════════╣")
	t.Log("║  Chief training Worker:                                      ║")
	t.Log("║    - Phương trình cho từng action                            ║")
	t.Log("║    - SuspicionThreshold (độ thông minh)                     ║")
	t.Log("║    - RetentionPolicy (lưu/bỏ)                               ║")
	t.Log("║  Worker sau training:                                        ║")
	t.Log("║    Bình thường → im lặng                                    ║")
	t.Log("║    Nghi ngờ    → tự quyết lưu/bỏ + BÁO Chief               ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── Chief training 2 Workers khác nhau ───────────────────────
	// Worker nhà bếp: ngưỡng thấp (nhạy) — mọi thứ lạ đều báo
	// Worker phòng ngủ: ngưỡng cao (bình tĩnh) — chỉ báo bất thường rõ

	kitchenWorker  := NewWorkerBrain("cam_kitchen", 0.05, DefaultPolicy)
	bedroomWorker  := NewWorkerBrain("cam_bedroom", 0.15, RetentionPolicy{
		MinAnomalyToSave: 0.15,
		MaxSavePerAction: 3,
		ConfidenceToKeep: 0.70,
	})

	t.Log("[ CHIEF TRAINING — 2 workers khác nhau ]")
	t.Logf("  cam_kitchen:  suspicionThreshold=0.05  (nhạy — an toàn quan trọng)")
	t.Logf("  cam_bedroom:  suspicionThreshold=0.15  (bình tĩnh — ít báo hơn)")
	t.Log()

	// ── Training phase: cho Worker xem ví dụ ─────────────────────
	// (Chief feed các clip mẫu để Worker học equations)
	t.Log("[ TRAINING PHASE — Chief cho Worker xem ví dụ ]")
	cookingClip := makeLibClip(ActionCooking, 3.5, 0.12, 0)
	typingClip  := makeLibClip(ActionTyping,  4.0, 0.03, 0)
	sleepClip   := makeLibClip(ActionSleeping,0.2, 0.01, 0)

	for _, w := range []*WorkerBrain{kitchenWorker} {
		w.ObserveMotion(cookingClip, ActionCooking, "human_adult_female")
		w.ObserveMotion(typingClip,  ActionTyping,  "human_adult_male")
	}
	bedroomWorker.ObserveMotion(sleepClip, ActionSleeping, "human_adult_female")

	t.Logf("  kitchen: learned equations=%d", len(kitchenWorker.Eqs.MotionEqs))
	t.Logf("  bedroom: learned equations=%d", len(bedroomWorker.Eqs.MotionEqs))
	t.Log()

	// ── Runtime phase ─────────────────────────────────────────────
	t.Log("[ RUNTIME — Worker tự xử lý, chỉ báo khi nghi ngờ ]")
	t.Log()

	type obs struct {
		worker  *WorkerBrain
		wname   string
		label   string
		action  ActionVerb
		freq    float64
		amp     float64
		leg     float64
	}

	observations := []obs{
		// Bình thường → im lặng
		{kitchenWorker,  "kitchen", "nấu ăn bình thường (lần 2)",  ActionCooking, 3.5, 0.12, 0},
		{kitchenWorker,  "kitchen", "nấu ăn bình thường (lần 3)",  ActionCooking, 3.4, 0.12, 0},
		{bedroomWorker,  "bedroom", "ngủ bình thường",              ActionSleeping,0.2, 0.01, 0},

		// Hơi lạ — kitchen nhạy nên báo, bedroom bình tĩnh nên im
		{kitchenWorker,  "kitchen", "nấu kiểu khác (khuấy nhanh)", ActionCooking, 2.0, 0.18, 0},
		{bedroomWorker,  "bedroom", "ngủ hơi trằn trọc",           ActionSleeping,0.8, 0.04, 0},

		// Rõ ràng lạ — cả 2 đều báo
		{kitchenWorker,  "kitchen", "đứng im không nấu???",        ActionCooking, 0.1, 0.01, 0},
		{bedroomWorker,  "bedroom", "đứng dậy đột ngột lúc 3am",  ActionSleeping,2.0, 0.15, 0},

		// Action hoàn toàn mới
		{kitchenWorker,  "kitchen", "nhảy múa trong bếp?!",        ActionDancing, 1.0, 0.20, 0},
	}

	chiefReports := []*SuspicionReport{}

	for _, o := range observations {
		clip := makeLibClip(o.action, o.freq, o.amp, o.leg)
		report := o.worker.ObserveMotion(clip, o.action, "human")

		if report == nil {
			t.Logf("  [%s] %-35s → ✓ im lặng", o.wname, o.label)
		} else {
			chiefReports = append(chiefReports, report)
			saveStr := ""
			if report.Saved { saveStr = " [LƯU EQ mới: " + report.EqID + "]" }
			t.Logf("  [%s] %-35s → 🚨 BÁO  score=%.3f%s",
				o.wname, o.label, report.AnomalyScore, saveStr)
			t.Logf("         Reason: %s", report.Reason)
		}
	}

	t.Log()
	t.Log("[ CHIEF nhận được báo cáo ]")
	t.Logf("  Tổng báo cáo lên Chief: %d/%d observations", len(chiefReports), len(observations))
	for i, r := range chiefReports {
		saved := "không lưu"
		if r.Saved { saved = "đã lưu " + r.EqID }
		t.Logf("  [%d] %s  action=%s  anomaly=%.3f  → %s",
			i+1, r.Source, r.Action, r.AnomalyScore, saved)
	}

	t.Log()
	t.Log("[ ĐỘ THÔNG MINH — sau training + runtime ]")
	t.Log("  " + kitchenWorker.Intelligence())
	t.Log("  " + bedroomWorker.Intelligence())

	t.Log()
	t.Log("[ KEY INSIGHT ]")
	t.Log("  Worker KHÔNG hỏi Chief từng mẫu")
	t.Log("  Worker TỰ QUYẾT lưu/bỏ equation")
	t.Log("  Worker CHỈ BÁO Chief khi nghi ngờ")
	t.Log("  Chief set threshold → 'độ thông minh' khác nhau mỗi phòng")
	t.Log("  SeenCount↑ → threshold↓ → Worker nhạy hơn theo thời gian")

	// Assertions
	totalSilent := kitchenWorker.Stats.Silent + bedroomWorker.Stats.Silent
	if totalSilent == 0 {
		t.Error("✗ Worker không bao giờ im lặng — sai")
	}
	if len(chiefReports) == 0 {
		t.Error("✗ Không có báo cáo nào lên Chief — sai")
	}
	if len(chiefReports) >= len(observations) {
		t.Error("✗ Báo tất cả observations — threshold không hoạt động")
	}
	t.Logf("\n  ✓ im lặng=%d  báo Chief=%d  (%.0f%% filtered)",
		totalSilent, len(chiefReports),
		100*float64(totalSilent)/float64(totalSilent+len(chiefReports)))
}
