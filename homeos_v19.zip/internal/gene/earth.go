// internal/gene/earth.go
// EarthGene — Trái Đất hoàn chỉnh theo kiến trúc ISL+SDF+Spline
//
//   ISL_Earth      = định danh (primary key)
//   SDF()          = SDFSphere (hình cầu)
//   Orbit          = Spline Vec3   — quỹ đạo quanh mặt trời (365 ngày)
//   Rotate         = ScalarSpline  — góc tự quay (24h)
//   SurfaceTemp    = ScalarSpline  — nhiệt độ bề mặt trung bình (K) theo mùa
//   AtmosPressure  = ScalarConst   — 101325 Pa
//   Humidity       = ScalarSpline  — độ ẩm trung bình theo mùa [0..1]
//   Gravity        = ScalarConst   — 9.807 m/s²
//
// Tính nhiệt độ bề mặt tại (lat, lon, t):
//   f(ISL_Sun.Luminosity, ISL_Earth.SurfaceTemp, lat, season)

package gene

import "math"

// Climate — vùng khí hậu, ảnh hưởng đến Spline nhiệt độ
type Climate byte

const (
	ClimateTropical    Climate = 0x01 // nhiệt đới   — nóng quanh năm
	ClimateSubtropical Climate = 0x02 // cận nhiệt đới
	ClimateTemperate   Climate = 0x03 // ôn đới       — 4 mùa rõ rệt
	ClimateBoreal      Climate = 0x04 // hàn đới
	ClimatePolar       Climate = 0x05 // cực          — lạnh quanh năm
)

// EarthGene = Trái Đất với đầy đủ thuộc tính vật lý
type EarthGene struct {
	Addr   ISLAddr
	Radius float64 // world units
	pos    Vec3    // vị trí trong hệ mặt trời sau Animate

	// Quỹ đạo quanh mặt trời (t ∈ [0,1] = 1 năm)
	Orbit *Spline

	// Góc nghiêng trục (~23.5°) — ảnh hưởng mùa
	AxialTilt float64 // radians

	// Thuộc tính vật lý — ScalarSpline
	SurfaceTemp   *ScalarSpline // ISL_EarthTemp   — K, biến thiên theo mùa
	AtmosPressure *ScalarSpline // ISL_EarthAtmos  — Pa (hằng số ~101325)
	Humidity      *ScalarSpline // ISL_EarthHumid  — [0..1], theo mùa
	Gravity       *ScalarSpline // ISL_EarthGravity — 9.807 m/s² (hằng số)
	Rotate        *ScalarSpline // ISL_EarthRotate  — góc tự quay [0,2π] theo giờ
}

// NewEarthGene tạo Trái Đất với climate mặc định = ôn đới
func NewEarthGene() *EarthGene {
	return newEarthWithClimate(ClimateTemperate)
}

// NewEarthGeneAt tạo Trái Đất tại vùng khí hậu cụ thể
func NewEarthGeneAt(c Climate) *EarthGene {
	return newEarthWithClimate(c)
}

func newEarthWithClimate(c Climate) *EarthGene {
	e := &EarthGene{
		Addr:      ISL_Earth,
		Radius:    6.0,
		AxialTilt: 23.5 * math.Pi / 180.0,
	}

	// Quỹ đạo quanh mặt trời — elipse nhẹ (eccentricity 0.017)
	// t=0.0 = tháng 1 (perihelion, gần mặt trời nhất)
	// t=0.5 = tháng 7 (aphelion, xa nhất)
	e.Orbit = &Spline{Keys: []Keyframe{
		{T: 0.00, Vec3: Vec3{147.1, 0, 0}},  // tháng 1 — gần nhất (AU scale)
		{T: 0.25, Vec3: Vec3{0, 0, 149.6}},  // tháng 4
		{T: 0.50, Vec3: Vec3{-152.1, 0, 0}}, // tháng 7 — xa nhất
		{T: 0.75, Vec3: Vec3{0, 0, -149.6}}, // tháng 10
	}}

	// Tự quay: 1 vòng = 24h → [0,2π]
	e.Rotate = &ScalarSpline{
		Keys: []ScalarKey{
			{T: 0.0, V: 0},
			{T: 1.0, V: 2 * math.Pi},
		},
		Unit: "rad",
	}

	// Áp suất khí quyển — hằng số
	e.AtmosPressure = ScalarConst(101325, "Pa")

	// Trọng lực — hằng số
	e.Gravity = ScalarConst(9.807, "m/s²")

	// Nhiệt độ + độ ẩm theo khí hậu
	e.SurfaceTemp, e.Humidity = climateSplines(c)

	e.pos = e.Orbit.Eval(0)
	return e
}

// climateSplines trả về SurfaceTemp và Humidity theo vùng khí hậu
// t ∈ [0,1] = 1 năm (tháng 1 → tháng 12)
func climateSplines(c Climate) (*ScalarSpline, *ScalarSpline) {
	switch c {
	case ClimateTropical:
		// Nhiệt đới: nóng quanh năm, ~300K (27°C), ít biến động
		// Mùa mưa (6-9) → độ ẩm cao
		return NewScalarSpline("K",
				0.00, 300.0, // tháng 1
				0.25, 303.0, // tháng 4
				0.50, 301.0, // tháng 7
				0.75, 299.0, // tháng 10
				1.00, 300.0,
			), NewScalarSpline("",
				0.00, 0.65,
				0.42, 0.70,
				0.58, 0.90, // mùa mưa
				0.83, 0.75,
				1.00, 0.65,
			)

	case ClimateSubtropical:
		// Cận nhiệt đới: hè nóng, đông mát
		return NewScalarSpline("K",
				0.00, 285.0,
				0.25, 295.0,
				0.50, 308.0,
				0.75, 298.0,
				1.00, 285.0,
			), NewScalarSpline("",
				0.00, 0.55,
				0.25, 0.45,
				0.50, 0.35,
				0.75, 0.50,
				1.00, 0.55,
			)

	case ClimateTemperate:
		// Ôn đới: 4 mùa — đông ~275K(2°C), hè ~295K(22°C)
		return NewScalarSpline("K",
				0.00, 275.0, // tháng 1 — đông
				0.25, 283.0, // tháng 4 — xuân
				0.50, 295.0, // tháng 7 — hè
				0.75, 286.0, // tháng 10 — thu
				1.00, 275.0,
			), NewScalarSpline("",
				0.00, 0.70,
				0.25, 0.65,
				0.50, 0.60,
				0.75, 0.72,
				1.00, 0.70,
			)

	case ClimateBoreal:
		// Hàn đới: đông dài lạnh, hè ngắn mát
		return NewScalarSpline("K",
				0.00, 258.0, // -15°C
				0.25, 270.0,
				0.50, 285.0, // 12°C
				0.75, 268.0,
				1.00, 258.0,
			), NewScalarSpline("",
				0.00, 0.75,
				0.50, 0.65,
				1.00, 0.75,
			)

	default: // ClimatePolar
		// Cực: lạnh quanh năm
		return NewScalarSpline("K",
				0.00, 243.0, // -30°C
				0.50, 263.0, // -10°C mùa hè
				1.00, 243.0,
			), NewScalarSpline("",
				0.00, 0.80,
				0.50, 0.70,
				1.00, 0.80,
			)
	}
}

// ─── Gene interface ───────────────────────────────────────────────

func (e *EarthGene) SDF(p Vec3) float64 {
	return SDFSphere(p, e.pos, e.Radius)
}

func (e *EarthGene) Normal(p Vec3) Vec3 {
	return SurfaceNormal(p, e.SDF, e.Radius*0.001)
}

// Animate cập nhật vị trí theo t ∈ [0,1] = 1 năm
func (e *EarthGene) Animate(t float64) {
	e.pos = e.Orbit.Eval(t)
}

func (e *EarthGene) SimpleSDF(p Vec3) float64 {
	return SDFSphere(p, e.pos, e.Radius)
}

func (e *EarthGene) DNA() string {
	return "🌍●~ISL_Earth~ISL_EarthOrbit~ISL_EarthTemp~ISL_EarthAtmos~ISL_EarthHumid"
}

// ─── Truy vấn vật lý ─────────────────────────────────────────────

// TempAt trả về nhiệt độ bề mặt tại thời điểm t ∈ [0,1] (năm)
// và giờ trong ngày h ∈ [0,24] — ban ngày ấm hơn ~3K
func (e *EarthGene) TempAt(yearT, hourOfDay float64) float64 {
	base := e.SurfaceTemp.Eval(yearT)
	// Ban ngày ấm hơn ban đêm ~6K, peak lúc 14h
	diurnal := 3.0 * math.Sin((hourOfDay-8)/16*math.Pi)
	return base + diurnal
}

// TempCelsius chuyển K → °C
func (e *EarthGene) TempCelsius(yearT, hourOfDay float64) float64 {
	return e.TempAt(yearT, hourOfDay) - 273.15
}

// SunsetTemp trả về nhiệt độ lúc hoàng hôn (~18h) tại yearT
// = kết quả của Sun.Luminosity × Earth.SurfaceTemp + diurnal
func (e *EarthGene) SunsetTemp(yearT float64, sun *SunGene) float64 {
	base := e.TempAt(yearT, 18.0)
	// Ảnh hưởng của cường độ mặt trời — lúc hoàng hôn đã giảm
	sunFactor := sun.Luminosity.Eval(18.0 / 24.0) // ~0.3
	// Bức xạ mặt trời góp thêm tối đa ~2K lúc hoàng hôn
	return base + sunFactor*2.0
}

// HumidityAt trả về độ ẩm tại t ∈ [0,1]
func (e *EarthGene) HumidityAt(yearT float64) float64 {
	return e.Humidity.Eval(yearT)
}

// Season trả về mùa hiện tại (0=đông, 1=xuân, 2=hè, 3=thu)
func (e *EarthGene) Season(yearT float64) int {
	t := math.Mod(yearT, 1.0)
	switch {
	case t < 0.25:
		return 0 // đông
	case t < 0.50:
		return 1 // xuân
	case t < 0.75:
		return 2 // hè
	default:
		return 3 // thu
	}
}

var SeasonName = [4]string{"Đông", "Xuân", "Hè", "Thu"}
