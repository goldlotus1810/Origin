// internal/gene/node_registry.go
// NodeRegistry — ánh xạ name → ISLAddr
//
// Mục tiêu: mọi node trong homeos.olang đều có ISLAddr xác định.
// Sau này gọi node bằng địa chỉ, không xung đột, không tra text.
//
// Nguyên tắc:
//   L0 = Primitives (SDF ops)     → LayerOp   (0x4F)
//   L2 = Nature                   → LayerWorld (0x57)
//   L3 = Life                     → LayerWorld (0x57)
//   L4 = Objects                  → LayerWorld (0x57)
//   L5 = Programming              → LayerKnow  (0x4B)
//   L6 = Perception               → LayerSensor(0x53)
//   L7 = Programs/Skills/Agents   → LayerAgent (0x41)
//
// Group phân theo domain trong mỗi layer.

package gene

import "sync"

// NodeEntry = 1 entry trong registry
type NodeEntry struct {
	Name  string  // "SUN" / "WATER" / "SKILL_VISION"...
	Addr  ISLAddr // địa chỉ xác định, bất biến
	Layer uint8   // layer trong homeos.olang (0-8)
	Desc  string  // mô tả ngắn
}

// NodeRegistry — map từ name → ISLAddr
// Thread-safe, append-only sau init
type NodeRegistry struct {
	mu      sync.RWMutex
	byName  map[string]*NodeEntry
	byAddr  map[ISLAddr]*NodeEntry
}

var globalRegistry = &NodeRegistry{
	byName: make(map[string]*NodeEntry),
	byAddr: make(map[ISLAddr]*NodeEntry),
}

// Register thêm 1 node vào registry
func Register(e *NodeEntry) {
	globalRegistry.mu.Lock()
	defer globalRegistry.mu.Unlock()
	globalRegistry.byName[e.Name] = e
	globalRegistry.byAddr[e.Addr] = e
}

// Lookup tra ISLAddr từ name
func Lookup(name string) (ISLAddr, bool) {
	globalRegistry.mu.RLock()
	defer globalRegistry.mu.RUnlock()
	if e, ok := globalRegistry.byName[name]; ok {
		return e.Addr, true
	}
	return 0, false
}

// LookupName tra name từ ISLAddr
func LookupName(addr ISLAddr) (string, bool) {
	globalRegistry.mu.RLock()
	defer globalRegistry.mu.RUnlock()
	if e, ok := globalRegistry.byAddr[addr]; ok {
		return e.Name, true
	}
	return "", false
}

// MustLookup tra ISLAddr — panic nếu không tìm thấy (dùng trong init)
func MustLookup(name string) ISLAddr {
	addr, ok := Lookup(name)
	if !ok {
		panic("NodeRegistry: unknown node: " + name)
	}
	return addr
}

// All trả về tất cả entries
func AllEntries() []*NodeEntry {
	globalRegistry.mu.RLock()
	defer globalRegistry.mu.RUnlock()
	out := make([]*NodeEntry, 0, len(globalRegistry.byName))
	for _, e := range globalRegistry.byName {
		out = append(out, e)
	}
	return out
}

// ─── Group constants cho từng layer ──────────────────────────────
// Dùng để tạo ISLAddr không xung đột

// L2 Nature groups
const (
	GrpNatureWater  byte = 0x01
	GrpNatureFire   byte = 0x02
	GrpNatureEarth  byte = 0x03
	GrpNatureWind   byte = 0x04
	GrpNatureLight  byte = 0x05
	GrpNatureSound  byte = 0x06
	GrpNatureSpace  byte = 0x07
	GrpNatureTime   byte = 0x08
)

// L3 Life groups
const (
	GrpLifeHuman    byte = 0x01
	GrpLifeAnimal   byte = 0x02
	GrpLifePlant    byte = 0x03
	GrpLifeCell     byte = 0x04
	GrpLifeEco      byte = 0x05
)

// L4 Objects groups
const (
	GrpObjHome      byte = 0x01
	GrpObjTool      byte = 0x02
	GrpObjVehicle   byte = 0x03
	GrpObjDevice    byte = 0x04
	GrpObjFood      byte = 0x05
)

// L5 Know/Programming groups
const (
	GrpKnowMath     byte = 0x01
	GrpKnowPhysics  byte = 0x02
	GrpKnowBiology  byte = 0x03
	GrpKnowHistory  byte = 0x04
	GrpKnowLang     byte = 0x05
	GrpKnowCS       byte = 0x06
	GrpKnowPhilo    byte = 0x07
)

// L6 Perception/Sensor groups
const (
	GrpSenseVision  byte = 0x01
	GrpSenseAudio   byte = 0x02
	GrpSenseTouch   byte = 0x03
	GrpSenseDepth   byte = 0x04
)

// L7 Agent/Skill groups
const (
	GrpAgentAAM     byte = 0x01
	GrpAgentLeoAI   byte = 0x02
	GrpAgentChief   byte = 0x03
	GrpAgentWorker  byte = 0x04
	GrpSkillMemory  byte = 0x10
	GrpSkillDecide  byte = 0x11
	GrpSkillLearn   byte = 0x12
	GrpSkillActuate byte = 0x13
	GrpSkillSense   byte = 0x14
	GrpSkillSec     byte = 0x15
)

// ─── init: đăng ký tất cả nodes đã biết ──────────────────────────

func init() {
	registerL0()
	registerL2()
	registerL3()
	registerL4()
	registerL7()
}

// L0 — SDF Primitives (đã có trong isl.go, register thêm vào registry)
func registerL0() {
	entries := []*NodeEntry{
		{Name: "OP_SPHERE",  Addr: ISL_OpSphere,  Layer: 0, Desc: "● SDFSphere"},
		{Name: "OP_CAPSULE", Addr: ISL_OpCapsule, Layer: 0, Desc: "⌀ SDFCapsule"},
		{Name: "OP_BOX",     Addr: ISL_OpBox,     Layer: 0, Desc: "□ SDFBox"},
		{Name: "OP_UNION",   Addr: ISL_OpUnion,   Layer: 0, Desc: "∪ SmoothUnion"},
		{Name: "OP_SUB",     Addr: ISL_OpSub,     Layer: 0, Desc: "∖ SmoothSub"},
		{Name: "OP_LIGHT",   Addr: ISL_OpLight,   Layer: 0, Desc: "☀ LightNode"},
		{Name: "CONST_G",    Addr: ISL_ConstG,    Layer: 0, Desc: "G=6.674e-11"},
	}
	for _, e := range entries {
		Register(e)
	}
}

// L2 — Nature
func registerL2() {
	entries := []*NodeEntry{
		{Name: "SUN",   Addr: ISL_Sun,   Layer: 2, Desc: "mặt trời ☀"},
		{Name: "EARTH", Addr: ISL_Earth, Layer: 2, Desc: "trái đất 🌍"},
		{Name: "MOON",  Addr: ISL_Moon,  Layer: 2, Desc: "mặt trăng 🌙"},
		{Name: "WATER", Addr: ISL_Water, Layer: 2, Desc: "nước 💧"},
		{Name: "FIRE",  Addr: ISL_Fire,  Layer: 2, Desc: "lửa 🔥"},
		{Name: "TREE",  Addr: ISL_Tree,  Layer: 2, Desc: "cây 🌳"},
		// Thuộc tính vật lý mặt trời
		{Name: "SUN_TEMP",  Addr: ISL_SunTemp,  Layer: 2, Desc: "nhiệt độ Sun 5778K"},
		{Name: "SUN_WAVE",  Addr: ISL_SunWave,  Layer: 2, Desc: "bước sóng Sun nm"},
		{Name: "SUN_LUMIN", Addr: ISL_SunLumin, Layer: 2, Desc: "cường độ Sun [0,1]"},
		{Name: "SUN_ORBIT", Addr: ISL_SunOrbit, Layer: 2, Desc: "quỹ đạo Sun"},
		{Name: "SUN_MAG",   Addr: ISL_SunMag,   Layer: 2, Desc: "từ trường Sun 11yr"},
		{Name: "SUN_MASS",  Addr: ISL_SunMass,  Layer: 2, Desc: "khối lượng Sun kg"},
		// Thuộc tính vật lý trái đất
		{Name: "EARTH_TEMP",    Addr: ISL_EarthTemp,    Layer: 2, Desc: "nhiệt độ Earth K"},
		{Name: "EARTH_ATMOS",   Addr: ISL_EarthAtmos,   Layer: 2, Desc: "áp suất Earth Pa"},
		{Name: "EARTH_GRAVITY", Addr: ISL_EarthGravity, Layer: 2, Desc: "trọng lực Earth"},
		{Name: "EARTH_ORBIT",   Addr: ISL_EarthOrbit,   Layer: 2, Desc: "quỹ đạo Earth"},
		{Name: "EARTH_HUMID",   Addr: ISL_EarthHumid,   Layer: 2, Desc: "độ ẩm Earth"},
		{Name: "EARTH_MASS",    Addr: ISL_EarthMass,    Layer: 2, Desc: "khối lượng Earth kg"},
		{Name: "MOON_MASS",     Addr: ISL_MoonMass,     Layer: 2, Desc: "khối lượng Moon kg"},
	}
	for _, e := range entries {
		Register(e)
	}
}

// L3 — Life / Creatures
func registerL3() {
	entries := []*NodeEntry{
		{
			Name:  "HUMAN",
			Addr:  MakeISL(LayerWorld, GroupCreature, byte(SpeciesHuman), 0x01, 0),
			Layer: 3, Desc: "người 👤",
		},
		{
			Name:  "DOG",
			Addr:  MakeISL(LayerWorld, GroupCreature, byte(SpeciesDog), 0x01, 0),
			Layer: 3, Desc: "chó 🐕",
		},
		{
			Name:  "BIRD",
			Addr:  MakeISL(LayerWorld, GroupCreature, byte(SpeciesBird), 0x01, 0),
			Layer: 3, Desc: "chim 🐦",
		},
		// Sinh lý dùng LayerSensor (0x53) — tách khỏi LayerPhysics celestial
		{
			Name:  "HUMAN_HR",
			Addr:  MakeISL(LayerSensor, GrpSenseTouch, byte(SpeciesHuman), 0x01, 0),
			Layer: 3, Desc: "nhịp tim người bpm",
		},
		{
			Name:  "HUMAN_TEMP",
			Addr:  MakeISL(LayerSensor, GrpSenseTouch, byte(SpeciesHuman), 0x02, 0),
			Layer: 3, Desc: "thân nhiệt người 310K",
		},
		{
			Name:  "HUMAN_BREATH",
			Addr:  MakeISL(LayerSensor, GrpSenseTouch, byte(SpeciesHuman), 0x03, 0),
			Layer: 3, Desc: "nhịp thở người /phút",
		},
	}
	for _, e := range entries {
		Register(e)
	}
}

// L4 — Objects
func registerL4() {
	// Objects dùng LayerKnow (0x4B) để tách khỏi LayerWorld L2/L3
	// Vì HomeOS objects = "vật thể nhân tạo trong nhà" — khác với "thực thể tự nhiên"
	entries := []*NodeEntry{
		{
			Name:  "LIGHT_LIVING",
			Addr:  MakeISL(LayerKnow, GrpObjHome, 0x01, 0x01, 0),
			Layer: 4, Desc: "đèn phòng khách",
		},
		{
			Name:  "LIGHT_BED",
			Addr:  MakeISL(LayerKnow, GrpObjHome, 0x01, 0x02, 0),
			Layer: 4, Desc: "đèn phòng ngủ",
		},
		{
			Name:  "HVAC",
			Addr:  MakeISL(LayerKnow, GrpObjDevice, 0x01, 0x01, 0),
			Layer: 4, Desc: "điều hòa",
		},
		{
			Name:  "DOOR_LOCK",
			Addr:  MakeISL(LayerKnow, GrpObjHome, 0x02, 0x01, 0),
			Layer: 4, Desc: "khóa cửa",
		},
	}
	for _, e := range entries {
		Register(e)
	}
}

// L7 — Agents & Skills
func registerL7() {
	entries := []*NodeEntry{
		{Name: "AAM",         Addr: MakeISL(LayerAgent, GrpAgentAAM,    0x01, 0x01, 0), Layer: 7, Desc: "AAM agent"},
		{Name: "LEOAI",       Addr: MakeISL(LayerAgent, GrpAgentLeoAI,  0x01, 0x01, 0), Layer: 7, Desc: "LeoAI agent"},
		{Name: "HOME_CHIEF",  Addr: MakeISL(LayerAgent, GrpAgentChief,  0x01, 0x01, 0), Layer: 7, Desc: "HomeChief agent"},
		{Name: "LIGHT_AGENT", Addr: MakeISL(LayerAgent, GrpAgentWorker, 0x01, 0x01, 0), Layer: 7, Desc: "LightAgent worker"},
		// Skills
		{Name: "SKILL_SHORTTERM", Addr: MakeISL(LayerAgent, GrpSkillMemory,  0x01, 0x01, 0), Layer: 7, Desc: "ShortTermMemory ĐN"},
		{Name: "SKILL_LONGTERM",  Addr: MakeISL(LayerAgent, GrpSkillMemory,  0x01, 0x02, 0), Layer: 7, Desc: "LongTermMemory QR"},
		{Name: "SKILL_DECIDE4D",  Addr: MakeISL(LayerAgent, GrpSkillDecide,  0x01, 0x01, 0), Layer: 7, Desc: "Decide4D"},
		{Name: "SKILL_DREAM",     Addr: MakeISL(LayerAgent, GrpSkillLearn,   0x01, 0x01, 0), Layer: 7, Desc: "Dream learning"},
		{Name: "SKILL_CLUSTER",   Addr: MakeISL(LayerAgent, GrpSkillLearn,   0x01, 0x02, 0), Layer: 7, Desc: "Cluster learning"},
		{Name: "SKILL_BROADCAST", Addr: MakeISL(LayerAgent, GrpSkillActuate, 0x01, 0x01, 0), Layer: 7, Desc: "Broadcast"},
		{Name: "SKILL_GATE",      Addr: MakeISL(LayerAgent, GrpSkillSec,     0x01, 0x01, 0), Layer: 7, Desc: "SecurityGate 🛡"},
		{Name: "SKILL_VISION",    Addr: MakeISL(LayerAgent, GrpSkillSense,   0x01, 0x01, 0), Layer: 7, Desc: "Vision SDF"},
		{Name: "SKILL_AUDIO",     Addr: MakeISL(LayerAgent, GrpSkillSense,   0x01, 0x02, 0), Layer: 7, Desc: "Audio formant"},
		{Name: "SKILL_ACTUATOR_LIGHT", Addr: MakeISL(LayerAgent, GrpSkillActuate, 0x02, 0x01, 0), Layer: 7, Desc: "ActuatorLight"},
	}
	for _, e := range entries {
		Register(e)
	}
}
