package gene

import (
	"math"
	"testing"
)

func TestWorldScene(t *testing.T) {
	ws := NewWorldScene()

	t.Log("=== WorldScene khởi tạo ===")
	t.Logf("  Clock: year=%.2f (Hè)  hour=%.0fh", ws.Clock.YearT, ws.Clock.HourOfDay)
	t.Logf("  Entities: Sun + Earth + %d Creature(s)", len(ws.Creatures))
	t.Logf("  GravityEdges: %d", len(ws.Gravity.Edges))

	// Snapshot tại 12h
	snap := ws.Snapshot()
	t.Logf("\n=== Snapshot 12h Hè ===")
	t.Logf("  Streams: %d", len(snap.Streams))
	t.Logf("  Tổng binary: %d bytes", snap.TotalBytes())
	t.Logf("  AirTemp: %.1f°C", snap.AirTempC)
	t.Logf("  Light intensity: %.2f", snap.Light.Intensity)
	t.Logf("  Sky RGB: (%.2f, %.2f, %.2f)", snap.SkyRGB.X, snap.SkyRGB.Y, snap.SkyRGB.Z)
	t.Logf("  Sun stream tokens: %d", snap.Streams[0].Len())
	t.Logf("  Earth stream tokens: %d", snap.Streams[1].Len())

	// Encode/Decode round-trip
	sunBytes := snap.Streams[0].Bytes()
	decoded  := DecodeStream(sunBytes)
	if decoded.Len() != snap.Streams[0].Len() {
		t.Errorf("Decode sai: got %d tokens, want %d", decoded.Len(), snap.Streams[0].Len())
	}
	t.Logf("\nRound-trip Sun stream: %d tokens → %d bytes → decode %d tokens ✓",
		snap.Streams[0].Len(), len(sunBytes), decoded.Len())

	// Token ISL đúng
	if decoded.Tokens[0].Addr != ISL_Sun {
		t.Errorf("Token[0] addr sai: %x", uint64(decoded.Tokens[0].Addr))
	}
	if decoded.Tokens[0].Type != TokEntity {
		t.Errorf("Token[0] type sai: %d", decoded.Tokens[0].Type)
	}
	t.Logf("  Token[0]: ISL=%016x type=Entity ✓", uint64(decoded.Tokens[0].Addr))

	// Tick qua 4 thời điểm trong ngày
	t.Log("\n=== Tick qua ngày ===")
	for _, h := range []float64{0, 6, 12, 18} {
		// Reset và tick đến giờ h
		ws2 := NewWorldScene()
		ws2.Clock.HourOfDay = h
		ws2.Clock.YearT = 0.5
		ws2.Sun.Animate(h)
		ws2.Earth.Animate(0.5)

		air := ws2.AirTempC()
		light := ws2.LightAt()
		sky := ws2.SkyColorAt()
		t.Logf("  %2.0fh  air=%.1f°C  lum=%.2f  skyR=%.2f",
			h, air, light.Intensity, sky.X)
	}

	// TemperatureAt — cross-entity query
	t.Log("\n=== TemperatureAt ===")
	// Điểm sát bề mặt trái đất (dùng vị trí thật của Earth)
	ep := ws.Earth.Orbit.Eval(ws.Clock.YearT)
	earthSurf := Vec3{ep.X, ep.Y + float64(ws.Earth.Radius) + 0.1, ep.Z}
	tempEarth := ws.TemperatureAt(earthSurf)
	t.Logf("  Bề mặt Earth: %.1f°C", tempEarth-273.15)

	// Điểm trên bề mặt mặt trời
	sunPos := ws.Sun.Orbit.Eval(0.5)
	sunSurf := Vec3{sunPos.X, sunPos.Y + ws.Sun.Radius + 0.1, sunPos.Z}
	tempSun := ws.TemperatureAt(sunSurf)
	t.Logf("  Bề mặt Sun: %.0fK (%.0f°C)", tempSun, tempSun-273.15)

	// Trời hè giữa trưa phải ấm
	airTemp := ws.AirTempC()
	if airTemp < 10 || airTemp > 35 {
		t.Errorf("AirTemp %.1f°C ngoài dải hợp lý [10,35]°C (Hè ôn đới)", airTemp)
	}
	t.Logf("\nHè ôn đới 12h: %.1f°C ✓ (trong dải [10,35])", airTemp)

	// Binary size hợp lý
	if snap.TotalBytes() == 0 {
		t.Error("TotalBytes = 0")
	}
	expectedMin := 5 * 20 // ít nhất 5 tokens × 20 bytes
	if snap.TotalBytes() < expectedMin {
		t.Errorf("TotalBytes %d < %d", snap.TotalBytes(), expectedMin)
	}
	t.Logf("Binary snapshot: %d bytes ✓", snap.TotalBytes())

	_ = math.Pi
}
