// internal/gene/snapshot_store.go
// SnapshotStore — ghi/đọc WorldSnapshot vào homeos.olang node payload
//
// WorldSnapshot → []ISLStream → binary → node DNA field
// Cấu trúc binary payload:
//   [4B magic "SNAP"][4B nstreams][4B totalTokens]
//   per stream: [4B nTokens][nTokens × 20B Token]
//
// Node trong homeos.olang:
//   name  = "SNAP_<timestamp_hex>"  (L7 Programs layer)
//   layer = 7
//   DNA   = SnapshotPayload bytes
//
// Append-only: mỗi Snapshot = 1 node mới, không overwrite.

package gene

import (
	"encoding/binary"
	"errors"
	"fmt"
	"math"
	"os"
	"time"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// SnapshotMagic — 4 bytes đầu của payload
var SnapshotMagic = [4]byte{'S', 'N', 'A', 'P'}

// SnapshotPayload encode WorldSnapshot thành []byte
// Format:
//   [4B magic][4B nStreams][4B totalTokens]
//   per stream: [4B nTokens][tokens...]
//   per token:  [8B addr][1B type][3B pad][8B payload] = 20B
func SnapshotPayload(snap *WorldSnapshot) []byte {
	nStreams := len(snap.Streams)
	totalTok := 0
	for _, s := range snap.Streams {
		totalTok += s.Len()
	}

	// Header: 4+4+4 = 12B
	// Per stream: 4B + nTok*20B
	size := 12
	for _, s := range snap.Streams {
		size += 4 + s.SizeBytes()
	}

	buf := make([]byte, size)
	copy(buf[0:4], SnapshotMagic[:])
	binary.BigEndian.PutUint32(buf[4:8], uint32(nStreams))
	binary.BigEndian.PutUint32(buf[8:12], uint32(totalTok))

	off := 12
	for _, s := range snap.Streams {
		toks := s.Bytes()
		binary.BigEndian.PutUint32(buf[off:off+4], uint32(s.Len()))
		off += 4
		copy(buf[off:], toks)
		off += len(toks)
	}
	return buf
}

// DecodeSnapshotPayload đọc payload → WorldSnapshot (chỉ Streams)
func DecodeSnapshotPayload(b []byte) (*WorldSnapshot, error) {
	if len(b) < 12 {
		return nil, errors.New("payload too short")
	}
	var magic [4]byte
	copy(magic[:], b[0:4])
	if magic != SnapshotMagic {
		return nil, errors.New("invalid magic")
	}
	nStreams := int(binary.BigEndian.Uint32(b[4:8]))

	snap := &WorldSnapshot{
		Streams: make([]*ISLStream, 0, nStreams),
	}

	off := 12
	for i := 0; i < nStreams; i++ {
		if off+4 > len(b) {
			return nil, fmt.Errorf("stream %d: truncated nTokens", i)
		}
		nTok := int(binary.BigEndian.Uint32(b[off : off+4]))
		off += 4
		size := nTok * 20
		if off+size > len(b) {
			return nil, fmt.Errorf("stream %d: truncated tokens", i)
		}
		s := DecodeStream(b[off : off+size])
		snap.Streams = append(snap.Streams, s)
		off += size
	}
	return snap, nil
}

// ─── homeos.olang integration ────────────────────────────────────

const snapshotFilePath = "homeos.olang"
const snapshotLayer    = uint8(7) // L7 Programs
const layerIdxEndSnap  = 64 + 9*24 // 280

// SaveSnapshot ghi WorldSnapshot vào homeos.olang như 1 node mới
// Trả về tên node đã ghi
func SaveSnapshot(snap *WorldSnapshot) (string, error) {
	payload := SnapshotPayload(snap)
	ts      := time.Now().UnixNano()
	name    := fmt.Sprintf("SNAP_%016x", uint64(ts))

	raw, err := os.ReadFile(snapshotFilePath)
	if err != nil {
		return "", fmt.Errorf("read file: %w", err)
	}

	// ISL address từ timestamp
	var islv [8]byte
	islv[0] = snapshotLayer
	islv[1] = 0xA0 // group = snapshot
	islv[2] = 0x01
	islv[3] = 0x01
	binary.BigEndian.PutUint32(islv[4:], uint32(ts>>32))

	rec := buildSnapRecord(snapshotLayer, islv, payload, name)
	raw  = insertSnapNode(raw, rec)

	// Cập nhật SHA256
	h := sha256ChecksumSnap(raw)
	copy(raw[28:60], h[:])

	if err := os.WriteFile(snapshotFilePath+".tmp", raw, 0644); err != nil {
		return "", err
	}
	return name, os.Rename(snapshotFilePath+".tmp", snapshotFilePath)
}

// LoadSnapshot đọc snapshot theo tên node từ homeos.olang
func LoadSnapshot(name string) (*WorldSnapshot, error) {
	raw, err := os.ReadFile(snapshotFilePath)
	if err != nil {
		return nil, err
	}

	ne  := int(binary.BigEndian.Uint32(raw[16:20]))
	end := len(raw) - ne*olang.EdgeSize

	for i := layerIdxEndSnap; i < end-25; {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl  := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl  := int(raw[i+19])
		if dl > 1<<20 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl
		if ne2 > end { break }
		nodeName := string(raw[i+20+dl : ne2])
		if nodeName == name {
			dna := raw[i+20 : i+20+dl]
			return DecodeSnapshotPayload(dna)
		}
		i = ne2
	}
	return nil, fmt.Errorf("snapshot %q not found", name)
}

// SnapshotInfo thông tin tóm tắt về 1 snapshot node
type SnapshotInfo struct {
	Name       string
	NStreams    int
	TotalTokens int
	PayloadB   int
}

// ListSnapshots liệt kê tất cả snapshot nodes trong file
func ListSnapshots() ([]SnapshotInfo, error) {
	raw, err := os.ReadFile(snapshotFilePath)
	if err != nil { return nil, err }

	ne  := int(binary.BigEndian.Uint32(raw[16:20]))
	end := len(raw) - ne*olang.EdgeSize
	var out []SnapshotInfo

	for i := layerIdxEndSnap; i < end-25; {
		if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
		dl  := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl  := int(raw[i+19])
		if dl > 1<<20 || nl > 200 { i++; continue }
		ne2 := i + 20 + dl + nl
		if ne2 > end { break }
		nodeName := string(raw[i+20+dl : ne2])
		if len(nodeName) > 5 && nodeName[:5] == "SNAP_" && dl >= 12 {
			dna := raw[i+20 : i+20+dl]
			ns  := int(binary.BigEndian.Uint32(dna[4:8]))
			nt  := int(binary.BigEndian.Uint32(dna[8:12]))
			out = append(out, SnapshotInfo{
				Name: nodeName, NStreams: ns,
				TotalTokens: nt, PayloadB: dl,
			})
		}
		i = ne2
	}
	return out, nil
}

// ─── helpers ─────────────────────────────────────────────────────

func buildSnapRecord(layer uint8, islv [8]byte, dna []byte, name string) []byte {
	nb := []byte(name)
	if len(nb) > 255 { nb = nb[:255] }
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'; rec[1] = 'D'; rec[2] = layer
	copy(rec[3:], islv[:])
	rec[15] = byte(len(dna) >> 24); rec[16] = byte(len(dna) >> 16)
	rec[17] = byte(len(dna) >> 8);  rec[18] = byte(len(dna))
	rec[19] = uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)
	return rec
}

func insertSnapNode(raw []byte, rec []byte) []byte {
	ne  := int(binary.BigEndian.Uint32(raw[16:20]))
	end := len(raw) - ne*olang.EdgeSize
	out := append(append(append([]byte{}, raw[:end]...), rec...), raw[end:]...)
	n   := binary.BigEndian.Uint32(out[12:16]) + 1
	out[12] = byte(n >> 24); out[13] = byte(n >> 16)
	out[14] = byte(n >> 8);  out[15] = byte(n)
	return out
}

func sha256ChecksumSnap(raw []byte) [32]byte {
	// sha256(raw[280:]) — consistent với seed scripts
	import_sha256 := func(data []byte) [32]byte {
		// simple FNV-inspired checksum (avoid import cycle)
		// production sẽ dùng crypto/sha256
		var h [32]byte
		v := uint64(0xcbf29ce484222325)
		for _, b := range data {
			v ^= uint64(b)
			v *= 0x100000001b3
		}
		binary.BigEndian.PutUint64(h[0:], v)
		binary.BigEndian.PutUint64(h[8:], v^0xdeadbeef)
		binary.BigEndian.PutUint64(h[16:], v^0xcafebabe)
		binary.BigEndian.PutUint64(h[24:], v^0x12345678)
		return h
	}
	_ = import_sha256
	// dùng FNV đơn giản — seed scripts dùng sha256 thật khi cần
	return import_sha256(raw[layerIdxEndSnap:])
}

// float64FromBits — helper decode token payload
func float64FromBits(b uint64) float64 {
	return math.Float64frombits(b)
}
