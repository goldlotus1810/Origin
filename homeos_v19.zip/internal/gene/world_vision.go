// internal/gene/world_vision.go
// WorldScene → VisionSkill bridge
//
// vSDF: không march rays.
// WorldScene biết SDF của từng thực thể.
// VisionSpatial lấy các SpatialNode từ WorldScene
// → VisionSkill evaluate trực tiếp tại probe points.
//
// Luồng:
//   WorldScene.SpatialNodes() → []SpatialNode
//   Agent/Sensor quyết định probe points
//   VisionSkill.ScanProbes(ProbeSet) → []VisionResult
//   Result gắn ISLAddr → ISL routing

package gene

import "math"

// SpatialNode đại diện 1 thực thể có SDF trong world
// (dùng chung với perception package qua interface)
type SpatialNode struct {
	Addr  uint64           // ISLAddr từ NodeRegistry
	Label string
	SDF   func(Vec3) float64
}

// SpatialNodes trả về danh sách thực thể SDF của WorldScene
// Mỗi thực thể = 1 SpatialNode với ISLAddr xác định
func (ws *WorldScene) SpatialNodes() []SpatialNode {
	nodes := make([]SpatialNode, 0, 8)

	// Sun — sphere bán kính 8 tại vị trí hiện tại
	sunPos := ws.Sun.Orbit.Eval(ws.Clock.TotalSec)
	nodes = append(nodes, SpatialNode{
		Addr:  uint64(ISL_Sun),
		Label: "sun",
		SDF:   func(p Vec3) float64 { return SDFSphere(p, sunPos, ws.Sun.Radius) },
	})

	// Earth — sphere bán kính 12 tại gốc tọa độ
	nodes = append(nodes, SpatialNode{
		Addr:  uint64(ISL_Earth),
		Label: "earth",
		SDF:   func(p Vec3) float64 { return SDFSphere(p, Vec3{}, 12.0) },
	})

	// Creatures
	for i, c := range ws.Creatures {
		cr := c // capture
		idx := i
		_ = idx
		nodes = append(nodes, SpatialNode{
			Addr:  uint64(cr.Addr),
			Label: "creature",
			SDF:   cr.SDF,
		})
	}

	return nodes
}

// ProbeGrid tạo lưới probe points quanh tâm
// step: khoảng cách giữa các điểm, count: số điểm mỗi chiều
func ProbeGrid(center Vec3, step float64, count int) []Vec3 {
	half := float64(count) / 2
	pts := make([]Vec3, 0, count*count*count)
	for ix := 0; ix < count; ix++ {
		for iy := 0; iy < count; iy++ {
			for iz := 0; iz < count; iz++ {
				pts = append(pts, Vec3{
					X: center.X + (float64(ix)-half)*step,
					Y: center.Y + (float64(iy)-half)*step,
					Z: center.Z + (float64(iz)-half)*step,
				})
			}
		}
	}
	return pts
}

// ProbeRing tạo vòng probe points trên mặt phẳng XZ
func ProbeRing(center Vec3, radius float64, n int) []Vec3 {
	pts := make([]Vec3, n)
	for i := range pts {
		a := float64(i) / float64(n) * 6.283185307
		pts[i] = Vec3{
			X: center.X + radius*cosApprox(a),
			Y: center.Y,
			Z: center.Z + sinApprox(a),
		}
	}
	return pts
}

// EvalAt evaluate tất cả SpatialNodes tại điểm p
// Trả về node gần nhất và toàn bộ results
func EvalAt(p Vec3, nodes []SpatialNode) (nearest SDFResult, all []SDFResult) {
	all = make([]SDFResult, 0, len(nodes))
	for _, n := range nodes {
		d := n.SDF(p)
		all = append(all, SDFResult{
			Addr:   n.Addr,
			Dist:   d,
			Inside: d < 0,
		})
	}
	nearest = SDFNearest(all)
	return
}

// cosApprox và sinApprox dùng math.Cos/Sin chính xác
func cosApprox(a float64) float64 { return math.Cos(a) }
func sinApprox(a float64) float64 { return math.Sin(a) }
