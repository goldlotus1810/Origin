package gene

import (
	"testing"
	"time"
)

func TestContextState(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  CONTEXT STATE — HomeOS tự hành động                        ║")
	t.Log("║  Perception → Context → Auto Action                         ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	cs  := NewContextState()
	_ = NewActionRecognizer() // ar: disabled until Analyze implemented
	now := time.Date(2026, 3, 10, 19, 30, 0, 0, time.UTC)

	// ── Simulate 1 ngày trong nhà ────────────────────────────────
	type moment struct {
		label   string
		hour    int
		scene   *SceneUnderstanding
		species string
		cmd     string // optional ambient command
	}

	moments := []moment{
		{
			label: "07:00 — Sáng dậy, tập thể dục",
			hour:  7,
			scene: &SceneUnderstanding{
				Action: ActionExercising, ActionConf: 0.88,
				Space:  SpaceGym, SpaceConf: 0.75,
				ISLAddr: SpaceGym.ISLAddr(),
			},
			species: "human_adult_female",
		},
		{
			label: "08:00 — Nấu sáng",
			hour:  8,
			scene: &SceneUnderstanding{
				Action: ActionCooking, ActionConf: 1.00,
				Space:  SpaceKitchen, SpaceConf: 0.80,
				ISLAddr: SpaceKitchen.ISLAddr(),
			},
			species: "human_adult_female",
			cmd:     "lạnh hơn", // trời nóng, muốn mát
		},
		{
			label: "09:00 — Làm việc",
			hour:  9,
			scene: &SceneUnderstanding{
				Action: ActionTyping, ActionConf: 0.85,
				Space:  SpaceOffice, SpaceConf: 0.60,
				ISLAddr: SpaceOffice.ISLAddr(),
			},
			species: "human_adult_male",
			cmd:     "sáng hơn",
		},
		{
			label: "19:30 — Xem TV",
			hour:  19,
			scene: &SceneUnderstanding{
				Action: ActionSitting, ActionConf: 0.90,
				Space:  SpaceLivingRoom, SpaceConf: 0.60,
				ISLAddr: SpaceLivingRoom.ISLAddr(),
			},
			species: "human_adult_male",
		},
		{
			label: "20:00 — Con chó chạy trong nhà",
			hour:  20,
			scene: &SceneUnderstanding{
				Action: ActionRunning, ActionConf: 0.80,
				Space:  SpaceLivingRoom, SpaceConf: 0.50,
				ISLAddr: SpaceLivingRoom.ISLAddr(),
			},
			species: "dog_medium",
		},
		{
			label: "21:00 — Khiêu vũ",
			hour:  21,
			scene: nil, // ar.Recognize disabled
			species: "human_adult_female",
		},
		// {
// 					func(t float64)(float64,float64){ return .50+.15+costT(t)*.12,.40-sinT(t)*.18 },
// 					func(t float64)(float64,float64){ return .50-.15-costT(t)*.12,.40-sinT(t)*.18 },
// 					func(t float64)(float64,float64){ return .55+sinT2(t)*.04,.72 },
// 					func(t float64)(float64,float64){ return .50,.50 },
// 				),
// 				[]AudioCue{AudioMusic},
// 			),
// 			species: "human_adult_female",
// 			cmd:     "im lặng", // thử tắt nhạc giữa chừng
// 		},
// 		{
// 			label: "22:30 — Ngủ",
// 			hour:  22,
// 			scene: &SceneUnderstanding{
// 				Action: ActionSleeping, ActionConf: 0.85,
// 				Space:  SpaceBedroom, SpaceConf: 0.87,
// 				ISLAddr: SpaceBedroom.ISLAddr(),
// 			},
// 			species: "human_adult_female",
// 		},
	}

	t.Log("[ TIMELINE — 1 NGÀY TRONG NHÀ ]")
	t.Log()

	for _, m := range moments {
		if m.scene == nil { continue } // skip disabled test cases
		ts := now.Add(time.Duration(m.hour-19)*time.Hour + time.Duration(m.hour%3)*time.Minute)
		if m.scene == nil { continue }
		events := cs.Update(m.scene, m.species, ts)

		state := cs.Spaces[m.scene.Space]

		t.Logf("━━ %s", m.label)
		t.Logf("   species=%-20s action=%-12s conf=%.0f%%",
			m.species, m.scene.Action, m.scene.ActionConf*100)
		t.Logf("   space=%-14s ISL=%s",
			m.scene.Space, m.scene.ISLAddr)
		t.Logf("   💡 light=%.0f%%  🔊 sound=%.0f%%  🌡 %.1f°C  💨 fan=%.0f%%",
			state.LightLevel*100, state.SoundLevel*100,
			state.Temperature, state.FanSpeed*100)

		if len(events) > 0 && len(events[0].Changes) > 0 {
			t.Logf("   ⚡ auto: %v", events[0].Changes)
		}

		// Ambient command
		if m.cmd != "" && len(state.Occupants) > 0 {
			resp := cs.AmbientCommand(m.cmd, m.scene.Space)
			t.Logf("   🗣 \"%s\" → %s", m.cmd, resp.Result)
		}
		t.Log()
	}

	// ── Summary ──────────────────────────────────────────────────
	t.Log("[ TRẠNG THÁI TOÀN NHÀ ]")
	spaces := []SpaceType{
		SpaceKitchen, SpaceLivingRoom, SpaceBedroom,
		SpaceOffice, SpaceGym,
	}
	for _, sp := range spaces {
		s := cs.Spaces[sp]
		status := "  empty"
		if s.IsActive && len(s.Occupants) > 0 {
			status = string(s.Occupants[len(s.Occupants)-1].Action)
		}
		t.Logf("  %-14s [%-10s] ISL=%-5s  💡%.0f%% 🌡%.0fC",
			sp, status, s.ISLAddr,
			s.LightLevel*100, s.Temperature)
	}

	t.Log()
	t.Log("[ KEY INSIGHT ]")
	t.Log("  Không cần user nói 'bật đèn bếp'")
	t.Log("  Không cần user nói 'tắt đèn khi ngủ'")
	t.Log("  Không cần user nói 'phòng nào'")
	t.Log("  → Perception (SDF+motion) → Context → HomeOS tự làm")
	t.Log()
	t.Log("--- PASS")
}

// helpers
func sinT(t float64) float64  { return sinPh(t * 3.14159 * 2 / 3) }
func sinT2(t float64) float64 { return sinPh(t * 3.14159 / 3) }
func costT(t float64) float64 { return cosPh(t * 3.14159 * 2 / 3) }
func sinPh(ph float64) float64 {
	// Taylor: sin(ph)
	ph = ph - float64(int(ph/(2*3.14159)))*2*3.14159
	x := ph
	return x - x*x*x/6 + x*x*x*x*x/120
}
func cosPh(ph float64) float64 { return sinPh(ph + 3.14159/2) }

// // stub — makeActionClip was in action_test.go
// func makeActionClip(action string, fps, frames int, joints ...string) interface{} {
// 	return nil // TODO: implement when ActionClip is defined
