// internal/gene/context_state.go
//
// ContextState — trạng thái hiện tại của không gian
//
// Insight (session 116):
//   ActionRecognizer biết: "ai đang làm gì ở đâu"
//   ContextState lưu: lịch sử + suy luận tự động
//   HomeOS hành động: không cần người dùng nói thêm
//
// Ví dụ:
//   19:30 → cooking in kitchen → đèn bếp bật
//   22:00 → sleeping in bedroom → toàn nhà tắt tiếng
//   07:00 → stretching in gym → nhạc tập thể dục
//
// QT6: SDF (hữu hình) ⧺ ISL (vô hình) = Smooth_union
//   SDF = skeleton, motion, space
//   ISL = intent, rule, action
//   Kết hợp → HomeOS tự hành động

package gene

import (
	"fmt"
	"math"
	"time"
)

// ─── SpaceState — trạng thái 1 phòng ────────────────────────────────────

type OccupantState struct {
	Species    string      // "human_adult_female"
	Action     ActionVerb
	ActionConf float64
	Since      time.Time
	Duration   time.Duration // đã ở bao lâu
}

type SpaceState struct {
	Space     SpaceType
	ISLAddr   string
	Occupants []OccupantState
	LastSeen  time.Time
	IsActive  bool

	// Environment suggestions
	LightLevel   float64 // 0=tắt, 1=sáng tối đa
	SoundLevel   float64 // 0=yên tĩnh, 1=to
	Temperature  float64 // Celsius ideal
	FanSpeed     float64 // 0=tắt, 1=full
}

// ─── AutoRule — luật tự động ────────────────────────────────────────────

type AutoRule struct {
	Name      string
	Condition func(s *SpaceState) bool
	Apply     func(s *SpaceState)
	Priority  int // cao hơn = ưu tiên hơn
}

// defaultRules là bộ luật tự động mặc định
var defaultRules = []AutoRule{
	{
		Name:     "cooking → đèn bếp sáng + quạt hút",
		Priority: 10,
		Condition: func(s *SpaceState) bool {
			return s.Space == SpaceKitchen && s.hasAction(ActionCooking)
		},
		Apply: func(s *SpaceState) {
			s.LightLevel  = 0.90
			s.FanSpeed    = 0.70
			s.Temperature = 22.0
		},
	},
	{
		Name:     "sleeping → tắt đèn + yên tĩnh + mát",
		Priority: 10,
		Condition: func(s *SpaceState) bool {
			return s.Space == SpaceBedroom && s.hasAction(ActionSleeping)
		},
		Apply: func(s *SpaceState) {
			s.LightLevel  = 0.0
			s.SoundLevel  = 0.0
			s.Temperature = 26.0
			s.FanSpeed    = 0.20
		},
	},
	{
		Name:     "dancing → đèn vừa + nhạc",
		Priority: 8,
		Condition: func(s *SpaceState) bool {
			return s.hasAction(ActionDancing)
		},
		Apply: func(s *SpaceState) {
			s.LightLevel = 0.60
			s.SoundLevel = 0.65
		},
	},
	{
		Name:     "typing/working → đèn sáng + yên tĩnh",
		Priority: 8,
		Condition: func(s *SpaceState) bool {
			return s.hasAction(ActionTyping) || s.Space == SpaceOffice
		},
		Apply: func(s *SpaceState) {
			s.LightLevel  = 0.85
			s.SoundLevel  = 0.10
			s.Temperature = 24.0
		},
	},
	{
		Name:     "exercising → đèn sáng + thông khí",
		Priority: 9,
		Condition: func(s *SpaceState) bool {
			return s.hasAction(ActionExercising) || s.hasAction(ActionRunning)
		},
		Apply: func(s *SpaceState) {
			s.LightLevel  = 1.00
			s.FanSpeed    = 1.00
			s.Temperature = 20.0
			s.SoundLevel  = 0.70
		},
	},
	{
		Name:     "sitting/TV → đèn dịu + yên tĩnh vừa",
		Priority: 6,
		Condition: func(s *SpaceState) bool {
			return s.hasAction(ActionSitting) && s.Space == SpaceLivingRoom
		},
		Apply: func(s *SpaceState) {
			s.LightLevel  = 0.35
			s.SoundLevel  = 0.40
			s.Temperature = 25.0
		},
	},
	{
		Name:     "empty room → tiết kiệm điện",
		Priority: 1,
		Condition: func(s *SpaceState) bool {
			return !s.IsActive
		},
		Apply: func(s *SpaceState) {
			s.LightLevel = 0.0
			s.FanSpeed   = 0.0
		},
	},
}

func (s *SpaceState) hasAction(a ActionVerb) bool {
	for _, o := range s.Occupants {
		if o.Action == a && o.ActionConf > 0.5 {
			return true
		}
	}
	return false
}

// ─── ContextState — toàn bộ ngôi nhà ────────────────────────────────────

type ContextState struct {
	Spaces  map[SpaceType]*SpaceState
	Rules   []AutoRule
	History []ContextEvent
}

type ContextEvent struct {
	Time    time.Time
	Space   SpaceType
	Action  ActionVerb
	ISLAddr string
	Changes []string // môi trường thay đổi gì
}

func NewContextState() *ContextState {
	cs := &ContextState{
		Spaces: make(map[SpaceType]*SpaceState),
		Rules:  defaultRules,
	}
	// Khởi tạo tất cả phòng
	for _, sp := range []SpaceType{
		SpaceKitchen, SpaceLivingRoom, SpaceBedroom,
		SpaceOffice, SpaceBathroom, SpaceGym, SpaceOutdoor,
	} {
		cs.Spaces[sp] = &SpaceState{
			Space:       sp,
			ISLAddr:     sp.ISLAddr(),
			Temperature: 25.0,
		}
	}
	return cs
}

// Update cập nhật state từ SceneUnderstanding mới
func (cs *ContextState) Update(scene *SceneUnderstanding, species string, now time.Time) []ContextEvent {
	if scene == nil {
		return nil
	}
	sp := scene.Space
	state := cs.Spaces[sp]

	// Tìm occupant cũ hoặc tạo mới
	found := false
	for i, o := range state.Occupants {
		if o.Species == species {
			state.Occupants[i].Action     = scene.Action
			state.Occupants[i].ActionConf = scene.ActionConf
			state.Occupants[i].Duration   = now.Sub(o.Since)
			found = true
			break
		}
	}
	if !found {
		state.Occupants = append(state.Occupants, OccupantState{
			Species:    species,
			Action:     scene.Action,
			ActionConf: scene.ActionConf,
			Since:      now,
		})
	}

	state.IsActive = true
	state.LastSeen = now

	// Áp dụng rules theo priority
	prev := SpaceState{
		LightLevel:  state.LightLevel,
		SoundLevel:  state.SoundLevel,
		Temperature: state.Temperature,
		FanSpeed:    state.FanSpeed,
	}

	// Sort by priority desc
	rules := cs.Rules
	for i := 0; i < len(rules)-1; i++ {
		for j := i+1; j < len(rules); j++ {
			if rules[j].Priority > rules[i].Priority {
				rules[i], rules[j] = rules[j], rules[i]
			}
		}
	}
	for _, rule := range rules {
		if rule.Condition(state) {
			rule.Apply(state)
			break // highest priority wins
		}
	}

	// Ghi lại thay đổi
	var changes []string
	if math.Abs(state.LightLevel-prev.LightLevel) > 0.05 {
		changes = append(changes, fmt.Sprintf("light %.0f%%→%.0f%%",
			prev.LightLevel*100, state.LightLevel*100))
	}
	if math.Abs(state.SoundLevel-prev.SoundLevel) > 0.05 {
		changes = append(changes, fmt.Sprintf("sound %.0f%%→%.0f%%",
			prev.SoundLevel*100, state.SoundLevel*100))
	}
	if math.Abs(state.Temperature-prev.Temperature) > 0.5 {
		changes = append(changes, fmt.Sprintf("temp %.0f→%.0fC",
			prev.Temperature, state.Temperature))
	}
	if math.Abs(state.FanSpeed-prev.FanSpeed) > 0.05 {
		changes = append(changes, fmt.Sprintf("fan %.0f%%→%.0f%%",
			prev.FanSpeed*100, state.FanSpeed*100))
	}

	event := ContextEvent{
		Time:    now,
		Space:   sp,
		Action:  scene.Action,
		ISLAddr: scene.ISLAddr,
		Changes: changes,
	}
	cs.History = append(cs.History, event)
	return []ContextEvent{event}
}

// AmbientCommand xử lý lệnh ngắn trong context
// "tắt đèn" → biết đang ở kitchen → tắt đèn kitchen
// "lạnh hơn" → biết đang ở bedroom → hạ nhiệt độ
func (cs *ContextState) AmbientCommand(cmd string, activeSpace SpaceType) *AmbientResponse {
	state := cs.Spaces[activeSpace]

	type cmdRule struct {
		keywords []string
		apply    func(s *SpaceState) string
	}

	rules := []cmdRule{
		{
			keywords: []string{"tắt đèn", "tối đi", "dim"},
			apply: func(s *SpaceState) string {
				old := s.LightLevel
				s.LightLevel = math.Max(0, s.LightLevel-0.30)
				return fmt.Sprintf("%s: đèn %.0f%%→%.0f%%", s.ISLAddr, old*100, s.LightLevel*100)
			},
		},
		{
			keywords: []string{"bật đèn", "sáng hơn", "bright"},
			apply: func(s *SpaceState) string {
				old := s.LightLevel
				s.LightLevel = math.Min(1, s.LightLevel+0.30)
				return fmt.Sprintf("%s: đèn %.0f%%→%.0f%%", s.ISLAddr, old*100, s.LightLevel*100)
			},
		},
		{
			keywords: []string{"lạnh hơn", "mát hơn", "cooler"},
			apply: func(s *SpaceState) string {
				old := s.Temperature
				s.Temperature -= 1.5
				return fmt.Sprintf("%s: %.1f→%.1fC", s.ISLAddr, old, s.Temperature)
			},
		},
		{
			keywords: []string{"ấm hơn", "nóng hơn", "warmer"},
			apply: func(s *SpaceState) string {
				old := s.Temperature
				s.Temperature += 1.5
				return fmt.Sprintf("%s: %.1f→%.1fC", s.ISLAddr, old, s.Temperature)
			},
		},
		{
			keywords: []string{"im lặng", "yên tĩnh", "quiet"},
			apply: func(s *SpaceState) string {
				s.SoundLevel = 0
				return fmt.Sprintf("%s: sound off", s.ISLAddr)
			},
		},
	}

	for _, rule := range rules {
		for _, kw := range rule.keywords {
			if containsKW(cmd, kw) {
				result := rule.apply(state)
				return &AmbientResponse{
					ISLAddr: state.ISLAddr,
					Space:   activeSpace,
					Result:  result,
					Context: fmt.Sprintf("người đang %s", state.Occupants[0].Action),
				}
			}
		}
	}
	return &AmbientResponse{
		ISLAddr: state.ISLAddr,
		Space:   activeSpace,
		Result:  "không hiểu lệnh: " + cmd,
	}
}

type AmbientResponse struct {
	ISLAddr string
	Space   SpaceType
	Result  string
	Context string
}

func containsKW(s, kw string) bool {
	// Simple contains check
	for i := 0; i <= len(s)-len(kw); i++ {
		if s[i:i+len(kw)] == kw { return true }
	}
	return false
}
