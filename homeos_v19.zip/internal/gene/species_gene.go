// internal/gene/creature.go
//
// CREATURE GENE — DNA của mọi sinh vật
//
// Vision (session 114):
//   Không phải 1 avatar — mà là kho DNA của mọi sinh vật
//   Trẻ em, người già, nam, nữ, chó, mèo, chim, cá, rắn...
//   Mỗi loài = proportions + skeleton + motion signature
//
// QT4: Bản chất quyết định tồn tại
//   Species = tập hợp SDF primitives + proportions
//
// QT5: Bản chất quyết định vị trí
//   human_child gần human_adult hơn là gần fish

package gene

import "math"

// ─── Proportions — tỉ lệ cơ thể ─────────────────────────────────────────

// Proportions tỉ lệ cơ thể normalized (height = 1.0)
type Proportions struct {
	// Đầu
	HeadR      float64 // bán kính đầu / chiều cao
	NeckLen    float64
	NeckR      float64

	// Thân
	ShoulderW  float64 // vai rộng
	ChestD     float64 // ngực sâu
	TorsoLen   float64
	TorsoR     float64
	HipW       float64

	// Chi trên
	UpperArmLen float64
	UpperArmR   float64
	ForeArmLen  float64
	ForeArmR    float64
	HandR       float64

	// Chi dưới
	UpperLegLen float64
	UpperLegR   float64
	LowerLegLen float64
	LowerLegR   float64
	FootLen     float64

	// Cột sống
	SpineCurve  float64 // 0=thẳng, >0=cong về trước (người già)
	SpineCount  int     // số đốt sống (quan trọng cho rắn)

	// Smooth union
	K float64 // blend factor
}

// ─── Species templates ────────────────────────────────────────────────────

// SpeciesGene DNA đầy đủ của 1 loài
type SpeciesGene struct {
	ID          string
	Name        string
	Category    string // "human" / "mammal" / "bird" / "fish" / "reptile"
	Props       Proportions
	LimbCount   int    // 2=bipedal, 4=quadruped, 0=snake, 6=insect
	HasWings    bool
	HasTail     bool
	TailLen     float64
	TailR       float64
	Description string
}

// ── HUMAN VARIANTS ──────────────────────────────────────────────────────

var HumanAdultMale = SpeciesGene{
	ID: "human_adult_male", Name: "Người trưởng thành nam",
	Category: "human", LimbCount: 2,
	Description: "Vai rộng, hông hẹp, tỉ lệ 1:7.5",
	Props: Proportions{
		HeadR: 0.072, NeckLen: 0.055, NeckR: 0.030,
		ShoulderW: 0.240, ChestD: 0.130, TorsoLen: 0.290, TorsoR: 0.110, HipW: 0.180,
		UpperArmLen: 0.165, UpperArmR: 0.032, ForeArmLen: 0.145, ForeArmR: 0.026, HandR: 0.028,
		UpperLegLen: 0.245, UpperLegR: 0.048, LowerLegLen: 0.230, LowerLegR: 0.032, FootLen: 0.075,
		SpineCurve: 0.02, SpineCount: 5, K: 0.12,
	},
}

var HumanAdultFemale = SpeciesGene{
	ID: "human_adult_female", Name: "Người trưởng thành nữ",
	Category: "human", LimbCount: 2,
	Description: "Hông rộng, vai hẹp, tỉ lệ 1:7",
	Props: Proportions{
		HeadR: 0.070, NeckLen: 0.050, NeckR: 0.026,
		ShoulderW: 0.200, ChestD: 0.115, TorsoLen: 0.275, TorsoR: 0.095, HipW: 0.220,
		UpperArmLen: 0.150, UpperArmR: 0.026, ForeArmLen: 0.130, ForeArmR: 0.021, HandR: 0.024,
		UpperLegLen: 0.250, UpperLegR: 0.052, LowerLegLen: 0.235, LowerLegR: 0.030, FootLen: 0.065,
		SpineCurve: 0.025, SpineCount: 5, K: 0.13,
	},
}

var HumanChild6 = SpeciesGene{
	ID: "human_child_6", Name: "Trẻ em 6 tuổi",
	Category: "human", LimbCount: 2,
	Description: "Đầu to, chân ngắn, tỉ lệ 1:5.5",
	Props: Proportions{
		HeadR: 0.110, NeckLen: 0.040, NeckR: 0.025, // đầu to hơn nhiều
		ShoulderW: 0.180, ChestD: 0.090, TorsoLen: 0.220, TorsoR: 0.090, HipW: 0.165,
		UpperArmLen: 0.130, UpperArmR: 0.022, ForeArmLen: 0.110, ForeArmR: 0.018, HandR: 0.020,
		UpperLegLen: 0.185, UpperLegR: 0.038, LowerLegLen: 0.170, LowerLegR: 0.026, FootLen: 0.055,
		SpineCurve: 0.01, SpineCount: 5, K: 0.15, // mềm hơn
	},
}

var HumanToddler = SpeciesGene{
	ID: "human_toddler", Name: "Trẻ 1-2 tuổi",
	Category: "human", LimbCount: 2,
	Description: "Đầu rất to, bụng tròn, chân rất ngắn, tỉ lệ 1:4",
	Props: Proportions{
		HeadR: 0.145, NeckLen: 0.025, NeckR: 0.028,
		ShoulderW: 0.160, ChestD: 0.110, TorsoLen: 0.200, TorsoR: 0.110, HipW: 0.170,
		UpperArmLen: 0.100, UpperArmR: 0.022, ForeArmLen: 0.085, ForeArmR: 0.018, HandR: 0.022,
		UpperLegLen: 0.145, UpperLegR: 0.038, LowerLegLen: 0.130, LowerLegR: 0.028, FootLen: 0.045,
		SpineCurve: 0.05, SpineCount: 5, K: 0.18,
	},
}

var HumanElderly = SpeciesGene{
	ID: "human_elderly", Name: "Người cao tuổi",
	Category: "human", LimbCount: 2,
	Description: "Cột sống cong, khớp lớn hơn, tỉ lệ giảm",
	Props: Proportions{
		HeadR: 0.075, NeckLen: 0.045, NeckR: 0.028,
		ShoulderW: 0.205, ChestD: 0.120, TorsoLen: 0.265, TorsoR: 0.105, HipW: 0.195,
		UpperArmLen: 0.155, UpperArmR: 0.028, ForeArmLen: 0.135, ForeArmR: 0.022, HandR: 0.030,
		UpperLegLen: 0.230, UpperLegR: 0.044, LowerLegLen: 0.215, LowerLegR: 0.030, FootLen: 0.068,
		SpineCurve: 0.12, SpineCount: 5, K: 0.14, // cong nhiều
	},
}

// ── ANIMALS — MAMMALS ───────────────────────────────────────────────────

var Dog = SpeciesGene{
	ID: "dog_medium", Name: "Chó (trung bình)",
	Category: "mammal", LimbCount: 4, HasTail: true,
	TailLen: 0.18, TailR: 0.018,
	Description: "4 chân, spine dài nằm ngang, tai mềm",
	Props: Proportions{
		HeadR: 0.095, NeckLen: 0.110, NeckR: 0.048,
		ShoulderW: 0.160, ChestD: 0.160, TorsoLen: 0.420, TorsoR: 0.095, HipW: 0.140,
		UpperArmLen: 0.160, UpperArmR: 0.030, ForeArmLen: 0.155, ForeArmR: 0.025, HandR: 0.032,
		UpperLegLen: 0.165, UpperLegR: 0.032, LowerLegLen: 0.150, LowerLegR: 0.024, FootLen: 0.040,
		SpineCurve: 0.0, SpineCount: 7, K: 0.13,
	},
}

var Cat = SpeciesGene{
	ID: "cat", Name: "Mèo",
	Category: "mammal", LimbCount: 4, HasTail: true,
	TailLen: 0.32, TailR: 0.016,
	Description: "Spine cực linh hoạt, tai nhọn, đuôi dài",
	Props: Proportions{
		HeadR: 0.085, NeckLen: 0.090, NeckR: 0.035,
		ShoulderW: 0.120, ChestD: 0.110, TorsoLen: 0.380, TorsoR: 0.072, HipW: 0.115,
		UpperArmLen: 0.130, UpperArmR: 0.022, ForeArmLen: 0.120, ForeArmR: 0.018, HandR: 0.022,
		UpperLegLen: 0.140, UpperLegR: 0.024, LowerLegLen: 0.130, LowerLegR: 0.018, FootLen: 0.032,
		SpineCurve: 0.0, SpineCount: 9, K: 0.11, // linh hoạt nhất
	},
}

var Horse = SpeciesGene{
	ID: "horse", Name: "Ngựa",
	Category: "mammal", LimbCount: 4, HasTail: true,
	TailLen: 0.35, TailR: 0.030,
	Description: "To lớn, cổ dài, chân dài thanh mảnh",
	Props: Proportions{
		HeadR: 0.095, NeckLen: 0.280, NeckR: 0.065,
		ShoulderW: 0.220, ChestD: 0.240, TorsoLen: 0.520, TorsoR: 0.140, HipW: 0.200,
		UpperArmLen: 0.240, UpperArmR: 0.038, ForeArmLen: 0.260, ForeArmR: 0.028, HandR: 0.025,
		UpperLegLen: 0.250, UpperLegR: 0.040, LowerLegLen: 0.270, LowerLegR: 0.026, FootLen: 0.035,
		SpineCurve: 0.0, SpineCount: 8, K: 0.10,
	},
}

// ── ANIMALS — BIRDS ─────────────────────────────────────────────────────

var Bird = SpeciesGene{
	ID: "bird_small", Name: "Chim nhỏ",
	Category: "bird", LimbCount: 2, HasWings: true, HasTail: true,
	TailLen: 0.12, TailR: 0.015,
	Description: "Cánh = modified arms, 2 chân, mỏ",
	Props: Proportions{
		HeadR: 0.095, NeckLen: 0.060, NeckR: 0.025,
		ShoulderW: 0.180, ChestD: 0.140, TorsoLen: 0.200, TorsoR: 0.085, HipW: 0.100,
		// Wings (dùng arm slots)
		UpperArmLen: 0.200, UpperArmR: 0.018, ForeArmLen: 0.180, ForeArmR: 0.012, HandR: 0.030,
		// Chân chim ngắn
		UpperLegLen: 0.090, UpperLegR: 0.018, LowerLegLen: 0.110, LowerLegR: 0.012, FootLen: 0.045,
		SpineCurve: 0.0, SpineCount: 4, K: 0.10,
	},
}

// ── ANIMALS — REPTILE ───────────────────────────────────────────────────

var Snake = SpeciesGene{
	ID: "snake", Name: "Rắn",
	Category: "reptile", LimbCount: 0, HasTail: true,
	TailLen: 0.70, TailR: 0.025,
	Description: "Không có chân, toàn thân = spline + capsules",
	Props: Proportions{
		HeadR: 0.055, NeckLen: 0.0, NeckR: 0.0,
		// Không có limbs
		TorsoLen: 1.0, TorsoR: 0.028,
		SpineCurve: 0.0, SpineCount: 30, // nhiều đốt → uốn lượn
		K: 0.08,
	},
}

// ── ANIMALS — FISH ──────────────────────────────────────────────────────

var Fish = SpeciesGene{
	ID: "fish", Name: "Cá",
	Category: "fish", LimbCount: 0, HasTail: true,
	TailLen: 0.30, TailR: 0.040,
	Description: "Thân hình thoi, vây = modified limbs, đuôi dẹt",
	Props: Proportions{
		HeadR: 0.085, NeckLen: 0.0, NeckR: 0.0,
		ShoulderW: 0.120, ChestD: 0.080, TorsoLen: 0.480, TorsoR: 0.065, HipW: 0.060,
		// Vây (fins)
		UpperArmLen: 0.090, UpperArmR: 0.008, ForeArmLen: 0.070, ForeArmR: 0.006,
		SpineCurve: 0.0, SpineCount: 15, K: 0.09,
	},
}

// ─── CreatureGeneRegistry ─────────────────────────────────────────────────

// AllSpecies kho tất cả loài
var AllSpecies = []SpeciesGene{
	// Human
	HumanAdultMale, HumanAdultFemale,
	HumanChild6, HumanToddler, HumanElderly,
	// Mammals
	Dog, Cat, Horse,
	// Birds
	Bird,
	// Reptiles
	Snake,
	// Fish
	Fish,
}

// FindSpecies tìm species theo ID
func FindSpecies(id string) *SpeciesGene {
	for i := range AllSpecies {
		if AllSpecies[i].ID == id { return &AllSpecies[i] }
	}
	return nil
}

// SimilarSpecies tìm loài tương đồng (QT5)
// Dựa vào category + proportions distance
func SimilarSpecies(id string, n int) []SpeciesGene {
	src := FindSpecies(id)
	if src == nil { return nil }

	type scored struct {
		g     SpeciesGene
		score float64
	}
	var scored_list []scored

	for _, g := range AllSpecies {
		if g.ID == id { continue }

		// Category match = gần hơn
		catBonus := 0.0
		if g.Category == src.Category { catBonus = 0.5 }

		// LimbCount match
		limbBonus := 0.0
		if g.LimbCount == src.LimbCount { limbBonus = 0.3 }

		// Proportion distance
		p1, p2 := src.Props, g.Props
		propDist := math.Abs(p1.HeadR-p2.HeadR) +
			math.Abs(p1.TorsoLen-p2.TorsoLen) +
			math.Abs(p1.HipW-p2.HipW)

		score := catBonus + limbBonus - propDist
		scored_list = append(scored_list, scored{g, score})
	}

	// Sort descending
	for i := 0; i < len(scored_list)-1; i++ {
		for j := i+1; j < len(scored_list); j++ {
			if scored_list[j].score > scored_list[i].score {
				scored_list[i], scored_list[j] = scored_list[j], scored_list[i]
			}
		}
	}

	result := make([]SpeciesGene, 0, n)
	for i := 0; i < n && i < len(scored_list); i++ {
		result = append(result, scored_list[i].g)
	}
	return result
}

// HeightScale tính scale thực tế từ chiều cao (cm)
func (g *SpeciesGene) HeightScale(heightCM float64) float64 {
	return heightCM / 170.0 // normalized to adult human
}
