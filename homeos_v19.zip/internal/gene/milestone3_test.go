package gene

import (
	"fmt"
	"testing"
	"time"
)

func TestMilestone3Vision(t *testing.T) {
	t.Log("═══════════════════════════════════════════════")
	t.Log("MILESTONE 3 — Thị giác nâng cao")
	t.Log("Quadtree · FovealVision · MultiPersonTracker")
	t.Log("═══════════════════════════════════════════════")

	// ── 1. Quadtree ──────────────────────────────────
	t.Log("\n[1] Quadtree spatial index")
	qt := NewQuadtree(Rect{0, 0, 1, 1})
	points := [][2]float64{
		{0.1, 0.2}, {0.5, 0.5}, {0.8, 0.9},
		{0.15, 0.25}, {0.51, 0.49}, {0.3, 0.7},
	}
	for i, p := range points {
		qt.Insert(QPoint{X: p[0], Y: p[1], Data: fmt.Sprintf("obj%d", i)})
	}
	// Query vùng trung tâm
	found := qt.Query(Rect{0.4, 0.4, 0.2, 0.2})
	t.Logf("  Query(0.4,0.4,w=0.2): %d points", len(found))
	if len(found) == 0 {
		t.Error("  Quadtree query failed")
	}
	// Nearest
	near := qt.Nearest(0.5, 0.5)
	t.Logf("  Nearest(0.5,0.5): (%.2f,%.2f) data=%v", near.X, near.Y, near.Data)

	// ── 2. FovealVision ───────────────────────────────
	t.Log("\n[2] FovealVision — attention zones")
	fv := NewFovealVision()
	skeletons := []*SDFSkeleton{
		{ID: "sk1", CX: 0.5, CY: 0.5},  // fovea
		{ID: "sk2", CX: 0.3, CY: 0.3},  // parafovea
		{ID: "sk3", CX: 0.9, CY: 0.9},  // periphery
	}
	targets := fv.Update(skeletons)
	for _, tgt := range targets {
		zoneName := []string{"Fovea", "Parafovea", "Periphery"}[tgt.Zone]
		t.Logf("  %s → zone=%-10s conf=%.2f priority=%d",
			tgt.SkeletonID, zoneName, tgt.Confidence, tgt.Priority)
	}
	if len(targets) != 3 {
		t.Errorf("  want 3 targets, got %d", len(targets))
	}
	// Priority sorted
	if targets[0].Priority < targets[1].Priority {
		t.Error("  targets not sorted by priority")
	}
	t.Logf("  Fovea center: (%.2f,%.2f)", fv.CenterX, fv.CenterY)

	// ── 3. MultiPersonTracker ─────────────────────────
	t.Log("\n[3] MultiPersonTracker — track nhiều người")
	tracker := NewMultiPersonTracker()

	// Frame 1: 3 người
	sks1 := []*SDFSkeleton{
		{CX: 0.2, CY: 0.5},
		{CX: 0.5, CY: 0.5},
		{CX: 0.8, CY: 0.5},
	}
	persons := tracker.Update(sks1, nil)
	t.Logf("  Frame 1: %d persons detected", len(persons))
	for _, p := range persons {
		t.Logf("    %s conf=%.2f pos=(%.2f,%.2f)", p.ID, p.Confidence, p.Skeleton.CX, p.Skeleton.CY)
	}

	// Frame 2: cùng 3 người, dịch nhẹ
	sks2 := []*SDFSkeleton{
		{CX: 0.22, CY: 0.51},
		{CX: 0.52, CY: 0.50},
		{CX: 0.79, CY: 0.49},
	}
	persons2 := tracker.Update(sks2, nil)
	t.Logf("  Frame 2: %d persons (same IDs?)", len(persons2))
	for _, p := range persons2 {
		t.Logf("    %s frames=%d vx=%.3f vy=%.3f",
			p.ID, p.FrameCount, p.VX, p.VY)
	}
	// Phải match được — cùng ID
	if len(persons2) != 3 {
		t.Errorf("  want 3 persons, got %d", len(persons2))
	}
	for _, p := range persons2 {
		if p.FrameCount < 2 {
			t.Errorf("  %s should have FrameCount>=2, got %d", p.ID, p.FrameCount)
		}
	}

	// Frame 3: 1 người rời đi
	sks3 := []*SDFSkeleton{
		{CX: 0.24, CY: 0.52},
		{CX: 0.54, CY: 0.50},
	}
	persons3 := tracker.Update(sks3, nil)
	t.Logf("  Frame 3: %d active (1 left — tracked for 2s)", len(persons3))

	// Simulate timeout
	time.Sleep(1 * time.Millisecond)
	t.Logf("  Fovea center after tracking: %s",
		func() string { x, y := tracker.FovealCenter(); return fmt.Sprintf("%.2f,%.2f", x, y) }())

	t.Log("\n✓ MILESTONE 3 PASS — Quadtree + FovealVision + MultiPersonTracker")
}
