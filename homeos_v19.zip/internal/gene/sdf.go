// internal/gene/sdf.go
// SDF — Signed Distance Functions
// Đây là "vật lý học" của HomeOS — mọi thứ là hàm khoảng cách
// d < 0 = bên trong · d = 0 = bề mặt · d > 0 = bên ngoài
//
// opTable mapping (để dùng trong Olang):
//   '●' → SDFSphere
//   '⌀' → SDFCapsule
//   '□' → SDFBox
//   '◌' → SDFVoid
//   '∪' → SmoothUnion
//   '∖' → SmoothSub
//   '∇' → SurfaceNormal
//   '·' → Vec3.Dot  (built-in)
//   '☀' → SunLight
//   '👁' → RayMarch

package gene

import "math"

// ─────────────────────────────────────────────────────────────────
// SDF PRIMITIVES
// ─────────────────────────────────────────────────────────────────

// SDFSphere — '●'
// Khoảng cách từ p đến mặt cầu tâm c bán kính r
func SDFSphere(p, c Vec3, r float64) float64 {
	return Dist(p, c) - r
}

// SDFCapsule — '⌀'
// Khoảng cách từ p đến viên nang từ a đến b bán kính r
func SDFCapsule(p, a, b Vec3, r float64) float64 {
	ab := b.Sub(a)
	ap := p.Sub(a)
	h := math.Max(0, math.Min(1, ap.Dot(ab)/ab.Dot(ab)))
	return Dist(p, a.Add(ab.Scale(h))) - r
}

// SDFBox — '□'
// Khoảng cách từ p đến hộp axis-aligned tâm gốc tọa độ kích thước b
func SDFBox(p, b Vec3) float64 {
	q := p.Abs().Sub(b)
	return q.Max(V0).Len() + math.Min(q.MaxComp(), 0)
}

// SDFTorus — hình xuyến tâm gốc, bán kính lớn R, bán kính nhỏ r
func SDFTorus(p Vec3, R, r float64) float64 {
	q := Vec3{math.Hypot(p.X, p.Z) - R, p.Y, 0}
	return q.Len() - r
}

// SDFVoid — '◌' — khoảng trống = tiềm năng = vô cực
func SDFVoid() float64 { return math.Inf(1) }

// ─────────────────────────────────────────────────────────────────
// SDF OPERATIONS
// ─────────────────────────────────────────────────────────────────

// SmoothUnion — '∪' — hòa tan 2 SDF, k là hệ số blend
// k = 0 → union cứng (không blend)
// k = 0.3 → blend mịn
func SmoothUnion(d1, d2, k float64) float64 {
	if k < 1e-9 {
		return math.Min(d1, d2)
	}
	h := math.Max(k-math.Abs(d1-d2), 0) / k
	return math.Min(d1, d2) - h*h*k*0.25
}

// SmoothSub — '∖' — đục lỗ d2 khỏi d1
func SmoothSub(d1, d2, k float64) float64 {
	if k < 1e-9 {
		return math.Max(d1, -d2)
	}
	h := math.Max(k-math.Abs(-d2-d1), 0) / k
	return math.Max(d1, -d2) + h*h*k*0.25
}

// HardUnion — '⊕' — union cứng không blend
func HardUnion(d1, d2 float64) float64 { return math.Min(d1, d2) }

// ─────────────────────────────────────────────────────────────────
// LIGHTING & NORMAL
// ─────────────────────────────────────────────────────────────────

// LightInfo kết quả của SunLight(t)
type LightInfo struct {
	Dir       Vec3    // hướng ánh sáng (từ bề mặt đến nguồn)
	Intensity float64 // cường độ [0..1]
	Ambient   float64 // ánh sáng môi trường
}

// SunLight — '☀' — ánh sáng mặt trời theo giờ t ∈ [0,24]
// Quỹ đạo spline: mặt trời mọc lúc 6h, lặn lúc 18h
func SunLight(t float64) LightInfo {
	a := (t - 6) / 24 * 2 * math.Pi
	lx := -math.Cos(a) * 0.6
	ly := math.Sin(a)*0.5 + 0.5
	lz := -0.4
	dir := Vec3{lx, ly, lz}.Norm()
	intensity := math.Max(0, math.Sin((t-6)/12*math.Pi))
	return LightInfo{Dir: dir, Intensity: intensity, Ambient: 0.25}
}

// SurfaceNormal — '∇' — pháp tuyến bề mặt SDF tại điểm p
// Dùng finite difference gradient: ∇f(p) = normalize([∂f/∂x, ∂f/∂y, ∂f/∂z])
func SurfaceNormal(p Vec3, sdf func(Vec3) float64, eps float64) Vec3 {
	e := eps
	nx := sdf(Vec3{p.X + e, p.Y, p.Z}) - sdf(Vec3{p.X - e, p.Y, p.Z})
	ny := sdf(Vec3{p.X, p.Y + e, p.Z}) - sdf(Vec3{p.X, p.Y - e, p.Z})
	nz := sdf(Vec3{p.X, p.Y, p.Z + e}) - sdf(Vec3{p.X, p.Y, p.Z - e})
	return Vec3{nx, ny, nz}.Norm()
}

// Shade tính ánh sáng Lambertian: diffuse = max(0, normal · lightDir)
func Shade(normal Vec3, light LightInfo) float64 {
	diffuse := math.Max(0, normal.Dot(light.Dir))
	return light.Ambient + diffuse*light.Intensity
}

// ─────────────────────────────────────────────────────────────────
// RAY MARCHING — '👁' — 256 bước sphere-trace
// ─────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────
// vSDF EVALUATOR — evaluate SDF primitives trực tiếp
// KHÔNG march rays — chỉ evaluate tại điểm cho trước
//
// HomeOS dùng vSDF để:
//   1. Kiểm tra quan hệ không gian: p ∈ node? SDF(p) < 0
//   2. Tìm node gần nhất: argmin SDF(p) qua NodeRegistry
//   3. Tính normal tại bề mặt: SurfaceNormal(p, sdf, ε)
//   4. ISL routing: SDF value → ISL edge weight
// ─────────────────────────────────────────────────────────────────

// SDFResult — kết quả evaluate 1 node tại điểm p
type SDFResult struct {
	Addr   uint64  // ISLAddr của node
	Dist   float64 // khoảng cách có dấu
	Inside bool    // Dist < 0
	Normal Vec3    // pháp tuyến (chỉ tính khi cần)
}

// vSDFEval evaluate 1 hàm SDF tại p, trả về SDFResult
// addr: ISLAddr của node (để gắn vào kết quả)
func vSDFEval(addr uint64, p Vec3, sdf func(Vec3) float64) SDFResult {
	d := sdf(p)
	return SDFResult{
		Addr:   addr,
		Dist:   d,
		Inside: d < 0,
	}
}

// vSDFEvalWithNormal — như vSDFEval nhưng tính thêm pháp tuyến
// Dùng khi cần xác định hướng bề mặt (lighting, collision response)
func vSDFEvalWithNormal(addr uint64, p Vec3, sdf func(Vec3) float64, eps float64) SDFResult {
	d := sdf(p)
	n := SurfaceNormal(p, sdf, eps)
	return SDFResult{
		Addr:   addr,
		Dist:   d,
		Inside: d < 0,
		Normal: n,
	}
}

// vSDFNearest tìm node gần nhất trong danh sách
func vSDFNearest(nodes []SDFResult) SDFResult {
	if len(nodes) == 0 {
		return SDFResult{Dist: 1e18}
	}
	best := nodes[0]
	for _, r := range nodes[1:] {
		if r.Dist < best.Dist {
			best = r
		}
	}
	return best
}

// SDFNearest tìm node gần nhất trong danh sách (exported)
func SDFNearest(nodes []SDFResult) SDFResult {
	return vSDFNearest(nodes)
}
func vSDFContains(p Vec3, sdf func(Vec3) float64) bool {
	return sdf(p) < 0
}

// vSDFDistance khoảng cách từ p đến bề mặt (luôn dương)
func vSDFDistance(p Vec3, sdf func(Vec3) float64) float64 {
	d := sdf(p)
	if d < 0 { return -d }
	return d
}

// ─────────────────────────────────────────────────────────────────
// FBM TERRAIN — '∫' — fractal Brownian motion
// ─────────────────────────────────────────────────────────────────

// FBM tính chiều cao terrain tại (x,z) với oct octaves
func FBM(x, z float64, oct int, seed float64) float64 {
	v, amp, freq := 0.0, 0.5, 1.0
	for i := 0; i < oct; i++ {
		nx := x*0.08*freq + seed
		nz := z*0.08*freq + seed
		ix, iz := math.Floor(nx), math.Floor(nz)
		fx, fz := nx-ix, nz-iz
		ux := fx * fx * (3 - 2*fx)
		uz := fz * fz * (3 - 2*fz)
		h := func(a, b float64) float64 {
			s := math.Sin(a*127.1+b*311.7+seed*419.3) * 43758.5453
			return s - math.Floor(s)
		}
		v += (h(ix, iz) + (h(ix+1, iz)-h(ix, iz))*ux +
			(h(ix, iz+1)-h(ix, iz))*uz +
			(h(ix+1, iz+1)-h(ix+1, iz)-h(ix, iz+1)+h(ix, iz))*ux*uz) * amp
		amp *= 0.5
		freq *= 2.1
	}
	return v
}
