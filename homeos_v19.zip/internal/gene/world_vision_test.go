package gene

import (
	"fmt"
	"testing"
)

func TestWorldVision(t *testing.T) {
	ws := NewWorldScene()
	ws.Clock.HourOfDay = 12.0 // giữa trưa

	nodes := ws.SpatialNodes()
	t.Logf("WorldScene có %d SpatialNodes", len(nodes))
	for _, n := range nodes {
		t.Logf("  %016x  %s", n.Addr, n.Label)
	}

	// Probe tại gốc (surface Earth)
	p := Vec3{X: 0, Y: 12.5, Z: 0} // vừa ngoài Earth
	nearest, all := EvalAt(p, nodes)
	t.Logf("\nProbe tại (0, 12.5, 0):")
	for _, r := range all {
		t.Logf("  %016x  dist=%.3f  inside=%v", r.Addr, r.Dist, r.Inside)
	}
	t.Logf("  → nearest: %016x  dist=%.3f", nearest.Addr, nearest.Dist)

	// Probe bên trong Earth
	p2 := Vec3{X: 0, Y: 5, Z: 0}
	n2, _ := EvalAt(p2, nodes)
	t.Logf("\nProbe tại (0, 5, 0) trong Earth:")
	t.Logf("  nearest: %016x  dist=%.3f  inside=%v", n2.Addr, n2.Dist, n2.Inside)
	if !n2.Inside {
		t.Error("Điểm (0,5,0) phải nằm trong Earth (r=12)")
	}

	// ProbeRing quanh Earth
	ring := ProbeRing(Vec3{}, 13.0, 8)
	t.Logf("\nProbeRing r=13 (8 điểm quanh Earth):")
	hitCount := 0
	for _, p := range ring {
		r, _ := EvalAt(p, nodes)
		if r.Inside { hitCount++ }
	}
	t.Logf("  %d/8 điểm nằm trong thực thể", hitCount)

	// ProbeGrid 3x3x3 quanh gốc
	grid := ProbeGrid(Vec3{}, 5.0, 3)
	t.Logf("\nProbeGrid 3x3x3 step=5 (%d điểm):", len(grid))
	insideCount := 0
	for _, p := range grid {
		r, _ := EvalAt(p, nodes)
		if r.Inside { insideCount++ }
	}
	t.Logf("  %d/%d điểm nằm trong thực thể", insideCount, len(grid))

	// ISLAddr của nearest = ISL_Earth?
	if nearest.Addr == uint64(ISL_Earth) {
		t.Logf("\n✓ Nearest tại bề mặt Earth = ISL_Earth (%016x)", nearest.Addr)
	} else {
		t.Logf("\nNearest: %016x (ISL_Earth=%016x)", nearest.Addr, uint64(ISL_Earth))
	}

	fmt.Println("vSDF WorldVision: không march rays ✓")
}

