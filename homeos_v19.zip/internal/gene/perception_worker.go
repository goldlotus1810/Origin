// internal/gene/perception_worker.go
//
// PerceptionWorker — Worker agent quan sát camera + mic
//
// KIẾN TRÚC (bất biến):
//   Worker SILENT BY DEFAULT
//   Chỉ gửi khi có DELTA (thay đổi thật sự)
//   Worker → Chief → AAM  (không bao giờ Worker → AAM trực tiếp)
//
// Nguyên tắc:
//   - Quan sát liên tục (FovealVision + Audio)
//   - So sánh với state trước
//   - Nếu KHÁC đủ lớn → gửi PerceptionEvent lên Chief
//   - Không lưu frame, không lưu audio raw
//   - Chỉ lưu: action, space, confidence, timestamp

package gene

import (
	"fmt"
	"time"
)

// ─── PerceptionEvent — tin nhắn duy nhất Worker gửi lên Chief ─────────────

type PerceptionEvent struct {
	// ISL routing
	FromWorker string    // "perception_kitchen"
	ToChief    string    // "home_chief"
	At         time.Time

	// Delta — cái GÌ thay đổi
	DeltaType  DeltaType
	OldAction  ActionVerb
	NewAction  ActionVerb
	OldSpace   SpaceType
	NewSpace   SpaceType
	Confidence float64

	// Context
	Species  string
	ISLAddr  string
	Evidence []string
}

type DeltaType string

const (
	DeltaActionChanged  DeltaType = "action_changed"   // cooking → sleeping
	DeltaSpaceChanged   DeltaType = "space_changed"    // kitchen → bedroom
	DeltaPersonEntered  DeltaType = "person_entered"   // phòng trước empty
	DeltaPersonLeft     DeltaType = "person_left"      // phòng giờ empty
	DeltaAnimalDetected DeltaType = "animal_detected"  // chó/mèo xuất hiện
	DeltaUrgent         DeltaType = "urgent"           // ngã, bất động bất thường
)

func (e *PerceptionEvent) String() string {
	switch e.DeltaType {
	case DeltaActionChanged:
		return fmt.Sprintf("[%s] %s: %s→%s (%.0f%%)",
			e.ISLAddr, e.Species, e.OldAction, e.NewAction, e.Confidence*100)
	case DeltaPersonEntered:
		return fmt.Sprintf("[%s] %s entered: %s (%.0f%%)",
			e.ISLAddr, e.Species, e.NewAction, e.Confidence*100)
	case DeltaPersonLeft:
		return fmt.Sprintf("[%s] %s left", e.ISLAddr, e.Species)
	case DeltaSpaceChanged:
		return fmt.Sprintf("[%s→%s] %s moved", e.OldSpace, e.NewSpace, e.Species)
	case DeltaAnimalDetected:
		return fmt.Sprintf("[%s] animal: %s doing %s", e.ISLAddr, e.Species, e.NewAction)
	case DeltaUrgent:
		return fmt.Sprintf("🚨 [%s] URGENT: %s — %v", e.ISLAddr, e.Species, e.Evidence)
	}
	return fmt.Sprintf("[%s] %s", e.DeltaType, e.ISLAddr)
}

// ─── PerceptionWorker — quan sát 1 không gian ────────────────────────────

type PerceptionWorker struct {
	ID      string    // "perception_kitchen"
	Space   SpaceType
	Chief   string    // "home_chief"

	// State hiện tại (chỉ lưu kết quả, không lưu raw)
	current map[string]*trackedEntity // species → state

	// Thresholds
	ActionChangeTh  float64 // confidence cần để báo thay đổi action
	SilenceTimeout  time.Duration // bao lâu không thấy → "left"

	// Output channel (→ Chief)
	Events chan *PerceptionEvent

	// Internal
	ar *ActionRecognizer
}

type trackedEntity struct {
	Species    string
	Action     ActionVerb
	ActionConf float64
	Space      SpaceType
	LastSeen   time.Time
	StillSince time.Time  // để detect ngã/bất động
}

func NewPerceptionWorker(id string, space SpaceType, chief string) *PerceptionWorker {
	return &PerceptionWorker{
		ID:             id,
		Space:          space,
		Chief:          chief,
		current:        make(map[string]*trackedEntity),
		ActionChangeTh: 0.60,
		SilenceTimeout: 5 * time.Minute,
		Events:         make(chan *PerceptionEvent, 16),
		ar:             NewActionRecognizer(),
	}
}

// Observe nhận kết quả từ vision+audio pipeline
// Gọi mỗi frame — nhưng chỉ emit event khi có DELTA
func (pw *PerceptionWorker) Observe(
	scene *SceneUnderstanding,
	species string,
	now time.Time,
) {
	if scene == nil || scene.ActionConf < pw.ActionChangeTh {
		return // confidence thấp → bỏ qua
	}

	prev, exists := pw.current[species]

	// ── CASE 1: Chưa thấy ai → người vừa vào ────────────────────
	if !exists {
		pw.current[species] = &trackedEntity{
			Species:    species,
			Action:     scene.Action,
			ActionConf: scene.ActionConf,
			Space:      scene.Space,
			LastSeen:   now,
			StillSince: now,
		}

		deltaType := DeltaPersonEntered
		if !isHuman(species) {
			deltaType = DeltaAnimalDetected
		}

		pw.emit(&PerceptionEvent{
			FromWorker: pw.ID,
			ToChief:    pw.Chief,
			At:         now,
			DeltaType:  deltaType,
			NewAction:  scene.Action,
			NewSpace:   scene.Space,
			Confidence: scene.ActionConf,
			Species:    species,
			ISLAddr:    scene.ISLAddr,
			Evidence:   scene.Evidence,
		})
		return
	}

	// Update last seen
	prev.LastSeen = now

	// ── CASE 2: Action thay đổi ──────────────────────────────────
	if prev.Action != scene.Action && scene.ActionConf >= pw.ActionChangeTh {
		oldAction := prev.Action
		prev.Action = scene.Action
		prev.ActionConf = scene.ActionConf

		// Reset still tracker khi có chuyển động mới
		if scene.Action != ActionSleeping && scene.Action != ActionSitting {
			prev.StillSince = now
		}

		pw.emit(&PerceptionEvent{
			FromWorker: pw.ID,
			ToChief:    pw.Chief,
			At:         now,
			DeltaType:  DeltaActionChanged,
			OldAction:  oldAction,
			NewAction:  scene.Action,
			NewSpace:   scene.Space,
			Confidence: scene.ActionConf,
			Species:    species,
			ISLAddr:    scene.ISLAddr,
			Evidence:   scene.Evidence,
		})
		return
	}

	// ── CASE 3: Bất động quá lâu trong context bất thường ────────
	// Người không ngủ mà bất động > 10 phút → urgent
	stillDur := now.Sub(prev.StillSince)
	stillOK := prev.Action == ActionSleeping ||
		prev.Action == ActionSitting ||
		prev.Action == ActionTyping ||
		prev.Action == ActionCooking ||
		prev.Action == ActionCleaning ||
		prev.Action == ActionDancing
	if isHuman(species) && !stillOK && stillDur > 10*time.Minute {

		pw.emit(&PerceptionEvent{
			FromWorker: pw.ID,
			ToChief:    pw.Chief,
			At:         now,
			DeltaType:  DeltaUrgent,
			NewAction:  prev.Action,
			NewSpace:   scene.Space,
			Confidence: scene.ActionConf,
			Species:    species,
			ISLAddr:    scene.ISLAddr,
			Evidence:   []string{fmt.Sprintf("bất động %.0f phút", stillDur.Minutes())},
		})
		prev.StillSince = now // reset để không spam
	}
}

// CheckTimeout kiểm tra ai đã rời phòng (không còn thấy)
func (pw *PerceptionWorker) CheckTimeout(now time.Time) {
	for species, e := range pw.current {
		if now.Sub(e.LastSeen) > pw.SilenceTimeout {
			delete(pw.current, species)
			pw.emit(&PerceptionEvent{
				FromWorker: pw.ID,
				ToChief:    pw.Chief,
				At:         now,
				DeltaType:  DeltaPersonLeft,
				OldAction:  e.Action,
				OldSpace:   e.Space,
				Species:    species,
				ISLAddr:    e.Space.ISLAddr(),
			})
		}
	}
}

func (pw *PerceptionWorker) emit(e *PerceptionEvent) {
	select {
	case pw.Events <- e:
	default: // channel full → drop (không block)
	}
}

func isHuman(species string) bool {
	return len(species) >= 5 && species[:5] == "human"
}

// ─── PerceptionChief — nhận events từ Workers, route lên AAM ────────────

type PerceptionChief struct {
	ID      string
	Workers map[string]*PerceptionWorker
	ToAAM   chan *PerceptionEvent

	// Context state (Chief aggregate)
	ctx *ContextState
}

func NewPerceptionChief(id string) *PerceptionChief {
	return &PerceptionChief{
		ID:      id,
		Workers: make(map[string]*PerceptionWorker),
		ToAAM:   make(chan *PerceptionEvent, 32),
		ctx:     NewContextState(),
	}
}

func (pc *PerceptionChief) AddWorker(w *PerceptionWorker) {
	pc.Workers[w.ID] = w
}

// Route nhận event từ worker, update context, quyết định có báo AAM không
func (pc *PerceptionChief) Route(e *PerceptionEvent) {
	// Update context state
	scene := &SceneUnderstanding{
		Action:     e.NewAction,
		ActionConf: e.Confidence,
		Space:      e.NewSpace,
		ISLAddr:    e.ISLAddr,
	}
	if e.NewSpace == "" { scene.Space = e.OldSpace }

	pc.ctx.Update(scene, e.Species, e.At)

	// Tất cả events đều lên AAM (Chief đã filter — chỉ có delta mới đến đây)
	select {
	case pc.ToAAM <- e:
	default:
	}
}

// Drain xử lý tất cả pending events từ workers
func (pc *PerceptionChief) Drain() {
	for _, w := range pc.Workers {
		for {
			select {
			case e := <-w.Events:
				pc.Route(e)
			default:
				break
			}
			// non-blocking: thoát nếu channel trống
			if len(w.Events) == 0 {
				break
			}
		}
	}
}
