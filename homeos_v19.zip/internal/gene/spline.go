// internal/gene/spline.go
// Spline — Catmull-Rom keyframe interpolation
// Mọi chuyển động trong HomeOS = Spline. Không dùng lerp thẳng.
// Mọi sensor = Spline. Không dùng []float64 raw.

package gene

import "math"

// Keyframe là một điểm kiểm soát trong spline
type Keyframe struct {
	T float64 // time trong [0,1], tăng dần
	Vec3      // position
}

// Spline là chuỗi keyframe Catmull-Rom, periodic (lặp lại)
type Spline struct {
	Keys []Keyframe
}

// Eval nội suy vị trí tại thời điểm t (periodic, t có thể > 1)
// Catmull-Rom: smooth C1, đi qua tất cả control points
func (s *Spline) Eval(t float64) Vec3 {
	n := len(s.Keys)
	if n == 0 {
		return V0
	}
	if n == 1 {
		return s.Keys[0].Vec3
	}

	// Periodic: t về [0,1)
	t = math.Mod(t, 1.0)
	if t < 0 {
		t += 1.0
	}

	// Tìm segment
	seg := t * float64(n)
	i := int(seg)
	f := seg - float64(i)

	p0 := s.Keys[(i-1+n)%n].Vec3
	p1 := s.Keys[i%n].Vec3
	p2 := s.Keys[(i+1)%n].Vec3
	p3 := s.Keys[(i+2)%n].Vec3

	return catmullRom(p0, p1, p2, p3, f)
}

// catmullRom nội suy Catmull-Rom giữa p1 và p2
func catmullRom(p0, p1, p2, p3 Vec3, t float64) Vec3 {
	t2, t3 := t*t, t*t*t
	f := func(a, b, c, d float64) float64 {
		return 0.5 * ((-a+3*b-3*c+d)*t3 + (2*a-5*b+4*c-d)*t2 + (-a+c)*t + 2*b)
	}
	return Vec3{
		f(p0.X, p1.X, p2.X, p3.X),
		f(p0.Y, p1.Y, p2.Y, p3.Y),
		f(p0.Z, p1.Z, p2.Z, p3.Z),
	}
}

// ─────────────────────────────────────────────────────────────────
// ORBIT SPLINE — tạo spline orbit tròn quanh base position
// Dùng cho animation nodes trong ISDF renderer
// ─────────────────────────────────────────────────────────────────

// NewOrbitSpline tạo spline orbit hình elipse quanh base
// amp: biên độ orbit (world units)
// phase: offset góc ban đầu (radians) — khác nhau per node
func NewOrbitSpline(base Vec3, amp, phase float64) *Spline {
	keys := make([]Keyframe, 4)
	for k := 0; k < 4; k++ {
		a := phase + float64(k)/4*2*math.Pi
		keys[k] = Keyframe{
			T: float64(k) / 4,
			Vec3: Vec3{
				base.X + amp*math.Cos(a),
				base.Y + amp*0.4*math.Sin(a*1.3+0.5), // sóng dọc nhỏ hơn
				base.Z + amp*math.Sin(a),
			},
		}
	}
	return &Spline{Keys: keys}
}

// ─────────────────────────────────────────────────────────────────
// SCALAR SPLINE — đại lượng vô hướng biến thiên theo thời gian
// Dùng cho: nhiệt độ, bước sóng, cường độ, khối lượng, áp suất...
// Khác Vec3 Spline: chỉ lưu 1 float64, không phải Vec3
// ─────────────────────────────────────────────────────────────────

// ScalarKey là một keyframe vô hướng
type ScalarKey struct {
	T float64 // thời điểm [0..1], tăng dần
	V float64 // giá trị tại T
}

// ScalarSpline là chuỗi keyframe Catmull-Rom vô hướng
// Dùng cho mọi thuộc tính "vô hình nhưng có độ lớn"
type ScalarSpline struct {
	Keys []ScalarKey
	Unit string // đơn vị: "K", "nm", "W/m²", "kg", "Pa", "Hz"...
}

// Eval nội suy giá trị tại t
// Nếu t nằm trong [Keys[0].T, Keys[n-1].T] → nội suy
// Nếu t < Keys[0].T → clamp min
// Nếu t > Keys[n-1].T → clamp max (không periodic)
func (s *ScalarSpline) Eval(t float64) float64 {
	n := len(s.Keys)
	if n == 0 {
		return 0
	}
	if n == 1 {
		return s.Keys[0].V
	}
	// Clamp ngoài biên
	if t <= s.Keys[0].T {
		return s.Keys[0].V
	}
	if t >= s.Keys[n-1].T {
		return s.Keys[n-1].V
	}
	// Tìm segment chứa t
	for i := 0; i < n-1; i++ {
		if t > s.Keys[i+1].T { continue }
		k0, k1 := s.Keys[i], s.Keys[i+1]
		dt := k1.T - k0.T
		if dt < 1e-12 { return k0.V }
		f := (t - k0.T) / dt
		// Hermite cubic smooth
		f2, f3 := f*f, f*f*f
		return (2*f3-3*f2+1)*k0.V + (-2*f3+3*f2)*k1.V
	}
	return s.Keys[n-1].V
}

// Const tạo ScalarSpline hằng số — thuộc tính không đổi theo thời gian
// Ví dụ: khối lượng mặt trời = 1.989e30 kg
func ScalarConst(v float64, unit string) *ScalarSpline {
	return &ScalarSpline{
		Keys: []ScalarKey{{T: 0, V: v}, {T: 0.5, V: v}},
		Unit: unit,
	}
}

// ScalarCycle tạo ScalarSpline dao động sin quanh mean
// Ví dụ: nhiệt độ bề mặt mặt trời = 5778K ± 300K theo chu kỳ 11 năm
func ScalarCycle(mean, amp float64, unit string) *ScalarSpline {
	keys := make([]ScalarKey, 8)
	for i := range keys {
		phase := float64(i) / float64(len(keys))
		keys[i] = ScalarKey{
			T: phase,
			V: mean + amp*math.Sin(phase*2*math.Pi),
		}
	}
	return &ScalarSpline{Keys: keys, Unit: unit}
}

// ScalarDayNight tạo ScalarSpline theo chu kỳ ngày đêm
// Ví dụ: cường độ ánh sáng = 0 lúc nửa đêm, max lúc giữa trưa
func ScalarDayNight(min, max float64, unit string) *ScalarSpline {
	return &ScalarSpline{
		Keys: []ScalarKey{
			{T: 0.00, V: min}, // 00:00 nửa đêm
			{T: 0.25, V: min}, // 06:00 bình minh
			{T: 0.50, V: max}, // 12:00 giữa trưa
			{T: 0.75, V: min}, // 18:00 hoàng hôn
		},
		Unit: unit,
	}
}

// ─────────────────────────────────────────────────────────────────
// PROPERTY — gắn ScalarSpline vào một ISL address
// "node này có thuộc tính X với giá trị biến thiên theo Spline"
// ─────────────────────────────────────────────────────────────────

// Property = 1 cạnh ISL có giá trị Spline
// Thay thế cho SilkEdge đơn thuần khi cạnh mang thông tin định lượng
type Property struct {
	ISL    uint64        // địa chỉ node thuộc tính (từ homeos.olang)
	Spline *ScalarSpline // giá trị biến thiên của thuộc tính đó
}

// Val trả về giá trị hiện tại của thuộc tính tại thời điểm t ∈ [0,1]
func (p *Property) Val(t float64) float64 {
	if p.Spline == nil {
		return 0
	}
	return p.Spline.Eval(t)
}

// ─────────────────────────────────────────────────────────────────
func PhaseFor(id string) float64 {
	if len(id) == 0 {
		return 0
	}
	p := 0.0
	for i, c := range id {
		p += float64(c) * (0.37 + float64(i)*0.13)
	}
	return p
}
