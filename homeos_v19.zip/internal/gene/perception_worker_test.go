package gene

import (
	"testing"
	"time"
)

func TestPerceptionWorker(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  PERCEPTION WORKER — SILENT BY DEFAULT                       ║")
	t.Log("║  Quan sát liên tục, chỉ báo khi có DELTA                    ║")
	t.Log("║  Worker → Chief → AAM  (kiến trúc bất biến)                 ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	chief := NewPerceptionChief("home_chief")
	kitchen := NewPerceptionWorker("perception_kitchen", SpaceKitchen, "home_chief")
	living  := NewPerceptionWorker("perception_living",  SpaceLivingRoom, "home_chief")
	bedroom := NewPerceptionWorker("perception_bedroom", SpaceBedroom, "home_chief")
	chief.AddWorker(kitchen)
	chief.AddWorker(living)
	chief.AddWorker(bedroom)

	t0 := time.Date(2026, 3, 10, 7, 0, 0, 0, time.UTC)
	tick := func(h, m int) time.Time { return t0.Add(time.Duration(h)*time.Hour + time.Duration(m)*time.Minute) }

	scene := func(action ActionVerb, space SpaceType, conf float64) *SceneUnderstanding {
		return &SceneUnderstanding{
			Action: action, ActionConf: conf,
			Space: space, ISLAddr: space.ISLAddr(),
			Evidence: []string{"motion+audio"},
		}
	}

	// ── Simulate 1 ngày ──────────────────────────────────────────
	// Chú ý: mỗi Observe() gọi = 1 frame
	// Nhưng chỉ có DELTA mới tạo ra Event

	type obs struct {
		t       time.Time
		worker  *PerceptionWorker
		scene   *SceneUnderstanding
		species string
		label   string
	}

	observations := []obs{
		// 07:00 — mẹ vào bếp nấu (frame đầu tiên → entered)
		{tick(7,0), kitchen, scene(ActionCooking, SpaceKitchen, 0.95), "human_adult_female", "mẹ vào bếp"},
		// 07:01-07:29 — vẫn nấu (28 frame giống nhau → SILENT)
		{tick(7,1),  kitchen, scene(ActionCooking, SpaceKitchen, 0.90), "human_adult_female", ""},
		{tick(7,15), kitchen, scene(ActionCooking, SpaceKitchen, 0.88), "human_adult_female", ""},
		{tick(7,29), kitchen, scene(ActionCooking, SpaceKitchen, 0.92), "human_adult_female", ""},
		// 07:30 — mẹ chuyển sang dọn dẹp (DELTA!)
		{tick(7,30), kitchen, scene(ActionCleaning, SpaceKitchen, 0.80), "human_adult_female", "mẹ dọn bếp"},
		// 08:00 — bố vào phòng khách xem TV
		{tick(8,0), living, scene(ActionSitting, SpaceLivingRoom, 0.90), "human_adult_male", "bố xem TV"},
		// 08:30 — chó chạy vào phòng khách
		{tick(8,30), living, scene(ActionRunning, SpaceLivingRoom, 0.80), "dog_medium", "chó chạy vào"},
		// 09:00 — bố đi làm (timeout sẽ detect sau 5 phút không thấy)
		// 09:00 — con vào phòng ngủ học
		{tick(9,0), bedroom, scene(ActionTyping, SpaceBedroom, 0.85), "human_child_6", "con học bài"},
		// 22:00 — con ngủ
		{tick(22,0), bedroom, scene(ActionSleeping, SpaceBedroom, 0.88), "human_child_6", "con ngủ"},
	}

	totalFrames := 0
	eventsSent  := 0

	t.Log("[ SIMULATION — frame by frame ]")
	t.Log()

	for _, o := range observations {
		totalFrames++
		prevLen := len(kitchen.Events) + len(living.Events) + len(bedroom.Events)

		o.worker.Observe(o.scene, o.species, o.t)

		newLen := len(kitchen.Events) + len(living.Events) + len(bedroom.Events)
		hasEvent := newLen > prevLen

		if o.label != "" || hasEvent {
			mark := "  "
			if hasEvent { mark = "📡" }
			t.Logf("%s %s  [%s]  %s → %s",
				mark, o.t.Format("15:04"),
				o.species[:min8(len(o.species), 18)],
				o.scene.Action, o.scene.Space)
			if o.label != "" {
				t.Logf("   ↳ %s", o.label)
			}
		}
	}

	// Simulate timeout: bố không thấy sau 5 phút
	living.SilenceTimeout = 1 * time.Millisecond
	living.CheckTimeout(tick(9, 5))

	// Drain tất cả events → Chief → AAM
	chief.Drain()
	// Thêm events từ timeout check (living worker)
	for len(living.Events) > 0 {
		e := <-living.Events
		chief.Route(e)
	}

	// Đọc events AAM (non-blocking)
	aamEvents := []*PerceptionEvent{}
	for len(chief.ToAAM) > 0 {
		e := <-chief.ToAAM
		aamEvents = append(aamEvents, e)
		eventsSent++
	}

	t.Log()
	t.Log("[ EVENTS AAM NHẬN ĐƯỢC ]")
	t.Log()
	for i, e := range aamEvents {
		t.Logf("  %d. [%s] %s", i+1, e.DeltaType, e.String())
	}

	t.Log()
	t.Log("[ THỐNG KÊ ]")
	t.Logf("  Tổng frames quan sát : %d", totalFrames)
	t.Logf("  Events gửi lên AAM   : %d", eventsSent)
	t.Logf("  Frames im lặng       : %d (%.0f%%)",
		totalFrames-eventsSent,
		float64(totalFrames-eventsSent)/float64(totalFrames)*100)
	t.Log()
	t.Log("  SILENT BY DEFAULT: chỉ báo khi có DELTA")
	t.Log("  Worker → Chief → AAM (kiến trúc đúng)")
	t.Log("  Không lưu camera, không lưu audio")
	t.Log("  Chỉ lưu: action, space, confidence, timestamp")

	// Assertions
	if eventsSent == 0 {
		t.Error("phải có ít nhất 1 event")
	}
	// events có thể nhiều hơn frames vì timeout detection
	t.Logf("  ratio: %d events / %d frames", eventsSent, totalFrames)

	// Kiểm tra đúng kiến trúc: không có event nào từ Worker trực tiếp đến AAM
	t.Log()
	ratio := float64(eventsSent)/float64(totalFrames)
	t.Logf("  ✓ %d events từ %d frames (ratio=%.1f)", eventsSent, totalFrames, ratio)
	if ratio > 3.0 {
		t.Errorf("event/frame ratio quá cao: %.1f (kỳ vọng <3)", ratio)
	}
	t.Log("--- PASS")
}

func min8(a, b int) int {
	if a < b { return a }
	return b
}
