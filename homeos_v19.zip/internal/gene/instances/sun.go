// internal/gene/instances/sun.go
// SunGene — mặt trời hoàn chỉnh
//
// Kiến trúc đúng theo insight 2026-03-09:
//   SDF      = hình dạng (cầu)
//   ISL edge = địa chỉ thuộc tính trong homeos.olang
//   Spline   = giá trị biến thiên của thuộc tính đó
//
// Mặt trời = [ISL_sun] với 4 Property:
//   → ISL_temperature : ScalarCycle(5778K ± 300K, chu kỳ 11 năm)
//   → ISL_wavelength  : ScalarConst(550nm, peak visible)
//   → ISL_luminosity  : ScalarDayNight(0..1, chu kỳ ngày)
//   → ISL_orbit       : Spline Vec3 (quỹ đạo trên bầu trời)
//
// DNA() trả về chuỗi ISL thật — không phải ASCII placeholder

package instances

import (
	"fmt"
	"github.com/goldlotus1810/HomeOS/internal/gene"
)

// ISL addresses của các thuộc tính mặt trời
// Lấy từ homeos.olang — đây là primary key thật
// Tạm dùng hằng số cho đến khi có ISL resolver đầy đủ
const (
	// ISL_sun        = node mặt trời trong homeos.olang
	// layer=K(tri thức), group=astro, type=star, id=sun
	ISL_sun         uint64 = 0x4B_03_01_01_00000001

	// ISL_temperature = thuộc tính nhiệt độ
	ISL_temperature uint64 = 0x4B_03_02_01_00000001

	// ISL_wavelength  = thuộc tính bước sóng ánh sáng
	ISL_wavelength  uint64 = 0x4B_03_02_02_00000001

	// ISL_luminosity  = cường độ sáng
	ISL_luminosity  uint64 = 0x4B_03_02_03_00000001

	// ISL_mass        = khối lượng
	ISL_mass        uint64 = 0x4B_03_02_04_00000001

	// ISL_orbit_period = chu kỳ quỹ đạo
	ISL_orbit_period uint64 = 0x4B_03_02_05_00000001
)

// SunGene — mặt trời đầy đủ
// Implements gene.Gene interface
type SunGene struct {
	// SDF — hình dạng
	Center gene.Vec3
	Radius float64     // bán kính (world units, không phải km thật)

	// ISL + Spline — các thuộc tính vô hình
	Props []gene.Property

	// Quỹ đạo trên bầu trời (Vec3 Spline)
	Orbit *gene.Spline

	// Trạng thái hiện tại (sau Animate)
	pos       gene.Vec3
	t_current float64 // world time [0..24]
}

// NewSunGene tạo mặt trời với đầy đủ thuộc tính vật lý
func NewSunGene(center gene.Vec3, radius float64) *SunGene {
	g := &SunGene{
		Center: center,
		Radius: radius,
		pos:    center,
	}

	// 4 thuộc tính vật lý — mỗi cái = ISL address + Spline
	g.Props = []gene.Property{
		{
			ISL: ISL_temperature,
			// 5778K ± 300K, chu kỳ 11 năm (solar cycle)
			Spline: gene.ScalarCycle(5778, 300, "K"),
		},
		{
			ISL: ISL_wavelength,
			// Peak emission ~550nm (ánh sáng vàng lục)
			// Biến thiên nhỏ theo nhiệt độ: Wien's law λ_max = b/T
			Spline: gene.ScalarCycle(550, 10, "nm"),
		},
		{
			ISL: ISL_luminosity,
			// Cường độ sáng: 0 lúc nửa đêm → 1.0 lúc giữa trưa
			Spline: gene.ScalarDayNight(0.0, 1.0, "W/m²_norm"),
		},
		{
			ISL: ISL_mass,
			// Khối lượng hằng số: 1.989e30 kg
			Spline: gene.ScalarConst(1.989e30, "kg"),
		},
	}

	// Quỹ đạo mặt trời trên bầu trời
	// Mọc ở đông (6h), đỉnh ở nam (12h), lặn ở tây (18h)
	g.Orbit = &gene.Spline{
		Keys: []gene.Keyframe{
			{T: 0.00, Vec3: gene.Vec3{X: center.X, Y: center.Y - radius*3, Z: center.Z - radius*8}}, // nửa đêm: dưới chân trời
			{T: 0.25, Vec3: gene.Vec3{X: center.X + radius*8, Y: center.Y + radius*2, Z: center.Z}}, // bình minh: đông
			{T: 0.50, Vec3: gene.Vec3{X: center.X, Y: center.Y + radius*12, Z: center.Z}},           // giữa trưa: đỉnh
			{T: 0.75, Vec3: gene.Vec3{X: center.X - radius*8, Y: center.Y + radius*2, Z: center.Z}}, // hoàng hôn: tây
		},
	}

	return g
}

// ─────────────────────────────────────────────────────────────────
// Gene interface
// ─────────────────────────────────────────────────────────────────

func (g *SunGene) SDF(p gene.Vec3) float64 {
	return gene.SDFSphere(p, g.pos, g.Radius)
}

func (g *SunGene) Normal(p gene.Vec3) gene.Vec3 {
	return gene.SurfaceNormal(p, g.SDF, g.Radius*0.001)
}

// Animate cập nhật vị trí mặt trời theo giờ t ∈ [0..24]
func (g *SunGene) Animate(t float64) {
	g.t_current = t
	// t [0..24] → spline phase [0..1)
	g.pos = g.Orbit.Eval(t / 24.0)
}

// SimpleSDF dùng vị trí base cho LOD xa
func (g *SunGene) SimpleSDF(p gene.Vec3) float64 {
	return gene.SDFSphere(p, g.Center, g.Radius)
}

// DNA trả về chuỗi ISL address thật
// Format: [ISL_sun]→[ISL_temp:Spline][ISL_λ:Spline][ISL_L:Spline][ISL_m:Spline]
// Đây là "câu" đầu tiên trong ngôn ngữ ISL thuần túy
func (g *SunGene) DNA() string {
	// Hiện tại: serialize ISL addresses thành hex string
	// Tương lai: binary stream uint64[]
	dna := fmt.Sprintf("☀[%016X]", ISL_sun)
	for _, p := range g.Props {
		if p.Spline != nil {
			dna += fmt.Sprintf("→[%016X:%s]", p.ISL, p.Spline.Unit)
		}
	}
	return dna
}

// ─────────────────────────────────────────────────────────────────
// Accessor — lấy giá trị thuộc tính tại thời điểm hiện tại
// ─────────────────────────────────────────────────────────────────

// Temperature trả về nhiệt độ hiện tại (K)
func (g *SunGene) Temperature() float64 {
	return g.propVal(ISL_temperature)
}

// Wavelength trả về bước sóng đỉnh hiện tại (nm)
func (g *SunGene) Wavelength() float64 {
	return g.propVal(ISL_wavelength)
}

// Luminosity trả về cường độ sáng hiện tại [0..1]
func (g *SunGene) Luminosity() float64 {
	return g.propVal(ISL_luminosity)
}

// LightInfo tính ánh sáng đầy đủ từ Spline — thay thế SunLight() cứng
func (g *SunGene) LightInfo() gene.LightInfo {
	// Hướng từ điểm gốc đến vị trí mặt trời
	dir := g.pos.Sub(gene.V0).Norm()
	lum := g.Luminosity()
	return gene.LightInfo{
		Dir:       dir,
		Intensity: lum,
		Ambient:   0.15 + lum*0.1, // ambient tăng nhẹ ban ngày
	}
}

// propVal tìm giá trị Spline theo ISL address
func (g *SunGene) propVal(isl uint64) float64 {
	for _, p := range g.Props {
		if p.ISL == isl {
			return p.Val(g.t_current / 24.0)
		}
	}
	return 0
}

// Pos trả về vị trí hiện tại (sau Animate)
func (g *SunGene) Pos() gene.Vec3 { return g.pos }
