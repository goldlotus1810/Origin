// internal/gene/creature.go
// CreatureGene — sinh vật sống theo kiến trúc ISL+SDF+Spline
//
// Sinh vật = SDF hình dạng + Spline chuyển động + ScalarSpline sinh lý
//
//   SDF()        = SDFCapsule (thân) ∪ SDFSphere (đầu)
//   Gait         = Spline Vec3   — chu kỳ bước đi (locomotion)
//   HeartRate    = ScalarSpline  — nhịp tim (bpm), tăng khi vận động
//   BodyTemp     = ScalarSpline  — nhiệt độ cơ thể (K), ~310K người
//   Breath       = ScalarSpline  — nhịp thở (chu kỳ), phồng xẹp ngực
//   Energy       = ScalarSpline  — năng lượng [0..1], giảm theo thời gian

package gene

import "math"

// Species — loài sinh vật, ảnh hưởng hình dạng và sinh lý
type Species byte

const (
	SpeciesHuman  Species = 0x01
	SpeciesDog    Species = 0x02
	SpeciesBird   Species = 0x03
	SpeciesTree   Species = 0x04 // thực vật — không locomotion
)

// CreatureGene = một sinh vật sống
type CreatureGene struct {
	Addr    ISLAddr
	Species Species

	// Hình dạng (SDF)
	pos    Vec3    // vị trí world
	Height float64 // chiều cao
	Width  float64 // bề ngang

	// Chuyển động — Spline Vec3 (chu kỳ bước đi)
	// t ∈ [0,1] = 1 bước hoàn chỉnh
	Gait *Spline

	// Sinh lý — ScalarSpline
	HeartRate *ScalarSpline // ISL = MakeISL(LayerPhysics, GroupFrequency, species, 0x01, 0)
	BodyTemp  *ScalarSpline // K — hằng định sinh nhiệt hoặc biến nhiệt
	Breath    *ScalarSpline // chu kỳ thở [0..1] = thở ra → hít vào
	Energy    *ScalarSpline // [0..1] giảm dần, phục hồi khi nghỉ

	// Trạng thái hành vi
	Activity  float64 // [0..1] — 0=ngủ, 0.5=đi, 1.0=chạy
	stepPhase float64 // pha bước đi hiện tại
}

// NewCreatureGene tạo sinh vật theo loài
func NewCreatureGene(sp Species) *CreatureGene {
	c := &CreatureGene{
		Addr:    MakeISL(LayerWorld, GroupCreature, byte(sp), 0x01, 0),
		Species: sp,
		Activity: 0.5,
	}
	c.Height, c.Width = speciesDimensions(sp)
	c.Gait           = speciesGait(sp)
	c.HeartRate      = speciesHeartRate(sp)
	c.BodyTemp       = speciesBodyTemp(sp)
	c.Breath         = speciesBreath(sp)
	c.Energy         = &ScalarSpline{
		Keys: []ScalarKey{{T: 0, V: 1.0}, {T: 1, V: 1.0}},
		Unit: "",
	}
	c.pos = V0
	return c
}

// ─── Thông số theo loài ───────────────────────────────────────────

func speciesDimensions(sp Species) (height, width float64) {
	switch sp {
	case SpeciesHuman:
		return 1.75, 0.45
	case SpeciesDog:
		return 0.60, 0.25
	case SpeciesBird:
		return 0.20, 0.08
	default:
		return 1.0, 0.3
	}
}

func speciesGait(sp Species) *Spline {
	switch sp {
	case SpeciesHuman:
		// Bước đi người: xoay hông nhẹ, nảy lên xuống
		return &Spline{Keys: []Keyframe{
			{T: 0.00, Vec3: Vec3{0, 0, 0}},
			{T: 0.25, Vec3: Vec3{0.05, 0.03, 0.3}},
			{T: 0.50, Vec3: Vec3{0, 0, 0.6}},
			{T: 0.75, Vec3: Vec3{-0.05, 0.03, 0.9}},
		}}
	case SpeciesDog:
		// Chó: 4 chân, bước nhanh hơn
		return &Spline{Keys: []Keyframe{
			{T: 0.00, Vec3: Vec3{0, 0, 0}},
			{T: 0.25, Vec3: Vec3{0.03, 0.05, 0.4}},
			{T: 0.50, Vec3: Vec3{0, 0, 0.8}},
			{T: 0.75, Vec3: Vec3{-0.03, 0.05, 1.2}},
		}}
	case SpeciesBird:
		// Chim bay: lên xuống theo sải cánh
		return &Spline{Keys: []Keyframe{
			{T: 0.00, Vec3: Vec3{0, 0, 0}},
			{T: 0.25, Vec3: Vec3{0, 0.3, 0.5}},
			{T: 0.50, Vec3: Vec3{0, 0, 1.0}},
			{T: 0.75, Vec3: Vec3{0, -0.1, 1.5}},
		}}
	default:
		return &Spline{Keys: []Keyframe{
			{T: 0, Vec3: V0}, {T: 1, Vec3: V0},
		}}
	}
}

func speciesHeartRate(sp Species) *ScalarSpline {
	// t ∈ [0,1] = activity level
	switch sp {
	case SpeciesHuman:
		// 60 bpm nghỉ → 180 bpm chạy
		return NewScalarSpline("bpm",
			0.0, 60.0,
			0.5, 100.0,
			1.0, 180.0,
		)
	case SpeciesDog:
		// 70-120 bpm nghỉ → 220 bpm chạy
		return NewScalarSpline("bpm",
			0.0, 80.0,
			0.5, 140.0,
			1.0, 220.0,
		)
	case SpeciesBird:
		// 200-400 bpm (tim nhỏ, đập nhanh)
		return NewScalarSpline("bpm",
			0.0, 200.0,
			0.5, 300.0,
			1.0, 400.0,
		)
	default:
		return ScalarConst(70, "bpm")
	}
}

func speciesBodyTemp(sp Species) *ScalarSpline {
	switch sp {
	case SpeciesHuman:
		// 310.15K (37°C) — dao động nhẹ theo hoạt động
		return ScalarCycle(310.15, 0.5, "K")
	case SpeciesDog:
		return ScalarConst(311.65, "K") // 38.5°C
	case SpeciesBird:
		return ScalarConst(314.15, "K") // 41°C
	default:
		return ScalarConst(310.0, "K")
	}
}

func speciesBreath(sp Species) *ScalarSpline {
	// 1 chu kỳ thở = [0..1]: 0=thở ra, 0.5=hít vào đầy, 1=thở ra
	// Tần số thay đổi theo activity
	switch sp {
	case SpeciesHuman:
		// 12 lần/phút nghỉ → 30 lần/phút chạy
		return NewScalarSpline("cycle",
			0.0, 12.0,
			0.5, 20.0,
			1.0, 30.0,
		)
	case SpeciesDog:
		return NewScalarSpline("cycle",
			0.0, 18.0,
			0.5, 25.0,
			1.0, 40.0,
		)
	case SpeciesBird:
		return NewScalarSpline("cycle",
			0.0, 25.0,
			1.0, 60.0,
		)
	default:
		return ScalarConst(15, "cycle")
	}
}

// ─── Gene interface ───────────────────────────────────────────────

func (c *CreatureGene) SDF(p Vec3) float64 {
	// Thân = Capsule + đầu = Sphere
	foot := c.pos
	head := Vec3{c.pos.X, c.pos.Y + c.Height, c.pos.Z}
	neck := Vec3{c.pos.X, c.pos.Y + c.Height*0.85, c.pos.Z}
	torso  := SDFCapsule(p, foot, neck, c.Width*0.5)
	skull  := SDFSphere(p, head, c.Width*0.4)
	return SmoothUnion(torso, skull, 0.1)
}

func (c *CreatureGene) Normal(p Vec3) Vec3 {
	return SurfaceNormal(p, c.SDF, 0.01)
}

// Animate cập nhật vị trí và pha bước theo t (giây world time)
func (c *CreatureGene) Animate(t float64) {
	// Tốc độ bước tỉ lệ với activity
	stepSpeed := c.Activity * 2.0 // bước/giây
	c.stepPhase = math.Mod(t*stepSpeed, 1.0)

	// Vị trí thay đổi theo gait
	offset := c.Gait.Eval(c.stepPhase)
	c.pos = Vec3{
		c.pos.X + offset.X*0.01,
		offset.Y * 0.05, // nảy lên xuống
		c.pos.Z,
	}
}

func (c *CreatureGene) SimpleSDF(p Vec3) float64 {
	center := Vec3{c.pos.X, c.pos.Y + c.Height*0.5, c.pos.Z}
	return SDFSphere(p, center, c.Height*0.5)
}

func (c *CreatureGene) DNA() string {
	return "🧬⌀●~ISL_Creature~ISL_Gait~ISL_HeartRate~ISL_BodyTemp"
}

// ─── Truy vấn sinh lý ────────────────────────────────────────────

// HeartRateAt trả về nhịp tim tại mức hoạt động hiện tại (bpm)
func (c *CreatureGene) HeartRateAt() float64 {
	return c.HeartRate.Eval(c.Activity)
}

// BodyTempAt trả về nhiệt độ cơ thể (K)
func (c *CreatureGene) BodyTempAt(t float64) float64 {
	return c.BodyTemp.Eval(t)
}

// BreathRateAt trả về tần số thở (lần/phút)
func (c *CreatureGene) BreathRateAt() float64 {
	return c.Breath.Eval(c.Activity)
}

// BreathPhase trả về pha thở hiện tại [0..1]
// dùng để animate lồng ngực phồng xẹp
func (c *CreatureGene) BreathPhase(t float64) float64 {
	rate := c.BreathRateAt()           // lần/phút
	period := 60.0 / rate             // giây/lần
	phase := math.Mod(t, period) / period
	return (math.Sin(phase*2*math.Pi) + 1) * 0.5
}

// SetActivity cập nhật mức hoạt động [0..1]
func (c *CreatureGene) SetActivity(a float64) {
	if a < 0 { a = 0 }
	if a > 1 { a = 1 }
	c.Activity = a
}
