package gene

import (
	"fmt"
	"testing"
)

func TestNodeRegistry(t *testing.T) {
	entries := AllEntries()
	t.Logf("Registry: %d nodes đã đăng ký", len(entries))

	// Kiểm tra không xung đột ISLAddr
	seen := map[ISLAddr]string{}
	for _, e := range entries {
		if prev, dup := seen[e.Addr]; dup {
			t.Errorf("XUNG ĐỘT: %s và %s cùng ISLAddr %016x", e.Name, prev, uint64(e.Addr))
		}
		seen[e.Addr] = e.Name
	}
	t.Logf("Không xung đột ISLAddr ✓")

	// Lookup theo name
	tests := []string{
		"SUN", "EARTH", "MOON", "HUMAN", "DOG", "BIRD",
		"OP_SPHERE", "OP_UNION", "SKILL_GATE",
		"AAM", "LEOAI", "HOME_CHIEF",
		"LIGHT_LIVING", "HVAC", "DOOR_LOCK",
		"SUN_TEMP", "EARTH_MASS", "CONST_G",
	}
	t.Log("\nLookup tests:")
	for _, name := range tests {
		addr, ok := Lookup(name)
		if !ok {
			t.Errorf("Không tìm thấy: %s", name)
			continue
		}
		rname, _ := LookupName(addr)
		t.Logf("  %-22s → %016x  layer='%c'  reverse=%s",
			name, uint64(addr), addr.Layer(), rname)
	}

	// Phân bố theo layer
	t.Log("\nPhân bố theo Layer:")
	byLayer := map[byte][]string{}
	for _, e := range entries {
		l := e.Addr.Layer()
		byLayer[l] = append(byLayer[l], e.Name)
	}
	layerNames := map[byte]string{
		LayerWorld: "World(W)", LayerPhysics: "Physics(P)",
		LayerOp: "Op(O)", LayerKnow: "Know(K)",
		LayerAgent: "Agent(A)", LayerSensor: "Sensor(S)",
	}
	for l, names := range byLayer {
		lname := layerNames[l]
		if lname == "" { lname = fmt.Sprintf("0x%02x", l) }
		t.Logf("  %s: %d nodes", lname, len(names))
	}

	// Tất cả không xung đột
	if len(seen) != len(entries) {
		t.Errorf("Số unique addr %d != số entries %d", len(seen), len(entries))
	}
}
