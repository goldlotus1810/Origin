// internal/gene/isl_router.go
// ISLRouter — EvalAt → ISL routing
//
// Luồng:
//   Agent hỏi "probe point này thuộc về ai?"
//   → EvalAt(p, nodes) → nearest.Addr (ISLAddr)
//   → ISLRouter.Route(nearest) → ISLMessage đến đúng agent
//
// Nguyên tắc:
//   SDF value quyết định routing — không hardcode địa chỉ
//   Inside (dist < 0)  → message trực tiếp đến node owner
//   Outside (dist > 0) → message đến node gần nhất
//   Collision (nhiều Inside) → SmoothUnion → node có dist nhỏ nhất

package gene

import "fmt"

// RouteResult — kết quả routing từ SDF evaluation
type RouteResult struct {
	TargetAddr uint64  // ISLAddr của node đích
	Dist       float64 // khoảng cách (âm = trong, dương = ngoài)
	Inside     bool    // probe nằm trong node
	Label      string  // tên node (debug)
	Confident  bool    // true nếu dist < threshold
}

// ISLRouter route probe points đến ISLAddr
type ISLRouter struct {
	Nodes     []SpatialNode
	Threshold float64 // ngưỡng "đủ gần" (dương)
}

// NewISLRouter tạo router với danh sách nodes
func NewISLRouter(nodes []SpatialNode, threshold float64) *ISLRouter {
	return &ISLRouter{Nodes: nodes, Threshold: threshold}
}

// Route evaluate p → trả về RouteResult
// Quy tắc:
//   1. Nếu p nằm trong đúng 1 node → route thẳng
//   2. Nếu p nằm trong nhiều nodes → route đến node có dist nhỏ nhất (sâu nhất)
//   3. Nếu p nằm ngoài tất cả → route đến node gần nhất nếu dist < Threshold
//   4. Nếu xa hơn Threshold → không route (Confident=false)
func (r *ISLRouter) Route(p Vec3) RouteResult {
	nearest, all := EvalAt(p, r.Nodes)

	// Đếm nodes chứa p
	insideNodes := make([]SDFResult, 0, 2)
	for _, res := range all {
		if res.Inside {
			insideNodes = append(insideNodes, res)
		}
	}

	switch len(insideNodes) {
	case 0:
		// Ngoài tất cả — route đến gần nhất nếu đủ gần
		return RouteResult{
			TargetAddr: nearest.Addr,
			Dist:       nearest.Dist,
			Inside:     false,
			Label:      r.labelOf(nearest.Addr),
			Confident:  nearest.Dist < r.Threshold,
		}
	case 1:
		// Trong đúng 1 node — route thẳng
		return RouteResult{
			TargetAddr: insideNodes[0].Addr,
			Dist:       insideNodes[0].Dist,
			Inside:     true,
			Label:      r.labelOf(insideNodes[0].Addr),
			Confident:  true,
		}
	default:
		// Trong nhiều nodes — SmoothUnion logic: route đến sâu nhất (dist nhỏ nhất)
		deepest := insideNodes[0]
		for _, n := range insideNodes[1:] {
			if n.Dist < deepest.Dist { // dist âm: nhỏ hơn = sâu hơn
				deepest = n
			}
		}
		return RouteResult{
			TargetAddr: deepest.Addr,
			Dist:       deepest.Dist,
			Inside:     true,
			Label:      r.labelOf(deepest.Addr),
			Confident:  true,
		}
	}
}

// RouteAll trả về RouteResult cho mỗi probe trong slice
// Dùng cho ScanProbes — agent scan nhiều điểm cùng lúc
func (r *ISLRouter) RouteAll(probes []Vec3) []RouteResult {
	results := make([]RouteResult, len(probes))
	for i, p := range probes {
		results[i] = r.Route(p)
	}
	return results
}

// Tally đếm số lần mỗi ISLAddr được route đến
// Trả về map addr → count, sorted không cần — caller tự xử lý
func (r *ISLRouter) Tally(results []RouteResult) map[uint64]int {
	tally := make(map[uint64]int)
	for _, res := range results {
		if res.Confident {
			tally[res.TargetAddr]++
		}
	}
	return tally
}

// Dominant trả về ISLAddr được route đến nhiều nhất trong batch
// Dùng để xác định "node nào chiếm ưu thế trong không gian này?"
func (r *ISLRouter) Dominant(probes []Vec3) (uint64, int) {
	results := r.RouteAll(probes)
	tally   := r.Tally(results)
	var bestAddr uint64
	bestCount := 0
	for addr, count := range tally {
		if count > bestCount {
			bestCount = count
			bestAddr  = addr
		}
	}
	return bestAddr, bestCount
}

// String debug — hiển thị RouteResult
func (rr RouteResult) String() string {
	loc := "outside"
	if rr.Inside { loc = "inside" }
	conf := ""
	if !rr.Confident { conf = " [uncertain]" }
	return fmt.Sprintf("%016x %-8s  dist=%.3f  %s%s",
		rr.TargetAddr, rr.Label, rr.Dist, loc, conf)
}

// labelOf tra tên từ SpatialNode list
func (r *ISLRouter) labelOf(addr uint64) string {
	for _, n := range r.Nodes {
		if n.Addr == addr { return n.Label }
	}
	return fmt.Sprintf("%016x", addr)
}
