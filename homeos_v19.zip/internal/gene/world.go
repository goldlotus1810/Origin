// internal/gene/world.go
// WorldScene — tập hợp tất cả thực thể trong một World
//
// WorldScene KHÔNG phải renderer — nó là "trạng thái vật lý"
// tại một thời điểm (yearT, hourOfDay).
//
// Renderer sẽ đọc WorldScene.Snapshot() → ISLStream
// và rayMarch qua tất cả SDF.
//
// Kiến trúc:
//   WorldScene
//     ├─ Sun         *SunGene
//     ├─ Earth       *EarthGene
//     ├─ Creatures   []*CreatureGene
//     ├─ Gravity     *GravitySystem
//     └─ Clock       WorldClock
//
//   WorldClock: yearT ∈ [0,1] + hourOfDay ∈ [0,24]
//   Tick(dt) cập nhật tất cả cùng lúc

package gene

import "math"

// WorldClock — đồng hồ thống nhất của World
type WorldClock struct {
	YearT     float64 // [0,1] = vị trí trong năm (0=tháng1, 0.5=tháng7)
	HourOfDay float64 // [0,24]
	TotalSec  float64 // giây đã trôi qua (world time)
}

// Tick tăng thời gian lên dt giây (world time)
// 1 giây world time = 1 giờ thật (x3600 speed)
func (c *WorldClock) Tick(dt float64) {
	c.TotalSec += dt
	c.HourOfDay = math.Mod(c.TotalSec/3600.0, 24.0)
	c.YearT = math.Mod(c.TotalSec/(3600.0*24*365.25), 1.0)
}

// Season trả về mùa hiện tại
func (c *WorldClock) Season() string {
	switch {
	case c.YearT < 0.25: return "Đông"
	case c.YearT < 0.50: return "Xuân"
	case c.YearT < 0.75: return "Hè"
	default:              return "Thu"
	}
}

// ─── WorldScene ───────────────────────────────────────────────────

type WorldScene struct {
	Sun       *SunGene
	Earth     *EarthGene
	Creatures []*CreatureGene
	Gravity   *GravitySystem
	Clock     WorldClock
}

// NewWorldScene tạo World mặc định: Sun + Earth ôn đới + 1 người
func NewWorldScene() *WorldScene {
	sun   := NewSunGene()
	earth := NewEarthGene() // ôn đới

	// QUAN TRỌNG: WorldScene dùng render space, không phải AU thật
	// Sun ở (0,22,-8) lúc 12h (từ SunGene.Orbit)
	// Earth ở (0,0,0) — bề mặt = vị trí quan sát
	// Orbit Earth trong render space = quanh gốc tọa độ (bán kính nhỏ)
	earth.Orbit = &Spline{Keys: []Keyframe{
		{T: 0.00, Vec3: Vec3{0, 0, 0}},
		{T: 0.25, Vec3: Vec3{0, 0, 0}},
		{T: 0.50, Vec3: Vec3{0, 0, 0}},
		{T: 0.75, Vec3: Vec3{0, 0, 0}},
	}}
	// Earth.pos = gốc tọa độ (render space)
	earth.Animate(0.5)

	ws := &WorldScene{
		Sun:     sun,
		Earth:   earth,
		Gravity: NewGravitySystem(),
		Clock:   WorldClock{YearT: 0.5, HourOfDay: 12}, // mặc định: hè, giữa trưa
	}

	// Thêm human mặc định
	human := NewCreatureGene(SpeciesHuman)
	human.SetActivity(0.5)
	ws.Creatures = append(ws.Creatures, human)

	// Dây hấp dẫn Sun-Earth
	ws.Gravity.Add(&GravityEdge{
		From:  ISL_Earth,
		To:    ISL_SunMass,
		MassA: EarthMassKg,
		MassB: SunMassKg,
		DistFn: func() float64 {
			// r = khoảng cách Earth-Sun theo quỹ đạo (AU → m)
			ep := earth.Orbit.Eval(ws.Clock.YearT)
			// Orbit Spline dùng AU scale → nhân 1e9 để có đơn vị m (xấp xỉ)
			return ep.Len() * 1e9
		},
	})

	// Dây hấp dẫn Earth-Human (tại bề mặt)
	ws.Gravity.Add(&GravityEdge{
		From:  ISL_Earth,
		To:    MakeISL(LayerWorld, GroupCreature, 0x01, 0x01, 0),
		MassA: EarthMassKg,
		MassB: HumanMassKg,
		DistFn: func() float64 { return EarthRadiusM },
	})

	return ws
}

// Tick cập nhật toàn bộ World lên dt giây
func (ws *WorldScene) Tick(dt float64) {
	ws.Clock.Tick(dt)

	// Animate từng Gene theo đồng hồ chung
	ws.Sun.Animate(ws.Clock.HourOfDay)
	ws.Earth.Animate(ws.Clock.YearT)

	for _, c := range ws.Creatures {
		c.Animate(ws.Clock.TotalSec)
	}
}

// ─── Query ────────────────────────────────────────────────────────

// SDF trả về khoảng cách nhỏ nhất từ p đến bất kỳ thực thể nào
func (ws *WorldScene) SDF(p Vec3) float64 {
	d := ws.Sun.SDF(p)
	if ed := ws.Earth.SDF(p); ed < d { d = ed }
	for _, c := range ws.Creatures {
		if cd := c.SDF(p); cd < d { d = cd }
	}
	return d
}

// TemperatureAt trả về nhiệt độ tại vị trí p (K)
// Đây là ví dụ "query cross-entity":
//   nếu p gần Creature → dùng BodyTemp
//   nếu p gần bề mặt Earth → dùng SurfaceTemp
//   nếu p gần Sun → dùng SunTemp
func (ws *WorldScene) TemperatureAt(p Vec3) float64 {
	// Creature gần nhất trước
	for _, c := range ws.Creatures {
		if c.SDF(p) < 0.5 {
			return c.BodyTempAt(ws.Clock.TotalSec)
		}
	}
	// So sánh khoảng cách tương đối: normalize theo bán kính
	dSun   := ws.Sun.SDF(p) / ws.Sun.Radius
	dEarth := ws.Earth.SDF(p) / ws.Earth.Radius
	if dEarth < dSun {
		return ws.Earth.TempAt(ws.Clock.YearT, ws.Clock.HourOfDay)
	}
	return ws.Sun.TempAt(ws.Clock.HourOfDay)
}

// LightAt trả về thông tin ánh sáng tại thời điểm hiện tại
func (ws *WorldScene) LightAt() LightInfo {
	return ws.Sun.LightAt(ws.Clock.HourOfDay)
}

// SkyColorAt trả về màu bầu trời theo giờ
func (ws *WorldScene) SkyColorAt() Vec3 {
	return ws.Sun.ColorAt(ws.Clock.HourOfDay)
}

// SunsetTemp trả về nhiệt độ không khí tại thời điểm hiện tại (°C)
func (ws *WorldScene) AirTempC() float64 {
	return ws.Earth.SunsetTemp(ws.Clock.YearT, ws.Sun) - 273.15
}

// ─── Snapshot — ISLStream toàn bộ World ──────────────────────────
// Renderer đọc Snapshot() thay vì gọi từng Gene riêng lẻ

type WorldSnapshot struct {
	Clock   WorldClock
	Streams []*ISLStream // 1 stream per entity
	Light   LightInfo
	SkyRGB  Vec3
	AirTempC float64
}

func (ws *WorldScene) Snapshot() *WorldSnapshot {
	t  := ws.Clock.HourOfDay
	yr := ws.Clock.YearT

	snap := &WorldSnapshot{
		Clock:    ws.Clock,
		Light:    ws.LightAt(),
		SkyRGB:   ws.SkyColorAt(),
		AirTempC: ws.AirTempC(),
	}

	snap.Streams = append(snap.Streams, ws.Sun.DNAStream(t))
	snap.Streams = append(snap.Streams, ws.Earth.DNAStream(yr))
	for _, c := range ws.Creatures {
		snap.Streams = append(snap.Streams, c.DNAStream(ws.Clock.TotalSec))
	}
	for _, e := range ws.Gravity.Edges {
		snap.Streams = append(snap.Streams, e.DNAStream())
	}
	return snap
}

// TotalBytes trả về tổng kích thước binary của Snapshot
func (sn *WorldSnapshot) TotalBytes() int {
	n := 0
	for _, s := range sn.Streams { n += s.SizeBytes() }
	return n
}

// AddCreature thêm Creature vào WorldScene — hot-reload safe
// Creature mới sẽ xuất hiện trong SpatialNodes() ngay lập tức
func (ws *WorldScene) AddCreature(c *CreatureGene) {
	ws.Creatures = append(ws.Creatures, c)
}

// RemoveCreature xóa creature theo Addr (append-only: mark inactive thay vì xóa thật)
// Trả về true nếu tìm thấy
func (ws *WorldScene) RemoveCreature(addr uint64) bool {
	for i, c := range ws.Creatures {
		if uint64(c.Addr) == addr {
			// Swap với phần tử cuối (order không quan trọng)
			ws.Creatures[i] = ws.Creatures[len(ws.Creatures)-1]
			ws.Creatures = ws.Creatures[:len(ws.Creatures)-1]
			return true
		}
	}
	return false
}

// CreatureCount trả về số creature hiện tại
func (ws *WorldScene) CreatureCount() int { return len(ws.Creatures) }
