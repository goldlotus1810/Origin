// internal/gene/isl.go
// ISL Address — định danh thật cho mọi thực thể trong World
//
// Kiến trúc:
//   ISLAddr = uint64: [layer:1B][group:1B][type:1B][id:1B][attr:4B]
//   Mỗi thực thể vật lý, thuộc tính, operator đều có ISLAddr bất biến
//   homeos.olang dùng cùng không gian địa chỉ này làm primary key

package gene

// ISLAddr = 8 bytes = uint64
// [layer:1B][group:1B][type:1B][id:1B][attr:4B]
type ISLAddr uint64

// ─── Namespace layer ──────────────────────────────────────────────

const (
	LayerWorld   byte = 0x57 // 'W' — thực thể vật lý trong World
	LayerPhysics byte = 0x50 // 'P' — thuộc tính vật lý (nhiệt độ, ánh sáng...)
	LayerKnow    byte = 0x4B // 'K' — tri thức (homeos.olang nodes)
	LayerAgent   byte = 0x41 // 'A' — Agent
	LayerSensor  byte = 0x53 // 'S' — Sensor
	LayerOp      byte = 0x4F // 'O' — Operator (SDF primitives, math)
)

// ─── Group trong LayerWorld ───────────────────────────────────────

const (
	GroupStar     byte = 0x01 // ngôi sao
	GroupPlanet   byte = 0x02 // hành tinh
	GroupNature   byte = 0x03 // thiên nhiên (cây, đất, nước)
	GroupCreature byte = 0x04 // sinh vật
	GroupObject   byte = 0x05 // đồ vật nhân tạo
)

// ─── Group trong LayerPhysics ─────────────────────────────────────
// Mỗi thuộc tính vật lý = 1 node có ScalarSpline

const (
	GroupTemperature byte = 0x01 // nhiệt độ (K)
	GroupWavelength  byte = 0x02 // bước sóng ánh sáng (nm)
	GroupMass        byte = 0x03 // khối lượng (kg)
	GroupLuminosity  byte = 0x04 // độ sáng / cường độ (lux, W/m²)
	GroupOrbit       byte = 0x05 // quỹ đạo / chu kỳ chuyển động
	GroupMagnetic    byte = 0x06 // từ trường (T, chu kỳ)
	GroupGravity     byte = 0x07 // gia tốc trọng trường (m/s²)
	GroupPressure    byte = 0x08 // áp suất (Pa)
	GroupFrequency   byte = 0x09 // tần số (Hz)
)

// ─── Group trong LayerOp ─────────────────────────────────────────
// SDF Primitives và toán tử — dùng làm "động từ" trong DNA stream

const (
	GroupSDFPrimitive byte = 0x01 // Sphere, Capsule, Box, Torus...
	GroupSDFOp        byte = 0x02 // Union, Subtract, Intersect...
	GroupMathOp       byte = 0x03 // +, ×, ∇, ∑...
	GroupLightOp      byte = 0x04 // SunLight, PointLight...
)

// ─── MakeISL ─────────────────────────────────────────────────────

// MakeISL tạo ISLAddr từ 4 byte + 4 byte attr
func MakeISL(layer, group, typ, id byte, attr uint32) ISLAddr {
	return ISLAddr(
		uint64(layer)<<56 | uint64(group)<<48 |
			uint64(typ)<<40 | uint64(id)<<32 |
			uint64(attr),
	)
}

// Layer trả về byte layer của địa chỉ
func (a ISLAddr) Layer() byte { return byte(a >> 56) }

// Group trả về byte group
func (a ISLAddr) Group() byte { return byte(a >> 48) }

// Type trả về byte type
func (a ISLAddr) Type() byte { return byte(a >> 40) }

// ID trả về byte id
func (a ISLAddr) ID() byte { return byte(a >> 32) }

// Attr trả về 4 byte attr
func (a ISLAddr) Attr() uint32 { return uint32(a) }

// Uint64 để truyền qua ISLMessage
func (a ISLAddr) Uint64() uint64 { return uint64(a) }

// ─── ISL address cố định — bất biến, primary key ─────────────────

var (
	// ── Thực thể vật lý (LayerWorld) ──────────────────────────
	ISL_Sun   = MakeISL(LayerWorld, GroupStar,   0x01, 0x01, 0)
	ISL_Earth = MakeISL(LayerWorld, GroupPlanet, 0x01, 0x01, 0)
	ISL_Moon  = MakeISL(LayerWorld, GroupPlanet, 0x01, 0x02, 0)
	ISL_Water = MakeISL(LayerWorld, GroupNature, 0x01, 0x01, 0)
	ISL_Fire  = MakeISL(LayerWorld, GroupNature, 0x01, 0x02, 0)
	ISL_Tree  = MakeISL(LayerWorld, GroupNature, 0x01, 0x03, 0)

	// ── Thuộc tính vật lý mặt trời (LayerPhysics) ─────────────
	// Mỗi cái = 1 ScalarSpline gắn qua ISL edge vào ISL_Sun
	ISL_SunTemp  = MakeISL(LayerPhysics, GroupTemperature, 0x01, 0x01, 0) // 5778K
	ISL_SunWave  = MakeISL(LayerPhysics, GroupWavelength,  0x01, 0x01, 0) // 380-780nm
	ISL_SunLumin = MakeISL(LayerPhysics, GroupLuminosity,  0x01, 0x01, 0) // [0..1]
	ISL_SunOrbit = MakeISL(LayerPhysics, GroupOrbit,       0x01, 0x01, 0) // 24h
	ISL_SunMag   = MakeISL(LayerPhysics, GroupMagnetic,    0x01, 0x01, 0) // 11 năm

	// ── Hằng số vật lý (attr = fingerprint) ──────────────────
	ISL_ConstG = MakeISL(LayerPhysics, 0xFF, 0x01, 0x01, 0) // G = 6.674e-11

	// ── Khối lượng (LayerPhysics, GroupMass) ──────────────────
	ISL_SunMass   = MakeISL(LayerPhysics, GroupMass, 0x01, 0x01, 0) // 1.989e30 kg
	ISL_EarthMass = MakeISL(LayerPhysics, GroupMass, 0x02, 0x01, 0) // 5.972e24 kg
	ISL_MoonMass  = MakeISL(LayerPhysics, GroupMass, 0x03, 0x01, 0) // 7.342e22 kg

	// ── Thuộc tính vật lý Trái Đất (LayerPhysics) ────────────
	// id=0x02 phân biệt với mặt trời (id=0x01)
	ISL_EarthTemp    = MakeISL(LayerPhysics, GroupTemperature, 0x02, 0x01, 0) // nhiệt độ bề mặt (K)
	ISL_EarthAtmos   = MakeISL(LayerPhysics, GroupPressure,    0x02, 0x01, 0) // áp suất khí quyển (Pa)
	ISL_EarthGravity = MakeISL(LayerPhysics, GroupGravity,     0x02, 0x01, 0) // 9.807 m/s²
	ISL_EarthOrbit   = MakeISL(LayerPhysics, GroupOrbit,       0x02, 0x01, 0) // 365.25 ngày
	ISL_EarthRotate  = MakeISL(LayerPhysics, GroupFrequency,   0x02, 0x01, 0) // 24h tự quay
	ISL_EarthHumid   = MakeISL(LayerPhysics, GroupPressure,    0x02, 0x02, 0) // độ ẩm [0..1]

	// ── SDF Operators (LayerOp) ────────────────────────────────
	// Dùng làm "động từ" trong DNA stream ISL
	ISL_OpSphere = MakeISL(LayerOp, GroupSDFPrimitive, 0x01, 0x01, 0) // ●
	ISL_OpCapsule= MakeISL(LayerOp, GroupSDFPrimitive, 0x01, 0x02, 0) // ⌀
	ISL_OpBox    = MakeISL(LayerOp, GroupSDFPrimitive, 0x01, 0x03, 0) // □
	ISL_OpUnion  = MakeISL(LayerOp, GroupSDFOp,        0x01, 0x01, 0) // ∪
	ISL_OpSub    = MakeISL(LayerOp, GroupSDFOp,        0x01, 0x02, 0) // ∖
	ISL_OpLight  = MakeISL(LayerOp, GroupLightOp,      0x01, 0x01, 0) // ☀
)

// ─── NewScalarSpline helper ───────────────────────────────────────
// Tạo ScalarSpline từ cặp (t, v) liệt kê thẳng
// Ví dụ: NewScalarSpline("K", 0.0,5778, 0.5,5800, 1.0,5778)

func NewScalarSpline(unit string, pairs ...float64) *ScalarSpline {
	keys := make([]ScalarKey, len(pairs)/2)
	for i := range keys {
		keys[i] = ScalarKey{
			T: pairs[i*2],
			V: pairs[i*2+1],
		}
	}
	return &ScalarSpline{Keys: keys, Unit: unit}
}
