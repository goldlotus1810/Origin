package gene

import (
	"math"
	"testing"
)

func TestGravity(t *testing.T) {
	sun   := NewSunGene()
	earth := NewEarthGene()

	// ── Surface gravity tính từ M và R ───────────────────────
	t.Log("Surface gravity (tính từ G×M/R², không hardcode):")
	t.Logf("  Sun:   %.2f m/s²  (thực tế 274.0)", sun.SurfaceGrav())
	t.Logf("  Earth: %.4f m/s²  (thực tế 9.807)", earth.SurfaceGrav())
	earthG := earth.SurfaceGrav()
	if math.Abs(earthG-9.807) > 0.05 {
		t.Errorf("Earth g=%.4f sai lệch > 0.05 so với 9.807", earthG)
	}
	t.Logf("  |Earth g - 9.807| = %.4f ✓", math.Abs(earthG-9.807))

	// ── GravityEdge: Sun-Earth ────────────────────────────────
	// r = 1 AU = 1.496e11 m
	rAU := 1.496e11
	sunEarthEdge := &GravityEdge{
		From:  earth.Addr,
		To:    ISL_SunMass,
		MassA: EarthMassKg,
		MassB: SunMassKg,
		DistFn: func() float64 { return rAU },
	}
	t.Logf("\nGravityEdge Sun-Earth (r=1AU):")
	t.Logf("  Force  = %.3e N  (thực tế ~3.54e22 N)", sunEarthEdge.Force())
	t.Logf("  Accel  = %.6f m/s²  (thực tế ~0.006 m/s²)", sunEarthEdge.Accel())

	// ── GravityEdge: Earth-Human ──────────────────────────────
	humanEdge := &GravityEdge{
		From:  earth.Addr,
		To:    MakeISL(LayerWorld, GroupCreature, 0x01, 0x01, 0),
		MassA: EarthMassKg,
		MassB: HumanMassKg,
		DistFn: func() float64 { return EarthRadiusM },
	}
	t.Logf("\nGravityEdge Earth-Human (r=R_earth):")
	t.Logf("  Force  = %.2f N  (70kg × 9.807 = %.2f N)", humanEdge.Force(), HumanMassKg*9.807)
	t.Logf("  Accel  = %.4f m/s²", humanEdge.Accel())

	// ── Escape velocity ───────────────────────────────────────
	t.Log("\nEscape velocity:")
	t.Logf("  Earth: %.0f m/s  (thực tế 11186 m/s)", EscapeVelocity(EarthMassKg, EarthRadiusM))
	t.Logf("  Sun:   %.0f m/s  (thực tế 617500 m/s)", EscapeVelocity(SunMassKg, SunRadiusM))

	// ── Orbital velocity ─────────────────────────────────────
	t.Logf("\nOrbital velocity Earth quanh Sun (r=1AU):")
	t.Logf("  %.0f m/s  (thực tế 29783 m/s)", OrbitalVelocity(SunMassKg, rAU))

	// ── WeightOf ─────────────────────────────────────────────
	t.Logf("\nTrọng lượng tại bề mặt Trái Đất:")
	for _, m := range []float64{1, 70, 1000} {
		t.Logf("  %.0f kg → %.2f N", m, WeightOf(m))
	}

	// ── ISL address đúng ─────────────────────────────────────
	t.Logf("\nISL Mass nodes:")
	t.Logf("  ISL_SunMass   = %016x  layer='%c'", uint64(ISL_SunMass), ISL_SunMass.Layer())
	t.Logf("  ISL_EarthMass = %016x  layer='%c'", uint64(ISL_EarthMass), ISL_EarthMass.Layer())

	// Assertions
	if math.Abs(earth.SurfaceGrav()-9.807) > 0.05 { t.Error("Earth g sai") }
	evEarth := EscapeVelocity(EarthMassKg, EarthRadiusM)
	if math.Abs(evEarth-11186) > 100 { t.Errorf("Escape vel %.0f sai", evEarth) }
	ov := OrbitalVelocity(SunMassKg, rAU)
	if math.Abs(ov-29783) > 500 { t.Errorf("Orbital vel %.0f sai", ov) }

	_ = sun
}
