// internal/gene/worker_brain.go
//
// WorkerBrain — não của Worker
//
// Chief training Worker:
//   Chief.Train(worker, examples) → Worker học được:
//     - Phương trình của mỗi action (EquationLibrary)
//     - Ngưỡng nghi ngờ (SuspicionThreshold)
//     - Cách quyết định lưu/bỏ (RetentionPolicy)
//
// Sau training, Worker hoàn toàn tự chủ:
//   Thấy motion/audio:
//     → Khớp equation? → im lặng
//     → Nghi ngờ?      → TỰ QUYẾT lưu/bỏ + BÁO Chief
//
// "Độ thông minh" = SuspicionThreshold
//   Thấp (nhạy) → nghi ngờ nhiều → báo nhiều
//   Cao (lì)    → chỉ báo khi rõ ràng bất thường

package gene

import "fmt"

// ─── RetentionPolicy — Chief training Worker cách lưu/bỏ ────────────────

type RetentionPolicy struct {
	// Chief set các ngưỡng này khi training
	MinAnomalyToSave  float64 // anomaly phải > này mới đáng lưu
	MaxSavePerAction  int     // tối đa bao nhiêu equation/action
	ConfidenceToKeep  float64 // confidence của fit mới phải > này
}

var DefaultPolicy = RetentionPolicy{
	MinAnomalyToSave: 0.08,  // lệch > 8% mới lưu (bỏ noise nhỏ)
	MaxSavePerAction: 5,     // tối đa 5 phương trình/action
	ConfidenceToKeep: 0.60,
}

// ─── SuspicionReport — Worker báo Chief ─────────────────────────────────

type SuspicionReport struct {
	Source    string          // "cam_kitchen_01"
	Action    ActionVerb
	AnomalyScore float64
	Saved     bool            // Worker đã tự lưu chưa
	EqID      string          // equation mới (nếu saved=true)
	Reason    string
}

// ─── WorkerBrain ─────────────────────────────────────────────────────────

type WorkerBrain struct {
	ID      string
	Eqs     *EquationLibrary
	Policy  RetentionPolicy

	// "Độ thông minh" = ngưỡng nghi ngờ
	// Chief set khi training, Worker tự điều chỉnh theo kinh nghiệm
	SuspicionThreshold float64

	Stats struct {
		Seen      int
		Silent    int // bình thường, im lặng
		Suspected int // nghi ngờ, báo Chief
		Saved     int // tự lưu equation mới
		Dropped   int // nghi ngờ nhưng tự quyết bỏ
	}
}

// NewWorkerBrain khởi tạo Worker với config từ Chief training
func NewWorkerBrain(id string, suspicionThreshold float64, policy RetentionPolicy) *WorkerBrain {
	return &WorkerBrain{
		ID:                 id,
		Eqs:                NewEquationLibrary(suspicionThreshold, suspicionThreshold*3),
		Policy:             policy,
		SuspicionThreshold: suspicionThreshold,
	}
}

// ObserveMotion: Worker xử lý 1 motion clip
// Returns: nil = im lặng, non-nil = báo Chief
func (w *WorkerBrain) ObserveMotion(
	clip *MotionClip,
	action ActionVerb,
	species string,
) *SuspicionReport {
	w.Stats.Seen++

	isNew, anomaly, eq := w.Eqs.LearnMotion(clip, action, species)

	// Bình thường → im lặng
	if !isNew && anomaly < w.SuspicionThreshold {
		w.Stats.Silent++
		return nil
	}

	// Nghi ngờ → tự quyết lưu/bỏ
	w.Stats.Suspected++
	report := &SuspicionReport{
		Source:       w.ID,
		Action:       action,
		AnomalyScore: anomaly,
	}

	if isNew {
		// Mới hoàn toàn
		nSameAction := 0
		for _, e := range w.Eqs.MotionEqs {
			if e.Action == action { nSameAction++ }
		}

		// Tự quyết: lưu hay bỏ?
		shouldSave := anomaly > w.Policy.MinAnomalyToSave &&
			nSameAction <= w.Policy.MaxSavePerAction

		if shouldSave {
			// Đã lưu trong LearnMotion ở trên
			report.Saved = true
			report.EqID = eq.ID
			report.Reason = fmt.Sprintf("new equation fit (anomaly=%.3f, eqs_for_%s=%d)",
				anomaly, action, nSameAction)
			w.Stats.Saved++
		} else {
			// Tự quyết bỏ — nhưng vẫn báo Chief
			// Xóa equation vừa thêm
			last := len(w.Eqs.MotionEqs) - 1
			if last >= 0 && w.Eqs.MotionEqs[last].ID == eq.ID {
				w.Eqs.MotionEqs = w.Eqs.MotionEqs[:last]
				w.Eqs.SavedTotal--
			}
			report.Saved = false
			report.Reason = fmt.Sprintf("suspected but dropped (anomaly=%.3f too small or library full)",
				anomaly)
			w.Stats.Dropped++
		}
	} else {
		// Đã biết nhưng anomaly cao — bất thường
		report.EqID = eq.ID
		report.Saved = false
		report.Reason = fmt.Sprintf("known action but anomaly=%.3f > threshold=%.3f (seen=%d)",
			anomaly, w.SuspicionThreshold, eq.SeenCount)
	}

	return report
}

// ObserveAudio: tương tự cho âm thanh
func (w *WorkerBrain) ObserveAudio(
	cues []AudioCue,
	bands [8]float64,
) *SuspicionReport {
	w.Stats.Seen++

	isNew, anomaly, eq := w.Eqs.LearnAudio(cues, bands)

	if !isNew && anomaly < w.SuspicionThreshold*3 {
		w.Stats.Silent++
		return nil
	}

	w.Stats.Suspected++
	report := &SuspicionReport{
		AnomalyScore: anomaly,
		Source:       w.ID,
	}

	if isNew {
		shouldSave := anomaly > w.Policy.MinAnomalyToSave*0.5
		if shouldSave {
			report.Saved  = true
			report.EqID   = eq.ID
			report.Reason = fmt.Sprintf("new audio equation (anomaly=%.3f)", anomaly)
			w.Stats.Saved++
		} else {
			last := len(w.Eqs.AudioEqs) - 1
			if last >= 0 && w.Eqs.AudioEqs[last].ID == eq.ID {
				w.Eqs.AudioEqs = w.Eqs.AudioEqs[:last]
				w.Eqs.SavedTotal--
			}
			report.Saved  = false
			report.Reason = fmt.Sprintf("audio noise, dropped (anomaly=%.3f)", anomaly)
			w.Stats.Dropped++
		}
	} else {
		report.EqID   = eq.ID
		report.Saved  = false
		report.Reason = fmt.Sprintf("audio anomaly=%.3f > threshold", anomaly)
	}

	return report
}

// Intelligence summary
func (w *WorkerBrain) Intelligence() string {
	if w.Stats.Seen == 0 {
		return fmt.Sprintf("%s: no data", w.ID)
	}
	silentPct := 100 * w.Stats.Silent / w.Stats.Seen
	return fmt.Sprintf("%s: seen=%d silent=%d(%d%%) suspected=%d saved=%d dropped=%d | threshold=%.3f",
		w.ID,
		w.Stats.Seen, w.Stats.Silent, silentPct,
		w.Stats.Suspected, w.Stats.Saved, w.Stats.Dropped,
		w.SuspicionThreshold)
}
