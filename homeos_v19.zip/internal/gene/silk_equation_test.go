package gene

import (
	"fmt"
	"testing"
)

func TestSilkEquation(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  SILK EQUATION — lưu phương trình, không lưu samples        ║")
	t.Log("║  QT3: Toán học trừu tượng → Vật lý là sự thật              ║")
	t.Log("║  Anomaly → báo Chief. Bình thường → im lặng.               ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// Chief training: set threshold ban đầu
	lib := NewEquationLibrary(0.040, 0.15)

	t.Log("[ ĐIỂM 1 — SILK lưu phương trình ]")
	t.Log()

	// Simulate nhiều observations cùng action
	type obs struct {
		label  string
		action ActionVerb
		freq   float64 // variation nhỏ
		amp    float64
	}

	cookingObs := []obs{
		{"nấu ăn lần 1 (thái)",  ActionCooking, 3.5, 0.12},
		{"nấu ăn lần 2 (thái)",  ActionCooking, 3.4, 0.12},
		{"nấu ăn lần 3 (thái)",  ActionCooking, 3.6, 0.11},
		{"nấu ăn lần 4 (khuấy)", ActionCooking, 1.2, 0.16},
		{"nấu ăn lần 5 (thái)",  ActionCooking, 3.5, 0.12},
	}

	t.Log("  Motion equations cho 'cooking':")
	for _, o := range cookingObs {
		clip := makeLibClip(o.action, o.freq, o.amp, 0)
		isNew, anom, eq := lib.LearnMotion(clip, o.action, "human_adult_female")
		mark := "LƯU EQ"
		if !isNew { mark = fmt.Sprintf("  fit  (anom=%.4f < thr=%.3f)", anom, eq.Threshold) }
		t.Logf("    %-26s → %s  [%s]  seen=%d", o.label, mark, eq.ID, eq.SeenCount)
	}

	t.Log()
	t.Log("  Storage comparison:")
	for _, eq := range lib.MotionEqs {
		eqBytes  := EquationStorageBytes(eq)
		rawBytes := SampleStorageBytes(90)
		t.Logf("    %s: equation=%dB  raw_samples=%dB  save=%.0f%%",
			eq.ID, eqBytes, rawBytes,
			100*(1-float64(eqBytes)/float64(rawBytes)))
	}

	t.Log()
	t.Log("[ ĐIỂM 2 — Âm thanh cũng lưu phương trình (Fourier) ]")
	t.Log()

	audioObs := []struct {
		label  string
		cues   []AudioCue
		bands  [8]float64
	}{
		{"bếp lần 1", []AudioCue{AudioWater}, [8]float64{0,0,0.80,0.60,0.20,0,0,0}},
		{"bếp lần 2", []AudioCue{AudioWater}, [8]float64{0,0,0.78,0.62,0.21,0,0,0}},
		{"nhạc pop",  []AudioCue{AudioMusic}, [8]float64{0.2,0.8,0.6,0.4,0.3,0.5,0.7,0.4}},
		{"nhạc pop 2",[]AudioCue{AudioMusic}, [8]float64{0.2,0.79,0.61,0.4,0.3,0.5,0.7,0.4}},
		{"TV",        []AudioCue{AudioTV},    [8]float64{0.1,0.5,0.7,0.6,0.4,0.3,0.2,0.1}},
	}

	for _, o := range audioObs {
		isNew, anom, eq := lib.LearnAudio(o.cues, o.bands)
		mark := "LƯU EQ"
		if !isNew { mark = fmt.Sprintf("  fit  (anom=%.4f < thr=%.3f)", anom, eq.Threshold) }
		t.Logf("  %-14s → %s  [%s]  seen=%d", o.label, mark, eq.ID, eq.SeenCount)
	}

	audioEqBytes := len(lib.AudioEqs) * (8*2*8 + 40) // harmonics + meta
	rawWaveBytes := 44100 * 2 * 3                     // 3 giây PCM 16-bit
	t.Logf("\n  Audio equation: %dB  vs raw waveform 3s: %dB  save=%.0f%%",
		audioEqBytes, rawWaveBytes,
		100*(1-float64(audioEqBytes)/float64(rawWaveBytes)))

	t.Log()
	t.Log("[ ĐIỂM 3 — Worker tự quyết, báo Chief khi bất thường ]")
	t.Log()
	t.Log("  Chief training → threshold ban đầu = 0.040")
	t.Log("  SeenCount tăng → Worker tự tune (SelfTune)")
	t.Log()

	// Tìm equation cooking để demo anomaly
	var cookingEq *MotionEquation
	for _, eq := range lib.MotionEqs {
		if eq.Action == ActionCooking { cookingEq = eq; break }
	}

	if cookingEq != nil {
		t.Logf("  Equation: %s  seen=%d  threshold=%.4f  selfTuned=%v",
			cookingEq.ID, cookingEq.SeenCount, cookingEq.Threshold, cookingEq.SelfTuned)
		t.Log()

		checks := []struct {
			label string
			t     float64
			cx    float64 // arm_r position
			cy    float64
		}{
			{"Tay phải nấu bình thường",  0.5, 0.65, 0.45},
			{"Tay phải hơi lệch",         0.5, 0.67, 0.47},
			{"Tay phải lệch nhiều",       0.5, 0.80, 0.60}, // bất thường
			{"Tay phải vị trí lạ hoàn toàn",0.5, 0.20, 0.10}, // rất bất thường
		}

		for _, c := range checks {
			rep := lib.CheckMotionAnomaly("arm_r", c.t, c.cx, c.cy, ActionCooking)
			if rep.IsAnomaly {
				t.Logf("  🚨 %-32s → BÁO CHIEF  score=%.4f > %.4f",
					c.label, rep.Score, cookingEq.Threshold)
			} else {
				t.Logf("  ✓  %-32s → im lặng    score=%.4f",
					c.label, rep.Score)
			}
		}

		t.Log()
		t.Logf("  [ Self-tuning sau %d lần quan sát ]", cookingEq.SeenCount)
		origThresh := cookingEq.Threshold
		cookingEq.SeenCount = 30
		cookingEq.SelfTune()
		t.Logf("  Threshold: %.4f → %.4f (seen=30, nhạy hơn %.0f%%)",
			origThresh, cookingEq.Threshold,
			100*(origThresh-cookingEq.Threshold)/origThresh)
	}

	t.Log()
	t.Log("[ TỔNG KẾT ]")
	t.Logf("  Observations: %d  |  Equations saved: motion=%d audio=%d",
		lib.SeenTotal, len(lib.MotionEqs), len(lib.AudioEqs))

	motionBytes := 0
	for _, eq := range lib.MotionEqs { motionBytes += EquationStorageBytes(eq) }
	audioBytes  := len(lib.AudioEqs) * (8*2*8 + 40)
	t.Logf("  RAM: motion=%dB  audio=%dB  total=%dB",
		motionBytes, audioBytes, motionBytes+audioBytes)
	t.Log()
	t.Log("  ✓ SILK lưu phương trình (control points + Fourier coefficients)")
	t.Log("  ✓ Mọi instance = evaluate equation, không lưu lại")
	t.Log("  ✓ Worker im lặng khi bình thường")
	t.Log("  ✓ Worker báo Chief khi anomaly score > threshold")
	t.Log("  ✓ SeenCount↑ → threshold↓ → Worker nhạy hơn (tự học)")
}
