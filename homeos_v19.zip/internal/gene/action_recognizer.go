// internal/gene/action_recognizer.go
//
// ACTION RECOGNIZER — từ MotionSpline → Hành động → Không gian
//
// Insight (session 115):
//   Pixel không có nghĩa
//   Waveform không có nghĩa
//   Nghĩa đến từ HÀNH ĐỘNG
//
// Pipeline:
//   MotionClip (joint tracks)
//     ↓
//   MotionPattern (đặc trưng chuyển động)
//     ↓
//   ActionVerb  (đang làm gì)
//     ↓
//   SceneContext (đang ở đâu)
//     ↓
//   ISL Address (HAa1=bếp, HAb2=phòng khách...)

package gene

import (
	"fmt"
	"math"
	"sort"
)

// ─── MotionPattern — đặc trưng chuyển động của 1 joint ───────────────────

type PatternType string

const (
	PatternStill      PatternType = "still"       // không động
	PatternOscillate  PatternType = "oscillate"   // lặp đi lặp lại (nấu, giặt)
	PatternCircular   PatternType = "circular"    // xoay tròn (khuấy, múa)
	PatternRaise      PatternType = "raise"       // giơ lên (chào, hỏi)
	PatternReach      PatternType = "reach"       // với ra (lấy đồ)
	PatternSymmetric  PatternType = "symmetric"   // 2 tay đối xứng (múa, yoga)
	PatternAsymmetric PatternType = "asymmetric"  // 1 tay (thái, gõ phím)
	PatternWalk       PatternType = "walk"        // chân đi bộ
	PatternRun        PatternType = "run"         // chân chạy
	PatternSit        PatternType = "sit"         // ngồi (chân thu lại)
	PatternLie        PatternType = "lie"         // nằm (toàn thân thấp)
)

// MotionFeatures đặc trưng được extract từ JointTrack
type MotionFeatures struct {
	JointName string

	// Amplitude: biên độ dao động
	AmpX, AmpY float64

	// Frequency: tần số (Hz)
	FreqX, FreqY float64

	// Circularity: 0=thẳng, 1=tròn hoàn hảo
	Circularity float64

	// NetDisplacement: tổng dịch chuyển
	NetDX, NetDY float64

	// AvgY: vị trí trung bình (cao/thấp)
	AvgY float64

	// Velocity: tốc độ trung bình
	AvgVelocity float64

	Pattern PatternType
}

// extractFeatures phân tích JointTrack → MotionFeatures
func extractFeatures(track *JointTrack) MotionFeatures {
	kfs := track.Keyframes
	if len(kfs) < 4 {
		return MotionFeatures{JointName: track.Name, Pattern: PatternStill}
	}

	// Mean position
	mx, my := 0.0, 0.0
	for _, k := range kfs { mx += k.CX; my += k.CY }
	mx /= float64(len(kfs)); my /= float64(len(kfs))

	// Amplitude (max deviation from mean)
	ampX, ampY := 0.0, 0.0
	for _, k := range kfs {
		if d := math.Abs(k.CX - mx); d > ampX { ampX = d }
		if d := math.Abs(k.CY - my); d > ampY { ampY = d }
	}

	// Circularity: nếu quỹ đạo là hình tròn
	// → variance của distance từ mean gần 0
	dists := make([]float64, len(kfs))
	meanDist := 0.0
	for i, k := range kfs {
		dx, dy := k.CX-mx, k.CY-my
		dists[i] = math.Sqrt(dx*dx + dy*dy)
		meanDist += dists[i]
	}
	meanDist /= float64(len(kfs))
	varDist := 0.0
	for _, d := range dists {
		varDist += (d - meanDist) * (d - meanDist)
	}
	varDist /= float64(len(kfs))
	circularity := 0.0
	if meanDist > 1e-6 {
		circularity = math.Max(0, 1-math.Sqrt(varDist)/meanDist)
	}

	// Frequency: zero crossing count / duration
	duration := kfs[len(kfs)-1].T - kfs[0].T
	if duration < 1e-6 { duration = 1 }
	crossX, crossY := 0, 0
	for i := 1; i < len(kfs); i++ {
		if (kfs[i].CX-mx)*(kfs[i-1].CX-mx) < 0 { crossX++ }
		if (kfs[i].CY-my)*(kfs[i-1].CY-my) < 0 { crossY++ }
	}
	freqX := float64(crossX) / (2 * duration)
	freqY := float64(crossY) / (2 * duration)

	// Net displacement
	netDX := kfs[len(kfs)-1].CX - kfs[0].CX
	netDY := kfs[len(kfs)-1].CY - kfs[0].CY

	// Average velocity
	totalDist := 0.0
	for i := 1; i < len(kfs); i++ {
		dx := kfs[i].CX - kfs[i-1].CX
		dy := kfs[i].CY - kfs[i-1].CY
		totalDist += math.Sqrt(dx*dx + dy*dy)
	}
	avgVel := totalDist / duration

	// Classify pattern
	pattern := classifyPattern(ampX, ampY, freqX, freqY, circularity, netDX, netDY, my, avgVel)

	return MotionFeatures{
		JointName:   track.Name,
		AmpX: ampX, AmpY: ampY,
		FreqX: freqX, FreqY: freqY,
		Circularity: circularity,
		NetDX: netDX, NetDY: netDY,
		AvgY: my,
		AvgVelocity: avgVel,
		Pattern: pattern,
	}
}

func classifyPattern(ampX, ampY, freqX, freqY, circ, netDX, netDY, avgY, vel float64) PatternType {
	totalAmp := ampX + ampY

	// Không động
	if totalAmp < 0.008 && vel < 0.002 {
		return PatternStill
	}

	// Đi/chạy TRƯỚC: net displacement là dấu hiệu rõ nhất
	if math.Abs(netDX) > 0.018 || math.Abs(netDY) > 0.018 {
		if vel > 0.08 { return PatternRun }
		return PatternWalk
	}

	// Tròn: circularity cao + không có displacement lớn
	if circ > 0.65 && totalAmp > 0.05 {
		return PatternCircular
	}

	// Oscillate: dao động đều 2 chiều
	if (freqX > 0.5 || freqY > 0.5) && totalAmp > 0.03 {
		return PatternOscillate
	}

	// Raise: di chuyển lên rõ ràng
	if netDY < -0.08 && avgY < 0.35 {
		return PatternRaise
	}

	// Reach: với sang ngang
	if math.Abs(netDX) > 0.06 && math.Abs(netDY) < 0.04 {
		return PatternReach
	}

	// Sit: chân ở vị trí cao (co lại)
	if avgY > 0.55 && totalAmp < 0.04 {
		return PatternSit
	}

	return PatternOscillate // default: có chuyển động
}

// ─── ActionVerb — hành động được nhận ra ─────────────────────────────────

type ActionVerb string

const (
	ActionDancing   ActionVerb = "dancing"
	ActionCooking   ActionVerb = "cooking"
	ActionCleaning  ActionVerb = "cleaning"
	ActionTyping    ActionVerb = "typing"
	ActionWalking   ActionVerb = "walking"
	ActionRunning   ActionVerb = "running"
	ActionSitting   ActionVerb = "sitting"
	ActionSleeping  ActionVerb = "sleeping"
	ActionStretching ActionVerb = "stretching"
	ActionWaving    ActionVerb = "waving"
	ActionExercising ActionVerb = "exercising"
	ActionUnknown   ActionVerb = "unknown"
)

// ─── AudioCue — gợi ý từ âm thanh ────────────────────────────────────────

type AudioCue string

const (
	AudioMusic    AudioCue = "music"      // nhạc → dance/living room
	AudioWater    AudioCue = "water"      // nước → kitchen/bathroom
	AudioTV       AudioCue = "tv"         // TV → living room
	AudioKeyboard AudioCue = "keyboard"   // gõ phím → office/bedroom
	AudioSilent   AudioCue = "silent"     // yên tĩnh → sleep/focus
	AudioVoice    AudioCue = "voice"      // giọng nói → social
	AudioUnknown  AudioCue = "unknown"
)

// ─── SpaceType — loại không gian ─────────────────────────────────────────

type SpaceType string

const (
	SpaceKitchen    SpaceType = "kitchen"      // HAa1
	SpaceLivingRoom SpaceType = "living_room"  // HAb1
	SpaceBedroom    SpaceType = "bedroom"      // HAc1
	SpaceOffice     SpaceType = "office"       // HAd1
	SpaceBathroom   SpaceType = "bathroom"     // HAe1
	SpaceGym        SpaceType = "gym"          // HAf1
	SpaceOutdoor    SpaceType = "outdoor"      // HBa1
	SpaceUnknown    SpaceType = "unknown"
)

// ISLAddr trả về ISL address cho space
func (s SpaceType) ISLAddr() string {
	m := map[SpaceType]string{
		SpaceKitchen:    "HAa1",
		SpaceLivingRoom: "HAb1",
		SpaceBedroom:    "HAc1",
		SpaceOffice:     "HAd1",
		SpaceBathroom:   "HAe1",
		SpaceGym:        "HAf1",
		SpaceOutdoor:    "HBa1",
	}
	if a, ok := m[s]; ok { return a }
	return "HA??"
}

// ─── SceneUnderstanding — kết quả cuối cùng ──────────────────────────────

type SceneUnderstanding struct {
	// Hành động chính
	Action     ActionVerb
	ActionConf float64

	// Không gian suy ra
	Space      SpaceType
	SpaceConf  float64
	ISLAddr    string

	// Bằng chứng
	Evidence []string

	// Raw features
	Features map[string]MotionFeatures
}

func (s *SceneUnderstanding) Summary() string {
	return fmt.Sprintf("[%s] đang %s tại %s (conf=%.0f%%) → ISL:%s",
		s.Features["torso"].Pattern,
		s.Action, s.Space,
		s.SpaceConf*100, s.ISLAddr)
}

// ─── ActionRecognizer ─────────────────────────────────────────────────────

type ActionRecognizer struct{}

func NewActionRecognizer() *ActionRecognizer { return &ActionRecognizer{} }

// Recognize phân tích MotionClip + AudioCues → SceneUnderstanding
func (ar *ActionRecognizer) Recognize(
	clip *MotionClip,
	audio []AudioCue,
) *SceneUnderstanding {

	if clip == nil {
		return &SceneUnderstanding{
			Action: ActionUnknown, Space: SpaceUnknown,
		}
	}

	// 1. Extract features cho mỗi joint
	features := make(map[string]MotionFeatures)
	for _, track := range clip.Tracks {
		features[track.Name] = extractFeatures(track)
	}

	// 2. Classify action từ pattern combination
	action, actionConf, evidence := classifyAction(features, audio)

	// 3. Infer space từ action + audio
	space, spaceConf := inferSpace(action, audio, features)

	return &SceneUnderstanding{
		Action:     action,
		ActionConf: actionConf,
		Space:      space,
		SpaceConf:  spaceConf,
		ISLAddr:    space.ISLAddr(),
		Evidence:   evidence,
		Features:   features,
	}
}

// classifyAction từ motion patterns → ActionVerb
func classifyAction(
	features map[string]MotionFeatures,
	audio []AudioCue,
) (ActionVerb, float64, []string) {

	var evidence []string
	scores := make(map[ActionVerb]float64)

	armR := features["arm_r"]
	armL := features["arm_l"]
	legs  := features["leg_r"]
	torso := features["torso"]
	head  := features["head"]

	// ── DANCING ──────────────────────────────────────────────
	// Leg walk pattern = KHÔNG phải dancing
	legWalking := legs.Pattern == PatternWalk || legs.Pattern == PatternRun
	hasKeyboard := hasAudio(audio, AudioKeyboard)
	if armR.Circularity > 0.5 && armL.Circularity > 0.5 && !legWalking && !hasKeyboard {
		scores[ActionDancing] += 0.6
		evidence = append(evidence, fmt.Sprintf("both arms circular (%.2f, %.2f)", armR.Circularity, armL.Circularity))
	}
	if (armR.Pattern == PatternCircular || armL.Pattern == PatternCircular) && !legWalking && !hasKeyboard {
		scores[ActionDancing] += 0.3
		evidence = append(evidence, "circular arm motion")
	}
	if hasAudio(audio, AudioMusic) && !legWalking {
		scores[ActionDancing] += 0.35
		evidence = append(evidence, "music detected")
	}
	if armR.AvgY < -0.05 && armL.AvgY < -0.05 && !legWalking {
		scores[ActionDancing] += 0.2
		evidence = append(evidence, "arms raised")
	}

	// ── COOKING ──────────────────────────────────────────────
	// 1 tay oscillate (thái/khuấy), 1 tay ít động + tiếng nước
	if armR.Pattern == PatternOscillate && armL.Pattern == PatternStill {
		scores[ActionCooking] += 0.45
		evidence = append(evidence, "right arm repetitive, left arm still")
	}
	if armR.Pattern == PatternOscillate && armL.Pattern == PatternReach {
		scores[ActionCooking] += 0.35
		evidence = append(evidence, "stirring/cutting pattern")
	}
	if hasAudio(audio, AudioWater) {
		scores[ActionCooking] += 0.30
		evidence = append(evidence, "water sound")
	}
	if torso.Pattern == PatternStill && armR.FreqY > 0.4 {
		scores[ActionCooking] += 0.35
		evidence = append(evidence, fmt.Sprintf("high freq arm (%.1fHz)", armR.FreqY))
	}
	// 1 tay oscillate dọc (thái/khuấy)
	if armR.AmpY > 0.08 && armR.AmpX < 0.04 && armL.AvgVelocity < 0.004 {
		scores[ActionCooking] += 0.45
		evidence = append(evidence, "vertical arm chop/stir")
	}

	// ── TYPING ───────────────────────────────────────────────
	// Cả 2 tay oscillate thấp + tần số cao
	if armR.Pattern == PatternOscillate && armL.Pattern == PatternOscillate &&
		armR.AmpY < 0.06 && armL.AmpY < 0.06 {
		scores[ActionTyping] += 0.55
		evidence = append(evidence, "both arms low oscillation")
	}
	if hasAudio(audio, AudioKeyboard) {
		scores[ActionTyping] += 0.70
		evidence = append(evidence, "keyboard sound")
	}
	if torso.Pattern == PatternStill {
		scores[ActionTyping] += 0.15
	}

	// ── WALKING ──────────────────────────────────────────────
	if legs.Pattern == PatternWalk {
		scores[ActionWalking] += 0.85
		evidence = append(evidence, "leg walk pattern")
	}
	if armR.Pattern == PatternOscillate && legs.Pattern == PatternWalk {
		scores[ActionWalking] += 0.25
		evidence = append(evidence, "arm swing with walk")
	}

	// ── RUNNING ──────────────────────────────────────────────
	if legs.Pattern == PatternRun {
		scores[ActionRunning] += 0.80
		evidence = append(evidence, "leg run pattern")
	}

	// ── SITTING ──────────────────────────────────────────────
	if legs.Pattern == PatternSit && torso.Pattern == PatternStill {
		scores[ActionSitting] += 0.65
		evidence = append(evidence, "legs folded, torso still")
	}
	if hasAudio(audio, AudioTV) && torso.AvgVelocity < 0.010 {
		scores[ActionSitting] += 0.55
		evidence = append(evidence, "TV + low movement → sitting")
	}
	// torso mid-height + still = sitting (not lying)
	if torso.AvgY > 0.40 && torso.AvgY < 0.58 && torso.AvgVelocity < 0.008 {
		scores[ActionSitting] += 0.35
		evidence = append(evidence, fmt.Sprintf("torso mid-height (%.2f)", torso.AvgY))
	}

	// ── SLEEPING ─────────────────────────────────────────────
	if torso.AvgY > 0.55 && torso.AvgVelocity < 0.003 {
		scores[ActionSleeping] += 0.60
		evidence = append(evidence, "torso low and still")
	}
	if hasAudio(audio, AudioSilent) && head.Pattern == PatternStill {
		scores[ActionSleeping] += 0.25
		evidence = append(evidence, "silent + no head movement")
	}

	// ── EXERCISING ───────────────────────────────────────────
	if (armR.Pattern == PatternOscillate || armR.Pattern == PatternCircular) &&
		legs.Pattern == PatternOscillate {
		scores[ActionExercising] += 0.55
		evidence = append(evidence, "full body movement")
	}

	// ── CLEANING ─────────────────────────────────────────────
	if armR.Pattern == PatternOscillate && armR.AmpX > 0.08 {
		scores[ActionCleaning] += 0.40
		evidence = append(evidence, "wide horizontal arm sweep")
	}
	if hasAudio(audio, AudioWater) && armR.FreqX > 0.5 {
		scores[ActionCleaning] += 0.25
		evidence = append(evidence, "water + sweeping motion")
	}

	// ── WAVING ───────────────────────────────────────────────
	if armR.Pattern == PatternRaise && armR.FreqX > 1.0 {
		scores[ActionWaving] += 0.70
		evidence = append(evidence, "arm raised and oscillating")
	}

	// ── STRETCHING ───────────────────────────────────────────
	if armR.Pattern == PatternRaise && armL.Pattern == PatternRaise &&
		torso.Pattern == PatternStill {
		scores[ActionStretching] += 0.60
		evidence = append(evidence, "both arms raised, torso still")
	}

	// Pick best
	best, bestScore := ActionUnknown, 0.0
	for action, score := range scores {
		if score > bestScore {
			bestScore = score
			best = action
		}
	}

	// Normalize confidence
	conf := math.Min(1.0, bestScore)
	return best, conf, evidence
}

// inferSpace từ action + audio → SpaceType
func inferSpace(
	action ActionVerb,
	audio []AudioCue,
	features map[string]MotionFeatures,
) (SpaceType, float64) {

	scores := make(map[SpaceType]float64)

	// Action → space
	actionSpace := map[ActionVerb][]struct{ s SpaceType; w float64 }{
		ActionDancing:    {{SpaceLivingRoom, 0.5}, {SpaceGym, 0.3}, {SpaceOutdoor, 0.2}},
		ActionCooking:    {{SpaceKitchen, 0.90}},
		ActionCleaning:   {{SpaceKitchen, 0.4}, {SpaceBathroom, 0.4}, {SpaceLivingRoom, 0.2}},
		ActionTyping:     {{SpaceOffice, 0.6}, {SpaceBedroom, 0.3}, {SpaceLivingRoom, 0.1}},
		ActionWalking:    {{SpaceLivingRoom, 0.5}, {SpaceOutdoor, 0.3}, {SpaceOffice, 0.2}},
		ActionRunning:    {{SpaceGym, 0.5}, {SpaceOutdoor, 0.5}},
		ActionSitting:    {{SpaceLivingRoom, 0.4}, {SpaceOffice, 0.4}, {SpaceBedroom, 0.2}},
		ActionSleeping:   {{SpaceBedroom, 0.95}},
		ActionExercising: {{SpaceGym, 0.7}, {SpaceOutdoor, 0.3}},
	}
	if spaces, ok := actionSpace[action]; ok {
		for _, sp := range spaces {
			scores[sp.s] += sp.w
		}
	}

	// Audio → space
	audioSpace := map[AudioCue][]struct{ s SpaceType; w float64 }{
		AudioMusic:    {{SpaceLivingRoom, 0.4}, {SpaceGym, 0.3}},
		AudioWater:    {{SpaceKitchen, 0.5}, {SpaceBathroom, 0.5}},
		AudioTV:       {{SpaceLivingRoom, 0.85}},
		AudioKeyboard: {{SpaceOffice, 0.6}, {SpaceBedroom, 0.4}},
		AudioSilent:   {{SpaceBedroom, 0.5}, {SpaceOffice, 0.3}},
		AudioVoice:    {{SpaceLivingRoom, 0.5}, {SpaceOffice, 0.3}},
	}
	for _, cue := range audio {
		if spaces, ok := audioSpace[cue]; ok {
			for _, sp := range spaces {
				scores[sp.s] += sp.w * 0.6 // audio weight thấp hơn action
			}
		}
	}

	// Pick best
	type ss struct{ s SpaceType; score float64 }
	var ranked []ss
	for s, score := range scores { ranked = append(ranked, ss{s, score}) }
	sort.Slice(ranked, func(i, j int) bool { return ranked[i].score > ranked[j].score })

	if len(ranked) == 0 { return SpaceUnknown, 0 }

	total := 0.0
	for _, r := range ranked { total += r.score }
	conf := ranked[0].score / total
	return ranked[0].s, math.Min(1.0, conf)
}

// hasAudio helper
func hasAudio(cues []AudioCue, target AudioCue) bool {
	for _, c := range cues {
		if c == target { return true }
	}
	return false
}
