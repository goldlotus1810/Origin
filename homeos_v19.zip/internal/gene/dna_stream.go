// internal/gene/dna_stream.go
// ISLStream — DNA binary thật
//
// Thay thế DNA() string placeholder bằng chuỗi ISLAddr binary.
//
// Một "câu" trong ngôn ngữ hệ thống:
//   [ISL_entity][ISL_op][ISL_property][Spline_encoded]...
//   = []uint64 — không có text trung gian
//
// Format mỗi token (16 bytes):
//   [0:8]  ISLAddr (uint64 big-endian)
//   [8]    TokenType
//   [9:16] payload (float64 hoặc 0)
//
// TokenType:
//   0x01 = Entity   — thực thể (Sun, Earth, Human...)
//   0x02 = Op       — toán tử SDF (∪ ∖ ●...)
//   0x03 = Property — thuộc tính vật lý (Temp, Wave...)
//   0x04 = Scalar   — giá trị float64 tức thời
//   0x05 = Edge     — quan hệ (~, →, ∈)
//   0x06 = SplineRef — tham chiếu đến ScalarSpline

package gene

import (
	"encoding/binary"
	"math"
)

// TokenType phân loại vai trò của mỗi ISLAddr trong stream
type TokenType byte

const (
	TokEntity    TokenType = 0x01 // thực thể vật lý
	TokOp        TokenType = 0x02 // toán tử SDF / math
	TokProperty  TokenType = 0x03 // thuộc tính vật lý
	TokScalar    TokenType = 0x04 // giá trị float64 tức thời
	TokEdge      TokenType = 0x05 // quan hệ giữa 2 nodes
	TokSplineRef TokenType = 0x06 // tham chiếu ScalarSpline
)

// Token = 1 đơn vị trong ISLStream (16 bytes)
type Token struct {
	Addr    ISLAddr   // 8 bytes
	Type    TokenType // 1 byte
	_       [3]byte   // padding
	Payload float64   // 8 bytes — scalar value hoặc 0
}

// ISLStream = chuỗi Token — DNA binary của 1 Gene
// Đây là "câu" trong ngôn ngữ hệ thống
type ISLStream struct {
	Tokens []Token
}

// NewStream tạo ISLStream rỗng
func NewStream() *ISLStream { return &ISLStream{} }

// Entity thêm token thực thể
func (s *ISLStream) Entity(addr ISLAddr) *ISLStream {
	s.Tokens = append(s.Tokens, Token{Addr: addr, Type: TokEntity})
	return s
}

// Op thêm token toán tử SDF
func (s *ISLStream) Op(addr ISLAddr) *ISLStream {
	s.Tokens = append(s.Tokens, Token{Addr: addr, Type: TokOp})
	return s
}

// Prop thêm token thuộc tính vật lý
func (s *ISLStream) Prop(addr ISLAddr) *ISLStream {
	s.Tokens = append(s.Tokens, Token{Addr: addr, Type: TokProperty})
	return s
}

// Scalar thêm giá trị float64 tức thời
func (s *ISLStream) Scalar(addr ISLAddr, v float64) *ISLStream {
	s.Tokens = append(s.Tokens, Token{Addr: addr, Type: TokScalar, Payload: v})
	return s
}

// Edge thêm quan hệ ("has", "→", "∈")
func (s *ISLStream) Edge(addr ISLAddr) *ISLStream {
	s.Tokens = append(s.Tokens, Token{Addr: addr, Type: TokEdge})
	return s
}

// SplineRef tham chiếu ScalarSpline tại giá trị t hiện tại
func (s *ISLStream) SplineRef(addr ISLAddr, sp *ScalarSpline, t float64) *ISLStream {
	v := 0.0
	if sp != nil { v = sp.Eval(t) }
	s.Tokens = append(s.Tokens, Token{Addr: addr, Type: TokSplineRef, Payload: v})
	return s
}

// ─── Encode / Decode binary ───────────────────────────────────────

// Bytes encode ISLStream thành []byte (big-endian)
// Mỗi token = 16 bytes: [isl:8][type:1][pad:3][payload:8] = 20 bytes
// → thực tế dùng 20 bytes/token để align
func (s *ISLStream) Bytes() []byte {
	buf := make([]byte, len(s.Tokens)*20)
	for i, tok := range s.Tokens {
		off := i * 20
		binary.BigEndian.PutUint64(buf[off:], uint64(tok.Addr))
		buf[off+8] = byte(tok.Type)
		// [9:12] padding = 0
		binary.BigEndian.PutUint64(buf[off+12:], math.Float64bits(tok.Payload))
	}
	return buf
}

// DecodeStream parse []byte → ISLStream
func DecodeStream(b []byte) *ISLStream {
	s := NewStream()
	for off := 0; off+20 <= len(b); off += 20 {
		addr := ISLAddr(binary.BigEndian.Uint64(b[off:]))
		typ  := TokenType(b[off+8])
		pay  := math.Float64frombits(binary.BigEndian.Uint64(b[off+12:]))
		s.Tokens = append(s.Tokens, Token{Addr: addr, Type: typ, Payload: pay})
	}
	return s
}

// Len trả về số token
func (s *ISLStream) Len() int { return len(s.Tokens) }

// SizeBytes trả về kích thước binary (bytes)
func (s *ISLStream) SizeBytes() int { return len(s.Tokens) * 20 }

// ─── DNAStream interface ──────────────────────────────────────────
// Thêm vào Gene interface — song song với DNA() string (backward compat)

type Streamable interface {
	DNAStream(t float64) *ISLStream // t = thời điểm snapshot
}

// ─── Implement DNAStream cho các Gene ────────────────────────────

// DNAStream của SunGene tại thời điểm t ∈ [0,24]
func (s *SunGene) DNAStream(t float64) *ISLStream {
	return NewStream().
		Entity(ISL_Sun).
		Op(ISL_OpSphere).
		Scalar(ISL_OpSphere, s.Radius).
		SplineRef(ISL_SunOrbit,  nil, t/24.0).           // vị trí
		SplineRef(ISL_SunTemp,   s.Temp, t/24.0).         // 5778K
		SplineRef(ISL_SunWave,   s.Wavelength, t/24.0).   // λ nm
		SplineRef(ISL_SunLumin,  s.Luminosity, t/24.0).   // [0..1]
		SplineRef(ISL_SunMag,    s.Magnetic, t/8766.0).   // 11 năm
		Prop(ISL_SunMass).
		Scalar(ISL_SunMass, SunMassKg)
}

// DNAStream của EarthGene tại yearT ∈ [0,1] và hourOfDay
func (e *EarthGene) DNAStream(yearT float64) *ISLStream {
	return NewStream().
		Entity(ISL_Earth).
		Op(ISL_OpSphere).
		Scalar(ISL_OpSphere, e.Radius).
		SplineRef(ISL_EarthOrbit,   nil, yearT).
		SplineRef(ISL_EarthTemp,    e.SurfaceTemp, yearT).
		SplineRef(ISL_EarthAtmos,   e.AtmosPressure, 0).
		SplineRef(ISL_EarthHumid,   e.Humidity, yearT).
		SplineRef(ISL_EarthGravity, e.Gravity, 0).
		Prop(ISL_EarthMass).
		Scalar(ISL_EarthMass, EarthMassKg)
}

// DNAStream của CreatureGene tại t (giây)
func (c *CreatureGene) DNAStream(t float64) *ISLStream {
	return NewStream().
		Entity(c.Addr).
		Op(ISL_OpCapsule).   // thân
		Op(ISL_OpSphere).    // đầu
		Op(ISL_OpUnion).     // ghép lại
		SplineRef(MakeISL(LayerPhysics, GroupFrequency, byte(c.Species), 0x01, 0),
			c.HeartRate, c.Activity).
		SplineRef(MakeISL(LayerPhysics, GroupTemperature, byte(c.Species), 0x01, 0),
			c.BodyTemp, t).
		SplineRef(MakeISL(LayerPhysics, GroupFrequency, byte(c.Species), 0x02, 0),
			c.Breath, c.Activity)
}

// ─── GravityEdge DNAStream ────────────────────────────────────────

func (ge *GravityEdge) DNAStream() *ISLStream {
	r := ge.DistFn()
	f := ge.Force()
	return NewStream().
		Edge(ge.From).
		Edge(ge.To).
		Prop(ISL_ConstG).
		Scalar(ISL_ConstG, G).
		Prop(ISL_EarthMass).
		Scalar(ISL_EarthMass, ge.MassA).
		Prop(ISL_SunMass).
		Scalar(ISL_SunMass, ge.MassB).
		Scalar(ISL_ConstG, r). // r hiện tại
		Scalar(ISL_ConstG, f)  // F hiện tại
}
