package gene

import (
	"testing"
)

func TestISLRouter(t *testing.T) {
	ws := NewWorldScene()
	ws.Clock.HourOfDay = 12.0

	nodes := ws.SpatialNodes()
	router := NewISLRouter(nodes, 5.0)

	t.Log("=== ISLRouter: SDF value → ISLAddr routing ===")

	// 1. Probe bên trong Earth (r=12)
	p1 := Vec3{X: 0, Y: 5, Z: 0}
	r1 := router.Route(p1)
	t.Logf("p(0,5,0)    → %s", r1)
	if r1.TargetAddr != uint64(ISL_Earth) {
		t.Errorf("expect ISL_Earth %016x, got %016x", uint64(ISL_Earth), r1.TargetAddr)
	}
	if !r1.Inside    { t.Error("phải Inside") }
	if !r1.Confident { t.Error("phải Confident") }

	// 2. Probe gần bề mặt Earth (dist=1.0 < threshold=5.0)
	p2 := Vec3{X: 0, Y: 13.0, Z: 0}
	r2 := router.Route(p2)
	t.Logf("p(0,13,0)   → %s", r2)
	if !r2.Confident {
		t.Errorf("dist=%.2f < threshold=5 phải confident", r2.Dist)
	}

	// 3. Probe rất xa — uncertain
	p3 := Vec3{X: 100, Y: 100, Z: 100}
	r3 := router.Route(p3)
	t.Logf("p(100,100)  → %s", r3)
	if r3.Confident {
		t.Errorf("xa 100 units (dist=%.1f) phải uncertain", r3.Dist)
	}

	// 4. RouteAll — 16 điểm ProbeRing r=10 (trong Earth)
	ring := ProbeRing(Vec3{}, 10.0, 16)
	results := router.RouteAll(ring)
	inside := 0
	for _, res := range results { if res.Inside { inside++ } }
	t.Logf("ProbeRing r=10 (16 pts): %d/16 inside", inside)
	if inside < 12 { t.Errorf("ring r=10 < Earth r=12, phải nhiều inside: %d/16", inside) }

	// 5. Dominant — grid 4×4×4 step=3 quanh Earth
	grid := ProbeGrid(Vec3{}, 3.0, 4)
	domAddr, domCount := router.Dominant(grid)
	t.Logf("Dominant grid 4×4×4 step=3 (%d pts): addr=%016x count=%d",
		len(grid), domAddr, domCount)
	if domAddr == uint64(ISL_Earth) {
		t.Log("  → ISL_Earth chiếm ưu thế ✓")
	}

	// 6. Tally — phân bố route
	tally := router.Tally(results)
	t.Log("Tally ProbeRing:")
	for addr, cnt := range tally {
		label := router.Route(Vec3{}).Label
		_ = label
		t.Logf("  %016x  × %d", addr, cnt)
	}

	t.Log("\n✓ ISLRouter: SDF → ISLAddr, không hardcode địa chỉ")
}
