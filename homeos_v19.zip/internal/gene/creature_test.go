package gene

import "testing"

func TestCreatureGene(t *testing.T) {
	human := NewCreatureGene(SpeciesHuman)
	dog   := NewCreatureGene(SpeciesDog)
	bird  := NewCreatureGene(SpeciesBird)

	t.Logf("ISL addresses:")
	t.Logf("  Human = %016x", uint64(human.Addr))
	t.Logf("  Dog   = %016x", uint64(dog.Addr))
	t.Logf("  Bird  = %016x", uint64(bird.Addr))

	t.Logf("\nSDF tại gốc tọa độ:")
	for _, c := range []*CreatureGene{human, dog, bird} {
		d := c.SDF(Vec3{0, 0, 5}) // điểm cách 5 đơn vị
		t.Logf("  species=%d  h=%.2f  SDF=%.2f", c.Species, c.Height, d)
	}

	t.Logf("\nSinh lý theo mức hoạt động:")
	for _, act := range []float64{0.0, 0.5, 1.0} {
		human.SetActivity(act)
		label := []string{"ngủ", "đi", "chạy"}[int(act*2)]
		t.Logf("  [%s] HR=%.0fbpm  breath=%.0f/phút  T=%.2fK",
			label,
			human.HeartRateAt(),
			human.BreathRateAt(),
			human.BodyTempAt(0),
		)
	}

	t.Logf("\nSo sánh loài (activity=0.5):")
	for _, c := range []*CreatureGene{human, dog, bird} {
		c.SetActivity(0.5)
		t.Logf("  species=%d  HR=%.0fbpm  breath=%.0f/phút  T=%.1f°C",
			c.Species, c.HeartRateAt(), c.BreathRateAt(),
			c.BodyTempAt(0)-273.15)
	}

	t.Logf("\nBreath phase (human đi bộ, t=0..2s):")
	human.SetActivity(0.5)
	for _, sec := range []float64{0, 0.5, 1.0, 1.5, 2.0} {
		bp := human.BreathPhase(sec)
		t.Logf("  t=%.1fs  breathPhase=%.2f", sec, bp)
	}

	// Assertions
	human.SetActivity(1.0)
	hrRun := human.HeartRateAt()
	human.SetActivity(0.0)
	hrRest := human.HeartRateAt()
	if hrRun <= hrRest {
		t.Errorf("HR chạy %.0f <= HR nghỉ %.0f", hrRun, hrRest)
	}
	t.Logf("\nHR nghỉ=%.0f < HR chạy=%.0f ✓", hrRest, hrRun)

	// Bird tim nhanh hơn human
	bird.SetActivity(0.5)
	human.SetActivity(0.5)
	if bird.HeartRateAt() <= human.HeartRateAt() {
		t.Error("Bird HR phải cao hơn Human")
	}
	t.Logf("Human HR=%.0f < Bird HR=%.0f ✓", human.HeartRateAt(), bird.HeartRateAt())
}
