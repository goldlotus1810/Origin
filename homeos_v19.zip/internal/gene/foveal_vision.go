// FovealVision — vùng nhìn trung tâm độ phân giải cao + ngoại vi thấp
// Mô phỏng mắt người: trung tâm rõ nét, ngoại vi blur
// Dùng Quadtree để tìm skeleton trong vùng fovea
package gene

import "math"

// FovealZone — vùng nhìn
type FovealZone int

const (
	ZoneFovea    FovealZone = iota // trung tâm — phân tích chi tiết
	ZoneParafovea                  // vùng cận — phát hiện chuyển động
	ZonePeriphery                  // ngoại vi — chỉ phát hiện có/không
)

// FovealTarget — skeleton đang được fovea track
type FovealTarget struct {
	SkeletonID string
	Zone       FovealZone
	Confidence float64 // 0..1
	Priority   int     // cao hơn = quan trọng hơn
}

// FovealVision — quản lý attention của camera
type FovealVision struct {
	CenterX, CenterY float64 // tâm nhìn hiện tại (0..1 normalized)
	FoveaRadius      float64 // bán kính fovea (normalized)
	qt               *Quadtree
	targets          []FovealTarget
}

func NewFovealVision() *FovealVision {
	return &FovealVision{
		CenterX:     0.5,
		CenterY:     0.5,
		FoveaRadius: 0.2, // 20% frame width
		qt:          NewQuadtree(Rect{0, 0, 1, 1}),
	}
}

// Update — nhận list skeleton mới, phân loại vào zones
func (f *FovealVision) Update(skeletons []*SDFSkeleton) []FovealTarget {
	f.qt.Clear()
	f.targets = f.targets[:0]

	for _, sk := range skeletons {
		if sk == nil {
			continue
		}
		cx, cy := sk.CenterX(), sk.CenterY()
		f.qt.Insert(QPoint{X: cx, Y: cy, Data: sk})

		zone, conf := f.classify(cx, cy)
		f.targets = append(f.targets, FovealTarget{
			SkeletonID: sk.ID,
			Zone:       zone,
			Confidence: conf,
			Priority:   f.priority(zone, conf),
		})
	}

	// Sắp xếp: priority cao lên đầu
	sortTargets(f.targets)
	return f.targets
}

// MoveFovea — dịch chuyển điểm nhìn về phía target ưu tiên cao nhất
func (f *FovealVision) MoveFovea(targets []FovealTarget, skeletons []*SDFSkeleton) {
	if len(targets) == 0 {
		return
	}
	// Tìm skeleton của target ưu tiên cao nhất
	top := targets[0]
	for _, sk := range skeletons {
		if sk.ID == top.SkeletonID {
			// Smooth tracking — không nhảy ngay
			f.CenterX += (sk.CenterX() - f.CenterX) * 0.3
			f.CenterY += (sk.CenterY() - f.CenterY) * 0.3
			return
		}
	}
}

// InFovea — kiểm tra skeleton có trong vùng trung tâm không
func (f *FovealVision) InFovea(sk *SDFSkeleton) bool {
	d := math.Sqrt(dist2(sk.CenterX(), sk.CenterY(), f.CenterX, f.CenterY))
	return d <= f.FoveaRadius
}

// NearestToCenter — skeleton gần tâm nhất
func (f *FovealVision) NearestToCenter() *QPoint {
	return f.qt.Nearest(f.CenterX, f.CenterY)
}

func (f *FovealVision) classify(x, y float64) (FovealZone, float64) {
	d := math.Sqrt(dist2(x, y, f.CenterX, f.CenterY))
	switch {
	case d <= f.FoveaRadius:
		conf := 1.0 - d/f.FoveaRadius*0.3
		return ZoneFovea, conf
	case d <= f.FoveaRadius*2.5:
		conf := 0.7 - (d-f.FoveaRadius)/(f.FoveaRadius*1.5)*0.3
		return ZoneParafovea, conf
	default:
		conf := math.Max(0.1, 0.4-(d-f.FoveaRadius*2.5)*0.5)
		return ZonePeriphery, conf
	}
}

func (f *FovealVision) priority(z FovealZone, conf float64) int {
	base := map[FovealZone]int{
		ZoneFovea: 100, ZoneParafovea: 50, ZonePeriphery: 10,
	}[z]
	return base + int(conf*20)
}

func sortTargets(t []FovealTarget) {
	// Insertion sort — list nhỏ (<20 skeletons)
	for i := 1; i < len(t); i++ {
		j := i
		for j > 0 && t[j].Priority > t[j-1].Priority {
			t[j], t[j-1] = t[j-1], t[j]
			j--
		}
	}
}
