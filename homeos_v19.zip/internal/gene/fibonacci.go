// internal/gene/fibonacci.go
//
// FIBONACCI ANALYZER
// ===================
// MASTER.md §1.3: "VisionChief không so sánh pixel.
//                  VisionChief phân tích cấu trúc SDF + Fibonacci"
//
// φ = 1.618... — tỉ lệ vàng trong tự nhiên:
//   Xương người   → tỉ lệ đốt ngón tay = φ
//   Vỏ ốc sên    → r(θ) = a·e^(b·θ), b = ln(φ)/(π/2)
//   Cánh hoa     → phyllotaxis 137.5° = 360°/φ²
//
// Pipeline nhận diện:
//   image → FBM SDF approximation → FibScore → ISLAddress
//   "nhận diện = tìm ISLAddress có cấu trúc Fibonacci khớp"

package gene

import (
	"math"
	"sort"
)

const (
	Phi        = 1.6180339887498948482
	GoldenAngle = 2.3998315 // 137.507...° in radians = 2π/φ²
	PhiEps     = 0.05       // tolerance cho isFibRatio
)

// ── IsFibRatio ────────────────────────────────────────────────

// IsFibRatio kiểm tra a/b ≈ φ hoặc b/a ≈ φ
// MASTER.md: "isFibRatio(a, b float64) bool: return |a/b − φ| < ε"
func IsFibRatio(a, b float64) bool {
	if b < 1e-10 || a < 1e-10 {
		return false
	}
	r := a / b
	return math.Abs(r-Phi) < PhiEps || math.Abs(r-1/Phi) < PhiEps
}

// IsFibSequence kiểm tra một dãy số có theo tỉ lệ Fibonacci không
// Trả về score [0..1]
func IsFibSequence(vals []float64) float64 {
	if len(vals) < 2 {
		return 0
	}
	hits := 0
	for i := 1; i < len(vals); i++ {
		if IsFibRatio(vals[i], vals[i-1]) {
			hits++
		}
	}
	return float64(hits) / float64(len(vals)-1)
}

// ── DetectSpiral ──────────────────────────────────────────────

// SpiralResult kết quả phân tích spiral
type SpiralResult struct {
	Score      float64 // [0..1] — 1 = perfect golden spiral
	GrowthRate float64 // b trong r = a·e^(b·θ)
	NumArms    int     // số cánh xoắn
}

// DetectSpiral phân tích SDF theo θ ∈ [0, 2π] tìm golden spiral
// MASTER.md: "detectSpiral(sdf func(Vec3)float64) float64:
//             → tích phân ∂sdf/∂θ theo θ ∈ [0, 2π]"
func DetectSpiral(sdf func(Vec3) float64) SpiralResult {
	const (
		radialSteps  = 32
		angularSteps = 128
		maxR         = 0.45
	)

	// Lấy mẫu ∂sdf/∂θ tại các r khác nhau
	type polarSample struct {
		r, theta, val float64
	}
	var samples []polarSample

	for ri := 1; ri <= radialSteps; ri++ {
		r := float64(ri) / float64(radialSteps) * maxR
		for ti := 0; ti < angularSteps; ti++ {
			theta := float64(ti) / float64(angularSteps) * 2 * math.Pi
			p := Vec3{
				X: r * math.Cos(theta),
				Y: r * math.Sin(theta),
			}
			samples = append(samples, polarSample{r, theta, sdf(p)})
		}
	}

	// Tìm zerocrossings của SDF (bề mặt ký tự)
	// Trong spiral: khoảng cách giữa các zero crossing ~ r * φ
	var zeros []float64
	for ri := 1; ri <= radialSteps; ri++ {
		r := float64(ri) / float64(radialSteps) * maxR
		offset := (ri - 1) * angularSteps
		for ti := 0; ti < angularSteps-1; ti++ {
			v1 := samples[offset+ti].val
			v2 := samples[offset+ti+1].val
			if v1*v2 < 0 { // sign change = zero crossing
				theta := float64(ti) / float64(angularSteps) * 2 * math.Pi
				zeros = append(zeros, r*theta) // arc length
			}
		}
	}

	if len(zeros) < 3 {
		return SpiralResult{}
	}

	sort.Float64s(zeros)

	// Tính tỉ lệ giữa các zero crossing liên tiếp
	var ratios []float64
	for i := 1; i < len(zeros); i++ {
		if zeros[i-1] > 1e-10 {
			ratios = append(ratios, zeros[i]/zeros[i-1])
		}
	}

	fibScore := IsFibSequence(ratios)

	// Growth rate b: trong golden spiral r = a·e^(b·θ)
	// b = ln(φ) / (π/2) ≈ 0.3063
	theoreticalB := math.Log(Phi) / (math.Pi / 2)
	var measuredB float64
	if len(zeros) >= 2 && zeros[0] > 1e-10 {
		measuredB = math.Log(zeros[len(zeros)-1]/zeros[0]) /
			float64(len(zeros)-1)
	}

	growthMatch := 0.0
	if measuredB > 0 {
		growthMatch = 1 - math.Min(1, math.Abs(measuredB-theoreticalB)/theoreticalB)
	}

	score := (fibScore*2 + growthMatch) / 3

	return SpiralResult{
		Score:      score,
		GrowthRate: measuredB,
		NumArms:    estimateArms(zeros),
	}
}

func estimateArms(zeros []float64) int {
	if len(zeros) < 2 {
		return 1
	}
	// Đếm số cụm zero crossing
	clusters := 1
	threshold := zeros[len(zeros)-1] / float64(len(zeros)) * 0.5
	for i := 1; i < len(zeros); i++ {
		if zeros[i]-zeros[i-1] > threshold {
			clusters++
		}
	}
	return clusters
}

// ── SDFProfile — phân tích cấu trúc SDF thành feature vector ─

// SDFProfile là vector đặc trưng của một SDF, dùng để match với ISLAddress
type SDFProfile struct {
	// Fibonacci spiral score [0..1]
	SpiralScore float64

	// Số nét chính (strokes) trong ký tự
	StrokeCount int

	// Tỉ lệ chiều cao/chiều rộng
	AspectRatio float64

	// Đối xứng [0..1]: 1 = hoàn toàn đối xứng
	SymmetryScore float64

	// Tỉ lệ Fibonacci của các khoảng cách nét chính
	FibStrokeScore float64
}

// ProfileSDF tính SDFProfile của một hàm SDF
func ProfileSDF(sdf func(Vec3) float64) SDFProfile {
	prof := SDFProfile{}

	// Spiral score
	spiral := DetectSpiral(sdf)
	prof.SpiralScore = spiral.Score

	// Sample trên grid 20×20 để tìm bề mặt
	const n = 20
	var surfacePoints []Vec3
	for i := 0; i < n; i++ {
		for j := 0; j < n; j++ {
			x := float64(i)/float64(n-1)*0.9 - 0.45
			y := float64(j)/float64(n-1)*0.9 - 0.45
			p := Vec3{X: x, Y: y}
			if math.Abs(sdf(p)) < 0.06 {
				surfacePoints = append(surfacePoints, p)
			}
		}
	}

	if len(surfacePoints) < 4 {
		return prof
	}

	// Bounding box → aspect ratio
	minX, maxX := surfacePoints[0].X, surfacePoints[0].X
	minY, maxY := surfacePoints[0].Y, surfacePoints[0].Y
	for _, p := range surfacePoints {
		if p.X < minX {
			minX = p.X
		}
		if p.X > maxX {
			maxX = p.X
		}
		if p.Y < minY {
			minY = p.Y
		}
		if p.Y > maxY {
			maxY = p.Y
		}
	}
	w := maxX - minX
	h := maxY - minY
	if w > 1e-10 {
		prof.AspectRatio = h / w
	}

	// Symmetry: so sánh left half vs right half
	leftHits, rightHits, matches := 0, 0, 0
	for i := 0; i < n; i++ {
		for j := 0; j < n; j++ {
			x := float64(i)/float64(n-1)*0.9 - 0.45
			y := float64(j)/float64(n-1)*0.9 - 0.45
			vL := sdf(Vec3{X: x, Y: y})
			vR := sdf(Vec3{X: -x, Y: y})
			if vL < 0 {
				leftHits++
			}
			if vR < 0 {
				rightHits++
			}
			if (vL < 0) == (vR < 0) {
				matches++
			}
		}
	}
	prof.SymmetryScore = float64(matches) / float64(n*n)

	return prof
}

// ── MatchProfiles — so sánh 2 SDFProfile ─────────────────────

// ProfileDistance tính khoảng cách cosine giữa 2 SDFProfile
// 0 = giống hệt, 1 = hoàn toàn khác
func ProfileDistance(a, b SDFProfile) float64 {
	// Feature vector
	va := [4]float64{a.SpiralScore, a.AspectRatio, a.SymmetryScore, a.FibStrokeScore}
	vb := [4]float64{b.SpiralScore, b.AspectRatio, b.SymmetryScore, b.FibStrokeScore}

	dot, na, nb := 0.0, 0.0, 0.0
	for i := 0; i < 4; i++ {
		dot += va[i] * vb[i]
		na += va[i] * va[i]
		nb += vb[i] * vb[i]
	}
	if na < 1e-10 || nb < 1e-10 {
		return 1.0
	}
	cos := dot / (math.Sqrt(na) * math.Sqrt(nb))
	return 1.0 - cos
}
