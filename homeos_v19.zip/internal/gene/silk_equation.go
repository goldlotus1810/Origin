// internal/gene/silk_equation.go
//
// SilkEquation — lưu PHƯƠNG TRÌNH, không lưu samples
//
// QT3: Toán học trừu tượng → Vật lý là sự thật
//   Không lưu "nấu ăn lần 1", "nấu ăn lần 2"...
//   Lưu: f(cooking) = spline control points + fourier coefficients
//   Mọi instance = evaluate phương trình tại t
//
// 3 loại phương trình:
//   MotionEq  — Spline fit (Catmull-Rom control points)
//   AudioEq   — Fourier fit (N coefficients)
//   SceneEq   — SDF params (primitives)
//
// Worker tự quyết (Điểm 3):
//   Chief training → threshold ban đầu
//   SeenCount tăng → Worker tự tin hơn
//   Anomaly = |sample - equation(t)| > threshold
//   Báo Chief khi bất thường, không báo khi bình thường

package gene

import (
	"fmt"
	"math"
)

// ─── MotionEquation — Spline fit cho motion ───────────────────────────────

// MotionEquation lưu Catmull-Rom control points cho mỗi joint
// Không lưu 90 keyframes — chỉ lưu 4-6 control points
type MotionEquation struct {
	ID       string
	Action   ActionVerb
	Species  string

	// Control points cho mỗi joint (4 points = Catmull-Rom)
	// Đủ để reconstruct toàn bộ trajectory
	Controls map[string][]JointKeyframe // joint → 4-6 control points

	// Fit quality
	RMSE      float64 // root mean square error vs original
	Period    float64 // chu kỳ lặp (giây), 0 = không lặp

	// Learning state
	SeenCount   int
	Threshold   float64 // Chief set, Worker tự điều chỉnh
	SelfTuned   bool    // đã tự tune chưa
}

// Evaluate: tính vị trí joint tại thời điểm t
func (eq *MotionEquation) Evaluate(joint string, t float64) (cx, cy float64) {
	pts, ok := eq.Controls[joint]
	if !ok || len(pts) < 2 { return 0.5, 0.5 }

	// Normalize t vào period
	if eq.Period > 0 {
		t = math.Mod(t, eq.Period)
	}
	dur := pts[len(pts)-1].T - pts[0].T
	if dur < 1e-9 { return pts[0].CX, pts[0].CY }
	t = pts[0].T + t/dur*(pts[len(pts)-1].T-pts[0].T)

	// Tìm segment
	for i := 1; i < len(pts); i++ {
		if pts[i].T >= t || i == len(pts)-1 {
			// Linear interp (simple, đủ dùng)
			a, b := pts[i-1], pts[i]
			dt := b.T - a.T
			if dt < 1e-9 { return a.CX, a.CY }
			u := (t - a.T) / dt
			return a.CX + u*(b.CX-a.CX), a.CY + u*(b.CY-a.CY)
		}
	}
	return pts[len(pts)-1].CX, pts[len(pts)-1].CY
}

// Anomaly: khoảng cách từ observation đến equation
// > threshold → bất thường → Worker báo Chief
func (eq *MotionEquation) Anomaly(joint string, t, cx, cy float64) float64 {
	ex, ey := eq.Evaluate(joint, t)
	dx, dy := cx-ex, cy-ey
	return math.Sqrt(dx*dx + dy*dy)
}

// SelfTune: sau khi thấy đủ lần, Worker tự điều chỉnh threshold
func (eq *MotionEquation) SelfTune() {
	if eq.SeenCount < 5 { return }
	// Càng thấy nhiều → càng tự tin → threshold chặt hơn
	// SeenCount=5  → threshold giữ nguyên
	// SeenCount=20 → threshold giảm 30% (nhạy hơn)
	// SeenCount=50 → threshold giảm 50%
	factor := 1.0 - math.Min(0.5, float64(eq.SeenCount-5)*0.01)
	eq.Threshold *= factor
	eq.SelfTuned = true
}

// FitMotionEquation: từ MotionClip → MotionEquation
// Lấy ~6 control points đại diện (không phải tất cả 90 frames)
func FitMotionEquation(clip *MotionClip, action ActionVerb, species string, initThreshold float64) *MotionEquation {
	eq := &MotionEquation{
		ID:        fmt.Sprintf("meq_%s_%s", action, species[:4]),
		Action:    action,
		Species:   species,
		Controls:  make(map[string][]JointKeyframe),
		Threshold: initThreshold,
		SeenCount: 1,
	}

	totalRMSE := 0.0
	trackCount := 0

	for _, track := range clip.Tracks {
		kfs := track.Keyframes
		if len(kfs) < 4 { continue }

		// Lấy N control points đều nhau
		N := 6
		if len(kfs) < N { N = len(kfs) }
		controls := make([]JointKeyframe, N)
		for i := 0; i < N; i++ {
			idx := i * (len(kfs) - 1) / (N - 1)
			controls[i] = kfs[idx]
		}
		eq.Controls[track.Name] = controls

		// Detect period: tìm chu kỳ lặp
		if eq.Period == 0 {
			eq.Period = detectPeriod(kfs)
		}

		// Tính RMSE
		rmse := 0.0
		for _, k := range kfs {
			ex, ey := eq.Evaluate(track.Name, k.T)
			rmse += (k.CX-ex)*(k.CX-ex) + (k.CY-ey)*(k.CY-ey)
		}
		totalRMSE += math.Sqrt(rmse / float64(len(kfs)))
		trackCount++
	}

	if trackCount > 0 {
		eq.RMSE = totalRMSE / float64(trackCount)
	}
	return eq
}

// detectPeriod tìm chu kỳ lặp của joint track
func detectPeriod(kfs []JointKeyframe) float64 {
	if len(kfs) < 8 { return 0 }
	// Zero crossing của CX deviation từ mean
	mx := 0.0
	for _, k := range kfs { mx += k.CX }
	mx /= float64(len(kfs))

	crossings := []float64{}
	for i := 1; i < len(kfs); i++ {
		if (kfs[i].CX-mx)*(kfs[i-1].CX-mx) < 0 {
			crossings = append(crossings, kfs[i].T)
		}
	}
	if len(crossings) < 4 { return 0 }
	// Period = 2 × khoảng cách trung bình giữa crossings
	gaps := 0.0
	for i := 1; i < len(crossings); i++ {
		gaps += crossings[i] - crossings[i-1]
	}
	return 2 * gaps / float64(len(crossings)-1)
}

// ─── AudioEquation — Fourier fit ─────────────────────────────────────────

// AudioEquation lưu N Fourier coefficients
// Không lưu waveform — lưu phương trình tạo ra nó
type AudioEquation struct {
	ID     string
	Cues   []AudioCue

	// Fourier: a_n * cos(2π*n*t/T) + b_n * sin(2π*n*t/T)
	// 8 harmonics đủ cho nhận dạng âm thanh
	Harmonics [8][2]float64 // [n][a,b]
	Fundamental float64     // tần số cơ bản (Hz)

	SeenCount int
	Threshold float64
	SelfTuned bool
}

// Synthesize: tái tạo waveform tại t (Hz)
func (eq *AudioEquation) Synthesize(t float64) float64 {
	v := 0.0
	for n, h := range eq.Harmonics {
		freq := eq.Fundamental * float64(n+1)
		v += h[0]*math.Cos(2*math.Pi*freq*t) + h[1]*math.Sin(2*math.Pi*freq*t)
	}
	return v
}

// BandEnergy: năng lượng tại band n
func (eq *AudioEquation) BandEnergy(n int) float64 {
	if n >= 8 { return 0 }
	a, b := eq.Harmonics[n][0], eq.Harmonics[n][1]
	return math.Sqrt(a*a + b*b)
}

// Anomaly: khoảng cách spectral từ observation đến equation
func (eq *AudioEquation) Anomaly(bands [8]float64) float64 {
	dist := 0.0
	for n := 0; n < 8; n++ {
		exp := eq.BandEnergy(n)
		diff := bands[n] - exp
		dist += diff * diff
	}
	return math.Sqrt(dist / 8)
}

func (eq *AudioEquation) SelfTune() {
	if eq.SeenCount < 5 { return }
	factor := 1.0 - math.Min(0.5, float64(eq.SeenCount-5)*0.01)
	eq.Threshold *= factor
	eq.SelfTuned = true
}

// FitAudioEquation: từ frequency bands → AudioEquation
func FitAudioEquation(cues []AudioCue, bands [8]float64, fundamental float64, initThreshold float64) *AudioEquation {
	eq := &AudioEquation{
		Cues:        cues,
		Fundamental: fundamental,
		SeenCount:   1,
		Threshold:   initThreshold,
	}
	// Convert bands → Fourier coefficients
	// Band n → harmonic n với power = bands[n]
	for n := 0; n < 8; n++ {
		// Simple: a_n = band energy, b_n = 0 (phase unknown)
		eq.Harmonics[n] = [2]float64{bands[n], bands[n] * 0.1}
	}
	return eq
}

// ─── EquationLibrary — lưu phương trình, không lưu samples ──────────────

type EquationLibrary struct {
	MotionEqs []*MotionEquation
	AudioEqs  []*AudioEquation

	// Config từ Chief training
	MotionThreshold float64
	AudioThreshold  float64

	SeenTotal  int
	SavedTotal int
}

func NewEquationLibrary(motionThresh, audioThresh float64) *EquationLibrary {
	return &EquationLibrary{
		MotionThreshold: motionThresh,
		AudioThreshold:  audioThresh,
	}
}

// LearnMotion: thấy motion mới → fit equation hoặc update existing
func (lib *EquationLibrary) LearnMotion(
	clip *MotionClip,
	action ActionVerb,
	species string,
) (isNew bool, anomaly float64, eq *MotionEquation) {
	lib.SeenTotal++

	// Tìm equation gần nhất
	bestEq, bestAnomaly := (*MotionEquation)(nil), math.MaxFloat64
	for _, e := range lib.MotionEqs {
		if e.Action != action { continue }
		// Đánh giá fit của equation này với clip
		anom := evalMotionFit(e, clip)
		if anom < bestAnomaly {
			bestAnomaly = anom
			bestEq = e
		}
	}

	// Đã biết
	if bestEq != nil && bestAnomaly < bestEq.Threshold {
		bestEq.SeenCount++
		bestEq.SelfTune()
		return false, bestAnomaly, bestEq
	}

	// Chưa biết → fit equation mới
	newEq := FitMotionEquation(clip, action, species, lib.MotionThreshold)
	newEq.ID = fmt.Sprintf("meq_%03d_%s", lib.SavedTotal+1, action)
	lib.MotionEqs = append(lib.MotionEqs, newEq)
	lib.SavedTotal++
	return true, bestAnomaly, newEq
}

// LearnAudio: tương tự cho âm thanh
func (lib *EquationLibrary) LearnAudio(
	cues []AudioCue,
	bands [8]float64,
) (isNew bool, anomaly float64, eq *AudioEquation) {
	lib.SeenTotal++

	bestEq, bestAnomaly := (*AudioEquation)(nil), math.MaxFloat64
	for _, e := range lib.AudioEqs {
		anom := e.Anomaly(bands)
		if anom < bestAnomaly {
			bestAnomaly = anom
			bestEq = e
		}
	}

	if bestEq != nil && bestAnomaly < bestEq.Threshold {
		bestEq.SeenCount++
		bestEq.SelfTune()
		return false, bestAnomaly, bestEq
	}

	newEq := FitAudioEquation(cues, bands, 440, lib.AudioThreshold)
	newEq.ID = fmt.Sprintf("aeq_%03d_%s", lib.SavedTotal+1, cueLabel(cues))
	lib.AudioEqs = append(lib.AudioEqs, newEq)
	lib.SavedTotal++
	return true, bestAnomaly, newEq
}

// AnomalyCheck: Worker check observation có bất thường không
// → true = báo Chief
// Độ thông minh: SeenCount cao → threshold thấp → nhạy hơn
type AnomalyReport struct {
	IsAnomaly bool
	Score     float64  // anomaly score
	EqID      string   // equation reference
	Reason    string
}

func (lib *EquationLibrary) CheckMotionAnomaly(
	joint string, t, cx, cy float64,
	action ActionVerb,
) AnomalyReport {
	for _, eq := range lib.MotionEqs {
		if eq.Action != action { continue }
		score := eq.Anomaly(joint, t, cx, cy)
		if score > eq.Threshold {
			return AnomalyReport{
				IsAnomaly: true,
				Score:     score,
				EqID:      eq.ID,
				Reason: fmt.Sprintf("joint %s deviation=%.3f > threshold=%.3f (seen=%d)",
					joint, score, eq.Threshold, eq.SeenCount),
			}
		}
		return AnomalyReport{IsAnomaly: false, Score: score, EqID: eq.ID}
	}
	// Không có equation → chắc chắn bất thường
	return AnomalyReport{IsAnomaly: true, Score: 1.0, Reason: "no equation for " + string(action)}
}

// evalMotionFit đánh giá equation fit với clip
func evalMotionFit(eq *MotionEquation, clip *MotionClip) float64 {
	total, count := 0.0, 0
	for _, track := range clip.Tracks {
		for _, k := range track.Keyframes {
			anom := eq.Anomaly(track.Name, k.T, k.CX, k.CY)
			total += anom
			count++
		}
	}
	if count == 0 { return math.MaxFloat64 }
	return total / float64(count)
}

func cueLabel(cues []AudioCue) string {
	if len(cues) == 0 { return "silent" }
	return string(cues[0])
}

// ─── Storage comparison ───────────────────────────────────────────────────

func EquationStorageBytes(eq *MotionEquation) int {
	// ID(20) + Action(12) + Species(20) + Period(8) + RMSE(8) + Threshold(8)
	header := 76
	// Controls: joints × N_control_points × (T+CX+CY) = joints × 6 × 24
	controls := len(eq.Controls) * 6 * 24
	return header + controls
}

func SampleStorageBytes(nKeyframes int) int {
	// Mỗi keyframe: T+CX+CY+Rotation+ScaleX+ScaleY = 6×8 = 48B
	// 5 joints × 90 frames × 48B
	return 5 * nKeyframes * 48
}
