// internal/gene/motion_library.go
//
// MotionLibrary — chỉ lưu mẫu chưa có
//
// QT7: ĐN → QR
//   Quan sát mẫu mới → so sánh với library
//   Đã biết (sim > threshold) → bỏ
//   Chưa biết → lưu vào library
//
// Tương tự AudioLibrary cho âm thanh

package gene

import (
	"fmt"
	"math"
	"sort"
)

// ─── MotionSignature — đặc trưng gọn của 1 mẫu chuyển động ──────────────
// Không lưu toàn bộ keyframes — chỉ lưu fingerprint

type MotionSignature struct {
	ID       string          // "dancing_001", "cooking_002"...
	Action   ActionVerb
	Species  string
	SpaceCtx SpaceType

	// Fingerprint: 5 joints × 4 features = 20 float64
	// AmpX, AmpY, FreqY, Circularity mỗi joint
	Joints map[string][4]float64

	// Metadata
	Confidence float64
	SeenCount  int    // bao nhiêu lần đã gặp pattern này
}

// similarity: 0=khác hoàn toàn, 1=giống hệt
func (a *MotionSignature) Similarity(b *MotionSignature) float64 {
	if a.Action != b.Action { return 0.0 }

	total, count := 0.0, 0
	for joint, fa := range a.Joints {
		fb, ok := b.Joints[joint]
		if !ok { continue }
		// Cosine-like similarity giữa 4-vector
		dot, na, nb := 0.0, 0.0, 0.0
		for i := 0; i < 4; i++ {
			dot += fa[i] * fb[i]
			na  += fa[i] * fa[i]
			nb  += fb[i] * fb[i]
		}
		if na < 1e-9 || nb < 1e-9 { continue }
		sim := dot / (math.Sqrt(na) * math.Sqrt(nb))
		total += sim
		count++
	}
	if count == 0 { return 0 }
	return total / float64(count)
}

// extractSignature từ MotionClip → MotionSignature gọn
func extractSignature(clip *MotionClip, action ActionVerb, species string, space SpaceType) *MotionSignature {
	sig := &MotionSignature{
		Action:     action,
		Species:    species,
		SpaceCtx:   space,
		Confidence: 1.0,
		SeenCount:  1,
		Joints:     make(map[string][4]float64),
	}
	for _, track := range clip.Tracks {
		f := extractFeatures(track)
		sig.Joints[track.Name] = [4]float64{
			f.AmpX, f.AmpY, f.FreqY, f.Circularity,
		}
	}
	return sig
}

// ─── MotionLibrary ────────────────────────────────────────────────────────

type MotionLibrary struct {
	Signatures  []*MotionSignature
	Threshold   float64 // sim > threshold → đã biết
	SeenTotal   int     // tổng số mẫu đã xem
	SavedTotal  int     // tổng số mẫu đã lưu
}

func NewMotionLibrary(threshold float64) *MotionLibrary {
	return &MotionLibrary{Threshold: threshold}
}

type LearnResult struct {
	IsNew      bool    // chưa biết → đã lưu
	Similarity float64 // similarity với mẫu gần nhất
	MatchID    string  // ID của mẫu giống nhất (nếu đã biết)
	Saved      *MotionSignature
}

// Learn: xem mẫu mới, quyết định lưu hay bỏ
func (lib *MotionLibrary) Learn(
	clip *MotionClip,
	action ActionVerb,
	species string,
	space SpaceType,
) LearnResult {
	lib.SeenTotal++
	sig := extractSignature(clip, action, species, space)

	// Tìm mẫu giống nhất trong library
	bestSim, bestID := 0.0, ""
	for _, s := range lib.Signatures {
		sim := sig.Similarity(s)
		if sim > bestSim {
			bestSim = sim
			bestID = s.ID
		}
	}

	// Đã biết → bỏ, chỉ tăng seenCount
	if bestSim >= lib.Threshold {
		for _, s := range lib.Signatures {
			if s.ID == bestID {
				s.SeenCount++
				break
			}
		}
		return LearnResult{IsNew: false, Similarity: bestSim, MatchID: bestID}
	}

	// Chưa biết → lưu
	sig.ID = fmt.Sprintf("%s_%03d", action, lib.SavedTotal+1)
	lib.Signatures = append(lib.Signatures, sig)
	lib.SavedTotal++

	return LearnResult{IsNew: true, Similarity: bestSim, Saved: sig}
}

// Stats trả về thống kê library
func (lib *MotionLibrary) Stats() string {
	return fmt.Sprintf("seen=%d saved=%d ratio=%.1f:1 threshold=%.2f",
		lib.SeenTotal, lib.SavedTotal,
		float64(lib.SeenTotal)/math.Max(1, float64(lib.SavedTotal)),
		lib.Threshold)
}

// TopPatterns trả về các mẫu hay gặp nhất
func (lib *MotionLibrary) TopPatterns(n int) []*MotionSignature {
	sigs := make([]*MotionSignature, len(lib.Signatures))
	copy(sigs, lib.Signatures)
	sort.Slice(sigs, func(i, j int) bool {
		return sigs[i].SeenCount > sigs[j].SeenCount
	})
	if n > len(sigs) { n = len(sigs) }
	return sigs[:n]
}

// ─── AudioSignature ───────────────────────────────────────────────────────

type AudioSignature struct {
	ID     string
	Cues   []AudioCue
	// Fingerprint: frequency band energy (8 bands)
	Bands  [8]float64
	Label  string     // "cooking_water", "music_fast", "tv_speech"...
	SeenCount int
}

func (a *AudioSignature) Similarity(b *AudioSignature) float64 {
	// Cue overlap
	overlap := 0
	for _, ca := range a.Cues {
		for _, cb := range b.Cues {
			if ca == cb { overlap++ }
		}
	}
	cueScore := 0.0
	if len(a.Cues) > 0 {
		cueScore = float64(overlap) / float64(len(a.Cues))
	}

	// Band similarity
	dot, na, nb := 0.0, 0.0, 0.0
	for i := 0; i < 8; i++ {
		dot += a.Bands[i] * b.Bands[i]
		na  += a.Bands[i] * a.Bands[i]
		nb  += b.Bands[i] * b.Bands[i]
	}
	bandScore := 0.0
	if na > 1e-9 && nb > 1e-9 {
		bandScore = dot / (math.Sqrt(na) * math.Sqrt(nb))
	}
	return 0.6*cueScore + 0.4*bandScore
}

// ─── AudioLibrary ─────────────────────────────────────────────────────────

type AudioLibrary struct {
	Signatures []*AudioSignature
	Threshold  float64
	SeenTotal  int
	SavedTotal int
}

func NewAudioLibrary(threshold float64) *AudioLibrary {
	return &AudioLibrary{Threshold: threshold}
}

type AudioLearnResult struct {
	IsNew      bool
	Similarity float64
	MatchID    string
	Saved      *AudioSignature
}

// LearnAudio: xem mẫu âm thanh, lưu nếu chưa biết
func (lib *AudioLibrary) LearnAudio(
	cues []AudioCue,
	bands [8]float64, // frequency band energies
	label string,
) AudioLearnResult {
	lib.SeenTotal++
	sig := &AudioSignature{
		Cues:      cues,
		Bands:     bands,
		Label:     label,
		SeenCount: 1,
	}

	bestSim, bestID := 0.0, ""
	for _, s := range lib.Signatures {
		sim := sig.Similarity(s)
		if sim > bestSim {
			bestSim = sim
			bestID = s.ID
		}
	}

	if bestSim >= lib.Threshold {
		for _, s := range lib.Signatures {
			if s.ID == bestID { s.SeenCount++; break }
		}
		return AudioLearnResult{IsNew: false, Similarity: bestSim, MatchID: bestID}
	}

	sig.ID = fmt.Sprintf("audio_%03d_%s", lib.SavedTotal+1, label)
	lib.Signatures = append(lib.Signatures, sig)
	lib.SavedTotal++
	return AudioLearnResult{IsNew: true, Similarity: bestSim, Saved: sig}
}

func (lib *AudioLibrary) Stats() string {
	return fmt.Sprintf("seen=%d saved=%d ratio=%.1f:1",
		lib.SeenTotal, lib.SavedTotal,
		float64(lib.SeenTotal)/math.Max(1, float64(lib.SavedTotal)))
}
