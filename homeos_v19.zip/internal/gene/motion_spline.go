// internal/gene/motion_spline.go
//
// MOTION SPLINE — lưu chuyển động từ skeleton qua nhiều frame
//
// Insight (session 113):
//   Nhà làm phim 15 năm trước: tuần → 1 scene mocap
//   Bây giờ: 276μs/frame → real-time
//
// Pipeline:
//   Frame 1..N → Skeleton (joints: cx, cy, rotation, scale)
//       ↓
//   MotionTracker: theo dõi mỗi joint qua thời gian
//       ↓
//   SplineBuilder: fit Catmull-Rom spline qua các điểm
//       ↓
//   MotionClip: {name, duration, joints[]{spline}}
//       ↓
//   DNA node → Silk Tree → nhớ mãi
//       ↓
//   Nhận diện: so MotionClip mới vs đã lưu
//   "điệu múa này giống Pale 87%"

package gene

import (
	"fmt"
	"math"
	"sort"
)

// ─── JointTrack — quỹ đạo 1 joint qua thời gian ─────────────────────────

// JointKeyframe trạng thái joint tại 1 thời điểm
type JointKeyframe struct {
	T        float64 // thời gian (giây)
	CX, CY   float64 // vị trí
	Rotation float64 // góc xoay (radians)
	ScaleX   float64 // kích thước
	ScaleY   float64
}

// JointTrack quỹ đạo của 1 joint
type JointTrack struct {
	Name      string
	Keyframes []JointKeyframe
}

// AddFrame thêm keyframe mới
func (t *JointTrack) AddFrame(kf JointKeyframe) {
	t.Keyframes = append(t.Keyframes, kf)
}

// ─── Catmull-Rom Spline ────────────────────────────────────────────────────
// Đi qua tất cả control points — quan trọng cho mocap
// (Bezier không đi qua → sẽ sai vị trí khớp)

// catmullRom nội suy giữa p1 và p2, với p0 và p3 là context
// t: 0..1
func catmullRom1D(p0, p1, p2, p3, t float64) float64 {
	t2 := t * t
	t3 := t2 * t
	return 0.5 * ((2*p1) +
		(-p0+p2)*t +
		(2*p0-5*p1+4*p2-p3)*t2 +
		(-p0+3*p1-3*p2+p3)*t3)
}

// Evaluate lấy giá trị tại thời điểm t (nội suy Catmull-Rom)
func (track *JointTrack) Evaluate(t float64) JointKeyframe {
	kfs := track.Keyframes
	if len(kfs) == 0 { return JointKeyframe{T: t} }
	if len(kfs) == 1 { return kfs[0] }

	// Clamp
	if t <= kfs[0].T { return kfs[0] }
	if t >= kfs[len(kfs)-1].T { return kfs[len(kfs)-1] }

	// Tìm đoạn chứa t
	idx := sort.Search(len(kfs)-1, func(i int) bool {
		return kfs[i+1].T >= t
	})
	if idx >= len(kfs)-1 { idx = len(kfs) - 2 }

	// 4 control points cho Catmull-Rom
	i0 := max0(idx - 1)
	i1 := idx
	i2 := min0(idx+1, len(kfs)-1)
	i3 := min0(idx+2, len(kfs)-1)

	// Normalize t trong đoạn [i1, i2]
	dt := kfs[i2].T - kfs[i1].T
	if dt < 1e-9 { return kfs[i1] }
	lt := (t - kfs[i1].T) / dt

	return JointKeyframe{
		T:        t,
		CX:       catmullRom1D(kfs[i0].CX, kfs[i1].CX, kfs[i2].CX, kfs[i3].CX, lt),
		CY:       catmullRom1D(kfs[i0].CY, kfs[i1].CY, kfs[i2].CY, kfs[i3].CY, lt),
		Rotation: catmullRom1D(kfs[i0].Rotation, kfs[i1].Rotation, kfs[i2].Rotation, kfs[i3].Rotation, lt),
		ScaleX:   catmullRom1D(kfs[i0].ScaleX, kfs[i1].ScaleX, kfs[i2].ScaleX, kfs[i3].ScaleX, lt),
		ScaleY:   catmullRom1D(kfs[i0].ScaleY, kfs[i1].ScaleY, kfs[i2].ScaleY, kfs[i3].ScaleY, lt),
	}
}

// ─── MotionClip — điệu múa hoàn chỉnh ────────────────────────────────────

// MotionClip lưu toàn bộ chuyển động
type MotionClip struct {
	Name     string
	Duration float64       // giây
	FPS      float64       // frames per second lúc record
	Tracks   []*JointTrack // mỗi joint 1 track
}

// DNA serialize clip thành chuỗi lưu vào node
func (clip *MotionClip) DNA() string {
	s := fmt.Sprintf("motion:name=%s|dur=%.2f|fps=%.0f|joints=%d",
		clip.Name, clip.Duration, clip.FPS, len(clip.Tracks))
	for _, t := range clip.Tracks {
		s += fmt.Sprintf("|track=%s:kf=%d", t.Name, len(t.Keyframes))
	}
	return s
}

// GetTrack tìm track theo tên joint
func (clip *MotionClip) GetTrack(name string) *JointTrack {
	for _, t := range clip.Tracks {
		if t.Name == name { return t }
	}
	return nil
}

// ─── MotionTracker — theo dõi skeleton qua frames ─────────────────────────

// MotionTracker nhận skeleton frame by frame → build MotionClip
type MotionTracker struct {
	clip     *MotionClip
	frameNum int
	fps      float64
}

func NewMotionTracker(name string, fps float64) *MotionTracker {
	return &MotionTracker{
		clip: &MotionClip{Name: name, FPS: fps},
		fps:  fps,
	}
}

// AddSkeleton thêm 1 frame skeleton
func (mt *MotionTracker) AddSkeleton(sk *SDFSkeleton) {
	if sk == nil { return }
	t := float64(mt.frameNum) / mt.fps
	mt.frameNum++

	for _, joint := range sk.Joints {
		// Tìm hoặc tạo track cho joint này
		track := mt.clip.GetTrack(joint.Name)
		if track == nil {
			track = &JointTrack{Name: joint.Name}
			mt.clip.Tracks = append(mt.clip.Tracks, track)
		}

		track.AddFrame(JointKeyframe{
			T:        t,
			CX:       joint.CX,
			CY:       joint.CY,
			Rotation: joint.Rotation,
			ScaleX:   joint.ScaleX,
			ScaleY:   joint.ScaleY,
		})
	}

	mt.clip.Duration = t
}

// Finish hoàn thành và trả về MotionClip
func (mt *MotionTracker) Finish() *MotionClip {
	return mt.clip
}

// ─── MotionMatcher — so sánh 2 clip ──────────────────────────────────────

// MotionMatch kết quả so sánh
type MotionMatch struct {
	Score      float64  // 0..1 (1 = giống hệt)
	JointScores map[string]float64
	Label      string   // "giống Pale 87%"
}

// Compare so sánh 2 MotionClip
// Normalize về cùng duration rồi sample N điểm
func Compare(a, b *MotionClip) MotionMatch {
	const samples = 20
	match := MotionMatch{JointScores: make(map[string]float64)}

	// Tìm joints chung
	commonJoints := []string{}
	for _, ta := range a.Tracks {
		if b.GetTrack(ta.Name) != nil {
			commonJoints = append(commonJoints, ta.Name)
		}
	}
	if len(commonJoints) == 0 {
		match.Label = "không có joint chung"
		return match
	}

	totalScore := 0.0
	for _, jname := range commonJoints {
		ta := a.GetTrack(jname)
		tb := b.GetTrack(jname)

		jScore := 0.0
		for s := 0; s < samples; s++ {
			// Normalize time 0..1
			tNorm := float64(s) / float64(samples-1)
			tA    := tNorm * a.Duration
			tB    := tNorm * b.Duration

			kfA := ta.Evaluate(tA)
			kfB := tb.Evaluate(tB)

			// So sánh position + rotation
			dPos := math.Sqrt(
				math.Pow(kfA.CX-kfB.CX, 2) +
				math.Pow(kfA.CY-kfB.CY, 2))
			dRot := math.Abs(kfA.Rotation - kfB.Rotation)
			// Normalize rotation diff [0, π] → [0, 1]
			dRot = math.Min(dRot, math.Pi) / math.Pi

			// Score: 1 khi giống hệt, 0 khi hoàn toàn khác
			posScore := math.Max(0, 1-dPos*5)
			rotScore := math.Max(0, 1-dRot)
			jScore += (posScore*0.7 + rotScore*0.3)
		}
		jScore /= float64(samples)
		match.JointScores[jname] = jScore
		totalScore += jScore
	}

	match.Score = totalScore / float64(len(commonJoints))
	pct := int(match.Score * 100)
	match.Label = fmt.Sprintf("giống %.0f%%", match.Score*100)

	// Nhận diện theo ngưỡng
	switch {
	case pct >= 90:
		match.Label = fmt.Sprintf("✓ khớp chính xác (%.0f%%)", match.Score*100)
	case pct >= 70:
		match.Label = fmt.Sprintf("~ giống nhiều (%.0f%%)", match.Score*100)
	case pct >= 50:
		match.Label = fmt.Sprintf("? có thể giống (%.0f%%)", match.Score*100)
	default:
		match.Label = fmt.Sprintf("✗ khác nhau (%.0f%%)", match.Score*100)
	}

	return match
}

func max0(a int) int { if a < 0 { return 0 }; return a }
func min0(a, b int) int { if a < b { return a }; return b }
