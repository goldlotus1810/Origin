package gene

import (
	"fmt"
	"math"
	"testing"
)

func TestMotionLibrary(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  MOTION + AUDIO LIBRARY — chỉ lưu mẫu chưa biết            ║")
	t.Log("║  QT7: quan sát → đã biết? bỏ : lưu                         ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	motionLib := NewMotionLibrary(0.80) // 80% similarity → đã biết
	audioLib  := NewAudioLibrary(0.75)

	// ── Simulate 1 ngày: nhiều lần lặp lại ─────────────────────
	// Sáng: nấu ăn 3 lần (hơi khác nhau nhưng cùng pattern)
	// Tối: múa 4 lần
	// Âm thanh: TV bật tắt nhiều lần

	type obs struct {
		label   string
		action  ActionVerb
		species string
		space   SpaceType
		// motion params để tạo clip giả
		armFreq float64 // tần số tay
		armAmp  float64 // biên độ
		legMove float64 // chân di chuyển
		// audio
		audioCues []AudioCue
		audioBands [8]float64
		audioLabel string
	}

	observations := []obs{
		// Nấu ăn — lần 1 (mới hoàn toàn)
		{"08:00 nấu ăn lần 1",  ActionCooking,  "human_adult_female", SpaceKitchen,
			3.5, 0.12, 0.0,
			[]AudioCue{AudioWater}, [8]float64{0,0,0.8,0.6,0.2,0,0,0}, "water"},
		// Nấu ăn — lần 2 (tương tự lần 1, nên BỎ)
		{"08:20 nấu ăn lần 2",  ActionCooking,  "human_adult_female", SpaceKitchen,
			3.4, 0.13, 0.0,
			[]AudioCue{AudioWater}, [8]float64{0,0,0.75,0.65,0.2,0,0,0}, "water"},
		// Nấu ăn — lần 3 (kiểu khác: khuấy thay vì thái)
		{"09:00 nấu ăn lần 3",  ActionCooking,  "human_adult_female", SpaceKitchen,
			1.2, 0.15, 0.0,   // tần số thấp hơn, biên độ tròn hơn
			[]AudioCue{AudioWater}, [8]float64{0,0,0.5,0.4,0.5,0.3,0,0}, "water_stir"},
		// Gõ phím — mới
		{"09:30 gõ phím",       ActionTyping,   "human_adult_male",   SpaceOffice,
			4.0, 0.03, 0.0,
			[]AudioCue{AudioKeyboard}, [8]float64{0.8,0.6,0.2,0.1,0,0,0,0}, "keyboard"},
		// Gõ phím — lần 2 (tương tự, BỎ)
		{"10:00 gõ phím lần 2", ActionTyping,   "human_adult_male",   SpaceOffice,
			4.1, 0.03, 0.0,
			[]AudioCue{AudioKeyboard}, [8]float64{0.82,0.58,0.2,0.1,0,0,0,0}, "keyboard"},
		// Múa — lần 1 (mới)
		{"20:00 múa lần 1",     ActionDancing,  "human_adult_female", SpaceLivingRoom,
			1.0, 0.18, 0.0,
			[]AudioCue{AudioMusic}, [8]float64{0.2,0.8,0.6,0.4,0.3,0.5,0.7,0.4}, "music_pop"},
		// Múa — lần 2 (tương tự, BỎ)
		{"20:30 múa lần 2",     ActionDancing,  "human_adult_female", SpaceLivingRoom,
			1.0, 0.17, 0.0,
			[]AudioCue{AudioMusic}, [8]float64{0.2,0.78,0.62,0.4,0.3,0.5,0.7,0.4}, "music_pop"},
		// Múa — lần 3 kiểu khác (nhạc slow)
		{"21:00 múa slow",      ActionDancing,  "human_adult_female", SpaceLivingRoom,
			0.4, 0.22, 0.0,   // chậm hơn nhiều
			[]AudioCue{AudioMusic}, [8]float64{0,0.3,0.2,0.5,0.8,0.6,0.4,0.2}, "music_slow"},
		// Đi bộ — mới
		{"19:00 đi bộ",         ActionWalking,  "human_adult_male",   SpaceLivingRoom,
			1.9, 0.06, 0.12,
			[]AudioCue{}, [8]float64{0,0,0,0,0,0,0,0}, "silent"},
		// Đi bộ — lần 2 (tương tự, BỎ)
		{"19:30 đi bộ lần 2",   ActionWalking,  "human_adult_male",   SpaceLivingRoom,
			1.9, 0.06, 0.12,
			[]AudioCue{}, [8]float64{0,0,0,0,0,0,0,0}, "silent"},
		// TV — xem tivi
		{"20:00 xem TV",        ActionSitting,  "human_adult_male",   SpaceLivingRoom,
			0.0, 0.01, 0.0,
			[]AudioCue{AudioTV}, [8]float64{0.1,0.5,0.7,0.6,0.4,0.3,0.2,0.1}, "tv_speech"},
		// TV — lần 2 (BỎ)
		{"20:30 xem TV lần 2",  ActionSitting,  "human_adult_male",   SpaceLivingRoom,
			0.0, 0.01, 0.0,
			[]AudioCue{AudioTV}, [8]float64{0.1,0.5,0.68,0.6,0.4,0.3,0.2,0.1}, "tv_speech"},
	}

	t.Log("[ LEARNING — mỗi mẫu: lưu hay bỏ? ]")
	t.Log()

	for _, o := range observations {
		// Tạo clip giả với params
		clip := makeLibClip(o.action, o.armFreq, o.armAmp, o.legMove)

		// Motion learn
		mr := motionLib.Learn(clip, o.action, o.species, o.space)

		// Audio learn
		ar := audioLib.LearnAudio(o.audioCues, o.audioBands, o.audioLabel)

		motionMark := "LƯU ✓"
		if !mr.IsNew {
			motionMark = fmt.Sprintf("bỏ  (%.0f%% ~ %s)", mr.Similarity*100, mr.MatchID)
		}
		audioMark := "LƯU ✓"
		if !ar.IsNew {
			audioMark = fmt.Sprintf("bỏ  (%.0f%% ~ %s)", ar.Similarity*100, ar.MatchID)
		}

		t.Logf("  %-28s  motion: %-30s  audio: %s",
			o.label, motionMark, audioMark)
	}

	t.Log()
	t.Log("[ THỐNG KÊ ]")
	t.Logf("  Motion: %s", motionLib.Stats())
	t.Logf("  Audio:  %s", audioLib.Stats())

	t.Log()
	t.Log("[ MOTION PATTERNS đã học được ]")
	for _, s := range motionLib.Signatures {
		t.Logf("  %-20s %-12s  seen=%d  joints=%d",
			s.ID, s.Action, s.SeenCount, len(s.Joints))
	}

	t.Log()
	t.Log("[ AUDIO PATTERNS đã học được ]")
	for _, s := range audioLib.Signatures {
		t.Logf("  %-25s  cues=%v  seen=%d", s.ID, s.Cues, s.SeenCount)
	}

	t.Log()
	t.Log("[ BỘ NHỚ ]")
	// Ước tính bộ nhớ
	motionBytes := len(motionLib.Signatures) * (20*8 + 64)   // 20 floats + metadata
	audioBytes  := len(audioLib.Signatures)  * (8*8 + 32)    // 8 bands + metadata
	seenBytes   := len(observations) * 124                    // nếu lưu tất cả

	t.Logf("  Nếu lưu tất cả %d mẫu:  %dB", len(observations), seenBytes)
	t.Logf("  Thực tế lưu:             %dB (motion=%dB audio=%dB)",
		motionBytes+audioBytes, motionBytes, audioBytes)
	t.Logf("  Tiết kiệm:               %.0f%%",
		100*(1-float64(motionBytes+audioBytes)/float64(seenBytes)))

	t.Log()
	t.Log("[ TOP PATTERNS (hay gặp nhất) ]")
	for _, s := range motionLib.TopPatterns(3) {
		t.Logf("  %-20s seen=%d", s.ID, s.SeenCount)
	}

	// Assertions
	if motionLib.SavedTotal >= len(observations) {
		t.Errorf("✗ Không filter được — lưu tất cả %d/%d",
			motionLib.SavedTotal, len(observations))
	}
	if motionLib.SeenTotal != len(observations) {
		t.Errorf("✗ SeenTotal sai: %d != %d", motionLib.SeenTotal, len(observations))
	}
	if audioLib.SavedTotal >= len(observations) {
		t.Errorf("✗ Audio không filter được")
	}

	t.Logf("\n  ✓ Motion: %d/%d mẫu lưu lại (bỏ %d)",
		motionLib.SavedTotal, motionLib.SeenTotal,
		motionLib.SeenTotal-motionLib.SavedTotal)
	t.Logf("  ✓ Audio:  %d/%d mẫu lưu lại (bỏ %d)",
		audioLib.SavedTotal, audioLib.SeenTotal,
		audioLib.SeenTotal-audioLib.SavedTotal)
}

// makeLibClip tạo clip giả với params đơn giản
func makeLibClip(action ActionVerb, armFreq, armAmp, legMove float64) *MotionClip {
	fps, frames := 30.0, 90
	tracker := NewMotionTracker(string(action), fps)
	for f := 0; f < frames; f++ {
		t := float64(f) / fps
		armRY := 0.40 + armAmp*math.Sin(t*armFreq*2*math.Pi)
		armCirc := 0.0
		if action == ActionDancing { armCirc = armAmp * 0.5 }
		tracker.AddSkeleton(&SDFSkeleton{Joints: []*Joint{
			{Name: "arm_r", CX: 0.65 + armCirc*math.Cos(t*armFreq*2*math.Pi), CY: armRY},
			{Name: "arm_l", CX: 0.35 - armCirc*math.Cos(t*armFreq*2*math.Pi), CY: armRY},
			{Name: "leg_r", CX: 0.55 + legMove*t, CY: 0.72},
			{Name: "torso", CX: 0.50 + legMove*t*0.8, CY: 0.50},
			{Name: "head",  CX: 0.50 + legMove*t*0.8, CY: 0.25},
		}})
	}
	return tracker.Finish()
}
