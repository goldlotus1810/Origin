// internal/gene/sun.go
// SunGene — mặt trời hoàn chỉnh theo kiến trúc ISL+SDF+Spline
//
//   ISL_Sun      = định danh (primary key, bất biến)
//   SDF()        = SDFSphere — hình dạng
//   Orbit        = Spline Vec3   — vị trí theo giờ trong ngày
//   Temp         = ScalarSpline  — nhiệt độ bề mặt (K)
//   Wavelength   = ScalarSpline  — bước sóng đỉnh (nm)
//   Luminosity   = ScalarSpline  — cường độ sáng [0..1]
//   Magnetic     = ScalarSpline  — chu kỳ từ trường (11 năm)

package gene

import "math"

// SunGene = mặt trời với đầy đủ thuộc tính vật lý
type SunGene struct {
	Addr   ISLAddr // = ISL_Sun
	Radius float64
	pos    Vec3    // vị trí hiện tại sau Animate

	// Quỹ đạo theo giờ trong ngày
	Orbit *Spline

	// Thuộc tính vật lý — mỗi cái gắn với 1 ISL address riêng
	Temp       *ScalarSpline // ISL_SunTemp
	Wavelength *ScalarSpline // ISL_SunWave
	Luminosity *ScalarSpline // ISL_SunLumin
	Magnetic   *ScalarSpline // ISL_SunMag
}

// NewSunGene tạo mặt trời với tất cả Spline vật lý
func NewSunGene() *SunGene {
	s := &SunGene{
		Addr:   ISL_Sun,
		Radius: 8.0,
	}

	// Quỹ đạo: 4 keyframe = ellipse trên bầu trời
	// t=0.0 (0h) → t=0.25 (6h bình minh) → t=0.5 (12h đỉnh) → t=0.75 (18h hoàng hôn)
	s.Orbit = &Spline{Keys: []Keyframe{
		{T: 0.00, Vec3: Vec3{-20, -2, 0}},
		{T: 0.25, Vec3: Vec3{-15, 12, -5}},
		{T: 0.50, Vec3: Vec3{0, 22, -8}},
		{T: 0.75, Vec3: Vec3{15, 12, -5}},
	}}

	// Nhiệt độ bề mặt ~5778K, dao động ±50K theo góc nhìn
	s.Temp = NewScalarSpline("K",
		0.00, 5750.0,
		0.25, 5778.0,
		0.50, 5810.0,
		0.75, 5778.0,
		1.00, 5750.0,
	)

	// Bước sóng đỉnh: thay đổi theo góc khí quyển
	// 6h=580nm(vàng cam), 12h=500nm(trắng xanh), 18h=620nm(cam đỏ)
	s.Wavelength = NewScalarSpline("nm",
		0.00, 700.0,
		0.25, 580.0,
		0.50, 500.0,
		0.75, 620.0,
		1.00, 700.0,
	)

	// Cường độ sáng: 0 đêm → 1 trưa
	s.Luminosity = NewScalarSpline("lux",
		0.00, 0.00,
		0.25, 0.30,
		0.50, 1.00,
		0.75, 0.30,
		1.00, 0.00,
	)

	// Từ trường chu kỳ 11 năm (t normalize về [0,1] = 11 năm)
	s.Magnetic = NewScalarSpline("T",
		0.00, 0.30,
		0.30, 1.00,
		0.55, 0.50,
		0.73, 0.05,
		1.00, 0.30,
	)

	s.pos = s.Orbit.Eval(0.5)
	return s
}

// ─── Gene interface ───────────────────────────────────────────────

func (s *SunGene) SDF(p Vec3) float64 {
	return SDFSphere(p, s.pos, s.Radius)
}

func (s *SunGene) Normal(p Vec3) Vec3 {
	return SurfaceNormal(p, s.SDF, s.Radius*0.01)
}

func (s *SunGene) Animate(t float64) {
	s.pos = s.Orbit.Eval(t / 24.0)
}

func (s *SunGene) SimpleSDF(p Vec3) float64 {
	noon := s.Orbit.Eval(0.5)
	return SDFSphere(p, noon, s.Radius)
}

// DNA — placeholder cho ISL binary stream thật
// Tương lai: trả về []ISLAddr trực tiếp
func (s *SunGene) DNA() string {
	return "☀●~ISL_Sun~ISL_SunOrbit~ISL_SunTemp~ISL_SunWave~ISL_SunLumin~ISL_SunMag"
}

// ─── Truy vấn vật lý tại t ∈ [0,24] ─────────────────────────────

// LightAt trả về thông tin ánh sáng tại giờ t
// Dùng Orbit Spline thay vì sin/cos cứng
func (s *SunGene) LightAt(t float64) LightInfo {
	tN := t / 24.0
	sunPos := s.Orbit.Eval(tN)
	dir := sunPos.Scale(-1).Norm()
	intensity := s.Luminosity.Eval(tN)
	return LightInfo{
		Dir:       dir,
		Intensity: intensity,
		Ambient:   0.05 + intensity*0.20,
	}
}

// ColorAt trả về màu ánh sáng tại t dựa trên bước sóng
func (s *SunGene) ColorAt(t float64) Vec3 {
	tN := t / 24.0
	lam := s.Wavelength.Eval(tN)
	lum := s.Luminosity.Eval(tN)
	r, g, b := wavelengthToRGB(lam)
	return Vec3{r * lum, g * lum, b * lum}
}

// TempAt trả về nhiệt độ bề mặt (K) tại t
func (s *SunGene) TempAt(t float64) float64 {
	return s.Temp.Eval(t / 24.0)
}

// ─── Wavelength (nm) → RGB [0,1] ─────────────────────────────────

func wavelengthToRGB(lam float64) (r, g, b float64) {
	switch {
	case lam < 380:
		r, g, b = 0.5, 0, 0.5
	case lam < 440:
		r = -(lam - 440) / 60
		b = 1.0
	case lam < 490:
		g = (lam - 440) / 50
		b = 1.0
	case lam < 510:
		g = 1.0
		b = -(lam - 510) / 20
	case lam < 580:
		r = (lam - 510) / 70
		g = 1.0
	case lam < 645:
		r = 1.0
		g = -(lam - 645) / 65
	case lam <= 780:
		r = 1.0
	default:
		r = 0.5
	}
	gamma := 0.8
	r = math.Pow(math.Max(0, r), gamma)
	g = math.Pow(math.Max(0, g), gamma)
	b = math.Pow(math.Max(0, b), gamma)
	return
}
