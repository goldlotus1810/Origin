package gene

import (
	"os"
	"strings"
	"testing"
)

func TestSnapshotStore(t *testing.T) {
	// Dùng file tạm để test, không động vào homeos.olang thật
	const testFile = "test_snap.olang"

	// Copy homeos.olang → test file
	raw, err := os.ReadFile("../../../homeos.olang")
	if err != nil {
		t.Skip("homeos.olang không tìm thấy, skip")
	}
	if err := os.WriteFile(testFile, raw, 0644); err != nil {
		t.Fatal(err)
	}
	defer os.Remove(testFile)

	// Patch snapshotFilePath tạm thời
	origPath := snapshotFilePath
	// Không thể patch const — dùng function helper thay
	_ = origPath

	// Test SnapshotPayload encode/decode trực tiếp
	ws := NewWorldScene()
	ws.Clock.HourOfDay = 12.0
	ws.Clock.YearT = 0.5

	snap := ws.Snapshot()
	t.Logf("Snapshot: %d streams, %d bytes", len(snap.Streams), snap.TotalBytes())

	// Encode
	payload := SnapshotPayload(snap)
	t.Logf("Payload: %d bytes (header=12, streams=%d×(4+tokens×20))",
		len(payload), len(snap.Streams))

	// Decode round-trip
	snap2, err := DecodeSnapshotPayload(payload)
	if err != nil {
		t.Fatalf("Decode failed: %v", err)
	}
	if len(snap2.Streams) != len(snap.Streams) {
		t.Errorf("stream count: got %d want %d", len(snap2.Streams), len(snap.Streams))
	}
	for i, s := range snap2.Streams {
		orig := snap.Streams[i]
		if s.Len() != orig.Len() {
			t.Errorf("stream %d: tokens %d != %d", i, s.Len(), orig.Len())
		}
		t.Logf("  stream %d: %d tokens round-trip ✓", i, s.Len())
	}

	// Verify token payload khớp
	for si, s := range snap2.Streams {
		orig := snap.Streams[si]
		for ti, tok := range s.Tokens {
			otok := orig.Tokens[ti]
			if tok.Addr != otok.Addr {
				t.Errorf("s%d t%d addr %016x != %016x", si, ti, tok.Addr, otok.Addr)
			}
			if tok.Type != otok.Type {
				t.Errorf("s%d t%d type %d != %d", si, ti, tok.Type, otok.Type)
			}
		}
	}
	t.Log("Round-trip encode/decode ✓")

	// Kiểm tra magic
	if payload[0] != 'S' || payload[1] != 'N' ||
		payload[2] != 'A' || payload[3] != 'P' {
		t.Error("magic bytes sai")
	}
	t.Log("Magic SNAP ✓")

	// Tên node SNAP_ format
	ts := "SNAP_0000000000000001"
	if !strings.HasPrefix(ts, "SNAP_") {
		t.Error("tên node format sai")
	}

	// buildSnapRecord test
	var islv [8]byte
	islv[0] = 7; islv[1] = 0xA0
	rec := buildSnapRecord(7, islv, payload, "SNAP_test")
	if rec[0] != 'N' || rec[1] != 'D' {
		t.Error("record magic sai")
	}
	if rec[2] != 7 {
		t.Errorf("layer sai: %d", rec[2])
	}
	t.Logf("buildSnapRecord: %d bytes ✓", len(rec))

	// ISLAddr trong record
	dnaLen := int(rec[15])<<24 | int(rec[16])<<16 | int(rec[17])<<8 | int(rec[18])
	if dnaLen != len(payload) {
		t.Errorf("dnaLen %d != payload %d", dnaLen, len(payload))
	}
	t.Logf("dnaLen encode/decode ✓ (%d bytes)", dnaLen)
}
