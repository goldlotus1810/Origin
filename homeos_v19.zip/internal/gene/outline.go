// internal/gene/outline.go
// Outline tracing + SDF skeleton fitting
// 
// 2 phương án:
//   A. Convex Hull  — nhanh, mất concavity
//   B. Marching Squares trên Fibonacci cells — chính xác, giữ shape
//
// SDF Skeleton: center + rotation + scale per joint
// → lưu vào DNA node → motion spline sau

package gene

import (
	"fmt"
	"image"
	"math"
	"sort"
)

// ─── A: Convex Hull ───────────────────────────────────────────────────────

func regionToPoints(r *AttentionRegion) []Vec3 {
	pts := make([]Vec3, len(r.Cells))
	for i, c := range r.Cells {
		pts[i] = Vec3{X: c.CX, Y: c.CY}
	}
	return pts
}

// convexHull Graham scan O(n log n)
func convexHull(pts []Vec3) []Vec3 {
	if len(pts) < 3 { return pts }

	// Tìm điểm thấp nhất (Y lớn nhất trong image coords)
	pivot := pts[0]
	for _, p := range pts {
		if p.Y > pivot.Y || (p.Y == pivot.Y && p.X < pivot.X) {
			pivot = p
		}
	}

	// Sort theo góc polar từ pivot
	sort.Slice(pts, func(i, j int) bool {
		a := math.Atan2(pts[i].Y-pivot.Y, pts[i].X-pivot.X)
		b := math.Atan2(pts[j].Y-pivot.Y, pts[j].X-pivot.X)
		if math.Abs(a-b) < 1e-10 {
			da := math.Hypot(pts[i].X-pivot.X, pts[i].Y-pivot.Y)
			db := math.Hypot(pts[j].X-pivot.X, pts[j].Y-pivot.Y)
			return da < db
		}
		return a < b
	})

	hull := []Vec3{pts[0], pts[1]}
	for i := 2; i < len(pts); i++ {
		for len(hull) > 1 {
			n := len(hull)
			// Cross product để check left turn
			ax := hull[n-1].X - hull[n-2].X
			ay := hull[n-1].Y - hull[n-2].Y
			bx := pts[i].X - hull[n-2].X
			by := pts[i].Y - hull[n-2].Y
			if ax*by-ay*bx > 0 { break }
			hull = hull[:n-1]
		}
		hull = append(hull, pts[i])
	}
	return hull
}

// ─── B: Marching Squares trên Fibonacci cells ────────────────────────────
// Không scan toàn bộ pixel — chỉ dùng Fibonacci cells đã có
// So sánh màu của 4 cells tạo thành ô vuông → detect boundary

func marchingSquaresFib(r *AttentionRegion, img image.Image) []Vec3 {
	if len(r.Cells) < 4 { return nil }

	// Build mini-grid từ attention cells
	// Dùng cell centers như lattice points
	cells := r.Cells

	// Sort by position
	sort.Slice(cells, func(i, j int) bool {
		if math.Abs(cells[i].CY-cells[j].CY) > 0.01 {
			return cells[i].CY < cells[j].CY
		}
		return cells[i].CX < cells[j].CX
	})

	// Threshold: cell là "inside" nếu color khác background
	bgColor := r.Cells[0].Color // xấp xỉ background = cell ngoài rìa
	if len(r.Cells) > 0 {
		// Background = cell có attention thấp nhất
		minAtt := r.Cells[0]
		for _, c := range r.Cells {
			if c.Attention < minAtt.Attention { minAtt = c }
		}
		bgColor = minAtt.Color
	}

	threshold := 0.15
	isInside := func(c FibCell) bool {
		return c.Color.Delta(bgColor) > threshold
	}

	// Marching squares: xét từng cặp cells liền kề
	var outlinePoints []Vec3
	visited := make(map[[2]int]bool)

	for i := 0; i < len(cells)-1; i++ {
		for j := i + 1; j < len(cells); j++ {
			ci, cj := cells[i], cells[j]
			dx := ci.CX - cj.CX
			dy := ci.CY - cj.CY
			dist := math.Sqrt(dx*dx + dy*dy)

			// Chỉ xét neighbors gần
			avgSize := (ci.Size + cj.Size) / 2
			if dist > avgSize*3 { continue }

			key := [2]int{i, j}
			if visited[key] { continue }
			visited[key] = true

			// Boundary = một cell inside, một cell outside
			inI := isInside(ci)
			inJ := isInside(cj)
			if inI != inJ {
				// Midpoint là điểm outline
				outlinePoints = append(outlinePoints, Vec3{
					X: (ci.CX + cj.CX) / 2,
					Y: (ci.CY + cj.CY) / 2,
				})
			}
		}
	}

	return outlinePoints
}

// ─── SDF Skeleton — center + rotation + scale ────────────────────────────

// Joint một khớp trong skeleton
type Joint struct {
	Name     string  // "head" / "torso" / "arm_l" / "arm_r" / "leg_l" / "leg_r"
	CX, CY   float64 // center (normalized)
	Rotation float64 // radians
	ScaleX   float64 // width
	ScaleY   float64 // height
	Shape    string  // "sphere" / "capsule"
}

// SDFSkeleton bộ khung SDF của một vật thể
type SDFSkeleton struct {
	ID       string
	Joints   []*Joint
	Rotation float64 // overall rotation
	ScaleX   float64 // overall scale
	ScaleY   float64
	CX, CY   float64 // overall center
}

// DNA serialize skeleton thành chuỗi DNA cho node
func (sk *SDFSkeleton) DNA() string {
	s := "skel:"
	for _, j := range sk.Joints {
		s += j.Name + ":" +
			fmtF(j.CX) + "," + fmtF(j.CY) + "," +
			fmtF(j.Rotation) + "," +
			fmtF(j.ScaleX) + "," + fmtF(j.ScaleY) + ";"
	}
	return s
}

func fmtF(f float64) string { _ = f; return "" }

// fitSkeleton fit SDF skeleton từ outline points
// Dùng PCA để tìm axis chính → joints
func fitSkeleton(pts []Vec3) *SDFSkeleton {
	if len(pts) < 4 { return nil }

	// 1. Centroid
	cx, cy := 0.0, 0.0
	for _, p := range pts {
		cx += p.X; cy += p.Y
	}
	cx /= float64(len(pts))
	cy /= float64(len(pts))

	// 2. PCA — covariance matrix 2×2
	var cxx, cxy, cyy float64
	for _, p := range pts {
		dx := p.X - cx
		dy := p.Y - cy
		cxx += dx * dx
		cxy += dx * dy
		cyy += dy * dy
	}
	n := float64(len(pts))
	cxx /= n; cxy /= n; cyy /= n

	// Eigenvalue → rotation angle
	// tan(2θ) = 2*cxy / (cxx - cyy)
	rotation := 0.5 * math.Atan2(2*cxy, cxx-cyy)

	// Eigenvalues → scale
	trace := cxx + cyy
	det   := cxx*cyy - cxy*cxy
	disc  := math.Sqrt(math.Max(0, trace*trace/4-det))
	l1 := trace/2 + disc // major axis
	l2 := trace/2 - disc // minor axis

	scaleX := math.Sqrt(math.Max(0, l1)) * 4
	scaleY := math.Sqrt(math.Max(0, l2)) * 4

	// 3. Phân tích skeleton — chia outline thành joints
	// Dựa vào distribution của points dọc theo major axis
	sk := &SDFSkeleton{
		CX: cx, CY: cy,
		Rotation: rotation,
		ScaleX:   scaleX,
		ScaleY:   scaleY,
	}

	// Project points lên major axis
	cos := math.Cos(rotation)
	sin := math.Sin(rotation)

	type projPt struct{ t, s float64 } // t=along axis, s=perpendicular
	projs := make([]projPt, len(pts))
	for i, p := range pts {
		dx := p.X - cx
		dy := p.Y - cy
		projs[i] = projPt{
			t: dx*cos + dy*sin,
			s: -dx*sin + dy*cos,
		}
	}

	// Sort theo axis chính
	sort.Slice(projs, func(i, j int) bool {
		return projs[i].t < projs[j].t
	})

	tMin := projs[0].t
	tMax := projs[len(projs)-1].t
	tRange := tMax - tMin

	if tRange < 1e-6 { tRange = 1e-6 }

	// Chia thành 5 vùng: đầu, vai/tay_l, thân, tay_r, chân
	// Dựa vào width tại mỗi vùng để phân loại
	segments := 5
	segWidth := make([]float64, segments)
	segCount := make([]int, segments)

	for _, p := range projs {
		seg := int((p.t - tMin) / tRange * float64(segments))
		if seg >= segments { seg = segments - 1 }
		if math.Abs(p.s) > segWidth[seg] {
			segWidth[seg] = math.Abs(p.s)
		}
		segCount[seg]++
	}

	jointNames := []string{"head", "torso_upper", "torso", "arm", "legs"}
	for i := 0; i < segments; i++ {
		if segCount[i] < 2 { continue }

		t := tMin + (float64(i)+0.5)/float64(segments)*tRange
		jcx := cx + t*cos
		jcy := cy + t*sin

		shape := "capsule"
		// Head thường gần tròn
		if i == 0 && math.Abs(segWidth[i]/tRange*float64(segments)-1.0) < 0.4 {
			shape = "sphere"
		}

		sk.Joints = append(sk.Joints, &Joint{
			Name:     jointNames[i],
			CX:       jcx,
			CY:       jcy,
			Rotation: rotation,
			ScaleX:   segWidth[i],
			ScaleY:   tRange / float64(segments),
			Shape:    shape,
		})
	}

	return sk
}

// ID — unique ID cho skeleton (dùng bởi FovealVision, MultiPersonTracker)
func (sk *SDFSkeleton) CenterX() float64 { return sk.CX }
func (sk *SDFSkeleton) CenterY() float64 { return sk.CY }

// skeletonID — tạo ID từ center + scale
func skeletonIDFrom(sk *SDFSkeleton) string {
	return fmt.Sprintf("sk_%.2f_%.2f", sk.CX, sk.CY)
}
