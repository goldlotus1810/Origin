// MultiPersonTracker — theo dõi nhiều người/sinh vật cùng lúc
// Dùng Quadtree để match skeleton frame-to-frame
// QT5: cùng vị trí → cùng người
package gene

import (
	"fmt"
	"math"
	"time"
)

// TrackedPerson — một người đang được track
type TrackedPerson struct {
	ID         string
	Species    Species
	Skeleton   *SDFSkeleton
	LastSeen   time.Time
	FrameCount int
	Confidence float64

	// Velocity — để predict vị trí frame sau
	VX, VY float64
	PrevCX, PrevCY float64
}

func (p *TrackedPerson) Predict() (x, y float64) {
	return p.Skeleton.CX + p.VX, p.Skeleton.CY + p.VY
}

func (p *TrackedPerson) UpdateVelocity() {
	if p.FrameCount > 1 {
		alpha := 0.7 // EMA smoothing
		p.VX = alpha*(p.Skeleton.CX-p.PrevCX) + (1-alpha)*p.VX
		p.VY = alpha*(p.Skeleton.CY-p.PrevCY) + (1-alpha)*p.VY
	}
	p.PrevCX = p.Skeleton.CX
	p.PrevCY = p.Skeleton.CY
}

// MultiPersonTracker — Hungarian-like matching đơn giản
type MultiPersonTracker struct {
	persons    map[string]*TrackedPerson
	nextID     int
	maxAge     time.Duration // xóa nếu không thấy quá lâu
	matchDist  float64       // ngưỡng match (normalized)
	qt         *Quadtree
	foveal     *FovealVision
}

func NewMultiPersonTracker() *MultiPersonTracker {
	return &MultiPersonTracker{
		persons:   make(map[string]*TrackedPerson),
		maxAge:    2 * time.Second,
		matchDist: 0.15, // 15% frame width
		qt:        NewQuadtree(Rect{0, 0, 1, 1}),
		foveal:    NewFovealVision(),
	}
}

// Update — nhận skeletons mới, trả về persons đang track
func (t *MultiPersonTracker) Update(skeletons []*SDFSkeleton, species []Species) []*TrackedPerson {
	now := time.Now()

	// Rebuild quadtree từ persons hiện có (để match)
	t.qt.Clear()
	for _, p := range t.persons {
		px, py := p.Predict()
		t.qt.Insert(QPoint{X: px, Y: py, Data: p})
	}

	matched := map[string]bool{}

	// Match mỗi skeleton với person gần nhất
	for i, sk := range skeletons {
		if sk == nil {
			continue
		}
		sp := Species(0)
		if i < len(species) {
			sp = species[i]
		}

		nearest := t.qt.Nearest(sk.CX, sk.CY)
		if nearest != nil {
			d := math.Sqrt(dist2(sk.CX, sk.CY, nearest.X, nearest.Y))
			if d <= t.matchDist {
				// Match thành công → update person
				p := nearest.Data.(*TrackedPerson)
				p.UpdateVelocity()
				p.Skeleton = sk
				sk.ID = p.ID
				p.LastSeen = now
				p.FrameCount++
				p.Confidence = math.Min(1.0, float64(p.FrameCount)/10.0)
				matched[p.ID] = true
				continue
			}
		}

		// Không match → person mới
		id := fmt.Sprintf("P%03d", t.nextID)
		t.nextID++
		sk.ID = id
		p := &TrackedPerson{
			ID:         id,
			Species:    sp,
			Skeleton:   sk,
			LastSeen:   now,
			FrameCount: 1,
			Confidence: 0.1,
			PrevCX:     sk.CX,
			PrevCY:     sk.CY,
		}
		t.persons[id] = p
		matched[id] = true
	}

	// Xóa persons không thấy quá maxAge
	for id, p := range t.persons {
		if !matched[id] && now.Sub(p.LastSeen) > t.maxAge {
			delete(t.persons, id)
		}
	}

	// Update foveal attention
	skPtrs := make([]*SDFSkeleton, 0, len(t.persons))
	for _, p := range t.persons {
		skPtrs = append(skPtrs, p.Skeleton)
	}
	targets := t.foveal.Update(skPtrs)
	t.foveal.MoveFovea(targets, skPtrs)

	// Trả về list persons hiện tại
	result := make([]*TrackedPerson, 0, len(t.persons))
	for _, p := range t.persons {
		result = append(result, p)
	}
	return result
}

// ActiveCount — số người đang track
func (t *MultiPersonTracker) ActiveCount() int { return len(t.persons) }

// GetByID — lấy person theo ID
func (t *MultiPersonTracker) GetByID(id string) *TrackedPerson {
	return t.persons[id]
}

// FovealCenter — tâm nhìn hiện tại
func (t *MultiPersonTracker) FovealCenter() (float64, float64) {
	return t.foveal.CenterX, t.foveal.CenterY
}
