package alphabet

import "math"

// ArabicBasic — 28 chữ cái Arabic cơ bản (dạng độc lập)
// Arabic viết phải→trái, nhưng SDF trong ô [-0.5,+0.5]² không cần quan tâm chiều
// Codepoint: 0x0621-0x064A
var ArabicBasic = []*OlangChar{
	// ا — Alef (nét đứng)
	{Codepoint:0x0627,Glyph:"ا",Name:"Arabic Letter Alef",Script:"arabic",Category:"letter",
		SDF:SV(XCenter,YBot,YTop),
		Phonemes:[]string{"/ʔ/","/aː/"}},

	// ب — Ba (đĩa + chấm dưới)
	{Codepoint:0x0628,Glyph:"ب",Name:"Arabic Letter Ba",Script:"arabic",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.8,YMid*0.3),SArc(XCenter*0.3,YMid*0.3,0.2,0,math.Pi),SDot(XCenter,YBot*0.7,0.05)),
		Phonemes:[]string{"/b/"}},

	// ت — Ta (như Ba + 2 chấm trên)
	{Codepoint:0x062A,Glyph:"ت",Name:"Arabic Letter Ta",Script:"arabic",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.8,YMid*0.3),SArc(XCenter*0.3,YMid*0.3,0.2,0,math.Pi),SDot(XMidL,YMid,0.04),SDot(XMidR,YMid,0.04)),
		Phonemes:[]string{"/t/"}},

	// ث — Tha (như Ba + 3 chấm trên)
	{Codepoint:0x062B,Glyph:"ث",Name:"Arabic Letter Tha",Script:"arabic",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.8,YMid*0.3),SArc(XCenter*0.3,YMid*0.3,0.2,0,math.Pi),SDot(XCenter,YMid*1.2,0.04),SDot(XMidL,YMid,0.04),SDot(XMidR,YMid,0.04)),
		Phonemes:[]string{"/θ/"}},

	// ج — Jim (bụng + chấm giữa)
	{Codepoint:0x062C,Glyph:"ج",Name:"Arabic Letter Jeem",Script:"arabic",Category:"letter",
		SDF:union(SArc(XCenter*0.2,YMid,0.22,0,math.Pi*1.5),SHook(XRight*0.5,YMid,YBase),SDot(XCenter,YBot*0.4,0.05)),
		Phonemes:[]string{"/dʒ/","/ʒ/"}},

	// د — Dal (nét chéo + đáy)
	{Codepoint:0x062F,Glyph:"د",Name:"Arabic Letter Dal",Script:"arabic",Category:"letter",
		SDF:union(SD(XCenter,YTop*0.5,XLeft*0.8,YMid),SH(XLeft*0.8,XRight*0.5,YMid)),
		Phonemes:[]string{"/d/"}},

	// ر — Ra (cong nhẹ xuống)
	{Codepoint:0x0631,Glyph:"ر",Name:"Arabic Letter Ra",Script:"arabic",Category:"letter",
		SDF:union(SD(XCenter*0.5,YTop*0.3,XLeft*0.5,YMid),SArc(XLeft*0.5,YMid,0.15,math.Pi,math.Pi*1.8)),
		Phonemes:[]string{"/r/"}},

	// س — Sin (3 răng cưa)
	{Codepoint:0x0633,Glyph:"س",Name:"Arabic Letter Sin",Script:"arabic",Category:"letter",
		SDF:union(SArc(XLeft*0.7,YMid*0.2,0.09,0,math.Pi),SArc(XCenter*0.1,YMid*0.2,0.09,0,math.Pi),SArc(XRight*0.5,YMid*0.2,0.09,0,math.Pi),SH(XLeft*0.8,XRight*0.7,YBot*0.3)),
		Phonemes:[]string{"/s/"}},

	// ص — Sad (bụng lớn + đuôi)
	{Codepoint:0x0635,Glyph:"ص",Name:"Arabic Letter Sad",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XLeft*0.3,YMid*0.3,0.18),SH(XLeft*0.5,XRight*0.7,YBot*0.3)),
		Phonemes:[]string{"/sˤ/"}},

	// ط — Ta emphatic (vòng + nét)
	{Codepoint:0x0637,Glyph:"ط",Name:"Arabic Letter Tah",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XLeft*0.3,YMid*0.2,0.18),SV(XRight*0.4,YBot,YTop*0.6)),
		Phonemes:[]string{"/tˤ/"}},

	// ع — Ain (móc đặc biệt)
	{Codepoint:0x0639,Glyph:"ع",Name:"Arabic Letter Ain",Script:"arabic",Category:"letter",
		SDF:union(SArc(XCenter*0.2,YTop*0.5,0.14,0,math.Pi),SArc(XCenter*0.1,YMid*0.2,0.2,math.Pi*0.3,math.Pi*1.5)),
		Phonemes:[]string{"/ʕ/"}},

	// ف — Fa (vòng + chấm + đuôi)
	{Codepoint:0x0641,Glyph:"ف",Name:"Arabic Letter Fa",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XLeft*0.3,YMid*0.4,0.16),SH(XLeft*0.3,XRight*0.7,YBot*0.3),SDot(XLeft*0.3,YMid*0.7,0.05)),
		Phonemes:[]string{"/f/"}},

	// ق — Qaf (vòng + 2 chấm)
	{Codepoint:0x0642,Glyph:"ق",Name:"Arabic Letter Qaf",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XCenter*0.1,YMid*0.3,0.19),SDot(XMidL,YMid*0.8,0.04),SDot(XMidR,YMid*0.8,0.04),SV(XCenter*0.1,YBase,YBot*0.3)),
		Phonemes:[]string{"/q/"}},

	// ك — Kaf (nét phức)
	{Codepoint:0x0643,Glyph:"ك",Name:"Arabic Letter Kaf",Script:"arabic",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.8,YMid*0.5),SArc(XCenter*0.3,YMid*0.5,0.2,0,math.Pi),SH(XLeft*0.5,XRight*0.7,YTop*0.4)),
		Phonemes:[]string{"/k/"}},

	// ل — Lam (móc trái)
	{Codepoint:0x0644,Glyph:"ل",Name:"Arabic Letter Lam",Script:"arabic",Category:"letter",
		SDF:union(SV(XCenter*0.3,YBot,YTop*0.7),SArc(XCenter*0.3,YTop*0.7,0.12,math.Pi*0.5,math.Pi)),
		Phonemes:[]string{"/l/"}},

	// م — Mim (vòng + đuôi)
	{Codepoint:0x0645,Glyph:"م",Name:"Arabic Letter Mim",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XCenter*0.1,YMid*0.3,0.14),SHook(XRight*0.4,YBot*0.2,YBase)),
		Phonemes:[]string{"/m/"}},

	// ن — Nun (đĩa + chấm trên)
	{Codepoint:0x0646,Glyph:"ن",Name:"Arabic Letter Nun",Script:"arabic",Category:"letter",
		SDF:union(SArc(XCenter*0.2,YMid*0.2,0.2,0,math.Pi),SH(XLeft*0.7,XRight*0.5,YBot*0.4),SDot(XCenter,YMid*0.6,0.05)),
		Phonemes:[]string{"/n/"}},

	// ه — Ha (hai vòng)
	{Codepoint:0x0647,Glyph:"ه",Name:"Arabic Letter Ha",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XMidL*0.3,YMid*0.4,0.13),SCircle(XMidR*0.5,YMid*0.3,0.1)),
		Phonemes:[]string{"/h/"}},

	// و — Waw (móc + vòng)
	{Codepoint:0x0648,Glyph:"و",Name:"Arabic Letter Waw",Script:"arabic",Category:"letter",
		SDF:union(SCircle(XCenter*0.2,YMid*0.5,0.14),SArc(XCenter*0.2,YBot*0.5,0.14,math.Pi,math.Pi*2)),
		Phonemes:[]string{"/w/","/uː/"}},

	// ي — Ya (đĩa + 2 chấm dưới)
	{Codepoint:0x064A,Glyph:"ي",Name:"Arabic Letter Ya",Script:"arabic",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.8,YMid*0.3),SArc(XCenter*0.3,YMid*0.3,0.2,0,math.Pi),SDot(XMidL,YBot*0.6,0.04),SDot(XMidR,YBot*0.6,0.04)),
		Phonemes:[]string{"/j/","/iː/"}},
}

// AllArabic — Arabic cơ bản
func AllArabic() []*OlangChar { return ArabicBasic }
