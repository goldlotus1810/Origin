package alphabet

import "math"

// CyrillicUpper — 33 chữ hoa Nga А-Я (CP: 0x410-0x42F)
// Nhiều chữ Cyrillic = hình Latin nhưng âm khác
var CyrillicUpper = []*OlangChar{
	// А = Latin A
	{Codepoint:0x410,Glyph:"А",Name:"Cyrillic Capital А",Script:"cyrillic",Category:"letter",
		SDF:union(SD(XLeft,YBot,XCenter,YTop),SD(XCenter,YTop,XRight,YBot),SH(XMidL*0.9,XMidR*0.9,YMid*0.2)),
		Phonemes:[]string{"/a/"},SameSound:[]uint32{0x41,0x391},DerivedFrom:0x391},

	// Б — như B nhưng có mái trên
	{Codepoint:0x411,Glyph:"Б",Name:"Cyrillic Capital Б",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SH(XLeft,XRight*0.8,YTop),SCurveR(XLeft,YMid+0.05,YBot)),
		Phonemes:[]string{"/b/"}},

	// В = Latin B
	{Codepoint:0x412,Glyph:"В",Name:"Cyrillic Capital В",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SCurveR(XLeft,YTop,YMid+0.02),SCurveR(XLeft,YMid+0.02,YBot)),
		Phonemes:[]string{"/v/"},SameShape:[]uint32{0x42},DerivedFrom:0x392},

	// Г = Latin Γ (Gamma)
	{Codepoint:0x413,Glyph:"Г",Name:"Cyrillic Capital Г",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SH(XLeft,XRight*0.85,YTop)),
		Phonemes:[]string{"/ɡ/"},DerivedFrom:0x393},

	// Д — như A ngược + chân
	{Codepoint:0x414,Glyph:"Д",Name:"Cyrillic Capital Д",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft*0.8,YBot,YTop),SV(XRight*0.8,YBot,YTop),SH(XLeft*0.8,XRight*0.8,YTop),
			SH(XLeft,XLeft*0.8,YBot),SH(XRight*0.8,XRight,YBot)),
		Phonemes:[]string{"/d/"}},

	// Е = Latin E
	{Codepoint:0x415,Glyph:"Е",Name:"Cyrillic Capital Е",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SH(XLeft,XRight*0.9,YTop),SH(XLeft,XRight*0.7,YMid),SH(XLeft,XRight*0.9,YBot)),
		Phonemes:[]string{"/je/"},SameShape:[]uint32{0x45},DerivedFrom:0x395},

	// Ж — нет посередине + два веера
	{Codepoint:0x416,Glyph:"Ж",Name:"Cyrillic Capital Ж",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XCenter,YBot,YTop),SD(XCenter,YMid,XRight,YTop),SD(XCenter,YMid,XRight,YBot),
			SD(XCenter,YMid,XLeft,YTop),SD(XCenter,YMid,XLeft,YBot)),
		Phonemes:[]string{"/ʐ/"}},

	// З — два полукруга
	{Codepoint:0x417,Glyph:"З",Name:"Cyrillic Capital З",Script:"cyrillic",Category:"letter",
		SDF:union(SArc(XCenter*0.3,YMid*0.6,0.18,math.Pi*0.9,math.Pi*1.9),SArc(XCenter*0.3,YMid*(-0.6),0.18,-math.Pi*0.9,math.Pi*0.1)),
		Phonemes:[]string{"/z/"}},

	// И — зеркало N
	{Codepoint:0x418,Glyph:"И",Name:"Cyrillic Capital И",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YBot,XRight,YTop),SV(XRight,YBot,YTop)),
		Phonemes:[]string{"/i/"},SameShape:[]uint32{0x4E}},

	// Й — И + дужка сверху
	{Codepoint:0x419,Glyph:"Й",Name:"Cyrillic Capital Й",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YBot,XRight,YTop),SV(XRight,YBot,YTop),
			SArc(XCenter,YTop+0.06,0.18,0,math.Pi)),
		Phonemes:[]string{"/j/"}},

	// К = Latin K
	{Codepoint:0x41A,Glyph:"К",Name:"Cyrillic Capital К",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YMid,XRight,YTop),SD(XLeft,YMid,XRight,YBot)),
		Phonemes:[]string{"/k/"},SameShape:[]uint32{0x4B},DerivedFrom:0x39A},

	// Л — два нет угол
	{Codepoint:0x41B,Glyph:"Л",Name:"Cyrillic Capital Л",Script:"cyrillic",Category:"letter",
		SDF:union(SD(XLeft*0.9,YTop,XLeft*0.9,YBot),SD(XLeft*0.9,YTop,XRight,YTop),SV(XRight,YBot,YTop)),
		Phonemes:[]string{"/l/"}},

	// М = Latin M
	{Codepoint:0x41C,Glyph:"М",Name:"Cyrillic Capital М",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YTop,XCenter,YMid),SD(XCenter,YMid,XRight,YTop),SV(XRight,YBot,YTop)),
		Phonemes:[]string{"/m/"},SameShape:[]uint32{0x4D},DerivedFrom:0x39C},

	// Н = Latin H
	{Codepoint:0x41D,Glyph:"Н",Name:"Cyrillic Capital Н",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XRight,YBot,YTop),SH(XLeft,XRight,YMid)),
		Phonemes:[]string{"/n/"},SameShape:[]uint32{0x48},DerivedFrom:0x397},

	// О = Latin O
	{Codepoint:0x41E,Glyph:"О",Name:"Cyrillic Capital О",Script:"cyrillic",Category:"letter",
		SDF:SCircle(XCenter,YMid,0.28),
		Phonemes:[]string{"/o/"},SameShape:[]uint32{0x4F},DerivedFrom:0x39F},

	// П — как Н без перекладины + верх
	{Codepoint:0x41F,Glyph:"П",Name:"Cyrillic Capital П",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XRight,YBot,YTop),SH(XLeft,XRight,YTop)),
		Phonemes:[]string{"/p/"},DerivedFrom:0x3A0},

	// Р = Latin P
	{Codepoint:0x420,Glyph:"Р",Name:"Cyrillic Capital Р",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SCurveR(XLeft,YTop,YMid)),
		Phonemes:[]string{"/r/"},SameShape:[]uint32{0x50},DerivedFrom:0x3A1},

	// С = Latin C
	{Codepoint:0x421,Glyph:"С",Name:"Cyrillic Capital С",Script:"cyrillic",Category:"letter",
		SDF:SArc(XCenter*0.4,YMid,0.28,math.Pi*0.25,math.Pi*1.75),
		Phonemes:[]string{"/s/"},SameShape:[]uint32{0x43},DerivedFrom:0x3A3},

	// Т = Latin T
	{Codepoint:0x422,Glyph:"Т",Name:"Cyrillic Capital Т",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XCenter,YBot,YTop),SH(XLeft,XRight,YTop)),
		Phonemes:[]string{"/t/"},SameShape:[]uint32{0x54},DerivedFrom:0x3A4},

	// У — как Y
	{Codepoint:0x423,Glyph:"У",Name:"Cyrillic Capital У",Script:"cyrillic",Category:"letter",
		SDF:union(SD(XLeft,YTop,XCenter,YMid),SD(XRight,YTop,XCenter,YMid),SV(XCenter,YBot,YMid)),
		Phonemes:[]string{"/u/"},SameShape:[]uint32{0x59},DerivedFrom:0x3A5},

	// Ф — circle + вертикаль
	{Codepoint:0x424,Glyph:"Ф",Name:"Cyrillic Capital Ф",Script:"cyrillic",Category:"letter",
		SDF:union(SCircle(XCenter,YMid,0.22),SV(XCenter,YBot,YTop)),
		Phonemes:[]string{"/f/"},DerivedFrom:0x3A6},

	// Х = Latin X
	{Codepoint:0x425,Glyph:"Х",Name:"Cyrillic Capital Х",Script:"cyrillic",Category:"letter",
		SDF:union(SD(XLeft,YTop,XRight,YBot),SD(XLeft,YBot,XRight,YTop)),
		Phonemes:[]string{"/x/"},SameShape:[]uint32{0x58},DerivedFrom:0x3A7},

	// Ц — П + хвост
	{Codepoint:0x426,Glyph:"Ц",Name:"Cyrillic Capital Ц",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XRight*0.8,YBot,YTop),SH(XLeft,XRight*0.8,YTop),
			SD(XRight*0.8,YBot,XRight,YBase*0.5)),
		Phonemes:[]string{"/ts/"}},

	// Ч — обратное Г + вертикаль
	{Codepoint:0x427,Glyph:"Ч",Name:"Cyrillic Capital Ч",Script:"cyrillic",Category:"letter",
		SDF:union(SCurveR(XLeft,YTop,YMid),SV(XRight,YBot,YTop)),
		Phonemes:[]string{"/tɕ/"}},

	// Ш — три вертикали + низ
	{Codepoint:0x428,Glyph:"Ш",Name:"Cyrillic Capital Ш",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XCenter,YBot,YTop),SV(XRight,YBot,YTop),SH(XLeft,XRight,YBot)),
		Phonemes:[]string{"/ʂ/"}},

	// Щ — Ш + хвост
	{Codepoint:0x429,Glyph:"Щ",Name:"Cyrillic Capital Щ",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XCenter*0.7,YBot,YTop),SV(XRight*0.7,YBot,YTop),SH(XLeft,XRight*0.7,YBot),
			SD(XRight*0.7,YBot,XRight,YBase*0.5)),
		Phonemes:[]string{"/ɕː/"}},

	// Ъ — мягкий знак вариант
	{Codepoint:0x42A,Glyph:"Ъ",Name:"Cyrillic Capital Ъ",Script:"cyrillic",Category:"letter",
		SDF:union(SH(XLeft,XLeft*0.3,YTop),SV(XLeft*0.3,YBot,YTop),SCurveR(XLeft*0.3,YMid+0.05,YBot)),
		Phonemes:[]string{"ʺ"}},

	// Ы — И + мягкий знак
	{Codepoint:0x42B,Glyph:"Ы",Name:"Cyrillic Capital Ы",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SCurveR(XLeft,YMid+0.05,YBot),SV(XRight*0.5,YBot,YTop)),
		Phonemes:[]string{"/ɨ/"}},

	// Ь — мягкий знак
	{Codepoint:0x42C,Glyph:"Ь",Name:"Cyrillic Capital Ь",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SCurveR(XLeft,YMid+0.05,YBot)),
		Phonemes:[]string{"ʹ"}},

	// Э — обратное С
	{Codepoint:0x42D,Glyph:"Э",Name:"Cyrillic Capital Э",Script:"cyrillic",Category:"letter",
		SDF:union(SArc(XCenter*(-0.4),YMid,0.28,-math.Pi*0.75,math.Pi*0.75),SH(XCenter*(-0.4),XRight*0.5,YMid)),
		Phonemes:[]string{"/e/"}},

	// Ю — И + О
	{Codepoint:0x42E,Glyph:"Ю",Name:"Cyrillic Capital Ю",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SH(XLeft,XCenter*0.3,YMid),SCircle(XCenter*0.7,YMid,0.2)),
		Phonemes:[]string{"/ju/"}},

	// Я — зеркало R
	{Codepoint:0x42F,Glyph:"Я",Name:"Cyrillic Capital Я",Script:"cyrillic",Category:"letter",
		SDF:union(SV(XRight,YBot,YTop),SCurveL(XRight,YTop,YMid),SD(XCenter*0.1,YMid,XRight,YBot)),
		Phonemes:[]string{"/ja/"}},
}

// AllCyrillic — toàn bộ Cyrillic (chỉ uppercase, lowercase tự suy)
func AllCyrillic() []*OlangChar { return CyrillicUpper }
