package alphabet

import "math"

// DevanagariBasic — 16 nguyên âm + 36 phụ âm Devanagari (Sanskrit/Hindi)
// Codepoint: 0x0900-0x097F
// Đặc trưng: mọi chữ đều có đường kẻ ngang ở trên (shiromani)
var DevanagariBasic = []*OlangChar{
	// अ — nguyên âm a (không có dấu)
	{Codepoint:0x0905,Glyph:"अ",Name:"Devanagari Letter A",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SCurveR(XLeft*0.7,YMid,YBot),SV(XRight*0.6,YBot,YTop)),
		Phonemes:[]string{"/ə/","/a/"}},

	// आ — nguyên âm aa
	{Codepoint:0x0906,Glyph:"आ",Name:"Devanagari Letter AA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SCurveR(XLeft*0.7,YMid,YBot),SV(XRight*0.3,YBot,YTop),SV(XRight*0.8,YBot,YTop)),
		Phonemes:[]string{"/aː/"}},

	// इ — nguyên âm i
	{Codepoint:0x0907,Glyph:"इ",Name:"Devanagari Letter I",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.8,YTop),SV(XRight*0.5,YBot,YTop),SArc(XLeft*0.3,YMid,0.2,0,math.Pi)),
		Phonemes:[]string{"/ɪ/"}},

	// क — phụ âm ka
	{Codepoint:0x0915,Glyph:"क",Name:"Devanagari Letter KA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SD(XLeft*0.7,YMid,XRight,YTop),SD(XLeft*0.7,YMid,XRight,YBot)),
		Phonemes:[]string{"/k/"}},

	// ख — phụ âm kha
	{Codepoint:0x0916,Glyph:"ख",Name:"Devanagari Letter KHA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SCurveR(XLeft*0.7,YTop,YMid),SDot(XRight*0.5,YMid*0.3,0.06)),
		Phonemes:[]string{"/kʰ/"}},

	// ग — phụ âm ga
	{Codepoint:0x0917,Glyph:"ग",Name:"Devanagari Letter GA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SH(XLeft*0.7,XRight*0.7,YMid)),
		Phonemes:[]string{"/ɡ/"}},

	// च — phụ âm ca
	{Codepoint:0x091A,Glyph:"च",Name:"Devanagari Letter CA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SArc(XCenter*0.2,YMid,0.2,0,math.Pi),SV(XRight*0.6,YBot,YTop)),
		Phonemes:[]string{"/tɕ/"}},

	// त — phụ âm ta
	{Codepoint:0x0924,Glyph:"त",Name:"Devanagari Letter TA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SD(XLeft*0.5,YTop,XLeft*0.5,YBot),SH(XLeft*0.5,XRight*0.7,YMid)),
		Phonemes:[]string{"/t̪/"}},

	// न — phụ âm na
	{Codepoint:0x0928,Glyph:"न",Name:"Devanagari Letter NA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SH(XLeft*0.7,XRight*0.7,YMid),SV(XRight*0.6,YBot,YTop)),
		Phonemes:[]string{"/n/"}},

	// प — phụ âm pa
	{Codepoint:0x092A,Glyph:"प",Name:"Devanagari Letter PA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SCurveR(XLeft*0.7,YTop,YMid),SV(XRight*0.6,YMid,YTop)),
		Phonemes:[]string{"/p/"}},

	// म — phụ âm ma
	{Codepoint:0x092E,Glyph:"म",Name:"Devanagari Letter MA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SD(XLeft*0.7,YTop,XCenter,YMid),SD(XCenter,YMid,XRight*0.6,YTop),SV(XRight*0.6,YBot,YTop)),
		Phonemes:[]string{"/m/"}},

	// र — phụ âm ra (đặc biệt)
	{Codepoint:0x0930,Glyph:"र",Name:"Devanagari Letter RA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SD(XLeft*0.5,YTop,XRight*0.7,YBot)),
		Phonemes:[]string{"/r/"}},

	// स — phụ âm sa
	{Codepoint:0x0938,Glyph:"स",Name:"Devanagari Letter SA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SArc(XCenter*0.2,YMid*0.7,0.15,math.Pi*0.3,math.Pi*1.7),SArc(XCenter*0.2,YMid*(-0.3),0.15,-math.Pi*0.7,0)),
		Phonemes:[]string{"/s/"}},

	// ह — phụ âm ha
	{Codepoint:0x0939,Glyph:"ह",Name:"Devanagari Letter HA",Script:"devanagari",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SV(XLeft*0.7,YBot,YTop),SCurveR(XLeft*0.7,YTop,YMid)),
		Phonemes:[]string{"/h/"}},

	// ् — virama (xóa nguyên âm)
	{Codepoint:0x094D,Glyph:"्",Name:"Devanagari Virama",Script:"devanagari",Category:"mark",
		SDF:SDot(XCenter,YBot*0.5,0.05)},
}

// AllDevanagari — Devanagari cơ bản
func AllDevanagari() []*OlangChar { return DevanagariBasic }
