package alphabet

import "math"

// CJK3 — batch 3: phương hướng, cảm xúc, hành động, giao thông, địa lý
var CJK3 = []*OlangChar{
	// phương hướng / không gian
	{Codepoint:0x5DE6,Glyph:"左",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0*0.7,cW*0.3,cQT*0.4),cH(-cW*0.6,cW*0.6,cQT*0.4),cV(-cW*0.2,-cH0,cQT*0.4),cH(-cW,cW,-cH0*0.4),cH(-cW,cW,-cH0))},
	{Codepoint:0x53F3,Glyph:"右",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0*0.7,cW*0.4,cQT*0.4),cH(-cW*0.6,cW*0.6,cQT*0.4),cH(-cW*0.7,cW*0.7,cQT*0.1),cH(-cW*0.7,cW*0.7,cQB*0.3),cV(-cW*0.7,cQB*0.3,cQT*0.1),cV(cW*0.7,cQB*0.3,cQT*0.1),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x91CC,Glyph:"里",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cH(-cW,cW,-cH0),cV(-cW*0.6,-cH0,cH0),cV(cW*0.6,-cH0,cH0),cH(-cW,cW,0),cV(0,-cH0,cH0))},
	{Codepoint:0x5916,Glyph:"外",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0*0.7,0,0),cD(0,0,-cW*0.4,-cH0),cD(cW*0.3,cH0,cW*0.7,cQT*0.4),cD(cW*0.7,cQT*0.4,cW*0.3,-cH0),cDot(cW*0.7,cQT*0.4))},
	{Codepoint:0x524D,Glyph:"前",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,0,cQT*0.5),cD(cW*0.3,cH0,0,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cH(-cW*0.7,cW*0.7,0),cV(-cW*0.7,0,cQT*0.5),cV(cW*0.7,0,cQT*0.5),cH(-cW,cW,-cH0*0.4),cV(-cW*0.3,-cH0*0.4,-cH0),cV(cW*0.3,-cH0*0.4,-cH0))},
	{Codepoint:0x540E,Glyph:"后",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.2,cH0,0,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cV(-cW*0.7,-cH0*0.3,cQT*0.5),cH(-cW*0.7,cW*0.7,0),cH(-cW*0.7,cW*0.7,-cH0*0.3),cV(-cW*0.7,-cH0*0.3,0),cV(cW*0.7,-cH0*0.3,0),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x90A3,Glyph:"那",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cH(-cW,0,cQT*0.2),cH(-cW,0,-cH0*0.4),cV(-cW,-cH0*0.4,cH0*0.7),cV(0,-cH0,cH0),cD(cW*0.2,cQT*0.4,cW*0.8,-cH0*0.3))},
	{Codepoint:0x5929,Glyph:"天",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cH(-cW,cW,cQT*0.2),cV(0,cQT*0.2,cH0*0.8),cD(0,cQT*0.2,-cW,-cH0),cD(0,cQT*0.2,cW,-cH0))},
	{Codepoint:0x5730,Glyph:"地",Script:"cjk",Category:"letter",SDF:union(cV(-cW*0.7,-cH0,cH0),cH(-cW*0.7,cW*0.3,cH0*0.6),cH(-cW*0.7,cW*0.3,cQT*0.2),cH(-cW*0.7,cW*0.3,-cH0*0.4),cD(cW*0.3,cH0*0.6,cW*0.7,-cH0),cD(cW*0.7,-cH0,cW*0.3,cQT*0.2))},
	// cảm xúc
	{Codepoint:0x559C,Glyph:"喜",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0),cV(-cW*0.5,-cH0*0.2,cH0),cV(cW*0.5,-cH0*0.2,cH0),cH(-cW*0.5,cW*0.5,cQT*0.5),cH(-cW*0.5,cW*0.5,cQT*0.1),cH(-cW*0.7,cW*0.7,cQB*0.3),cH(-cW*0.7,cW*0.7,cQB*0.7),cV(-cW*0.7,cQB*0.3,cQB*0.7),cV(cW*0.7,cQB*0.3,cQB*0.7),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x6012,Glyph:"怒",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.5),cD(cW*0.4,cH0,0,cQT*0.5),cH(-cW*0.5,cW*0.5,cQT*0.5),cV(-cW*0.5,cQT*0.1,cQT*0.5),cV(cW*0.5,cQT*0.1,cQT*0.5),cH(-cW*0.5,cW*0.5,cQT*0.1),cArc(-cW*0.5,cQB*0.4,cW*0.45,0,math.Pi),cArc(cW*0.2,cQB*0.4,cW*0.3,0,math.Pi))},
	{Codepoint:0x7231,Glyph:"爱",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,0,cQT*0.6),cD(cW*0.3,cH0,0,cQT*0.6),cH(-cW*0.7,cW*0.7,cQT*0.6),cD(-cW*0.3,cQT*0.2,-cW*0.7,-cH0*0.3),cD(cW*0.3,cQT*0.2,cW*0.7,-cH0*0.3),cH(-cW*0.7,cW*0.7,cQT*0.2),cD(-cW*0.3,-cH0*0.3,-cW,-cH0),cD(cW*0.3,-cH0*0.3,cW,-cH0),cDot(0,-cH0*0.3))},
	// hành động
	{Codepoint:0x95EE,Glyph:"问",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),cH(-cW*0.7,cW*0.7,cQT*0.4),cH(-cW*0.7,cW*0.7,cQB*0.4),cV(-cW*0.7,cQB*0.4,cQT*0.4),cV(cW*0.7,cQB*0.4,cQT*0.4),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x542C,Glyph:"听",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW*0.1,cQT*0.4),cH(-cW,cW*0.1,cQB*0.4),cV(-cW,cQB*0.4,cQT*0.4),cV(cW*0.1,cQB*0.4,cQT*0.4),cV(cW*0.4,-cH0,cH0),cD(cW*0.4,cQT*0.4,cW*0.9,-cH0*0.3))},
	{Codepoint:0x5199,Glyph:"写",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cD(-cW*0.7,cQT*0.5,-cW*0.7,-cH0*0.3),cArc(0,-cH0*0.4,cW*0.6,0,math.Pi))},
	{Codepoint:0x8BFB,Glyph:"读",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0,cH0*0.6),cD(cW*0.1,cH0*0.6,cW*0.5,cQT*0.2),cD(cW*0.5,cQT*0.2,cW*0.8,-cH0*0.4))},
	{Codepoint:0x753B,Glyph:"画",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cD(-cW*0.5,cH0*0.8,0,cQT*0.4),cH(-cW*0.7,cW*0.7,cQT*0.4),cH(-cW*0.7,cW*0.7,cQB*0.4),cV(-cW*0.7,cQB*0.4,cQT*0.4),cV(cW*0.7,cQB*0.4,cQT*0.4),cH(-cW*0.7,cW*0.7,-cH0),cV(-cW*0.1,cQB*0.4,-cH0),cV(cW*0.1,cQB*0.4,-cH0))},
	{Codepoint:0x4E70,Glyph:"买",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,0,cQT*0.5),cD(cW*0.3,cH0,0,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cD(0,cQT*0.5,-cW,-cH0),cD(0,cQT*0.5,cW,-cH0))},
	{Codepoint:0x5356,Glyph:"卖",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0),cD(-cW*0.3,cH0,0,cQT*0.6),cD(cW*0.3,cH0,0,cQT*0.6),cH(-cW*0.7,cW*0.7,cQT*0.6),cD(0,cQT*0.6,-cW,-cH0),cD(0,cQT*0.6,cW,-cH0))},
	{Codepoint:0x7ED9,Glyph:"给",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0,cH0*0.6),cD(cW*0.1,cH0*0.6,cW*0.5,cQT*0.2),cD(cW*0.5,cQT*0.2,cW*0.8,-cH0*0.4))},
	{Codepoint:0x62FF,Glyph:"拿",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,0,cQT*0.5),cD(cW*0.3,cH0,0,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),cV(-cW*0.3,cQT*0.1,cQT*0.5),cV(cW*0.3,cQT*0.1,cQT*0.5),cH(-cW*0.3,cW*0.3,cQT*0.1),cH(-cW,cW,-cH0*0.4),cV(-cW*0.4,-cH0*0.4,-cH0),cV(cW*0.4,-cH0*0.4,-cH0))},
	// giao thông / địa lý
	{Codepoint:0x98DE,Glyph:"飞",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.2,cH0,0,cQT*0.3),cH(-cW*0.7,cW*0.7,cQT*0.3),cD(0,cQT*0.3,-cW*0.7,-cH0),cArc(cW*0.4,0,cW*0.4,0,math.Pi))},
	{Codepoint:0x6CB3,Glyph:"河",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0,cH0*0.6),cH(cW*0.1,cW*0.8,cQT*0.2),cH(cW*0.1,cW*0.8,cQB*0.2),cH(cW*0.1,cW*0.8,-cH0))},
	{Codepoint:0x6D77,Glyph:"海",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cDot(cW*0.3,cH0*0.7),cH(cW*0.1,cW*0.8,cQT*0.5),cV(cW*0.1,-cH0,cQT*0.5),cH(cW*0.1,cW*0.8,cQT*0.1),cH(cW*0.1,cW*0.8,cQB*0.3),cH(cW*0.1,cW*0.8,-cH0))},
	{Codepoint:0x57CE,Glyph:"城",Script:"cjk",Category:"letter",SDF:union(cV(-cW*0.7,-cH0,cH0),cH(-cW*0.7,cW*0.3,cH0*0.6),cH(-cW*0.7,cW*0.3,cQT*0.2),cH(-cW*0.7,cW*0.3,-cH0*0.4),cH(-cW*0.7,cW*0.3,-cH0),cD(cW*0.3,cH0*0.6,cW*0.8,-cH0*0.3),cD(cW*0.3,cH0*0.6,cW*0.8,cQT*0.4))},
	{Codepoint:0x6751,Glyph:"村",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cD(-cW*0.5,0,-cW,-cH0*0.4),cH(cW*0.1,cW*0.8,cQT*0.5),cV(cW*0.1,-cH0,cH0),cD(cW*0.5,cQT*0.5,cW*0.8,-cH0*0.3))},
	{Codepoint:0x6865,Glyph:"桥",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cD(-cW*0.5,0,-cW,-cH0*0.4),cD(cW*0.1,cH0,cW*0.8,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cV(cW*0.5,-cH0,cH0*0.7),cD(cW*0.5,cQT*0.3,cW*0.8,-cH0*0.3))},
	// quan hệ xã hội
	{Codepoint:0x670B,Glyph:"朋",Script:"cjk",Category:"letter",SDF:union(cArc(-cW*0.3,0,cW*0.35,-math.Pi/2,math.Pi/2),cH(-cW*0.3,cW*0.1,cQT*0.4),cH(-cW*0.3,cW*0.1,cQB*0.4),cV(-cW*0.3,-cH0,cH0),cArc(cW*0.3,0,cW*0.35,-math.Pi/2,math.Pi/2),cH(cW*0.1,cW*0.7,cQT*0.4),cH(cW*0.1,cW*0.7,cQB*0.4),cV(cW*0.1,-cH0,cH0))},
	{Codepoint:0x53CB,Glyph:"友",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0*0.7,cW*0.3,cQT*0.4),cH(-cW*0.6,cW*0.6,cQT*0.4),cD(0,cQT*0.4,-cW,-cH0),cD(0,cQT*0.4,cW,-cH0))},
	{Codepoint:0x5E08,Glyph:"师",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW*0.1,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cH(-cW*0.7,cW*0.1,cQT*0.2),cH(-cW*0.7,cW*0.1,-cH0),cV(cW*0.1,-cH0,cH0),cD(cW*0.4,cH0,cW*0.8,-cH0*0.3))},
	{Codepoint:0x533B,Glyph:"医",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cH(-cW,cW,-cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),cD(-cW*0.3,cQT*0.4,-cW*0.3,-cH0*0.4),cH(-cW*0.5,cW*0.5,cQT*0.1),cD(-cW*0.5,cQT*0.1,cW*0.5,-cH0*0.2))},
	// vật liệu
	{Codepoint:0x77F3,Glyph:"石",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.2,cH0,cW*0.4,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,cQT*0.5),cV(cW*0.6,-cH0,cQT*0.5),cH(-cW*0.6,cW*0.6,0))},
	{Codepoint:0x9435,Glyph:"铁",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,0,cH0*0.6),cV(cW*0.8,0,cH0*0.6),cH(cW*0.1,cW*0.8,0),cD(cW*0.1,0,cW*0.5,-cH0),cD(cW*0.8,0,cW*0.5,-cH0))},
	// khoa học
	{Codepoint:0x79D1,Glyph:"科",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cQT*0.5),cV(-cW*0.5,-cH0,cH0),cD(-cW*0.5,0,-cW,-cH0*0.4),cH(-cW*0.5,0,0),cD(-cW*0.5,0,0,-cH0),cV(cW*0.4,-cH0,cH0),cD(cW*0.1,cQT*0.4,cW*0.8,-cH0*0.3))},
	{Codepoint:0x6280,Glyph:"技",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cD(-cW*0.5,0,-cW,-cH0*0.4),cH(cW*0.1,cW*0.8,cQT*0.5),cV(cW*0.1,-cH0,cH0),cD(cW*0.1,cH0,cW*0.4,cQT*0.5),cD(cW*0.4,cQT*0.5,cW*0.8,-cH0*0.3))},
	{Codepoint:0x7406,Glyph:"理",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cH(-cW*0.7,0,cQT*0.2),cH(-cW*0.7,0,cQB*0.2),cH(-cW*0.7,0,-cH0*0.5),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0*0.6,cH0*0.6),cH(cW*0.1,cW*0.8,cQT*0.2),cH(cW*0.1,cW*0.8,cQB*0.2),cH(cW*0.1,cW*0.8,-cH0*0.6))},
	// chất lượng
	{Codepoint:0x591A,Glyph:"多",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.4),cD(cW*0.3,cQT*0.4,-cW*0.3,-cH0*0.2),cD(-cW*0.3,0,cW*0.5,-cH0))},
	{Codepoint:0x5C11,Glyph:"少",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.7),cV(0,-cH0,cH0*0.7),cDot(-cW*0.6,cQB*0.5))},
	{Codepoint:0x957F,Glyph:"长",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cV(0,cQT*0.5,cH0*0.8),cD(0,cQT*0.5,-cW,0),cD(0,cQT*0.5,cW*0.5,-cH0*0.4),cArc(cW*0.2,-cH0*0.5,cW*0.4,0,math.Pi))},
	{Codepoint:0x65B0,Glyph:"新",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0*0.3,cH0*0.7),cH(-cW*0.7,0,cQT*0.2),cH(-cW*0.7,0,cQB*0.2),cD(-cW*0.5,-cH0*0.3,-cW,-cH0),cD(cW*0.1,cH0,cW*0.6,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cD(cW*0.3,cQT*0.4,cW*0.8,-cH0*0.3))},
	{Codepoint:0x9AD8,Glyph:"高",Script:"cjk",Category:"letter",SDF:union(cDot(0,cH0*0.8),cH(-cW*0.4,cW*0.4,cH0*0.5),cV(0,cQT*0.3,cH0*0.5),cH(-cW*0.7,cW*0.7,cQT*0.3),cH(-cW*0.7,cW*0.7,0),cV(-cW*0.7,0,cQT*0.3),cV(cW*0.7,0,cQT*0.3),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x5FEB,Glyph:"快",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cD(cW*0.1,cH0,cW*0.5,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cD(cW*0.5,cQT*0.4,cW*0.8,0),cD(cW*0.5,cQT*0.4,cW*0.8,-cH0*0.5))},
	// từ phổ biến
	{Codepoint:0x53EF,Glyph:"可",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.6),cV(-cW*0.5,-cH0,cH0*0.6),cH(-cW*0.7,0,cQT*0.2),cH(-cW*0.7,0,-cH0),cH(cW*0.1,cW*0.8,cQT*0.4),cH(cW*0.1,cW*0.8,cQB*0.4),cV(cW*0.1,cQB*0.4,cQT*0.4),cV(cW*0.8,cQB*0.4,cQT*0.4))},
	{Codepoint:0x80FD,Glyph:"能",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW*0.1,cH0*0.6),cV(-cW*0.5,-cH0,cH0*0.6),cH(-cW*0.7,cW*0.1,cQT*0.2),cH(-cW*0.7,cW*0.1,cQB*0.2),cV(cW*0.3,-cH0,cH0*0.5),cV(cW*0.8,-cH0,cH0*0.5),cD(cW*0.3,cQT*0.2,cW*0.8,-cH0*0.3))},
	{Codepoint:0x4F1A,Glyph:"会",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,0,cQT*0.5),cD(cW*0.3,cH0,0,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),cH(-cW*0.6,cW*0.6,0),cV(-cW*0.6,0,cQT*0.5),cV(cW*0.6,0,cQT*0.5),cV(-cW*0.3,-cH0,0),cV(cW*0.3,-cH0,0))},
	{Codepoint:0x5BF9,Glyph:"对",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cH(-cW*0.7,0,cQT*0.2),cH(-cW*0.7,0,-cH0),cD(cW*0.1,cH0,cW*0.7,cQT*0.4),cDot(cW*0.7,cH0*0.5))},
	{Codepoint:0x6CA1,Glyph:"没",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cQT*0.5),cV(cW*0.1,-cH0*0.3,cH0),cD(cW*0.1,cH0,cW*0.5,cQT*0.5),cD(cW*0.5,cQT*0.5,cW*0.8,-cH0*0.3))},
	{Codepoint:0x4EE5,Glyph:"以",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cV(cW*0.2,-cH0,cH0),cD(cW*0.5,cQT*0.4,cW*0.9,-cH0*0.5),cDot(cW*0.6,cH0*0.5))},
	{Codepoint:0x548C,Glyph:"和",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cQT*0.5),cV(-cW*0.5,-cH0,cH0),cD(-cW*0.5,cQT*0.5,-cW,-cH0*0.4),cD(-cW*0.5,cQT*0.5,0,cQB*0.3),cH(cW*0.1,cW*0.8,cQT*0.4),cH(cW*0.1,cW*0.8,cQB*0.4),cV(cW*0.1,cQB*0.4,cQT*0.4),cV(cW*0.8,cQB*0.4,cQT*0.4))},
	{Codepoint:0x4E3A,Glyph:"为",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.6,cQT*0.3),cArc(cW*0.2,0,cW*0.5,math.Pi*0.1,math.Pi),cD(-cW*0.2,0,-cW*0.6,-cH0),cDot(cW*0.5,cQB*0.5))},
	{Codepoint:0x518D,Glyph:"再",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cV(0,cQT*0.3,cH0*0.8),cH(-cW*0.7,cW*0.7,cQT*0.3),cV(-cW*0.7,-cH0,cQT*0.3),cV(cW*0.7,-cH0,cQT*0.3),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x5C31,Glyph:"就",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW*0.2,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cH(-cW*0.7,cW*0.2,cQT*0.2),cH(-cW*0.7,cW*0.2,-cH0),cV(cW*0.4,-cH0,cH0),cD(cW*0.4,cQT*0.4,cW*0.9,-cH0*0.3))},
	{Codepoint:0x4E48,Glyph:"么",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,0,cQT*0.4),cD(cW*0.3,cH0,0,cQT*0.4),cArc(0,0,cW*0.4,0,math.Pi))},
	{Codepoint:0x54EA,Glyph:"哪",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW*0.1,cQT*0.4),cH(-cW,cW*0.1,cQB*0.4),cV(-cW,cQB*0.4,cQT*0.4),cV(cW*0.1,cQB*0.4,cQT*0.4),cH(cW*0.1,0,cH0*0.7),cH(cW*0.1,0,cQT*0.2),cH(cW*0.1,0,-cH0*0.4),cV(cW*0.1,-cH0*0.4,cH0*0.7),cV(0,-cH0,cH0))},
	{Codepoint:0x4EC0,Glyph:"什",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cV(cW*0.1,-cH0,cH0),cD(cW*0.5,cH0,cW*0.8,-cH0*0.5))},
	{Codepoint:0x4E2A,Glyph:"个",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cQT*0.5,0,cH0),cD(cW*0.3,cQT*0.5,0,cH0),cV(0,-cH0,cQT*0.5))},
	{Codepoint:0x4EEC,Glyph:"们",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0),cV(cW*0.1,-cH0,cH0),cV(cW*0.8,-cH0,cH0))},
	{Codepoint:0x8FD9,Glyph:"这",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cQT*0.5,cW*0.3,0),cH(-cW*0.5,cW*0.7,0),cV(-cW*0.1,-cH0*0.5,0),cD(-cW*0.5,cQB*0.5,-cW,-cH0),cD(cW*0.5,0,cW,-cH0*0.5))},
	{Codepoint:0x4E5F,Glyph:"也",Script:"cjk",Category:"letter",SDF:union(cV(-cW*0.5,-cH0,cH0),cH(-cW*0.5,cW*0.7,cQT*0.3),cD(cW*0.7,cQT*0.3,cW*0.9,-cH0*0.5),cArc(cW*0.1,-cH0*0.5,cW*0.5,0,math.Pi))},
	{Codepoint:0x53EA,Glyph:"只",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.7),cV(-cW*0.2,-cH0,cH0*0.7),cD(-cW*0.2,0,-cW,-cH0),cD(-cW*0.2,0,cW*0.5,-cH0))},
	{Codepoint:0x90FD,Glyph:"都",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW*0.2,cH0*0.7),cH(-cW,cW*0.2,cQT*0.2),cH(-cW,cW*0.2,cQB*0.2),cH(-cW,cW*0.2,-cH0),cV(-cW,-cH0,cH0*0.7),cV(cW*0.2,-cH0,cH0),cD(cW*0.5,cH0,cW*0.9,-cH0*0.3))},
	{Codepoint:0x8FD8,Glyph:"还",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.5,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cArc(0,0,cW*0.5,math.Pi*0.1,math.Pi),cD(-cW*0.5,0,-cW,-cH0),cD(cW*0.5,0,cW,-cH0*0.5))},
	{Codepoint:0x624D,Glyph:"才",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.7),cV(0,-cH0,cH0*0.7),cD(0,0,-cW,-cH0))},
	{Codepoint:0x66F4,Glyph:"更",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.8),cV(0,cQT*0.4,cH0*0.8),cH(-cW*0.6,cW*0.6,cQT*0.4),cH(-cW*0.6,cW*0.6,0),cD(0,0,-cW,-cH0),cD(0,0,cW,-cH0))},
	// âm nhạc
	{Codepoint:0x97F3,Glyph:"音",Script:"cjk",Category:"letter",SDF:union(cDot(0,cH0*0.8),cH(-cW*0.5,cW*0.5,cH0*0.5),cV(0,0,cH0*0.5),cH(-cW*0.7,cW*0.7,0),cH(-cW*0.7,cW*0.7,-cH0*0.4),cV(-cW*0.7,-cH0*0.4,0),cV(cW*0.7,-cH0*0.4,0),cH(-cW*0.7,cW*0.7,-cH0))},
	{Codepoint:0x661F,Glyph:"星",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cV(-cW*0.5,cQT*0.4,cH0),cV(cW*0.5,cQT*0.4,cH0),cH(-cW*0.5,cW*0.5,cQT*0.4),cH(-cW*0.6,cW*0.6,-cH0*0.4),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,-cH0*0.4),cV(cW*0.6,-cH0,-cH0*0.4),cH(-cW*0.6,cW*0.6,0))},
	{Codepoint:0x5149,Glyph:"光",Script:"cjk",Category:"letter",SDF:union(cDot(0,cH0*0.8),cH(-cW*0.5,cW*0.5,cH0*0.5),cV(0,0,cH0*0.5),cD(0,0,-cW,-cH0),cD(0,0,cW,-cH0),cH(-cW*0.3,cW*0.3,-cH0*0.5))},
	{Codepoint:0x767E,Glyph:"百",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.2,cH0,cW*0.2,cQT*0.6),cH(-cW*0.6,cW*0.6,cQT*0.6),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,cQT*0.6),cV(cW*0.6,-cH0,cQT*0.6),cH(-cW*0.6,cW*0.6,0))},
	{Codepoint:0x5343,Glyph:"千",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,cW*0.2,cQT*0.5),cH(-cW,cW,cQT*0.5),cV(0,-cH0,cH0*0.9))},
	{Codepoint:0x4E07,Glyph:"万",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.7,cW*0.7,cH0*0.7),cD(cW*0.3,cH0*0.7,-cW,-cH0*0.5),cArc(cW*0.3,-cH0*0.5,cW*0.4,math.Pi*0.5,math.Pi*1.5))},
	{Codepoint:0x4EBF,Glyph:"亿",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cD(cW*0.1,cH0,cW*0.7,cQT*0.4),cArc(cW*0.4,0,cW*0.35,0,math.Pi))},
}
