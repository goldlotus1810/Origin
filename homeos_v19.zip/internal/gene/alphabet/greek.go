package alphabet

import (
	"math"
	"github.com/goldlotus1810/HomeOS/internal/gene"
)

const _pi = math.Pi

// GreekUpper — 24 chữ hoa Hy Lạp Α-Ω
var GreekUpper = []*OlangChar{
	{Codepoint:0x391,Glyph:"Α",Name:"Greek Capital Alpha",Script:"greek",Category:"letter",
		SDF:union(SD(XLeft,YBot,XCenter,YTop),SD(XCenter,YTop,XRight,YBot),SH(XMidL*0.9,XMidR*0.9,YMid*0.2)),
		Phonemes:[]string{"/a/"},SameSound:[]uint32{0x41,0x0410},DerivedFrom:0x10900},

	{Codepoint:0x392,Glyph:"Β",Name:"Greek Capital Beta",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SCurveR(XLeft,YTop,YMid+0.02),SCurveR(XLeft,YMid+0.02,YBot)),
		Phonemes:[]string{"/v/"},SameSound:[]uint32{0x42,0x0411}},

	{Codepoint:0x393,Glyph:"Γ",Name:"Greek Capital Gamma",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SH(XLeft,XRight*0.85,YTop)),
		Phonemes:[]string{"/ɣ/","/ɡ/"}},

	{Codepoint:0x394,Glyph:"Δ",Name:"Greek Capital Delta",Script:"greek",Category:"letter",
		SDF:union(SD(XCenter,YTop,XLeft,YBot),SD(XCenter,YTop,XRight,YBot),SH(XLeft,XRight,YBot)),
		Phonemes:[]string{"/ð/","/d/"}},

	{Codepoint:0x395,Glyph:"Ε",Name:"Greek Capital Epsilon",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SH(XLeft,XRight*0.9,YTop),SH(XLeft,XRight*0.7,YMid),SH(XLeft,XRight*0.9,YBot)),
		Phonemes:[]string{"/e/"},SameSound:[]uint32{0x45,0x0415}},

	{Codepoint:0x396,Glyph:"Ζ",Name:"Greek Capital Zeta",Script:"greek",Category:"letter",
		SDF:union(SH(XLeft,XRight,YTop),SD(XRight,YTop,XLeft,YBot),SH(XLeft,XRight,YBot)),
		Phonemes:[]string{"/z/"},SameSound:[]uint32{0x5A}},

	{Codepoint:0x397,Glyph:"Η",Name:"Greek Capital Eta",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XRight,YBot,YTop),SH(XLeft,XRight,YMid)),
		Phonemes:[]string{"/iː/"},SameSound:[]uint32{0x48,0x0418}},

	{Codepoint:0x398,Glyph:"Θ",Name:"Greek Capital Theta",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter,YMid,0.28),SH(XLeft*0.7,XRight*0.7,YMid)),
		Phonemes:[]string{"/θ/"}},

	{Codepoint:0x399,Glyph:"Ι",Name:"Greek Capital Iota",Script:"greek",Category:"letter",
		SDF:union(SV(XCenter,YBot,YTop),SH(XLeft*0.6,XRight*0.6,YTop),SH(XLeft*0.6,XRight*0.6,YBot)),
		Phonemes:[]string{"/i/"},SameSound:[]uint32{0x49,0x0418}},

	{Codepoint:0x39A,Glyph:"Κ",Name:"Greek Capital Kappa",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YMid,XRight,YTop),SD(XLeft,YMid,XRight,YBot)),
		Phonemes:[]string{"/k/"},SameSound:[]uint32{0x4B}},

	{Codepoint:0x39B,Glyph:"Λ",Name:"Greek Capital Lambda",Script:"greek",Category:"letter",
		SDF:union(SD(XCenter,YTop,XLeft,YBot),SD(XCenter,YTop,XRight,YBot)),
		Phonemes:[]string{"/l/"}},

	{Codepoint:0x39C,Glyph:"Μ",Name:"Greek Capital Mu",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YTop,XCenter,YMid),SD(XCenter,YMid,XRight,YTop),SV(XRight,YBot,YTop)),
		Phonemes:[]string{"/m/"},SameSound:[]uint32{0x4D,0x041C}},

	{Codepoint:0x39D,Glyph:"Ν",Name:"Greek Capital Nu",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SD(XLeft,YTop,XRight,YBot),SV(XRight,YBot,YTop)),
		Phonemes:[]string{"/n/"},SameSound:[]uint32{0x4E,0x041D}},

	{Codepoint:0x39E,Glyph:"Ξ",Name:"Greek Capital Xi",Script:"greek",Category:"letter",
		SDF:union(SH(XLeft,XRight*0.9,YTop),SH(XLeft*0.6,XRight*0.7,YMid),SH(XLeft,XRight*0.9,YBot)),
		Phonemes:[]string{"/ks/"}},

	{Codepoint:0x39F,Glyph:"Ο",Name:"Greek Capital Omicron",Script:"greek",Category:"letter",
		SDF:SCircle(XCenter,YMid,0.28),
		Phonemes:[]string{"/o/"},SameSound:[]uint32{0x4F,0x041E}},

	{Codepoint:0x3A0,Glyph:"Π",Name:"Greek Capital Pi",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SV(XRight,YBot,YTop),SH(XLeft,XRight,YTop)),
		Phonemes:[]string{"/p/"},SameSound:[]uint32{0x50}},

	{Codepoint:0x3A1,Glyph:"Ρ",Name:"Greek Capital Rho",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YTop),SCurveR(XLeft,YTop,YMid)),
		Phonemes:[]string{"/r/"},SameSound:[]uint32{0x52,0x0420}},

	{Codepoint:0x3A3,Glyph:"Σ",Name:"Greek Capital Sigma",Script:"greek",Category:"letter",
		SDF:union(SH(XLeft,XRight,YTop),SD(XRight,YTop,XLeft,YMid),SD(XLeft,YMid,XRight,YBot),SH(XLeft,XRight,YBot)),
		Phonemes:[]string{"/s/"},SameSound:[]uint32{0x53}},

	{Codepoint:0x3A4,Glyph:"Τ",Name:"Greek Capital Tau",Script:"greek",Category:"letter",
		SDF:union(SV(XCenter,YBot,YTop),SH(XLeft,XRight,YTop)),
		Phonemes:[]string{"/t/"},SameSound:[]uint32{0x54,0x0422}},

	{Codepoint:0x3A5,Glyph:"Υ",Name:"Greek Capital Upsilon",Script:"greek",Category:"letter",
		SDF:union(SD(XLeft,YTop,XCenter,YMid),SD(XRight,YTop,XCenter,YMid),SV(XCenter,YBot,YMid)),
		Phonemes:[]string{"/i/","/y/"},SameSound:[]uint32{0x59,0x0423}},

	{Codepoint:0x3A6,Glyph:"Φ",Name:"Greek Capital Phi",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter,YMid,0.22),SV(XCenter,YBot,YTop)),
		Phonemes:[]string{"/f/"}},

	{Codepoint:0x3A7,Glyph:"Χ",Name:"Greek Capital Chi",Script:"greek",Category:"letter",
		SDF:union(SD(XLeft,YTop,XRight,YBot),SD(XLeft,YBot,XRight,YTop)),
		Phonemes:[]string{"/x/","/k/"},SameSound:[]uint32{0x58}},

	{Codepoint:0x3A8,Glyph:"Ψ",Name:"Greek Capital Psi",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter,YMid*0.5,0.18),SV(XCenter,YBot,YTop),SH(XLeft*0.5,XRight*0.5,YMid*0.5)),
		Phonemes:[]string{"/ps/"}},

	{Codepoint:0x3A9,Glyph:"Ω",Name:"Greek Capital Omega",Script:"greek",Category:"letter",
		SDF:union(SArc(XCenter,YMid,0.26,0,_pi),SH(XLeft*0.8,XLeft*0.3,YBot),SH(XRight*0.3,XRight*0.8,YBot)),
		Phonemes:[]string{"/o/"},SameSound:[]uint32{0x4F}},
}

// GreekLower — 24 chữ thường α-ω
var GreekLower = []*OlangChar{
	{Codepoint:0x3B1,Glyph:"α",Name:"Greek Small Alpha",Script:"greek",Category:"letter",
		SDF:union(SCircle(XMidL*0.2,YXH*0.5,0.15),SV(XMidR*1.2,YBot,YXH)),
		Phonemes:[]string{"/a/"},UppercaseOf:0x391,SameSound:[]uint32{0x61,0x0430}},

	{Codepoint:0x3B2,Glyph:"β",Name:"Greek Small Beta",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBase,YTop),SCurveR(XLeft,YTop,YMid+0.02),SCurveR(XLeft,YMid+0.02,YXH*0.2)),
		Phonemes:[]string{"/v/","/b/"},UppercaseOf:0x392},

	{Codepoint:0x3B3,Glyph:"γ",Name:"Greek Small Gamma",Script:"greek",Category:"letter",
		SDF:union(SD(XLeft,YXH,XCenter,YBase*0.5),SD(XRight*0.8,YXH,XCenter,YBase*0.5),SV(XCenter,YBase*0.5,YBase)),
		Phonemes:[]string{"/ɣ/"},UppercaseOf:0x393},

	{Codepoint:0x3B4,Glyph:"δ",Name:"Greek Small Delta",Script:"greek",Category:"letter",
		SDF:union(SArc(XCenter*0.3,YXH*0.5,0.15,0,2*_pi),SArc(XCenter*0.4,YTop*0.7,0.18,_pi*0.3,_pi*1.5)),
		Phonemes:[]string{"/ð/"},UppercaseOf:0x394},

	{Codepoint:0x3B5,Glyph:"ε",Name:"Greek Small Epsilon",Script:"greek",Category:"letter",
		SDF:union(SArc(XCenter*0.3,YXH*0.75,0.12,_pi*0.1,_pi*1.7),SArc(XCenter*0.3,YXH*0.25,0.12,-_pi*0.7,0)),
		Phonemes:[]string{"/e/"},UppercaseOf:0x395},

	{Codepoint:0x3B6,Glyph:"ζ",Name:"Greek Small Zeta",Script:"greek",Category:"letter",
		SDF:union(SH(XLeft*0.8,XRight*0.6,YTop*0.7),SD(XRight*0.6,YTop*0.7,XLeft*0.8,YBase),SArc(XLeft*0.8,YBase,0.1,0,_pi)),
		Phonemes:[]string{"/z/"},UppercaseOf:0x396},

	{Codepoint:0x3B7,Glyph:"η",Name:"Greek Small Eta",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YXH,YBase*0.5),union(SArc(XLeft,YXH,0.18,-_pi/2,0),SV(XLeft+0.18,YBase,YXH))),
		Phonemes:[]string{"/iː/"},UppercaseOf:0x397},

	{Codepoint:0x3B8,Glyph:"θ",Name:"Greek Small Theta",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter,YMid*0.3,0.22),SH(XLeft*0.7,XRight*0.7,YMid*0.3)),
		Phonemes:[]string{"/θ/"},UppercaseOf:0x398},

	{Codepoint:0x3B9,Glyph:"ι",Name:"Greek Small Iota",Script:"greek",Category:"letter",
		SDF:SV(XCenter,YBot,YXH),
		Phonemes:[]string{"/i/"},UppercaseOf:0x399},

	{Codepoint:0x3BA,Glyph:"κ",Name:"Greek Small Kappa",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBot,YXH),SD(XLeft,YXH*0.5,XRight*0.8,YXH),SD(XLeft,YXH*0.5,XRight*0.8,YBot)),
		Phonemes:[]string{"/k/"},UppercaseOf:0x39A},

	{Codepoint:0x3BB,Glyph:"λ",Name:"Greek Small Lambda",Script:"greek",Category:"letter",
		SDF:union(SD(XCenter,YTop*0.7,XLeft*0.8,YBot),SD(XCenter,YTop*0.7,XRight*0.8,YBot)),
		Phonemes:[]string{"/l/"},UppercaseOf:0x39B},

	{Codepoint:0x3BC,Glyph:"μ",Name:"Greek Small Mu",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YBase,YXH),union(SArc(XLeft,YXH,0.13,-_pi/2,0),SV(XLeft+0.13,YBot,YXH)),union(SArc(XLeft+0.13,YXH,0.13,-_pi/2,0),SV(XLeft+0.26,YBot,YXH))),
		Phonemes:[]string{"/m/"},UppercaseOf:0x39C},

	{Codepoint:0x3BD,Glyph:"ν",Name:"Greek Small Nu",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YXH,YBot+0.05),SD(XLeft,YBot+0.05,XRight*0.8,YXH)),
		Phonemes:[]string{"/n/"},UppercaseOf:0x39D},

	{Codepoint:0x3BE,Glyph:"ξ",Name:"Greek Small Xi",Script:"greek",Category:"letter",
		SDF:union(SArc(XCenter*0.4,YTop*0.75,0.15,_pi*0.2,_pi*1.5),SArc(XCenter*0.3,YXH*0.5,0.15,_pi*0.3,_pi*1.8),SArc(XCenter*0.4,YBase*0.5,0.12,0,_pi)),
		Phonemes:[]string{"/ks/"},UppercaseOf:0x39E},

	{Codepoint:0x3BF,Glyph:"ο",Name:"Greek Small Omicron",Script:"greek",Category:"letter",
		SDF:SCircle(XCenter*0.3,YXH*0.5,0.16),
		Phonemes:[]string{"/o/"},UppercaseOf:0x39F,SameSound:[]uint32{0x6F}},

	{Codepoint:0x3C0,Glyph:"π",Name:"Greek Small Pi",Script:"greek",Category:"letter",
		SDF:union(SH(XLeft*0.9,XRight*0.7,YXH),SV(XLeft*0.7,YBot,YXH),SV(XRight*0.5,YBot,YXH)),
		Phonemes:[]string{"/p/"},UppercaseOf:0x3A0},

	{Codepoint:0x3C1,Glyph:"ρ",Name:"Greek Small Rho",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter*0.2,YXH*0.55,0.16),SV(XLeft*0.7,YBase,YXH*0.4)),
		Phonemes:[]string{"/r/"},UppercaseOf:0x3A1},

	{Codepoint:0x3C3,Glyph:"σ",Name:"Greek Small Sigma",Script:"greek",Category:"letter",
		SDF:union(SArc(XCenter*0.2,YXH*0.5,0.16,_pi*0.1,2*_pi),SH(XCenter*0.2,XRight*0.8,YXH)),
		Phonemes:[]string{"/s/"},UppercaseOf:0x3A3},

	{Codepoint:0x3C4,Glyph:"τ",Name:"Greek Small Tau",Script:"greek",Category:"letter",
		SDF:union(SV(XCenter,YBot,YXH),SH(XLeft*0.7,XRight*0.6,YXH)),
		Phonemes:[]string{"/t/"},UppercaseOf:0x3A4},

	{Codepoint:0x3C5,Glyph:"υ",Name:"Greek Small Upsilon",Script:"greek",Category:"letter",
		SDF:union(SV(XLeft,YXH,YBot+0.1),SArc(XCenter*0.1,YBot+0.1,0.19,_pi,2*_pi),SV(XRight*0.8,YBot+0.1,YXH)),
		Phonemes:[]string{"/y/","/i/"},UppercaseOf:0x3A5},

	{Codepoint:0x3C6,Glyph:"φ",Name:"Greek Small Phi",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter,YXH*0.5,0.16),SV(XCenter,YBase,YTop*0.5)),
		Phonemes:[]string{"/f/"},UppercaseOf:0x3A6},

	{Codepoint:0x3C7,Glyph:"χ",Name:"Greek Small Chi",Script:"greek",Category:"letter",
		SDF:union(SD(XLeft,YXH,XRight*0.8,YBase),SD(XLeft,YBase,XRight*0.8,YXH)),
		Phonemes:[]string{"/x/"},UppercaseOf:0x3A7},

	{Codepoint:0x3C8,Glyph:"ψ",Name:"Greek Small Psi",Script:"greek",Category:"letter",
		SDF:union(SCircle(XCenter,YXH*0.4,0.14),SV(XCenter,YBase,YTop*0.5),SH(XLeft*0.5,XRight*0.4,YXH*0.4)),
		Phonemes:[]string{"/ps/"},UppercaseOf:0x3A8},

	{Codepoint:0x3C9,Glyph:"ω",Name:"Greek Small Omega",Script:"greek",Category:"letter",
		SDF:union(SArc(XMidL*0.5,YXH*0.4,0.13,0,_pi),SArc(XMidR*0.5,YXH*0.4,0.13,0,_pi),SH(XLeft*0.5,XRight*0.4,YBot)),
		Phonemes:[]string{"/o/"},UppercaseOf:0x3A9},
}

// AllGreek — toàn bộ Greek alphabet
func AllGreek() []*OlangChar {
	out := make([]*OlangChar, 0, 48)
	out = append(out, GreekUpper...)
	out = append(out, GreekLower...)
	return out
}

// dummy dùng gene để tránh unused import
var _ = gene.Vec3{}
