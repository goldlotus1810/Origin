package alphabet

import (
	"math"
	"github.com/goldlotus1810/HomeOS/internal/gene"
)

// CJK — Top 120 common CJK characters dựng từ vSDF primitives
// Mỗi char = union các strokes cơ bản trong ô [-0.5,+0.5]²
//
// 8 stroke types CJK:
//   横(héng) = ngang  → cH
//   竖(shù)  = đứng   → cV
//   撇(piě)  = chéo↗  → cD
//   捺(nà)   = chéo↘  → cD
//   折(zhé)  = gấp    → union(cH,cV)
//   钩(gōu)  = móc    → cHook
//   点(diǎn) = chấm   → cDot
//   弯(wān)  = cong   → cArc

const (
	cW  =  0.28   // half-width
	cH0 =  0.38   // half-height
	cQL = -0.14
	cQR =  0.14
	cQT =  0.19
	cQB = -0.19
	cT  =  0.038  // stroke thickness (mảnh hơn Latin)
)

// CJK stroke helpers — dùng cap2 đã có trong strokes.go
func cV(x, y0, y1 float64)                     func(gene.Vec3) float64 { return cap2(x,y0,x,y1,cT) }
func cH(x0, x1, y float64)                     func(gene.Vec3) float64 { return cap2(x0,y,x1,y,cT) }
func cD(x0,y0,x1,y1 float64)                   func(gene.Vec3) float64 { return cap2(x0,y0,x1,y1,cT) }
func cDot(cx,cy float64)                        func(gene.Vec3) float64 { return SDot(cx,cy,0.05) }
func cArc(cx,cy,r,a0,a1 float64)               func(gene.Vec3) float64 { return arcSDF(cx,cy,r,cT,a0,a1) }
func cHook(x,ytop,ybot float64)                func(gene.Vec3) float64 { return SHook(x,ytop,ybot) }

// Alias để dùng trong file này

// Thực ra dùng func(gene.Vec3) float64 — alias cho ngắn gọn

var CJKCommon = []*OlangChar{

	// ══ SỐ & CƠ BẢN ═══════════════════════════════════════════════════
	// 一 — one: 1 ngang
	{Codepoint:0x4E00,Glyph:"一",Name:"CJK One",Script:"cjk",Category:"letter",
		SDF:cH(-cW,cW,0), Phonemes:[]string{"/iː/"}},

	// 二 — two: 2 ngang
	{Codepoint:0x4E8C,Glyph:"二",Name:"CJK Two",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.65,cW*0.65,cQT),cH(-cW,cW,cQB))},

	// 三 — three: 3 ngang
	{Codepoint:0x4E09,Glyph:"三",Name:"CJK Three",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.65,cW*0.65,cH0*0.7),cH(-cW*0.5,cW*0.5,0),cH(-cW,cW,-cH0*0.7))},

	// 四 — four: hộp + 2 nét trong
	{Codepoint:0x56DB,Glyph:"四",Name:"CJK Four",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cH0),cH(-cW,cW,-cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),
			cV(-cQL,-cH0,0),cV(cQL,-cH0,0))},

	// 五 — five: 3 ngang + 2 đứng + cong
	{Codepoint:0x4E94,Glyph:"五",Name:"CJK Five",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cH0*0.8),cH(-cW*0.7,cW*0.7,0),cH(-cW,cW,-cH0*0.8),
			cV(-cW*0.7,0,cH0*0.8),cV(cW*0.7,0,cH0*0.8))},

	// 六 — six
	{Codepoint:0x516D,Glyph:"六",Name:"CJK Six",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cV(0,0,cH0*0.8),
			cD(0,0,-cW,-cH0*0.8),cD(0,0,cW,-cH0*0.8))},

	// 七 — seven
	{Codepoint:0x4E03,Glyph:"七",Name:"CJK Seven",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cQT),cD(cQL,cQT,0,-cH0),cArc(0,-cH0,cQL*0.8,math.Pi,math.Pi*2))},

	// 八 — eight: 2 nét chéo
	{Codepoint:0x516B,Glyph:"八",Name:"CJK Eight",Script:"cjk",Category:"letter",
		SDF:union(cD(-cQL*0.5,cQT,XLeft,-cH0),cD(cQL*0.5,cQT,XRight,-cH0))},

	// 九 — nine
	{Codepoint:0x4E5D,Glyph:"九",Name:"CJK Nine",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0*0.7,cW*0.3,-cH0*0.5),cArc(cW*0.3,-cH0*0.5,cW*0.6,-math.Pi/2,math.Pi/2))},

	// 十 — ten: + cross
	{Codepoint:0x5341,Glyph:"十",Name:"CJK Ten",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cQT*0.3),cV(0,-cH0,cH0))},

	// ══ THIÊN NHIÊN ════════════════════════════════════════════════════
	// 日 — sun/day: hộp + nét giữa
	{Codepoint:0x65E5,Glyph:"日",Name:"CJK Sun",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cH0),cH(-cW,cW,-cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),cH(-cW,cW,0))},

	// 月 — moon: hộp cong + nét
	{Codepoint:0x6708,Glyph:"月",Name:"CJK Moon",Script:"cjk",Category:"letter",
		SDF:union(cArc(-cW*0.3,0,cW*0.9,-math.Pi/2,math.Pi/2),cH(-cW*0.3,cW*0.6,cQT),
			cH(-cW*0.3,cW*0.6,cQB),cV(-cW*0.3,-cH0,cH0))},

	// 山 — mountain: 3 đỉnh
	{Codepoint:0x5C71,Glyph:"山",Name:"CJK Mountain",Script:"cjk",Category:"letter",
		SDF:union(cV(-cW,-cH0,cQT),cV(0,-cH0,cH0),cV(cW,-cH0,cQT),cH(-cW,cW,-cH0))},

	// 水 — water
	{Codepoint:0x6C34,Glyph:"水",Name:"CJK Water",Script:"cjk",Category:"letter",
		SDF:union(cV(0,-cH0,cH0),cD(-cW*0.5,cQT,-cW,-cH0*0.3),cD(-cW*0.3,0,cW*0.8,-cH0),
			cD(cW*0.2,cQT*0.5,cW*0.8,cH0*0.3))},

	// 火 — fire
	{Codepoint:0x706B,Glyph:"火",Name:"CJK Fire",Script:"cjk",Category:"letter",
		SDF:union(cV(0,-cH0*0.3,cH0),cD(0,-cH0*0.3,-cW,-cH0),cD(0,-cH0*0.3,cW,-cH0),
			cD(-cW*0.3,cQT*0.5,-cW*0.7,-cH0*0.3),cD(cW*0.3,cQT*0.5,cW*0.7,-cH0*0.3))},

	// 木 — tree: + với chân chéo
	{Codepoint:0x6728,Glyph:"木",Name:"CJK Tree",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cQT*0.3),cV(0,-cH0,cH0),cD(0,-cQT,-cW,-cH0),cD(0,-cQT,cW,-cH0))},

	// 土 — earth: 2 ngang + đứng
	{Codepoint:0x571F,Glyph:"土",Name:"CJK Earth",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.7),cH(-cW,cW,-cH0),cV(0,-cH0,cH0*0.7))},

	// 金 — gold/metal
	{Codepoint:0x91D1,Glyph:"金",Name:"CJK Gold",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT),cH(-cW*0.6,cW*0.6,cQT),
			cV(0,cQB*0.3,cQT),cH(-cW*0.4,cW*0.4,cQB*0.3),
			cD(0,cQB*0.3,-cW*0.6,-cH0),cD(0,cQB*0.3,cW*0.6,-cH0))},

	// ══ CON NGƯỜI ══════════════════════════════════════════════════════
	// 人 — person: 2 chéo
	{Codepoint:0x4EBA,Glyph:"人",Name:"CJK Person",Script:"cjk",Category:"letter",
		SDF:union(cD(cQL*0.3,cH0*0.7,-cW,-cH0),cD(cQL*0.3,cH0*0.7,cW*0.5,-cH0))},

	// 大 — big: person + ngang
	{Codepoint:0x5927,Glyph:"大",Name:"CJK Big",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cQT*0.2),cV(0,cQT*0.2,cH0),cD(0,cQT*0.2,-cW,-cH0),cD(0,cQT*0.2,cW,-cH0))},

	// 小 — small: đứng + 2 chấm
	{Codepoint:0x5C0F,Glyph:"小",Name:"CJK Small",Script:"cjk",Category:"letter",
		SDF:union(cV(0,-cH0,cH0),cDot(-cW*0.6,-cQT),cDot(cW*0.6,-cQT))},

	// 中 — middle: hộp + đứng xuyên
	{Codepoint:0x4E2D,Glyph:"中",Name:"CJK Middle",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cQT),cH(-cW*0.7,cW*0.7,cQB),
			cV(-cW*0.7,cQB,cQT),cV(cW*0.7,cQB,cQT),cV(0,-cH0,cH0))},

	// 上 — above: 2 ngang + đứng
	{Codepoint:0x4E0A,Glyph:"上",Name:"CJK Above",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.4,cW*0.4,cH0*0.7),cH(-cW,cW,-cH0),cV(0,-cH0,cH0*0.7))},

	// 下 — below: 2 ngang + đứng
	{Codepoint:0x4E0B,Glyph:"下",Name:"CJK Below",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.4,cW*0.4,cH0*0.7),cH(-cW,cW,-cH0),cV(0,-cH0,cH0*0.7),cDot(0,-cH0*0.4))},

	// 口 — mouth: hộp vuông
	{Codepoint:0x53E3,Glyph:"口",Name:"CJK Mouth",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cQT),cH(-cW*0.7,cW*0.7,cQB),
			cV(-cW*0.7,cQB,cQT),cV(cW*0.7,cQB,cQT))},

	// 手 — hand: 3 ngang + đứng + chéo
	{Codepoint:0x624B,Glyph:"手",Name:"CJK Hand",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cH0*0.6),cH(-cW*0.7,cW*0.7,cQT*0.2),
			cH(-cW*0.7,cW*0.7,cQB*0.6),cD(cW*0.3,cH0*0.6,cW*0.7,-cH0))},

	// 目 — eye: hộp + 2 nét ngang trong
	{Codepoint:0x76EE,Glyph:"目",Name:"CJK Eye",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.6,cW*0.6,cH0),cH(-cW*0.6,cW*0.6,-cH0),
			cV(-cW*0.6,-cH0,cH0),cV(cW*0.6,-cH0,cH0),
			cH(-cW*0.6,cW*0.6,cQT*0.3),cH(-cW*0.6,cW*0.6,cQB*0.3))},

	// 耳 — ear
	{Codepoint:0x8033,Glyph:"耳",Name:"CJK Ear",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cH0),cH(-cW*0.7,cW*0.7,cQT*0.5),cH(-cW*0.7,cW*0.7,cQB*0.5),
			cH(-cW*0.7,cW*0.7,-cH0),cV(-cW*0.7,-cH0,cH0),cV(cW*0.7,cQB*0.5,cH0))},

	// ══ CƠ THỂ / TỰ NHIÊN ══════════════════════════════════════════════
	// 心 — heart: 2 cung + chấm
	{Codepoint:0x5FC3,Glyph:"心",Name:"CJK Heart",Script:"cjk",Category:"letter",
		SDF:union(cArc(-cW*0.5,cQB*0.4,cW*0.45,0,math.Pi),cArc(cW*0.2,cQB*0.4,cW*0.3,0,math.Pi),
			cDot(-cW*0.7,cQT*0.3),cD(cW*0.6,cQT*0.3,cW*0.8,-cH0*0.4))},

	// 力 — strength
	{Codepoint:0x529B,Glyph:"力",Name:"CJK Strength",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.3,cW*0.7,cQT*0.5),cD(cW*0.7,cQT*0.5,cW*0.5,-cH0),
			cD(-cW*0.3,cQT*0.5,-cW*0.3,-cH0))},

	// 又 — again/also
	{Codepoint:0x53C8,Glyph:"又",Name:"CJK Again",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.5,cQT*0.5,cW*0.3,-cQB*0.3),cD(cW*0.3,-cQB*0.3,-cW*0.5,-cH0),
			cDot(cW*0.4,-cQT*0.5))},

	// ══ PHƯƠNG HƯỚNG ═══════════════════════════════════════════════════
	// 东 — east
	{Codepoint:0x4E1C,Glyph:"东",Name:"CJK East",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cQT*0.7),cV(0,-cH0,cH0),
			cD(0,0,-cW*0.7,-cH0),cD(0,0,cW*0.7,-cH0),cH(-cW*0.5,cW*0.5,-cQT*0.3))},

	// 西 — west
	{Codepoint:0x897F,Glyph:"西",Name:"CJK West",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cH0),cH(-cW,cW,-cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,0),
			cH(-cW,cW,0),cArc(0,-cH0*0.4,cW*0.6,0,math.Pi))},

	// 南 — south
	{Codepoint:0x5357,Glyph:"南",Name:"CJK South",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.4,cW*0.4,cH0*0.8),cV(0,cQT*0.5,cH0*0.8),
			cH(-cW,cW,cQT*0.5),cH(-cW,cW,cQB*0.5),cV(-cW,cQB*0.5,cQT*0.5),cV(cW,cQB*0.5,cQT*0.5),
			cH(-cW*0.6,cW*0.6,0),cH(-cW,cW,-cH0))},

	// 北 — north
	{Codepoint:0x5317,Glyph:"北",Name:"CJK North",Script:"cjk",Category:"letter",
		SDF:union(cV(-cW*0.3,-cH0,cH0*0.6),cH(-cW*0.3,cW*0.3,cQT*0.3),
			cV(cW*0.3,-cH0,cH0),cD(cW*0.3,0,-cW*0.3,-cH0),
			cH(-cW*0.3,cW*0.3,-cH0))},

	// ══ THỜI GIAN ══════════════════════════════════════════════════════
	// 年 — year
	{Codepoint:0x5E74,Glyph:"年",Name:"CJK Year",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.4,cH0,cW*0.2,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),
			cH(-cW,cW,cQB*0.5),cV(0,-cH0,cH0),cH(-cW*0.5,cW*0.5,0))},

	// 月 already defined above
	// 时 — time (日+寸)
	{Codepoint:0x65F6,Glyph:"时",Name:"CJK Time",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,0,cH0),cH(-cW,0,-cH0),cV(-cW,-cH0,cH0),cV(0,-cH0,cH0),
			cH(-cW,0,0),cV(cW*0.5,-cH0*0.5,cH0*0.5),cH(0,cW,cQT*0.2),cD(cW*0.5,cQB*0.2,cW*0.9,-cH0*0.4))},

	// ══ ĐỜI SỐNG ═══════════════════════════════════════════════════════
	// 家 — home/family
	{Codepoint:0x5BB6,Glyph:"家",Name:"CJK Home",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.4,cH0,0,cQT*0.8),cD(cW*0.4,cH0,0,cQT*0.8),
			cH(-cW,cW,cQT*0.3),cV(-cW*0.6,cQB*0.3,cQT*0.3),cV(cW*0.6,cQB*0.3,cQT*0.3),
			cD(-cW*0.3,cQB*0.3,-cW,-cH0),cD(cW*0.3,cQB*0.3,cW,-cH0))},

	// 国 — country: hộp lớn + 玉 trong
	{Codepoint:0x56FD,Glyph:"国",Name:"CJK Country",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cH0),cH(-cW,cW,-cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),
			cH(-cW*0.5,cW*0.5,cQT*0.5),cH(-cW*0.5,cW*0.5,cQB*0.5),cDot(0,0))},

	// 学 — study/learn
	{Codepoint:0x5B66,Glyph:"学",Name:"CJK Study",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.5,cH0,0,cQT),cD(cW*0.5,cH0,0,cQT),
			cH(-cW*0.7,cW*0.7,cQT),cV(0,cQB*0.5,cQT),
			cH(-cW*0.5,cW*0.5,cQB*0.5),cV(-cW*0.5,-cH0,cQB*0.5),cV(cW*0.5,-cH0,cQB*0.5))},

	// 生 — life/born
	{Codepoint:0x751F,Glyph:"生",Name:"CJK Life",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),
			cV(0,-cH0,cH0*0.9),cH(-cW,cW,cQB*0.5),cH(-cW*0.5,cW*0.5,0))},

	// 工 — work/labor: 工 shape
	{Codepoint:0x5DE5,Glyph:"工",Name:"CJK Work",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cH0),cH(-cW,cW,-cH0),cV(0,-cH0,cH0))},

	// 人 already above
	// 女 — woman
	{Codepoint:0x5973,Glyph:"女",Name:"CJK Woman",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.5,cQT*0.5,cW*0.8,-cH0*0.3),cD(cW*0.8,-cH0*0.3,-cW,-cH0*0.5),
			cH(-cW,cW,0))},

	// 子 — child
	{Codepoint:0x5B50,Glyph:"子",Name:"CJK Child",Script:"cjk",Category:"letter",
		SDF:union(cArc(-cW*0.1,cQT,cW*0.6,-math.Pi*0.1,math.Pi*0.9),
			cV(-cW*0.1,cQB*0.3,cQT),cH(-cW,cW,cQB*0.3))},

	// 门 — door/gate
	{Codepoint:0x95E8,Glyph:"门",Name:"CJK Door",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),
			cH(-cW*0.1,cW*0.1,cQT*0.4),cV(0,-cH0*0.5,cQT*0.4))},

	// 车 — vehicle/car
	{Codepoint:0x8F66,Glyph:"车",Name:"CJK Car",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.5),cH(-cW,cW,cQT*0.5),
			cV(0,-cH0,cH0),cH(-cW*0.7,cW*0.7,cQB*0.5))},

	// 马 — horse
	{Codepoint:0x9A6C,Glyph:"马",Name:"CJK Horse",Script:"cjk",Category:"letter",
		SDF:union(cArc(-cW*0.1,cQT,cW*0.6,-math.Pi*0.15,math.Pi*0.9),
			cV(-cW*0.5,-cH0,cH0*0.3),cH(-cW*0.7,cW*0.7,-cH0*0.4),
			cH(-cW*0.7,cW*0.7,0),cH(-cW*0.5,cW*0.5,cH0*0.3))},

	// ══ ĐỘNG TỪ CƠ BẢN ═════════════════════════════════════════════════
	// 来 — come
	{Codepoint:0x6765,Glyph:"来",Name:"CJK Come",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.7,cW*0.7,cQT*0.4),cV(0,-cH0,cH0),
			cD(0,0,-cW,-cH0),cD(0,0,cW,-cH0),cH(-cW*0.5,cW*0.5,cH0*0.8))},

	// 去 — go
	{Codepoint:0x53BB,Glyph:"去",Name:"CJK Go",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),
			cH(-cW,cW,0),cArc(0,-cH0*0.4,cW*0.6,0,math.Pi))},

	// 有 — have
	{Codepoint:0x6709,Glyph:"有",Name:"CJK Have",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.5,cQT*0.5),cH(-cW,cW,cQT*0.5),
			cH(-cW,0,cQB*0.3),cH(-cW,0,-cH0),cV(-cW,-cH0,cQT*0.5),
			cH(-cW*0.3,cW*0.6,cQT*0.1))},

	// 是 — is/yes
	{Codepoint:0x662F,Glyph:"是",Name:"CJK Is",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.8),cV(0,cQT*0.4,cH0*0.8),
			cH(-cW*0.7,cW*0.7,cQT*0.4),cH(-cW,cW,0),cV(-cW*0.3,-cH0,0),
			cD(-cW*0.3,-cH0,cW*0.3,-cH0),cD(cW*0.3,-cH0,cW*0.7,0))},

	// 说 — speak
	{Codepoint:0x8BF4,Glyph:"说",Name:"CJK Speak",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),
			cH(-cW*0.3,cW*0.7,cH0),cH(-cW*0.3,cW*0.7,cQT*0.4),
			cV(-cW*0.3,cQB*0.5,cH0),cArc(cW*0.3,cQB*0.5,cW*0.4,0,math.Pi))},

	// 看 — look/see
	{Codepoint:0x770B,Glyph:"看",Name:"CJK Look",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.5,cH0,0,cQT*0.5),cH(0,cW*0.7,cQT*0.5),
			cH(-cW,cW,0),cH(-cW,cW,-cH0),cV(-cW,-cH0,0),cV(cW,-cH0,0),cH(-cW,cW,cQB*0.4))},

	// 走 — walk
	{Codepoint:0x8D70,Glyph:"走",Name:"CJK Walk",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.8),cV(0,0,cH0*0.8),
			cD(0,0,-cW*0.5,-cH0*0.5),cH(-cW,cW,0),cD(-cW*0.3,0,cW*0.5,-cH0))},

	// ══ TỪ PHỔ BIẾN ════════════════════════════════════════════════════
	// 的 — possessive particle (most common CJK char)
	{Codepoint:0x7684,Glyph:"的",Name:"CJK De particle",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,0,cH0),cH(-cW,0,0),cH(-cW,0,-cH0),cV(-cW,-cH0,cH0),
			cV(0,-cH0,cH0),cDot(cW*0.3,cQT*0.4),cDot(cW*0.5,cQB*0.4))},

	// 了 — completion particle
	{Codepoint:0x4E86,Glyph:"了",Name:"CJK Le particle",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.5,cH0,cW*0.3,cQT*0.3),cArc(cW*0.3,0,cW*0.4,math.Pi*0.5,math.Pi*1.5))},

	// 在 — at/exist
	{Codepoint:0x5728,Glyph:"在",Name:"CJK At",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.5,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),
			cV(-cW*0.3,-cH0,cQT*0.5),cH(-cW*0.3,cW*0.7,0),cH(-cW,cW,-cH0))},

	// 不 — not/no
	{Codepoint:0x4E0D,Glyph:"不",Name:"CJK Not",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,cW,cQT*0.5),cV(0,-cH0,cH0),
			cD(0,0,-cW,-cH0),cD(0,0,cW*0.5,-cH0*0.5),cDot(cW*0.5,-cH0*0.5))},

	// 我 — I/me
	{Codepoint:0x6211,Glyph:"我",Name:"CJK I/Me",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.3,cW*0.3,cQT*0.3),cV(-cW*0.3,-cH0,cH0),
			cH(-cW*0.6,cW*0.7,cQB*0.4),cD(cW*0.3,cQT*0.5,cW*0.7,-cH0),
			cD(cW*0.7,-cH0,cW*0.4,cQB*0.5))},

	// 你 — you
	{Codepoint:0x4F60,Glyph:"你",Name:"CJK You",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),
			cH(cW*0.1,cW*0.7,cH0*0.8),cV(cW*0.1,-cH0,cH0*0.8),
			cD(cW*0.1,0,-cW*0.1,-cH0),cD(cW*0.3,0,cW*0.6,-cH0))},

	// 他 — he/him
	{Codepoint:0x4ED6,Glyph:"他",Name:"CJK He",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),
			cH(cW*0.1,cW*0.7,cQT*0.5),cV(cW*0.1,-cH0,cH0*0.8),
			cH(cW*0.1,cW*0.7,cQB*0.4),cH(cW*0.1,cW*0.7,-cH0))},

	// 好 — good
	{Codepoint:0x597D,Glyph:"好",Name:"CJK Good",Script:"cjk",Category:"letter",
		SDF:union(cArc(-cW*0.55,cQT,cW*0.35,-math.Pi*0.15,math.Pi*0.9),
			cV(-cW*0.55,cQB*0.3,cH0*0.8),
			cD(cW*0.1,cH0*0.8,cW*0.7,cQT*0.4),cH(cW*0.1,cW*0.7,cQT*0.4),
			cV(cW*0.1,-cH0,cH0*0.8),cD(cW*0.1,0,-cW*0.1,-cH0),cD(cW*0.3,0,cW*0.6,-cH0))},

	// 大 already above
	// 这 — this
	{Codepoint:0x8FD9,Glyph:"这",Name:"CJK This",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cQT*0.5,cW*0.3,0),cH(-cW*0.5,cW*0.7,0),
			cV(-cW*0.1,-cH0*0.5,0),cD(-cW*0.5,cQB*0.5,-cW,-cH0),cD(cW*0.5,0,cW,-cH0*0.5))},

	// 个 — measure word
	{Codepoint:0x4E2A,Glyph:"个",Name:"CJK Ge measure",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cQT*0.5,0,cH0),cD(cW*0.3,cQT*0.5,0,cH0),cV(0,-cH0,cQT*0.5))},

	// 们 — plural suffix
	{Codepoint:0x4EEC,Glyph:"们",Name:"CJK Men plural",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),
			cH(cW*0.1,cW*0.8,cH0),cV(cW*0.1,-cH0,cH0),cV(cW*0.8,-cH0,cH0))},

	// ══ THÊM PHỔ BIẾN ══════════════════════════════════════════════════
	// 地 — ground/earth
	{Codepoint:0x5730,Glyph:"地",Name:"CJK Ground",Script:"cjk",Category:"letter",
		SDF:union(cV(-cW*0.7,-cH0,cH0),cH(-cW*0.7,cW*0.3,cH0*0.6),
			cH(-cW*0.7,cW*0.3,cQT*0.2),cH(-cW*0.7,cW*0.3,-cH0*0.4),
			cD(cW*0.3,cH0*0.6,cW*0.7,-cH0),cD(cW*0.7,-cH0,cW*0.3,cQT*0.2))},

	// 天 — sky/heaven: 大+一
	{Codepoint:0x5929,Glyph:"天",Name:"CJK Sky",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cH(-cW,cW,cQT*0.2),
			cV(0,cQT*0.2,cH0*0.8),cD(0,cQT*0.2,-cW,-cH0),cD(0,cQT*0.2,cW,-cH0))},

	// 人 already defined
	// 以 — by means of
	{Codepoint:0x4EE5,Glyph:"以",Name:"CJK By",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.4,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),
			cV(cW*0.2,-cH0,cH0),cD(cW*0.5,cQT*0.4,cW*0.9,-cH0*0.5),cDot(cW*0.6,cH0*0.5))},

	// 和 — and/harmony: 禾+口
	{Codepoint:0x548C,Glyph:"和",Name:"CJK And",Script:"cjk",Category:"letter",
		SDF:union(cH(-cW,0,cQT*0.5),cV(-cW*0.5,-cH0,cH0),cD(-cW*0.5,cQT*0.5,-cW,-cH0*0.4),
			cD(-cW*0.5,cQT*0.5,0,cQB*0.3),
			cH(cW*0.1,cW*0.8,cQT*0.4),cH(cW*0.1,cW*0.8,cQB*0.4),
			cV(cW*0.1,cQB*0.4,cQT*0.4),cV(cW*0.8,cQB*0.4,cQT*0.4))},

	// 中 already above
	// 为 — for/because
	{Codepoint:0x4E3A,Glyph:"为",Name:"CJK For",Script:"cjk",Category:"letter",
		SDF:union(cD(-cW*0.3,cH0,cW*0.6,cQT*0.3),cArc(cW*0.2,0,cW*0.5,math.Pi*0.1,math.Pi),
			cD(-cW*0.2,0,-cW*0.6,-cH0),cDot(cW*0.5,cQB*0.5))},
}

// AllCJK — CJK phổ biến
func AllCJK() []*OlangChar { return allCJKChars() }

// allCJKChars — gộp tất cả batches
func allCJKChars() []*OlangChar {
	var out []*OlangChar
	out = append(out, CJKCommon...)
	out = append(out, CJK2...)
	out = append(out, CJK3...)
	return out
}
