package alphabet

import "math"

// CJK2 — batch 2: hành động + vật thể + thức ăn + động vật + màu sắc
var CJK2 = []*OlangChar{
	{Codepoint:0x505A,Glyph:"做",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0),cV(cW*0.1,-cH0,cH0),cH(cW*0.1,cW*0.8,cQT*0.4),cH(cW*0.1,cW*0.8,cQB*0.4),cV(cW*0.8,cQB*0.4,cQT*0.4))},
	{Codepoint:0x5230,Glyph:"到",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0),cV(-cW*0.5,-cH0,cH0),cD(-cW*0.5,0,0,-cH0),cH(-cW,0,0),cV(cW*0.2,-cH0,cH0),cD(cW*0.5,cH0*0.5,cW*0.9,-cH0*0.4))},
	{Codepoint:0x5F00,Glyph:"开",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0*0.7),cV(0,-cH0,cH0*0.7),cH(-cW*0.5,cW*0.5,cQB*0.5))},
	{Codepoint:0x5173,Glyph:"关",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.5),cD(cW*0.4,cH0,0,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cD(0,cQT*0.5,-cW,-cH0),cD(0,cQT*0.5,cW,-cH0))},
	{Codepoint:0x51FA,Glyph:"出",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0),cV(-cW*0.5,-cH0*0.3,cH0),cV(cW*0.5,-cH0*0.3,cH0),cH(-cW*0.5,cW*0.5,-cH0*0.3),cV(0,-cH0,cH0))},
	{Codepoint:0x5165,Glyph:"入",Script:"cjk",Category:"letter",SDF:union(cD(cQL*0.3,cH0*0.7,-cW,-cH0),cD(cQL*0.3,cH0*0.7,cW*0.5,-cH0))},
	{Codepoint:0x7528,Glyph:"用",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.7,cW*0.7,cH0),cH(-cW*0.7,cW*0.7,-cH0),cV(-cW*0.7,-cH0,cH0),cV(cW*0.7,-cH0,cH0),cH(-cW*0.7,cW*0.7,cQT*0.3),cV(0,-cH0,cH0))},
	{Codepoint:0x77E5,Glyph:"知",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.5,cQT*0.4,0,-cH0),cH(-cW*0.5,cW*0.3,cQT*0.4),cDot(-cW*0.2,cH0*0.5),cH(cW*0.1,cW*0.8,cQT*0.4),cH(cW*0.1,cW*0.8,cQB*0.4),cV(cW*0.1,cQB*0.4,cQT*0.4),cV(cW*0.8,cQB*0.4,cQT*0.4))},
	{Codepoint:0x9053,Glyph:"道",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.5,cQT*0.5),cH(-cW*0.7,cW*0.7,cQT*0.5),cV(-cW*0.1,-cH0*0.3,cQT*0.5),cH(-cW*0.5,cW*0.5,cQB*0.4),cD(-cW*0.5,cQB*0.4,-cW,-cH0),cD(cW*0.5,0,cW,-cH0*0.5))},
	{Codepoint:0x60F3,Glyph:"想",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0),cV(0,cQT*0.4,cH0),cH(-cW*0.6,cW*0.6,cQT*0.4),cH(-cW*0.4,cW*0.4,cQT*0.1),cH(-cW*0.4,cW*0.4,0),cArc(-cW*0.5,cQB*0.4,cW*0.45,0,math.Pi),cArc(cW*0.2,cQB*0.4,cW*0.3,0,math.Pi))},
	// vật thể
	{Codepoint:0x4E66,Glyph:"书",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,cW*0.3,cQT*0.4),cH(-cW*0.6,cW*0.6,cQT*0.4),cArc(0,0,cW*0.6,0,math.Pi),cV(0,-cH0,cH0*0.3))},
	{Codepoint:0x9322,Glyph:"钱",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.7,cH0*0.6),cV(cW*0.1,0,cH0*0.6),cV(cW*0.7,0,cH0*0.6),cH(cW*0.1,cW*0.7,0),cD(cW*0.1,0,cW*0.7,-cH0))},
	{Codepoint:0x623F,Glyph:"房",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.8),cD(cW*0.4,cH0,0,cQT*0.8),cH(-cW,cW,cQT*0.3),cV(-cW*0.6,cQB*0.3,cQT*0.3),cV(cW*0.6,cQB*0.3,cQT*0.3),cH(-cW*0.6,cW*0.6,cQB*0.3),cH(-cW,cW,-cH0))},
	{Codepoint:0x684C,Glyph:"桌",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.4,cW*0.4,cH0),cV(0,0,cH0),cH(-cW*0.7,cW*0.7,0),cD(0,0,-cW,-cH0),cD(0,0,cW,-cH0),cH(-cW*0.5,cW*0.5,-cH0*0.6))},
	{Codepoint:0x5E8A,Glyph:"床",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.8),cD(cW*0.4,cH0,0,cQT*0.8),cH(-cW*0.8,cW*0.8,cQT*0.3),cV(-cW*0.8,-cH0,cQT*0.3),cD(-cW*0.8,0,0,-cH0),cD(cW*0.4,0,cW*0.7,-cH0*0.5))},
	// thức ăn
	{Codepoint:0x98DF,Glyph:"食",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),cArc(0,0,cW*0.6,0,math.Pi),cV(0,-cH0,0),cH(-cW*0.5,cW*0.5,-cH0*0.4))},
	{Codepoint:0x996D,Glyph:"饭",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cD(cW*0.1,cH0,cW*0.6,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cArc(cW*0.4,0,cW*0.4,0,math.Pi))},
	{Codepoint:0x8336,Glyph:"茶",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.6),cD(cW*0.4,cH0,0,cQT*0.6),cH(-cW*0.7,cW*0.7,cQT*0.6),cD(-cW*0.3,cQT*0.6,0,0),cD(cW*0.3,cQT*0.6,0,0),cArc(0,-cH0*0.3,cW*0.6,0,math.Pi))},
	{Codepoint:0x8089,Glyph:"肉",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,cH0),cV(cW*0.6,-cH0,cH0),cH(-cW*0.6,cW*0.6,cQT*0.3),cD(-cW*0.6,cQT*0.3,cW*0.6,-cH0))},
	// động vật
	{Codepoint:0x9E1F,Glyph:"鸟",Script:"cjk",Category:"letter",SDF:union(cArc(0,cQT*0.5,cW*0.5,-math.Pi*0.15,math.Pi*0.9),cV(0,-cH0*0.5,cQT*0.5),cH(-cW*0.5,cW*0.8,cQB*0.5),cD(-cW*0.3,-cH0*0.5,-cW,-cH0),cD(cW*0.3,-cH0*0.5,cW,-cH0))},
	{Codepoint:0x9C7C,Glyph:"鱼",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.3,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.5),cV(0,cQB*0.5,cQT*0.5),cH(-cW*0.6,cW*0.6,cQT*0.1),cH(-cW*0.6,cW*0.6,cQB*0.3),cH(-cW*0.8,cW*0.8,-cH0))},
	{Codepoint:0x72D7,Glyph:"狗",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cArc(cW*0.3,cQT*0.4,cW*0.35,-math.Pi*0.15,math.Pi*0.9),cV(cW*0.3,-cH0*0.5,cQT*0.4),cH(-cW*0.1,cW*0.8,cQB*0.4),cD(cW*0.3,-cH0*0.5,-cW*0.1,cQB*0.4))},
	{Codepoint:0x732B,Glyph:"猫",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.3,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0),cH(cW*0.1,cW*0.8,cQT*0.3),cH(cW*0.1,cW*0.8,cQB*0.3),cV(cW*0.1,cQB*0.3,cH0),cV(cW*0.8,-cH0*0.5,cH0),cH(cW*0.1,cW*0.8,-cH0*0.5))},
	// cơ thể
	{Codepoint:0x5934,Glyph:"头",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.3,cH0,cW*0.5,cQT*0.3),cH(-cW*0.5,cW*0.7,cQT*0.3),cD(0,cQT*0.3,-cW,-cH0),cD(cW*0.4,0,cW*0.8,-cH0*0.5),cDot(cW*0.7,cH0*0.5))},
	{Codepoint:0x811A,Glyph:"脚",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0),cH(-cW,0,cQT*0.4),cH(-cW,0,cQB*0.4),cH(-cW,0,-cH0),cV(-cW,-cH0,cH0),cV(0,-cH0,cH0),cV(cW*0.4,-cH0*0.5,cH0*0.5),cH(0,cW*0.8,cQT*0.3),cH(0,cW*0.8,cQB*0.3),cD(cW*0.4,cQB*0.3,cW*0.8,-cH0))},
	// màu sắc
	{Codepoint:0x7EA2,Glyph:"红",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.7,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,0,cH0*0.6),cV(cW*0.8,0,cH0*0.6),cH(cW*0.1,cW*0.8,0),cArc(cW*0.4,-cH0*0.5,cW*0.4,0,math.Pi))},
	{Codepoint:0x767D,Glyph:"白",Script:"cjk",Category:"letter",SDF:union(cDot(0,cH0*0.7),cH(-cW*0.6,cW*0.6,cH0*0.4),cH(-cW*0.6,cW*0.6,-cH0*0.4),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,cH0*0.4),cV(cW*0.6,-cH0,cH0*0.4),cH(-cW*0.6,cW*0.6,0))},
	{Codepoint:0x9ED1,Glyph:"黑",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0*0.8),cV(0,cQT*0.4,cH0*0.8),cH(-cW*0.7,cW*0.7,cQT*0.4),cH(-cW*0.7,cW*0.7,0),cV(-cW*0.7,0,cQT*0.4),cV(cW*0.7,0,cQT*0.4),cDot(-cW*0.4,-cH0*0.5),cDot(0,-cH0*0.5),cDot(cW*0.4,-cH0*0.5))},
	{Codepoint:0x7EFF,Glyph:"绿",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.7,-cH0),cD(cW*0.1,cH0,cW*0.6,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cV(-cW*0.1,-cH0,cQT*0.4),cD(cW*0.1,0,cW*0.8,-cH0))},
	// thời tiết
	{Codepoint:0x98CE,Glyph:"风",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0),cArc(0,0,cW*0.6,0,math.Pi),cD(-cW*0.4,0,-cW*0.6,-cH0),cDot(cW*0.3,cQT*0.2))},
	{Codepoint:0x96E8,Glyph:"雨",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cV(-cW,-cH0*0.3,cH0),cV(cW,-cH0*0.3,cH0),cH(-cW,cW,-cH0*0.3),cDot(-cW*0.5,-cH0*0.65),cDot(0,-cH0*0.65),cDot(cW*0.5,-cH0*0.65),cDot(-cW*0.25,-cH0*0.85),cDot(cW*0.25,-cH0*0.85))},
	{Codepoint:0x4E91,Glyph:"云",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.5,cW*0.5,cH0*0.8),cArc(-cW*0.3,cQT*0.3,cW*0.35,0,math.Pi),cArc(cW*0.2,cQT*0.3,cW*0.45,0,math.Pi),cH(-cW*0.8,cW*0.8,cQT*0.3))},
	{Codepoint:0x96EA,Glyph:"雪",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cV(-cW,-cH0*0.3,cH0),cV(cW,-cH0*0.3,cH0),cH(-cW,cW,-cH0*0.3),cH(-cW*0.6,cW*0.6,cQB*0.3),cV(-cW*0.4,cQB*0.3,-cH0*0.3),cV(cW*0.4,cQB*0.3,-cH0*0.3),cH(-cW*0.7,cW*0.7,-cH0))},
	// thực vật
	{Codepoint:0x82B1,Glyph:"花",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.6),cD(cW*0.4,cH0,0,cQT*0.6),cH(-cW*0.7,cW*0.7,cQT*0.6),cD(-cW*0.3,cQT*0.6,-cW,0),cD(cW*0.3,cQT*0.6,cW,0),cArc(0,-cH0*0.3,cW*0.5,0,math.Pi))},
	{Codepoint:0x8349,Glyph:"草",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.6),cD(cW*0.4,cH0,0,cQT*0.6),cH(-cW*0.7,cW*0.7,cQT*0.6),cH(-cW,cW,cQT*0.2),cV(-cW*0.5,-cH0,cQT*0.2),cV(cW*0.5,-cH0,cQT*0.2),cH(-cW*0.5,cW*0.5,-cH0))},
	{Codepoint:0x6811,Glyph:"树",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cD(-cW*0.5,0,-cW,-cH0*0.4),cH(cW*0.1,cW*0.8,cH0*0.7),cV(cW*0.1,-cH0,cH0*0.7),cH(cW*0.1,cW*0.8,cQT*0.3),cD(cW*0.5,cQT*0.3,cW*0.8,-cH0*0.3))},
	// nhà cửa
	{Codepoint:0x8DEF,Glyph:"路",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0),cH(-cW,0,cQT*0.4),cH(-cW,0,cQB*0.4),cH(-cW,0,-cH0),cV(-cW,-cH0,cH0),cV(0,-cH0,cH0),cH(cW*0.1,cW*0.8,cH0),cH(cW*0.1,cW*0.8,0),cH(cW*0.1,cW*0.8,-cH0),cV(cW*0.1,-cH0,cH0),cV(cW*0.8,-cH0,cH0))},
	{Codepoint:0x5BA4,Glyph:"室",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.8),cD(cW*0.4,cH0,0,cQT*0.8),cH(-cW*0.7,cW*0.7,cQT*0.3),cH(-cW*0.5,cW*0.5,0),cV(-cW*0.5,0,cQT*0.3),cV(cW*0.5,0,cQT*0.3),cH(-cW,cW,-cH0),cD(-cW*0.3,0,-cW,-cH0*0.5))},
	// học vấn
	{Codepoint:0x5B57,Glyph:"字",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.8),cD(cW*0.4,cH0,0,cQT*0.8),cH(-cW*0.4,cW*0.4,cQT*0.3),cV(0,-cH0,cQT*0.3),cH(-cW*0.7,cW*0.7,-cH0*0.4))},
	{Codepoint:0x6587,Glyph:"文",Script:"cjk",Category:"letter",SDF:union(cDot(0,cH0*0.8),cH(-cW*0.7,cW*0.7,cQT*0.4),cD(0,cQT*0.4,-cW,-cH0),cD(0,cQT*0.4,cW,-cH0))},
	{Codepoint:0x8BED,Glyph:"语",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0,cH0*0.6),cH(cW*0.1,cW*0.8,cQT*0.3),cH(cW*0.1,cW*0.8,cQB*0.3),cH(cW*0.1,cW*0.8,-cH0*0.5),cV(cW*0.8,-cH0*0.5,cH0*0.6))},
	{Codepoint:0x6570,Glyph:"数",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.6),cV(-cW*0.5,-cH0*0.4,cH0*0.6),cH(-cW*0.7,0,0),cH(-cW*0.7,0,-cH0*0.4),cV(-cW*0.7,-cH0*0.4,0),cD(cW*0.1,cH0,cW*0.6,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cD(cW*0.3,cQT*0.4,cW*0.8,-cH0*0.3))},
	// kỹ thuật
	{Codepoint:0x7535,Glyph:"电",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,cH0),cV(cW*0.6,-cH0,cH0),cH(-cW*0.6,cW*0.6,0),cV(0,-cH0,cH0),cD(cW*0.2,-cH0,cW*0.7,-cH0*1.3))},
	{Codepoint:0x7F51,Glyph:"网",Script:"cjk",Category:"letter",SDF:union(cH(-cW,cW,cH0),cV(-cW,-cH0,cH0),cV(cW,-cH0,cH0),cArc(0,-cH0*0.3,cW*0.9,0,math.Pi),cV(-cW*0.4,-cH0,cH0*0.3),cV(cW*0.4,-cH0,cH0*0.3))},
	{Codepoint:0x673A,Glyph:"机",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cD(-cW*0.5,0,-cW,-cH0*0.4),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0*0.4,cH0*0.6),cD(cW*0.1,cH0*0.6,cW*0.5,cQT*0.2),cArc(cW*0.5,cQB*0.4,cW*0.3,0,math.Pi))},
	{Codepoint:0x8111,Glyph:"脑",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0),cH(-cW,0,cQT*0.4),cH(-cW,0,cQB*0.4),cH(-cW,0,-cH0),cV(-cW,-cH0,cH0),cV(0,-cH0,cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0,cH0*0.6),cArc(cW*0.4,0,cW*0.35,0,math.Pi))},
	{Codepoint:0x8BDD,Glyph:"话",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cV(cW*0.1,-cH0,cH0),cD(cW*0.1,cQT*0.5,cW*0.7,cH0*0.5),cDot(cW*0.7,cH0*0.5),cH(cW*0.1,cW*0.8,0),cH(cW*0.1,cW*0.8,-cH0))},
	// xã hội
	{Codepoint:0x6C11,Glyph:"民",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.8),cV(-cW*0.4,-cH0,cH0*0.8),cD(-cW*0.4,0,-cW*0.7,-cH0*0.5),cD(-cW*0.4,0,cW*0.4,-cH0))},
	{Codepoint:0x653F,Glyph:"政",Script:"cjk",Category:"letter",SDF:union(cH(-cW,0,cH0*0.6),cH(-cW,0,cQT*0.2),cH(-cW,0,-cH0*0.4),cV(-cW,-cH0*0.4,cH0*0.6),cD(cW*0.1,cH0,cW*0.6,cQT*0.4),cH(-cW*0.1,cW*0.8,cQT*0.4),cD(cW*0.3,cQT*0.4,cW*0.8,-cH0*0.3))},
	{Codepoint:0x6CD5,Glyph:"法",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cV(cW*0.1,-cH0*0.4,cH0*0.6),cD(cW*0.1,cH0*0.6,cW*0.5,cQT*0.2),cH(cW*0.1,cW*0.8,cQB*0.4),cH(cW*0.1,cW*0.8,-cH0*0.4))},
	{Codepoint:0x4E1A,Glyph:"业",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.7,cW*0.7,cH0*0.7),cV(-cW*0.5,-cH0,cH0*0.7),cV(cW*0.5,-cH0,cH0*0.7),cH(-cW,cW,-cH0),cV(0,-cH0,cQT*0.2))},
	{Codepoint:0x7ECF,Glyph:"经",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.6,cQT*0.5,-cW,cQB*0.3),cD(-cW,cQB*0.3,-cW*0.6,-cH0),cV(cW*0.1,-cH0,cH0),cH(cW*0.1,cW*0.8,cH0*0.6),cH(cW*0.1,cW*0.8,cQT*0.2),cH(cW*0.1,cW*0.8,cQB*0.2),cH(cW*0.1,cW*0.8,-cH0*0.5))},
	// gia đình
	{Codepoint:0x7236,Glyph:"父",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.4,cH0,0,cQT*0.3),cD(cW*0.4,cH0,0,cQT*0.3),cD(0,cQT*0.3,-cW,-cH0),cD(0,cQT*0.3,cW,-cH0),cDot(0,cH0*0.6))},
	{Codepoint:0x6BCD,Glyph:"母",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0),cH(-cW*0.6,cW*0.6,-cH0),cV(-cW*0.6,-cH0,cH0),cV(cW*0.6,-cH0,0),cDot(-cW*0.2,cQT*0.2),cDot(cW*0.2,cQT*0.2),cH(-cW*0.6,cW*0.6,0))},
	{Codepoint:0x5144,Glyph:"兄",Script:"cjk",Category:"letter",SDF:union(cH(-cW*0.6,cW*0.6,cH0*0.8),cV(0,-cH0*0.2,cH0*0.8),cD(0,-cH0*0.2,-cW,-cH0),cD(0,-cH0*0.2,cW,-cH0))},
	{Codepoint:0x5973,Glyph:"女",Script:"cjk",Category:"letter",SDF:union(cD(-cW*0.5,cQT*0.5,cW*0.8,-cH0*0.3),cD(cW*0.8,-cH0*0.3,-cW,-cH0*0.5),cH(-cW,cW,0))},
	{Codepoint:0x5B50,Glyph:"子",Script:"cjk",Category:"letter",SDF:union(cArc(-cW*0.1,cQT,cW*0.6,-math.Pi*0.1,math.Pi*0.9),cV(-cW*0.1,cQB*0.3,cQT),cH(-cW,cW,cQB*0.3))},
}
