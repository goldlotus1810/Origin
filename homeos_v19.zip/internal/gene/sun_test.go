package gene

import "testing"

func TestSunGene(t *testing.T) {
	sun := NewSunGene()

	t.Logf("ISL addresses:")
	t.Logf("  ISL_Sun      = %016x  layer='%c' (World)  ", uint64(sun.Addr), sun.Addr.Layer())
	t.Logf("  ISL_SunTemp  = %016x  layer='%c' (Physics)", uint64(ISL_SunTemp), ISL_SunTemp.Layer())
	t.Logf("  ISL_SunWave  = %016x  layer='%c' (Physics)", uint64(ISL_SunWave), ISL_SunWave.Layer())
	t.Logf("  ISL_OpSphere = %016x  layer='%c' (Op)     ", uint64(ISL_OpSphere), ISL_OpSphere.Layer())

	t.Logf("\nQuỹ đạo + SDF:")
	for _, h := range []float64{0, 6, 12, 18} {
		sun.Animate(h)
		d := sun.SDF(Vec3{0, 0, 0})
		t.Logf("  %2.0fh  pos=(%.1f,%.1f,%.1f)  SDF=%.1f", h, sun.pos.X, sun.pos.Y, sun.pos.Z, d)
	}

	t.Logf("\nSpline vật lý:")
	for _, h := range []float64{6, 12, 18} {
		lam  := sun.Wavelength.Eval(h / 24.0)
		temp := sun.TempAt(h)
		lum  := sun.Luminosity.Eval(h / 24.0)
		r, g, _ := wavelengthToRGB(lam)
		t.Logf("  %2.0fh  T=%.0fK  λ=%.0fnm  lum=%.2f  hue_R=%.2f hue_G=%.2f",
			h, temp, lam, lum, r, g)
	}

	// Bước sóng 18h (620nm) phải đỏ hơn 12h (500nm) — so sánh hue thuần
	lam12 := sun.Wavelength.Eval(12.0 / 24.0)
	lam18 := sun.Wavelength.Eval(18.0 / 24.0)
	r12, _, _ := wavelengthToRGB(lam12)
	r18, _, _ := wavelengthToRGB(lam18)
	if r18 <= r12 {
		t.Errorf("18h hue_R=%.2f <= 12h hue_R=%.2f (bước sóng 18h phải đỏ hơn)", r18, r12)
	}
	t.Logf("\nHue 12h λ=%.0fnm R=%.2f → 18h λ=%.0fnm R=%.2f (đỏ hơn ✓)", lam12, r12, lam18, r18)

	t.Logf("\nMagnetic 11 năm:")
	for _, yr := range []float64{0, 3, 5.5, 8, 11} {
		t.Logf("  year=%4.1f  mag=%.3f", yr, sun.Magnetic.Eval(yr/11.0))
	}

	t.Logf("\nDNA: %s", sun.DNA())

	// Assertions
	if sun.Addr != ISL_Sun { t.Error("ISL_Sun sai") }
	if sun.Addr.Layer() != LayerWorld { t.Error("ISL_Sun layer != World") }
	if ISL_SunTemp.Layer() != LayerPhysics { t.Error("ISL_SunTemp layer != Physics") }
	if ISL_OpSphere.Layer() != LayerOp { t.Error("ISL_OpSphere layer != Op") }
}
