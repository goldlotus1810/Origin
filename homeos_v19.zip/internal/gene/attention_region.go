// AttentionRegion + FibCell — vùng chú ý dựa trên Fibonacci cells
// Dùng bởi outline.go (Marching Squares), FovealVision
package gene

import (
	"image/color"
	"math"
)

// ColorRGBA — wrapper có Delta()
type ColorRGBA struct {
	R, G, B, A uint8
}

func FromColor(c color.Color) ColorRGBA {
	r, g, b, a := c.RGBA()
	return ColorRGBA{uint8(r >> 8), uint8(g >> 8), uint8(b >> 8), uint8(a >> 8)}
}

// Delta — khoảng cách màu (Euclidean trong RGB space)
func (c ColorRGBA) Delta(o ColorRGBA) float64 {
	dr := float64(c.R) - float64(o.R)
	dg := float64(c.G) - float64(o.G)
	db := float64(c.B) - float64(o.B)
	return math.Sqrt(dr*dr+dg*dg+db*db) / 441.67 // normalize 0..1
}

// FibCell — một ô trong lưới Fibonacci
type FibCell struct {
	CX, CY    float64    // center normalized 0..1
	Color     ColorRGBA
	Attention float64    // 0..1
	Radius    float64    // ban kinh cell
	Size      float64    // kich thuoc cell (alias Radius)
}

// AttentionRegion — tập hợp FibCell tạo thành vùng chú ý
type AttentionRegion struct {
	Cells     []FibCell
	CenterX   float64
	CenterY   float64
	TotalArea float64
}

// NewAttentionRegion — tạo vùng chú ý từ tâm (cx,cy) với n cells
// Dùng Fibonacci spiral để phân bố đều
func NewAttentionRegion(cx, cy float64, n int) *AttentionRegion {
	cells := make([]FibCell, n)
	phi := math.Phi // 1.618...

	for i := 0; i < n; i++ {
		r := math.Sqrt(float64(i+1) / float64(n)) * 0.3 // radius max 30% frame
		theta := float64(i) * 2 * math.Pi / (phi * phi)
		cells[i] = FibCell{
			CX:        cx + r*math.Cos(theta),
			CY:        cy + r*math.Sin(theta),
			Attention: 1.0 - float64(i)/float64(n), // trung tâm chú ý cao hơn
			Radius:    r / float64(n) * 5,
		}
	}

	return &AttentionRegion{
		Cells:   cells,
		CenterX: cx,
		CenterY: cy,
	}
}

// AddCell — thêm cell vào vùng
func (r *AttentionRegion) AddCell(c FibCell) {
	r.Cells = append(r.Cells, c)
}

// HighAttention — lấy cells có attention cao nhất
func (r *AttentionRegion) HighAttention(threshold float64) []FibCell {
	var out []FibCell
	for _, c := range r.Cells {
		if c.Attention >= threshold {
			out = append(out, c)
		}
	}
	return out
}
