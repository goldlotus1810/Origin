package gene

import "testing"

func TestEarthGene(t *testing.T) {
	sun   := NewSunGene()
	earth := NewEarthGene()

	t.Logf("ISL_Earth    = %016x  layer='%c'", uint64(earth.Addr), earth.Addr.Layer())
	t.Logf("ISL_EarthTemp= %016x  layer='%c'", uint64(ISL_EarthTemp), ISL_EarthTemp.Layer())

	t.Logf("\n4 mùa (ôn đới):")
	months := []struct{ t float64; name string }{
		{0.04, "tháng 1"}, {0.29, "tháng 4"},
		{0.54, "tháng 7"}, {0.79, "tháng 10"},
	}
	for _, m := range months {
		tc := earth.TempCelsius(m.t, 12.0)
		hum := earth.HumidityAt(m.t)
		t.Logf("  %-10s  T=%5.1f°C  humid=%.2f  mùa=%s",
			m.name, tc, hum, SeasonName[earth.Season(m.t)])
	}

	t.Logf("\nNhiệt độ hoàng hôn (18h) qua 4 mùa:")
	for _, m := range months {
		ts := earth.SunsetTemp(m.t, sun)
		t.Logf("  %-10s  hoàng hôn=%.1f°C", m.name, ts-273.15)
	}

	t.Logf("\nBiến thiên nhiệt độ trong ngày (tháng 7 ôn đới):")
	for _, h := range []float64{0, 6, 12, 14, 18, 21} {
		tc := earth.TempCelsius(0.54, h)
		t.Logf("  %2.0fh  %.1f°C", h, tc)
	}

	t.Logf("\nSo sánh khí hậu lúc 12h tháng 7:")
	for _, c := range []struct{ cl Climate; name string }{
		{ClimateTropical, "Nhiệt đới"},
		{ClimateSubtropical, "Cận nhiệt"},
		{ClimateTemperate, "Ôn đới"},
		{ClimateBoreal, "Hàn đới"},
		{ClimatePolar, "Cực"},
	} {
		e2 := NewEarthGeneAt(c.cl)
		tc := e2.TempCelsius(0.54, 12.0)
		hum := e2.HumidityAt(0.54)
		t.Logf("  %-12s  T=%5.1f°C  humid=%.2f", c.name, tc, hum)
	}

	// Assertions
	if earth.Addr != ISL_Earth { t.Error("ISL_Earth sai") }
	// Hè phải ấm hơn đông (ôn đới)
	tWinter := earth.TempCelsius(0.04, 12)
	tSummer := earth.TempCelsius(0.54, 12)
	if tSummer <= tWinter {
		t.Errorf("Hè %.1f°C <= Đông %.1f°C", tSummer, tWinter)
	}
	t.Logf("\nĐông=%.1f°C < Hè=%.1f°C ✓", tWinter, tSummer)
	// Nhiệt đới phải nóng hơn ôn đới
	tTrop := NewEarthGeneAt(ClimateTropical).TempCelsius(0.54, 12)
	tTemp := NewEarthGeneAt(ClimateTemperate).TempCelsius(0.54, 12)
	if tTrop <= tTemp {
		t.Errorf("Nhiệt đới %.1f <= Ôn đới %.1f", tTrop, tTemp)
	}
	t.Logf("Nhiệt đới=%.1f°C > Ôn đới=%.1f°C ✓", tTrop, tTemp)
}
