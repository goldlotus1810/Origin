package silk

import (
	"testing"
)

func TestLoadL1FromOlang(t *testing.T) {
	g := NewSilkGraph()
	// Load tất cả layers từ homeos.olang
	n, _ := LoadFromOlang(g, "../../homeos.olang")
	t.Logf("Loaded %d nodes from homeos.olang", n)

	// Kiểm tra CJK nodes có trong graph
	testChars := []struct{
		cp   rune
		name string
	}{
		{'愛', "ai (love)"},
		{'山', "mountain"},
		{'水', "water"},
		{'日', "sun/day"},
	}

	found := 0
	for _, tc := range testChars {
		var matchNode *OlangNode
		for _, n := range g.AllNodes() {
			if n.Glyph == string(tc.cp) {
				matchNode = n
				break
			}
		}
		if matchNode != nil {
			t.Logf("✅ '%c' (%s) → ISL[%02X][%02X][%02X][%02X] Layer=%d",
				tc.cp, tc.name,
				matchNode.Addr.Layer, matchNode.Addr.Group,
				matchNode.Addr.Type, matchNode.Addr.ID,
				matchNode.Layer)
			found++
		} else {
			t.Logf("⚠️  '%c' (%s) not found in graph", tc.cp, tc.name)
		}
	}

	if found == 0 {
		t.Error("No CJK nodes loaded into graph")
	}
	t.Logf("Found %d/%d CJK test chars in graph", found, len(testChars))
}
