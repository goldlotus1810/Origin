// internal/silk/olang_loader.go
// LoadFromOlang — đọc nodes VÀ raw edges từ homeos.olang binary → SilkGraph
//
// Hỗ trợ V18 (inline name) và V19 (NamesTable riêng).
// Edges: ISL-only, src(8B)+dst(8B)+type(1B)+weight(4B) — không thay đổi.

package silk

import (
	"encoding/binary"
	"log"
	"math"
	"os"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

const (
	olHdrSize = 64
	olEntSize = 24
	olNLayers = 9
	olIdxEnd  = olHdrSize + olNLayers*olEntSize // 280
)

// LoadFromOlang đọc toàn bộ homeos.olang:
//   - L1–L7 nodes → graph (nodes + byID)
//   - Raw edges (type 0x01–0x0F, V2=21B) → graph.rawEdges
//
// Tự động detect V18 (inline name) vs V19 (NamesTable).
// Trả về (nodesAdded, edgesAdded).
func LoadFromOlang(g *SilkGraph, path string) (int, int) {
	raw, err := os.ReadFile(path)
	if err != nil || len(raw) < olIdxEnd { return 0, 0 }
	if string(raw[0:4]) != "OLNG" { return 0, 0 }

	// Detect format version
	fileVersion := binary.BigEndian.Uint16(raw[4:6])
	isV19 := fileVersion >= 19

	nedges    := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < olIdxEnd { edgeStart = olIdxEnd }

	// ── Bước 1: Parse node records ─────────────────────────────
	type nodeRecord struct {
		layerID uint8
		isl     [8]byte
		cp      [4]byte
		dna     string
		name    string
	}
	var records []nodeRecord

	if isV19 {
		// V19: node không có nameLen field (19B header)
		for i := olIdxEnd; i+olang.NodeHeaderSizeV19 <= edgeStart; {
			if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
			if i+olang.NodeHeaderSizeV19 > len(raw) { break }
			layerID := raw[i+2]
			var islB [8]byte; copy(islB[:], raw[i+3:i+11])
			var cpB  [4]byte; copy(cpB[:],  raw[i+11:i+15])
			dnaLen  := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
			if dnaLen < 0 || dnaLen > 65536 { i++; continue }
			end := i + olang.NodeHeaderSizeV19 + dnaLen
			if end > len(raw) { break }
			records = append(records, nodeRecord{
				layerID: layerID,
				isl:     islB,
				cp:      cpB,
				dna:     string(raw[i+olang.NodeHeaderSizeV19 : end]),
			})
			i = end
		}
		// Load NamesTable và populate name
		names := loadNamesTable(raw, edgeStart)
		for idx := range records {
			islU := binary.BigEndian.Uint64(records[idx].isl[:])
			records[idx].name = names.Get(islU)
		}
	} else {
		// V18: node có nameLen(1) + name (format cũ)
		for i := olIdxEnd; i+olang.NodeHeaderSizeV18 < edgeStart; {
			if raw[i] != 'N' || raw[i+1] != 'D' { i++; continue }
			if i+olang.NodeHeaderSizeV18 > len(raw) { break }
			layerID := raw[i+2]
			var islB [8]byte; copy(islB[:], raw[i+3:i+11])
			var cpB  [4]byte; copy(cpB[:],  raw[i+11:i+15])
			dnaLen  := int(binary.BigEndian.Uint32(raw[i+15:i+19]))
			nameLen := int(raw[i+19])
			if dnaLen > 65536 || nameLen > 255 { i++; continue }
			dnaStart  := i + olang.NodeHeaderSizeV18
			nameStart := dnaStart + dnaLen
			if nameStart+nameLen > len(raw) { break }
			records = append(records, nodeRecord{
				layerID: layerID,
				isl:     islB,
				cp:      cpB,
				dna:     string(raw[dnaStart : dnaStart+dnaLen]),
				name:    string(raw[nameStart : nameStart+nameLen]),
			})
			i = nameStart + nameLen
		}
	}

	// ── Bước 2: Build ISL index (cho edge resolution) ──────────
	islIndex := map[[8]byte]string{}
	for _, r := range records {
		if r.name != "" {
			islIndex[r.isl] = r.name
		}
	}

	// ── Bước 3: Add nodes vào SilkGraph ────────────────────────
	nodesAdded := 0
	for _, r := range records {
		addr := isl.Address{
			Layer: r.isl[0], Group: r.isl[1],
			Type:  r.isl[2], ID:    r.isl[3],
		}

		if r.layerID == 1 {
			if _, exists := g.Get(addr); exists { continue }
			cp := decodeCodepointFromRecord(r.cp[:])
			if cp == 0 { cp = decodeCodepoint(r.dna) }
			var glyph string
			if cp > 0 { glyph = string(cp) }
			node := &OlangNode{
				Name:   r.name,
				Addr:   addr,
				Layer:  1,
				Glyph:  glyph,
				DNA:    r.dna,
				Cat:    "utf32",
				Status: StatusQR,
			}
			g.AddNode(node)
			nodesAdded++
			continue
		}

		if r.layerID == 7 {
			if r.name == "" { continue }
			isDNAText := strings.Contains(r.dna, "=") ||
				strings.Contains(r.dna, ",") ||
				len(r.dna) == 0
			dna := r.dna
			if !isDNAText { dna = "" }
			node := &OlangNode{
				Name:  r.name,
				Addr:  addr,
				Layer: int(r.layerID),
				DNA:   dna,
			}
			g.ForceAddByName(r.name, node)
			nodesAdded++
			continue
		}

		if r.layerID >= 2 && r.layerID <= 6 {
			if r.name == "" { continue }
			if _, exists := g.GetByName(r.name); exists { continue }
			node := &OlangNode{
				Name:   r.name,
				Addr:   addr,
				Layer:  int(r.layerID),
				DNA:    r.dna,
				Status: StatusQR,
			}
			g.ForceAddByName(r.name, node)
			nodesAdded++
			continue
		}
	}

	// ── Bước 4: Parse raw edges từ cuối file ───────────────────
	// Edges: ISL-only, src(8)+dst(8)+type(1)+weight(4) = 21B
	// Không có name, không có DNA — chỉ ISL addresses
	edgesAdded := 0
	for i := len(raw) - olang.EdgeSize; i >= olIdxEnd; i -= olang.EdgeSize {
		if i+olang.EdgeSize > len(raw) { continue }
		edgeType := raw[i+16]
		if edgeType < 0x01 || edgeType > 0x0F { continue }

		var src, dst [8]byte
		copy(src[:], raw[i:i+8])
		copy(dst[:], raw[i+8:i+16])

		srcName := islIndex[src]
		dstName := islIndex[dst]
		if srcName == "" || dstName == "" { continue }

		// Chỉ load edges giữa AGENT/SKILL nodes vào rawEdges
		if !strings.HasPrefix(srcName, "AGENT_") && !strings.HasPrefix(srcName, "SKILL_") { continue }
		if !strings.HasPrefix(dstName, "AGENT_") && !strings.HasPrefix(dstName, "SKILL_") { continue }

		srcAddr := toAddr(src)
		dstAddr := toAddr(dst)
		var w float32 = 1.0
		if olang.EdgeSize == olang.EdgeSizeV2 && i+21 <= len(raw) {
			w = math.Float32frombits(binary.BigEndian.Uint32(raw[i+17 : i+21]))
		}
		g.AddRawEdgeWeighted(srcAddr, dstAddr, edgeType, w)
		edgesAdded++
	}

	log.Printf("○ SilkGraph: +%d nodes (L1–L7), +%d raw edges từ %s (V%d)",
		nodesAdded, edgesAdded, path, fileVersion)
	return nodesAdded, edgesAdded
}

// loadNamesTable — đọc NamesTable từ raw bytes (V19 only)
// Dùng offset từ header[28:32] (fast path).
// Fallback: scan ngược từ edgeStart.
func loadNamesTable(raw []byte, edgeStart int) *olang.NamesTable {
	// Fast path: offset tại header[28:32]
	if len(raw) >= 32 {
		offset := int(binary.BigEndian.Uint32(raw[28:32]))
		if offset > 280 && offset < edgeStart && offset+6 < len(raw) {
			if raw[offset] == 'N' && raw[offset+1] == 'T' {
				t, consumed := olang.ParseNamesTable(raw[offset:])
				if consumed > 0 && offset+consumed <= edgeStart {
					return t
				}
			}
		}
	}
	// Fallback: scan ngược (V19 files không có offset hợp lệ)
	for start := edgeStart - 6; start >= 280; start-- {
		if start+2 > len(raw) { continue }
		if raw[start] != 'N' || raw[start+1] != 'T' { continue }
		t, consumed := olang.ParseNamesTable(raw[start:])
		if consumed > 0 && start+consumed == edgeStart {
			return t
		}
	}
	return olang.NewNamesTable()
}

// LoadL7FromOlang — backward compat wrapper
func LoadL7FromOlang(g *SilkGraph, path string) int {
	n, _ := LoadFromOlang(g, path)
	return n
}

// LoadL1FromOlang — backward compat wrapper
func LoadL1FromOlang(g *SilkGraph, path string) int {
	n, _ := LoadFromOlang(g, path)
	return n
}

// ── Helpers ───────────────────────────────────────────────────

func decodeCodepoint(dna string) rune {
	if len(dna) < 6 { return 0 }
	b := []byte(dna)
	if b[0] == 0x01 {
		return rune(b[2])<<24 | rune(b[3])<<16 | rune(b[4])<<8 | rune(b[5])
	}
	return 0
}

func decodeCodepointFromRecord(cpBytes []byte) rune {
	if len(cpBytes) < 4 { return 0 }
	return rune(cpBytes[0])<<24 | rune(cpBytes[1])<<16 | rune(cpBytes[2])<<8 | rune(cpBytes[3])
}

func toAddr(b [8]byte) isl.Address {
	return isl.Address{Layer: b[0], Group: b[1], Type: b[2], ID: b[3]}
}

func layerCat(l uint8) string {
	switch l {
	case 1: return "utf32"
	case 2: return "nature"
	case 3: return "life"
	case 4: return "objects"
	case 5: return "programming"
	case 6: return "perception"
	case 7: return "programs"
	default: return "unknown"
	}
}

// ════════════════════════════════════════════════════════════════
// LoadAllFromOlang — dùng olang.ParseBytes, load TẤT CẢ layers
// ════════════════════════════════════════════════════════════════

func LoadAllFromOlang(g *SilkGraph, path string) (int, int) {
	raw, err := os.ReadFile(path)
	if err != nil { return 0, 0 }

	res, err := olang.ParseBytes(raw)
	if err != nil {
		log.Printf("LoadAllFromOlang: parse error: %v", err)
		return 0, 0
	}

	nodesAdded := 0
	for _, n := range res.Nodes {
		if n.Name == "" || n.Layer == 0 { continue }
		if n.Layer > 8 { continue }

		addr := isl.Address{
			Layer: uint8(n.ISLAddr >> 56),
			Group: uint8(n.ISLAddr >> 48),
			Type:  uint8(n.ISLAddr >> 40),
			ID:    uint8(n.ISLAddr >> 32),
		}

		if _, exists := g.GetByName(n.Name); exists { continue }

		var glyph string
		if n.Layer == uint8(1) {
			if cp := decodeCodepoint(string(n.DNA)); cp > 0 {
				glyph = string(cp)
			}
		}

		node := &OlangNode{
			Name:   n.Name,
			Addr:   addr,
			Layer:  int(n.Layer),
			Glyph:  glyph,
			DNA:    string(n.DNA),
			Cat:    layerCat(n.Layer),
			Status: StatusQR,
		}
		g.ForceAddByName(n.Name, node)
		nodesAdded++
	}

	edgesAdded := 0
	for _, e := range res.Edges {
		srcAddr := isl.Address{
			Layer: uint8(e.Src >> 56),
			Group: uint8(e.Src >> 48),
			Type:  uint8(e.Src >> 40),
			ID:    uint8(e.Src >> 32),
		}
		dstAddr := isl.Address{
			Layer: uint8(e.Dst >> 56),
			Group: uint8(e.Dst >> 48),
			Type:  uint8(e.Dst >> 40),
			ID:    uint8(e.Dst >> 32),
		}
		if _, ok := g.Get(srcAddr); !ok { continue }
		if _, ok := g.Get(dstAddr); !ok { continue }
		g.AddEdge(srcAddr, dstAddr, EdgeOp(e.Type))
		edgesAdded++
	}

	return nodesAdded, edgesAdded
}
