package silk

import "testing"

func TestL3L6Nodes(t *testing.T) {
	g := NewSilkGraph()
	SeedUnicodeTree(g)
	ApplyNameEdges(g)
	SeedUTF32(g)
	SeedUTF32Bridge(g)
	LoadFromOlang(g, "../../homeos.olang")
	r := NewSilkReasoner(g)

	queries := []struct{ q, want string }{
		{"tò mò",     "LIFE_CURIOSITY"},
		{"suy nghĩ",  "LIFE_THINK"},
		{"chạy",      "LIFE_RUN"},
		{"đói bụng",  "PERCEPT_HUNGER"},
		{"mệt mỏi",   "PERCEPT_TIRED"},
		{"tươi mát",  "PERCEPT_FRESH"},
		{"sắc bén",   "PERCEPT_SHARP"},
		{"đau đớn",   "PERCEPT_PAIN"},
		{"tin tưởng", "LIFE_TRUST"},
	}
	pass := 0
	for _, tc := range queries {
		rr := r.Reason(tc.q)
		if rr.HasResult() {
			t.Logf("✅ %q → %s", tc.q, rr.BestNode().Name)
			pass++
		} else {
			t.Logf("⚠️  %q → no result (want %s)", tc.q, tc.want)
		}
	}
	t.Logf("%d/%d L3/L6 queries resolved", pass, len(queries))
	if pass == 0 {
		t.Error("No L3/L6 nodes resolvable via DNA label search")
	}
}
