// internal/silk/edge_index.go
// EdgeIndex — index O(1) cho Silk edges theo type + ISL address
//
// Vấn đề: Silk append-only ledger → scan O(n) để tìm edge
// Giải pháp: in-memory index xây khi load, rebuild khi cần
//
// Structure:
//   index[EdgeType][ISLAddr] → []int (offsets trong ledger)
//
// Không lưu index vào disk — rebuild từ ledger khi khởi động.
// Index chỉ là cache — mất đi không sao, ledger là source of truth.

package silk

import (
	"strings"
	"sync"
)

// ISLAddr — 8 byte address (dùng string làm map key)
type ISLAddr = string

// EdgeRecord — một entry trong index
type EdgeRecord struct {
	Type    EdgeType
	Addr    ISLAddr // ISL address của node liên quan (nếu có)
	DNA     string  // payload đầy đủ
	Offset  int     // vị trí trong ledger (để seek nhanh)
}

// EdgeIndex — in-memory index, thread-safe
type EdgeIndex struct {
	mu      sync.RWMutex
	byType  map[EdgeType][]EdgeRecord      // tất cả edges theo type
	byAddr  map[ISLAddr][]EdgeRecord       // edges theo ISL address
	total   int
}

func NewEdgeIndex() *EdgeIndex {
	return &EdgeIndex{
		byType: make(map[EdgeType][]EdgeRecord),
		byAddr: make(map[ISLAddr][]EdgeRecord),
	}
}

// Add thêm edge vào index (gọi sau khi append vào ledger)
func (idx *EdgeIndex) Add(dna string, addr ISLAddr, offset int) {
	t := ParseEdgeType(dna)
	rec := EdgeRecord{Type: t, Addr: addr, DNA: dna, Offset: offset}

	idx.mu.Lock()
	idx.byType[t] = append(idx.byType[t], rec)
	if addr != "" {
		idx.byAddr[addr] = append(idx.byAddr[addr], rec)
	}
	idx.total++
	idx.mu.Unlock()
}

// QueryByType — O(1) lookup tất cả edges của 1 type
func (idx *EdgeIndex) QueryByType(t EdgeType) []EdgeRecord {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	res := make([]EdgeRecord, len(idx.byType[t]))
	copy(res, idx.byType[t])
	return res
}

// QueryByAddr — O(1) tất cả edges liên quan đến 1 ISL address
func (idx *EdgeIndex) QueryByAddr(addr ISLAddr) []EdgeRecord {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	res := make([]EdgeRecord, len(idx.byAddr[addr]))
	copy(res, idx.byAddr[addr])
	return res
}

// QueryByTypeAndAddr — giao của 2 điều kiện
func (idx *EdgeIndex) QueryByTypeAndAddr(t EdgeType, addr ISLAddr) []EdgeRecord {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	var result []EdgeRecord
	for _, rec := range idx.byAddr[addr] {
		if rec.Type == t {
			result = append(result, rec)
		}
	}
	return result
}

// QueryEmotionHistory — lấy toàn bộ lịch sử cảm xúc, mới nhất trước
func (idx *EdgeIndex) QueryEmotionHistory(addr ISLAddr) []EdgeRecord {
	recs := idx.QueryByTypeAndAddr(EdgeEmotion, addr)
	// Đảo ngược — append-only nên cuối = mới nhất
	for i, j := 0, len(recs)-1; i < j; i, j = i+1, j-1 {
		recs[i], recs[j] = recs[j], recs[i]
	}
	return recs
}

// QueryInflections — lấy tất cả bước ngoặt của 1 nguồn
func (idx *EdgeIndex) QueryInflections(addr ISLAddr) []EdgeRecord {
	return idx.QueryByTypeAndAddr(EdgeInflect, addr)
}

// Stats — thống kê nhanh
func (idx *EdgeIndex) Stats() string {
	idx.mu.RLock()
	defer idx.mu.RUnlock()
	var b strings.Builder
	b.WriteString("EdgeIndex stats:\n")
	types := []EdgeType{EdgeSemantic, EdgeEmotion, EdgeInflect, EdgeKnowledge, EdgeContext, EdgeSpline}
	for _, t := range types {
		n := len(idx.byType[t])
		if n > 0 {
			b.WriteString("  " + t.Prefix() + ": " + itoa(n) + "\n")
		}
	}
	b.WriteString("  total: " + itoa(idx.total) + "  addrs: " + itoa(len(idx.byAddr)))
	return b.String()
}

func itoa(n int) string {
	if n == 0 { return "0" }
	buf := make([]byte, 0, 10)
	for n > 0 { buf = append([]byte{byte('0' + n%10)}, buf...); n /= 10 }
	return string(buf)
}
