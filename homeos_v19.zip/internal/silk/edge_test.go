package silk

import (
	"fmt"
	"testing"
)

func TestEdgeTypeAndIndex(t *testing.T) {
	t.Log("=== EdgeType prefix + EdgeIndex O(1) ===\n")

	// ── Test 1: ParseEdgeType ──────────────────────────────────────
	cases := []struct {
		dna  string
		want EdgeType
	}{
		{"sem:ABa1→DCb4:w=0.82", EdgeSemantic},
		{"emo:t=1741500100:v=-0.60:label=melancholy", EdgeEmotion},
		{"infl:turn=3:v=-0.70:d2=+0.70", EdgeInflect},
		{"knw:QR:ABa1:conf=0.91", EdgeKnowledge},
		{"ctx:role=first_person:src=real_now", EdgeContext},
	}
	t.Log("ParseEdgeType:")
	for _, c := range cases {
		got := ParseEdgeType(c.dna)
		ok := "✓"
		if got != c.want { ok = "✗" }
		t.Logf("  %-45s → %-4s %s", c.dna[:min(45,len(c.dna))], got.Prefix(), ok)
	}

	// ── Test 2: EdgeIndex ──────────────────────────────────────────
	t.Log("\nEdgeIndex (O(1) query):")
	idx := NewEdgeIndex()

	addr1 := "ABa1____" // ISL address node A
	addr2 := "DCb4____" // ISL address node B

	// Thêm 1000 edges (mô phỏng đọc sách dài)
	for i := 0; i < 84; i++ {
		idx.Add(fmt.Sprintf("infl:turn=%d:v=%.2f", i, float64(i)*0.01-0.42), addr1, i*60)
	}
	for i := 0; i < 200; i++ {
		idx.Add(fmt.Sprintf("emo:t=%d:v=%.2f:label=neutral", 1741500000+i, float64(i)*0.005), addr1, 5040+i*80)
	}
	for i := 0; i < 50; i++ {
		idx.Add(fmt.Sprintf("knw:QR:ABa1:conf=%.2f", 0.5+float64(i)*0.01), addr2, 21040+i*100)
	}
	for i := 0; i < 30; i++ {
		idx.Add(fmt.Sprintf("sem:ABa1→DCb4:w=%.2f", float64(i)*0.03), addr1, 26040+i*40)
		idx.Add(fmt.Sprintf("sem:ABa1→DCb4:w=%.2f", float64(i)*0.03), addr2, 26040+i*40)
	}

	t.Log(idx.Stats())

	// Query theo type — O(1)
	inflects := idx.QueryByType(EdgeInflect)
	emos     := idx.QueryByType(EdgeEmotion)
	t.Logf("\n  QueryByType(infl): %d records", len(inflects))
	t.Logf("  QueryByType(emo):  %d records", len(emos))

	// Query theo addr — O(1)
	addr1Edges := idx.QueryByAddr(addr1)
	t.Logf("  QueryByAddr(addr1): %d records", len(addr1Edges))

	// EmotionHistory — mới nhất trước
	history := idx.QueryEmotionHistory(addr1)
	t.Logf("  EmotionHistory(addr1): %d records, latest: %s",
		len(history), history[0].DNA[:min(40, len(history[0].DNA))])

	// Verify: không collision
	for _, rec := range inflects {
		if ParseEdgeType(rec.DNA) != EdgeInflect {
			t.Error("collision: infl bucket contains non-infl edge")
		}
	}
	t.Log("\n✓ Không collision")
	t.Log("✓ QueryByType O(1) — không scan toàn bộ ledger")
	t.Log("✓ Index rebuild từ ledger — không cần persist")

	// ── Test 3: Không có SplineEdge ──────────────────────────────────
	splines := idx.QueryByType(EdgeSpline)
	t.Logf("\n  SplineEdge count: %d (reserved, reconstruct từ InflectEdge)", len(splines))
}

func min(a, b int) int {
	if a < b { return a }
	return b
}
