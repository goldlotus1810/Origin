package silk

import "testing"

func TestDNALabelSearch(t *testing.T) {
	g := NewSilkGraph()
	LoadFromOlang(g, "../../homeos.olang")

	// Tìm LIFE_CURIOSITY node và in DNA
	for _, n := range g.AllNodes() {
		if n.Name == "LIFE_CURIOSITY" || n.Name == "LIFE_THINK" || n.Name == "PERCEPT_HUNGER" {
			t.Logf("Node: %s Layer=%d DNA=%q", n.Name, n.Layer, n.DNA)
		}
	}

	// Test dnaField
	testDNA := "label=tò mò|desc=ham muốn tìm hiểu|vi=tò mò,curious"
	label := dnaField(testDNA, "label")
	vi    := dnaField(testDNA, "vi")
	t.Logf("dnaField label=%q vi=%q", label, vi)
}
