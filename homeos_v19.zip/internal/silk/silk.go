// internal/silk/silk.go
// Silk Web — cấu trúc lưu trữ tri thức của HomeOS
// OlangAtom: 12B/symbol (4B codepoint + 8B ISL)
// SilkEdge: silk link giữa 2 nodes
// SilkGraph: đồ thị tri thức append-only

package silk

import (
	"crypto/ed25519"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"strings"
	"os"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─────────────────────────────────────────────────────────────────
// OLANG ATOM — 12 bytes/symbol
// ─────────────────────────────────────────────────────────────────

// OlangAtom là đơn vị cơ bản của ngôn ngữ Olang
// Codepoint: 4B UTF-32 (ký tự gốc)
// ISL:       8B address (nghĩa trong hệ thống)
type OlangAtom struct {
	Codepoint rune        // 4B — ký tự UTF-32
	ISL       isl.Address // 8B — địa chỉ ISL
} // = 12B/symbol như spec

// ─────────────────────────────────────────────────────────────────
// SILK EDGE — liên kết ngữ nghĩa
// ─────────────────────────────────────────────────────────────────

// EdgeOp là loại quan hệ của silk edge
type EdgeOp rune

const (
	OpMember    EdgeOp = '∈' // thuộc về (parent-child)
	OpEquiv     EdgeOp = '≡' // tương đương ngữ nghĩa (A≡α≡а)
	OpPhonetic  EdgeOp = '♫' // cùng âm qua IPA
	OpCompose   EdgeOp = '∘' // tổ hợp (math∘olang)
	OpSimilar   EdgeOp = '≈' // tương tự
)

// SilkEdge là một liên kết ngữ nghĩa giữa 2 nodes
type SilkEdge struct {
	To     isl.Address // địa chỉ node đích
	Op     EdgeOp      // loại quan hệ
	Weight int         // Hebbian weight — tăng khi 2 nodes co-activate
}

// ─────────────────────────────────────────────────────────────────
// NODE STATUS
// ─────────────────────────────────────────────────────────────────

type NodeStatus byte

const (
	StatusDN       NodeStatus = 0x01 // ΔΨ — đang học, chưa chứng minh
	StatusQR       NodeStatus = 0x02 // QR — đã chứng minh, append-only
	StatusArchived NodeStatus = 0x03 // ARCHIVED — không xóa, chỉ ẩn
)

// ─────────────────────────────────────────────────────────────────
// OLANG NODE
// ─────────────────────────────────────────────────────────────────

// OlangNode là node trong SilkGraph
type OlangNode struct {
	Addr   isl.Address  // địa chỉ ISL của node
	Atom   *OlangAtom   // atom gốc (nếu là character node)
	Edges  []SilkEdge   // silk links đi ra
	Status NodeStatus
	Weight int          // số lần xác nhận
	Sig    []byte       // ED25519 signature (chỉ QR nodes)
	// Metadata
	Name   string       // tên human-readable
	Glyph  string       // ký tự hiển thị
	Cat    string       // category (scripts/math/geo/...)
	Layer  int          // 0=origin, 1=supergroup, 2=family, 3=leaf
	// Olang encoding
	DNA    string       // SDF formula trong Olang notation — lưu công thức, không lưu hình
	// Ví dụ: "∪(⌀(-.28,.44,0,-.44,0), ⌀(.28,.44,0,-.44,0), □(0,.05,.36,.04))"
}

// ─────────────────────────────────────────────────────────────────
// SILK GRAPH — đồ thị tri thức
// ─────────────────────────────────────────────────────────────────

// SilkGraph là đồ thị tri thức append-only
// Tìm kiếm: đến đúng node → Walk theo silk edges → không scan toàn bộ
type SilkGraph struct {
	mu       sync.RWMutex
	nodes    map[uint64]*OlangNode // key = isl.Address.Uint64()
	byID     map[string]*OlangNode // key = tên/id string (cho prototype)
	rawEdges []OlangEdge           // raw edges từ olang file (type byte)
}

func NewSilkGraph() *SilkGraph {
	return &SilkGraph{
		nodes: make(map[uint64]*OlangNode),
		byID:  make(map[string]*OlangNode),
	}
}

// AddRawEdge thêm raw edge (từ olang file) vào graph
func (g *SilkGraph) AddRawEdge(src, dst isl.Address, edgeType uint8) {
	g.AddRawEdgeWeighted(src, dst, edgeType, 1.0)
}

// AddRawEdgeWeighted thêm raw edge với Hebbian weight từ V2 format
func (g *SilkGraph) AddRawEdgeWeighted(src, dst isl.Address, edgeType uint8, weight float32) {
	g.mu.Lock(); defer g.mu.Unlock()
	for _, e := range g.rawEdges {
		if e.Src == src && e.Dst == dst && e.Type == edgeType { return }
	}
	g.rawEdges = append(g.rawEdges, OlangEdge{Src: src, Dst: dst, Type: edgeType, Weight: weight})
}

// AddNode thêm node — nếu đã tồn tại thì update (ΔΨ) hoặc bỏ qua (QR)
func (g *SilkGraph) AddNode(n *OlangNode) {
	g.mu.Lock(); defer g.mu.Unlock()
	key := n.Addr.Uint64()
	existing, ok := g.nodes[key]
	if ok && existing.Status == StatusQR {
		return // QR = append-only, không ghi đè
	}
	g.nodes[key] = n
	if n.Name != "" {
		g.byID[n.Name] = n
	}
}

// AddEdge thêm silk edge từ fromAddr đến toAddr
func (g *SilkGraph) AddEdge(from, to isl.Address, op EdgeOp) {
	g.mu.Lock(); defer g.mu.Unlock()
	n := g.nodes[from.Uint64()]
	if n == nil {
		return
	}
	// Không thêm duplicate
	for _, e := range n.Edges {
		if e.To.Uint64() == to.Uint64() && e.Op == op {
			return
		}
	}
	n.Edges = append(n.Edges, SilkEdge{To: to, Op: op})
}

// BoostEdge tăng Hebbian weight của edge (from→to)
// Nếu edge chưa tồn tại, tạo mới với weight=1
func (g *SilkGraph) BoostEdge(from, to isl.Address, op EdgeOp) {
	g.mu.Lock(); defer g.mu.Unlock()
	n := g.nodes[from.Uint64()]
	if n == nil { return }
	for i := range n.Edges {
		if n.Edges[i].To.Uint64() == to.Uint64() && n.Edges[i].Op == op {
			n.Edges[i].Weight++
			return
		}
	}
	// Edge chưa tồn tại — tạo mới
	n.Edges = append(n.Edges, SilkEdge{To: to, Op: op, Weight: 1})
}

// EdgeWeight trả về Hebbian weight của edge (from→to), 0 nếu không có
func (g *SilkGraph) EdgeWeight(fromU, toU uint64) int {
	g.mu.RLock(); defer g.mu.RUnlock()
	n := g.nodes[fromU]
	if n == nil { return 0 }
	for _, e := range n.Edges {
		if e.To.Uint64() == toU { return e.Weight }
	}
	return 0
}

// HasEdge kiểm tra edge (from→to) tồn tại với bất kỳ Op nào
func (g *SilkGraph) HasEdge(from, to isl.Address) bool {
	g.mu.RLock(); defer g.mu.RUnlock()
	n := g.nodes[from.Uint64()]
	if n == nil { return false }
	toU := to.Uint64()
	for _, e := range n.Edges {
		if e.To.Uint64() == toU { return true }
	}
	return false
}

// Get lấy node theo địa chỉ ISL
func (g *SilkGraph) Get(addr isl.Address) (*OlangNode, bool) {
	g.mu.RLock(); defer g.mu.RUnlock()
	n, ok := g.nodes[addr.Uint64()]
	return n, ok
}

// GetByName lấy node theo tên (dùng cho prototype/debug)
func (g *SilkGraph) GetByName(name string) (*OlangNode, bool) {
	g.mu.RLock(); defer g.mu.RUnlock()
	n, ok := g.byID[name]
	return n, ok
}

// ForceAddByName — overwrite byID bất kể node cũ có QR hay không
// Dùng cho append-only ledger: node cuối cùng = định nghĩa hiện tại
func (g *SilkGraph) ForceAddByName(name string, n *OlangNode) {
	g.mu.Lock(); defer g.mu.Unlock()
	// Remove old node entry if name already mapped to different ISL
	if name != "" {
		if old, had := g.byID[name]; had && old.Addr.Uint64() != n.Addr.Uint64() {
			delete(g.nodes, old.Addr.Uint64()) // xóa ISL cũ
		}
		g.byID[name] = n
	}
	// Overwrite nodes map (last wins — append-only)
	g.nodes[n.Addr.Uint64()] = n
}

// Walk đi theo silk edges từ node, lọc theo op (OpMember = theo cây)
// Đây là cách tìm kiếm chính: không scan toàn bộ graph
func (g *SilkGraph) Walk(from isl.Address, op EdgeOp) []*OlangNode {
	g.mu.RLock(); defer g.mu.RUnlock()
	n := g.nodes[from.Uint64()]
	if n == nil {
		return nil
	}
	var result []*OlangNode
	for _, e := range n.Edges {
		if e.Op == op {
			if child, ok := g.nodes[e.To.Uint64()]; ok {
				result = append(result, child)
			}
		}
	}
	return result
}

// WalkWeighted trả về nodes qua edges, sorted by Weight (cao → thấp)
// Nodes có Hebbian weight cao hơn được ưu tiên trong BFS
func (g *SilkGraph) WalkWeighted(from isl.Address, op EdgeOp) []*OlangNode {
	g.mu.RLock(); defer g.mu.RUnlock()
	n := g.nodes[from.Uint64()]
	if n == nil { return nil }

	type weighted struct {
		node   *OlangNode
		weight int
	}
	var items []weighted
	for _, e := range n.Edges {
		if e.Op == op {
			if child, ok := g.nodes[e.To.Uint64()]; ok {
				items = append(items, weighted{node: child, weight: e.Weight})
			}
		}
	}
	// Sort: weight cao trước
	for i := 1; i < len(items); i++ {
		for j := 0; j < len(items)-i; j++ {
			if items[j].weight < items[j+1].weight {
				items[j], items[j+1] = items[j+1], items[j]
			}
		}
	}
	result := make([]*OlangNode, len(items))
	for i, it := range items {
		result[i] = it.node
	}
	return result
}

// WalkWeightedMulti traverse nhiều EdgeOp cùng lúc, merge+dedup, sort by weight
// Dùng khi muốn lấy cả OpMember lẫn OpSimilar (Hebbian edges) cùng lúc
func (g *SilkGraph) WalkWeightedMulti(from isl.Address, ops ...EdgeOp) []*OlangNode {
	g.mu.RLock(); defer g.mu.RUnlock()
	n := g.nodes[from.Uint64()]
	if n == nil { return nil }

	type weighted struct {
		node   *OlangNode
		weight int
	}
	seen := map[uint64]bool{}
	var items []weighted

	for _, e := range n.Edges {
		for _, op := range ops {
			if e.Op == op {
				key := e.To.Uint64()
				if seen[key] { break }
				if child, ok := g.nodes[key]; ok {
					seen[key] = true
					items = append(items, weighted{node: child, weight: e.Weight})
				}
				break
			}
		}
	}
	// Sort: weight cao trước (insertion sort — thường ít items)
	for i := 1; i < len(items); i++ {
		for j := 0; j < len(items)-i; j++ {
			if items[j].weight < items[j+1].weight {
				items[j], items[j+1] = items[j+1], items[j]
			}
		}
	}
	result := make([]*OlangNode, len(items))
	for i, it := range items { result[i] = it.node }
	return result
}

// DecayAllEdges giảm weight của tất cả edges đi 1 (không xuống dưới minWeight)
// Trả về số edges bị decay
func (g *SilkGraph) DecayAllEdges(minWeight int) int {
	g.mu.Lock(); defer g.mu.Unlock()
	decayed := 0
	for _, n := range g.nodes {
		for i := range n.Edges {
			if n.Edges[i].Weight > minWeight {
				n.Edges[i].Weight--
				decayed++
			}
		}
	}
	return decayed
}

// HebbianDecayTime-based decay: giảm weight theo số ngày kể từ lastAccess
// Rate: weight -= decayPerDay * days. Không xuống dưới minWeight.
// Trả về số edges bị decay và số bị prune (weight <= minWeight sau decay)
func (g *SilkGraph) HebbianDecay(decayPerDay float64, minWeight int, elapsed time.Duration) (decayed, pruned int) {
	if elapsed <= 0 {
		return 0, 0
	}
	days := elapsed.Hours() / 24.0
	delta := int(decayPerDay * days)
	if delta <= 0 {
		return 0, 0
	}
	g.mu.Lock(); defer g.mu.Unlock()
	for _, n := range g.nodes {
		for i := range n.Edges {
			if n.Edges[i].Weight > minWeight {
				before := n.Edges[i].Weight
				n.Edges[i].Weight -= delta
				if n.Edges[i].Weight < minWeight {
					n.Edges[i].Weight = minWeight
					pruned++
				}
				if n.Edges[i].Weight < before {
					decayed++
				}
			}
		}
	}
	return decayed, pruned
}

// PersistHighWeightEdges ghi edges có weight >= threshold vào rawEdges của OlangEdge
// để có thể flush ra disk sau. Trả về số edges được update.
// Quy tắc: weight cao → được nhớ lâu dài (QT7: ĐN → QR khi lặp lại đủ)
func (g *SilkGraph) PersistHighWeightEdges(threshold int) []OlangEdge {
	g.mu.RLock(); defer g.mu.RUnlock()
	var result []OlangEdge
	for _, n := range g.nodes {
		for _, e := range n.Edges {
			if e.Weight >= threshold {
				result = append(result, OlangEdge{
					Src:    n.Addr,
					Dst:    e.To,
					Type:   uint8(e.Op),
					Weight: float32(e.Weight),
				})
			}
		}
	}
	return result
}

// NodeCount trả về số nodes hiện tại
func (g *SilkGraph) NodeCount() int {
	g.mu.RLock(); defer g.mu.RUnlock()
	return len(g.nodes)
}

// EdgeCount trả về tổng số silk edges
func (g *SilkGraph) EdgeCount() int {
	g.mu.RLock(); defer g.mu.RUnlock()
	total := 0
	for _, n := range g.nodes {
		total += len(n.Edges)
	}
	return total
}

// AllNodes trả về tất cả nodes (dùng cho renderer)
func (g *SilkGraph) AllNodes() []*OlangNode {
	g.mu.RLock(); defer g.mu.RUnlock()
	out := make([]*OlangNode, 0, len(g.nodes))
	for _, n := range g.nodes {
		out = append(out, n)
	}
	return out
}

// OlangEdge — edge có type byte (dùng cho HAS_SKILL, REQUIRES, PRODUCES)
type OlangEdge struct {
	Src    isl.Address
	Dst    isl.Address
	Type   uint8   // 0x01=HAS_SKILL, 0x02=REQUIRES, 0x03=PRODUCES, 'op'=silk semantic
	Weight float32 // Hebbian weight — 0.0 = unset (treat as 1.0)
}

// AllOlangEdges trả về tất cả edges dưới dạng []OlangEdge
// Bao gồm cả silk edges (Op → Type byte) và raw olang edges (từ olang_loader)
func (g *SilkGraph) AllOlangEdges() []OlangEdge {
	g.mu.RLock(); defer g.mu.RUnlock()
	var out []OlangEdge
	for _, n := range g.nodes {
		for _, e := range n.Edges {
			out = append(out, OlangEdge{Src: n.Addr, Dst: e.To, Type: uint8(e.Op)})
		}
	}
	// Raw edges (từ rawEdges nếu có)
	for _, re := range g.rawEdges {
		out = append(out, re)
	}
	return out
}

// AllNodes trả về slice value (không phải pointer) để loader có thể dùng range an toàn
func (g *SilkGraph) AllNodeValues() []OlangNode {
	g.mu.RLock(); defer g.mu.RUnlock()
	out := make([]OlangNode, 0, len(g.nodes))
	for _, n := range g.nodes {
		out = append(out, *n)
	}
	return out
}

// AllEdges trả về tất cả edges dạng (from, to, op)
func (g *SilkGraph) AllEdges() [][3]interface{} {
	g.mu.RLock(); defer g.mu.RUnlock()
	var out [][3]interface{}
	for _, n := range g.nodes {
		for _, e := range n.Edges {
			out = append(out, [3]interface{}{n.Addr, e.To, e.Op})
		}
	}
	return out
}

// ─────────────────────────────────────────────────────────────────
// LEDGER — append-only với ED25519
// ─────────────────────────────────────────────────────────────────

// LedgerEntry là một entry trong ledger
type LedgerEntry struct {
	Seq       uint64    `json:"seq"`
	Timestamp time.Time `json:"ts"`
	NodeAddr  string    `json:"addr"`  // isl.Address.String()
	Data      []byte    `json:"data"`
	Sig       []byte    `json:"sig"`   // ED25519 signature
}

// Ledger là append-only log của QR nodes
type Ledger struct {
	mu      sync.Mutex
	path    string
	entries []LedgerEntry
	seq     uint64
	privKey ed25519.PrivateKey // nil = unsigned (dev mode)
}

func NewLedger(path string, privKey ed25519.PrivateKey) *Ledger {
	return &Ledger{path: path, privKey: privKey}
}

// Append thêm entry vào ledger
// entry.Sig được tự động tạo nếu privKey != nil
func (l *Ledger) Append(node *OlangNode) error {
	l.mu.Lock(); defer l.mu.Unlock()

	// Marshal only safe fields (no pointer cycles)
	type safeNode struct {
		Addr   string `json:"addr"`
		Name   string `json:"name"`
		Status byte   `json:"status"`
		Weight int    `json:"weight"`
	}
	safe := safeNode{Addr: node.Addr.String(), Name: node.Name, Status: byte(node.Status), Weight: node.Weight}
	data, err := json.Marshal(safe)
	if err != nil {
		return fmt.Errorf("ledger: marshal: %w", err)
	}

	l.seq++
	entry := LedgerEntry{
		Seq:      l.seq,
		Timestamp: time.Now(),
		NodeAddr: node.Addr.String(),
		Data:     data,
	}

	if l.privKey != nil {
		// Sign: seq(8B) + timestamp(8B) + data
		msg := make([]byte, 16+len(data))
		binary.BigEndian.PutUint64(msg[:8], entry.Seq)
		binary.BigEndian.PutUint64(msg[8:16], uint64(entry.Timestamp.Unix()))
		copy(msg[16:], data)
		entry.Sig = ed25519.Sign(l.privKey, msg)
	}

	l.entries = append(l.entries, entry)

	// Persist nếu có path
	if l.path != "" {
		return l.persistEntry(entry)
	}
	return nil
}

func (l *Ledger) persistEntry(e LedgerEntry) error {
	f, err := os.OpenFile(l.path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	return enc.Encode(e)
}

// Count trả về số entries
func (l *Ledger) Count() int {
	l.mu.Lock(); defer l.mu.Unlock()
	return len(l.entries)
}

// SearchNode tìm node theo tên (fuzzy lowercase match)
func (g *SilkGraph) SearchNode(query string) *OlangNode {
	g.mu.RLock()
	defer g.mu.RUnlock()
	q := strings.ToLower(strings.TrimSpace(query))
	// exact match trước
	for _, n := range g.nodes {
		if strings.ToLower(n.Name) == q {
			return n
		}
	}
	// prefix match
	for _, n := range g.nodes {
		if strings.HasPrefix(strings.ToLower(n.Name), q) {
			return n
		}
	}
	// contains match
	for _, n := range g.nodes {
		if strings.Contains(strings.ToLower(n.Name), q) {
			return n
		}
	}
	return nil
}

// WalkFrom BFS từ addr theo silk edges, trả về danh sách nodes liên quan
func (g *SilkGraph) WalkFrom(addr isl.Address, depth, maxHops int) []*OlangNode {
	g.mu.RLock()
	defer g.mu.RUnlock()

	visited := map[uint64]bool{addr.Uint64(): true}
	queue := []isl.Address{addr}
	result := []*OlangNode{}

	for d := 0; d < depth && len(queue) > 0 && len(result) < maxHops; d++ {
		next := []isl.Address{}
		for _, cur := range queue {
			node, ok := g.nodes[cur.Uint64()]
			if !ok {
				continue
			}
			for _, edge := range node.Edges {
				if visited[edge.To.Uint64()] {
					continue
				}
				visited[edge.To.Uint64()] = true
				if neighbor, ok := g.nodes[edge.To.Uint64()]; ok {
					result = append(result, neighbor)
					next = append(next, edge.To)
					if len(result) >= maxHops {
						return result
					}
				}
			}
		}
		queue = next
	}
	return result
}
