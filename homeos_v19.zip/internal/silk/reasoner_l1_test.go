package silk

import (
	"testing"
)

func TestReasonerL1(t *testing.T) {
	g := NewSilkGraph()
	SeedUnicodeTree(g)
	ApplyNameEdges(g)
	ApplyIPAEdges(g)
	SeedUTF32(g)
	SeedUTF32Bridge(g)
	LoadFromOlang(g, "../../homeos.olang") // load L1 + L7

	r := NewSilkReasoner(g)

	tests := []struct {
		query string
		desc  string
	}{
		{"愛",     "CJK love"},
		{"山",     "CJK mountain"},
		{"水",     "CJK water"},
		{"こんにちは", "hiragana hello"},
		{"А",     "Cyrillic A"},
		{"ا",     "Arabic alef"},
		{"đ",     "Vietnamese d with stroke"},
		{"∑",     "Math sum"},
	}

	passed := 0
	for _, tc := range tests {
		rr := r.Reason(tc.query)
		if rr.HasResult() {
			best := rr.BestNode()
			t.Logf("✅ %q (%s) → '%s' [%s] conf=%.2f",
				tc.query, tc.desc,
				best.Glyph, best.Name, rr.Conclusions[0].Confidence)
			passed++
		} else {
			t.Logf("⚠️  %q (%s) → no result", tc.query, tc.desc)
		}
	}
	t.Logf("\n%d/%d queries resolved", passed, len(tests))
	if passed == 0 {
		t.Error("SilkReasoner cannot resolve any L1 query")
	}
}
