// internal/silk/weights.go
//
// EdgeWeightStore — persist Hebbian edge weights vào file riêng
//
// Format: text, append-friendly
//   "from_hex:to_hex weight\n"
//   VD: "0301610100000000:0301620100000000 5\n"
//
// Không phá vỡ homeos.olang format (QT8: lịch sử bất biến).
// Weight file riêng — có thể reset mà không mất knowledge.

package silk

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"sync"
)

// EdgeWeightStore lưu Hebbian weights vào file
type EdgeWeightStore struct {
	mu      sync.RWMutex
	path    string
	weights map[string]int // "from:to" → weight
}

func NewEdgeWeightStore(path string) *EdgeWeightStore {
	s := &EdgeWeightStore{
		path:    path,
		weights: make(map[string]int),
	}
	if path != "" {
		s.load()
	}
	return s
}

// Load đọc weights từ file
func (s *EdgeWeightStore) load() {
	f, err := os.Open(s.path)
	if err != nil {
		return // file chưa tồn tại = ok
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	loaded := 0
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.Fields(line)
		if len(parts) != 2 {
			continue
		}
		w, err := strconv.Atoi(parts[1])
		if err != nil {
			continue
		}
		s.weights[parts[0]] = w
		loaded++
	}
	if loaded > 0 {
		log.Printf("EdgeWeightStore: loaded %d weights from %s", loaded, s.path)
	}
}

// Save ghi tất cả weights ra file (snapshot — không append)
func (s *EdgeWeightStore) Save() error {
	if s.path == "" {
		return nil
	}
	s.mu.RLock()
	defer s.mu.RUnlock()

	f, err := os.CreateTemp("", "weights-*.tmp")
	if err != nil {
		return err
	}
	tmpPath := f.Name()

	w := bufio.NewWriter(f)
	fmt.Fprintf(w, "# HomeOS EdgeWeights — Hebbian learning\n")
	for key, weight := range s.weights {
		fmt.Fprintf(w, "%s %d\n", key, weight)
	}
	if err := w.Flush(); err != nil {
		f.Close()
		os.Remove(tmpPath)
		return err
	}
	f.Close()

	return os.Rename(tmpPath, s.path)
}

// Set ghi weight cho edge
func (s *EdgeWeightStore) Set(fromU, toU uint64, w int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	key := fmt.Sprintf("%016x:%016x", fromU, toU)
	s.weights[key] = w
}

// Get đọc weight của edge (0 nếu không có)
func (s *EdgeWeightStore) Get(fromU, toU uint64) int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	key := fmt.Sprintf("%016x:%016x", fromU, toU)
	return s.weights[key]
}

// ApplyTo áp dụng weights từ store vào SilkGraph (khi startup)
func (s *EdgeWeightStore) ApplyTo(g *SilkGraph) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	applied := 0
	for key, weight := range s.weights {
		parts := strings.Split(key, ":")
		if len(parts) != 2 {
			continue
		}
		var fromU, toU uint64
		fmt.Sscanf(parts[0], "%016x", &fromU)
		fmt.Sscanf(parts[1], "%016x", &toU)

		// Tìm edge trong graph và set weight
		g.mu.Lock()
		n := g.nodes[fromU]
		if n != nil {
			for i := range n.Edges {
				if n.Edges[i].To.Uint64() == toU {
					n.Edges[i].Weight = weight
					applied++
					break
				}
			}
		}
		g.mu.Unlock()
	}
	if applied > 0 {
		log.Printf("EdgeWeightStore: applied %d weights to SilkGraph", applied)
	}
}
