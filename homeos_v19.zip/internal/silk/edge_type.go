// internal/silk/edge_type.go
// EdgeType — định danh loại Silk edge, tránh collision
//
// Quy tắc DNA key: "<prefix>:<payload>"
// Ví dụ:
//   "sem:ABa1→DCb4:w=0.82:t=relation"
//   "emo:t=1741500100:v=-0.60:a=0.70:label=melancholy"
//   "infl:turn=3:v=-0.70:d2=+0.70"
//   "knw:QR:ABa1:conf=0.91:ev=3"
//   "ctx:role=first_person:src=real_now:rec=0.93"

package silk

// EdgeType — 1 byte prefix, append-only ledger-safe
type EdgeType uint8

const (
	EdgeSemantic  EdgeType = 's' // sem: — tơ ngữ nghĩa node↔node
	EdgeEmotion   EdgeType = 'e' // emo: — VAD-I + context
	EdgeInflect   EdgeType = 'i' // infl: — inflection point
	EdgeKnowledge EdgeType = 'k' // knw: — tri thức QR
	EdgeContext   EdgeType = 'c' // ctx: — ngữ cảnh
	EdgeSpline    EdgeType = 'p' // spl: — đường cong nén (reserved, ít dùng)
)

func (t EdgeType) Prefix() string {
	switch t {
	case EdgeSemantic:  return "sem"
	case EdgeEmotion:   return "emo"
	case EdgeInflect:   return "infl"
	case EdgeKnowledge: return "knw"
	case EdgeContext:   return "ctx"
	case EdgeSpline:    return "spl"
	}
	return "unk"
}

func (t EdgeType) String() string { return t.Prefix() }

// ParseEdgeType đọc prefix từ DNA string
func ParseEdgeType(dna string) EdgeType {
	if len(dna) < 3 { return 0 }
	switch {
	case len(dna) > 4 && dna[:4] == "sem:":  return EdgeSemantic
	case len(dna) > 4 && dna[:4] == "emo:":  return EdgeEmotion
	case len(dna) > 5 && dna[:5] == "infl:": return EdgeInflect
	case len(dna) > 4 && dna[:4] == "knw:":  return EdgeKnowledge
	case len(dna) > 4 && dna[:4] == "ctx:":  return EdgeContext
	case len(dna) > 4 && dna[:4] == "spl:":  return EdgeSpline
	}
	return 0
}
