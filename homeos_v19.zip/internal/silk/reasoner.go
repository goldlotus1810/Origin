// internal/silk/reasoner.go
//
// SILK REASONER — Suy luận qua graph
// ====================================
// MASTER.md §1.5: "Gặp từ 'liebe' (Đức, chưa biết):
//   L-i-e-b-e → nodes lá → silk edges → IPA /liːbə/
//   → ISL[K][Concept][Love] → đã link love, yêu, 愛, 사랑
//   → Hiểu nghĩa không cần từ điển Đức-Việt"
//
// MASTER.md §4.1: "confidence giảm 0.85 mỗi bước silk"
//
// Đây KHÔNG phải text matching — đây là graph traversal thật:
//   1. Mỗi ký tự → tìm node trong SilkGraph (O(1) hash lookup)
//   2. Walk silk edges với confidence decay 0.85/hop
//   3. Tổng hợp các node đạt được → kết luận có xác suất

package silk

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"unicode"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

const (
	// ConfidenceDecay: mỗi silk hop giảm confidence 15%
	// MASTER.md §4.1: "confidence giảm 0.85 mỗi bước silk"
	ConfidenceDecay = 0.85

	// MinConfidence: dưới ngưỡng này không đưa vào kết quả
	MinConfidence = 0.10

	// MaxHops: giới hạn độ sâu tìm kiếm
	MaxHops = 4
)

// ── ReasonStep — một bước trong chuỗi suy luận ───────────────

type ReasonStep struct {
	FromAddr   isl.Address
	FromName   string
	FromGlyph  string
	Op         EdgeOp
	ToAddr     isl.Address
	ToName     string
	ToGlyph    string
	ToCategory string
	ToDNA      string  // SDF formula nếu có
	Confidence float64 // tại bước này
	Hop        int
}

func (s ReasonStep) String() string {
	return fmt.Sprintf("[%.2f] %s %s %s %s", s.Confidence,
		s.FromGlyph, edgeSymbol(s.Op), s.ToGlyph, s.ToName)
}

// ── ReasonResult — kết quả suy luận đầy đủ ───────────────────

type ReasonResult struct {
	Input      string
	InputRunes []rune

	// Nodes tìm thấy trực tiếp từ ký tự input
	DirectMatches []*ScoredNode

	// Chuỗi suy luận: mỗi bước một hop qua silk
	Path []ReasonStep

	// Kết luận — nodes có confidence cao nhất
	Conclusions []*ScoredNode

	// Tổng confidence
	TopConfidence float64
}

// ScoredNode — node với điểm confidence
type ScoredNode struct {
	Node       *OlangNode
	Confidence float64
	Source     string // "direct" | "silk_hop_N" | "concept"
	HopCount   int
}

// ── SilkReasoner ──────────────────────────────────────────────

// SilkReasoner thực hiện suy luận qua SilkGraph
// Không phải text matching — là graph traversal với confidence decay
type SilkReasoner struct {
	graph *SilkGraph
}

func NewSilkReasoner(g *SilkGraph) *SilkReasoner {
	return &SilkReasoner{graph: g}
}

// Reason — entry point chính
// Input: query string (bất kỳ ngôn ngữ nào, bất kỳ ký tự nào)
// Output: ReasonResult với chuỗi suy luận có confidence
func (r *SilkReasoner) Reason(query string) *ReasonResult {
	res := &ReasonResult{Input: query}

	// Bước 0: tìm bằng DNA label / vi aliases — ưu tiên cao nhất
	// Cho phép query "tò mò" → LIFE_CURIOSITY, "đói bụng" → PERCEPT_HUNGER
	{
		q := strings.ToLower(strings.TrimSpace(query))
		seen0 := map[string]bool{}
		for _, n := range r.graph.AllNodes() {
			if n.DNA == "" || n.Layer == 1 { continue } // bỏ L1 chars
			dna := strings.ToLower(n.DNA)
			label := dnaField(dna, "label")
			vi    := dnaField(dna, "vi")
			name  := strings.ToLower(n.Name)

			// Chỉ exact match: label, name, hoặc vi alias
			matched := label == q || name == q
			if !matched && vi != "" {
				for _, alias := range strings.Split(vi, ",") {
					if strings.TrimSpace(alias) == q {
						matched = true
						break
					}
				}
			}
			if matched && !seen0[n.Addr.String()] {
				seen0[n.Addr.String()] = true
				res.DirectMatches = append(res.DirectMatches, &ScoredNode{
					Node:       n,
					Confidence: 0.95,
					Source:     "label",
					HopCount:   0,
				})
			}
		}
		// Nếu có label match → populate Conclusions và trả về sớm
		if len(res.DirectMatches) > 0 {
			res.Conclusions = append(res.Conclusions, res.DirectMatches...)
			sort.Slice(res.Conclusions, func(i, j int) bool {
				return res.Conclusions[i].Confidence > res.Conclusions[j].Confidence
			})
			res.TopConfidence = res.Conclusions[0].Confidence
			return res
		}
	}

	// Bước 1: tách ký tự, bỏ space
	for _, ch := range query {
		if !unicode.IsSpace(ch) {
			res.InputRunes = append(res.InputRunes, ch)
		}
	}

	if len(res.InputRunes) == 0 {
		return res
	}

	// Bước 2: tìm direct matches — mỗi ký tự → node trong graph
	seen := map[string]bool{}
	for _, ch := range res.InputRunes {
		nodes := r.findByGlyph(ch)
		for _, n := range nodes {
			key := n.Addr.String()
			if seen[key] {
				continue
			}
			seen[key] = true
			res.DirectMatches = append(res.DirectMatches, &ScoredNode{
				Node:       n,
				Confidence: 1.0,
				Source:     "direct",
				HopCount:   0,
			})
		}
	}

	// Bước 3: BFS qua silk edges với confidence decay
	visited := map[string]float64{} // addr → best confidence đã thấy
	queue := make([]*ScoredNode, len(res.DirectMatches))
	copy(queue, res.DirectMatches)

	for _, sn := range queue {
		visited[sn.Node.Addr.String()] = sn.Confidence
	}

	for len(queue) > 0 {
		curr := queue[0]
		queue = queue[1:]

		if curr.HopCount >= MaxHops {
			continue
		}

		nextConf := curr.Confidence * ConfidenceDecay
		if nextConf < MinConfidence {
			continue
		}

		// Walk tất cả outgoing edges từ curr.Node
		for _, triple := range r.graph.AllEdges() {
			fromAddr, ok1 := triple[0].(isl.Address)
			toAddr, ok2 := triple[1].(isl.Address)
			op, ok3 := triple[2].(EdgeOp)
			if !ok1 || !ok2 || !ok3 {
				continue
			}
			if fromAddr != curr.Node.Addr {
				continue
			}

			target, ok := r.graph.Get(toAddr)
			if !ok {
				continue
			}

			targetKey := toAddr.String()
			if prev, found := visited[targetKey]; found && prev >= nextConf {
				continue // đã thăm với confidence tốt hơn
			}
			visited[targetKey] = nextConf

			// Điều chỉnh confidence theo loại edge
			adjConf := nextConf * edgeConfidenceMultiplier(op)

			step := ReasonStep{
				FromAddr:   curr.Node.Addr,
				FromName:   curr.Node.Name,
				FromGlyph:  curr.Node.Glyph,
				Op:         op,
				ToAddr:     toAddr,
				ToName:     target.Name,
				ToGlyph:    target.Glyph,
				ToCategory: target.Cat,
				ToDNA:      target.DNA,
				Confidence: adjConf,
				Hop:        curr.HopCount + 1,
			}
			res.Path = append(res.Path, step)

			next := &ScoredNode{
				Node:       target,
				Confidence: adjConf,
				Source:     fmt.Sprintf("silk_hop_%d", curr.HopCount+1),
				HopCount:   curr.HopCount + 1,
			}
			queue = append(queue, next)
		}
	}

	// Bước 4: thu thập kết luận — tất cả nodes đã thấy, sort by confidence
	confidenceMap := map[string]*ScoredNode{}
	for _, sn := range res.DirectMatches {
		confidenceMap[sn.Node.Addr.String()] = sn
	}
	for _, step := range res.Path {
		key := step.ToAddr.String()
		node, ok := r.graph.Get(step.ToAddr)
		if !ok {
			continue
		}
		if existing, found := confidenceMap[key]; !found || step.Confidence > existing.Confidence {
			src := fmt.Sprintf("silk_hop_%d", step.Hop)
			if node.Cat == "concept" {
				src = "concept"
			}
			confidenceMap[key] = &ScoredNode{
				Node:       node,
				Confidence: step.Confidence,
				Source:     src,
				HopCount:   step.Hop,
			}
		}
	}

	for _, sn := range confidenceMap {
		res.Conclusions = append(res.Conclusions, sn)
	}

	// Sort by confidence desc
	sort.Slice(res.Conclusions, func(i, j int) bool {
		return res.Conclusions[i].Confidence > res.Conclusions[j].Confidence
	})

	if len(res.Conclusions) > 0 {
		res.TopConfidence = res.Conclusions[0].Confidence
	}

	return res
}

// ── Format — câu tiếng Việt tự nhiên từ ReasonResult ─────────

// FormatVI trả về câu giải thích tiếng Việt
// Theo đúng triết lý: "không lưu hình dạng, lưu công thức"
func (rr *ReasonResult) FormatVI() string {
	if rr == nil || (len(rr.DirectMatches) == 0 && len(rr.Conclusions) == 0) {
		return ""
	}

	var sb strings.Builder

	// Direct matches — ký tự đã biết
	if len(rr.DirectMatches) > 0 {
		sb.WriteString(fmt.Sprintf("**\"%s\"** — ", rr.Input))
		parts := make([]string, 0, len(rr.DirectMatches))
		for _, sn := range rr.DirectMatches {
			n := sn.Node
			part := fmt.Sprintf("**%s** (%s)", n.Glyph, n.Name)
			if n.DNA != "" {
				// Có SDF formula — đây là điểm mấu chốt
				part += fmt.Sprintf("\n  ```\n  SDF: %s\n  ```", trimDNA(n.DNA))
			}
			parts = append(parts, part)
		}
		sb.WriteString(strings.Join(parts, " · "))
		sb.WriteString("\n\n")
	}

	// Silk path — chuỗi suy luận (tối đa 5 bước đáng chú ý)
	notablePaths := filterNotablePaths(rr.Path)
	if len(notablePaths) > 0 {
		sb.WriteString("**Suy luận qua silk:**\n")
		for _, step := range notablePaths {
			sb.WriteString(fmt.Sprintf("  %s %s **%s** — *%s* _(%.0f%%)_\n",
				step.FromGlyph, edgeSymbol(step.Op),
				step.ToGlyph, step.ToName,
				step.Confidence*100))
		}
		sb.WriteString("\n")
	}

	// Top conclusions — kết luận có confidence cao nhất
	topN := 3
	if len(rr.Conclusions) < topN {
		topN = len(rr.Conclusions)
	}
	if topN > 0 {
		sb.WriteString("**Kết luận:**\n")
		for _, sn := range rr.Conclusions[:topN] {
			n := sn.Node
			line := fmt.Sprintf("  → **%s** %s _(conf: %.0f%%)_",
				n.Glyph, n.Name, sn.Confidence*100)
			if n.DNA != "" && sn.Confidence > 0.5 {
				line += fmt.Sprintf("\n    `%s`", trimDNA(n.DNA))
			}
			sb.WriteString(line + "\n")
		}
	}

	return sb.String()
}

// FormatCharDetail — format chi tiết 1 ký tự với SDF nổi bật
func FormatCharDetail(n *OlangNode) string {
	if n == nil {
		return ""
	}
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("**%s** — *%s*\n\n", n.Glyph, n.Name))

	// SDF — cái quan trọng nhất: "không lưu hình dạng, lưu công thức"
	if n.DNA != "" {
		sdfPart := n.DNA
		conceptPart := ""
		if idx := strings.Index(n.DNA, "// world:"); idx >= 0 {
			sdfPart = strings.TrimSpace(n.DNA[:idx])
			conceptPart = strings.TrimSpace(n.DNA[idx+9:])
		}
		if sdfPart != "" {
			sb.WriteString(fmt.Sprintf("```\nSDF glyph: %s\n```\n", sdfPart))
		}
		if conceptPart != "" {
			sb.WriteString(fmt.Sprintf("🌍 World SDF: `%s`\n\n", conceptPart))
		}
	}

	// Script + ISL
	if n.Cat != "" {
		sb.WriteString(fmt.Sprintf("📜 *%s* · ISL: `%s`\n", n.Cat, n.Addr.String()))
	}

	return sb.String()
}

// ── helpers ───────────────────────────────────────────────────

// findByGlyph tìm tất cả nodes có glyph hoặc name khớp với rune ch
func (r *SilkReasoner) findByGlyph(ch rune) []*OlangNode {
	glyph := string(ch)
	var results []*OlangNode

	for _, n := range r.graph.AllNodes() {
		if n.Glyph == glyph {
			results = append(results, n)
			continue
		}
		// Match codepoint hex trong Name
		cpHex := fmt.Sprintf("%04X", ch)
		if strings.Contains(n.Name, "U+"+cpHex) || strings.Contains(n.Name, cpHex) {
			results = append(results, n)
		}
	}
	return results
}

// edgeConfidenceMultiplier — trọng số của từng loại edge
// Edge ≡ (equivalence) đáng tin nhất, edge → (produces) ít tin hơn
func edgeConfidenceMultiplier(op EdgeOp) float64 {
	switch op {
	case OpEquiv:
		return 1.0  // A ≡ α — bản chất giống hệt
	case OpPhonetic:
		return 0.95 // A ♫ /a/ — cùng âm, rất đáng tin
	case OpSimilar:
		return 0.90 // ≈ tương đồng
	case OpMember:
		return 0.85 // ∈ phân loại — vẫn đáng tin
	case OpCompose:
		return 0.80 // ∘ kết hợp — ít chắc hơn
	default:
		return 0.75
	}
}

// edgeSymbol trả về ký tự biểu diễn
func edgeSymbol(op EdgeOp) string {
	switch op {
	case OpEquiv:
		return "≡"
	case OpSimilar:
		return "≈"
	case OpCompose:
		return "∘"
	case OpMember:
		return "∈"
	case OpPhonetic:
		return "♫"
	default:
		return "→"
	}
}

// filterNotablePaths lọc các bước đáng chú ý: concept nodes + high confidence
func filterNotablePaths(path []ReasonStep) []ReasonStep {
	var notable []ReasonStep
	seen := map[string]bool{}
	for _, step := range path {
		if step.Confidence < 0.30 {
			continue
		}
		key := step.ToAddr.String()
		if seen[key] {
			continue
		}
		seen[key] = true
		// Ưu tiên: concept nodes, nodes có DNA (SDF formula), hop 1
		if step.ToCategory == "concept" || step.ToDNA != "" || step.Hop == 1 {
			notable = append(notable, step)
		}
		if len(notable) >= 5 {
			break
		}
	}
	return notable
}

func trimDNA(dna string) string {
	// Bỏ comment "// world:..."
	if idx := strings.Index(dna, "//"); idx >= 0 {
		dna = strings.TrimSpace(dna[:idx])
	}
	if len([]rune(dna)) > 80 {
		runes := []rune(dna)
		return string(runes[:77]) + "..."
	}
	return dna
}

// Confidence returns confidence as percentage string
func (rr *ReasonResult) ConfidencePct() string {
	return fmt.Sprintf("%.0f%%", rr.TopConfidence*100)
}

// HasResult kiểm tra có kết quả thực sự không
func (rr *ReasonResult) HasResult() bool {
	return rr != nil && (len(rr.DirectMatches) > 0 || len(rr.Conclusions) > 0)
}

// BestNode trả về node có confidence cao nhất
func (rr *ReasonResult) BestNode() *OlangNode {
	if !rr.HasResult() {
		return nil
	}
	if len(rr.Conclusions) > 0 {
		return rr.Conclusions[0].Node
	}
	if len(rr.DirectMatches) > 0 {
		return rr.DirectMatches[0].Node
	}
	return nil
}

// PathSummary tóm tắt ngắn của chuỗi suy luận
func (rr *ReasonResult) PathSummary() string {
	if len(rr.DirectMatches) == 0 {
		return "không tìm thấy ký tự quen"
	}
	var glyphs []string
	for _, sn := range rr.DirectMatches {
		glyphs = append(glyphs, sn.Node.Glyph)
	}
	hops := 0
	for _, step := range rr.Path {
		if step.Hop > hops {
			hops = step.Hop
		}
	}
	return fmt.Sprintf("%s → %d bước silk → %d kết luận",
		strings.Join(glyphs, ""), hops, len(rr.Conclusions))
}

// TopConcepts trả về các concept nodes có confidence cao nhất
func (rr *ReasonResult) TopConcepts(n int) []*ScoredNode {
	var concepts []*ScoredNode
	for _, sn := range rr.Conclusions {
		if sn.Node.Cat == "concept" || sn.Node.DNA != "" {
			concepts = append(concepts, sn)
		}
		if len(concepts) >= n {
			break
		}
	}
	return concepts
}

// Verify tự kiểm chứng: path có consistent không?
// Dùng trong Dreaming cycle (QT7)
func (rr *ReasonResult) Verify() float64 {
	if len(rr.Path) < 2 {
		return rr.TopConfidence
	}

	// Kiểm tra confidence có giảm dần đúng 0.85/hop không
	consistent := 0
	for i := 1; i < len(rr.Path); i++ {
		if rr.Path[i].Confidence <= rr.Path[i-1].Confidence {
			consistent++
		}
	}
	decay := float64(consistent) / float64(len(rr.Path)-1)

	// Kiểm tra circular reasoning (path quay lại node cũ)
	seenAddrs := map[string]int{}
	loops := 0
	for _, step := range rr.Path {
		key := step.ToAddr.String()
		seenAddrs[key]++
		if seenAddrs[key] > 1 {
			loops++
		}
	}
	loopPenalty := math.Min(0.5, float64(loops)*0.1)

	return rr.TopConfidence * decay * (1 - loopPenalty)
}

// dnaField trích giá trị field từ DNA format "field=value|field2=value2"
func dnaField(dna, field string) string {
	prefix := field + "="
	for _, part := range strings.Split(dna, "|") {
		if strings.HasPrefix(part, prefix) {
			return strings.TrimSpace(part[len(prefix):])
		}
	}
	return ""
}
