// internal/ws/node_lookup.go
//
// NodeLookup — chỉ mục và dò tìm đúng thiết kế Silk Web Tree:
//
//   Tìm kiếm = đến đúng địa chỉ lá O(1) → đi theo sợi tơ (BFS)
//   Không bao giờ scan toàn bộ cây.
//
// Label và desc đọc từ DNA của node trong homeos.olang:
//   DNA format: "label=...|desc=...|vi=alias1,alias2"
// Không còn nodeTable hardcode trong Go.

package ws

import (
	"encoding/binary"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"fmt"
	"os"
	"strings"
	"sync"
)

// KnownNode — 1 node đã biết từ homeos.olang
type KnownNode struct {
	Name    string
	LayerID uint8
	ISL     [8]byte  // địa chỉ ISL thật — dùng để walk edges
	ISLU    uint64   // ISL dạng uint64 — key cho O(1) lookup
	Label   string   // tên tiếng Việt
	Desc    string   // mô tả
	Aliases []string // vi aliases tìm kiếm thêm
	POS     uint8    // Part of Speech theo origin.md — 0=unknown
	//   1=noun(꜈)  2=verb(꜉)  3=adj(꜊)  4=adv(꜋)
	//   5=pronoun1(◔)  6=pronoun2(◕)  7=pronoun3(◑)
}

// NodeLookup — index O(1) theo ISL và label
type NodeLookup struct {
	mu       sync.RWMutex
	olang    string
	raw      []byte               // cache toàn bộ file — không đọc lại mỗi query
	byISLU   map[uint64]*KnownNode
	byLabel  map[string]*KnownNode
	byName   map[string]*KnownNode
	adjCache map[uint64][]*SilkHop // cache adjacency depth=1 cho BFS
	tokIdx   tokenIndex               // inverted index token → nodes
}

func NewNodeLookup(olangPath string) *NodeLookup {
	nl := &NodeLookup{
		olang:    olangPath,
		byISLU:   make(map[uint64]*KnownNode),
		byLabel:  make(map[string]*KnownNode),
		byName:   make(map[string]*KnownNode),
		adjCache: make(map[uint64][]*SilkHop),
	}
	nl.build()
	nl.buildAdjCache()
	nl.buildTokenIndex()
	return nl
}

// build — đọc tất cả L1–L6 nodes, index theo ISL và label
// Tự động detect V18 (inline name) vs V19 (NamesTable riêng).
func (nl *NodeLookup) build() {
	raw, err := os.ReadFile(nl.olang)
	if err != nil { return }
	nl.raw = raw // cache cho buildAdjCache

	nedgesX  := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }

	// Detect V18 vs V19
	fileVersion := binary.BigEndian.Uint16(raw[4:6])
	isV19 := fileVersion >= 19

	// V19: load NamesTable để lookup name theo ISL
	var namesTable *olang.NamesTable
	if isV19 {
		namesTable = nl.loadNamesTable(raw, edgeStart)
	}

	// Helper: lấy name cho 1 node (V18: inline, V19: từ NamesTable)
	getName := func(isl8 [8]byte, inlineName string) string {
		if isV19 && namesTable != nil {
			islu := binary.BigEndian.Uint64(isl8[:])
			return namesTable.Get(islu)
		}
		return inlineName
	}

	// Scan nodes
	hdrSize := olang.NodeHeaderSizeV18
	if isV19 { hdrSize = olang.NodeHeaderSizeV19 }

	for off := 0; off+hdrSize <= edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		base := off
		if off+hdrSize > len(raw) { break }

		lid  := raw[off+2]
		isl8 := [8]byte{}; copy(isl8[:], raw[off+3:off+11])
		// off+11..14 = cp (4B) — bỏ qua ở đây
		dl := int(binary.BigEndian.Uint32(raw[off+15 : off+19]))

		var dnaStart, nameLen int
		var inlineName string

		if isV19 {
			// V19: không có nameLen
			if dl < 0 || dl > 65536 { off++; continue }
			dnaStart = off + olang.NodeHeaderSizeV19
			nameLen  = 0
		} else {
			// V18: có nameLen(1)
			if off+20 > len(raw) { break }
			nameLen  = int(raw[off+19])
			if dl > 65536 || nameLen > 255 { off++; continue }
			dnaStart = off + olang.NodeHeaderSizeV18
		}

		end := dnaStart + dl + nameLen
		if end > len(raw) { off = base + 1; continue }
		if dl > 65536 { off = end; continue }

		dna := string(raw[dnaStart : dnaStart+dl])
		if !isV19 {
			inlineName = string(raw[dnaStart+dl : end])
		}
		name := getName(isl8, inlineName)
		off = end

		// L0: skip, L7: skip
		if lid == 0 || lid == 7 { continue }

		txt := dnaText(dna)
		if !strings.Contains(txt, "label=") { continue }

		p     := parseDNAKV(txt)
		label := p["label"]
		if label == "" { continue }

		islu := binary.BigEndian.Uint64(isl8[:])
		node := &KnownNode{
			Name:    name,
			LayerID: lid,
			ISL:     isl8,
			ISLU:    islu,
			Label:   label,
			Desc:    p["desc"],
			Aliases: append(splitComma(p["vi"]), splitComma(p["en"])...),
			POS:     inferPOSByName(name, lid, isl8[1], p["pos"]),
		}
		nl.byISLU[islu] = node
		if name != "" { nl.byName[name] = node }

		// L1 UTF32: chỉ index byISLU/byName, không byLabel
		if lid == 1 { continue }

		nl.byLabel[normVI(label)] = node
		for _, a := range node.Aliases {
			if a == "" { continue }
			aR := []rune(a)
			isAcronym := len(aR) >= 2 && strings.ToUpper(a) == a && !strings.Contains(a, " ")
			if len(aR) >= 5 || len(strings.Fields(a)) >= 2 || isAcronym {
				nl.byLabel[normVI(a)] = node
			}
		}
	}
}

// loadNamesTable — đọc NamesTable từ raw bytes (V19)
// Fast path: offset tại header[28:32]. Fallback: scan ngược.
func (nl *NodeLookup) loadNamesTable(raw []byte, edgeStart int) *olang.NamesTable {
	if len(raw) >= 32 {
		offset := int(binary.BigEndian.Uint32(raw[28:32]))
		if offset > 280 && offset < edgeStart && offset+6 <= len(raw) {
			if raw[offset] == 'N' && raw[offset+1] == 'T' {
				t, consumed := olang.ParseNamesTable(raw[offset:])
				if consumed > 0 && offset+consumed <= edgeStart {
					return t
				}
			}
		}
	}
	// Fallback scan
	for start := edgeStart - 6; start >= 280; start-- {
		if start+2 > len(raw) { continue }
		if raw[start] != 'N' || raw[start+1] != 'T' { continue }
		t, consumed := olang.ParseNamesTable(raw[start:])
		if consumed > 0 && start+consumed == edgeStart {
			return t
		}
	}
	return olang.NewNamesTable()
}

// GetAllL3 — trả về tối đa n L3 nodes từ byISLU (cho quiz random)
func (nl *NodeLookup) GetAllL3(n int) []*KnownNode {
	nl.mu.RLock(); defer nl.mu.RUnlock()
	var result []*KnownNode
	for _, node := range nl.byISLU {
		if node.LayerID == 3 && node.Desc != "" {
			result = append(result, node)
			if len(result) >= n { break }
		}
	}
	return result
}

// DomainLabel — trả về nhãn domain cho node theo prefix
func (nl *NodeLookup) DomainLabel(name string) string {
	type pp struct{ prefix, phrase string }
	domains := []pp{
		{"CS_","khoa học máy tính"},{"AI2_","trí tuệ nhân tạo"},
		{"BIO","sinh học"},{"PHYS","vật lý"},{"CHEM","hóa học"},
		{"MATH","toán học"},{"MED","y tế"},{"TECH","công nghệ"},
		{"VN","Việt Nam"},{"ECON","kinh tế"},{"HIST","lịch sử"},
		{"ENV","môi trường"},{"SOC","xã hội"},{"PHIL","triết học"},
		{"ASTRO","thiên văn"},{"GEO","địa lý"},{"FOOD","ẩm thực"},
	}
	for _, d := range domains {
		if strings.HasPrefix(name, d.prefix) { return d.phrase }
	}
	return "tri thức"
}


// SearchExact — tìm node có label BẰNG ĐÚNG query (không word-boundary fuzzy)
// Ưu tiên L3 nodes để tránh last-write-wins vấn đề với alias trùng
func (nl *NodeLookup) SearchExact(query string) *KnownNode {
	nl.mu.RLock(); defer nl.mu.RUnlock()
	q := normVI(query)
	// Tìm tất cả candidates có label == q, bao gồm scan byName
	var candidates []*KnownNode
	seen := map[uint64]bool{}
	for _, node := range nl.byISLU {
		if normVI(node.Label) == q {
			candidates = append(candidates, node)
			seen[node.ISLU] = true
		}
	}

	// Cũng tìm qua aliases trong byLabel (để catch alias exact match)
	if n, ok := nl.byLabel[q]; ok && !seen[n.ISLU] {
		candidates = append(candidates, n)
	}
	if len(candidates) == 0 { return nil }
	// Ưu tiên L3 (domain node), rồi L2, rồi khác
	for _, n := range candidates { if n.LayerID == 3 && normVI(n.Label) == q { return n } }
	for _, n := range candidates { if n.LayerID == 3 { return n } }
	for _, n := range candidates { if n.LayerID == 2 { return n } }
	return candidates[0]
}


// Search — O(1) lookup theo label/alias, không scan
func (nl *NodeLookup) Search(query string) *KnownNode {
	nl.mu.RLock(); defer nl.mu.RUnlock()

	q := normVI(query)

	// 1. Exact match
	if n, ok := nl.byLabel[q]; ok { return n }

	// 2. Query chứa label như 1 cụm từ hoàn chỉnh (word-boundary aware)
	//    Ưu tiên label dài nhất match
	var best *KnownNode
	bestLen := 0
	qRunes := []rune(q)
	for lbl, node := range nl.byLabel {
		if len([]rune(lbl)) <= 1 { continue }
		if !strings.Contains(q, lbl) { continue }
		// Kiểm tra word boundary dùng rune index
		lblRunes := []rune(lbl)
		lbl2 := string(lblRunes)
		ri := runeIndex(qRunes, lblRunes)
		for ri >= 0 {
			before := ri == 0 || !isViWordChar(qRunes[ri-1])
			after  := ri+len(lblRunes) >= len(qRunes) || !isViWordChar(qRunes[ri+len(lblRunes)])
			if before && after && len(lblRunes) > bestLen {
				best = node
				bestLen = len(lblRunes)
				break
			}
			next := runeIndex(qRunes[ri+1:], lblRunes)
			if next < 0 { break }
			ri = ri + 1 + next
			_ = lbl2
		}
	}
	if best != nil { return best }

	// 3. Uppercase name fallback (e.g. "LIFE_CAT")
	if n, ok := nl.byName[strings.ToUpper(query)]; ok { return n }

	return nil
}

// SearchAndWalk — tìm node + BFS theo silk edges theo đúng thiết kế
// Trả về: node chính + danh sách related nodes theo sợi tơ
func (nl *NodeLookup) SearchAndWalk(query string, maxDepth int) (*KnownNode, []*SilkHop) {
	root := nl.Search(query)
	if root == nil { return nil, nil }
	hops := nl.walkSilk(root, maxDepth)
	return root, hops
}

// SilkHop — 1 bước đi theo sợi tơ
type SilkHop struct {
	Node     *KnownNode
	EdgeType uint8
	TypeSym  string
	Depth    int
}

// walkSilk — BFS theo silk edges từ node gốc
// Đúng thiết kế: "đến đúng địa chỉ lá → đi theo tơ"
func (nl *NodeLookup) walkSilk(root *KnownNode, maxDepth int) []*SilkHop {
	raw, err := os.ReadFile(nl.olang)
	if err != nil { return nil }
	if len(raw) < 20 { return nil }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 { return nil }

	// Build edge map: srcISLU → []{ dstISLU, type }
	type edge struct{ dst uint64; typ uint8 }
	edgeMap := map[uint64][]edge{}
	for i := 0; i < nedges; i++ {
		o := edgeStart + i*olang.EdgeSize
		if o+17 > len(raw) { break }
		src := binary.BigEndian.Uint64(raw[o : o+8])
		dst := binary.BigEndian.Uint64(raw[o+8 : o+16])
		typ := raw[o+16]
		edgeMap[src] = append(edgeMap[src], edge{dst, typ})
	}

	nl.mu.RLock()
	defer nl.mu.RUnlock()

	// BFS
	type qItem struct{ islu uint64; depth int }
	visited := map[uint64]bool{root.ISLU: true}
	queue := []qItem{{root.ISLU, 0}}
	var hops []*SilkHop

	for len(queue) > 0 && len(hops) < 12 {
		cur := queue[0]; queue = queue[1:]
		if cur.depth >= maxDepth { continue }

		for _, e := range edgeMap[cur.islu] {
			if visited[e.dst] { continue }
			visited[e.dst] = true
			node, ok := nl.byISLU[e.dst]
			if !ok { continue }
			hops = append(hops, &SilkHop{
				Node:     node,
				EdgeType: e.typ,
				TypeSym:  edgeSymbol(e.typ),
				Depth:    cur.depth + 1,
			})
			queue = append(queue, qItem{e.dst, cur.depth + 1})
		}
	}
	return hops
}

// Format — câu trả lời markdown cho 1 node
func (nl *NodeLookup) Format(node *KnownNode) string {
	layer := map[uint8]string{
		2: "🌿 Tự nhiên", 3: "🦋 Sinh vật",
		4: "🏠 Vật thể",  6: "👁 Cảm nhận",
	}[node.LayerID]
	if layer == "" { layer = fmt.Sprintf("L%d", node.LayerID) }
	return fmt.Sprintf("**%s** _%s_\n\n%s\n\n`%s`",
		node.Label, layer, node.Desc, node.Name)
}

// FormatWithSilk — node chính + các node liên kết theo sợi tơ
func (nl *NodeLookup) FormatWithSilk(node *KnownNode, hops []*SilkHop) string {
	base := nl.Format(node)
	if len(hops) == 0 { return base }
	var parts []string
	for _, h := range hops {
		parts = append(parts, fmt.Sprintf("%s **%s**", h.TypeSym, h.Node.Label))
	}
	return base + "\n\n_Liên quan: " + strings.Join(parts, " · ") + "_"
}

// EdgeInfo — giữ lại cho /api/edges compatibility
type EdgeInfo struct {
	DstName  string
	DstLabel string
	Type     uint8
	TypeName string
}

// WalkEdges — giữ lại cho backward compat (dùng walkSilk thay thế)
func (nl *NodeLookup) WalkEdges(nodeISL [8]byte) []EdgeInfo {
	islu := binary.BigEndian.Uint64(nodeISL[:])
	nl.mu.RLock()
	root, ok := nl.byISLU[islu]
	nl.mu.RUnlock()
	if !ok { return nil }
	hops := nl.walkSilk(root, 1)
	var out []EdgeInfo
	for _, h := range hops {
		out = append(out, EdgeInfo{
			DstName:  h.Node.Name,
			DstLabel: h.Node.Label,
			Type:     h.EdgeType,
			TypeName: h.TypeSym,
		})
	}
	return out
}

// WalkIncoming — tìm edges ngược
func (nl *NodeLookup) WalkIncoming(nodeISL [8]byte) []EdgeInfo {
	raw, err := os.ReadFile(nl.olang)
	if err != nil { return nil }
	if len(raw) < 20 { return nil }
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - 32 - nedges*olang.EdgeSize // trừ 32 bytes SHA256 cuối file
	if edgeStart < 280 { return nil }

	dstU := binary.BigEndian.Uint64(nodeISL[:])
	nl.mu.RLock(); defer nl.mu.RUnlock()

	var out []EdgeInfo
	for i := 0; i < nedges; i++ {
		o := edgeStart + i*olang.EdgeSize
		if o+17 > len(raw) { break }
		src := binary.BigEndian.Uint64(raw[o : o+8])
		dst := binary.BigEndian.Uint64(raw[o+8 : o+16])
		typ := raw[o+16]
		if dst != dstU { continue }
		node, ok := nl.byISLU[src]
		if !ok { continue }
		out = append(out, EdgeInfo{
			DstName:  node.Name,
			DstLabel: node.Label,
			Type:     typ,
			TypeName: edgeSymbol(typ),
		})
	}
	return out
}

// FormatFull — format node + outgoing + incoming (compat)
func (nl *NodeLookup) FormatFull(node *KnownNode, nodeISL [8]byte) string {
	_, hops := nl.SearchAndWalk(node.Label, 2)
	base := nl.FormatWithSilk(node, hops)
	in := nl.WalkIncoming(nodeISL)
	if len(in) == 0 { return base }
	var parts []string
	for _, e := range in {
		parts = append(parts, fmt.Sprintf("← **%s**", e.DstLabel))
	}
	return base + " · " + strings.Join(parts, " · ")
}

// ── helpers ────────────────────────────────────────────────────

// isViWordChar — ký tự thuộc từ (Latin, Vietnamese, digit)
func isViWordChar(r rune) bool {
	return (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') ||
		(r >= '0' && r <= '9') || r > 127
}

// edgeLabel returns (symbol, Vietnamese phrase) for edge type byte
func edgeLabel(t uint8) (string, string) {
	type el struct{ sym, phrase string }
	m := map[uint8]el{
		1:  {"⊆", "là loại"},
		2:  {"∈", "thuộc về"},
		3:  {"≈", "liên quan đến"},
		4:  {"→", "gây ra / là thành viên"},
		5:  {"↪", "sử dụng"},
		6:  {"⇒", "tạo ra"},
		7:  {"⊃", "chứa"},
		8:  {"↻", "bơm / quay quanh"},
		9:  {"↑", "oxy hóa / liên kết"},
		10: {"⇌", "điều khiển"},
		11: {"←", "được tạo bởi"},
		12: {"∈", "là thành phần"},
		13: {"✓", "huấn luyện"},
		14: {"⚡", "kích hoạt"},
		15: {"💊", "điều trị"},
		16: {"🔧", "can thiệp"},
		17: {"✏", "chỉnh sửa"},
		18: {"🛡", "duy trì"},
		19: {"🧠", "bắt nguồn từ"},
		20: {"🌿", "nuôi dưỡng"},
		21: {"⊢", "hình thức hóa"},
		22: {"🔍", "tìm kiếm"},
		23: {"👁", "nghiên cứu"},
		24: {"≺", "đứng trước"},
		25: {"❓", "vấn đề của"},
		26: {"⊆", "áp dụng"},
		27: {"🧬", "bén rễ từ"},
		28: {"⊢", "nền tảng của"},
		29: {"✓", "xác minh bởi"},
		30: {"≈", "tương tự"},
		31: {"≠", "đối lập"},
		32: {"📐", "biểu diễn bởi"},
		33: {"📈", "mô tả bởi"},
		34: {"=", "biểu đạt trong"},
		35: {"←", "dẫn xuất từ"},
	}
	if e, ok := m[t]; ok { return e.sym, e.phrase }
	return "~", "liên kết với"
}

func edgeSymbol(t uint8) string {
	sym, _ := edgeLabel(t)
	return sym
}

func normVI(s string) string {
	return strings.ToLower(strings.TrimSpace(s))
}

// POS constants theo origin.md Phần III
const (
	POSUnknown  uint8 = 0
	POSNoun     uint8 = 1  // ꜈ U+A708 — danh từ
	POSVerb     uint8 = 2  // ꜉ U+A709 — động từ
	POSAdj      uint8 = 3  // ꜊ U+A70A — tính từ
	POSAdv      uint8 = 4  // ꜋ U+A70B — trạng từ
)

// posSymbol — ký hiệu Unicode theo origin.md
func posSymbol(pos uint8) string {
	switch pos {
	case POSNoun: return "꜈"  // U+A708
	case POSVerb: return "꜉"  // U+A709
	case POSAdj:  return "꜊"  // U+A70A
	case POSAdv:  return "꜋"  // U+A70B
	}
	return ""
}

// inferPOS — xác định Part of Speech từ layer/group/DNA/name
// Nếu DNA có pos= thì dùng, không thì infer từ bản chất node
func inferPOS(layer, group uint8, posField string) uint8 {
	// DNA pos= field (explicit)
	switch posField {
	case "noun", "n": return POSNoun
	case "verb", "v": return POSVerb
	case "adj",  "a": return POSAdj
	case "adv",  "d": return POSAdv
	}
	// Infer từ layer + group (QT4: bản chất quyết định)
	switch layer {
	case 2: // Nature — hiện tượng, lực → noun
		return POSNoun
	case 3: // Life
		switch group {
		case 1, 2, 3: return POSNoun  // sinh vật, động vật, thực vật
		case 4:        return POSNoun  // bộ phận cơ thể
		case 5:        return POSNoun  // cảm xúc (danh từ: "nỗi sợ hãi")
		case 6:        return POSVerb  // hành động: chạy, ăn, ngủ
		case 7:        return POSNoun  // khái niệm xã hội
		}
	case 4: // Objects — vật thể → noun
		return POSNoun
	case 5: // Programming — khái niệm → noun
		return POSNoun
	case 6: // Perception
		switch group {
		case 1: return POSNoun  // màu sắc: "màu đỏ"
		case 2: return POSNoun  // âm thanh: "tiếng ồn"
		case 3: return POSAdj   // cảm giác nhiệt/xúc: nóng, lạnh, mềm, cứng
		case 4: return POSAdj   // vị/mùi: ngọt, đắng, thơm
		case 5: return POSAdj   // kích thước/tốc độ: to, nhỏ, nhanh, chậm
		}
	}
	return POSUnknown
}

// inferPOSByName — xác định POS từ tên node (reliable hơn group byte từ ISL)
func inferPOSByName(name string, layer, group uint8, posField string) uint8 {
	// DNA pos= field (explicit — ưu tiên cao nhất)
	switch posField {
	case "noun", "n": return POSNoun
	case "verb", "v": return POSVerb
	case "adj",  "a": return POSAdj
	case "adv",  "d": return POSAdv
	}

	// L3 Life — phân biệt noun vs verb theo tên node
	if layer == 3 {
		lifeVerbs := map[string]bool{
			"LIFE_RUN":     true, "LIFE_EAT":     true, "LIFE_SLEEP":  true,
			"LIFE_WALK":    true, "LIFE_THINK":   true, "LIFE_LEARN":  true,
			"LIFE_BREATHE": true, "LIFE_TALK":    true, "LIFE_AWAKE":  true,
		}
		if lifeVerbs[name] { return POSVerb }
		return POSNoun // emotions, animals, body parts = noun
	}

	// L6 Perception — adj vs noun theo prefix
	if layer == 6 {
		adjPrefixes := []string{
			"PERCEPT_HOT", "PERCEPT_COLD", "PERCEPT_WARM", "PERCEPT_FRESH",
			"PERCEPT_BRIGHT", "PERCEPT_DARK", "PERCEPT_LOUD", "PERCEPT_QUIET",
			"PERCEPT_FAST", "PERCEPT_SLOW", "PERCEPT_BIG", "PERCEPT_SMALL",
			"PERCEPT_HARD", "PERCEPT_SOFT", "PERCEPT_SMOOTH", "PERCEPT_ROUGH",
			"PERCEPT_SHARP", "PERCEPT_HEAVY", "PERCEPT_NEAR", "PERCEPT_FAR",
			"PERCEPT_CLEAN", "PERCEPT_DIRTY", "PERCEPT_SWEET", "PERCEPT_BITTER",
			"PERCEPT_SALTY", "PERCEPT_SOUR", "PERCEPT_FRAGRANT",
			"PERCEPT_AWAKE", "PERCEPT_TIRED", "PERCEPT_FRESH", "PERCEPT_PAIN",
		}
		for _, p := range adjPrefixes {
			if name == p { return POSAdj }
		}
		return POSNoun // colors, sounds = noun
	}

	// L2 Nature, L4 Objects, L5 Programming → noun
	return POSNoun
}

func splitComma(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		if t := strings.TrimSpace(p); t != "" { out = append(out, t) }
	}
	return out
}


// ── NaturalSentence — tổng hợp câu tiếng Việt từ node + silk hops ──────────
// QT6: ISL = vô hình (ý nghĩa) → SDF = hữu hình (câu chữ)
// Đây là bước cuối: chuyển tri thức → ngôn ngữ tự nhiên

// NaturalSentence trả về câu giải thích tự nhiên tiếng Việt
func (nl *NodeLookup) NaturalSentence(node *KnownNode, hops []*SilkHop) string {
	if node == nil { return "" }

	label := node.Label
	desc  := node.Desc
	layer := node.LayerID
	group := node.ISL[1] // group byte = bản chất nhóm

	// Mở đầu theo tầng, nhóm và POS
	var opening string
	if node.POS == POSVerb {
		// Verb: "chạy là hành động..." → thêm ký hiệu ꜉
		opening = fmt.Sprintf("꜉ **%s**", label)
		if desc != "" {
			return opening + " — " + capFirst(desc) + nl.silkContext(label, hops)
		}
	} else if node.POS == POSAdj {
		// Adj: "nóng bức", "lạnh buốt" → thêm ký hiệu ꜊
		opening = fmt.Sprintf("꜊ **%s**", label)
	} else {
		opening = layerGroupOpening(node.Name, label, layer, group)
	}

	// Thân: desc
	body := ""
	if desc != "" {
		body = ". " + capFirst(desc)
	}

	// Silk: context từ edges — xuống dòng mới
	silk := nl.silkContext(label, hops)

	// "Xem thêm" — liệt kê related nodes từ hops (tối đa 3 node khác loại)
	seeAlso := nl.buildSeeAlso(node, hops)
	return opening + body + silk + seeAlso
}

// NaturalExplain — trả lời câu hỏi "tại sao / như thế nào / giải thích"
func (nl *NodeLookup) NaturalExplain(node *KnownNode, hops []*SilkHop, question string) string {
	if node == nil { return "" }
	label := node.Label
	desc  := node.Desc

	// Xác định loại câu hỏi
	q := strings.ToLower(question)
	isTaiSao   := strings.Contains(q, "tại sao") || strings.Contains(q, "vì sao") || strings.Contains(q, "why")
	isNhTheNao := strings.Contains(q, "như thế nào") || strings.Contains(q, "thế nào") || strings.Contains(q, "how")
	isGiNghia  := strings.Contains(q, "nghĩa là") || strings.Contains(q, "có nghĩa") || strings.Contains(q, "what")
	isCoKhong  := strings.Contains(q, "có không") || strings.Contains(q, "có phải") || strings.Contains(q, "is ")

	// Tìm nodes liên quan qua silk
	relatedByType := map[uint8][]string{} // edgeType → labels
	for _, h := range hops {
		if h.Node != nil {
			relatedByType[h.EdgeType] = append(relatedByType[h.EdgeType], h.Node.Label)
		}
	}
	memberOf   := relatedByType[0x08] // ∈
	composes   := relatedByType[0x0A] // ∘
	opposite   := relatedByType[0x0D] // ⊥
	similar    := relatedByType[0x0C] // ≈

	switch {
	case isTaiSao:
		return explainTaiSao(label, desc, node.LayerID, node.ISL[1], memberOf, composes, opposite)
	case isNhTheNao:
		return explainNhTheNao(label, desc, composes, similar)
	case isGiNghia:
		return explainGiNghia(label, desc, memberOf)
	case isCoKhong:
		return explainCoKhong(label, desc, memberOf)
	default:
		// Câu hỏi chung — giải thích đầy đủ
		return explainGeneral(label, desc, node.LayerID, node.ISL[1], memberOf, composes, opposite, similar)
	}
}

// ── Các hàm sinh câu theo loại ───────────────────────────────────────────────

func layerGroupOpening(nodeName, label string, layer, group uint8) string {
	// Domain nodes với nodeName prefix → smartOpening ngay (ưu tiên cao)
	if nodeName != "" {
		domainPrefixes := []string{
			"PSY_","MED_","PHIL_","TECH_","ART_","ASTRO_",
			"ECON_","ENV_","CHEM_","PHYS_","MATH_","BIO_",
			"GEO_","HIST_","LANG_","PLANT_","MOL_",
			"SPORT_","FOOD_",
			"REL_","PLACE_",
			"MATL_","BUILD_",
			"ENERGY_","JOB_",
			"PH_","MICRO_",
			"OCEAN_","SPACE_",
			"AGR_","EDU_",
			"SOC_","TRANS_",
			"LAW_","DIG_",
			"NAT_","HIST2_",
			"ANAT_","LIT_",
			"CLIM_","ECON2_",
			"TECH2_","SPACE2_","AGR2_","PSYCH2_",
			"CULT_","ENRG2_","MATH2_","PHYS2_","MED2_",
			"BIO2_","PSY2_","GEO2_","SOC2_",
			"FINTECH_","ASTRO2_","NUTR_",
			"CS_","PHYS3_","CHEM2_","MATH3_","ARCH_","ANTH_","PHIL2_","ASTRO3_",
			"VN_","HLTH_","MICRO2_","NRG_","DESIGN_","MUSIC_","MEDIA_","ENV2_",
			"SPORT2_","TECH3_","ECON3_","BIO3_","GEO3_","PSYCH3_",
			"HEALTH2_","VNECON_","VNEDU_","VNHIST_","VNTRAVEL_","VNLIT_","VNENV_",
			"LING_","COG_","VNNATURE_","VNART_","VNFOOD_","SOC3_",
			"VNENERGY_","VNAGR_","VNINFRA_","POLINT_","ECON_THEORY_","NEURO_","ECO2_","APPPHYS_","CS_THEORY_","SOLAR_","PHYSGEO_","SDG_","SPACE3_","ARTWORLD_","LIT2_","SCI_","WORLD_","FUTURE_","ASEAN_","VNSPORT_","MOD_PHIL_","TRAD_MED_","DEMO_",
			"CS2_","AI2_","ECON4_","DIGITAL2_","EASPHIL_","SEC2_","MATER2_","PHYS4_",
			"WILD_","STAT_",
		}
		for _, p := range domainPrefixes {
			if strings.HasPrefix(nodeName, p) {
				return smartOpening(nodeName, label)
			}
		}
	}
	switch layer {
	case 2: // Nature
		switch group {
		case 1: return fmt.Sprintf("**%s** là một hiện tượng vật lý", label)
		case 2: return fmt.Sprintf("**%s** là một hiện tượng tự nhiên", label)
		case 3: return fmt.Sprintf("**%s** là khái niệm về không-thời gian", label)
		}
	case 3: // Life
		switch group {
		case 1: return fmt.Sprintf("**%s** là sinh vật sống", label)
		case 2: return fmt.Sprintf("**%s** là một loài động vật", label)
		case 3: return fmt.Sprintf("**%s** là một loài thực vật", label)
		case 4: return fmt.Sprintf("**%s** là bộ phận cơ thể", label)
		case 5: return fmt.Sprintf("**%s** là một cảm xúc", label)
		case 6: return fmt.Sprintf("**%s** là hành động sống cơ bản", label)
		case 7: return fmt.Sprintf("**%s** là khái niệm xã hội", label)
		}
	case 4: // Objects
		switch group {
		case 1: return fmt.Sprintf("**%s** là vật dụng trong nhà", label)
		case 2: return fmt.Sprintf("**%s** là thiết bị điện tử", label)
		case 3: return fmt.Sprintf("**%s** là phương tiện di chuyển", label)
		case 4: return fmt.Sprintf("**%s** là thức ăn/đồ uống", label)
		}
	case 5: // Programming / Concepts
		switch group {
		case 1: return fmt.Sprintf("**%s** là khái niệm AI/học máy", label)
		case 2: return fmt.Sprintf("**%s** là thành phần HomeOS", label)
		case 3: return fmt.Sprintf("**%s** là khái niệm hệ thống", label)
		default: return fmt.Sprintf("**%s** là khái niệm lập trình", label)
		}
	case 6: // Perception
		switch group {
		case 1: return fmt.Sprintf("**%s** là một màu sắc", label)
		case 2: return fmt.Sprintf("**%s** là âm thanh", label)
		case 3: return fmt.Sprintf("**%s** là cảm giác xúc giác/nhiệt", label)
		case 4: return fmt.Sprintf("**%s** là vị/mùi", label)
		case 5: return fmt.Sprintf("**%s** là thuộc tính kích thước/tốc độ", label)
		}
	}
	// Fallback thông minh: dựa theo nodeName prefix
	return smartOpening(nodeName, label)
}

// smartOpening trả về opening tự nhiên khi layerGroupOpening không match
// Dùng cho các domain mới: PSY_ MED_ PHIL_ TECH_ ART_ ASTRO_ ECON_ ENV_ CHEM_ PHYS_ MATH_
func smartOpening(nodeName, label string) string {
	// PLACE_ dùng placeOpening thông minh
	if strings.HasPrefix(nodeName, "PLACE_") {
		return placeOpening(nodeName, label)
	}
	type prefixPhrase struct{ prefix, phrase string }
	prefixes := []prefixPhrase{
		{"PSY_",   "khái niệm tâm lý học"},
		{"MED_",   "khái niệm y học"},
		{"PHIL_",  "khái niệm triết học"},
		{"TECH_",  "khái niệm công nghệ"},
		{"ART_",   "khái niệm nghệ thuật"},
		{"ASTRO_", "khái niệm thiên văn học"},
		{"ECON_",  "khái niệm kinh tế"},
		{"ENV_",   "khái niệm môi trường"},
		{"CHEM_",  "khái niệm hóa học"},
		{"PHYS_",  "khái niệm vật lý"},
		{"MATH_",  "khái niệm toán học"},
		{"BIO_",   "khái niệm sinh học"},
		{"GEO_",   "khái niệm địa lý"},
		{"HIST_",  "khái niệm lịch sử"},
		{"LANG_",  "khái niệm ngôn ngữ học"},
		{"SPORT_", "khái niệm thể thao"},
		{"FOOD_",  "khái niệm ẩm thực"},
		{"REL_",   "khái niệm tôn giáo/văn hóa"},
		{"PLACE_", "địa danh"},
		{"MATL_",  "vật liệu"},
		{"BUILD_", "công trình kiến trúc/xây dựng"},
		{"ENERGY_","nguồn năng lượng"},
		{"JOB_",   "nghề nghiệp"},
		{"PH_",    "khái niệm y tế công cộng"},
		{"MICRO_", "khái niệm kinh tế/tài chính"},
		{"OCEAN_", "khái niệm đại dương/biển"},
		{"AGR_",   "khái niệm nông nghiệp"},
		{"EDU_",   "khái niệm giáo dục"},
		{"SOC_",   "khái niệm xã hội"},
		{"TRANS_", "phương tiện/vận tải"},
		{"LAW_",   "khái niệm pháp luật"},
		{"DIG_",   "khái niệm công nghệ số"},
		{"NAT_",   "địa hình/tài nguyên tự nhiên"},
		{"HIST2_", "sự kiện lịch sử hiện đại"},
		{"ANAT_",  "cơ quan/bộ phận cơ thể"},
		{"LIT_",   "khái niệm văn học/ngôn ngữ"},
		{"CLIM_",  "khí hậu/môi trường chi tiết"},
		{"ECON2_", "kinh tế vĩ mô"},
		{"TECH2_", "công nghệ mới"},
		{"SPACE2_", "khám phá vũ trụ"},
		{"PSYCH2_", "sức khỏe tâm thần"},
		{"CULT_",  "văn hóa xã hội"},
		{"ENRG2_", "năng lượng tương lai"},
		{"MATH2_", "toán học nâng cao"},
		{"PHYS2_", "vật lý nâng cao"},
		{"MED2_",  "y tế/y khoa"},
		{"BIO2_",  "sinh học phân tử/gene"},
		{"PSY2_",  "tâm lý học"},
		{"GEO2_",  "địa lý/địa chất"},
		{"SOC2_",  "xã hội học"},
		{"FINTECH_","công nghệ tài chính"},
		{"ASTRO2_","thiên văn học nâng cao"},
		{"NUTR_",  "dinh dưỡng"},

		{"CS_",      "khoa học máy tính"},
		{"PHYS3_",   "vật lý chuyên ngành"},
		{"CHEM2_",   "hóa học chuyên ngành"},
		{"MATH3_",   "toán học chuyên ngành"},
		{"ARCH_",    "kiến trúc"},
		{"ANTH_",    "nhân học/khảo cổ"},
		{"PHIL2_",   "triết học"},
		{"ASTRO3_",  "thiên văn học"},
		{"VN_",      "văn hóa Việt Nam"},
		{"HLTH_",    "khoa học sức khỏe"},
		{"MICRO2_",  "kinh tế vi mô"},
		{"NRG_",     "năng lượng"},
		{"DESIGN_",  "thiết kế"},
		{"MUSIC_",   "âm nhạc"},
		{"MEDIA_",   "truyền thông"},
		{"ENV2_",    "ô nhiễm/môi trường"},
		{"SPORT2_",  "thể thao/sức khỏe"},
		{"TECH3_",   "công nghệ tương lai"},
		{"ECON3_",   "kinh tế/tài chính"},
		{"BIO3_",    "sinh học tiên tiến"},
		{"GEO3_",    "địa lý đô thị"},
		{"PSYCH3_",  "tâm lý học xã hội"},
		{"HEALTH2_",   "sức khỏe/y tế"},
		{"LING_",  "ngôn ngữ học"},
		{"VNENERGY_",  "năng lượng VN"},
		{"VNTECH_",  "công nghệ VN"},
		{"BUILD2_",  "kiến trúc & xây dựng"},
		{"ROBOTICS_",  "robot học"},
		{"PHYS5_",  "vật lý nâng cao"},
		{"MGMT_",  "quản trị"},
		{"PHIL3_",  "triết học nâng cao"},
		{"INNOV_",  "khởi nghiệp & đổi mới"},
		{"CIVHIST_",  "lịch sử văn minh"},
		{"VNSEA_",  "VN & Đông Nam Á"},
		{"VNMARINE_",  "biển VN"},
		{"EASTPHIL2_",  "triết học Đông Á 2"},
		{"FUTUREAGR_",  "nông nghiệp tương lai"},
		{"GREENCHEM_",  "hóa học xanh"},
		{"HEALTHTECH_",  "công nghệ y tế"},
		{"LOGIC_",  "đại số & logic"},
		{"SEACULTURE_",  "văn hóa ĐNA"},
		{"RADENER_",  "bức xạ & năng lượng"},
		{"PHILANG_",  "triết học ngôn ngữ"},
		{"DEVEL_ECON_",  "kinh tế phát triển"},
		{"BRAINAREA_",  "vùng não bộ"},
		{"MACRO2_",  "kinh tế vĩ mô 2"},
		{"MENTAL2_",  "tâm thần nâng cao"},
		{"SOFTSKILL_",  "kỹ năng mềm"},
		{"MIDEASTHIST_",  "lịch sử Trung Đông"},
		{"ECO3_",  "sinh thái nâng cao"},
		{"EXPPHYS_",  "vật lý thực nghiệm"},
		{"VNTECH2_",  "công nghệ VN 2"},
		{"SPACEAPP_",  "ứng dụng vũ trụ"},
		{"CIVILLAW_",  "luật dân sự"},
		{"PHYSGEO2_",  "địa lý tự nhiên 2"},
		{"EURHIST2_",  "lịch sử châu Âu 2"},
		{"PHARMA_",  "dược học"},
		{"GLOBALFOOD_",  "ẩm thực thế giới"},
		{"ADVMATH_",  "toán cao cấp"},
		{"NEWMAT_",  "vật liệu mới"},
		{"SCIHIST_",  "lịch sử khoa học"},
		{"MIDEAST_",  "Trung Đông"},
		{"INTORG_",  "tổ chức quốc tế"},
		{"WELFARE_",  "phúc lợi xã hội"},
		{"ARTMODERN_",  "nghệ thuật hiện đại"},
		{"LIT3_",  "văn học thế giới 3"},
		{"WORLDMUSIC_",  "âm nhạc thế giới"},
		{"CLIMATE2_",  "khoa học khí hậu"},
		{"NUTRIHEALTH_",  "dinh dưỡng sức khỏe"},
		{"ENVECON_",  "kinh tế môi trường"},
		{"ASIA2_",  "các quốc gia châu Á"},
		{"EU2_",  "các quốc gia châu Âu"},
		{"OCEAN2_",  "đại dương"},
		{"CS2_",  "khoa học máy tính 2"},
		{"VNPOL_",  "chính trị VN"},
		{"BLOCKCHAIN2_",  "blockchain nâng cao"},
		{"COGNEURO_",  "thần kinh nhận thức"},
		{"ECOGEO_",  "địa lý kinh tế"},
		{"EXERCISE_",  "sức khỏe vận động"},
		{"AMERHIST_",  "lịch sử châu Mỹ"},
		{"EASREL_",  "tôn giáo Đông Á"},
		{"MODPHYS_",  "vật lý hiện đại"},
		{"SOFTENG_",  "kỹ thuật phần mềm"},
		{"PSYCH2_EXTRA",  "tâm lý bổ sung"},
		{"WATER_",  "môi trường nước"},
		{"IDEAHIST_",  "lịch sử tư tưởng"},
		{"AFRICA_",  "địa lý châu Phi"},
		{"BIO4_",  "sinh học nâng cao"},
		{"ENVCHEM_",  "hóa học môi trường"},
		{"SOCIOL_",  "xã hội học"},
		{"PHILSCI_",  "triết học khoa học"},
		{"BEHAV_ECON2_",  "kinh tế hành vi 2"},
		{"VNECON2_",  "kinh tế VN bổ sung"},
		{"NUCLEAR_",  "vật lý hạt nhân"},
		{"ORGCHEM_",  "hóa học hữu cơ"},
		{"VNHIST2_",  "lịch sử VN bổ sung"},
		{"ASTRO_APP_",  "thiên văn ứng dụng"},
		{"TECHETHICS_",  "đạo đức công nghệ"},
		{"VNLIT2_",  "văn học VN bổ sung"},
		{"SEA_GEO_",  "địa lý Đông Nam Á"},
		{"LANG_",  "ngoại ngữ"},
		{"EVOBIO_",  "sinh học tiến hóa"},
		{"FOODSCI_",  "khoa học thực phẩm"},
		{"SOCPSYCH_",  "tâm lý xã hội"},
		{"FINPERSONAL_",  "tài chính cá nhân"},
		{"VNCULTURE_",  "văn hóa VN"},
		{"ASTRO4_",  "thiên văn nâng cao"},
		{"ML2_",  "ML nâng cao"},
		{"INTLAW_",  "luật quốc tế"},
		{"MODEDU_",  "giáo dục hiện đại"},
		{"DATASCI_",  "khoa học dữ liệu"},
		{"PUBHEALTH2_",  "y tế cộng đồng"},
		{"LANDMARK_",  "địa danh nổi tiếng"},
		{"ASIAHIST_",  "lịch sử châu Á"},
		{"MATSCI_",  "khoa học vật chất"},
		{"APPMATH_",  "toán ứng dụng"},
		{"MODMED_",  "y học hiện đại"},
		{"GEOPOLIT_",  "địa chính trị"},
		{"VNLING_",  "ngôn ngữ VN"},
		{"POPCULTURE_",  "văn hóa đại chúng"},
		{"PSY_HEALTH_",  "sức khỏe tâm thần"},
		{"DIGI_ECON_",  "kinh tế số"},
		{"ASTROPHYS_",  "vật lý thiên văn"},
		{"ENVSCI_",  "khoa học môi trường"},
		{"SPORT3_",  "thể thao thế giới"},
		{"VNAGR_",  "nông nghiệp VN"},
		{"VNINFRA_",  "hạ tầng VN"},
		{"POLINT_",  "chính trị/quan hệ quốc tế"},
		{"ECON_THEORY_",  "kinh tế học lý thuyết"},
		{"NEURO_",  "khoa học thần kinh"},
		{"ECO2_",  "sinh thái học"},
		{"APPPHYS_",  "vật lý ứng dụng"},
		{"CS_THEORY_",  "lý thuyết CS"},
		{"SOLAR_",  "Hệ Mặt Trời"},
		{"PHYSGEO_",  "địa lý vật lý"},
		{"SDG_",  "phát triển bền vững"},
		{"SPACE3_",  "khám phá không gian"},
		{"ARTWORLD_",  "nghệ thuật thế giới"},
		{"LIT2_",  "văn học thế giới"},
		{"COG_",  "khoa học nhận thức"},
		{"VNNATURE_",  "thiên nhiên VN"},
		{"VNART_",  "nghệ thuật VN"},
		{"VNFOOD_",  "ẩm thực VN"},
		{"SOC3_",  "xã hội VN"},
		{"SCI_",  "khoa học hệ thống"},
		{"WORLD_",  "lịch sử thế giới"},
		{"FUTURE_",  "công nghệ tương lai"},
		{"ASEAN_",  "ASEAN"},
		{"VNSPORT_",  "thể thao VN"},
		{"MOD_PHIL_",  "triết học hiện đại"},
		{"TRAD_MED_",  "y học cổ truyền"},
		{"DEMO_",  "dân số học"},
		{"VNECON_",   "kinh tế Việt Nam"},
		{"VNEDU_",   "giáo dục Việt Nam"},
		{"VNHIST_",   "lịch sử Việt Nam"},
		{"VNTRAVEL_",   "du lịch Việt Nam"},
		{"VNLIT_",   "văn học Việt Nam"},
		{"VNENV_",   "môi trường Việt Nam"},
		{"CS2_",   "lập trình/CS"},
		{"AI2_",   "trí tuệ nhân tạo"},
		{"ECON4_",   "kinh tế toàn cầu"},
		{"DIGITAL2_",   "xã hội số"},
		{"EASPHIL_",   "triết học Đông phương"},
		{"SEC2_",   "an ninh"},
		{"MATER2_",   "khoa học vật liệu"},
		{"PHYS4_",   "vật lý lý thuyết"},
		{"SPACE_", "khái niệm vũ trụ/không gian"},
		{"WILD_",  "khái niệm thiên nhiên/sinh thái"},
		{"STAT_",  "khái niệm thống kê/toán học"},
		{"PLANT_", "loài thực vật"},
		{"MOL_",   "phân tử sinh học"},
	}
	for _, p := range prefixes {
		if strings.HasPrefix(nodeName, p.prefix) {
			return fmt.Sprintf("**%s** là %s", label, p.phrase)
		}
	}
	return fmt.Sprintf("**%s**", label)
}

// placeOpening trả về opening phù hợp cho PLACE_ nodes
// Dựa vào label + nodeName để phân loại:
//   thủ đô / thành phố → "là thành phố / thủ đô"
//   di sản / vịnh → "là di sản thế giới / địa danh thiên nhiên"
//   đồng bằng / sông → "là vùng địa lý"
func placeOpening(nodeName, label string) string {
	lo := strings.ToLower(label)
	// Thủ đô / thành phố lớn
	capitals := map[string]string{
		"hà nội": "**Hà Nội** là thủ đô Việt Nam",
		"sài gòn": "**Sài Gòn** (TP.HCM) là trung tâm kinh tế lớn nhất Việt Nam",
		"tokyo": "**Tokyo** là thủ đô Nhật Bản",
		"bắc kinh": "**Bắc Kinh** là thủ đô Trung Quốc",
	}
	if s, ok := capitals[lo]; ok { return s }

	// Di sản / địa danh thiên nhiên
	if strings.Contains(lo,"vịnh") || strings.Contains(lo,"hạ long") {
		return fmt.Sprintf("**%s** là di sản thiên nhiên thế giới UNESCO", label)
	}
	if strings.Contains(lo,"angkor") || strings.Contains(lo,"đền") {
		return fmt.Sprintf("**%s** là di sản văn hóa thế giới UNESCO", label)
	}
	// Đồng bằng / sông
	if strings.Contains(lo,"đồng bằng") || strings.Contains(lo,"mekong") {
		return fmt.Sprintf("**%s** là vùng địa lý", label)
	}
	// Mặc định: thành phố / địa danh
	return fmt.Sprintf("**%s** là địa danh", label)
}

// buildSeeAlso tạo "Xem thêm: X, Y, Z" từ depth=1 hops
// Chỉ hiện tối đa 3 node, ưu tiên node khác domain
// Không hiện nếu chỉ có 0-1 hop
func (nl *NodeLookup) buildSeeAlso(node *KnownNode, hops []*SilkHop) string {
	if len(hops) == 0 { return "" }
	seen := map[string]bool{node.Label: true}
	var d1, d2 []string
	for _, h := range hops {
		if h.Node == nil || h.Node.Label == "" { continue }
		lbl := h.Node.Label
		if seen[lbl] { continue }
		seen[lbl] = true
		if h.Depth == 1 && len(d1) < 4 {
			d1 = append(d1, "**"+lbl+"**")
		} else if h.Depth >= 2 && len(d2) < 3 {
			d2 = append(d2, "**"+lbl+"**")
		}
	}
	var sb strings.Builder
	if len(d1) > 0 {
		sb.WriteString("\n\n_Xem thêm: " + strings.Join(d1, " · ") + "_")
	}
	if len(d2) > 0 {
		sb.WriteString("\n_Khám phá sâu hơn: " + strings.Join(d2, " · ") + "_")
	}
	return sb.String()
}

// buildAdjCache — build adjacency list depth=1 cho tất cả nodes
// Gọi 1 lần khi khởi tạo, dùng trong walkSilk thay đọc file mỗi lần
func (nl *NodeLookup) buildAdjCache() {
	raw := nl.raw
	if len(raw) < 20 { return }
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 { return }

	for i := edgeStart; i+17 <= len(raw); i += 17 {
		fromU := binary.BigEndian.Uint64(raw[i : i+8])
		toU   := binary.BigEndian.Uint64(raw[i+8 : i+16])
		eType := raw[i+16]
		_, ok1 := nl.byISLU[fromU]
		toNode,   ok2 := nl.byISLU[toU]
		if !ok1 || !ok2 { continue }
		sym := edgeTypeSym(eType)
		hop := &SilkHop{Node: toNode, EdgeType: eType, TypeSym: sym, Depth: 1}
		nl.adjCache[fromU] = append(nl.adjCache[fromU], hop)
	}
}
// Refresh — rebuild toàn bộ index sau khi file được append node mới.
// Gọi async (goroutine) từ brain_learn.go sau mỗi OlangAppendNode.
func (nl *NodeLookup) Refresh() {
	nl.mu.Lock()
	defer nl.mu.Unlock()
	nl.byISLU  = make(map[uint64]*KnownNode)
	nl.byLabel = make(map[string]*KnownNode)
	nl.byName  = make(map[string]*KnownNode)
	nl.adjCache = make(map[uint64][]*SilkHop)
	nl.tokIdx  = tokenIndex{}
	nl.build()
	nl.buildAdjCache()
	nl.buildTokenIndex()
}

// edgeTypeSym trả về symbol string của edge type byte
func edgeTypeSym(t uint8) string {
	syms := map[uint8]string{
		1:"→", 2:"↔", 3:"⊂", 4:"≡", 5:"∈", 6:"⇒", 7:"⊃", 8:"↑", 9:"↓", 10:"⊕",
		11:"∘", 12:"∋", 13:"⊇", 14:"⊆", 15:"∩", 16:"∪",
	}
	if s, ok := syms[t]; ok { return s }
	return "→"
}

// HopsFromCache trả về adjacency depth=1 từ cache cho node có ISLU
func (nl *NodeLookup) HopsFromCache(islu uint64) []*SilkHop {
	return nl.adjCache[islu]
}


// SuggestSimilar trả về tối đa maxN node có label/alias gần nhất với query
// Kết hợp: bigram Jaccard + word containment boost
func (nl *NodeLookup) SuggestSimilar(query string, maxN int) []*KnownNode {
	qLo    := strings.ToLower(strings.TrimSpace(query))
	qNorm  := normVI(qLo)
	qWords := strings.Fields(qLo) // từng từ của query (có dấu)
	qBigrams := bigrams(qNorm)
	if len(qBigrams) == 0 { return nil }

	type scored struct {
		node  *KnownNode
		score float64
	}
	seen := map[string]bool{}
	var results []scored

	for lbl, node := range nl.byLabel {
		if seen[node.Name] { continue }
		seen[node.Name] = true
		// Skip L1 UTF32 và L0 opcodes
		if node.LayerID <= 1 { continue }

		// 1. Bigram Jaccard với normVI
		best := jaccardBigram(qBigrams, bigrams(lbl))
		if s2 := jaccardBigram(qBigrams, bigrams(normVI(node.Label))); s2 > best {
			best = s2
		}
		// 2. Word containment boost: mỗi từ query xuất hiện trong label/alias
		//    "lúa gạo" → "trồng lúa" chứa "lúa" → boost +0.25
		nodeLo := strings.ToLower(node.Label) + " " + strings.ToLower(strings.Join(node.Aliases, " "))
		for _, w := range qWords {
			if len([]rune(w)) >= 2 && strings.Contains(nodeLo, w) {
				best += 0.25
				break
			}
		}
		// 3. Prefix match: query là tiền tố của label → max boost
		if strings.HasPrefix(strings.ToLower(node.Label), qLo) {
			best = 1.0
		}

		if best > 0.12 { // threshold thấp hơn để bắt được word match
			results = append(results, scored{node, best})
		}
	}
	// Sort giảm dần
	for i := 1; i < len(results); i++ {
		for j := i; j > 0 && results[j].score > results[j-1].score; j-- {
			results[j], results[j-1] = results[j-1], results[j]
		}
	}
	out := make([]*KnownNode, 0, maxN)
	for _, r := range results {
		if len(out) >= maxN { break }
		out = append(out, r.node)
	}
	return out
}

func bigrams(s string) map[string]int {
	rr := []rune(s)
	m := map[string]int{}
	for i := 0; i+1 < len(rr); i++ {
		m[string(rr[i:i+2])]++
	}
	return m
}

func jaccardBigram(a, b map[string]int) float64 {
	if len(a) == 0 || len(b) == 0 { return 0 }
	inter := 0
	for k, va := range a {
		if vb, ok := b[k]; ok {
			if va < vb { inter += va } else { inter += vb }
		}
	}
	union := 0
	for _, v := range a { union += v }
	for _, v := range b { union += v }
	union -= inter
	if union == 0 { return 0 }
	return float64(inter) / float64(union)
}

// silkContext — sinh đoạn silk context từ hops, phân nhóm theo edge type
// Chỉ dùng depth=1 hops để tránh cascade misleading
// Thứ tự ưu tiên: causes(∘) > opposite(⊥) > similar(≈) > memberOf(∈)
func (nl *NodeLookup) silkContext(label string, hops []*SilkHop) string {
	if len(hops) == 0 { return "" }

	// Group by semantic category cho các edge types quan trọng
	// Dùng edgeLabel để lấy phrase tự nhiên cho mọi edge type
	type hopGroup struct {
		phrase string
		items  []string
	}
	groups := map[string]*hopGroup{}
	order  := []string{}

	seen := map[string]bool{}

	// nodeShortDesc tra desc ngắn của target node (tối đa 6 từ)
	nodeShortDesc := func(n *KnownNode) string {
		if n == nil || n.Desc == "" { return "" }
		words := strings.Fields(n.Desc)
		if len(words) > 6 { words = words[:6] }
		return " (" + strings.Join(words, " ") + "...)"
	}

	for _, h := range hops {
		if h.Node == nil || h.Depth > 1 { continue }
		lbl := "**" + h.Node.Label + "**" + nodeShortDesc(h.Node)
		key := h.Node.Label
		if seen[key] { continue }
		seen[key] = true

		_, phrase := edgeLabel(h.EdgeType)

		// Normalize phrase → gom cùng ý nghĩa
		switch phrase {
		case "là loại", "là thành viên", "là thành phần":
			phrase = "là loại / thuộc"
		case "thuộc về", "là phần của", "là thành phần của":
			phrase = "là phần của"
		case "tương tự", "liên quan đến":
			phrase = "liên quan đến"
		}

		if _, exists := groups[phrase]; !exists {
			groups[phrase] = &hopGroup{phrase: phrase}
			order = append(order, phrase)
		}
		groups[phrase].items = append(groups[phrase].items, lbl)
	}

	if len(groups) == 0 { return "" }

	var sb strings.Builder
	for _, phrase := range order {
		g := groups[phrase]
		if len(g.items) > 6 { g.items = g.items[:6] } // tối đa 6 mỗi nhóm
		sb.WriteString("\n\n_" + phrase + "_: " + joinBold(g.items))
	}
	return sb.String()
}


func joinBold(items []string) string {
	if len(items) == 1 { return items[0] }
	if len(items) == 2 { return items[0] + " và " + items[1] }
	return strings.Join(items[:len(items)-1], ", ") + " và " + items[len(items)-1]
}

func explainTaiSao(label, desc string, layer, group uint8, memberOf, composes, opposite []string) string {
	base := layerGroupOpening("", label, layer, group)
	if desc != "" { base += " — " + desc }

	var why string
	switch layer {
	case 3:
		switch group {
		case 2: why = fmt.Sprintf("\n\nVì **%s** có bản chất sinh học riêng biệt, được phân loại vào nhóm động vật", label)
		case 5: why = fmt.Sprintf("\n\nVì cảm xúc là phản ứng sinh lý và tâm lý — **%s** xuất hiện khi não xử lý tín hiệu cụ thể", label)
		case 6: why = fmt.Sprintf("\n\n**%s** là nhu cầu sinh tồn — cơ thể cần thực hiện để duy trì sự sống", label)
		}
	case 2:
		why = fmt.Sprintf("\n\nVì đây là quy luật tự nhiên: **%s** xảy ra do các yếu tố vật lý/hóa học trong môi trường", label)
	}

	if len(opposite) > 0 {
		why += fmt.Sprintf("\n\nĐối lập: **%s** ↔ **%s** — hiểu một bên giúp hiểu bên kia rõ hơn",
			label, strings.Join(opposite, "/"))
	}
	return base + why
}

func explainNhTheNao(label, desc string, composes, similar []string) string {
	s := fmt.Sprintf("**%s**", label)
	if desc != "" { s += " — " + desc }
	if len(composes) > 0 {
		s += fmt.Sprintf("\n\n→ Tạo ra: **%s**", strings.Join(composes, "**, **"))
	}
	if len(similar) > 0 {
		s += fmt.Sprintf("\n\n≈ Tương tự: **%s**", strings.Join(similar, "**, **"))
	}
	return s
}

func explainGiNghia(label, desc string, memberOf []string) string {
	s := fmt.Sprintf("**%s**", label)
	if desc != "" { s += " có nghĩa là: " + desc }
	if len(memberOf) > 0 {
		s += fmt.Sprintf("\n\n∈ Thuộc nhóm: **%s**", strings.Join(memberOf, "**, **"))
	}
	return s
}

func explainCoKhong(label, desc string, memberOf []string) string {
	s := fmt.Sprintf("Có — **%s** tồn tại trong Silk Tree", label)
	if desc != "" { s += " với mô tả: " + desc }
	if len(memberOf) > 0 {
		s += fmt.Sprintf(" (thuộc **%s**)", strings.Join(memberOf, ", "))
	}
	return s + "."
}

func explainGeneral(label, desc string, layer, group uint8, memberOf, composes, opposite, similar []string) string {
	s := layerGroupOpening("", label, layer, group)
	if desc != "" { s += " — " + desc }
	s += "."
	if len(memberOf) > 0 {
		s += fmt.Sprintf("\n\n∈ Thuộc: **%s**", strings.Join(memberOf, "**, **"))
	}
	if len(composes) > 0 {
		s += fmt.Sprintf("\n∘ Tạo ra: **%s**", strings.Join(composes, "**, **"))
	}
	if len(opposite) > 0 {
		s += fmt.Sprintf("\n⊥ Đối lập: **%s**", strings.Join(opposite, "**, **"))
	}
	if len(similar) > 0 {
		s += fmt.Sprintf("\n≈ Tương tự: **%s**", strings.Join(similar, "**, **"))
	}
	return s
}

func capFirst(s string) string {
	if s == "" { return s }
	r := []rune(s)
	if len(r) == 0 { return s }
	first := string(r[0])
	return strings.ToUpper(first) + string(r[1:])
}

// runeIndex tìm vị trí rune slice b trong a, trả về -1 nếu không có
func runeIndex(a, b []rune) int {
	if len(b) == 0 { return 0 }
	if len(b) > len(a) { return -1 }
	for i := 0; i <= len(a)-len(b); i++ {
		match := true
		for j := range b {
			if a[i+j] != b[j] { match = false; break }
		}
		if match { return i }
	}
	return -1
}

// SearchByISLU — lookup node bằng ISL uint64
func (nl *NodeLookup) SearchByISLU(islu uint64) *KnownNode {
	nl.mu.RLock()
	defer nl.mu.RUnlock()
	return nl.byISLU[islu]
}

// ════════════════════════════════════════════════════════════════
// Resolve — cascade 4 cấp, thay thế 84 boilerplate trong brain.go
//
// Cấp 1: SearchExact(query)           — tìm chính xác
// Cấp 2: Search(query)                — fuzzy/alias/vi
// Cấp 3: Search(extractSubject(q))    — bỏ đuôi câu hỏi
// Cấp 4: SuggestSimilar → best match  — gần nhất nếu vẫn nil
//
// Trả về (node, hops, found)
//   found=true  → node != nil, hops từ cache
//   found=false → node=nil, hops=nil (caller xử lý not-found)
// ════════════════════════════════════════════════════════════════

// ResolveResult gộp kết quả của Resolve
type ResolveResult struct {
	Node  *KnownNode
	Hops  []*SilkHop
	Query string // query đã normalize dùng để tìm
	Level int    // 1=exact 2=fuzzy 3=subject 4=suggest
}

// Resolve tìm node theo cascade 4 cấp
func (nl *NodeLookup) Resolve(query string) ResolveResult {
	q := strings.TrimSpace(strings.ToLower(query))
	if q == "" {
		return ResolveResult{}
	}

	// Cấp 1 — exact
	if n := nl.SearchExact(q); n != nil {
		return ResolveResult{Node: n, Hops: nl.HopsFromCache(n.ISLU), Query: q, Level: 1}
	}

	// Cấp 2 — fuzzy/alias/vi
	if n := nl.Search(q); n != nil {
		return ResolveResult{Node: n, Hops: nl.HopsFromCache(n.ISLU), Query: q, Level: 2}
	}

	// Cấp 3 — bỏ đuôi câu hỏi, lấy subject
	if subj := extractSubjectFromQuery(q); subj != "" && subj != q {
		if n := nl.SearchExact(subj); n != nil {
			return ResolveResult{Node: n, Hops: nl.HopsFromCache(n.ISLU), Query: subj, Level: 3}
		}
		if n := nl.Search(subj); n != nil {
			return ResolveResult{Node: n, Hops: nl.HopsFromCache(n.ISLU), Query: subj, Level: 3}
		}
	}

	// Cấp 4 — suggest similar, lấy best
	similar := nl.SuggestSimilar(q, 1)
	if len(similar) > 0 {
		n := similar[0]
		return ResolveResult{Node: n, Hops: nl.HopsFromCache(n.ISLU), Query: q, Level: 4}
	}

	return ResolveResult{Query: q}
}

// extractSubjectFromQuery bỏ đuôi câu hỏi VN/EN, lấy subject chính
func extractSubjectFromQuery(lo string) string {
	lo = strings.TrimRight(lo, "?!.")
	suffixes := []string{
		" là gì", " là ai", " ở đâu", " là ở đâu", " là thế gì",
		" là cái gì", " là loại gì", " như thế nào", " hoạt động thế nào",
		" được làm từ gì", " có nghĩa là gì", " là bao nhiêu",
		" bằng bao nhiêu", " xuất xứ từ đâu", " có tác dụng gì",
		" is what", " is who", " means what", " does what",
		" what is", " who is", " where is", " how does",
	}
	for _, suf := range suffixes {
		if idx := strings.Index(lo, suf); idx > 0 {
			s := strings.TrimSpace(lo[:idx])
			if len([]rune(s)) >= 2 {
				return s
			}
		}
	}
	return ""
}
