// internal/ws/brain_conv.go
// ConvContext, ConvTurn, Respond

package ws

import (
	"strings"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/agents"
)

type ConvContext struct {
	mu        sync.Mutex
	maxTurns  int
	turns     []ConvTurn     // lịch sử tối đa maxTurns turn
	lastNode  *KnownNode     // node được nhắc đến gần nhất
	quizNode  *KnownNode     // node đang được quiz
	quizSeen  map[uint64]bool // tracker nodes đã quiz
}

type ConvTurn struct {
	Query  string
	Intent Intent
	Node   *KnownNode
}

// Push thêm 1 turn mới vào lịch sử
func (c *ConvContext) Push(query string, intent Intent, node *KnownNode) {
	c.mu.Lock(); defer c.mu.Unlock()
	c.turns = append(c.turns, ConvTurn{query, intent, node})
	if len(c.turns) > c.maxTurns { c.turns = c.turns[1:] }
	if node != nil { c.lastNode = node }
}

// LastNode trả về node cuối cùng được nhắc đến
func (c *ConvContext) LastNode() *KnownNode {
	c.mu.Lock(); defer c.mu.Unlock()
	return c.lastNode
}

// SetQuizNode lưu node đang quiz + đánh dấu đã thấy
func (c *ConvContext) SetQuizNode(n *KnownNode) {
	c.mu.Lock(); defer c.mu.Unlock()
	c.quizNode = n
	if n != nil && c.quizSeen != nil {
		c.quizSeen[n.ISLU] = true
	}
}

// IsQuizSeen kiểm tra node đã được quiz chưa
func (c *ConvContext) IsQuizSeen(islu uint64) bool {
	c.mu.Lock(); defer c.mu.Unlock()
	if c.quizSeen == nil { return false }
	return c.quizSeen[islu]
}

// ResetQuizSeen xóa lịch sử quiz (sau khi đã quiz toàn bộ)
func (c *ConvContext) ResetQuizSeen() {
	c.mu.Lock(); defer c.mu.Unlock()
	c.quizSeen = make(map[uint64]bool)
}

// GetQuizNode lấy node đang quiz
func (c *ConvContext) GetQuizNode() *KnownNode {
	c.mu.Lock(); defer c.mu.Unlock()
	return c.quizNode
}

// ResolveAnaphor: "nó", "nó là gì", "thêm về chủ đề này", "ví dụ" → lastNode
// Trả về node nếu query có đại từ/anaphora, nil nếu không
func (c *ConvContext) ResolveAnaphor(lo string) *KnownNode {
	c.mu.Lock(); defer c.mu.Unlock()
	if c.lastNode == nil { return nil }
	anaphor := []string{
		"nó ", "nó?", "nó!", "của nó", "nó là gì",
		"thêm về", "chi tiết hơn", "ví dụ",
		"còn gì nữa", "kể thêm",
		"it ", "it?", "more about", "tell me more", "elaborate",
		"what else", "examples", "more detail",
	}
	for _, a := range anaphor {
		if strings.Contains(lo, a) { return c.lastNode }
	}
	// Đại từ hoàn toàn là "nó" / "it"
	if lo == "nó" || lo == "it" || lo == "nó?" { return c.lastNode }
	return nil
}


func (b *Brain) Respond(p ParsedInput) ChatResponse {
	// ── Cập nhật đường cong cảm xúc ──────────────────────────────
	// Infer context từ text → scale emotion → update curve
	if b.curve != nil {
		emCtx  := agents.InferContext(p.Lower)
		rawTag := agents.SentenceAffect(p.Raw) // SentenceAffect: composition rule + IntentModifier
		scaled := emCtx.Apply(rawTag)
		b.curve.Add(scaled, p.Raw)
		b.emoHistory.Add(scaled, emCtx, p.Raw)
	}

	// Multi-turn context
	if b.convCtx != nil {
		// "đố thêm" / "tiếp" → quiz tiếp (TRƯỚC anaphor check)
		lo0 := p.Lower
		if lo0 == "đố thêm" || lo0 == "đố nữa" || lo0 == "tiếp" || lo0 == "tiếp theo" || lo0 == "more" || lo0 == "next" ||
			strings.HasSuffix(lo0, " thêm") && strings.Contains(lo0, "đố") {
			return b.quizNode("", p.Lang)
		}
		if anode := b.convCtx.ResolveAnaphor(p.Lower); anode != nil {
			// Mở rộng query về node đang nói đến
			hops := b.nodeLookup.HopsFromCache(anode.ISLU)
			var sb strings.Builder
			if p.Lang == "vi" {
				sb.WriteString("**" + anode.Label + "** (tiếp theo):\n\n")
			} else {
				sb.WriteString("**" + anode.Label + "** (continued):\n\n")
			}
			if anode.Desc != "" {
				sb.WriteString(anode.Desc + "\n\n")
			}
			if len(hops) > 0 {
				var labels []string
				for _, h := range hops {
					if h.Node == nil { continue }
					labels = append(labels, "**"+h.Node.Label+"**")
					if len(labels) >= 5 { break }
				}
				if p.Lang == "vi" {
					sb.WriteString("Liên kết: " + strings.Join(labels, " · "))
				} else {
					sb.WriteString("Related: " + strings.Join(labels, " · "))
				}
			}
			b.glowNode(anode, hops)
			return b.resp("know", strings.TrimSpace(sb.String()))
		}

	}

	return b.dispatchIntent(p)
}

// ─── Response builders ─────────────────────────────────────────
