package ws

import "testing"

func TestIntentRelated(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")

	tests := []struct {
		input   string
		wantTag string
	}{
		{"liên quan đến sợ hãi",  "know"},
		{"liên quan đến HomeOS",  "know"},
		{"nói thêm về tình yêu", "know"},
		{"liên quan đến tò mò",  "know"},
		{"liên quan đến buồn bã", "know"},
	}

	for _, tc := range tests {
		// Parse intent
		b := &Brain{nodeLookup: nl}
		slots := map[string]string{}
		lo := tc.input
		relatedTriggers := []string{
			"liên quan đến", "liên quan tới", "liên quan với",
			"nói thêm về", "nói thêm",
		}
		var subj string
		for _, t2 := range relatedTriggers {
			if idx := indexOf(lo, t2); idx >= 0 {
				subj = trimSpace(lo[idx+len(t2):])
				break
			}
		}
		if subj != "" {
			slots["related_subject"] = subj
		}

		resp := b.relatedWalk(slots["related_subject"], "vi")
		if resp.Tag == tc.wantTag {
			t.Logf("✅ %q →\n%s\n", tc.input, resp.Answer)
		} else {
			t.Errorf("⚠️  %q → [%s] %s", tc.input, resp.Tag, resp.Answer[:min3(60, len(resp.Answer))])
		}
	}
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub { return i }
	}
	return -1
}
func trimSpace(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\t') { s = s[1:] }
	return s
}
