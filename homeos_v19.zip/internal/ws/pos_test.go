package ws

import (
	"strings"
	"testing"
)

func TestPOSInference(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	tests := []struct{
		query   string
		wantPOS uint8
		posName string
	}{
		{"chạy",        POSVerb, "verb"},
		{"ăn",          POSVerb, "verb"},
		{"ngủ",         POSVerb, "verb"},
		{"sợ hãi",      POSNoun, "noun"},   // cảm xúc = noun
		{"tình yêu",    POSNoun, "noun"},
		{"nóng bức",    POSAdj,  "adj"},    // L6 group3 = adj
		{"lạnh buốt",   POSAdj,  "adj"},
		{"nhanh",       POSAdj,  "adj"},    // L6 group5 = adj
		{"ngọt",        POSAdj,  "adj"},    // L6 group4 = adj
		{"HomeOS",      POSNoun, "noun"},   // L5 = noun
		{"đèn bật",     POSNoun, "noun"},   // L4 = noun
		{"lửa",         POSNoun, "noun"},   // L2 = noun
	}
	pass := 0
	for _, tc := range tests {
		n := nl.Search(tc.query)
		if n == nil { t.Logf("❌ %q not found", tc.query); continue }
		sym := posSymbol(n.POS)
		if n.POS == tc.wantPOS {
			t.Logf("✅ %q → %s %s (%s)", tc.query, sym, tc.posName, n.Name)
			pass++
		} else {
			t.Logf("⚠️  %q → POS=%d want=%d (%s)", tc.query, n.POS, tc.wantPOS, n.Name)
		}
	}
	t.Logf("\n%d/%d POS tests pass", pass, len(tests))
}

func TestPOSInNaturalSentence(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	tests := []struct{ q, expect string }{
		{"chạy",     "꜉"},   // verb marker
		{"ăn",       "꜉"},
		{"nóng bức", "꜊"},   // adj marker
		{"lạnh buốt","꜊"},
		{"sợ hãi",   "**sợ hãi** là một cảm xúc"}, // noun opening
		{"HomeOS",   "**HomeOS** là khái niệm lập trình"},
	}
	for _, tc := range tests {
		node, hops := nl.SearchAndWalk(tc.q, 2)
		if node == nil { t.Logf("❌ %q not found", tc.q); continue }
		s := nl.NaturalSentence(node, hops)
		if strings.Contains(s, tc.expect) {
			t.Logf("✅ %q → %s", tc.q, s[:min3(70, len(s))])
		} else {
			t.Logf("⚠️  %q → %q (want %q)", tc.q, s[:min3(70,len(s))], tc.expect)
		}
	}
}
