// internal/ws/api.go — REST endpoints cho frontend
package ws

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

type ChatRequest struct {
	Text   string `json:"text"`
	Action string `json:"action"` // "query","activate","deactivate"
	Target string `json:"target"`
}

type ChatResponse struct {
	Tag        string `json:"tag"`
	Answer     string `json:"answer"`
	ISL        string `json:"isl,omitempty"`
	DNA        string `json:"dna,omitempty"`
	Edges      int    `json:"edges,omitempty"`
	Ts         int64  `json:"ts"`
	Tone       string `json:"tone,omitempty"` // supportive/pause/reinforcing/...
	// AskConfirm != "" → UI hiển thị nút [Có / Không] thay vì input thường
	AskConfirm string `json:"ask_confirm,omitempty"`
}

// RegisterAPI thêm handlers vào mux hiện tại
func (s *Server) RegisterAPI(mux *http.ServeMux) {
	c := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Access-Control-Allow-Origin", "*")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
			if r.Method == "OPTIONS" { w.WriteHeader(200); return }
			h(w, r)
		}
	}
	mux.HandleFunc("/api/agents", c(s.apiAgents))
	mux.HandleFunc("/api/chat",   c(s.apiChat))
	mux.HandleFunc("/api/signal", c(s.apiSignal))
	mux.HandleFunc("/api/node",   c(s.apiNode))
	mux.HandleFunc("/api/olang/get", c(s.apiOlangGet))
	mux.HandleFunc("/api/memory",    c(s.apiMemory))
	mux.HandleFunc("/api/teach",      c(s.apiTeach))
	mux.HandleFunc("/api/teach/file", c(s.apiTeachFile))
}

func (s *Server) apiAgents(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	type A struct {
		ID     string   `json:"id"`
		Status string   `json:"status"`
		Tier   int      `json:"tier"`
		Skills []string `json:"skills"`
	}
	list := s.registry.List()
	out  := make([]A, 0, len(list))
	for _, info := range list {
		out = append(out, A{
			ID:     info.ID,
			Status: info.Status,
			Tier:   info.Tier,
			Skills: info.Skills,
		})
	}
	// Fallback nếu registry chưa có gì (chạy test)
	if len(out) == 0 {
		out = append(out, A{ID: "aam", Status: "active", Tier: 0, Skills: []string{"(loading)"}})
	}
	json.NewEncoder(w).Encode(out)
}

func (s *Server) apiChat(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	var req ChatRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), 400); return
	}
	text := strings.TrimSpace(req.Text)
	if text == "" {
		json.NewEncoder(w).Encode(ChatResponse{Tag:"empty", Answer:"_empty_", Ts: time.Now().Unix()})
		return
	}
	// Brain xử lý — NLP + Silk Tree + Identity
	parsed := s.brain.Parse(text)
	resp   := s.brain.Respond(parsed)

	// Wire Bus: gửi MsgUserInput đến agents (LeoAI học, AAM biết)
	if s.msgBus != nil {
		pm := s.brain.PerceptEncode(text)
		msg := &isl.ISLMessage{
			Version:       1,
			MsgType:       isl.MsgUserInput,
			PrimaryAddr:   pm.Primary,
			SecondaryAddr: pm.Intent,
			ContextAddr:   pm.Msg.ContextAddr, // first context address
			Confidence:    pm.Msg.Confidence,
			Payload:       []byte(text),
		}
		go s.msgBus.DispatchUserInput(msg)
	}

	// Nếu là lệnh ISL (tắt/bật đèn...) → gửi qua bus
	if req.Action == "activate" || req.Action == "deactivate" && req.Target != "" && s.bus != nil {
		msgType := isl.MsgActivate
		if req.Action == "deactivate" { msgType = isl.MsgDeactivate }
		s.bus <- &isl.ISLMessage{Version:1, MsgType: msgType,
			PrimaryAddr: isl.Address{Layer:'H', Group:'A', Type:'a', ID:1},
			Payload: []byte(req.Target)}
	}
	json.NewEncoder(w).Encode(resp)
}


func (s *Server) apiSignal(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method != "POST" { http.Error(w, "POST only", 405); return }
	var req struct { From, To, Msg string }
	json.NewDecoder(r.Body).Decode(&req)
	s.world.FireSignal(req.From, req.To)
	s.world.Glow(req.From); s.world.Glow(req.To)
	if s.bus != nil {
		mt := isl.MsgActivate
		if req.Msg == "deactivate" { mt = isl.MsgDeactivate }
		s.bus <- &isl.ISLMessage{Version:1, MsgType:mt, Payload:[]byte(req.To)}
	}
	fmt.Fprintf(w, `{"ok":true}`)
}

func (s *Server) apiNode(w http.ResponseWriter, r *http.Request) {
	// Trường hợp 1: ?name=UI_CSS — serve raw asset từ UILoader
	name := r.URL.Query().Get("name")
	if name != "" {
		if asset, ok := s.uiLoader.Get(name); ok && asset != nil {
			w.Header().Set("Content-Type", asset.ContentType)
			w.Header().Set("Cache-Control", "public, max-age=3600")
			w.Header().Set("X-Source", "homeos.olang:L5:"+name)
			w.Write(asset.Data)
			return
		}
		http.Error(w, "node not found: "+name, 404)
		return
	}

	// Trường hợp 2: ?q=X — tìm node trong Silk Tree (backward compat)
	w.Header().Set("Content-Type", "application/json")
	q := r.URL.Query().Get("q")
	if q == "" { http.Error(w, "?name= or ?q=", 400); return }
	nodes := s.world.Graph.AllNodes()
	lo := strings.ToLower(q)
	for _, n := range nodes {
		if strings.ToLower(n.Name) == lo || strings.ToLower(n.Glyph) == q {
			json.NewEncoder(w).Encode(n)
			return
		}
	}
	http.Error(w, "not found", 404)
}

func (s *Server) queryTree(input string) ChatResponse {
	lo := strings.ToLower(strings.TrimSpace(input))
	nodes := s.world.Graph.AllNodes()

	// 1. Exact match
	for _, n := range nodes {
		if strings.ToLower(n.Name) == lo || n.Glyph == input {
			return s.nodeResponse(n, nodes)
		}
	}
	// 2. Contains match
	for _, n := range nodes {
		if strings.Contains(strings.ToLower(n.Name), lo) && len(lo) > 2 {
			return s.nodeResponse(n, nodes)
		}
	}
	// 3. Keyword in input — word-boundary aware, min 4 runes
	// Chỉ match khi query ngắn (≤ 3 từ) hoặc node name chiếm ≥ 40% query words
	loWords := strings.Fields(lo)
	for _, n := range nodes {
		nm := strings.ToLower(n.Name)
		nmR := []rune(nm)
		if len(nmR) < 4 { continue }
		if !strings.Contains(lo, nm) { continue }
		loR := []rune(lo)
		ri := runeIndexS(loR, nmR)
		if ri < 0 { continue }
		before := ri == 0 || !isViWordCharR(loR[ri-1])
		after  := ri+len(nmR) >= len(loR) || !isViWordCharR(loR[ri+len(nmR)])
		if !before || !after { continue }
		nmWords := strings.Fields(nm)
		if len(loWords) <= 2 || len(nmWords)*10 >= len(loWords)*6 {
			return s.nodeResponse(n, nodes)
		}
	}

	total := len(nodes)
	edges := len(s.world.Graph.AllEdges())
	return ChatResponse{
		Tag:  "learn",
		Answer: fmt.Sprintf("**\"%s\"** chưa có trong Silk Tree.\n\nTree: %d nodes · %d edges\n\nDùng Teacher API (🔑) để LeoAI học và ghi vào Tree.", input, total, edges),
		Ts: time.Now().Unix(),
	}
}

func (s *Server) nodeResponse(n *silk.OlangNode, allNodes []*silk.OlangNode) ChatResponse {
	ans := fmt.Sprintf("**%s**", n.Name)
	if n.Glyph != "" { ans += " " + n.Glyph }
	ans += fmt.Sprintf(" `[%s]`", n.Addr.String())
	if n.Cat != "" { ans += "\nCat: " + n.Cat }
	if n.DNA != "" { ans += "\nDNA: `" + n.DNA + "`" }

	// Silk edges
	silkParts := []string{}
	for i, e := range n.Edges {
		if i >= 4 { silkParts = append(silkParts, "…"); break }
		if en, ok := s.world.Graph.Get(e.To); ok && en.Name != "" {
			silkParts = append(silkParts, fmt.Sprintf("%s→%s", string(rune(e.Op)), en.Name))
		}
	}
	if len(silkParts) > 0 { ans += "\nSilk: " + strings.Join(silkParts, "  ") }

	return ChatResponse{
		Tag: "know", Answer: ans,
		ISL: n.Addr.String(), DNA: n.DNA,
		Edges: len(n.Edges), Ts: time.Now().Unix(),
	}
}

// apiOlangGet — /api/olang/get?q=A  →  node info thật từ olang file
func (s *Server) apiOlangGet(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	q := r.URL.Query().Get("q")
	if q == "" { http.Error(w, `{"err":"?q="}`, 400); return }
	nodes := s.world.Graph.AllNodes()
	lo := strings.ToLower(q)
	type NodeDetail struct {
		Name  string   `json:"name"`
		Glyph string   `json:"glyph"`
		ISL   string   `json:"isl"`
		Cat   string   `json:"cat"`
		DNA   string   `json:"dna"`
		Layer int      `json:"layer"`
		Links []string `json:"links"`
		Similar []string `json:"similar"`
	}
	for _, n := range nodes {
		if strings.ToLower(n.Name) == lo || n.Glyph == q {
			links := []string{}
			for _, e := range n.Edges {
				if tn, ok := s.world.Graph.Get(e.To); ok && tn.Name != "" {
					links = append(links, fmt.Sprintf("%s→%s", string(rune(e.Op)), tn.Name))
				}
			}
			json.NewEncoder(w).Encode(NodeDetail{
				Name:  n.Name, Glyph: n.Glyph,
				ISL:   n.Addr.String(), Cat: n.Cat,
				DNA:   n.DNA, Layer: n.Layer,
				Links: links,
			})
			return
		}
	}
	http.Error(w, `{"err":"not found"}`, 404)
}

// apiMemory — GET /api/memory → trả về toàn bộ ĐN + QR + tên
// Frontend dùng để sync khi online
func (s *Server) apiMemory(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	snap := map[string]interface{}{
		"name": s.brain.state.GetName(),
		"dn":   s.brain.state.AllDN(),
		"qr":   map[string]interface{}{},
	}
	json.NewEncoder(w).Encode(snap)
}

// ── BƯỚC 4: Teacher API ─────────────────────────────────────────

// POST /api/teach
// Body: {"key":"X","value":"Y","force":true}
// force=true → QR ngay (không cần fire×3)
// force=false → ĐN (mặc định)
func (s *Server) apiTeach(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405); return
	}
	var req struct {
		Key   string `json:"key"`
		Value string `json:"value"`
		Force bool   `json:"force"` // true → QR ngay
		Layer uint8  `json:"layer"` // 0 = auto
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), 400); return
	}
	if req.Key == "" {
		http.Error(w, "key required", 400); return
	}

	var fire int
	var promoted bool

	if req.Force {
		// Force QR: ghi thẳng với status=QR, không qua fire counter
		isl := nameToISL(req.Key + " = " + req.Value)
		dna := nameToDNA(req.Key, req.Value)
		layer := req.Layer
		if layer == 0 { layer = inferLayerID(req.Key, req.Value) }
		err := OlangAppendNodeQR(s.brain.state.olangPath, layer, isl, 0, dna, req.Key+" = "+req.Value)
		if err != nil {
			http.Error(w, err.Error(), 500); return
		}
		fire, promoted = 3, true
		// Reload matchers nếu là INTENT hoặc QT node
		s.brain.matcher.Reload()
	} else {
		fire, promoted = s.brain.state.Learn(req.Key, req.Value)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"ok":       true,
		"key":      req.Key,
		"value":    req.Value,
		"fire":     fire,
		"promoted": promoted,
		"status":   map[bool]string{true: "QR", false: "ĐN"}[promoted],
	})
}

// POST /api/teach/file
// Body: multipart/form-data với file text
// Format file:
//   key = value        ← ĐN (fire=1)
//   !key = value       ← QR ngay (force)
//   # comment          ← bỏ qua
//   [blank line]       ← bỏ qua
func (s *Server) apiTeachFile(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", 405); return
	}
	if err := r.ParseMultipartForm(1 << 20); err != nil { // 1MB max
		http.Error(w, err.Error(), 400); return
	}
	file, _, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "file required", 400); return
	}
	defer file.Close()

	content := make([]byte, 1<<20)
	n, _ := file.Read(content)
	lines := strings.Split(string(content[:n]), "\n")

	type result struct {
		Line     int    `json:"line"`
		Key      string `json:"key"`
		Value    string `json:"value"`
		Status   string `json:"status"`
		Error    string `json:"error,omitempty"`
	}
	var results []result
	dn, qr, errs := 0, 0, 0

	for i, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") { continue }

		force := strings.HasPrefix(line, "!")
		if force { line = line[1:] }

		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			results = append(results, result{Line: i+1, Error: "format: key = value"})
			errs++; continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		if key == "" { continue }

		var status string
		if force {
			isl := nameToISL(key + " = " + val)
			dna := nameToDNA(key, val)
			layer := inferLayerID(key, val)
			if err2 := OlangAppendNodeQR(s.brain.state.olangPath, layer, isl, 0, dna, key+" = "+val); err2 != nil {
				results = append(results, result{Line: i+1, Key: key, Error: err2.Error()})
				errs++; continue
			}
			status = "QR"; qr++
		} else {
			fire, promoted := s.brain.state.Learn(key, val)
			_ = fire
			status = map[bool]string{true: "QR", false: "ĐN"}[promoted]
			if promoted { qr++ } else { dn++ }
		}
		results = append(results, result{Line: i+1, Key: key, Value: val, Status: status})
	}

	// Reload sau khi batch teach
	s.brain.matcher.Reload()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"ok":      errs == 0,
		"dn":      dn,
		"qr":      qr,
		"errors":  errs,
		"results": results,
	})
}

func runeIndexS(a, b []rune) int {
	if len(b)==0 { return 0 }
	if len(b)>len(a) { return -1 }
	for i:=0; i<=len(a)-len(b); i++ {
		ok:=true
		for j:=range b { if a[i+j]!=b[j] { ok=false; break } }
		if ok { return i }
	}
	return -1
}
func isViWordCharR(r rune) bool {
	return (r>='a'&&r<='z')||(r>='A'&&r<='Z')||(r>='0'&&r<='9')||r>127
}
