// internal/ws/brain_query_core_query_engine_—_resolvesubject,_querynode,_resp,_glownode,_helpers.go
// Core query engine — resolveSubject, queryNode, resp, glowNode, helpers

package ws

import (
	"fmt"
	"strings"
	"time"
	"unicode"
)

func (b *Brain) resolveSubject(subject, lang string) (*KnownNode, []*SilkHop, *ChatResponse) {
	if b.nodeLookup == nil {
		r := b.resp("unknown", "Silk Tree chưa sẵn sàng.")
		return nil, nil, &r
	}
	res := b.nodeLookup.Resolve(subject)
	if res.Node == nil {
		r := b.searchNodes(subject, lang)
		return nil, nil, &r
	}
	hops := res.Hops
	if len(hops) == 0 {
		hops = b.nodeLookup.HopsFromCache(res.Node.ISLU)
	}
	return res.Node, hops, nil
}

func (b *Brain) queryNode(p ParsedInput) ChatResponse {
	// 0. BookShelf — tìm trong sách đã đọc trước khi tìm Silk Tree
	if b.bookShelf != nil {
		if mem, _ := b.bookShelf.Find(p.Lower); mem != nil {
			return b.resp("book", b.respondAboutBook(p.Lower, p.Lang))
		}
	}

	// 0b. Nếu đang có pendingNew — user vừa trả lời confirm/reject
	//    (IntentConfirm/Reject đã xử lý ở Respond, nhưng nếu user gõ
	//    "ok" sau khi nhận new_knowledge thì sẽ vào đây qua default:)
	//    → handled bởi Respond() case IntentConfirm

	// 0b. Multi-keyword query: "bê tông và thép", "vaccine và virus"
	//     Tách tại "và"/"với"/"or"/"and" → trả lời tổng hợp nếu cả hai đều biết
	if multi := b.tryMultiKeyword(p); multi != nil {
		return *multi
	}

	// 1. NodeLookup — L2/L3/L4/L6 ontology nodes
	//    Thử cả p.Raw và subject được extract từ câu hỏi dài
	//    "Tokyo là thủ đô của nước nào?" → extract "Tokyo" trước
	searchCandidates := []string{p.Raw, p.Lower}
	if subj := extractQuerySubject(p.Lower); subj != "" && subj != p.Lower {
		searchCandidates = append([]string{subj}, searchCandidates...)
	}
	for _, cand := range searchCandidates {
		if node := b.nodeLookup.Search(cand); node != nil {
			_, hops := b.nodeLookup.SearchAndWalk(cand, 3)
			b.glowNode(node, hops)
			return b.resp("know", b.nodeLookup.NaturalSentence(node, hops))
		}
	}
	// 2. ĐN / QR memory (đã học từ người dùng)
	results := b.state.Search(p.Raw)
	if len(results) > 0 {
		return b.resp("dn", results[0])
	}

	// 3. Silk Tree lookup
	if b.s != nil {
		resp := b.s.queryTree(p.Raw)
		if resp.Tag == "know" {
			return resp
		}
	}

	// 4. Silk reasoning fallback
	b.initReasoner()
	if b.reasoner != nil {
		rr := b.reasoner.Reason(p.Raw)
		if rr != nil && rr.HasResult() {
			return b.resp("know", rr.FormatVI())
		}
	}

	// 5. Không biết → thử suggest gần nhất, rồi hỏi ghi nhớ
	if b.nodeLookup != nil {
		suggestions := b.nodeLookup.SuggestSimilar(p.Lower, 3)
		if len(suggestions) > 0 {
			var parts []string
			for _, s := range suggestions {
				parts = append(parts, "**"+s.Label+"**")
			}
			hint := strings.Join(parts, " · ")
			if p.Lang == "vi" {
				return b.resp("unknown",
					"Không tìm thấy **\""+p.Raw+"\"** trong Silk Tree.\n\n"+
					"Ý bạn là: "+hint+"?\n\n"+
					"_Hoặc nhập chính xác tên để tôi ghi nhớ._")
			}
			return b.resp("unknown", "\""+p.Raw+"\" not found. Did you mean: "+hint+"?")
		}
	}
	// Không có gợi ý → hỏi ghi nhớ
	b.pendingNew = &pendingKnowledge{Key: p.Raw, Query: p.Raw, Lang: p.Lang}

	if p.Lang == "vi" {
		msg := fmt.Sprintf(
			"Tôi chưa có **\"%s\"** trong bộ nhớ.\n\n"+
				"💡 Bạn có muốn tôi ghi nhớ khái niệm này không?\n"+
				"→ Nhấn **Có** hoặc gõ `nhớ rằng %s là [mô tả]` để dạy tôi.",
			p.Raw, p.Raw)
		r := b.respAsk("new_knowledge", msg, "new_knowledge:"+p.Raw)
		return r
	}
	msg := fmt.Sprintf(
		"**\"%s\"** not found in memory.\n\n"+
			"💡 Would you like me to remember this?\n"+
			"→ Click **Yes** or type `remember %s is [description]`.",
		p.Raw, p.Raw)
	return b.respAsk("new_knowledge", msg, "new_knowledge:"+p.Raw)
}

// explainNode — xử lý câu hỏi "tại sao / như thế nào / giải thích X"
func (b *Brain) resp(tag, answer string) ChatResponse {
	return ChatResponse{Tag: tag, Answer: answer, Ts: time.Now().Unix()}
}

// respAsk — giống resp nhưng kèm AskConfirm → UI hiện nút [Có / Không]
func (b *Brain) respAsk(tag, answer, askKey string) ChatResponse {
	return ChatResponse{Tag: tag, Answer: answer, AskConfirm: askKey, Ts: time.Now().Unix()}
}

// glowNode — khi Brain trả lời về 1 node, glow nó và fire signals tới hops depth=1
// Làm tree3d.html glow theo activity thật
func (b *Brain) glowNode(node *KnownNode, hops []*SilkHop) {
	// Cập nhật conversation context
	if b.convCtx != nil && node != nil {
		b.convCtx.Push(node.Label, IntentQueryNode, node)
	}
	if b.s == nil || b.s.world == nil || node == nil { return }
	// Map ISL→nodeID trong world graph
	w := b.s.world
	nodeID := node.Name // dùng Name làm ID (match với olang_graph.go)
	w.Glow(nodeID)
	// Fire signals depth=1 hops
	for _, h := range hops {
		if h.Node == nil || h.Depth > 1 { continue }
		w.FireSignal(nodeID, h.Node.Name)
	}
}

func matchAny(s string, patterns ...string) bool {
	for _, p := range patterns {
		if strings.Contains(s, p) {
			return true
		}
	}
	return false
}

// matchAnyWord kiểm tra pattern là từ đứng riêng (không phải substring của từ khác)
func matchAnyWord(s string, patterns ...string) bool {
	for _, p := range patterns {
		if idx := strings.Index(s, p); idx >= 0 {
			// Kiểm tra trước: không phải chữ cái Latin/Vietnamese
			before := idx == 0 || !isWordChar(rune(s[idx-1]))
			after  := idx+len(p) >= len(s) || !isWordChar(rune(s[idx+len(p)]))
			if before && after { return true }
		}
	}
	return false
}

func isWordChar(r rune) bool {
	return (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r > 127
}

func raw_after(s, prefix string) string {
	idx := strings.Index(s, prefix)
	if idx < 0 {
		return ""
	}
	return strings.TrimSpace(s[idx+len(prefix):])
}

func toTitle(s string) string {
	if s == "" {
		return s
	}
	runes := []rune(s)
	runes[0] = unicode.ToUpper(runes[0])
	return string(runes)
}

func firstLine(s string) string {
	if idx := strings.Index(s, "\n"); idx >= 0 {
		return s[:idx]
	}
	return s
}

// inferLayerForText — helper cho Brain (gọi sang Learner)
func inferLayerForText(key, value string) uint8 {
	return inferLayerID(key, value)
}

// lastISL helper
