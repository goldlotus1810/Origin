package ws

import (
	"testing"
)

func TestNaturalSentenceOutput(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	tests := []string{"sợ hãi", "vui vẻ", "tò mò", "HomeOS", "mạng nơ-ron", "tình yêu", "buồn bã"}
	for _, q := range tests {
		node, hops := nl.SearchAndWalk(q, 3)
		if node == nil { t.Logf("❌ %q not found", q); continue }
		s := nl.NaturalSentence(node, hops)
		t.Logf("=== %q ===\n%s\n", q, s)
	}
}
