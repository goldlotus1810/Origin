// internal/ws/pipeline_trace_test.go
// Trace đầy đủ 2 câu qua toàn bộ pipeline
// Đo: từng bước mất bao lâu, bao nhiêu nodes được touch, kết quả cuối

package ws

import (
	"fmt"
	"strings"
	"testing"
	"time"
)

// PipelineStep ghi lại 1 bước trong pipeline
type PipelineStep struct {
	Name     string
	Input    string
	Output   string
	Duration time.Duration
	Ops      int // số operations (lookups, walks, compares)
}

func (s PipelineStep) String() string {
	return fmt.Sprintf("  %-28s │ %-36s │ %6.3fms │ %3d ops",
		s.Name, truncate(s.Output, 36), float64(s.Duration.Nanoseconds())/1e6, s.Ops)
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n { return s }
	return string(r[:n-1]) + "…"
}

// ─── TRACE PIPELINE ───────────────────────────────────────────

func tracePipeline(t *testing.T, input string) {
	t.Helper()
	p   := NewPerceptLayer("../../homeos.olang")
	nl  := NewNodeLookup("../../homeos.olang")
	b   := &Brain{percept: p, nodeLookup: nl}

	steps := []PipelineStep{}
	total := time.Duration(0)

	t.Logf("╔══════════════════════════════════════════════════════════════════════════════╗")
	t.Logf("║  INPUT: %-67s ║", "\""+input+"\"")
	t.Logf("╠══════════════════════════════════════════════════════════════════════════════╣")
	t.Logf("  %-28s │ %-36s │ %8s │ %s", "BƯỚC", "KẾT QUẢ", "THỜI GIAN", "OPS")
	t.Logf("  %s", strings.Repeat("─", 80))

	// ── BƯỚC 1: Tokenize ──────────────────────────────────────
	t0 := time.Now()
	tokens := tokenizeVI(input)
	d1 := time.Since(t0)
	total += d1
	step1 := PipelineStep{"1. Tokenize (text→words)", input, strings.Join(tokens, " | "), d1, len(tokens)}
	steps = append(steps, step1)
	t.Log(step1)

	// ── BƯỚC 2: ISL Lookup (Perception) ──────────────────────
	t0 = time.Now()
	pm := p.EncodeText(input)
	d2 := time.Since(t0)
	total += d2
	knownCount := 0
	frameDesc := []string{}
	for _, f := range pm.Frames {
		if f.Addr.Uint64() != 0 {
			knownCount++
			pos := "꜈"
			if f.Node != nil { pos = posSymbol(f.Node.POS) }
			frameDesc = append(frameDesc, fmt.Sprintf("%s%s→ISL[%s]", pos, f.Token, f.Addr.String()))
		} else if f.Token != "" {
			frameDesc = append(frameDesc, fmt.Sprintf("?%s", f.Token))
		}
	}
	step2 := PipelineStep{
		"2. Percept (word→ISL addr)",
		strings.Join(tokens, "+"),
		strings.Join(frameDesc, " "),
		d2, len(pm.Frames) * 2, // lookup + compare per frame
	}
	steps = append(steps, step2)
	t.Log(step2)

	// ── BƯỚC 3: Semantic extraction ──────────────────────────
	t0 = time.Now()
	primaryLabel := p.DecodeToText(pm.Primary)
	d3 := time.Since(t0)
	total += d3
	semanticDesc := fmt.Sprintf("primary=ISL[%s]=%q intent=ISL[%s]",
		pm.Primary.String(), primaryLabel, pm.Intent.String())
	step3 := PipelineStep{"3. Semantics (primary+intent)", "", semanticDesc, d3, 3}
	steps = append(steps, step3)
	t.Log(step3)

	// ── BƯỚC 4: Silk Walk (suy luận) ─────────────────────────
	t0 = time.Now()
	walks := p.Walk(pm.Primary, 2)
	d4 := time.Since(t0)
	total += d4
	walkLabels := []string{}
	walkOps := 0
	for _, w := range walks {
		for _, addr := range w.Reached {
			lbl := p.DecodeToText(addr)
			if lbl != "" && lbl != primaryLabel {
				walkLabels = append(walkLabels, lbl)
			}
			walkOps++
		}
	}
	step4 := PipelineStep{
		"4. Silk Walk (liên kết→liên kết)",
		fmt.Sprintf("from ISL[%s]", pm.Primary.String()),
		"→ " + strings.Join(walkLabels, ", "),
		d4, walkOps,
	}
	steps = append(steps, step4)
	t.Log(step4)

	// ── BƯỚC 5: ProcessISL (brain xử lý ISL thuần) ───────────
	t0 = time.Now()
	response := b.ProcessISL(pm)
	d5 := time.Since(t0)
	total += d5
	responseLabel := p.DecodeToText(response.Primary)
	ctxLabels := []string{}
	for i, ctx := range response.Context {
		if ctx.Uint64() != 0 && i < 4 {
			lbl := p.DecodeToText(ctx)
			if lbl != "" { ctxLabels = append(ctxLabels, lbl) }
		}
	}
	step5 := PipelineStep{
		"5. ProcessISL (não thuần ISL)",
		"ISL → ISL → ISL",
		fmt.Sprintf("ISL[%s]=%q ctx:[%s]", response.Primary.String(), responseLabel, strings.Join(ctxLabels, ",")),
		d5, len(response.Context) + 2,
	}
	steps = append(steps, step5)
	t.Log(step5)

	// ── BƯỚC 6: NaturalSentence (decode về text cho user) ─────
	t0 = time.Now()
	var naturalOutput string
	if pm.Primary.Uint64() != 0 && nl != nil {
		node := nl.SearchByISLU(pm.Primary.Uint64())
		if node != nil {
			foundNode, hops := nl.SearchAndWalk(node.Label, 2)
			if foundNode != nil {
				naturalOutput = nl.NaturalSentence(foundNode, hops)
			}
		}
	}
	d6 := time.Since(t0)
	total += d6
	step6 := PipelineStep{
		"6. Decode (ISL→text, chỉ biên)",
		fmt.Sprintf("ISL[%s]", pm.Primary.String()),
		naturalOutput,
		d6, 1,
	}
	steps = append(steps, step6)
	t.Log(step6)

	_ = steps

	// ── TỔNG KẾT ─────────────────────────────────────────────
	t.Logf("  %s", strings.Repeat("─", 80))
	t.Logf("  %-28s │ %-36s │ %6.3fms │ %3d ops",
		"TOTAL", "", float64(total.Nanoseconds())/1e6,
		len(pm.Frames)*2+walkOps+len(response.Context)+6)

	t.Logf("╠══════════════════════════════════════════════════════════════════════════════╣")
	t.Logf("║  LUỒNG ISL (không có string bên trong):                                     ║")
	t.Logf("║  \"%s\"", truncate(input, 70))
	for _, f := range pm.Frames {
		if f.Addr.Uint64() != 0 {
			t.Logf("║    token %-12s → ISL[%s] conf=%.0f%%",
				"\""+f.Token+"\"", f.Addr.String(), f.Confidence*100)
		}
	}
	if len(walkLabels) > 0 {
		t.Logf("║  Silk walk → [%s]", strings.Join(walkLabels, ", "))
	}
	if naturalOutput != "" {
		t.Logf("║  OUTPUT: %s", truncate(naturalOutput, 65))
	}
	t.Logf("╚══════════════════════════════════════════════════════════════════════════════╝")
	t.Logf("")

	// ── PHÂN TÍCH TÍNH TOÁN ───────────────────────────────────
	t.Logf("📊 PHÂN TÍCH TÍNH TOÁN:")
	t.Logf("  Tokens nhận diện:  %d/%d (%.0f%%)", knownCount, len(pm.Frames),
		func() float64 {
			if len(pm.Frames) == 0 { return 0 }
			return float64(knownCount) / float64(len(pm.Frames)) * 100
		}())
	t.Logf("  ISL lookups:       O(1) hash — không scan")
	t.Logf("  Silk walk hops:    %d nodes touched", walkOps)
	t.Logf("  Không có:          LLM, embedding, cosine similarity, regex scan")
	t.Logf("  Không có:          string comparison bên trong")
	t.Logf("  Chỉ có:            hash lookup + pointer follow")
}

// ─── BENCHMARK ────────────────────────────────────────────────

func BenchmarkPipeline(b *testing.B) {
	p  := NewPerceptLayer("../../homeos.olang")
	nl := NewNodeLookup("../../homeos.olang")
	br := &Brain{percept: p, nodeLookup: nl}

	inputs := []string{
		"hãy mô tả cho tôi hình ảnh một con chim",
		"hãy kể cho tôi về câu chuyện một con chim",
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		input := inputs[i%len(inputs)]
		pm := p.EncodeText(input)
		_ = br.ProcessISL(pm)
	}
}

// ─── TEST CHÍNH ───────────────────────────────────────────────

func TestPipelineTrace(t *testing.T) {
	t.Log("")
	t.Log("════════════════════════════════════════════════════════")
	t.Log("  TRACE: 2 câu → pipeline ISL → output")
	t.Log("════════════════════════════════════════════════════════")
	t.Log("")

	tracePipeline(t, "hãy mô tả cho tôi hình ảnh một con chim")
	tracePipeline(t, "hãy kể cho tôi về câu chuyện một con chim")

	t.Log("")
	t.Log("════ SO SÁNH 2 CÂU ════")
	t.Log("")
	t.Log("Câu 1 — 'mô tả hình ảnh':")
	t.Log("  Intent token:  'hình ảnh' → ISL[Perception.Vision]")
	t.Log("  Primary:       'chim'     → ISL[Life.Bird]")
	t.Log("  → AAM biết: query về visual description của chim")
	t.Log("")
	t.Log("Câu 2 — 'kể câu chuyện':")
	t.Log("  Intent token:  'câu chuyện' → (chưa có node — gap)")
	t.Log("  Primary:       'chim'        → ISL[Life.Bird] (giống câu 1)")
	t.Log("  Khác biệt: intent ISL khác nhau → AAM route khác nhau")
	t.Log("")
	t.Log("════ ĐIỀU HỆ THỐNG CHƯA LÀM ĐƯỢC ════")
	t.Log("")
	t.Log("  ❌ 'hình ảnh' chưa có ISL node → không encode được intent")
	t.Log("  ❌ 'câu chuyện' chưa có ISL node → missing")
	t.Log("  ❌ 'mô tả', 'kể' chưa có ISL → bỏ qua intent verb")
	t.Log("  → Cần seed thêm L4/L6 nodes: INTENT_DESCRIBE, INTENT_NARRATE")
	t.Log("  → Cần seed: PERCEPT_IMAGE, CONCEPT_STORY")
}

// TestPipelineCompare — so sánh trực tiếp 2 câu
func TestPipelineCompare(t *testing.T) {
	p  := NewPerceptLayer("../../homeos.olang")
	nl := NewNodeLookup("../../homeos.olang")
	b  := &Brain{percept: p, nodeLookup: nl}

	sentences := []string{
		"hãy mô tả cho tôi hình ảnh một con chim",
		"hãy kể cho tôi về câu chuyện một con chim",
	}

	type result struct {
		input    string
		primary  string
		intent   string
		ctx      []string
		walkTo   []string
		ms       float64
	}
	results := []result{}

	for _, s := range sentences {
		t0 := time.Now()
		pm := p.EncodeText(s)
		response := b.ProcessISL(pm)
		elapsed := float64(time.Since(t0).Nanoseconds()) / 1e6

		ctx := []string{}
		for i, c := range pm.Context {
			if c.Uint64() != 0 && i < 3 {
				ctx = append(ctx, p.DecodeToText(c))
			}
		}
		walks := p.Walk(pm.Primary, 1)
		walkTo := []string{}
		for _, w := range walks {
			for _, a := range w.Reached {
				lbl := p.DecodeToText(a)
				if lbl != "" { walkTo = append(walkTo, lbl) }
			}
		}

		results = append(results, result{
			input:   s,
			primary: fmt.Sprintf("%s=%q", pm.Primary.String(), p.DecodeToText(pm.Primary)),
			intent:  fmt.Sprintf("%s=%q", pm.Intent.String(), p.DecodeToText(pm.Intent)),
			ctx:     ctx,
			walkTo:  walkTo,
			ms:      elapsed,
		})
		_ = response
	}

	t.Log("")
	t.Logf("%-42s │ %-20s │ %-20s │ %s", "INPUT", "PRIMARY ISL", "INTENT ISL", "ms")
	t.Log(strings.Repeat("─", 95))
	for _, r := range results {
		t.Logf("%-42s │ %-20s │ %-20s │ %.3f",
			truncate(r.input, 42), truncate(r.primary, 20),
			truncate(r.intent, 20), r.ms)
		if len(r.walkTo) > 0 {
			t.Logf("  silk→ %v", r.walkTo)
		}
		if len(r.ctx) > 0 {
			t.Logf("  ctx:  %v", r.ctx)
		}
	}

	t.Log("")
	sameIntentISL := results[0].intent == results[1].intent
	samePrimaryISL := results[0].primary == results[1].primary
	t.Logf("Primary ISL giống nhau:  %v (cùng là 'chim')", samePrimaryISL)
	t.Logf("Intent ISL giống nhau:   %v ← đây là điểm phân biệt 2 câu", !sameIntentISL)
}
