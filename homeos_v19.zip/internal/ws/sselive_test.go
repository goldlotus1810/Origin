package ws

import (
	"testing"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestGlowNodeOnQuery(t *testing.T) {
	// Khởi tạo world với SilkGraph
	graph := silk.NewSilkGraph()
	world := NewWorld(42, graph)

	// Brain cần server để glow, nhưng NewBrain đọc homeos.olang
	// Tạo minimal server với world
	s := &Server{world: world}
	// Brain với path thực
	vocab := NewVocabLoader("../../homeos.olang")
	b := &Brain{
		s:          s,
		state:      NewState("../../homeos.olang"),
		nodeLookup: NewNodeLookup("../../homeos.olang"),
		vocab:      vocab,
	}
	globalVocab = vocab

	// Query một node — brain phải glow nó
	before := len(world.glowing)
	p := b.Parse("sợ hãi là gì")
	resp := b.Respond(p)

	if resp.Tag != "know" {
		t.Fatalf("Expected know, got %s: %s", resp.Tag, resp.Answer[:min3(60,len(resp.Answer))])
	}

	after := len(world.glowing)
	if after <= before {
		t.Fatalf("Expected glowing nodes after query, before=%d after=%d", before, after)
	}
	t.Logf("✅ Glow triggered: %d nodes glowing", after)
	for id, g := range world.glowing {
		t.Logf("  glow[%s] = %.2f", id, g)
	}
	t.Logf("Signals fired: %d", len(world.signals))
	for _, sig := range world.signals {
		t.Logf("  %s → %s (p=%.2f)", sig.From, sig.To, sig.P)
	}
	t.Logf("Answer:\n%s", resp.Answer)
}
