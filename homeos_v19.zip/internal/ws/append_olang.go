// internal/ws/append_olang.go
//
// OlangAppendNode — ghi node thật vào homeos.olang
//
// Format node record (đúng chuẩn, verified bằng cmd/olang):
//   ND(2) + layerID(1) + isl(8) + codepoint(4,BE) + dnaLen(4,BE) + nameLen(1) + dna + name
//
// Append procedure (atomic):
//   1. Đọc file vào RAM
//   2. Build record bytes
//   3. Insert sau cuối layer target (trước edge table)
//   4. Update header.nnodes + sha256
//   5. Update LayerEntry: size, nnodes, offset của layers sau
//   6. Write .tmp → rename

package ws

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

const (
	olgHdrSize      = 64
	olgLayerEntSize = 24
	olgNLayers      = 9
	olgLayerIdxEnd  = olgHdrSize + olgNLayers*olgLayerEntSize // 280
)

var olgMu sync.Mutex

// shaOffset trả về byte offset để ghi SHA256 trong header.
// V19+: [32:64] (vì [28:32] = namesTableOffset)
// V18:  [28:60]
func shaOffset(raw []byte) int {
	if len(raw) >= 6 && binary.BigEndian.Uint16(raw[4:6]) >= 19 {
		return 32
	}
	return 28
}

// OnNodeAppended — hook gọi sau mỗi OlangAppendNode thành công.
// Brain.nodeLookup đặt hook này khi init để tự Refresh() async.
var OnNodeAppended func()

// OlangAppendNode ghi 1 node vào file .olang theo đúng format.
// Atomic: .tmp → rename.
func OlangAppendNode(filePath string, layerID uint8, isl [8]byte, cp rune, dna []byte, name string) error {
	olgMu.Lock()
	defer olgMu.Unlock()

	// ── Đọc file ────────────────────────────────────────────────
	raw, err := os.ReadFile(filePath)
	if err != nil { return fmt.Errorf("read: %w", err) }
	if len(raw) < olgLayerIdxEnd { return fmt.Errorf("file too small") }
	if string(raw[0:4]) != "OLNG" { return fmt.Errorf("bad magic") }

	// ── Parse layer offsets ─────────────────────────────────────
	type linfo struct{ offset, size uint64; nnodes uint32 }
	li := [olgNLayers]linfo{}
	for i := 0; i < olgNLayers; i++ {
		o := olgHdrSize + i*olgLayerEntSize
		li[i].offset = binary.BigEndian.Uint64(raw[o+4 : o+12])
		li[i].size   = binary.BigEndian.Uint64(raw[o+12 : o+20])
		li[i].nnodes = binary.BigEndian.Uint32(raw[o+20 : o+24])
	}

	// ── Build record ────────────────────────────────────────────
	// V19: node không có nameLen, tên lưu riêng trong NamesTable
	// V18: node có nameLen(1)+name inline
	fileVersion := binary.BigEndian.Uint16(raw[4:6])
	isV19 := fileVersion >= 19

	nameB := []byte(name)
	if len(nameB) > 255 { nameB = nameB[:255] }

	var rec []byte
	if isV19 {
		// V19: 2+1+8+4+4+dna = 19B header, NO nameLen
		rec = make([]byte, 2+1+8+4+4+len(dna))
		p := 0
		rec[p] = 'N'; p++
		rec[p] = 'D'; p++
		rec[p] = layerID; p++
		copy(rec[p:], isl[:]); p += 8
		binary.BigEndian.PutUint32(rec[p:], uint32(cp)); p += 4
		binary.BigEndian.PutUint32(rec[p:], uint32(len(dna))); p += 4
		copy(rec[p:], dna)
	} else {
		// V18: 2+1+8+4+4+1+dna+name
		rec = make([]byte, 2+1+8+4+4+1+len(dna)+len(nameB))
		p := 0
		rec[p] = 'N'; p++
		rec[p] = 'D'; p++
		rec[p] = layerID; p++
		copy(rec[p:], isl[:]); p += 8
		binary.BigEndian.PutUint32(rec[p:], uint32(cp)); p += 4
		binary.BigEndian.PutUint32(rec[p:], uint32(len(dna))); p += 4
		rec[p] = uint8(len(nameB)); p++
		copy(rec[p:], dna); p += len(dna)
		copy(rec[p:], nameB)
	}

	// ── Find insert point ───────────────────────────────────────
	var insertAt uint64
	tgt := int(layerID)
	if li[tgt].size > 0 {
		insertAt = li[tgt].offset + li[tgt].size
	} else {
		insertAt = uint64(olgLayerIdxEnd)
		for i := tgt - 1; i >= 0; i-- {
			if li[i].size > 0 { insertAt = li[i].offset + li[i].size; break }
		}
	}

	// ── Assemble new file ───────────────────────────────────────
	new := make([]byte, 0, len(raw)+len(rec))
	new = append(new, raw[:insertAt]...)
	new = append(new, rec...)
	new = append(new, raw[insertAt:]...)

	// ── Update header.nnodes ────────────────────────────────────
	oldN := binary.BigEndian.Uint32(new[12:16])
	binary.BigEndian.PutUint32(new[12:], oldN+1)

	// ── Update layer index ──────────────────────────────────────
	for i := 0; i < olgNLayers; i++ {
		o := olgHdrSize + i*olgLayerEntSize
		lo  := binary.BigEndian.Uint64(new[o+4 : o+12])
		ls  := binary.BigEndian.Uint64(new[o+12 : o+20])
		ln  := binary.BigEndian.Uint32(new[o+20 : o+24])

		if i == tgt {
			if ls == 0 { binary.BigEndian.PutUint64(new[o+4:], insertAt) }
			binary.BigEndian.PutUint64(new[o+12:], ls+uint64(len(rec)))
			binary.BigEndian.PutUint32(new[o+20:], ln+1)
		} else if lo > 0 && lo >= insertAt {
			binary.BigEndian.PutUint64(new[o+4:], lo+uint64(len(rec)))
		}
	}

	// ── V19: update namesTableOffset ──────────────────────────
	if isV19 && name != "" {
		// 1. Đọc namesTableOffset hiện tại từ file gốc (trước khi insert)
		oldNTOff := int(binary.BigEndian.Uint32(raw[28:32]))
		// 2. NamesTable dịch chuyển thêm len(rec) (node mới chèn trước NT)
		newNTOff := oldNTOff + len(rec)
		binary.BigEndian.PutUint32(new[28:], uint32(newNTOff))
		// 3. Append entry vào NamesTable: isl(8)+nameLen(1)+name
		nameB2 := []byte(name)
		if len(nameB2) > 255 { nameB2 = nameB2[:255] }
		ntEntry := make([]byte, 9+len(nameB2))
		copy(ntEntry[:8], isl[:])
		ntEntry[8] = uint8(len(nameB2))
		copy(ntEntry[9:], nameB2)
		// NamesTable = "NT"(2) + count(4) + entries
		// count tại offset newNTOff+2
		if newNTOff+6 <= len(new) && new[newNTOff] == 'N' && new[newNTOff+1] == 'T' {
			oldCount := binary.BigEndian.Uint32(new[newNTOff+2 : newNTOff+6])
			// Chèn entry vào cuối NamesTable (trước edge section)
			// Tìm vị trí cuối NT: newNTOff+6 + sum(9+nameLen)
			ntEnd := newNTOff + 6
			for k := 0; k < int(oldCount); k++ {
				if ntEnd+9 > len(new) { break }
				ntEnd += 9 + int(new[ntEnd+8])
			}
			// Insert ntEntry tại ntEnd
			new = append(new[:ntEnd], append(ntEntry, new[ntEnd:]...)...)
			// Update count
			binary.BigEndian.PutUint32(new[newNTOff+2:], oldCount+1)
			// Update header.edgeCount offset nếu edges bị dịch
			// edges vẫn ở cuối file — không cần update offset trong header
		}
	}

	// ── SHA256 of content after layer index ─────────────────────
	sum := sha256.Sum256(new[olgLayerIdxEnd:])
	so := shaOffset(new)
	copy(new[so:so+32], sum[:])

	// ── Atomic write ────────────────────────────────────────────
	tmp := filePath + ".append.tmp"
	if err := os.WriteFile(tmp, new, 0644); err != nil {
		return fmt.Errorf("write tmp: %w", err)
	}
	if err := os.Rename(tmp, filePath); err != nil {
		os.Remove(tmp)
		return fmt.Errorf("rename: %w", err)
	}
	if OnNodeAppended != nil {
		go OnNodeAppended() // BUG2 FIX: async Refresh
	}
	return nil
}

// OlangAppendNodeQR — giống OlangAppendNode nhưng set layer status = QR (2)
// Dùng cho Teacher force=true và QT nodes
func OlangAppendNodeQR(filePath string, layerID uint8, isl [8]byte, cp rune, dna []byte, name string) error {
	// Ghi node bình thường trước
	if err := OlangAppendNode(filePath, layerID, isl, cp, dna, name); err != nil {
		return err
	}
	// Set layer status = QR (2) trong header
	olgMu.Lock()
	defer olgMu.Unlock()
	raw, err := os.ReadFile(filePath)
	if err != nil { return err }
	rb := []byte(raw)
	// Layer entry: [layerID:1][status:1][flags:2][offset:8][size:8][nnodes:4] = 24B
	for i := 0; i < olgNLayers; i++ {
		o := olgHdrSize + i*olgLayerEntSize
		if rb[o] == layerID {
			rb[o+1] = 2 // status = QR
			break
		}
	}
	// Recalc SHA256
	content := rb[olgLayerIdxEnd:]
	hash := sha256.Sum256(content)
	so2 := shaOffset(rb)
	copy(rb[so2:so2+32], hash[:])
	tmp := filePath + ".qr.tmp"
	if err2 := os.WriteFile(tmp, rb, 0644); err2 != nil { return err2 }
	return os.Rename(tmp, filePath)
}

// ── Edge append ──────────────────────────────────────────────────────────────

// OlangAppendEdge thêm 1 silk edge vào edge table cuối file.
// Edge = src(8B) + dst(8B) + type(1B) = 17B.
// src và dst là ISL addresses (từ node records).
func OlangAppendEdge(filePath string, srcISL, dstISL [8]byte, edgeType uint8) error {
	return OlangAppendEdgeWeighted(filePath, srcISL, dstISL, edgeType, 1.0)
}

// OlangAppendEdgeWeighted thêm edge với Hebbian weight vào file (V2 format: 21B)
func OlangAppendEdgeWeighted(filePath string, srcISL, dstISL [8]byte, edgeType uint8, weight float32) error {
	olgMu.Lock()
	defer olgMu.Unlock()

	raw, err := os.ReadFile(filePath)
	if err != nil { return fmt.Errorf("read: %w", err) }
	rb := []byte(raw)

	// Edge record V2: 21B = src(8) + dst(8) + type(1) + weight(4)
	rec := make([]byte, olang.EdgeSize) // EdgeSize = 21 (V2)
	copy(rec[0:8], srcISL[:])
	copy(rec[8:16], dstISL[:])
	rec[16] = edgeType
	if weight == 0 { weight = 1.0 }
	binary.BigEndian.PutUint32(rec[17:], math.Float32bits(weight))

	// Append vào cuối file
	rb = append(rb, rec...)

	// Update header: nedges += 1
	nedges := binary.BigEndian.Uint32(rb[16:20])
	binary.BigEndian.PutUint32(rb[16:20], nedges+1)

	// Recalc SHA256
	h := sha256.Sum256(rb[olgLayerIdxEnd:])
	so3 := shaOffset(rb)
	copy(rb[so3:so3+32], h[:])

	tmp := filePath + ".edge.tmp"
	if err2 := os.WriteFile(tmp, rb, 0644); err2 != nil { return err2 }
	return os.Rename(tmp, filePath)
}

// OlangReadISL đọc ISL address của node theo tên từ file.
// Trả về [8]byte zero nếu không tìm thấy.
func OlangReadISL(filePath, name string) ([8]byte, bool) {
	raw, err := os.ReadFile(filePath)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil { return [8]byte{}, false }
	for off := 0; off+14 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > len(raw) { break }
		off++ // layerID
		var isl [8]byte; copy(isl[:], raw[off:off+8]); off += 8
		off += 4 // codepoint
		dlen := int(binary.BigEndian.Uint32(raw[off : off+4])); off += 4
		nlen := int(raw[off]); off++
		if off+dlen+nlen > len(raw) { break }
		off += dlen
		n := string(raw[off : off+nlen]); off += nlen
		if n == name { return isl, true }
	}
	return [8]byte{}, false
}
