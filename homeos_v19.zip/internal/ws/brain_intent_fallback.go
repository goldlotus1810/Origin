// internal/ws/brain_intent_fallback.go
// detectIntentFallback — keyword/pattern matching dự phòng
// Tách từ brain_parse.go vì đây là 1 concern riêng biệt

package ws

import (
	"fmt"
	"strings"
)

func (b *Brain) detectIntentFallback(lo string, slots map[string]string) Intent {
	v := b.vocab

	// WebFetch — "đọc trang X", "fetch URL", URL trực tiếp
	if u, ok := detectWebFetchIntent(lo); ok {
		slots["url"] = u
		return IntentWebFetch
	}

	// Calc — "tính X", "2+2", "căn bậc hai 144", "20% của 300"
	if expr, ok := detectCalcExpr(lo); ok {
		slots["expr"] = expr
		return IntentCalc
	}

	// ReadBook — "đọc sách X", "load book X", "đọc file X"
	for _, prefix := range []string{"đọc sách ", "load book ", "read book ", "đọc file ", "load file "} {
		if strings.HasPrefix(lo, prefix) {
			path := strings.TrimSpace(lo[len(prefix):])
			if path != "" { slots["book_path"] = path }
			return IntentReadBook
		}
	}
	// "sách đã đọc" / "danh sách sách"
	if (strings.Contains(lo, "sách") && strings.Contains(lo, "đã đọc")) ||
		strings.Contains(lo, "danh sách sách") || lo == "sách" {
		return IntentReadBook
	}

	// Greeting / Farewell / Help — vocab nodes
	if v.HasIntent(lo, "greet")   { return IntentGreeting }
	if v.HasIntent(lo, "bye")     { return IntentFarewell }
	// "hướng dẫn X" → HowTo trước khi check help
	for _, hp := range []string{"hướng dẫn ", "quy trình ", "bước để "} {
		if strings.HasPrefix(lo, hp) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(hp):]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["howto_subject"] = subj; return IntentHowTo }
		}
	}
	if v.HasIntent(lo, "help")    { return IntentHelp }

	// Confirm / Reject — feedback cho ĐN (QT7 correction)
	// Detect trước identity để "đúng" không bị nhầm
	if isConfirmSignal(lo) { return IntentConfirm }
	if isRejectSignal(lo)  { return IntentReject }

	// Identity trước Naming
	if v.HasIntent(lo, "identity") { return IntentIdentity }

	// Naming — detect + extract tên sau pattern
	if pn := v.GetPattern("naming"); pn != nil {
		for _, pat := range pn.Patterns {
			if strings.Contains(lo, pat) {
				name := strings.TrimSpace(raw_after(lo, pat))
				isQ := false
				for _, q := range pn.QuestionGuard {
					if strings.Contains(name, q) { isQ = true; break }
				}
				if name != "" && len([]rune(name)) >= 2 && !isQ {
					slots["name"] = toTitle(name)
					return IntentNaming
				}
			}
		}
	}

	// Rules — extract qt cụ thể nếu có
	if v.HasIntent(lo, "rule") {
		for i := 1; i <= 7; i++ {
			q := fmt.Sprintf("qt%d", i)
			if strings.Contains(lo, q) || strings.Contains(lo, fmt.Sprintf("quy tắc %d", i)) {
				slots["rule"] = q
			}
		}
		return IntentQueryRule
	}

	// Status
	if v.HasIntent(lo, "status") { return IntentStatus }

	// Emotion — em cảm thấy thế nào
	{
		emotionKW := []string{
			"cảm thấy thế nào", "cảm xúc gì", "đang cảm thấy",
			"em nghĩ gì về", "how do you feel", "what do you feel",
			"cam thay the nao", "cam xuc gi", "dang cam thay",
		}
		for _, kw := range emotionKW {
			if strings.Contains(lo, kw) { return IntentEmotion }
		}
	}

	// Report — em đang thấy gì / đang quan sát / what do you see
	{
		reportKW := []string{
			"em đang thấy", "đang quan sát", "nhìn thấy gì",
			"em đang nhìn", "bạn đang thấy", "mình đang nhìn",
			"what do you see", "what can you see", "what are you observing",
			"em dang thay", "dang quan sat", "nhin thay gi",
		}
		for _, kw := range reportKW {
			if strings.Contains(lo, kw) { return IntentReport }
		}
	}

	// Learn — extract value
	if pn := v.GetPattern("learn"); pn != nil {
		for _, pat := range pn.Patterns {
			if idx := strings.Index(lo, pat); idx >= 0 {
				val := strings.TrimSpace(raw_after(lo, pat))
				if val != "" { slots["value"] = val; return IntentLearn }
			}
		}
	}

	// Forget — extract subject
	if pn := v.GetPattern("forget"); pn != nil {
		for _, pat := range pn.Patterns {
			if idx := strings.Index(lo, pat); idx >= 0 {
				val := strings.TrimSpace(raw_after(lo, pat))
				if val != "" { slots["subject"] = val; return IntentForget }
			}
		}
	}

	// Self
	if v.HasIntent(lo, "self") { return IntentQuerySelf }

	// Actuator action words (backup nếu parseActuator miss)
	// Guard: "tóm tắt/gọn/lược" không phải actuator dù chứa "tắt"
	isSummFallback := strings.HasPrefix(lo, "tóm ") || strings.HasPrefix(lo, "summarize ") ||
		strings.HasPrefix(lo, "summary ") || strings.HasPrefix(lo, "brief overview") ||
		strings.HasPrefix(lo, "tổng hợp") || strings.HasPrefix(lo, "mẹo nhớ") ||
		strings.HasPrefix(lo, "cách nhớ") || strings.HasPrefix(lo, "mnemonic") ||
		strings.HasPrefix(lo, "cách ghi nhớ") || strings.HasPrefix(lo, "kỹ thuật nhớ")
	if !isSummFallback && v.HasIntent(lo, "actuator") { return IntentActuator }

	// CharLookup — "chữ A", "ký tự ∑", "山", single symbol
	// Trigger khi: query là 1 ký tự đặc biệt, hoặc có "chữ"/"ký tự"/"symbol"
	charTriggers := []string{"chữ ", "ký tự ", "symbol ", "glyph ", "letter "}
	for _, t := range charTriggers {
		if strings.Contains(lo, t) {
			rest := strings.TrimSpace(strings.ReplaceAll(lo, t, ""))
			rest  = strings.Trim(rest, "là gì? ")
			slots["char_query"] = rest
			return IntentCharLookup
		}
	}
	// Single non-Latin ký tự quan trọng (CJK, math symbol, emoji)
	runes := []rune(strings.TrimSpace(lo))
	if len(runes) == 1 {
		r := runes[0]
		if r > 0x2000 { // math/CJK/emoji range
			slots["char_query"] = string(r)
			return IntentCharLookup
		}
	}

	// Reason — suy luận từ chuỗi ký tự lạ hoặc từ ngữ nước ngoài
	// Trigger khi query chứa ký tự non-ASCII không phải tiếng Việt quen thuộc
	nonASCII := 0
	for _, r := range lo {
		if r > 127 { nonASCII++ }
	}
	hasUnknownScript := nonASCII > 0 && nonASCII == len([]rune(lo)) // toàn bộ là non-ASCII
	if hasUnknownScript && len([]rune(lo)) >= 2 && len([]rune(lo)) <= 8 {
		slots["reason_query"] = lo
		return IntentReason
	}

	// Define — "X là gì?" / "định nghĩa X" — súc tích hơn Explain
	definePats := []string{
		" là gì", " là gì?", " là cái gì", " là cái gì?",
		"định nghĩa ", "define ", "khái niệm ",
		" nghĩa là gì", " có nghĩa là gì",
	}
	for _, pat := range definePats {
		var subject string
		if strings.HasPrefix(pat, " ") {
			// Pattern đứng sau subject: "X là gì"
			if idx := strings.Index(lo, pat); idx > 0 {
				subject = strings.TrimSpace(lo[:idx])
			}
		} else {
			// Pattern đứng trước subject: "định nghĩa X"
			if strings.HasPrefix(lo, pat) {
				subject = strings.TrimSpace(lo[len(pat):])
				subject = strings.TrimRight(subject, "?!. ")
			}
		}
		if subject != "" && len([]rune(subject)) >= 2 {
			slots["define_subject"] = subject
			return IntentDefine
		}
	}


	// Mnemonic — "mẹo nhớ X" / "cách nhớ X" / "mnemonic for X"
	for _, mp := range []string{"mẹo nhớ ", "cách nhớ ", "mnemonic for ", "mnemonic of ", "trick to remember ", "cách ghi nhớ ", "kỹ thuật nhớ "} {
		if strings.HasPrefix(lo, mp) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(mp):]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["mnemonic_subject"] = subj; return IntentMnemonic }
		}
	}
	// Mnemonic suffix "làm sao nhớ X" / "nhớ X bằng cách nào"
	for _, sf := range []string{" làm sao nhớ", " cần nhớ gì", " nhớ như thế nào"} {
		if strings.HasSuffix(lo, sf) {
			subj := strings.TrimRight(strings.TrimSpace(lo[:len(lo)-len(sf)]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["mnemonic_subject"] = subj; return IntentMnemonic }
		}
	}

	// Summary — "tóm tắt X" / "summarize X" / "tóm lược X"
	for _, sp := range []string{"tóm tắt ", "summarize ", "tóm lược ", "summary of ", "brief overview of ", "tóm gọn ", "nói ngắn gọn về ", "tổng hợp về "} {
		if strings.HasPrefix(lo, sp) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(sp):]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["summary_subject"] = subj; return IntentSummary }
		}
	}
	// Summary suffix "X là gì tóm tắt" / "tóm tắt về X"
	for _, sf := range []string{" tóm tắt", " overview", " nói ngắn"} {
		if strings.HasSuffix(lo, sf) {
			subj := strings.TrimRight(strings.TrimSpace(lo[:len(lo)-len(sf)]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["summary_subject"] = subj; return IntentSummary }
		}
	}


	// Why — "tại sao X" / "vì sao X" / "why does X" / "nguyên nhân X"
	for _, wp := range []string{"tại sao ", "vì sao ", "tại sao lại ", "why does ", "why is ", "why are ", "why do ", "why did ", "nguyên nhân ", "lý do "} {
		if strings.HasPrefix(lo, wp) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(wp):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["why_subject"] = subj
				return IntentWhy
			}
		}
	}
	// Why suffix pattern "X xảy ra vì sao?"
	for _, sf := range []string{" xảy ra vì sao", " là vì sao", " xảy ra tại sao"} {
		if strings.HasSuffix(lo, sf) {
			subj := strings.TrimRight(strings.TrimSpace(lo[:len(lo)-len(sf)]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["why_subject"] = subj; return IntentWhy }
		}
	}
	// ExplainDeep — "giải thích chi tiết X" / "deep dive into X"
	for _, ep := range []string{"giải thích chi tiết ", "deep dive into ", "deep dive ", "phân tích sâu ", "explain in detail ", "explain deeply ", "elaborate on ", "phân tích kỹ ", "đi sâu vào "} {
		if strings.HasPrefix(lo, ep) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(ep):]), "?!. ")
			if len([]rune(subj)) >= 2 { slots["deep_subject"] = subj; return IntentExplainDeep }
		}
	}

	// Explain — "tại sao", "vì sao", "như thế nào", "giải thích", "nghĩa là gì"
	explainTriggers := []string{
		"tại sao", "vì sao", "why",
		"như thế nào", "thế nào", "how",
		"giải thích", "explain",
		"nghĩa là gì", "có nghĩa", "what is", "what does",
		"có phải", "có không", "có đúng",
	}
	for _, t := range explainTriggers {
		if strings.Contains(lo, t) {
			slots["explain_question"] = lo
			// Strip trigger word khỏi subject để tránh match nhầm
			// "giải thích cung cầu" → subject = "cung cầu"
			stripped := strings.TrimSpace(strings.Replace(lo, t, "", 1))
			stripped = strings.TrimLeft(stripped, " 	")
			if stripped != "" {
				slots["explain_subject"] = stripped
			} else {
				slots["explain_subject"] = lo
			}
			return IntentExplain
		}
	}

	// PathQuery — "X liên quan đến Y như thế nào?" / "kết nối giữa X và Y"
	pathPats := []string{
		" liên quan đến ", " kết nối với ", " liên quan gì đến ",
		" có quan hệ gì với ", " ảnh hưởng đến ", " connect to ",
		" related to ", " path to ",
	}
	for _, pat := range pathPats {
		if idx := strings.Index(lo, pat); idx > 0 {
			nodeA := strings.TrimSpace(lo[:idx])
			nodeB := strings.TrimSpace(lo[idx+len(pat):])
			nodeB = strings.TrimRight(nodeB, "?!. ")
			for _, suf := range []string{" không", " phải không", " chứ", " nhỉ", " hả", " ha"} {
				nodeB = strings.TrimSuffix(nodeB, suf)
			}
			nodeB = strings.TrimSpace(nodeB)
			if nodeA != "" && nodeB != "" && nodeA != nodeB {
				slots["path_a"] = nodeA
				slots["path_b"] = nodeB
				return IntentPathQuery
			}
		}
	}

	// Related — "liên quan đến X", "X có liên quan gì", "nói thêm về X", "khám phá X"
	relatedTriggers := []string{
		"liên quan đến", "liên quan tới", "liên quan với",
		"có liên quan", "nói thêm về", "nói thêm",
		"khám phá", "explore", "related to",
		"xung quanh", "context của", "silk walk",
	}
	for _, t := range relatedTriggers {
		if strings.Contains(lo, t) {
			// Tách subject — phần sau trigger
			for _, t2 := range relatedTriggers {
				if idx := strings.Index(lo, t2); idx >= 0 {
					subj := strings.TrimSpace(lo[idx+len(t2):])
					if subj != "" {
						slots["related_subject"] = subj
					}
					break
				}
			}
			if slots["related_subject"] == "" {
				slots["related_subject"] = lo
			}
			return IntentRelated
		}
	}

	// Quiz — "đố tôi về X" / "hỏi tôi về Y" / "quiz X"
	quizPats := []struct{ pref string }{
		{"đố tôi về "},
		{"đố tôi "},
		{"hỏi tôi về "},
		{"hỏi tôi "},
		{"quiz tôi về "},
		{"quiz me on "},
		{"quiz me about "},
		{"test me on "},
		{"flash card "},
		{"flashcard "},
	}
	for _, qp := range quizPats {
		if strings.HasPrefix(lo, qp.pref) {
			subject := strings.TrimRight(strings.TrimSpace(lo[len(qp.pref):]), "?!. ")
			if len([]rune(subject)) >= 2 {
				slots["quiz_subject"] = subject
				return IntentQuiz
			}
		}
	}
	// "đố" đứng một mình → quiz về random
	if lo == "đố tôi" || lo == "quiz" || lo == "flashcard" {
		slots["quiz_subject"] = ""
		return IntentQuiz
	}

	// Synonym — "X còn gọi là gì?" / "tên khác của X" / "synonyms of X"
	synoPats := []struct{ pref string }{
		{"còn gọi là gì "},
		{"tên khác của "},
		{"synonyms of "},
		{"synonym of "},
		{"alias of "},
		{"còn được gọi là "},
		{"nghĩa tương đương "},
		{"tương đương với "},
	}
	for _, sp := range synoPats {
		if strings.HasPrefix(lo, sp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(sp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["synonym_subject"] = subj
				return IntentSynonym
			}
		}
	}
	// Pattern: "X còn gọi là gì?" (subject đứng trước)
	for _, suf := range []string{" còn gọi là gì", " tên khác là gì", " có nghĩa là gì khác",
		" là gì theo nghĩa khác", " còn được gọi là gì"} {
		if strings.HasSuffix(lo, suf) {
			subj := strings.TrimRight(strings.TrimSpace(lo[:len(lo)-len(suf)]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["synonym_subject"] = subj
				return IntentSynonym
			}
		}
	}
	// Pattern: "còn gọi là gì X" (subject đứng sau)
	for _, pref2 := range []string{"còn gọi là gì ", "tên khác của gì "} {
		if strings.HasPrefix(lo, pref2) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(pref2):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["synonym_subject"] = subj
				return IntentSynonym
			}
		}
	}

	// Convert — "đổi X sang Y" / "convert X to Y"
	convertPats := []struct{ pref, sep string }{
		{"đổi ", " sang "},
		{"convert ", " to "},
		{"chuyển đổi ", " sang "},
		{"chuyển ", " thành "},
	}
	for _, cp := range convertPats {
		if strings.HasPrefix(lo, cp.pref) {
			rest := lo[len(cp.pref):]
			idx := strings.Index(rest, cp.sep)
			if idx > 0 {
				from := strings.TrimSpace(rest[:idx])
				to   := strings.TrimRight(strings.TrimSpace(rest[idx+len(cp.sep):]), "?!. ")
				if len([]rune(from)) >= 2 && len([]rune(to)) >= 1 {
					slots["convert_from"] = from
					slots["convert_to"]   = to
					return IntentConvert
				}
			}
		}
	}

	// Rank — "X tốt hơn Y không?" / "so sánh X và Y về Z" / "rank X vs Y"
	rankPats := []struct{ sep string }{
		{" tốt hơn "},
		{" hay "},
		{" vs "},
		{" versus "},
		{" better than "},
		{" so với "},
		{" hoặc "},
	}
	for _, rp := range rankPats {
		if idx := strings.Index(lo, rp.sep); idx > 0 {
			before := strings.TrimRight(strings.TrimSpace(lo[:idx]), "?!. ")
			after  := strings.TrimRight(strings.TrimSpace(lo[idx+len(rp.sep):]), "?!. ")
			// Loại bỏ "không?" và các đuôi ở cuối after
			for _, suf := range []string{" không", " tốt hơn", " better", " hơn"} {
				if strings.HasSuffix(after, suf) {
					after = strings.TrimRight(after[:len(after)-len(suf)], " ")
				}
			}
			// Loại bỏ "không?" ở cuối trước
			before = strings.TrimRight(before, " ?!")
			if len([]rune(before)) >= 2 && len([]rune(after)) >= 2 {
				slots["rank_a"] = before
				slots["rank_b"] = after
				return IntentRank
			}
		}
	}

	// Debate — "pros and cons of X" / "tranh luận về X" / "lợi hại của X"
	debatePats := []struct{ pref string }{
		{"pros and cons of "},
		{"pros cons "},
		{"lợi và hại của "},
		{"lợi hại của "},
		{"tranh luận về "},
		{"mặt tốt xấu của "},
		{"ưu nhược điểm "},
		{"advantages disadvantages "},
		{"debate about "},
		{"ưu điểm nhược điểm "},
	}
	for _, dp := range debatePats {
		if strings.HasPrefix(lo, dp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(dp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["debate_subject"] = subj
				return IntentDebate
			}
		}
	}
	// Pattern: "X có lợi hại gì?" (subject đứng trước)
	for _, suf := range []string{" có lợi hại gì", " ưu nhược điểm là gì", " uu nhuoc diem la gi", " pros cons là gì", " có ưu điểm gì", " có nhược điểm gì"} {
		if strings.HasSuffix(lo, suf) {
			subj := strings.TrimRight(strings.TrimSpace(lo[:len(lo)-len(suf)]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["debate_subject"] = subj
				return IntentDebate
			}
		}
	}

	// Trend — "xu hướng X" / "tương lai của X" / "trend in X"
	trendPats := []struct{ pref string }{
		{"xu hướng "},
		{"tương lai của "},
		{"tương lai "},
		{"trend in "},
		{"trends in "},
		{"future of "},
		{"outlook for "},
		{"trien vong "},
		{"dự báo "},
		{"triển vọng "},
		{"triển vọng của "},
	}
	for _, tp := range trendPats {
		if strings.HasPrefix(lo, tp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(tp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["trend_subject"] = subj
				return IntentTrend
			}
		}
	}

	// Example — "ví dụ về X" / "cho tôi ví dụ X" / "example of X"
	exPats := []struct{ pref string }{
		{"ví dụ về "},
		{"cho tôi ví dụ "},
		{"ví dụ "},
		{"example of "},
		{"give me an example of "},
		{"examples of "},
		{"lấy ví dụ "},
		{"举例 "},
	}
	for _, ep := range exPats {
		if strings.HasPrefix(lo, ep.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(ep.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["example_subject"] = subj
				return IntentExample
			}
		}
	}

	// Biography — "tiểu sử X" / "biography of X" / "X là ai"
	bioPats := []struct{ pref string }{
		{"tiểu sử "},
		{"biography of "},
		{"bio of "},
		{"life of "},
		{"who was "},
		{"cuộc đời "},
		{"cuộc đời của "},
		{"thân thế "},
	}
	for _, bp := range bioPats {
		if strings.HasPrefix(lo, bp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(bp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["bio_subject"] = subj
				return IntentBiography
			}
		}
	}

	// Timeline — "lịch sử X" / "quá trình hình thành X" / "history of X"
	timelinePats := []struct{ pref string }{
		{"lịch sử "},
		{"quá trình "},
		{"quá trình hình thành "},
		{"timeline "},
		{"history of "},
		{"evolution of "},
		{"sự phát triển của "},
		{"hành trình "},
	}
	for _, tp := range timelinePats {
		if strings.HasPrefix(lo, tp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(tp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["timeline_subject"] = subj
				return IntentTimeline
			}
		}
	}

	// Fact — "X có bao nhiêu..." / "khi nào X..." / "ai là..." / "how many"
	factKeywords := []struct{ pref, slot string }{
		{"có bao nhiêu ", "fact_subject"},
		{"bao nhiêu ", "fact_subject"},
		{"khi nào ", "fact_subject"},
		{"ai là ", "fact_subject"},
		{"ai đã ", "fact_subject"},
		{"tại sao ", "fact_subject"},
		{"ở đâu ", "fact_subject"},
		{"how many ", "fact_subject"},
		{"when was ", "fact_subject"},
		{"who is ", "fact_subject"},
		{"where is ", "fact_subject"},
		{"how far ", "fact_subject"},
		{"năm nào ", "fact_subject"},
	}
	for _, fk := range factKeywords {
		if strings.HasPrefix(lo, fk.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(fk.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots[fk.slot] = subj
				slots["fact_question"] = fk.pref
				return IntentFact
			}
		}
	}

	// Search — "tìm kiếm X" / "tìm X" / "search X"
	searchPats := []struct{ pref string }{
		{"tìm kiếm "},
		{"tìm "},
		{"search for "},
		{"search "},
		{"tra cứu "},
		{"lookup "},
	}
	for _, sp := range searchPats {
		if strings.HasPrefix(lo, sp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(sp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["search_subject"] = subj
				return IntentSearch
			}
		}
	}

	// Related — "liên quan đến X" / "related to X" / "kết nối với X"
	relPats := []struct{ pref string }{
		{"liên quan đến "},
		{"liên quan tới "},
		{"kết nối với "},
		{"gần với "},
		{"related to "},
		{"connected to "},
		{"links to "},
		{"liên kết với "},
	}
	for _, rp := range relPats {
		if strings.HasPrefix(lo, rp.pref) {
			subj := strings.TrimRight(strings.TrimSpace(lo[len(rp.pref):]), "?!. ")
			if len([]rune(subj)) >= 2 {
				slots["related_subject"] = subj
				return IntentRelated
			}
		}
	}

	// HowTo — "cách X" / "làm thế nào để Y" / "how to Z"
	howtoPats := []struct{ pref string }{
		{"cách "},
		{"làm thế nào để "},
		{"làm sao để "},
		{"làm sao để "},
		{"how to "},
		{"how do i "},
		{"hướng dẫn "},
		{"bước để "},
		{"quy trình "},
	}
	for _, hp := range howtoPats {
		if strings.HasPrefix(lo, hp.pref) {
			subject := strings.TrimSpace(lo[len(hp.pref):])
			subject = strings.TrimRight(subject, "?!. ")
			if len([]rune(subject)) >= 2 {
				slots["howto_subject"] = subject
				return IntentHowTo
			}
		}
	}

	// List — "liệt kê các X" / "các loại Y" / "ví dụ về Z" / "kể tên"
	listPats := []struct{ pref string }{
		{"liệt kê "},
		{"các loại "},
		{"các dạng "},
		{"ví dụ về "},
		{"kể tên "},
		{"các ví dụ về "},
		{"list "},
		{"examples of "},
		{"types of "},
		{"categories of "},
	}
	for _, lp := range listPats {
		if strings.HasPrefix(lo, lp.pref) {
			subject := strings.TrimSpace(lo[len(lp.pref):])
			subject = strings.TrimRight(subject, "?!. ")
			if len([]rune(subject)) >= 2 {
				slots["list_subject"] = subject
				return IntentList
			}
		}
	}

	// Compare — "so sánh X và Y" / "X khác Y"
	comparePats := []struct{ pref, mid string }{
		{"so sánh ", " và "},
		{"so sánh ", " với "},
		{"", " khác gì so với "},
		{"", " khác với "},
		{"", " giống và khác "},
		{"", " vs "},
		{"phân biệt ", " và "},
		{"phân biệt ", " với "},
	}
	for _, cp := range comparePats {
		lo2 := lo
		if cp.pref != "" {
			if !strings.HasPrefix(lo2, cp.pref) { continue }
			lo2 = lo2[len(cp.pref):]
		}
		if midIdx := strings.Index(lo2, cp.mid); midIdx > 0 {
			nodeA := strings.TrimSpace(lo2[:midIdx])
			nodeB := strings.TrimSpace(lo2[midIdx+len(cp.mid):])
			nodeB = strings.TrimRight(nodeB, "?!. ")
			if nodeA != "" && nodeB != "" && nodeA != nodeB {
				slots["cmp_a"] = nodeA
				slots["cmp_b"] = nodeB
				return IntentCompare
			}
		}
	}

	// IntentParagraph — đoạn văn dài (>80 rune, nhiều câu)
	// Detect trước QueryNode để tránh bị search toàn câu
	loRunes := []rune(lo)
	if len(loRunes) > 80 && (strings.Count(lo, " ") > 8 || strings.ContainsAny(lo, ".\n,;")) {
		slots["paragraph_text"] = lo
		return IntentParagraph
	}

	// IntentStatement — câu cảm thán / nói một mình
	// Dấu hiệu: có adj/adv mức độ ("thật X", "X quá", "X ghê") mà KHÔNG có dấu hỏi
	if !strings.ContainsAny(lo, "?？") && isSentimentPhrase(lo) {
		slots["statement_text"] = lo
		return IntentStatement
	}

	return IntentQueryNode
}

// ─── ProcessISL — xử lý input thuần ISL (không có string) ────
//
// Đây là hàm "não thật sự" — nhận ISL, trả ISL.
// Text/audio/image chỉ là encoding ở biên giao tiếp.
// Bên trong hệ thống: chỉ có ISL addresses và silk walks.
//
// Luồng:
//   PerceptMessage{Primary, Intent, Context}
//       ↓
//   Intersect(Primary + Context) → candidate addresses
//       ↓
//   Walk(Intent) → action
//       ↓
//   PerceptMessage{response}