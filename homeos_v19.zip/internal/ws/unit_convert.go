// unit_convert.go — Đổi đơn vị thực tế
// "100 USD sang VND" / "5 km to miles" / "30 độ C sang F"
package ws

import (
	"fmt"
	"math"
	"strconv"
	"strings"
)

// tryUnitConvert — parse "số đơn_vị" → đổi sang đơn_vị_đích
// Trả về (kết quả, true) nếu parse được
func tryUnitConvert(from, to, lang string) (string, bool) {
	// Parse: from = "100 usd" hoặc "100" (số) + to = "vnd" (đơn vị)
	val, fromUnit := parseValueUnit(from)
	_, toUnit := parseValueUnit(to)

	// Nếu from không có số → thử to có số, from là đơn vị
	if math.IsNaN(val) {
		val2, toUnit2 := parseValueUnit(to)
		if !math.IsNaN(val2) {
			val = val2; toUnit = toUnit2; fromUnit = strings.ToLower(strings.TrimSpace(from))
		}
	}
	if math.IsNaN(val) { return "", false }
	if fromUnit == "" || toUnit == "" { return "", false }

	result, unit, ok := convert(val, fromUnit, toUnit)
	if !ok { return "", false }

	fromDisplay := formatNum(val) + " " + unitDisplay(fromUnit)
	toDisplay   := formatNum(result) + " " + unitDisplay(unit)

	if lang == "vi" {
		return fmt.Sprintf("**%s** = **%s**", fromDisplay, toDisplay), true
	}
	return fmt.Sprintf("**%s** = **%s**", fromDisplay, toDisplay), true
}

func parseValueUnit(s string) (float64, string) {
	s = strings.TrimSpace(strings.ToLower(s))
	// Tìm số ở đầu
	i := 0
	for i < len(s) && (s[i] >= '0' && s[i] <= '9' || s[i] == '.' || s[i] == ',' || s[i] == '-') {
		i++
	}
	numStr := strings.ReplaceAll(s[:i], ",", "")
	unit   := strings.TrimSpace(s[i:])
	if numStr == "" { return math.NaN(), unit }
	val, err := strconv.ParseFloat(numStr, 64)
	if err != nil { return math.NaN(), unit }
	return val, unit
}

// convert — bảng đổi đơn vị
func convert(val float64, from, to string) (float64, string, bool) {
	type Rule struct {
		from, to string
		fn       func(float64) float64
	}

	// Chuẩn hoá alias
	alias := map[string]string{
		"usd":"usd","$":"usd","dollar":"usd","dollars":"usd",
		"vnd":"vnd","đồng":"vnd","dong":"vnd","vn":"vnd",
		"eur":"eur","euro":"eur","euros":"eur","€":"eur",
		"gbp":"gbp","pound":"gbp","pounds":"gbp","£":"gbp",
		"jpy":"jpy","yen":"jpy","¥":"jpy",
		"cny":"cny","yuan":"cny","rmb":"cny",
		"thb":"thb","baht":"thb",
		"sgd":"sgd",
		"krw":"krw","won":"krw",

		"km":"km","kilometre":"km","kilometres":"km","kilometer":"km","kilometers":"km",
		"m":"m","metre":"m","metres":"m","meter":"m","meters":"m",
		"cm":"cm","centimetre":"cm","centimeter":"cm",
		"mm":"mm","millimetre":"mm","millimeter":"mm",
		"mile":"mile","miles":"mile","mi":"mile",
		"yard":"yard","yards":"yard","yd":"yard",
		"foot":"foot","feet":"foot","ft":"foot",
		"inch":"inch","inches":"inch","in":"inch",
		"nm":"nm","nautical mile":"nm","nautical miles":"nm",

		"kg":"kg","kilogram":"kg","kilograms":"kg","kilo":"kg",
		"g":"g","gram":"g","grams":"g",
		"lb":"lb",
		"oz":"oz","ounce":"oz","ounces":"oz",
		"ton":"ton","tonne":"ton","tonnes":"ton","tấn":"ton",

		"°c":"°c","celsius":"°c","c":"°c","độ c":"°c","do c":"°c",
		"°f":"°f","fahrenheit":"°f","f":"°f","độ f":"°f",
		"k":"k","kelvin":"k",

		"l":"l","litre":"l","litres":"l","liter":"l","liters":"l","lít":"l",
		"ml":"ml","millilitre":"ml","milliliter":"ml",
		"gal":"gal","gallon":"gal","gallons":"gal",
		"fl oz":"fl_oz","fluid ounce":"fl_oz",

		"km/h":"km/h","kph":"km/h","kmh":"km/h",
		"m/s":"m/s","mps":"m/s",
		"mph":"mph","miles per hour":"mph",
		"knot":"knot","knots":"knot","kn":"knot",

		"j":"j","joule":"j","joules":"j",
		"kj":"kj","kilojoule":"kj",
		"cal":"cal","calorie":"cal","calories":"cal",
		"kcal":"kcal","kilocalorie":"kcal","kilocalories":"kcal",
		"kwh":"kwh","kilowatt hour":"kwh",

		"w":"w","watt":"w","watts":"w",
		"kw":"kw","kilowatt":"kw",
		"mw":"mw","megawatt":"mw",
		"hp":"hp","horsepower":"hp","mã lực":"hp",

		"pa":"pa","pascal":"pa",
		"kpa":"kpa","kilopascal":"kpa",
		"bar":"bar",
		"atm":"atm","atmosphere":"atm",
		"psi":"psi",

		"bit":"bit","bits":"bit",
		"byte":"byte","bytes":"byte","b":"byte",
		"kb":"kb","kilobyte":"kb","kilobytes":"kb",
		"mb":"mb","megabyte":"mb","megabytes":"mb",
		"gb":"gb","gigabyte":"gb","gigabytes":"gb",
		"tb":"tb","terabyte":"tb","terabytes":"tb",
		"pb":"pb","petabyte":"pb",

		"s":"s","second":"s","seconds":"s","giây":"s",
		"min":"min","minute":"min","minutes":"min","phút":"min",
		"h":"h","hour":"h","hours":"h","giờ":"h","gio":"h",
		"day":"day","days":"day","ngày":"day","ngay":"day",
		"week":"week","weeks":"week","tuần":"week",
		"month":"month","months":"month","tháng":"month",
		"year":"year","years":"year","năm":"year",
	}

	f := func(s string) string {
		if v, ok := alias[s]; ok { return v }
		return s
	}
	from = f(from); to = f(to)

	// Tỷ giá tham khảo (2026-03)
	// USD base
	fxToUSD := map[string]float64{
		"usd":1.0, "vnd":1.0/25450, "eur":1.0/0.92, "gbp":1.0/0.79,
		"jpy":1.0/149.5, "cny":1.0/7.24, "thb":1.0/35.1,
		"sgd":1.0/1.34, "krw":1.0/1320,
	}
	if fromUSD, ok1 := fxToUSD[from]; ok1 {
		if toUSD, ok2 := fxToUSD[to]; ok2 {
			return val * fromUSD / toUSD, to, true
		}
	}

	// Length → metre base
	toMetre := map[string]float64{
		"km":1000,"m":1,"cm":0.01,"mm":0.001,
		"mile":1609.344,"yard":0.9144,"foot":0.3048,"inch":0.0254,"nm":1852,
	}
	if fm, ok1 := toMetre[from]; ok1 {
		if tm, ok2 := toMetre[to]; ok2 {
			return val * fm / tm, to, true
		}
	}

	// Mass → gram base
	toGram := map[string]float64{
		"kg":1000,"g":1,"lb":453.592,"oz":28.3495,"ton":1e6,
	}
	if fg, ok1 := toGram[from]; ok1 {
		if tg, ok2 := toGram[to]; ok2 {
			return val * fg / tg, to, true
		}
	}

	// Temperature
	if from == "°c" && to == "°f" { return val*9/5 + 32, "°f", true }
	if from == "°f" && to == "°c" { return (val-32)*5/9, "°c", true }
	if from == "°c" && to == "k"  { return val + 273.15, "k", true }
	if from == "k"  && to == "°c" { return val - 273.15, "°c", true }
	if from == "°f" && to == "k"  { return (val-32)*5/9 + 273.15, "k", true }
	if from == "k"  && to == "°f" { return (val-273.15)*9/5 + 32, "°f", true }

	// Volume → ml base
	toML := map[string]float64{
		"l":1000,"ml":1,"gal":3785.41,"fl_oz":29.5735,
	}
	if fv, ok1 := toML[from]; ok1 {
		if tv, ok2 := toML[to]; ok2 {
			return val * fv / tv, to, true
		}
	}

	// Speed → m/s base
	toMS := map[string]float64{
		"m/s":1,"km/h":1.0/3.6,"mph":0.44704,"knot":0.514444,
	}
	if fs, ok1 := toMS[from]; ok1 {
		if ts, ok2 := toMS[to]; ok2 {
			return val * fs / ts, to, true
		}
	}

	// Energy → joule base
	toJ := map[string]float64{
		"j":1,"kj":1000,"cal":4.184,"kcal":4184,"kwh":3.6e6,
	}
	if fe, ok1 := toJ[from]; ok1 {
		if te, ok2 := toJ[to]; ok2 {
			return val * fe / te, to, true
		}
	}

	// Power → watt base
	toW := map[string]float64{"w":1,"kw":1000,"mw":1e6,"hp":745.7}
	if fp, ok1 := toW[from]; ok1 {
		if tp, ok2 := toW[to]; ok2 {
			return val * fp / tp, to, true
		}
	}

	// Pressure → Pa base
	toPa := map[string]float64{"pa":1,"kpa":1000,"bar":1e5,"atm":101325,"psi":6894.76}
	if fp2, ok1 := toPa[from]; ok1 {
		if tp2, ok2 := toPa[to]; ok2 {
			return val * fp2 / tp2, to, true
		}
	}

	// Data → byte base
	toByte := map[string]float64{
		"bit":0.125,"byte":1,"kb":1024,"mb":1024*1024,
		"gb":1024*1024*1024,"tb":1024*1024*1024*1024,"pb":1024*1024*1024*1024*1024,
	}
	if fd, ok1 := toByte[from]; ok1 {
		if td, ok2 := toByte[to]; ok2 {
			return val * fd / td, to, true
		}
	}

	// Time → second base
	toSec := map[string]float64{
		"s":1,"min":60,"h":3600,"day":86400,
		"week":604800,"month":2629800,"year":31557600,
	}
	if ft, ok1 := toSec[from]; ok1 {
		if tt, ok2 := toSec[to]; ok2 {
			return val * ft / tt, to, true
		}
	}

	return 0, "", false
}

func formatNum(v float64) string {
	if v == math.Trunc(v) && v < 1e12 {
		return fmt.Sprintf("%d", int64(v))
	}
	if math.Abs(v) >= 1e9 { return fmt.Sprintf("%.2f", v) }
	if math.Abs(v) >= 1000 { return fmt.Sprintf("%.2f", v) }
	if math.Abs(v) >= 1    { return fmt.Sprintf("%.4g", v) }
	return fmt.Sprintf("%.6g", v)
}

func unitDisplay(u string) string {
	display := map[string]string{
		"usd":"USD","vnd":"VND","eur":"EUR","gbp":"GBP",
		"jpy":"JPY","cny":"CNY","thb":"THB","sgd":"SGD","krw":"KRW",
		"km":"km","m":"m","cm":"cm","mm":"mm","mile":"mile","yard":"yard",
		"foot":"ft","inch":"in","nm":"nm",
		"kg":"kg","g":"g","lb":"lb","oz":"oz","ton":"tấn",
		"°c":"°C","°f":"°F","k":"K",
		"l":"L","ml":"mL","gal":"gallon","fl_oz":"fl oz",
		"km/h":"km/h","m/s":"m/s","mph":"mph","knot":"knot",
		"j":"J","kj":"kJ","cal":"cal","kcal":"kcal","kwh":"kWh",
		"w":"W","kw":"kW","mw":"MW","hp":"HP",
		"pa":"Pa","kpa":"kPa","bar":"bar","atm":"atm","psi":"psi",
		"bit":"bit","byte":"byte","kb":"KB","mb":"MB","gb":"GB","tb":"TB","pb":"PB",
		"s":"giây","min":"phút","h":"giờ","day":"ngày","week":"tuần","month":"tháng","year":"năm",
	}
	if v, ok := display[u]; ok { return v }
	return u
}
