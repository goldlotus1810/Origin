// internal/ws/vocab_loader.go
// VocabLoader — đọc Intent/Location/Device keywords từ homeos.olang nodes
// Thay thế toàn bộ hardcode matchAny() trong brain.go

package ws

import (
	"encoding/binary"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"os"
	"strings"
)

// dnaText — lấy phần text của DNA, skip b[0]=STATE|TYPE header nếu có.
// NODE_Spec: b[0] = STATE(2bit)|TYPE(6bit). TYPE=TEXT(0x06) → b[1..] là text.
// Các TYPE khác cũng có thể chứa text payload — skip b[0] an toàn.
func dnaText(raw string) string {
	if len(raw) == 0 { return raw }
	b0 := raw[0]
	state := b0 & 0xC0
	typ   := b0 & 0x3F
	// Nếu b[0] là STATE|TYPE hợp lệ → skip (không phải text content)
	if (state == 0x00 || state == 0x40 || state == 0x80) && typ <= 0x06 {
		return raw[1:]
	}
	return raw
}

type VocabLoader struct {
	intents   map[string][]string  // tag → []keyword
	locations map[string][]string  // id  → []keyword
	devices   map[string][]string  // id  → []keyword
	patterns  map[string]*PatternNode // tag → PatternNode
	// config nodes
	LayerInfer  map[string][]string // "l2_nature"→[], "l4_object"→[], "default"→["7"]
	DeviceIcon  map[string]string   // device_id → icon emoji
	ActuatorDef map[string]string   // "device"→"light", "location"→"living_room"
	// dynamic vocab từ olang L3-L5 nodes — tự động khi seed thêm
	dynL3  map[string]uint8  // label/vi term → layer 3 (sinh/hóa/lý/toán/địa/lịch sử)
	dynL5  map[string]uint8  // label/vi term → layer 5
}

func NewVocabLoader(olangPath string) *VocabLoader {
	v := &VocabLoader{
		intents:     map[string][]string{},
		locations:   map[string][]string{},
		devices:     map[string][]string{},
		patterns:    map[string]*PatternNode{},
		LayerInfer:  map[string][]string{},
		DeviceIcon:  map[string]string{},
		ActuatorDef: map[string]string{"device": "light", "location": "living_room"},
		dynL3:       map[string]uint8{},
		dynL5:       map[string]uint8{},
	}
	v.load(olangPath)
	v.buildDynamic(olangPath) // phase 2: đọc L3-L5 labels
	return v
}

func (v *VocabLoader) load(path string) {
	raw, err := os.ReadFile(path)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil { return }

	for off := 0; off+20 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		base := off; off += 3
		if off+17 > len(raw) { break }
		off += 12 // ISL(8)+cp(4)
		dnaLen  := int(binary.BigEndian.Uint32(raw[off:])); off += 4
		nameLen := int(raw[off]); off++
		end := off + dnaLen + nameLen
		if end > len(raw) { off = base+1; break }
		dna  := string(raw[off : off+dnaLen]); off += dnaLen
		name := string(raw[off : off+nameLen]); off += nameLen
		txt  := dnaText(dna) // strip b[0]=STATE|TYPE header
		if !strings.Contains(txt, "=") { continue }

		p := parseDNAKV(txt)
		kws := func(key string) []string {
			var out []string
			for _, s := range strings.Split(p[key], ",") {
				if s = strings.TrimSpace(s); s != "" { out = append(out, strings.ToLower(s)) }
			}
			return out
		}

		switch {
		case name == "LAYER_INFER":
			p := parseDNAKV(txt)
			for k, val := range p { v.LayerInfer[k] = splitTrim(val, ",") }

		case name == "DEVICE_ICON":
			p := parseDNAKV(txt)
			for k, val := range p { v.DeviceIcon[k] = val }

		case name == "ACTUATOR_DEFAULTS":
			p := parseDNAKV(txt)
			for k, val := range p { v.ActuatorDef[k] = val }

		case strings.HasPrefix(name, "INTENT_") && strings.HasSuffix(name, "_PAT"):
			tag := p["tag"]
			if tag == "" { continue }
			pats   := splitTrim(p["patterns"], ",")
			guards := splitTrim(p["question_guard"], ",")
			v.patterns[tag] = &PatternNode{Tag: tag, Patterns: pats, QuestionGuard: guards}

		case strings.HasPrefix(name, "INTENT_"):
			tag := p["tag"]
			if tag == "" { continue }
			all := append(kws("vi"), kws("en")...)
			if len(all) > 0 { v.intents[tag] = append(v.intents[tag], all...) }

		case strings.HasPrefix(name, "LOCATION_"):
			id := p["id"]
			if id == "" { continue }
			all := append(kws("vi"), kws("en")...)
			if len(all) > 0 { v.locations[id] = append(v.locations[id], all...) }

		case strings.HasPrefix(name, "DEVICE_"):
			id := p["id"]
			if id == "" { continue }
			all := append(kws("vi"), kws("en")...)
			if len(all) > 0 { v.devices[id] = append(v.devices[id], all...) }
		}
	}
}

// HasIntent kiểm tra xem input có khớp tag intent không
func (v *VocabLoader) HasIntent(lo, tag string) bool {
	for _, kw := range v.intents[tag] {
		if wordBoundaryMatch(lo, kw) { return true }
	}
	return false
}

// wordBoundaryMatch — substring match cho kw dài, word-exact cho kw ngắn (≤3 ký tự)
func wordBoundaryMatch(s, kw string) bool {
	if !strings.Contains(s, kw) { return false }
	if len([]rune(kw)) > 3 { return true } // dài → substring OK
	// Ngắn → phải là từ đứng riêng
	idx := strings.Index(s, kw)
	for idx >= 0 {
		before := idx == 0 || !isWordChar(rune(s[idx-1]))
		after  := idx+len(kw) >= len(s) || !isWordChar(rune(s[idx+len(kw)]))
		if before && after { return true }
		idx = strings.Index(s[idx+1:], kw)
		if idx >= 0 { idx += strings.Index(s, kw) + 1 } // re-anchor (simplified)
		break // tránh vòng lặp phức tạp — chỉ check lần đầu
	}
	return false
}


// ParseLocation trả về location id từ input ("all", "living_room", "bedroom", ...)
func (v *VocabLoader) ParseLocation(lo string) string {
	for _, kw := range v.locations["all"] {
		if strings.Contains(lo, kw) { return "all" }
	}
	for id, kws := range v.locations {
		if id == "all" { continue }
		for _, kw := range kws {
			if strings.Contains(lo, kw) { return id }
		}
	}
	return ""
}

// ParseDevice trả về device id từ input ("light", "hvac", "lock")
func (v *VocabLoader) ParseDevice(lo string) string {
	for id, kws := range v.devices {
		for _, kw := range kws {
			if strings.Contains(lo, kw) { return id }
		}
	}
	return ""
}

// DisplayLocation trả về tên hiển thị tiếng Việt từ location id
func (v *VocabLoader) DisplayLocation(id string) string {
	kws := v.locations[id]
	if len(kws) > 0 { return kws[0] } // từ đầu tiên trong vi= là tên hiển thị
	return id
}

// DisplayDevice trả về tên hiển thị tiếng Việt từ device id
func (v *VocabLoader) DisplayDevice(id string) string {
	kws := v.devices[id]
	if len(kws) > 0 { return kws[0] }
	return id
}

func actionVI(a string) string {
	switch a {
	case "on":     return "bật"
	case "off":    return "tắt"
	case "toggle": return "chuyển trạng thái"
	}
	return a
}

// GetPattern trả về PatternNode theo tag (đã load lúc khởi tạo)
func (v *VocabLoader) GetPattern(tag string) *PatternNode {
	return v.patterns[tag]
}

// ─── Pattern nodes — INTENT_*_PAT ─────────────────────────────

// PatternNode — prefix patterns để extract slot value
type PatternNode struct {
	Tag           string
	Patterns      []string // prefix — phần sau = slot value
	QuestionGuard []string // nếu slot chứa từ này → không phải lệnh
}

func splitTrim(s, sep string) []string {
	var out []string
	for _, p := range strings.Split(s, sep) {
		if p != "" { out = append(out, p) }
	}
	return out
}

// buildDynamic — phase 2: đọc tất cả L3/L5 nodes từ olang
// Bổ sung label/vi terms vào dynL3/dynL5 để InferLayerID dùng động
// Khi seed thêm domain mới → tự động nhận diện KHÔNG cần sửa code
func (v *VocabLoader) buildDynamic(path string) {
	// Thay thế hardcode prefix map bằng đọc layer trực tiếp từ byte trong file.
	// Layer byte cả node đ㴭ng xác - không cần đoán qua prefix.
	raw, err := os.ReadFile(path)
	if err != nil { return }

	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }

	for off := 0; off+20 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		base := off; off += 2
		layer := raw[off]; off++
		off += 12 // ISL(8)+cp(4)
		if off+5 > len(raw) { break }
		dnaLen  := int(binary.BigEndian.Uint32(raw[off:])); off += 4
		nameLen := int(raw[off]); off++
		end := off + dnaLen + nameLen
		if end > edgeStart { off = base+1; continue }
		dna  := string(raw[off : off+dnaLen]); off += dnaLen
		off += nameLen

		// Chỉ index L3 (Life/Khảo sát) và L5 (Programming/Language)
		if layer != 3 && layer != 5 { continue }
		txt := dnaText(dna) // strip b[0]=STATE|TYPE header
		if !strings.Contains(txt, "label=") { continue }

		p := parseDNAKV(txt)
		terms := []string{}
		if lbl := strings.TrimSpace(p["label"]); lbl != "" {
			terms = append(terms, strings.ToLower(lbl))
		}
		for _, t := range strings.Split(p["vi"], ",") {
			if t = strings.TrimSpace(t); t != "" {
				terms = append(terms, strings.ToLower(t))
			}
		}
		for _, t := range strings.Split(p["en"], ",") {
			if t = strings.TrimSpace(t); t != "" {
				terms = append(terms, strings.ToLower(t))
			}
		}
		for _, term := range terms {
			if len(term) < 3 { continue }
			if layer == 5 {
				v.dynL5[term] = 5
			} else {
				v.dynL3[term] = layer
			}
		}
	}
}

func (v *VocabLoader) InferLayerID(key, value string) uint8 {
	kLow := strings.ToLower(strings.TrimSpace(key))
	vLow := strings.ToLower(strings.TrimSpace(value))
	combined := kLow + " " + vLow
	padded := " " + combined + " "
	kPad := " " + kLow + " "

	// ── 0. DYNAMIC vocab từ olang nodes (ưu tiên cao nhất) ─────────
	for term, lyr := range v.dynL5 {
		if kLow == term || strings.HasPrefix(kLow, term+" ") { return lyr }
	}
	for term, lyr := range v.dynL3 {
		if kLow == term || strings.HasPrefix(kLow, term+" ") ||
			strings.Contains(kPad, " "+term+" ") { return lyr }
	}


	// ── 1. L3 key sinh học chính xác ──────────────────────────
	l3bioKeys := []string{
		"quang hợp","diệp lục","lục lạp","hô hấp","tiến hóa",
		"tế bào","bào quan","sinh vật","thực vật","động vật",
		"gen ","adn","dna","photosynthesis","chlorophyll","chloroplast",
		"cellulose","glucose","protein","enzyme","vitamin","hormone","kháng thể",
		"polysaccharide","tinh bột","chất xơ","dinh dưỡng",
		"sinh thái","loài thực","loài động",
	}
	for _, w := range l3bioKeys {
		if kLow == w || kLow == strings.TrimSpace(w) ||
			strings.HasPrefix(kLow, w) || strings.Contains(kPad, " "+w+" ") {
			return 3
		}
	}
	for _, w := range v.LayerInfer["l3_life"] {
		if strings.Contains(kPad, " "+w+" ") || kLow == w { return 3 }
	}

	// ── 2. L5 ngôn ngữ học — key chính xác ───────────────────
	l5langKeys := []string{
		"danh từ","động từ","tính từ","trạng từ","đại từ","liên từ",
		"giới từ","mạo từ","thán từ","hạn định từ","số từ",
		"thì quá khứ","thì hiện tại","thì tương lai",
		"thể tiếp diễn","thể hoàn thành","thể bị động","thể chủ động",
		"câu hỏi","câu trần thuật","câu mệnh lệnh","câu cảm thán",
		"câu đơn","câu ghép","câu phức","câu điều kiện","câu bị động",
		"mệnh đề","chủ ngữ","vị ngữ","tân ngữ","bổ ngữ","định ngữ",
		"ẩn dụ","hoán dụ","thành ngữ","kết hợp từ","từ đồng nghĩa",
		"từ trái nghĩa","từ đồng âm","đa nghĩa","hàm ngôn","tiền giả định",
		"ngữ cảnh","lịch sự","ngôn phong","phong cách ngôn ngữ",
		"ngữ điệu","trọng âm","âm vị","âm tiết","hình vị",
		"tiền tố","hậu tố","từ gốc","từ ghép","từ vay mượn","từ mới","uyển ngữ",
		"văn tường thuật","văn miêu tả","văn nghị luận","văn thuyết minh",
		"tiếng anh","tiếng việt","tiếng trung","tiếng nhật","tiếng hàn",
		"tiếng pháp","tiếng đức","tiếng nga","tiếng ả rập","tiếng tây ban nha",
		"tiếng bồ đào nha","tiếng hindi",
		"noun","verb","adjective","adverb","pronoun","preposition","conjunction",
		"grammar","syntax","semantics","pragmatics","phoneme","morpheme",
		"metaphor","idiom","collocation","discourse",
		"ngôn ngữ học","từ loại","ngữ pháp","cú pháp","ngữ nghĩa","ngữ dụng",
	}
	for _, w := range l5langKeys {
		if kLow == w || kPad == " "+w+" " || strings.HasPrefix(kLow, w+" ") {
			return 5
		}
	}

	// ── 3. L5 lập trình/AI ────────────────────────────────────
	l5prog := []string{
		"agent","skill","isl","silk","node","graph","tree","api","http","code",
		"algorithm","database","server","network","protocol","binary",
		"machine learning","neural","training","inference","leoai","homeos",
	}
	for _, w := range l5prog {
		if strings.Contains(combined, w) { return 5 }
	}

	// ── 4. L4 thiết bị — key-based ───────────────────────────
	l4keyWords := []string{
		"đèn ","đèn led","đèn điện","tủ lạnh","máy lạnh","máy giặt",
		"điện thoại","máy tính","tivi","máy in","router","loa ","camera",
		"cửa ","xe hơi","xe máy","xe đạp","ô tô","máy bay",
		"bàn ","ghế ","giường ","tủ ","kệ ",
		"lamp","appliance","device","machine","phone","computer","furniture",
	}
	for _, w := range l4keyWords {
		if strings.HasPrefix(kLow, w) || strings.Contains(kPad, " "+w) {
			return 4
		}
	}
	for _, w := range v.LayerInfer["l4_object"] {
		if strings.Contains(kPad, " "+w+" ") || kLow == w { return 4 }
	}

	// ── 5. L3 sinh học trong combined ─────────────────────────
	l3exact := []string{
		"sinh vật","thực vật","động vật","tế bào","bào quan",
		"diệp lục","lục lạp","quang hợp","hô hấp","tiến hóa",
		"protein","enzyme","vitamin","hormone","kháng thể",
		"cảm xúc","tình cảm","con người","trẻ em","người lớn","xã hội","văn hóa",
		"plant","animal","organism","photosynthesis","biology","species",
		"chlorophyll","chloroplast","emotion","feeling","evolution",
	}
	for _, w := range l3exact {
		if strings.Contains(combined, w) { return 3 }
	}
	l3single := []string{
		" cây "," hoa "," lá "," rễ "," thân "," cỏ "," rêu ",
		" ăn "," uống "," ngủ "," thở "," chạy "," nhảy "," bơi "," bay ",
		" yêu "," ghét "," vui "," buồn "," sợ "," giận ",
		" organism "," life "," living "," growth ",
	}
	for _, w := range l3single {
		if strings.Contains(padded, w) { return 3 }
	}

	// ── 6a. L6 key-level check (trước L2 để tránh false positive) ──
	l6keyCheck := []string{
		"màu đỏ","màu xanh","màu vàng","màu trắng","màu đen","màu hồng",
		"màu tím","màu cam","màu nâu","màu xám","màu sắc",
		"âm thanh","tiếng ồn","mùi hương","vị giác",
		"cảm giác","xúc giác","thị giác","thính giác","khứu giác",
		"nóng bỏng","lạnh buốt","ấm áp","mát mẻ","mềm mại",
		"bước sóng","quang phổ",
		"color","sound","smell","taste","touch","vision","sensation","spectrum","wavelength",
	}
	for _, w := range l6keyCheck {
		if kLow == w || strings.HasPrefix(kLow, w+" ") || kPad == " "+w+" " { return 6 }
	}
// ── 6. L2 thiên nhiên — word-boundary ────────────────────
	// KHÔNG dùng substring "quang","sóng" — gây false positive
	for _, w := range v.LayerInfer["l2_nature"] {
		if strings.Contains(padded, " "+w+" ") { return 2 }
	}
	l2exact := []string{
		" ánh sáng "," nước "," lửa "," gió "," nhiệt "," điện "," đất ",
		" mưa "," nắng "," tuyết "," bão "," lũ "," sét ",
		" áp suất "," nhiệt độ "," độ ẩm ",
		" light "," water "," fire "," wind "," heat "," rain "," snow ",
	}
	for _, w := range l2exact {
		if strings.Contains(padded, w) { return 2 }
	}
	l2keyOnly := []string{
		"nước","lửa","gió","đất","ánh sáng","mưa","nắng","tuyết","bão","sét",
		"nóng","lạnh","khô","ẩm","sáng","tối",
	}
	for _, w := range l2keyOnly {
		if kLow == w { return 2 }
	}

	// ── 7b. L6 cảm giác / tri giác — combined ────────────────────
	l6words := []string{
		"màu sắc","màu đỏ","màu xanh","màu vàng","màu trắng","màu đen",
		"màu hồng","màu tím","màu cam","màu nâu","màu xám",
		"bước sóng","quang phổ","âm thanh","tiếng ồn","mùi hương","vị giác",
		"cảm giác","xúc giác","thị giác","thính giác","khứu giác",
		"nóng bỏng","lạnh buốt","ấm áp","mát mẻ","mềm mại",
		"color","wavelength","spectrum","sound","smell","taste","touch","vision","sensation",
	}
	for _, w := range l6words {
		if strings.Contains(combined, w) { return 6 }
	}
	l6colors := []string{" đỏ "," xanh "," vàng "," trắng "," đen "," hồng "," tím "," cam "," nâu "," xám "}
	for _, w := range l6colors {
		if strings.Contains(padded, w) { return 6 }
	}

	return 7 // L7 default
}
// DeviceIconFor trả về icon emoji cho device id
func (v *VocabLoader) DeviceIconFor(device string) string {
	if icon, ok := v.DeviceIcon[device]; ok { return icon }
	if def, ok := v.DeviceIcon["default"]; ok { return def }
	return "⚡"
}
