// internal/ws/brain_query_knowledge_queries_—_pathquery,_whynode,_explaindeep,_factnode,_definenode,_explainnode.go
// Knowledge queries — pathQuery, whyNode, explainDeep, factNode, defineNode, explainNode

package ws

import (
	"fmt"
	"strings"
)

func (b *Brain) pathQuery(queryA, queryB, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	// Tìm 2 node đầu/cuối
	nodeA := b.nodeLookup.Search(queryA)
	nodeB := b.nodeLookup.Search(queryB)
	if nodeA == nil {
		if ex := extractQuerySubject(queryA); ex != "" { nodeA = b.nodeLookup.Search(ex) }
	}
	if nodeB == nil {
		if ex := extractQuerySubject(queryB); ex != "" { nodeB = b.nodeLookup.Search(ex) }
	}
	if nodeA == nil && nodeB == nil {
		return b.resp("unknown", fmt.Sprintf("Không tìm thấy '%s' và '%s'.", queryA, queryB))
	}
	if nodeA == nil { return b.explainNode(queryB, queryB, lang) }
	if nodeB == nil { return b.explainNode(queryA, queryA, lang) }
	if nodeA.Name == nodeB.Name {
		_, hops := b.nodeLookup.SearchAndWalk(nodeA.Label, 3)
		return b.resp("know", b.nodeLookup.NaturalSentence(nodeA, hops))
	}

	// BFS tìm path ngắn nhất — lưu cả edge label
	type pathEdge struct {
		node *KnownNode
		rel  string // edge type symbol
	}
	type step struct {
		node  *KnownNode
		edges []pathEdge // chuỗi node+rel từ gốc
	}
	visited := map[string]bool{nodeA.Name: true}
	queue := []step{{nodeA, []pathEdge{{nodeA, ""}}}}
	var foundEdges []pathEdge

	for depth := 0; depth < 4 && len(queue) > 0 && foundEdges == nil; depth++ {
		var nextQ []step
		for _, cur := range queue {
			// Dùng adjCache thay SearchAndWalk để BFS nhanh O(1) per node
			curHops := b.nodeLookup.HopsFromCache(cur.node.ISLU)
			for _, h := range curHops {
				if h.Node == nil || h.Depth != 1 { continue }
				if visited[h.Node.Name] { continue }
				visited[h.Node.Name] = true
				rel := h.TypeSym
				if rel == "" { rel = "→" }
				newEdges := append(append([]pathEdge{}, cur.edges...), pathEdge{h.Node, rel})
				if h.Node.Name == nodeB.Name { foundEdges = newEdges; break }
				nextQ = append(nextQ, step{h.Node, newEdges})
			}
			if foundEdges != nil { break }
		}
		queue = nextQ
	}

	// Format kết quả với edge labels
	if foundEdges == nil {
		msg := fmt.Sprintf("**%s** và **%s** không có đường kết nối trực tiếp (depth ≤ 4).", nodeA.Label, nodeB.Label)
		if lang != "vi" {
			msg = fmt.Sprintf("No path found between **%s** and **%s** within depth 4.", nodeA.Label, nodeB.Label)
		}
		return b.resp("know", msg)
	}
	// Build path string: "A --[rel]--> B --[rel]--> C"
	var sb strings.Builder
	for i, pe := range foundEdges {
		if i == 0 {
			sb.WriteString("**" + pe.node.Label + "**")
		} else {
			if pe.rel != "" && pe.rel != "→" {
				sb.WriteString(" --[" + pe.rel + "]--> **" + pe.node.Label + "**")
			} else {
				sb.WriteString(" → **" + pe.node.Label + "**")
			}
		}
	}
	nSteps := len(foundEdges) - 1
	pathStr := sb.String()
	msg := fmt.Sprintf("Đường kết nối (%d bước):\n\n%s\n\n_%s_ và _%s_ liên quan nhau trong Silk Tree.",
		nSteps, pathStr, nodeA.Label, nodeB.Label)
	if lang != "vi" {
		msg = fmt.Sprintf("Connection path (%d steps):\n\n%s", nSteps, pathStr)
	}
	return b.resp("know", msg)
}


// listNodes — liệt kê các node liên quan đến subject
// "liệt kê các năng lượng tái tạo" → solar · wind · hydro · ...
// "các loại cảm xúc" → vui · buồn · sợ · tức · ...
// quizNode — tạo câu hỏi flashcard về subject
// "đố tôi về AI" → câu hỏi trắc nghiệm / điền vào chỗ trống
// Format: Câu hỏi + 4 đáp án (A/B/C/D) hoặc điền chỗ trống
func (b *Brain) whyNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }
	var sb strings.Builder
	nl, nl2 := "\n", "\n\n"

	if lang == "vi" {
		sb.WriteString("❓ **Tại sao / Nguyên nhân: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("❓ **Why / Cause: " + node.Label + "**" + nl2)
	}

	// Desc = giải thích cốt lõi
	if node.Desc != "" {
		if lang == "vi" {
			sb.WriteString("**Bản chất:** " + node.Desc + nl2)
		} else {
			sb.WriteString("**Core explanation:** " + node.Desc + nl2)
		}
	}

	// Hops = yếu tố liên quan / nguyên nhân phụ
	if len(hops) > 0 {
		if lang == "vi" {
			sb.WriteString("**Các yếu tố / Nguyên nhân liên quan:**" + nl)
		} else {
			sb.WriteString("**Related factors / Causes:**" + nl)
		}
		for i, h := range hops {
			if h.Node == nil { continue }
			sb.WriteString("• **" + h.Node.Label + "**")
			if h.Node.Desc != "" {
				rr := []rune(h.Node.Desc)
				if len(rr) > 50 { rr = rr[:50] }
				sb.WriteString(" — " + string(rr) + "...")
			}
			sb.WriteString(nl)
			if i >= 3 { break }
		}
	}

	b.glowNode(node, hops)
	return b.resp("why", strings.TrimSpace(sb.String()))
}

// explainDeepNode — phân tích sâu, nhiều lớp hơn explain thông thường
func (b *Brain) explainDeepNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }
	// SilkWalk depth=4 (QT7: 不始猫私)
	_, hops = b.nodeLookup.SearchAndWalk(node.Label, 4)
	if len(hops) == 0 { hops = b.nodeLookup.HopsFromCache(node.ISLU) }
	var sb strings.Builder
	nl, nl2 := "\n", "\n\n"
	domain := b.nodeLookup.DomainLabel(node.Name)

	if lang == "vi" {
		sb.WriteString("🔬 **Phân tích sâu: " + node.Label + "**")
		if domain != "" { sb.WriteString("  _" + domain + "_") }
		sb.WriteString(nl2)
	} else {
		sb.WriteString("🔬 **Deep Dive: " + node.Label + "**")
		if domain != "" { sb.WriteString("  _" + domain + "_") }
		sb.WriteString(nl2)
	}

	// Layer 1: Định nghĩa đầy đủ
	if node.Desc != "" {
		if lang == "vi" {
			sb.WriteString("**① Định nghĩa:** " + node.Desc + nl2)
		} else {
			sb.WriteString("**① Definition:** " + node.Desc + nl2)
		}
	}

	// Layer 2: Các khái niệm cốt lõi liên quan (hops 0-2)
	if len(hops) >= 1 {
		if lang == "vi" {
			sb.WriteString("**② Khái niệm nền tảng:**" + nl)
		} else {
			sb.WriteString("**② Foundation concepts:**" + nl)
		}
		for i, h := range hops {
			if h.Node == nil || i > 2 { break }
			sb.WriteString("• **" + h.Node.Label + "**: " + h.Node.Desc + nl)
		}
		sb.WriteString(nl)
	}

	// Layer 3: Ứng dụng / mở rộng (hops 3-5)
	if len(hops) >= 4 {
		if lang == "vi" {
			sb.WriteString("**③ Ứng dụng & Mở rộng:**" + nl)
		} else {
			sb.WriteString("**③ Applications & Extensions:**" + nl)
		}
		for i := 3; i < len(hops) && i <= 5; i++ {
			h := hops[i]
			if h.Node == nil { continue }
			sb.WriteString("• **" + h.Node.Label + "**")
			if h.Node.Desc != "" {
				rr := []rune(h.Node.Desc)
				if len(rr) > 55 { rr = rr[:55] }
				sb.WriteString(": " + string(rr) + "...")
			}
			sb.WriteString(nl)
		}
	}

	b.glowNode(node, hops)
	return b.resp("deep", strings.TrimSpace(sb.String()))
}


func (b *Brain) factNode(subject, question, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	r := b.nodeLookup.Resolve(subject)
	node := r.Node
	if node == nil {
		// Fallback sang search
		return b.searchNodes(subject, lang)
	}

	hops := b.nodeLookup.HopsFromCache(node.ISLU)
	desc := node.Desc

	var sb strings.Builder
	qword := strings.TrimSpace(question)

	// Prefix thân thiện theo loại câu hỏi
	prefix := ""
	switch {
	case strings.Contains(qword, "bao nhiêu") || strings.Contains(qword, "how many") || strings.Contains(qword, "how far"):
		if lang == "vi" { prefix = "Về số lượng" } else { prefix = "Quantity" }
	case strings.Contains(qword, "khi nào") || strings.Contains(qword, "năm nào") || strings.Contains(qword, "when"):
		if lang == "vi" { prefix = "Thời điểm" } else { prefix = "When" }
	case strings.Contains(qword, "ai") || strings.Contains(qword, "who"):
		if lang == "vi" { prefix = "Người liên quan" } else { prefix = "Who" }
	case strings.Contains(qword, "ở đâu") || strings.Contains(qword, "where"):
		if lang == "vi" { prefix = "Vị trí" } else { prefix = "Where" }
	case strings.Contains(qword, "tại sao") || strings.Contains(qword, "why"):
		if lang == "vi" { prefix = "Lý do" } else { prefix = "Why" }
	default:
		if lang == "vi" { prefix = "Thông tin" } else { prefix = "Info" }
	}

	if lang == "vi" {
		sb.WriteString("**" + node.Label + "** — " + prefix + ":\n\n")
	} else {
		sb.WriteString("**" + node.Label + "** — " + prefix + ":\n\n")
	}

	if desc != "" {
		// Trả toàn bộ desc (đã compact, ≤200 ký tự)
		sb.WriteString(desc)
	} else {
		if lang == "vi" {
			sb.WriteString("(Chưa có dữ liệu chi tiết cho **" + node.Label + "**)")
		} else {
			sb.WriteString("(No detailed data for **" + node.Label + "**)")
		}
	}

	// Related
	if len(hops) > 0 {
		sb.WriteString("\n\n")
		labels := []string{}
		for _, h := range hops {
			if h.Node == nil { continue }
			labels = append(labels, "**"+h.Node.Label+"**")
			if len(labels) >= 3 { break }
		}
		if lang == "vi" {
			sb.WriteString("Xem thêm: " + strings.Join(labels, " · "))
		} else {
			sb.WriteString("See also: " + strings.Join(labels, " · "))
		}
	}

	b.glowNode(node, hops)
	return b.resp("fact", strings.TrimSpace(sb.String()))
}

// resolveSubject — helper dùng chung cho 15 query handlers
// Thay thế boilerplate: Resolve → check nil → HopsFromCache
// Trả về (node, hops, notFoundResp).
// Nếu notFoundResp.Tag != "" → caller return ngay.
func (b *Brain) defineNode(subject, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	node := b.nodeLookup.SearchExact(subject)
	if node == nil {
		node = b.nodeLookup.Search(subject)
	}
	if node == nil {
		if ex := extractQuerySubject(subject); ex != "" {
			node = b.nodeLookup.SearchExact(ex)
			if node == nil { node = b.nodeLookup.Search(ex) }
		}
	}
	if node == nil {
		// Thử SuggestSimilar
		sugg := b.nodeLookup.SuggestSimilar(subject, 3)
		if len(sugg) > 0 {
			labels := make([]string, len(sugg))
			for i, s := range sugg { labels[i] = "**" + s.Label + "**" }
			if lang == "vi" {
				return b.resp("suggest", "Ý bạn là: "+strings.Join(labels, " · ")+"?")
			}
			return b.resp("suggest", "Did you mean: "+strings.Join(labels, " · ")+"?")
		}
		if lang == "vi" {
			return b.resp("unknown", fmt.Sprintf("Chưa có định nghĩa cho **%s** trong Silk Tree.", subject))
		}
		return b.resp("unknown", fmt.Sprintf("No definition found for **%s**.", subject))
	}

	hops := b.nodeLookup.HopsFromCache(node.ISLU)
	nl2 := "\n\n"
	nl1 := "\n"
	var sb strings.Builder

	// Dòng 1: định nghĩa súc tích
	if lang == "vi" {
		sb.WriteString("**" + node.Label + "** là ")
		if node.Desc != "" {
			// Lấy câu đầu tiên của Desc (đến dấu '.' hoặc tối đa 120 ký tự)
			desc := node.Desc
			if idx := strings.Index(desc, "."); idx > 10 && idx < 150 {
				sb.WriteString(desc[:idx+1])
			} else {
				rr := []rune(desc); if len(rr) > 120 { rr = rr[:120] }
				sb.WriteString(string(rr) + "...")
			}
		} else {
			sb.WriteString("một khái niệm trong Silk Tree.")
		}
	} else {
		sb.WriteString("**" + node.Label + "**: ")
		if node.Desc != "" {
			rr := []rune(node.Desc); if len(rr) > 120 { rr = rr[:120] }
			sb.WriteString(string(rr) + "...")
		}
	}
	sb.WriteString(nl2)

	// Key facts từ hops depth=1
	if len(hops) > 0 {
		var related []string
		for _, h := range hops {
			if h.Node == nil { continue }
			related = append(related, h.Node.Label)
			if len(related) >= 4 { break }
		}
		if len(related) > 0 {
			if lang == "vi" {
				sb.WriteString("Liên quan: " + strings.Join(related, " · ") + nl1)
			} else {
				sb.WriteString("Related: " + strings.Join(related, " · ") + nl1)
			}
		}
	}

	b.glowNode(node, hops)
	return b.resp("know", strings.TrimSpace(sb.String()))
}


// compareNodes — so sánh 2 node: điểm chung (shared hops) + điểm khác (unique hops)
func (b *Brain) explainNode(subject, question, lang string) ChatResponse {
	// Ưu tiên search: subject (đã strip trigger) → extractQuerySubject → question raw
	// "giải thích cung cầu" → subject="cung cầu" (stripped từ detectIntent)
	// "tại sao vaccine quan trọng?" → extractQuerySubject → "vaccine"
	var node *KnownNode
	// 1. Subject đã được strip trigger trong detectIntent
	if subject != "" && subject != question {
		node = b.nodeLookup.Search(subject)
	}
	// 2. extractQuerySubject từ câu hỏi đầy đủ
	if node == nil {
		if extracted := extractQuerySubject(strings.ToLower(question)); extracted != "" {
			node = b.nodeLookup.Search(extracted)
		}
	}
	// 3. Raw question fallback
	if node == nil {
		node = b.nodeLookup.Search(question)
	}
	if node == nil {
		if lang == "vi" {
			return b.resp("unknown", fmt.Sprintf(
				"Tôi chưa có đủ tri thức để giải thích **%s**."+
				"\n\nThử hỏi trực tiếp: `%s`", subject, strings.Trim(subject, "?")))
		}
		return b.resp("unknown", fmt.Sprintf("No knowledge found for %s.", subject))
	}
	_, hops := b.nodeLookup.SearchAndWalk(node.Label, 4)
	b.glowNode(node, hops) // 🌟 SSE live glow
	answer := b.nodeLookup.NaturalExplain(node, hops, question)
	return b.resp("know", answer)
}

// ─── Helpers ───────────────────────────────────────────────────
