// internal/ws/brain_intent.go
// Tách từ brain.go — Respond() intent dispatch switch
// package ws — cùng package, truy cập Brain methods trực tiếp
//
// Quy tắc: mỗi Intent group = 1 case, delegate xuống method cụ thể
// Không chứa logic — chỉ route đến đúng handler

package ws

import (
	"fmt"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// dispatchIntent là switch chính của Respond()
// Tách ra để brain.go chỉ giữ pre-processing (emotion, multi-turn)
func (b *Brain) dispatchIntent(p ParsedInput) ChatResponse {
	switch p.Intent {

	// ── Actuator ───────────────────────────────────────────────
	case IntentActuator:
		cmd := &ActuatorCmd{
			Action:   p.Slots["actuator_action"],
			Device:   p.Slots["actuator_device"],
			Location: p.Slots["actuator_location"],
			Raw:      p.Lower,
		}
		success := false
		if b.s != nil {
			success = b.s.dispatchActuator(cmd)
		}
		return b.resp("actuator", b.actuatorResponse(cmd, success))

	// ── Meta ───────────────────────────────────────────────────
	case IntentGreeting:  return b.resp("greet", b.greet(p.Lang))
	case IntentFarewell:  return b.resp("bye", b.farewell(p.Lang))
	case IntentHelp:      return b.resp("help", b.help(p.Lang))
	case IntentIdentity:  return b.resp("identity", b.identity(p.Lang))
	case IntentQuerySelf: return b.resp("self", b.selfDesc(p.Lang))
	case IntentStatus:    return b.resp("status", b.status())
	case IntentReport:    return b.resp("report", b.report())
	case IntentEmotion:   return b.resp("emotion", b.emotionReport())
	case IntentListNodes: return b.resp("list", b.listNodes())
	case IntentQueryRule: return b.resp("rule", b.rules(p.Slots["rule"], p.Lang))

	case IntentNaming:
		name := p.Slots["name"]
		old := b.state.GetName()
		b.state.SetName(name)
		if p.Lang == "vi" {
			return b.resp("named", fmt.Sprintf(
				"✓ Tôi đã ghi nhớ. Từ nay bạn có thể gọi tôi là **%s**.\n\n_(trước đây: %s — đã lưu vào ĐN, chờ xác nhận → QR)_",
				name, old))
		}
		return b.resp("named", fmt.Sprintf(
			"✓ Noted. You can now call me **%s**.\n\n_(previously: %s — saved to ĐN, awaiting confirmation → QR)_",
			name, old))

	// ── Learn / Memory ─────────────────────────────────────────
	case IntentLearn:
		return b.handleLearnIntent(p)

	case IntentForget:
		sub := p.Slots["subject"]
		result := b.state.ForgetDN(sub)
		switch result {
		case "deleted":
			return b.resp("forget", fmt.Sprintf("✓ Đã xóa `%s` khỏi ĐN.", sub))
		case "notfound":
			return b.resp("forget", fmt.Sprintf("Không tìm thấy `%s` trong bộ nhớ.", sub))
		default:
			return b.resp("forget", fmt.Sprintf("**Không thể xóa `%s`** — đã là QR (bất biến theo QT3).", sub))
		}

	case IntentConfirm:
		return b.handleConfirmIntent(p)

	case IntentReject:
		return b.handleRejectIntent(p)

	// ── Query / Knowledge ──────────────────────────────────────
	case IntentCharLookup:  return b.lookupChar(p.Slots["char_query"], p.Lang)
	case IntentReason:      return b.reasonSilk(p.Slots["reason_query"], p.Lang)
	case IntentDefine:      return b.defineNode(p.Slots["define_subject"], p.Lang)
	case IntentExplain:
		subj := p.Slots["explain_subject"]
		q    := p.Slots["explain_question"]
		if subj == "" { subj = p.Raw }
		return b.explainNode(subj, q, p.Lang)
	case IntentSynonym:     return b.synonymNode(p.Slots["synonym_subject"], p.Lang)
	case IntentDebate:      return b.debateNode(p.Slots["debate_subject"], p.Lang)
	case IntentWhy:         return b.whyNode(p.Slots["why_subject"], p.Lang)
	case IntentExplainDeep: return b.explainDeepNode(p.Slots["deep_subject"], p.Lang)
	case IntentMnemonic:    return b.mnemonicNode(p.Slots["mnemonic_subject"], p.Lang)
	case IntentSummary:     return b.summaryNode(p.Slots["summary_subject"], p.Lang)
	case IntentTrend:       return b.trendNode(p.Slots["trend_subject"], p.Lang)
	case IntentRank:        return b.rankNode(p.Slots["rank_a"], p.Slots["rank_b"], p.Lang)
	case IntentConvert:     return b.convertNode(p.Slots["convert_from"], p.Slots["convert_to"], p.Lang)
	case IntentExample:     return b.exampleNode(p.Slots["example_subject"], p.Lang)
	case IntentBiography:   return b.bioNode(p.Slots["bio_subject"], p.Lang)
	case IntentTimeline:    return b.timelineNode(p.Slots["timeline_subject"], p.Lang)
	case IntentFact:        return b.factNode(p.Slots["fact_subject"], p.Slots["fact_question"], p.Lang)
	case IntentSearch:      return b.searchNodes(p.Slots["search_subject"], p.Lang)
	case IntentRelated:     return b.relatedNodes(p.Slots["related_subject"], p.Lang)
	case IntentQuiz:        return b.quizNode(p.Slots["quiz_subject"], p.Lang)
	case IntentHowTo:       return b.howToNode(p.Slots["howto_subject"], p.Lang)
	case IntentList:        return b.listNodesIntent(p.Slots["list_subject"], p.Lang)
	case IntentCompare:     return b.compareNodes(p.Slots["cmp_a"], p.Slots["cmp_b"], p.Lang)
	case IntentPathQuery:   return b.pathQuery(p.Slots["path_a"], p.Slots["path_b"], p.Lang)
	case IntentAsk:         return b.respondAsk(p)
	case IntentOpinion:     return b.respondOpinion(p)
	case IntentStatement:   return b.handleStatement(p)
	case IntentParagraph:   return b.handleParagraph(p)

	case IntentReadBook:
		path := p.Slots["book_path"]
		if path == "" {
			// Không có path → hiện danh sách sách đã đọc
			return b.resp("book", b.respondAboutBook(p.Lower, p.Lang))
		}
		return b.resp("book", b.loadBookFile(path, p.Lang))

	case IntentCalc:
		return b.resp("calc", b.calcExpr(p.Slots["expr"], p.Lang))

	case IntentWebFetch:
		return b.resp("web", b.webFetch(p.Slots["url"], p.Lang))

	default: // IntentQueryNode
		return b.queryNode(p)
	}
}

// handleLearnIntent xử lý IntentLearn — tách ra để Confirm/Reject dùng lại
func (b *Brain) handleLearnIntent(p ParsedInput) ChatResponse {
	val := p.Slots["value"]
	key, value := val, ""
	if idx := strings.Index(val, " là "); idx >= 0 {
		key   = strings.TrimSpace(val[:idx])
		value = strings.TrimSpace(val[idx+4:])
	} else if idx := strings.Index(val, " is "); idx >= 0 {
		key   = strings.TrimSpace(val[:idx])
		value = strings.TrimSpace(val[idx+4:])
	} else if idx := strings.Index(val, " = "); idx >= 0 {
		key   = strings.TrimSpace(val[:idx])
		value = strings.TrimSpace(val[idx+3:])
	}
	fire, promoted := b.state.Learn(key, value)
	b.lastLearned = key + " = " + value
	b.sendLearn(key, value, fire)
	layer := fmt.Sprintf("L%d", inferLayerForText(key, value))
	if p.Lang == "vi" {
		if promoted {
			return b.resp("qr", fmt.Sprintf(
				"✓ **ĐN → QR** (fire=%d): `%s`\n\n"+
				"→ Ghi vào **memory.olang** layer **%s**\n"+
				"→ Có ISL address, DNA bytecode, Silk edge\n"+
				"_QR bất biến theo QT3_", fire, val, layer))
		}
		return b.resp("learn", fmt.Sprintf(
			"✓ Ghi vào **ĐN** → homeos.olang (fire=%d/3):\n`%s`\n"+
			"Layer: **%s** · ISL: `%x`\n\n"+
			"_Thêm %d lần nữa → QR bất biến_",
			fire, val, layer, nameToISL(key), 3-fire))
	}
	if promoted {
		return b.resp("qr", fmt.Sprintf("✓ **ĐN→QR** (fire=%d): `%s` → homeos.olang [%s]", fire, val, layer))
	}
	return b.resp("learn", fmt.Sprintf("✓ ĐN (fire=%d/3): `%s` → homeos.olang [%s]", fire, val, layer))
}

// handleConfirmIntent xử lý IntentConfirm
func (b *Brain) handleConfirmIntent(p ParsedInput) ChatResponse {
	// Ưu tiên 1: pendingNew
	if b.pendingNew != nil {
		rawKey := b.pendingNew.Key
		lang   := b.pendingNew.Lang
		b.pendingNew = nil

		keys := strings.Split(rawKey, "|")
		if len(keys) > 1 {
			learned := []string{}
			for _, k := range keys {
				k = strings.TrimSpace(k)
				if k == "" { continue }
				fire, _ := b.state.Learn(k, "")
				b.sendLearn(k, "", fire)
				learned = append(learned, "**\""+k+"\""+"**")
			}
			b.lastLearned = keys[0] + " = "
			if lang == "vi" {
				return b.resp("learn", fmt.Sprintf(
					"✓ Đã ghi vào ĐN: %s\n\n💬 Dạy tôi thêm: `nhớ rằng [từ] là [mô tả]`",
					strings.Join(learned, ", ")))
			}
			return b.resp("learn", fmt.Sprintf("✓ Saved to ĐN: %s", strings.Join(learned, ", ")))
		}

		key := strings.TrimSpace(keys[0])
		fire, promoted := b.state.Learn(key, "")
		b.lastLearned = key + " = "
		b.sendLearn(key, "", fire)
		if lang == "vi" {
			if promoted {
				return b.resp("learn", fmt.Sprintf(
					"✓ Đã ghi **\"%s\"** vào QR!\n\nBổ sung: `nhớ rằng %s là [mô tả]`", key, key))
			}
			return b.resp("learn", fmt.Sprintf(
				"✓ Đã ghi **\"%s\"** vào ĐN (fire=%d/3).\n\n💬 Dạy tôi: `nhớ rằng %s là [mô tả]`",
				key, fire, key))
		}
		if promoted {
			return b.resp("learn", fmt.Sprintf("✓ **\"%s\"** saved to QR!", key))
		}
		return b.resp("learn", fmt.Sprintf("✓ **\"%s\"** saved to ĐN (fire=%d/3).", key, fire))
	}

	// Ưu tiên 2: lastLearned
	if b.lastLearned == "" {
		if p.Lang == "vi" {
			return b.resp("ok", "Xác nhận điều gì? Hãy nói với tôi điều bạn muốn tôi nhớ trước.")
		}
		return b.resp("ok", "Confirm what? Tell me something to learn first.")
	}
	var sdfKey [15]byte
	copy(sdfKey[:], []byte(b.lastLearned))
	h := isl.HashSDF(sdfKey)
	b.state.shortTerm.Confirm(h)
	var conf float64
	if obs, ok := b.state.shortTerm.GetByHash(h); ok { conf = obs.Confidence }
	b.sendConfirmMsg(b.lastLearned)
	if conf >= 0.8 { b.sendPropose(b.lastLearned) }
	if p.Lang == "vi" {
		suffix := ""
		if conf >= 0.8 { suffix = " → đã gửi **MsgPropose** → Dream cycle sẽ promote lên QR" }
		return b.resp("confirm", fmt.Sprintf("✓ Đã xác nhận `%s`\n\nĐộ tin cậy: **%.0f%%**%s",
			b.lastLearned, conf*100, suffix))
	}
	return b.resp("confirm", fmt.Sprintf("✓ Confirmed `%s` (confidence: %.0f%%)", b.lastLearned, conf*100))
}

// handleRejectIntent xử lý IntentReject (QT7 correction)
func (b *Brain) handleRejectIntent(p ParsedInput) ChatResponse {
	if b.pendingNew != nil {
		key  := b.pendingNew.Key
		lang := b.pendingNew.Lang
		b.pendingNew = nil
		if lang == "vi" {
			return b.resp("ok", fmt.Sprintf("Được, tôi sẽ không ghi nhớ **\"%s\"**.", key))
		}
		return b.resp("ok", fmt.Sprintf("Ok, I won't remember **\"%s\"**.", key))
	}
	if b.lastLearned == "" {
		if p.Lang == "vi" {
			return b.resp("ok", "Bác bỏ điều gì? Không có gì trong bộ nhớ gần đây.")
		}
		return b.resp("ok", "Reject what? Nothing in recent memory.")
	}
	var sdfKey2 [15]byte
	copy(sdfKey2[:], []byte(b.lastLearned))
	h2 := isl.HashSDF(sdfKey2)
	b.state.shortTerm.Reject(h2)
	key := b.lastLearned
	b.lastLearned = ""
	if p.Lang == "vi" {
		return b.resp("reject", fmt.Sprintf("✓ Đã xóa `%s` khỏi ĐN (QT7 correction).", key))
	}
	return b.resp("reject", fmt.Sprintf("✓ Removed `%s` from ĐN (correction).", key))
}
