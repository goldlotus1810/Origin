package ws
import "testing"
func TestDebugRun(t *testing.T) {
    nl := NewNodeLookup("../../homeos.olang")
    n := nl.Search("chạy")
    if n == nil { t.Fatal("not found"); return }
    t.Logf("name=%s layer=%d ISL=%x group_from_ISL=%d POS=%d",
        n.Name, n.LayerID, n.ISL, n.ISL[1], n.POS)
}
