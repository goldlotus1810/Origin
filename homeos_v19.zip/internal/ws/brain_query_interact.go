// internal/ws/brain_query_interactive_queries_—_quiz,_debate,_mnemonic,_summary.go
// Interactive queries — quiz, debate, mnemonic, summary

package ws

import (
	"strings"
)

func (b *Brain) quizNode(subject, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}

	var node *KnownNode
	if subject != "" {
		r := b.nodeLookup.Resolve(subject)
		node = r.Node
	}

	// Nếu không tìm được subject → chọn node chưa quiz
	if node == nil {
		for _, n := range b.nodeLookup.GetAllL3(10) {
			if b.convCtx == nil || !b.convCtx.IsQuizSeen(n.ISLU) {
				node = n; break
			}
		}
		if node == nil {
			// Đã quiz hết → reset và bắt đầu lại
			if b.convCtx != nil { b.convCtx.ResetQuizSeen() }
			for _, n := range b.nodeLookup.GetAllL3(5) {
				node = n; break
			}
		}
	}
	if node == nil {
		return b.resp("unknown", "Không tìm thấy chủ đề để đố.")
	}

	hops := b.nodeLookup.HopsFromCache(node.ISLU)

	// Tạo câu hỏi dựa trên Desc + hops
	var sb strings.Builder
	nl2 := "\n\n"
	nl1 := "\n"

	if lang == "vi" {
		sb.WriteString("🧠 **Câu đố về " + node.Label + ":**" + nl2)
		if node.Desc != "" {
			// Tạo câu hỏi fill-in-the-blank từ Desc
			desc := node.Desc
			words := strings.Fields(desc)
			if len(words) > 6 {
				// Che 1 từ quan trọng (từ thứ 3-5)
				hideIdx := 3
				if len(words) > 10 { hideIdx = 5 }
				hidden := words[hideIdx]
				words[hideIdx] = "___"
				question := strings.Join(words[:min(15, len(words))], " ")
				sb.WriteString("**Điền vào chỗ trống:**" + nl1)
				sb.WriteString("_" + question + "_" + nl2)
				sb.WriteString("💡 Gợi ý: từ bị che bắt đầu bằng **" + string([]rune(hidden)[:1]) + "**" + nl2)
				// Đáp án lấy từ hops
				var opts []string
				opts = append(opts, "**A.** "+hidden)
				for _, h := range hops {
					if h.Node == nil { continue }
					opts = append(opts, "**"+string(rune('A'+len(opts)))+".** "+h.Node.Label)
					if len(opts) >= 4 { break }
				}
				sb.WriteString(strings.Join(opts, nl1) + nl2)
				sb.WriteString("||Đáp án: **A. " + hidden + "**||")
			} else {
				// Câu hỏi đơn giản
				sb.WriteString("**" + node.Label + "** là gì?" + nl2)
				sb.WriteString("||Đáp án: " + desc + "||")
			}
		} else if len(hops) > 0 {
			// Câu hỏi về liên kết
			h := hops[0]
			if h.Node != nil {
				sb.WriteString("**" + node.Label + "** liên quan đến khái niệm nào?" + nl2)
				var opts []string
				opts = append(opts, "**A.** "+h.Node.Label)
				sugg := b.nodeLookup.SuggestSimilar(node.Label, 4)
				for _, s := range sugg {
					if s.Name == node.Name || s.Name == h.Node.Name { continue }
					opts = append(opts, "**"+string(rune('A'+len(opts)))+".** "+s.Label)
					if len(opts) >= 4 { break }
				}
				sb.WriteString(strings.Join(opts, nl1) + nl2)
				sb.WriteString("||Đáp án: **A. " + h.Node.Label + "**||")
			}
		} else {
			sb.WriteString("**" + node.Label + "** thuộc lĩnh vực nào?" + nl2)
			sb.WriteString("||Đáp án: " + b.nodeLookup.DomainLabel(node.Name) + "||")
		}
		sb.WriteString(nl2 + "_Nhắn 'đố thêm' để tiếp tục!_")
	} else {
		sb.WriteString("🧠 **Quiz: " + node.Label + "**" + nl2)
		if node.Desc != "" {
			words := strings.Fields(node.Desc)
			if len(words) > 6 {
				hideIdx := 3
				hidden := words[hideIdx]
				words[hideIdx] = "___"
				question := strings.Join(words[:min(15, len(words))], " ")
				sb.WriteString("_" + question + "_" + nl2)
				sb.WriteString("||Answer: " + hidden + "||")
			}
		}
		sb.WriteString(nl2 + "_Say 'more' to continue!_")
	}

	if b.convCtx != nil { b.convCtx.SetQuizNode(node) }
	b.glowNode(node, hops)
	return b.resp("quiz", strings.TrimSpace(sb.String()))
}

func min(a, b int) int { if a < b { return a }; return b }


// searchNodes — tìm kiếm nodes khớp subject, trả danh sách kết quả
// "tìm kiếm AI" → danh sách 5-8 kết quả có liên quan
// factNode — trả lời câu hỏi thực tế từ Desc node
// "khi nào Big Bang?" → tìm node Big Bang → extract năm/số từ Desc
// timelineNode — tạo timeline/lịch sử của subject
// "lịch sử AI" → các mốc phát triển từ Desc + hops có thứ tự
// bioNode — tiểu sử chi tiết về một nhân vật / chủ thể
// Khác timelineNode: tập trung vào người, không phải sự kiện
// exampleNode — trả ví dụ thực tế về X
// "ví dụ về AI" → Desc node + ví dụ từ hops liên quan
// synonymNode — tìm các tên gọi khác / thuật ngữ tương đương cho X
// rankNode — so sánh A và B, trình bày điểm mạnh/yếu từng bên
// debateNode — pros và cons của X, dùng hops để tạo context đa chiều
// whyNode — giải thích nguyên nhân / lý do tồn tại của X
func (b *Brain) debateNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }

	hops = b.nodeLookup.HopsFromCache(node.ISLU)

	var sb strings.Builder
	nl  := "\n"
	nl2 := "\n\n"

	if lang == "vi" {
		sb.WriteString("🗣️ **Tranh luận / Lợi hại: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("🗣️ **Pros & Cons: " + node.Label + "**" + nl2)
	}

	// Desc làm nền tảng
	if node.Desc != "" {
		if lang == "vi" {
			sb.WriteString("**Tổng quan:** " + node.Desc + nl2)
		} else {
			sb.WriteString("**Overview:** " + node.Desc + nl2)
		}
	}

	// Sinh pros/cons dựa trên hops + domain keywords
	pros := []*KnownNode{}
	cons := []*KnownNode{}
	proKW  := []string{"hiệu quả","nhanh","tốt","an toàn","bảo vệ","phát triển","học","sáng tạo","tự do","kết nối","tiết kiệm","tái tạo","bền vững","chính xác","mạnh","lợi"}
	consKW := []string{"rủi ro","nguy hiểm","phức tạp","tốn","mất","ô nhiễm","phá huỷ","thất nghiệp","bất bình đẳng","phụ thuộc","tác hại","lỗi","tấn công","sai","giới hạn","khó"}
	chasAny := func(s string, kw []string) bool {
		sl := strings.ToLower(s)
		for _, k := range kw { if strings.Contains(sl, k) { return true } }
		return false
	}
	for _, h := range hops {
		if h.Node == nil { continue }
		text := h.Node.Label + " " + h.Node.Desc
		if chasAny(text, proKW) {
			pros = append(pros, h.Node)
		} else if chasAny(text, consKW) {
			cons = append(cons, h.Node)
		} else if len(pros) <= len(cons) {
			pros = append(pros, h.Node)
		} else {
			cons = append(cons, h.Node)
		}
		if len(pros)+len(cons) >= 8 { break }
	}

	if lang == "vi" {
		sb.WriteString("**✅ Ưu điểm / Cơ hội:**" + nl)
	} else {
		sb.WriteString("**✅ Pros / Opportunities:**" + nl)
	}
	if len(pros) > 0 {
		for _, p := range pros {
			sb.WriteString("• " + p.Label)
			if p.Desc != "" {
				rr := []rune(p.Desc); if len(rr) > 40 { rr = rr[:40] }
				sb.WriteString(" — " + string(rr) + "...")
			}
			sb.WriteString(nl)
		}
	} else {
		sb.WriteString("_(Cần thêm dữ liệu để phân tích ưu điểm.)_" + nl)
	}
	sb.WriteString(nl)

	if lang == "vi" {
		sb.WriteString("**⚠️ Nhược điểm / Rủi ro:**" + nl)
	} else {
		sb.WriteString("**⚠️ Cons / Risks:**" + nl)
	}
	if len(cons) > 0 {
		for _, c := range cons {
			sb.WriteString("• " + c.Label)
			if c.Desc != "" {
				rr := []rune(c.Desc); if len(rr) > 40 { rr = rr[:40] }
				sb.WriteString(" — " + string(rr) + "...")
			}
			sb.WriteString(nl)
		}
	} else {
		if lang == "vi" {
			sb.WriteString("_(Xem xét thêm qua 'liên quan đến " + node.Label + "'.)_" + nl)
		} else {
			sb.WriteString("_(See 'related to " + node.Label + "' for more context.)_" + nl)
		}
	}

	b.glowNode(node, hops)
	return b.resp("debate", strings.TrimSpace(sb.String()))
}

// trendNode — xu hướng và tương lai của X
// mnemonicNode — tạo mẹo nhớ / mnemonic cho khái niệm X
func (b *Brain) mnemonicNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }
	var sb strings.Builder
	nl, nl2 := "\n", "\n\n"
	if lang == "vi" {
		sb.WriteString("🧠 **Mẹo nhớ: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("🧠 **Mnemonic: " + node.Label + "**" + nl2)
	}
	words := strings.Fields(node.Label)
	if len(words) >= 2 {
		acronym := ""
		for _, w := range words {
			rr := []rune(w)
			if len(rr) > 0 { acronym += strings.ToUpper(string(rr[0])) }
		}
		if lang == "vi" {
			sb.WriteString("**Viết tắt:** `" + acronym + "` = " + node.Label + nl2)
		} else {
			sb.WriteString("**Acronym:** `" + acronym + "` = " + node.Label + nl2)
		}
	}
	if node.Desc != "" {
		if lang == "vi" {
			sb.WriteString("**Điểm nhớ chính:** " + node.Desc + nl2)
		} else {
			sb.WriteString("**Key facts:** " + node.Desc + nl2)
		}
	}
	if len(hops) > 0 {
		if lang == "vi" { sb.WriteString("**Liên tưởng với:**" + nl) } else { sb.WriteString("**Associate with:**" + nl) }
		for i, h := range hops {
			if h.Node == nil { break }
			sb.WriteString("• " + h.Node.Label + nl)
			if i >= 2 { break }
		}
	}
	b.glowNode(node, hops)
	return b.resp("mnemonic", strings.TrimSpace(sb.String()))
}

// summaryNode — tóm tắt ngắn gọn về X
func (b *Brain) summaryNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }
	var sb strings.Builder
	nl, nl2 := "\n", "\n\n"
	domain := b.nodeLookup.DomainLabel(node.Name)
	if lang == "vi" {
		sb.WriteString("📋 **Tóm tắt: " + node.Label + "**")
	} else {
		sb.WriteString("📋 **Summary: " + node.Label + "**")
	}
	if domain != "" { sb.WriteString("  _" + domain + "_") }
	sb.WriteString(nl2)
	if node.Desc != "" { sb.WriteString(node.Desc + nl2) }
	if len(hops) > 0 {
		if lang == "vi" { sb.WriteString("**Liên quan:** ") } else { sb.WriteString("**Related:** ") }
		labels := []string{}
		for i, h := range hops {
			if h.Node == nil { continue }
			labels = append(labels, h.Node.Label)
			if i >= 2 { break }
		}
		sb.WriteString(strings.Join(labels, " · ") + nl)
	}
	b.glowNode(node, hops)
	return b.resp("summary", strings.TrimSpace(sb.String()))
}

