// internal/ws/qt_reader.go — QT1..QT7 từ homeos.olang nodes (không hardcode)

package ws

import (
	"encoding/binary"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"fmt"
	"os"
	"strings"
)

type QTContent struct {
	ID    int
	Name  string
	Title string
	Body  string
}

type QTReader struct {
	olangPath string
	content   map[int]QTContent
}

func NewQTReader(olangPath string) *QTReader {
	r := &QTReader{olangPath: olangPath, content: make(map[int]QTContent)}
	r.load()
	return r
}

func (r *QTReader) load() {
	raw, err := os.ReadFile(r.olangPath)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil { return }
	for off := 0; off+20 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		base := off; off += 3 // ND + layerID
		if off+17 > len(raw) { break }
		off += 12 // ISL(8) + cp(4)
		dnaLen  := int(binary.BigEndian.Uint32(raw[off:])); off += 4
		nameLen := int(raw[off]); off++
		end := off + dnaLen + nameLen
		if end > len(raw) { off = base+1; break }
		dna  := raw[off : off+dnaLen]; off += dnaLen
		name := string(raw[off : off+nameLen]); off += nameLen
		// QT*_DEF nodes — text DNA "tag=rule|n=N|title=...|body=..."
		if strings.HasPrefix(name, "QT") && strings.HasSuffix(name, "_DEF") {
			dnaStr := string(dna)
			if !strings.Contains(dnaStr, "tag=rule") { continue }
			p := parseDNAKV(dnaStr)
			n := atoiSafe(p["n"])
			if n < 1 || n > 9 { continue }
			r.content[n] = QTContent{ID: n, Name: fmt.Sprintf("QT%d", n), Title: p["title"], Body: p["body"]}
		}
	}
}

func (r *QTReader) Get(id int) (QTContent, bool) {
	c, ok := r.content[id]; return c, ok
}

func (r *QTReader) GetByName(name string) (QTContent, bool) {
	lo := strings.ToLower(strings.TrimSpace(name))
	for id := 1; id <= 9; id++ {
		if lo == fmt.Sprintf("qt%d", id) { return r.Get(id) }
	}
	return QTContent{}, false
}

func (r *QTReader) All() []QTContent {
	var out []QTContent
	for i := 1; i <= 9; i++ {
		if c, ok := r.Get(i); ok { out = append(out, c) }
	}
	return out
}

func (c QTContent) FormatOne() string {
	return fmt.Sprintf("**%s — %s**\n\n%s", c.Name, c.Title, c.Body)
}

func FormatAllQT(rules []QTContent) string {
	if len(rules) == 0 { return "_(QT nodes chưa load từ homeos.olang)_" }
	var sb strings.Builder
	sb.WriteString("**7 Quy Tắc của ○:**\n\n")
	for _, c := range rules {
		firstLine := strings.SplitN(c.Body, "·", 2)[0]
		sb.WriteString(fmt.Sprintf("**%s — %s**\n_%s_\n\n", c.Name, c.Title, strings.TrimSpace(firstLine)))
	}
	sb.WriteString("_Gõ `qt1`...`qt7` để xem chi tiết._")
	return sb.String()
}

func parseDNAKV(dna string) map[string]string {
	m := map[string]string{}
	for _, part := range strings.Split(dna, "|") {
		kv := strings.SplitN(part, "=", 2)
		if len(kv) == 2 { m[kv[0]] = kv[1] }
	}
	return m
}

func atoiSafe(s string) int {
	n := 0
	for _, c := range s {
		if c >= '0' && c <= '9' { n = n*10 + int(c-'0') }
	}
	return n
}
