// internal/ws/state.go
//
// State — toàn bộ runtime state của HomeOS
// NGUỒN SỰ THẬT DUY NHẤT: homeos.olang
//
// Không có file riêng. Không có JSON. Không có memory.olang.
// Mọi thứ đọc/ghi từ homeos.olang qua OlangAppendNode.
//
// State hiện tại giữ trong RAM (load từ .olang khi khởi động):
//   - Tên agent (AAM_NAME node trong L7)
//   - ĐN nodes (fire counts → homeos_learner.json TẠM THỜI)
//   - QR nodes (đã trong homeos.olang)

package ws

import (
	"crypto/sha256"
	"encoding/binary"
	"log"
	"os"
	"strings"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// State — runtime state, load từ .olang
type State struct {
	mu        sync.Mutex
	olangPath string

	// Tên agent — L7 node "AAM_NAME"
	name string

	// ĐN nodes — tạm thời trong Go map (legacy)
	// Khi fire >= 3: promote → OlangAppendNode → xóa khỏi đây
	dn     map[string]*dnEntry

	// shortTerm — memory.ShortTerm để sync với ClusterSkill/DreamSkill
	// Mọi Push vào dn đều sync vào đây
	shortTerm *memory.ShortTerm
	longTerm  *memory.LongTerm
}

type dnEntry struct {
	Key     string `json:"key"`
	Value   string `json:"value"`
	Fire    int    `json:"fire"`
	LayerID uint8  `json:"layer"`
	ISL     string `json:"isl"`
}

func NewState(olangPath string) *State {
	s := &State{
		olangPath: olangPath,
		name:      "Orio",
		dn:        make(map[string]*dnEntry),
		shortTerm: memory.NewShortTerm(512),
		longTerm:  memory.NewLongTerm(nil, nil), // default: no graph/ledger
	}
	s.load()
	return s
}

// WithShortTerm gắn ShortTerm từ bên ngoài (dùng cùng instance với ClusterSkill/DreamSkill)
func (s *State) WithShortTerm(st *memory.ShortTerm) *State {
	s.shortTerm = st
	return s
}

// WithLongTerm gắn LongTerm từ bên ngoài
func (s *State) WithLongTerm(lt *memory.LongTerm) *State {
	s.longTerm = lt
	return s
}

func (s *State) load() {
	// Đọc tên agent từ L7 "AAM_NAME" node
	// và load các ĐN nodes (fire < 3) từ L7
	raw, err := os.ReadFile(s.olangPath)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil {
		log.Printf("○ State: fresh start (%v)", err)
		return
	}
	for off := 0; off+14 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > len(raw) { break }
		lid := raw[off]; off++
		off += 8; off += 4
		dlen := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nlen := int(raw[off]); off++
		if off+dlen+nlen > len(raw) { break }
		if dlen > 4096 || nlen > 200 { off += dlen + nlen; continue } // skip corrupt
		dna  := raw[off : off+dlen]; off += dlen
		name := string(raw[off : off+nlen]); off += nlen

		if lid != 7 { continue }

		// AAM_NAME node → load tên
		if name == "AAM_NAME" && len(dna) >= 2 && dna[0] == 0x52 && dna[1] == 0xA0 {
			s.name = "Orio" // tên mặc định — DNA chứa hash để verify
			continue
		}

		// ĐN node: DNA[0]=0xD0 (DN_FLAG) + fire(1B) + key_h4(4B) + val_h4(4B)
		// Name format: "key = value"
		if len(dna) >= 2 && dna[0] == 0xD0 {
			fire := int(dna[1])
			if fire < 3 { // chưa promote
				parts := strings.SplitN(name, " = ", 2)
				key := name; val := ""
				if len(parts) == 2 { key = parts[0]; val = parts[1] }
				s.dn[key] = &dnEntry{Key: key, Value: val, Fire: fire}
			}
		}
	}
	log.Printf("○ State: loaded — name=%s ĐN=%d", s.name, len(s.dn))
}

func (s *State) save() {
	// No-op: mọi thứ đã trong homeos.olang
	// Fire counts ĐN ở RAM; khi promote → OlangAppendNode
}

// ── Tên agent ────────────────────────────────────────────────

func (s *State) GetName() string {
	s.mu.Lock(); defer s.mu.Unlock()
	return s.name
}

func (s *State) SetName(name string) {
	s.mu.Lock(); defer s.mu.Unlock()
	s.name = name
	s.save()
	// Ghi vào homeos.olang như L7 node
	isl := nameToISL("AAM_NAME")
	dna := nameToDNA("AAM_NAME", name)
	if err := OlangAppendNode(s.olangPath, 7, isl, 0, dna, "AAM_NAME="+name); err != nil {
		log.Printf("○ State: SetName append error: %v", err)
	}
}

// ── Learn (ĐN → QR) ─────────────────────────────────────────

// Learn nhận 1 điều học mới. Trả về (fire, promoted).
func (s *State) Learn(key, value string) (int, bool) {
	s.mu.Lock(); defer s.mu.Unlock()

	fullKey := key
	if value != "" {
		fullKey = key + " = " + value
	}

	e, exists := s.dn[fullKey]
	if !exists {
		isl := nameToISL(fullKey)
		e = &dnEntry{
			Key: fullKey, Value: value,
			Fire:    0,
			LayerID: inferLayerID(key, value),
			ISL:     islToHex(isl),
		}
		s.dn[fullKey] = e
		// Ghi ĐN node vào homeos.olang:
		// DNA = DN_FLAG(0xD0) + fire(0x01) + key_h4 + val_h4
		dna := dnDNA(fullKey, value, 1)
		if err := OlangAppendNode(s.olangPath, e.LayerID, isl, 0, dna, fullKey); err != nil {
			log.Printf("○ State: learn append error: %v", err)
		}
	}

	e.Fire++

	// Sync vào ShortTerm (để ClusterSkill/DreamSkill đọc được)
	if s.shortTerm != nil {
		addr := nameToISLAddr(fullKey)
		var sdfKey [15]byte
		copy(sdfKey[:], []byte(fullKey))
		s.shortTerm.Observe(memory.Observation{
			NodeHash:   isl.HashSDF(sdfKey),
			ISL:        addr,
			Data:       []byte(fullKey),
			Confidence: float64(e.Fire) / 3.0,
			Confirmed:  e.Fire,
		}, s.longTerm)
	}

	// QT7: fire >= 3 → promote QR
	if e.Fire >= 3 {
		log.Printf("○ State: ĐN→QR: %q (fire=%d)", fullKey, e.Fire)
		delete(s.dn, fullKey)
		// Node đã trong .olang từ lần đầu — không cần thêm lại
		return e.Fire, true
	}

	return e.Fire, false
}

// dnDNA tạo DNA cho ĐN node: DN_FLAG + fire + key_h4 + val_h4
func dnDNA(fullKey, value string, fire int) []byte {
	h := sha256.Sum256([]byte(fullKey))
	v := sha256.Sum256([]byte(value))
	return []byte{0xD0, byte(fire), h[0], h[1], h[2], h[3], v[0], v[1], v[2], v[3]}
}

// ForgetDN xóa 1 ĐN node. QR không xóa được.
func (s *State) ForgetDN(key string) string {
	s.mu.Lock(); defer s.mu.Unlock()
	if _, ok := s.dn[key]; ok {
		delete(s.dn, key)
		s.save()
		return "deleted"
	}
	return "notfound"
}

// Search tìm trong ĐN + QR (QR đọc từ .olang)
func (s *State) Search(query string) []string {
	s.mu.Lock(); defer s.mu.Unlock()
	lo    := strings.ToLower(query)
	loNorm := normalizeVi(query)
	var results []string

	// 1. ĐN RAM — match theo từ (word-level), không phải substring
	for k, e := range s.dn {
		// Lấy key (trước '=' nếu có)
		keyPart := e.Key
		if idx := strings.Index(e.Key, " = "); idx >= 0 {
			keyPart = e.Key[:idx]
		}
		if wordMatch(keyPart, lo) || wordMatch(normalizeVi(keyPart), loNorm) {
			results = append(results, "[ĐN] "+k)
		}
	}

	// 2. L7 QR trong homeos.olang
	raw, err := os.ReadFile(s.olangPath)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil { return results }
	for off := 0; off+14 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > len(raw) { break }
		layerID := raw[off]; off++
		off += 8; off += 4
		dnaLen  := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nameLen := int(raw[off]); off++
		if off+dnaLen+nameLen > len(raw) { break }
		dna  := raw[off:off+dnaLen]; off += dnaLen
		name := string(raw[off:off+nameLen]); off += nameLen

		if layerID != 7 { continue }
		if strings.HasPrefix(name, "INTENT_") || strings.HasPrefix(name, "QT") ||
			strings.HasPrefix(name, "AGENT_") || strings.HasPrefix(name, "WORLD_") { continue }
		if len(dna) < 2 { continue }

		nameLo := strings.ToLower(name)
		nameNorm := normalizeVi(name)
		if strings.Contains(nameLo, lo) || strings.Contains(nameNorm, loNorm) {
			results = append(results, "[QR] "+name)
		}
	}
	return results
}

func (s *State) DNCount() int {
	s.mu.Lock(); defer s.mu.Unlock(); return len(s.dn)
}

func (s *State) QRCount() int {
	return 0 // TODO: đọc từ homeos.olang L7 nodes
}

// ── Helpers ──────────────────────────────────────────────────

func islToHex(isl [8]byte) string {
	h := make([]byte, 16)
	const hx = "0123456789abcdef"
	for i, b := range isl {
		h[i*2]   = hx[b>>4]
		h[i*2+1] = hx[b&0xf]
	}
	return string(h)
}

func nameToISL(name string) [8]byte {
	h := sha256.Sum256([]byte(name))
	var isl [8]byte
	isl[0] = '7'
	isl[1] = 'A' + h[0]%26
	isl[2] = 'a' + h[1]%26
	isl[3] = h[2]%200 + 1
	copy(isl[4:], h[3:7])
	return isl
}

// nameToISLAddr trả về isl.Address để dùng với memory.ShortTerm
func nameToISLAddr(name string) isl.Address {
	h := sha256.Sum256([]byte(name))
	return isl.Address{
		Layer: 7,            // L7 Programs
		Group: h[0] % 26,
		Type:  h[1] % 26,
		ID:    h[2]%200 + 1,
	}
}

func nameToDNA(key, value string) []byte {
	kh := sha256.Sum256([]byte(key))
	vh := sha256.Sum256([]byte(value))
	dna := make([]byte, 10)
	dna[0] = 0x17
	copy(dna[1:5], kh[:4])
	dna[5] = 0x19
	copy(dna[6:10], vh[:4])
	return dna
}

// AllDN trả về toàn bộ ĐN nodes cho /api/memory
func (s *State) AllDN() map[string]interface{} {
	s.mu.Lock(); defer s.mu.Unlock()
	out := make(map[string]interface{}, len(s.dn))
	for k, e := range s.dn {
		out[k] = map[string]interface{}{
			"key": e.Key, "value": e.Value,
			"fire": e.Fire, "layer": e.LayerID,
		}
	}
	return out
}

// normalizeVi — bỏ dấu tiếng Việt để so sánh không phân biệt dấu
func normalizeVi(s string) string {
	r := strings.NewReplacer(
		"à","a","á","a","ả","a","ã","a","ạ","a",
		"ă","a","ắ","a","ằ","a","ẳ","a","ẵ","a","ặ","a",
		"â","a","ấ","a","ầ","a","ẩ","a","ẫ","a","ậ","a",
		"è","e","é","e","ẻ","e","ẽ","e","ẹ","e",
		"ê","e","ế","e","ề","e","ể","e","ễ","e","ệ","e",
		"ì","i","í","i","ỉ","i","ĩ","i","ị","i",
		"ò","o","ó","o","ỏ","o","õ","o","ọ","o",
		"ô","o","ố","o","ồ","o","ổ","o","ỗ","o","ộ","o",
		"ơ","o","ớ","o","ờ","o","ở","o","ỡ","o","ợ","o",
		"ù","u","ú","u","ủ","u","ũ","u","ụ","u",
		"ư","u","ứ","u","ừ","u","ử","u","ữ","u","ự","u",
		"ỳ","y","ý","y","ỷ","y","ỹ","y","ỵ","y",
		"đ","d",
	)
	return r.Replace(strings.ToLower(s))
}

// inferLayerID — đọc từ LAYER_INFER node trong homeos.olang
// Trả về 2 (nature), 4 (object), 7 (default)
func inferLayerID(key, value string) uint8 {
	// Dùng global vocab nếu có (set bởi Brain khi khởi động)
	if globalVocab != nil {
		return globalVocab.InferLayerID(key, value)
	}
	// Fallback tĩnh nếu vocab chưa load — delegate sang VocabLoader trống
	v := &VocabLoader{LayerInfer: map[string][]string{}}
	return v.InferLayerID(key, value)
}

// globalVocab — set bởi Brain.init(), dùng bởi inferLayerID
var globalVocab *VocabLoader

// wordMatch kiểm tra query có match 1 từ trong text không (word-level)
func wordMatch(text, query string) bool {
	if text == query { return true } // exact
	words := strings.Fields(text)
	for _, w := range words {
		if w == query { return true }
	}
	// Fallback: nếu query dài (≥4 ký tự) thì mới substring
	if len([]rune(query)) >= 4 {
		return strings.Contains(text, query)
	}
	return false
}
