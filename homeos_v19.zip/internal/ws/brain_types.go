// internal/ws/brain_types.go
// Brain struct, types, NewBrain

package ws

import (

	"github.com/goldlotus1810/HomeOS/internal/agents"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

type Intent uint8

const (
	IntentUnknown    Intent = iota
	IntentIdentity          // tên tôi là gì, bạn là ai
	IntentNaming            // đặt tên cho bạn là X
	IntentQueryNode         // X là gì, tra cứu node
	IntentDefine            // X là gì? / định nghĩa X — trả lời súc tích
	IntentQueryRule         // quy tắc, qt, 7 quy tắc
	IntentQuerySelf         // bạn có thể làm gì
	IntentLearn             // nhớ rằng X là Y
	IntentForget            // quên X đi
	IntentConfirm           // đúng rồi, đúng, correct, yes
	IntentReject            // sai rồi, sai, wrong, no
	IntentListNodes         // liệt kê tất cả
	IntentStatus            // trạng thái hệ thống
	IntentReport            // em đang thấy gì / đang quan sát gì / what do you see
	IntentEmotion           // em cảm thấy thế nào / cảm xúc gì / how do you feel
	IntentGreeting          // xin chào, hello
	IntentFarewell          // tạm biệt, bye
	IntentHelp              // giúp tôi, help
	IntentActuator          // tắt/bật đèn, máy lạnh...
	IntentExplain           // tại sao / như thế nào / giải thích X
	IntentCharLookup        // tra ký tự: "chữ A", "ký tự ∑", "山 là gì"
	IntentReason            // suy luận: "liebe nghĩa là gì", "∫ là gì"
	IntentFact              // X có bao nhiêu... / khi nào X... / ai là X... / how many X
	IntentTimeline          // lịch sử X / quá trình X / timeline X / history of X
	IntentBiography         // tiểu sử X / biography of X / X là ai
	IntentExample           // ví dụ về X / cho tôi ví dụ X / example of X
	IntentSynonym           // X còn gọi là gì / synonyms of X / tên khác của X
	IntentConvert           // đổi X sang Y / convert X to Y (đơn vị concept)
	IntentRank              // X tốt hơn Y không / rank X vs Y / so sánh X và Y về Z
	IntentDebate            // pros and cons of X / tranh luận về X / lợi hại của X
	IntentTrend             // xu hướng X / trend in X / tương lai của X
	IntentMnemonic          // mẹo nhớ X / mnemonic for X / cách nhớ X
	IntentSummary           // tóm tắt X / summarize X / tóm lược X
	IntentWhy               // tại sao X / why does X / vì sao X / nguyên nhân X
	IntentExplainDeep       // giải thích chi tiết X / deep dive into X / phân tích sâu X
	IntentSearch            // tìm kiếm X / search X / tìm X
	IntentRelated           // liên quan đến X, X có liên quan gì, nói thêm về X
	IntentPathQuery         // X liên quan đến Y như thế nào? / kết nối giữa X và Y
	IntentCompare           // so sánh X và Y / X khác Y như thế nào?
	IntentList              // liệt kê các X / các loại Y / ví dụ về Z
	IntentHowTo             // cách làm X / làm thế nào để Y / how to Z
	IntentQuiz              // đố tôi về X / hỏi tôi về Y / quiz me on Z
	IntentStatement         // câu cảm thán / nói một mình: "cái cây này đẹp quá"
	IntentParagraph         // đoạn văn dài — extract known/unknown → trả lời tổng hợp
	IntentAsk               // hỏi claude X / claude nghĩ gì về X
	IntentOpinion           // bạn nghĩ gì về X / your take on X
	IntentReadBook          // đọc sách X / load book X / đọc file X
	IntentCalc              // 2+2, 15×7, căn bậc hai 144, tính X
	IntentWebFetch          // đọc trang X, fetch URL, tóm tắt web X
)

// ─── ParsedInput ───────────────────────────────────────────────
type ParsedInput struct {
	Raw     string
	Lower   string
	Intent  Intent
	Slots   map[string]string // "name", "subject", "value"
	Lang    string            // "vi" | "en"
}

// ─── Brain ─────────────────────────────────────────────────────
type Brain struct {
	s          *Server
	state      *State
	matcher    *IntentMatcher
	qtReader   *QTReader
	nodeLookup *NodeLookup
	vocab      *VocabLoader
	reasoner   *silk.SilkReasoner // graph walk với confidence*0.85/hop
	lastLearned string            // key của ĐN cuối cùng — để confirm/reject
	percept    *PerceptLayer      // L6: text/audio/image → ISL thuần

	// pendingNew — kiến thức mới chờ user xác nhận trước khi ghi ĐN
	// Vòng đời: unknown query → pendingNew{key,desc} → hỏi user
	//           user "ok/có" → ghi ĐN → clear
	//           user "không" → clear, không ghi
	pendingNew *pendingKnowledge

	// convCtx — multi-turn conversation context
	// Nhớ chủ đề đang nói trong vài turn gần nhất
	convCtx *ConvContext

	// curve — đường cong cảm xúc cả cuộc trò chuyện
	curve      *agents.ConversationCurve
	emoHistory *agents.EmotionHistory

	// bookShelf — kho sách đã đọc (BookMemory ĐN → FlushToSilk QR)
	bookShelf  *agents.BookShelf
}

func NewBrain(s *Server) *Brain {
	b := &Brain{
		s:          s,
		state:      NewState("homeos.olang"),
		curve:      agents.NewConversationCurve(nil),
		emoHistory: &agents.EmotionHistory{},
		bookShelf:  agents.NewBookShelf(),
		matcher:    NewIntentMatcher("homeos.olang"),
		qtReader:   NewQTReader("homeos.olang"),
		nodeLookup: NewNodeLookup("homeos.olang"),
		vocab:      NewVocabLoader("homeos.olang"),
		percept:    NewPerceptLayer("homeos.olang"),
	}
	globalVocab = b.vocab
	if s != nil && s.world != nil {
		b.reasoner = silk.NewSilkReasoner(s.world.Graph)
	}
	// BUG2 FIX: đăng ký hook để NodeLookup tự Refresh sau mỗi AppendNode
	OnNodeAppended = func() {
		if b.nodeLookup != nil {
			b.nodeLookup.Refresh()
		}
	}
	return b
}

// ─── PerceptEncode — export để apiChat dùng ─────────────────────
// Chuyển text → PerceptMessage (ISL) → gửi qua agents.MessageBus
func (b *Brain) PerceptEncode(text string) PerceptMessage {
	return b.percept.EncodeText(text)
}

// ─── Parse ─────────────────────────────────────────────────────