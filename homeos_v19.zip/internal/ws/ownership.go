// internal/ws/ownership.go
//
// Cryptographic Ownership — quản trị tối cao của Olang
//
// Ai giữ private key = chủ sở hữu. Không username/password.
//
// Flow:
//   First boot → sinh ED25519 keypair → lưu ~/.homeos/owner.key
//                → ghi OWNER_PUBKEY vào L7 QR homeos.olang
//
//   Login       → backend gửi challenge (32B random nonce)
//               → client sign(challenge) bằng private key
//               → backend verify(sig, challenge, OWNER_PUBKEY)
//               → pass → JWT session 24h
//
//   QR commit   → mọi QR node đều có sig = sign(sha256(dna+name))
//               → bất kỳ ai cũng có thể verify với OWNER_PUBKEY
//
// Key format:
//   ~/.homeos/owner.key  = ED25519 private key (64B raw, hex-encoded)
//   ~/.homeos/owner.pub  = ED25519 public  key (32B raw, hex-encoded)

package ws

import (
	"crypto/ed25519"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

const (
	ownerNodeName  = "OWNER_PUBKEY"
	trustedPrefix  = "TRUSTED_KEY:"
	ownerLayerID   = uint8(7)
	ownerDNAFlag   = byte(0xA2) // ownership flag
	jwtTTL         = 24 * time.Hour
)

// OwnershipManager — cryptographic ownership của Olang
type OwnershipManager struct {
	mu        sync.RWMutex
	olangPath string
	keyDir    string         // ~/.homeos/
	ownerPub  ed25519.PublicKey  // loaded từ OWNER_PUBKEY node
	hasOwner  bool
	jwtSecret []byte         // random per-boot, dùng cho JWT sessions
	challenges map[string]challengeEntry // nonce → expiry
}

type challengeEntry struct {
	nonce   []byte
	created time.Time
}

func NewOwnershipManager(olangPath string) *OwnershipManager {
	home, _ := os.UserHomeDir()
	keyDir := filepath.Join(home, ".homeos")
	_ = os.MkdirAll(keyDir, 0700)

	secret := make([]byte, 32)
	rand.Read(secret)

	m := &OwnershipManager{
		olangPath:  olangPath,
		keyDir:     keyDir,
		jwtSecret:  secret,
		challenges: make(map[string]challengeEntry),
	}
	m.loadOwnerPubkey()
	return m
}

// loadOwnerPubkey đọc OWNER_PUBKEY node từ homeos.olang
func (m *OwnershipManager) loadOwnerPubkey() {
	raw, err := os.ReadFile(m.olangPath)
	if err != nil { return }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeS  := len(raw) - nedges*olang.EdgeSize
	off := 0
	for off < edgeS {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > edgeS { break }
		off++                  // lid
		off += 8               // isl
		off += 4               // codepoint
		dlen := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nlen := int(raw[off]); off++
		if off+dlen+nlen > edgeS { break }
		dna  := raw[off:off+dlen]; off += dlen
		name := string(raw[off:off+nlen]); off += nlen

		if name != ownerNodeName { continue }
		// DNA: flag(1) + pubkey(32)
		if len(dna) < 33 || dna[0] != ownerDNAFlag { continue }
		m.ownerPub = ed25519.PublicKey(dna[1:33])
		m.hasOwner = true
		log.Printf("○ Ownership: loaded OWNER_PUBKEY (%s)", m.Fingerprint())
		return
	}
	log.Printf("○ Ownership: no owner — first boot pending")
}

// HasOwner trả về true nếu OWNER_PUBKEY đã tồn tại trong olang
func (m *OwnershipManager) HasOwner() bool {
	m.mu.RLock(); defer m.mu.RUnlock()
	return m.hasOwner
}

// Fingerprint trả về 8 hex chars đầu của sha256(pubkey)
func (m *OwnershipManager) Fingerprint() string {
	if m.ownerPub == nil { return "none" }
	h := sha256.Sum256(m.ownerPub)
	return hex.EncodeToString(h[:4])
}

// ── FIRST BOOT ────────────────────────────────────────────────

// InitOwner: sinh keypair, lưu key file, ghi OWNER_PUBKEY vào olang.
// Chỉ gọi khi !hasOwner. Trả về pubkey hex để hiển thị cho user.
func (m *OwnershipManager) InitOwner() (pubHex string, err error) {
	m.mu.Lock(); defer m.mu.Unlock()

	if m.hasOwner {
		return "", fmt.Errorf("owner đã tồn tại")
	}

	// Sinh keypair
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil { return "", fmt.Errorf("keygen: %w", err) }

	// Lưu key files (~/.homeos/)
	privHex := hex.EncodeToString(priv)
	pubHexStr := hex.EncodeToString(pub)

	privPath := filepath.Join(m.keyDir, "owner.key")
	pubPath  := filepath.Join(m.keyDir, "owner.pub")

	if err := os.WriteFile(privPath, []byte(privHex), 0600); err != nil {
		return "", fmt.Errorf("write private key: %w", err)
	}
	if err := os.WriteFile(pubPath, []byte(pubHexStr), 0644); err != nil {
		return "", fmt.Errorf("write public key: %w", err)
	}

	// Ghi OWNER_PUBKEY vào L7 QR node
	// DNA: ownerDNAFlag(1) + pubkey(32) = 33B
	dna := append([]byte{ownerDNAFlag}, pub...)
	h   := sha256.Sum256([]byte(ownerNodeName))
	var isl [8]byte; copy(isl[:], h[:8])

	if err := OlangAppendNodeQR(m.olangPath, ownerLayerID, isl, 0, dna, ownerNodeName); err != nil {
		// Xóa key files nếu ghi olang thất bại
		os.Remove(privPath); os.Remove(pubPath)
		return "", fmt.Errorf("ghi olang: %w", err)
	}

	m.ownerPub = pub
	m.hasOwner = true
	log.Printf("○ Ownership: OWNER_PUBKEY written — fingerprint=%s", m.Fingerprint())
	log.Printf("○ Ownership: private key → %s", privPath)

	return pubHexStr, nil
}

// ── LOGIN: CHALLENGE-RESPONSE ─────────────────────────────────

// NewChallenge sinh 32B random nonce, lưu tạm, trả về hex
func (m *OwnershipManager) NewChallenge() string {
	m.mu.Lock(); defer m.mu.Unlock()

	nonce := make([]byte, 32)
	rand.Read(nonce)
	id := hex.EncodeToString(nonce[:8]) // ID ngắn để lookup
	m.challenges[id] = challengeEntry{nonce: nonce, created: time.Now()}

	// Dọn challenges cũ (>2 phút)
	for k, v := range m.challenges {
		if time.Since(v.created) > 2*time.Minute { delete(m.challenges, k) }
	}

	// Trả về: id:nonce_hex
	return id + ":" + hex.EncodeToString(nonce)
}

// VerifyChallenge xác thực chữ ký của client
// challengeStr = id:nonce_hex (từ NewChallenge)
// sigHex = hex(ed25519_sign(nonce))
func (m *OwnershipManager) VerifyChallenge(challengeStr, sigHex string) error {
	m.mu.Lock(); defer m.mu.Unlock()

	if !m.hasOwner {
		return fmt.Errorf("chưa có owner")
	}

	// Parse challenge
	var id, nonceHex string
	for i, c := range challengeStr {
		if c == ':' { id = challengeStr[:i]; nonceHex = challengeStr[i+1:]; break }
	}
	entry, ok := m.challenges[id]
	if !ok {
		return fmt.Errorf("challenge không tồn tại hoặc đã hết hạn")
	}
	if time.Since(entry.created) > 2*time.Minute {
		delete(m.challenges, id)
		return fmt.Errorf("challenge hết hạn")
	}

	// Verify nonce khớp
	expectedNonce := hex.EncodeToString(entry.nonce)
	if nonceHex != expectedNonce {
		return fmt.Errorf("nonce không khớp")
	}

	// Verify chữ ký
	sig, err := hex.DecodeString(sigHex)
	if err != nil { return fmt.Errorf("sig hex invalid: %w", err) }

	if !ed25519.Verify(m.ownerPub, entry.nonce, sig) {
		return fmt.Errorf("chữ ký không hợp lệ")
	}

	delete(m.challenges, id) // dùng 1 lần
	return nil
}

// IssueJWT trả về JWT sau khi verify thành công
func (m *OwnershipManager) IssueJWT() (string, error) {
	m.mu.RLock(); defer m.mu.RUnlock()
	payload := map[string]interface{}{
		"sub":  "owner",
		"tier": 0,
		"fp":   m.Fingerprint(),
		"iat":  time.Now().Unix(),
		"exp":  time.Now().Add(jwtTTL).Unix(),
	}
	return signJWTMap(payload, m.jwtSecret)
}

// VerifyJWT xác thực token → trả fingerprint + tier
func (m *OwnershipManager) VerifyJWT(token string) (string, int, error) {
	m.mu.RLock(); defer m.mu.RUnlock()
	return verifyJWTMap(token, m.jwtSecret)
}

// RequireOwner middleware
func (m *OwnershipManager) RequireOwner(next func(w, r interface{})) func(interface{}, interface{}) {
	return next // placeholder — implemented in auth_api.go
}

// ── KEY EXPORT (cho UI) ───────────────────────────────────────

// ExportPrivKeyForDownload đọc private key từ file, trả về để download.
// Chỉ gọi khi init — sau đó user nên xóa khỏi server.
func (m *OwnershipManager) ExportPrivKeyForDownload() (string, error) {
	privPath := filepath.Join(m.keyDir, "owner.key")
	data, err := os.ReadFile(privPath)
	if err != nil { return "", fmt.Errorf("key file not found: %w", err) }
	return string(data), nil
}

// OwnerPubHex trả về public key dạng hex
func (m *OwnershipManager) OwnerPubHex() string {
	m.mu.RLock(); defer m.mu.RUnlock()
	if m.ownerPub == nil { return "" }
	return hex.EncodeToString(m.ownerPub)
}

// ── JWT helpers ───────────────────────────────────────────────

func signJWTMap(payload map[string]interface{}, secret []byte) (string, error) {
	hdr := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	pb, err := json.Marshal(payload)
	if err != nil { return "", err }
	body := base64.RawURLEncoding.EncodeToString(pb)
	mac  := hmac.New(sha256.New, secret)
	mac.Write([]byte(hdr + "." + body))
	sig  := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
	return hdr + "." + body + "." + sig, nil
}

func verifyJWTMap(token string, secret []byte) (fp string, tier int, err error) {
	parts := splitN(token, ".", 3)
	if len(parts) != 3 { return "", 0, fmt.Errorf("invalid token") }

	mac := hmac.New(sha256.New, secret)
	mac.Write([]byte(parts[0] + "." + parts[1]))
	expected := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
	if !hmac.Equal([]byte(parts[2]), []byte(expected)) {
		return "", 0, fmt.Errorf("invalid signature")
	}

	pb, _ := base64.RawURLEncoding.DecodeString(parts[1])
	var p map[string]interface{}
	if err := json.Unmarshal(pb, &p); err != nil { return "", 0, err }

	exp, _ := p["exp"].(float64)
	if time.Now().Unix() > int64(exp) { return "", 0, fmt.Errorf("token expired") }

	fp, _ = p["fp"].(string)
	t, _  := p["tier"].(float64)
	return fp, int(t), nil
}

func splitN(s, sep string, n int) []string {
	var result []string
	for i := 0; i < n-1; i++ {
		idx := -1
		for j := 0; j < len(s); j++ {
			if string(s[j]) == sep { idx = j; break }
		}
		if idx < 0 { break }
		result = append(result, s[:idx])
		s = s[idx+1:]
	}
	return append(result, s)
}
