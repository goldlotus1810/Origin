package ws

import "testing"

func TestL2NatureSentence(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	tests := []string{"lửa", "nước", "gió", "mưa", "ánh sáng", "điện", "trọng lực", "thời gian"}
	for _, q := range tests {
		node, hops := nl.SearchAndWalk(q, 2)
		if node == nil { t.Logf("❌ %q not found", q); continue }
		s := nl.NaturalSentence(node, hops)
		t.Logf("=== %q ===\n%s\n", q, s)
	}
}

func TestNatureWaterHops(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	node, hops := nl.SearchAndWalk("nước", 2)
	if node == nil { t.Fatal("not found"); return }
	t.Logf("Node: %s [%s]", node.Label, node.Name)
	t.Logf("Hops: %d", len(hops))
	for _, h := range hops {
		if h.Node != nil {
			t.Logf("  [%s] %s (depth=%d)", h.TypeSym, h.Node.Label, h.Depth)
		}
	}
}
