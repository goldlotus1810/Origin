// internal/ws/ui_loader.go
//
// UILoader — đọc UI_INDEX từ homeos.olang và serve HTML
//
// Khi olang run homeos.olang:
//   → Go tìm L5 node "UI_INDEX"
//   → DNA: EMIT(0x52) + flags(0x01=html) + raw_size(4B) + sha4(4B) + zlib_data
//   → decompress → serve HTTP /
//
// Không cần web/static/ nữa.
// web/static/ chỉ còn là nguồn để rebuild nếu cần.

package ws

import (
	"bytes"
	"compress/zlib"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

const (
	uiFlagHTML = 0x01
	uiFlagCSS  = 0x02
	uiFlagJS   = 0x03
)

// UIAsset — 1 asset đã decode từ .olang
type UIAsset struct {
	Name        string
	ContentType string
	Data        []byte // raw HTML/JS/CSS
	SHA4        [4]byte
}

// UILoader load tất cả UI_* nodes từ homeos.olang
type UILoader struct {
	mu        sync.RWMutex
	olangPath string
	assets    map[string]*UIAsset // name → asset
}

func NewUILoader(olangPath string) *UILoader {
	u := &UILoader{
		olangPath: olangPath,
		assets:    make(map[string]*UIAsset),
	}
	u.load()
	return u
}

func (u *UILoader) load() {
	raw, err := os.ReadFile(u.olangPath)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil {
		log.Printf("○ UILoader: cannot read %s: %v", u.olangPath, err)
		return
	}

	count := 0
	for off := 0; off+14 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > len(raw) { break }

		layerID := raw[off]; off++
		off += 8  // ISL
		off += 4  // codepoint
		dnaLen  := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nameLen := int(raw[off]); off++
		if off+dnaLen+nameLen > len(raw) { break }
		dna  := raw[off:off+dnaLen]; off += dnaLen
		name := string(raw[off:off+nameLen]); off += nameLen

		// Chỉ L5 UI_* nodes
		if layerID != 5 { continue }
		if !strings.HasPrefix(name, "UI_") { continue }
		if len(dna) < 10 { continue }

		// Parse DNA: EMIT(0x52) + flag(1B) + raw_size(4B) + sha4(4B) + zlib_data
		if dna[0] != 0x52 { continue }
		flag    := dna[1]
		rawSize := int(binary.BigEndian.Uint32(dna[2:6]))
		var sha4 [4]byte; copy(sha4[:], dna[6:10])
		zlibData := dna[10:]

		// Decompress
		decoded, err := zlibDecompress(zlibData, rawSize)
		if err != nil {
			log.Printf("○ UILoader: decompress %s failed: %v", name, err)
			continue
		}

		// Verify SHA4
		h := sha256.Sum256(decoded)
		if h[0] != sha4[0] || h[1] != sha4[1] || h[2] != sha4[2] || h[3] != sha4[3] {
			log.Printf("○ UILoader: SHA4 mismatch for %s — serving anyway", name)
		}

		ct := contentTypeFor(flag)
		u.assets[name] = &UIAsset{
			Name:        name,
			ContentType: ct,
			Data:        decoded,
			SHA4:        sha4,
		}
		count++
		log.Printf("○ UILoader: loaded %s (%s, %d bytes, sha4=%x)", name, ct, len(decoded), sha4)
	}

	if count == 0 {
		log.Printf("○ UILoader: no UI_* nodes found — falling back to web/static/")
	}
}

// Get trả về asset theo tên
func (u *UILoader) Get(name string) (*UIAsset, bool) {
	u.mu.RLock(); defer u.mu.RUnlock()
	a, ok := u.assets[name]
	return a, ok
}

// HasUI trả về true nếu có ít nhất UI_INDEX
func (u *UILoader) HasUI() bool {
	u.mu.RLock(); defer u.mu.RUnlock()
	_, ok := u.assets["UI_INDEX"]
	return ok
}

// Reload sau khi OlangAppendNode thêm UI node mới
func (u *UILoader) Reload() {
	u.mu.Lock()
	u.assets = make(map[string]*UIAsset)
	u.mu.Unlock()
	u.load()
}

// ── Helpers ──────────────────────────────────────────────────

func zlibDecompress(data []byte, expectedSize int) ([]byte, error) {
	r, err := zlib.NewReader(bytes.NewReader(data))
	if err != nil { return nil, fmt.Errorf("zlib.NewReader: %w", err) }
	defer r.Close()
	out := make([]byte, 0, expectedSize)
	buf := make([]byte, 32768)
	for {
		n, err := r.Read(buf)
		if n > 0 { out = append(out, buf[:n]...) }
		if err == io.EOF { break }
		if err != nil { return nil, err }
		if len(out) > 10*1024*1024 { return nil, fmt.Errorf("decompressed too large") }
	}
	return out, nil
}

func contentTypeFor(flag uint8) string {
	switch flag {
	case uiFlagHTML: return "text/html; charset=utf-8"
	case uiFlagJS:   return "application/javascript; charset=utf-8"
	case uiFlagCSS:  return "text/css; charset=utf-8"
	default:         return "application/octet-stream"
	}
}
