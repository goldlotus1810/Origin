// internal/ws/brain_webfetch.go
// IntentWebFetch — fetch URL và trả về nội dung tóm tắt
//
// Trigger: "đọc trang X", "fetch URL", "tóm tắt web X", URL trong text
// Pipeline:
//   1. Extract URL từ câu
//   2. HTTP GET với timeout 10s
//   3. Strip HTML → plain text
//   4. Trả về 500 ký tự đầu + tiêu đề trang

package ws

import (
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"
)

var httpClient = &http.Client{
	Timeout: 10 * time.Second,
}

// webFetch fetch URL và trả về nội dung tóm tắt
func (b *Brain) webFetch(rawURL, lang string) string {
	if rawURL == "" {
		if lang == "vi" {
			return "Vui lòng cung cấp URL, ví dụ: **đọc trang https://example.com**"
		}
		return "Please provide a URL, e.g. **fetch https://example.com**"
	}

	// Validate URL
	u, err := url.ParseRequestURI(rawURL)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") {
		if lang == "vi" {
			return fmt.Sprintf("URL không hợp lệ: **%s**", rawURL)
		}
		return fmt.Sprintf("Invalid URL: **%s**", rawURL)
	}

	// Fetch
	resp, err := httpClient.Get(rawURL)
	if err != nil {
		if lang == "vi" {
			return fmt.Sprintf("Không thể truy cập **%s**: %s", rawURL, simplifyNetErr(err))
		}
		return fmt.Sprintf("Cannot reach **%s**: %s", rawURL, simplifyNetErr(err))
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		if lang == "vi" {
			return fmt.Sprintf("Trang trả lỗi **%d** cho %s", resp.StatusCode, rawURL)
		}
		return fmt.Sprintf("Server returned **%d** for %s", resp.StatusCode, rawURL)
	}

	// Đọc tối đa 512KB
	body, err := io.ReadAll(io.LimitReader(resp.Body, 512*1024))
	if err != nil {
		return fmt.Sprintf("Lỗi đọc nội dung: %v", err)
	}

	// Strip HTML → plain text
	title   := extractHTMLTitle(string(body))
	text    := stripHTML(string(body))
	text     = collapseWhitespace(text)

	// Truncate ~800 ký tự
	maxRune := 800
	if utf8.RuneCountInString(text) > maxRune {
		runes := []rune(text)
		text  = string(runes[:maxRune]) + "…"
	}

	if text == "" {
		if lang == "vi" {
			return fmt.Sprintf("Đã fetch **%s** nhưng không có nội dung văn bản.", rawURL)
		}
		return fmt.Sprintf("Fetched **%s** but found no text content.", rawURL)
	}

	var sb strings.Builder
	if title != "" {
		sb.WriteString(fmt.Sprintf("**%s**\n", title))
	}
	sb.WriteString(fmt.Sprintf("*Nguồn: %s*\n\n", rawURL))
	sb.WriteString(text)
	return sb.String()
}

// ── HTML helpers ───────────────────────────────────────────────

var reTitle   = regexp.MustCompile(`(?i)<title[^>]*>(.*?)</title>`)
var reScript  = regexp.MustCompile(`(?is)<script[^>]*>.*?</script>|<style[^>]*>.*?</style>|<head[^>]*>.*?</head>`)
var reTag     = regexp.MustCompile(`<[^>]+>`)
var reEntity  = regexp.MustCompile(`&[a-zA-Z]+;|&#\d+;`)
var reSpaces  = regexp.MustCompile(`[ \t]+`)
var reLines   = regexp.MustCompile(`\n{3,}`)

func extractHTMLTitle(html string) string {
	m := reTitle.FindStringSubmatch(html)
	if m == nil { return "" }
	t := stripHTML(m[1])
	return strings.TrimSpace(collapseWhitespace(t))
}

func stripHTML(html string) string {
	// Bỏ script/style/head
	s := reScript.ReplaceAllString(html, " ")
	// Đổi block tags → newline
	s = regexp.MustCompile(`(?i)</(p|div|li|br|tr|h[1-6])\s*>`).ReplaceAllString(s, "\n")
	// Bỏ tất cả tags còn lại
	s = reTag.ReplaceAllString(s, "")
	// Decode HTML entities cơ bản
	s = decodeHTMLEntities(s)
	return s
}

func decodeHTMLEntities(s string) string {
	replacer := strings.NewReplacer(
		"&amp;", "&", "&lt;", "<", "&gt;", ">",
		"&quot;", `"`, "&#39;", "'", "&nbsp;", " ",
		"&mdash;", "—", "&ndash;", "–", "&hellip;", "…",
	)
	s = replacer.Replace(s)
	// Bỏ entity còn lại
	s = reEntity.ReplaceAllString(s, " ")
	return s
}

func collapseWhitespace(s string) string {
	s = reSpaces.ReplaceAllString(s, " ")
	s = reLines.ReplaceAllString(s, "\n\n")
	return strings.TrimSpace(s)
}

// detectWebFetchIntent kiểm tra câu có phải web fetch intent không
// Trả về (url, true) nếu match
var reURL = regexp.MustCompile(`https?://[^\s]+`)

func detectWebFetchIntent(lo string) (string, bool) {
	fetchPrefixes := []string{
		"đọc trang ", "fetch ", "tóm tắt web ", "tóm tắt trang ",
		"load url ", "lấy nội dung ", "đọc url ",
		"summarize url ", "summarize page ",
	}
	for _, p := range fetchPrefixes {
		if strings.HasPrefix(lo, p) {
			u := strings.TrimSpace(lo[len(p):])
			if !strings.HasPrefix(u, "http") {
				u = "https://" + u
			}
			return u, true
		}
	}
	// URL trực tiếp trong câu
	if m := reURL.FindString(lo); m != "" {
		return m, true
	}
	return "", false
}

func simplifyNetErr(err error) string {
	msg := err.Error()
	if strings.Contains(msg, "timeout") || strings.Contains(msg, "deadline") {
		return "timeout (>10s)"
	}
	if strings.Contains(msg, "no such host") || strings.Contains(msg, "dns") {
		return "không tìm thấy host"
	}
	if strings.Contains(msg, "connection refused") {
		return "kết nối bị từ chối"
	}
	// Truncate
	if len(msg) > 80 { msg = msg[:80] + "…" }
	return msg
}
