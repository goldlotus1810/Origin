// internal/ws/olang_graph.go
//
// OlangGraph — đọc nodes + edges từ homeos.olang để serve qua API
// Chỉ trả nodes L2/L3/L4/L6 (ontology), L7 (programs) tuỳ option

package ws

import (
	"encoding/binary"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"os"
)

// GraphNode — 1 node cho frontend
type GraphNode struct {
	ID    string `json:"id"`    // "LIFE_CAT"
	Label string `json:"label"` // "con mèo"
	Layer int    `json:"layer"` // 2,3,4,6,7
	Cat   string `json:"cat"`   // "life","nature","objects","perception","programs"
	Glyph string `json:"glyph,omitempty"` // emoji / symbol cho L1
	Desc  string `json:"desc,omitempty"`  // mô tả ngắn từ DNA
}

// GraphEdge — 1 edge cho frontend
type GraphEdge struct {
	From string `json:"from"` // node ID
	To   string `json:"to"`   // node ID
	Op   string `json:"op"`   // "∈","≈","⊥","∘",...
}

// OlangGraph đọc toàn bộ đồ thị ontology từ file
func OlangGraph(filePath string, nl *NodeLookup) ([]GraphNode, []GraphEdge) {
	raw, err := os.ReadFile(filePath)
	if err != nil { return nil, nil }
	if len(raw) < 20 { return nil, nil }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 { return nil, nil }

	layerCat := map[uint8]string{
		2: "nature", 3: "life", 4: "objects",
		5: "programs", 6: "perception", 7: "programs",
	}
	edgeSymbol := map[uint8]string{
		0x01: "♫",  // SameSound
		0x02: "≋",  // SameShape
		0x03: "≣",  // SameMeaning
		0x04: "←",  // DerivedFrom
		0x07: "⟺",  // Mirror
		0x08: "∈",  // Member
		0x09: "⊂",  // Subset
		0x0A: "∘",  // Compose
		0x0B: "≡",  // Equiv
		0x0C: "≈",  // Similar
		0x0D: "⊥",  // Opposite
		0x0E: "⟿",  // WorldLink
		0x0F: "♬",  // Phoneme
	}

	// Pass 1: đọc nodes
	islToName := map[uint64]string{}
	nodeSet   := map[string]bool{}
	var nodes []GraphNode

	for off := 0; off+14 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > edgeStart { break }
		lid := raw[off]; off++
		islU := binary.BigEndian.Uint64(raw[off:off+8]); off += 8
		off += 4
		dlen := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nlen := int(raw[off]); off++
		if off+dlen+nlen > edgeStart { break }
		off += dlen
		name := string(raw[off:off+nlen]); off += nlen

		islToName[islU] = name
		cat, ok := layerCat[lid]
		if !ok { continue }

		// Label + Desc từ NodeLookup
		label, desc := name, ""
		if nl != nil {
			nl.mu.RLock()
			if node, found := nl.byName[name]; found {
				label = node.Label
				// Cắt desc ngắn gọn cho tooltip
				if len(node.Desc) > 60 {
					desc = node.Desc[:57] + "..."
				} else {
					desc = node.Desc
				}
			}
			nl.mu.RUnlock()
		}

		nodes = append(nodes, GraphNode{
			ID: name, Label: label,
			Layer: int(lid), Cat: cat,
			Desc: desc,
		})
		nodeSet[name] = true
	}

	// Pass 2: đọc edges — chỉ giữ ontology→ontology
	var edges []GraphEdge
	for i := 0; i < nedges; i++ {
		o := edgeStart + i*olang.EdgeSize
		if o+17 > len(raw) { break }
		srcU := binary.BigEndian.Uint64(raw[o:o+8])
		dstU := binary.BigEndian.Uint64(raw[o+8:o+16])
		typ  := raw[o+16]

		srcN := islToName[srcU]
		dstN := islToName[dstU]
		if !nodeSet[srcN] || !nodeSet[dstN] { continue }

		op, ok := edgeSymbol[typ]
		if !ok { op = "→" }

		edges = append(edges, GraphEdge{From: srcN, To: dstN, Op: op})
	}

	return nodes, edges
}
