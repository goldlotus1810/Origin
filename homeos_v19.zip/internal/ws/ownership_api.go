// internal/ws/ownership_api.go — REST endpoints cho ownership

package ws

import (
	"encoding/json"
	"net/http"
	"strings"
)

// RegisterOwnershipAPI thêm /api/owner/* endpoints
func (s *Server) RegisterOwnershipAPI(mux *http.ServeMux) {
	c := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Access-Control-Allow-Origin", "*")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
			if r.Method == "OPTIONS" { w.WriteHeader(200); return }
			h(w, r)
		}
	}
	mux.HandleFunc("/api/owner/status",    c(s.ownerStatus))
	mux.HandleFunc("/api/owner/init",      c(s.ownerInit))
	mux.HandleFunc("/api/owner/challenge", c(s.ownerChallenge))
	mux.HandleFunc("/api/owner/verify",    c(s.ownerVerify))
	mux.HandleFunc("/api/owner/me",        c(s.ownerMe))
	mux.HandleFunc("/api/owner/pubkey",    c(s.ownerPubkey))
}

// GET /api/owner/status — đã có owner chưa? pubkey fingerprint?
func (s *Server) ownerStatus(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"hasOwner":    s.owner.HasOwner(),
		"fingerprint": s.owner.Fingerprint(),
	})
}

// POST /api/owner/init — first boot: sinh keypair, ghi OWNER_PUBKEY
// Không cần body. Trả về pubkey hex + private key để download.
func (s *Server) ownerInit(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method != "POST" { http.Error(w, "POST only", 405); return }
	if s.owner.HasOwner() {
		http.Error(w, `{"error":"owner đã tồn tại"}`, 409)
		return
	}

	pubHex, err := s.owner.InitOwner()
	if err != nil {
		w.WriteHeader(500)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}

	privKey, _ := s.owner.ExportPrivKeyForDownload()

	json.NewEncoder(w).Encode(map[string]interface{}{
		"pubkey":      pubHex,
		"fingerprint": s.owner.Fingerprint(),
		"privkey":     privKey, // 128 hex chars — user phải download và giữ
		"warning":     "Lưu private key ngay. Server sẽ không hiển thị lại.",
		"keyPath":     "~/.homeos/owner.key",
	})
}

// GET /api/owner/challenge — lấy nonce để sign
func (s *Server) ownerChallenge(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if !s.owner.HasOwner() {
		http.Error(w, `{"error":"chưa có owner — gọi /api/owner/init trước"}`, 400)
		return
	}
	challenge := s.owner.NewChallenge()
	json.NewEncoder(w).Encode(map[string]string{
		"challenge": challenge,
		"info":      "sign(hex_decode(nonce_part)) bằng ED25519 private key",
	})
}

// POST /api/owner/verify — submit chữ ký, nhận JWT
// Body: {challenge: "id:nonce_hex", sig: "sig_hex"}
func (s *Server) ownerVerify(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	if r.Method != "POST" { http.Error(w, "POST only", 405); return }

	var req struct {
		Challenge string `json:"challenge"`
		Sig       string `json:"sig"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid JSON"}`, 400); return
	}

	if err := s.owner.VerifyChallenge(req.Challenge, req.Sig); err != nil {
		w.WriteHeader(401)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}

	token, err := s.owner.IssueJWT()
	if err != nil {
		w.WriteHeader(500)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"token":       token,
		"fingerprint": s.owner.Fingerprint(),
		"tier":        "T0",
		"role":        "Owner",
	})
}

// GET /api/owner/me — thông tin session hiện tại
func (s *Server) ownerMe(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	auth := r.Header.Get("Authorization")
	if !strings.HasPrefix(auth, "Bearer ") {
		http.Error(w, `{"error":"no token"}`, 401); return
	}
	fp, tier, err := s.owner.VerifyJWT(auth[7:])
	if err != nil {
		w.WriteHeader(401)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	json.NewEncoder(w).Encode(map[string]interface{}{
		"fingerprint": fp,
		"tier":        tier,
		"role":        "Owner",
	})
}

// GET /api/owner/pubkey — lấy public key (public info)
func (s *Server) ownerPubkey(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"pubkey":      s.owner.OwnerPubHex(),
		"fingerprint": s.owner.Fingerprint(),
	})
}
