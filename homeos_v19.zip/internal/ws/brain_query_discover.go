// internal/ws/brain_query_discovery_queries_—_trend,_rank,_synonym,_convert,_example,_bio,_timeline,_search,_related,_howto,_list,_compare,_walk.go
// Discovery queries — trend, rank, synonym, convert, example, bio, timeline, search, related, howTo, list, compare, walk

package ws

import (
	"fmt"
	"strings"
)

func (b *Brain) trendNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }

	hops = b.nodeLookup.HopsFromCache(node.ISLU)

	var sb strings.Builder
	nl  := "\n"
	nl2 := "\n\n"

	if lang == "vi" {
		sb.WriteString("📈 **Xu hướng & Tương lai: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("📈 **Trends & Future: " + node.Label + "**" + nl2)
	}

	// Desc — hiện tại
	if node.Desc != "" {
		if lang == "vi" {
			sb.WriteString("**Hiện tại:** " + node.Desc + nl2)
		} else {
			sb.WriteString("**Current state:** " + node.Desc + nl2)
		}
	}

	// Hops — driver xu hướng
	if len(hops) > 0 {
		if lang == "vi" {
			sb.WriteString("**Động lực thay đổi:**" + nl)
		} else {
			sb.WriteString("**Key drivers:**" + nl)
		}
		for i, h := range hops {
			if h.Node == nil { continue }
			desc := ""
			if h.Node.Desc != "" {
				rr := []rune(h.Node.Desc); if len(rr) > 45 { rr = rr[:45] }
				desc = " — " + string(rr) + "..."
			}
			sb.WriteString(fmt.Sprintf("• **%s**%s%s", h.Node.Label, desc, nl))
			if i >= 3 { break }
		}
		sb.WriteString(nl)
	}

	// Outlook
	if lang == "vi" {
		sb.WriteString("_Hỏi 'ví dụ về " + node.Label + "' hoặc 'liên quan đến " + node.Label + "' để xem thêm._")
	} else {
		sb.WriteString("_Ask 'examples of " + node.Label + "' or 'related to " + node.Label + "' for more._")
	}

	b.glowNode(node, hops)
	return b.resp("trend", strings.TrimSpace(sb.String()))
}


func (b *Brain) rankNode(a, bStr, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	nodeA := b.nodeLookup.SearchExact(a)
	if nodeA == nil { nodeA = b.nodeLookup.Search(a) }
	nodeB := b.nodeLookup.SearchExact(bStr)
	if nodeB == nil { nodeB = b.nodeLookup.Search(bStr) }

	var sb strings.Builder
	nl  := "\n"
	nl2 := "\n\n"

	if lang == "vi" {
		sb.WriteString("⚖️ **So sánh**" + nl2)
	} else {
		sb.WriteString("⚖️ **Comparison**" + nl2)
	}

	renderNode := func(n *KnownNode, query string) {
		if n == nil {
			sb.WriteString(fmt.Sprintf("**%s:** _(chưa có trong Silk Tree)_%s", query, nl2))
			return
		}
		domain := b.nodeLookup.DomainLabel(n.Name)
		sb.WriteString(fmt.Sprintf("**%s** _%s_%s", n.Label, domain, nl))
		if n.Desc != "" {
			rr := []rune(n.Desc)
			if len(rr) > 80 { rr = rr[:80] }
			sb.WriteString(string(rr) + "..." + nl2)
		}
	}

	renderNode(nodeA, a)
	renderNode(nodeB, bStr)

	// Tìm điểm chung qua hops
	if nodeA != nil && nodeB != nil {
		hopsA := b.nodeLookup.HopsFromCache(nodeA.ISLU)
		hopsB := b.nodeLookup.HopsFromCache(nodeB.ISLU)
		commonNames := []string{}
		setB := map[uint64]bool{}
		for _, h := range hopsB {
			if h.Node != nil { setB[h.Node.ISLU] = true }
		}
		for _, h := range hopsA {
			if h.Node != nil && setB[h.Node.ISLU] {
				commonNames = append(commonNames, "**"+h.Node.Label+"**")
				if len(commonNames) >= 3 { break }
			}
		}
		if len(commonNames) > 0 {
			if lang == "vi" {
				sb.WriteString("**Điểm chung:** " + strings.Join(commonNames, " · ") + nl2)
			} else {
				sb.WriteString("**In common:** " + strings.Join(commonNames, " · ") + nl2)
			}
		}

		// Kiểm tra liên kết trực tiếp
		for _, h := range hopsA {
			if h.Node != nil && h.Node.ISLU == nodeB.ISLU {
				if lang == "vi" {
					sb.WriteString(fmt.Sprintf("✅ **Liên kết trực tiếp:** %s ↔ %s", nodeA.Label, nodeB.Label))
				} else {
					sb.WriteString(fmt.Sprintf("✅ **Direct link:** %s ↔ %s", nodeA.Label, nodeB.Label))
				}
				break
			}
		}

		b.glowNode(nodeA, hopsA)
	} else if nodeA != nil {
		hopsA := b.nodeLookup.HopsFromCache(nodeA.ISLU)
		b.glowNode(nodeA, hopsA)
	}

	return b.resp("rank", strings.TrimSpace(sb.String()))
}


func (b *Brain) synonymNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }

	hops = b.nodeLookup.HopsFromCache(node.ISLU)

	var sb strings.Builder
	nl  := "\n"
	nl2 := "\n\n"

	if lang == "vi" {
		sb.WriteString("🔤 **Tên gọi khác / Thuật ngữ tương đương: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("🔤 **Synonyms / Aliases: " + node.Label + "**" + nl2)
	}

	// Lấy alias từ Aliases và Name (đã parse sẵn trong node_lookup)
	aliases := []string{}
	for _, a := range node.Aliases {
		a = strings.TrimSpace(a)
		if a == "" || strings.EqualFold(a, node.Label) || strings.EqualFold(a, subject) {
			continue
		}
		aliases = append(aliases, "• "+a)
	}
	// Thêm Name nếu khác Label
	if node.Name != "" && !strings.EqualFold(node.Name, node.Label) {
		aliases = append([]string{"• " + node.Name + " _(key)_"}, aliases...)
	}

	if len(aliases) > 0 {
		sb.WriteString(strings.Join(aliases, nl) + nl2)
	} else {
		if lang == "vi" {
			sb.WriteString("_(Không tìm thấy tên gọi khác.)_" + nl2)
		} else {
			sb.WriteString("_(No aliases found.)_" + nl2)
		}
	}

	// Các khái niệm tương đương qua hops
	if len(hops) > 0 {
		if lang == "vi" {
			sb.WriteString("**Khái niệm liên quan:**" + nl)
		} else {
			sb.WriteString("**Related concepts:**" + nl)
		}
		for i, h := range hops {
			if h.Node == nil { continue }
			sb.WriteString("• " + h.Node.Label + nl)
			if i >= 2 { break }
		}
	}

	b.glowNode(node, hops)
	return b.resp("synonym", strings.TrimSpace(sb.String()))
}

// convertNode — tìm mối liên hệ giữa hai khái niệm X và Y
// Không đổi đơn vị số học, nhưng giải thích mối quan hệ
func (b *Brain) convertNode(from, to, lang string) ChatResponse {
	// Thử unit conversion trước (số + đơn vị)
	if result, ok := tryUnitConvert(from, to, lang); ok {
		return b.resp("convert", result)
	}
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	nodeFrom := b.nodeLookup.SearchExact(from)
	if nodeFrom == nil { nodeFrom = b.nodeLookup.Search(from) }
	nodeTo   := b.nodeLookup.SearchExact(to)
	if nodeTo == nil { nodeTo = b.nodeLookup.Search(to) }

	var sb strings.Builder
	nl2 := "\n\n"

	if nodeFrom == nil && nodeTo == nil {
		return b.searchNodes(from+" "+to, lang)
	}

	if lang == "vi" {
		sb.WriteString(fmt.Sprintf("🔄 **So sánh / Chuyển đổi khái niệm**%s", nl2))
	} else {
		sb.WriteString(fmt.Sprintf("🔄 **Concept Mapping**%s", nl2))
	}

	if nodeFrom != nil {
		sb.WriteString(fmt.Sprintf("**%s:** %s%s", nodeFrom.Label, nodeFrom.Desc, nl2))
	} else {
		sb.WriteString(fmt.Sprintf("_'%s' chưa có trong Silk Tree._%s", from, nl2))
	}

	if nodeTo != nil {
		sb.WriteString(fmt.Sprintf("**%s:** %s%s", nodeTo.Label, nodeTo.Desc, nl2))
	} else {
		sb.WriteString(fmt.Sprintf("_'%s' chưa có trong Silk Tree._%s", to, nl2))
	}

	// Tìm path giữa 2 nodes
	if nodeFrom != nil && nodeTo != nil {
		hopsFrom := b.nodeLookup.HopsFromCache(nodeFrom.ISLU)
		for _, h := range hopsFrom {
			if h.Node != nil && h.Node.ISLU == nodeTo.ISLU {
				if lang == "vi" {
					sb.WriteString(fmt.Sprintf("✅ **Liên kết trực tiếp:** %s ↔ %s", nodeFrom.Label, nodeTo.Label))
				} else {
					sb.WriteString(fmt.Sprintf("✅ **Direct link:** %s ↔ %s", nodeFrom.Label, nodeTo.Label))
				}
				break
			}
		}
		b.glowNode(nodeFrom, hopsFrom)
	}

	return b.resp("convert", strings.TrimSpace(sb.String()))
}


func (b *Brain) exampleNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }

	hops = b.nodeLookup.HopsFromCache(node.ISLU)

	var sb strings.Builder
	nl  := "\n"
	nl2 := "\n\n"

	if lang == "vi" {
		sb.WriteString("💡 **Ví dụ về: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("💡 **Examples of: " + node.Label + "**" + nl2)
	}

	// Desc là "định nghĩa + ví dụ nội tuyến"
	if node.Desc != "" {
		if lang == "vi" {
			sb.WriteString("**Khái niệm:** " + node.Desc + nl2)
		} else {
			sb.WriteString("**Concept:** " + node.Desc + nl2)
		}
	}

	// Hops là ví dụ cụ thể / ứng dụng
	if len(hops) > 0 {
		if lang == "vi" {
			sb.WriteString("**Ví dụ / Ứng dụng thực tế:**" + nl)
		} else {
			sb.WriteString("**Real-world examples:**" + nl)
		}
		for i, h := range hops {
			if h.Node == nil { continue }
			desc := ""
			if h.Node.Desc != "" {
				rr := []rune(h.Node.Desc)
				if len(rr) > 50 { rr = rr[:50] }
				desc = " — " + string(rr) + "..."
			}
			sb.WriteString(fmt.Sprintf("• **%s**%s%s", h.Node.Label, desc, nl))
			if i >= 3 { break }
		}
	} else {
		if lang == "vi" {
			sb.WriteString("_(Hỏi 'tìm kiếm " + node.Label + "' để xem thêm ví dụ cụ thể.)_")
		} else {
			sb.WriteString("_(Search '" + node.Label + "' for more specific examples.)_")
		}
	}

	b.glowNode(node, hops)
	return b.resp("example", strings.TrimSpace(sb.String()))
}


func (b *Brain) bioNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }

	hops = b.nodeLookup.HopsFromCache(node.ISLU)
	domain := b.nodeLookup.DomainLabel(node.Name)

	var sb strings.Builder
	nl2 := "\n\n"

	// Header
	if lang == "vi" {
		sb.WriteString("👤 **" + node.Label + "**")
		if domain != "" { sb.WriteString(" _(" + domain + ")_") }
		sb.WriteString(nl2)
	} else {
		sb.WriteString("👤 **" + node.Label + "**")
		if domain != "" { sb.WriteString(" _(" + domain + ")_") }
		sb.WriteString(nl2)
	}

	// Mô tả đầy đủ
	if node.Desc != "" {
		sb.WriteString(node.Desc)
		sb.WriteString(nl2)
	} else {
		if lang == "vi" {
			sb.WriteString("_(Chưa có tiểu sử chi tiết.)_" + nl2)
		} else {
			sb.WriteString("_(No detailed biography available.)_" + nl2)
		}
	}

	// Liên kết — đóng vai trò "xem thêm"
	if len(hops) > 0 {
		labels := []string{}
		for _, h := range hops {
			if h.Node == nil { continue }
			labels = append(labels, "**"+h.Node.Label+"**")
			if len(labels) >= 4 { break }
		}
		if lang == "vi" {
			sb.WriteString("Liên quan: " + strings.Join(labels, " · "))
		} else {
			sb.WriteString("Related: " + strings.Join(labels, " · "))
		}
	}

	b.glowNode(node, hops)
	return b.resp("bio", strings.TrimSpace(sb.String()))
}


func (b *Brain) timelineNode(subject, lang string) ChatResponse {
	node, hops, notFound := b.resolveSubject(subject, lang)
	if notFound != nil { return *notFound }

	hops = b.nodeLookup.HopsFromCache(node.ISLU)

	var sb strings.Builder
	nl := "\n"
	nl2 := "\n\n"

	if lang == "vi" {
		sb.WriteString("📅 **Lịch sử / Quá trình: " + node.Label + "**" + nl2)
	} else {
		sb.WriteString("📅 **Timeline: " + node.Label + "**" + nl2)
	}

	// Desc là nguồn chính — có thể chứa năm, sự kiện
	if node.Desc != "" {
		sb.WriteString("**Tổng quan:**" + nl)
		sb.WriteString(node.Desc + nl2)
	}

	// Liên kết theo thứ tự (predecessors, successors từ hops)
	if len(hops) > 0 {
		if lang == "vi" {
			sb.WriteString("**Liên kết quan trọng:**" + nl)
		} else {
			sb.WriteString("**Key connections:**" + nl)
		}
		for i, h := range hops {
			if h.Node == nil { continue }
			// Lấy desc ngắn của node liên quan
			desc := ""
			if h.Node.Desc != "" {
				rr := []rune(h.Node.Desc)
				if len(rr) > 40 { rr = rr[:40] }
				desc = " — " + string(rr) + "..."
			}
			sb.WriteString(fmt.Sprintf("• **%s**%s%s", h.Node.Label, desc, nl))
			if i >= 4 { break }
		}
	}

	// Gợi ý search sâu hơn
	if lang == "vi" {
		sb.WriteString(nl + "_Hỏi 'liên quan đến " + node.Label + "' để xem đồ thị đầy đủ._")
	} else {
		sb.WriteString(nl + "_Ask 'related to " + node.Label + "' for full graph._")
	}

	b.glowNode(node, hops)
	return b.resp("timeline", strings.TrimSpace(sb.String()))
}


func (b *Brain) searchNodes(subject, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	// Tìm exact trước
	exact := b.nodeLookup.SearchExact(subject)
	// Tìm similar
	similar := b.nodeLookup.SuggestSimilar(subject, 8)

	var results []*KnownNode
	seen := map[string]bool{}
	if exact != nil && !seen[exact.Name] {
		results = append(results, exact)
		seen[exact.Name] = true
	}
	for _, s := range similar {
		if !seen[s.Name] {
			results = append(results, s)
			seen[s.Name] = true
		}
		if len(results) >= 7 { break }
	}

	if len(results) == 0 {
		if lang == "vi" {
			return b.resp("unknown", fmt.Sprintf("Không tìm thấy kết quả cho **%s**.", subject))
		}
		return b.resp("unknown", fmt.Sprintf("No results found for **%s**.", subject))
	}

	var sb strings.Builder
	nl1 := "\n"
	exactIdx := -1
	for i, r := range results { if exact != nil && r.Name == exact.Name { exactIdx = i; break } }
	if lang == "vi" {
		sb.WriteString(fmt.Sprintf("Tim kiem \"%s\" (%d ket qua):\n\n", subject, len(results)))
	} else {
		sb.WriteString(fmt.Sprintf("Search \"%s\" (%d results):\n\n", subject, len(results)))
	}
	for i, r := range results {
		domain := b.nodeLookup.DomainLabel(r.Name)
		desc := ""
		if r.Desc != "" {
			rr := []rune(r.Desc); if len(rr) > 60 { rr = rr[:60] }
			desc = " — " + string(rr) + "..."
		}
		star := ""
		if i == exactIdx { star = " ★" }
		sb.WriteString(fmt.Sprintf("%d. **%s**%s _%s_%s%s", i+1, r.Label, star, domain, desc, nl1))
	}
	if exact != nil {
		b.glowNode(exact, b.nodeLookup.HopsFromCache(exact.ISLU))
	}
	return b.resp("search", strings.TrimSpace(sb.String()))
}

// relatedNodes — BFS depth=2, trả về đồ thị liên kết
// "liên quan đến AI" → các khái niệm kết nối trực tiếp + gián tiếp
func (b *Brain) relatedNodes(subject, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	r := b.nodeLookup.Resolve(subject)
	node := r.Node
	if node == nil {
		sugg := b.nodeLookup.SuggestSimilar(subject, 3)
		if len(sugg) > 0 {
			labels := make([]string, len(sugg))
			for i, s := range sugg { labels[i] = "**" + s.Label + "**" }
			if lang == "vi" {
				return b.resp("suggest", "Ý bạn là: "+strings.Join(labels, " · ")+"?")
			}
			return b.resp("suggest", "Did you mean: "+strings.Join(labels, " · ")+"?")
		}
		if lang == "vi" {
			return b.resp("unknown", fmt.Sprintf("Không tìm thấy **%s**.", subject))
		}
		return b.resp("unknown", fmt.Sprintf("**%s** not found.", subject))
	}

	// Depth 1
	depth1 := b.nodeLookup.HopsFromCache(node.ISLU)
	// Depth 2 — hops của từng depth-1 node
	depth2Map := map[string]*KnownNode{}
	for _, h := range depth1 {
		if h.Node == nil { continue }
		hops2 := b.nodeLookup.HopsFromCache(h.Node.ISLU)
		for _, h2 := range hops2 {
			if h2.Node == nil || h2.Node.Name == node.Name { continue }
			if _, exists := depth2Map[h2.Node.Name]; !exists {
				// Chỉ thêm nếu không trùng depth1
				isDup := false
				for _, d1 := range depth1 {
					if d1.Node != nil && d1.Node.Name == h2.Node.Name { isDup = true; break }
				}
				if !isDup { depth2Map[h2.Node.Name] = h2.Node }
			}
		}
		if len(depth2Map) >= 6 { break }
	}

	var sb strings.Builder
	nl2 := "\n\n"
	if lang == "vi" {
		sb.WriteString("**Mạng lưới liên kết: " + node.Label + "**" + nl2)
		if len(depth1) > 0 {
			sb.WriteString("📌 **Trực tiếp:**" + "\n")
			for i, h := range depth1 {
				if h.Node == nil { continue }
				sb.WriteString("• " + h.Node.Label)
				if i < len(depth1)-1 { sb.WriteString("\n") }
				if i >= 4 { break }
			}
			sb.WriteString(nl2)
		}
		if len(depth2Map) > 0 {
			sb.WriteString("🔗 **Gián tiếp:**" + "\n")
			i := 0
			for _, n2 := range depth2Map {
				sb.WriteString("• " + n2.Label)
				if i < len(depth2Map)-1 { sb.WriteString("\n") }
				i++
				if i >= 5 { break }
			}
		}
	} else {
		sb.WriteString("**Related network: " + node.Label + "**" + nl2)
		if len(depth1) > 0 {
			sb.WriteString("📌 **Direct:**\n")
			for i, h := range depth1 {
				if h.Node == nil { continue }
				sb.WriteString("• " + h.Node.Label + "\n")
				if i >= 4 { break }
			}
		}
		if len(depth2Map) > 0 {
			sb.WriteString("\n🔗 **Indirect:**\n")
			i := 0
			for _, n2 := range depth2Map {
				sb.WriteString("• " + n2.Label + "\n")
				i++; if i >= 5 { break }
			}
		}
	}

	b.glowNode(node, depth1)
	return b.resp("related", strings.TrimSpace(sb.String()))
}


func (b *Brain) howToNode(subject, lang string) ChatResponse {
	if b.nodeLookup == nil { return b.resp("unknown", "Silk Tree chưa sẵn sàng.") }
	r := b.nodeLookup.Resolve(subject)
	node := r.Node
	if node == nil {
		if ex := extractQuerySubject(subject); ex != "" {
			node = b.nodeLookup.SearchExact(ex)
			if node == nil { node = b.nodeLookup.Search(ex) }
		}
	}
	if node == nil {
		sugg := b.nodeLookup.SuggestSimilar(subject, 3)
		if len(sugg) > 0 {
			labels := make([]string, len(sugg))
			for i, s := range sugg { labels[i] = "**" + s.Label + "**" }
			return b.resp("suggest", "Ý bạn là: "+strings.Join(labels, " · ")+"?")
		}
		return b.resp("unknown", "Không tìm thấy hướng dẫn cho **"+subject+"**.")
	}
	hops := b.nodeLookup.HopsFromCache(node.ISLU)
	var sb strings.Builder
	prefix := "Cách "; if lang != "vi" { prefix = "How to " }
	sb.WriteString("**" + prefix + node.Label + ":**\n\n")
	if node.Desc != "" {
		rr := []rune(node.Desc); if len(rr) > 200 { rr = rr[:200] }
		sb.WriteString(string(rr)); if len([]rune(node.Desc)) > 200 { sb.WriteString("...") }
		sb.WriteString("\n\n")
	}
	var tools []string
	for _, h := range hops {
		if h.Node == nil { continue }
		tools = append(tools, "**"+h.Node.Label+"**")
		if len(tools) >= 4 { break }
	}
	relLabel := "Liên quan: "; if lang != "vi" { relLabel = "See also: " }
	if len(tools) > 0 { sb.WriteString(relLabel + strings.Join(tools, " · ")) }
	b.glowNode(node, hops)
	return b.resp("know", strings.TrimSpace(sb.String()))
}

func (b *Brain) listNodesIntent(subject, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	// Tìm node subject
	r := b.nodeLookup.Resolve(subject)
	node := r.Node
	if node == nil {
		if ex := extractQuerySubject(subject); ex != "" {
			node = b.nodeLookup.SearchExact(ex)
			if node == nil { node = b.nodeLookup.Search(ex) }
		}
	}

	nl2 := "\n\n"
	nl1 := "\n"

	if node != nil {
		// Lấy hops depth=1 → đây là "các X liên quan"
		hops := b.nodeLookup.HopsFromCache(node.ISLU)

		// Cũng tìm nodes có hops ĐẾN node này (inverse)
		// (không có inverse cache → dùng SuggestSimilar để bổ sung)
		sugg := b.nodeLookup.SuggestSimilar(node.Label, 6)

		var items []string
		seen := map[string]bool{node.Label: true}

		for _, h := range hops {
			if h.Node == nil || seen[h.Node.Label] { continue }
			items = append(items, "**"+h.Node.Label+"**")
			seen[h.Node.Label] = true
		}
		for _, s := range sugg {
			if seen[s.Label] || s.Name == node.Name { continue }
			items = append(items, "**"+s.Label+"**")
			seen[s.Label] = true
		}

		if len(items) == 0 {
			return b.resp("know", "**"+node.Label+"**"+nl1+"_Chưa có danh sách liên quan trong Silk Tree._")
		}

		var sb strings.Builder
		if lang == "vi" {
			sb.WriteString("**Các loại / ví dụ về " + node.Label + ":**" + nl2)
		} else {
			sb.WriteString("**Types / examples of " + node.Label + ":**" + nl2)
		}
		sb.WriteString(strings.Join(items, " · "))
		b.glowNode(node, hops)
		return b.resp("know", sb.String())
	}

	// Không tìm thấy node → tìm theo từ khóa trong byLabel
	// Tìm tất cả nodes có label chứa subject
	sugg := b.nodeLookup.SuggestSimilar(subject, 8)
	if len(sugg) > 0 {
		var items []string
		for _, s := range sugg { items = append(items, "**"+s.Label+"**") }
		var sb strings.Builder
		if lang == "vi" {
			sb.WriteString("**Liên quan đến [" + subject + "]:\n\n")
		} else {
						sb.WriteString("**Related to [" + subject + "]:\n\n")
		}
		sb.WriteString(strings.Join(items, " · "))
		return b.resp("know", sb.String())
	}
	if lang == "vi" {
		return b.resp("unknown", fmt.Sprintf("Không tìm thấy danh sách cho **%s**.", subject))
	}
	return b.resp("unknown", fmt.Sprintf("No list found for **%s**.", subject))
}


// defineNode — trả lời "X là gì?" dạng súc tích
// Format: 1 câu định nghĩa + key facts từ hops + see also
func (b *Brain) compareNodes(queryA, queryB, lang string) ChatResponse {
	if b.nodeLookup == nil {
		return b.resp("unknown", "Silk Tree chưa sẵn sàng.")
	}
	nodeA := b.nodeLookup.Search(queryA)
	nodeB := b.nodeLookup.Search(queryB)
	if nodeA == nil {
		if ex := extractQuerySubject(queryA); ex != "" { nodeA = b.nodeLookup.Search(ex) }
	}
	if nodeB == nil {
		if ex := extractQuerySubject(queryB); ex != "" { nodeB = b.nodeLookup.Search(ex) }
	}
	if nodeA == nil && nodeB == nil {
		return b.resp("unknown", fmt.Sprintf("Không tìm thấy '%s' và '%s'.", queryA, queryB))
	}
	if nodeA == nil { return b.explainNode(queryB, queryB, lang) }
	if nodeB == nil { return b.explainNode(queryA, queryA, lang) }

	hopsA := b.nodeLookup.HopsFromCache(nodeA.ISLU)
	hopsB := b.nodeLookup.HopsFromCache(nodeB.ISLU)

	setA := map[string]string{}
	setB := map[string]string{}
	for _, h := range hopsA { if h.Node != nil { setA[h.Node.Name] = h.Node.Label } }
	for _, h := range hopsB { if h.Node != nil { setB[h.Node.Name] = h.Node.Label } }

	var shared, onlyA, onlyB []string
	for name, label := range setA {
		if _, ok := setB[name]; ok { shared = append(shared, label) } else { onlyA = append(onlyA, label) }
	}
	for name, label := range setB {
		if _, ok := setA[name]; !ok { onlyB = append(onlyB, label) }
	}

	nl2 := "\n\n"
	var sb strings.Builder
	if lang == "vi" {
		sb.WriteString("## So sánh: **" + nodeA.Label + "** vs **" + nodeB.Label + "**" + nl2)
		if nodeA.Desc != "" {
			d := []rune(nodeA.Desc); if len(d) > 80 { d = d[:80] }
			sb.WriteString("**" + nodeA.Label + "**: " + string(d) + "..." + nl2)
		}
		if nodeB.Desc != "" {
			d := []rune(nodeB.Desc); if len(d) > 80 { d = d[:80] }
			sb.WriteString("**" + nodeB.Label + "**: " + string(d) + "..." + nl2)
		}
		var simScore float64
	unionSize := len(setA) + len(setB) - len(shared)
	if unionSize > 0 { simScore = float64(len(shared)) / float64(unionSize) * 100 }
	if len(shared) > 0 {
		sb.WriteString(fmt.Sprintf("**Điểm chung** (%.0f%% tương đồng): ", simScore) + strings.Join(shared, " · ") + nl2)
	} else {
		sb.WriteString(fmt.Sprintf("_Tương đồng: %.0f%%_ — hai khái niệm ít liên kết trực tiếp."+nl2, simScore))
	}
		if len(onlyA) > 0 { sb.WriteString("**Chỉ " + nodeA.Label + "**: " + strings.Join(onlyA, " · ") + nl2) }
		if len(onlyB) > 0 { sb.WriteString("**Chỉ " + nodeB.Label + "**: " + strings.Join(onlyB, " · ") + nl2) }
		if len(shared)+len(onlyA)+len(onlyB) == 0 {
			sb.WriteString("_Chưa đủ edges để so sánh chi tiết._")
		}
	} else {
		sb.WriteString("## Compare: **" + nodeA.Label + "** vs **" + nodeB.Label + "**" + nl2)
		if len(shared) > 0 { sb.WriteString("**In common**: " + strings.Join(shared, " · ") + nl2) }
		if len(onlyA) > 0 { sb.WriteString("**Only " + nodeA.Label + "**: " + strings.Join(onlyA, " · ") + nl2) }
		if len(onlyB) > 0 { sb.WriteString("**Only " + nodeB.Label + "**: " + strings.Join(onlyB, " · ") + nl2) }
	}
	b.glowNode(nodeA, hopsA)
	return b.resp("know", strings.TrimSpace(sb.String()))
}


// relatedWalk — silk walk query: "liên quan đến X" → list hops + NaturalSentence
func (b *Brain) relatedWalk(subject, lang string) ChatResponse {
	if subject == "" {
		if lang == "vi" {
			return b.resp("unknown", "Liên quan đến **gì**? Ví dụ: `liên quan đến sợ hãi`")
		}
		return b.resp("unknown", "Related to **what**? Example: `related to fear`")
	}

	node, hops := b.nodeLookup.SearchAndWalk(subject, 2)
	if node == nil {
		if lang == "vi" {
			return b.resp("unknown", fmt.Sprintf("Không tìm thấy **\"%s\"** trong Silk Tree.\n\nThử: `liên quan đến sợ hãi`, `liên quan đến HomeOS`", subject))
		}
		return b.resp("unknown", fmt.Sprintf("**\"%s\"** not found in Silk Tree.", subject))
	}

	if len(hops) == 0 {
		// Node tồn tại nhưng chưa có edges
		ns := b.nodeLookup.NaturalSentence(node, nil)
		if lang == "vi" {
			return b.resp("know", ns+"\n\n_Node này chưa có silk edges. Dùng `nhớ rằng` để dạy thêm._")
		}
		return b.resp("know", ns+"\n\n_No silk edges yet._")
	}

	// Phân loại hops depth=1
	var causes, opposite, similar, partOf, memberOf []string
	for _, h := range hops {
		if h.Node == nil || h.Depth > 1 { continue }
		lbl := h.Node.Label
		switch h.EdgeType {
		case 0x08: memberOf = append(memberOf, lbl)
		case 0x09: partOf   = append(partOf,   lbl)
		case 0x0A: causes   = append(causes,   lbl)
		case 0x0C: similar  = append(similar,  lbl)
		case 0x0D: opposite = append(opposite, lbl)
		}
	}

	// Heading
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("**%s** — silk connections:\n", node.Label))

	if len(causes) > 0 {
		sb.WriteString(fmt.Sprintf("\n**∘ Dẫn đến:** %s", strings.Join(causes, " · ")))
	}
	if len(opposite) > 0 {
		sb.WriteString(fmt.Sprintf("\n**⊥ Đối lập:** %s", strings.Join(opposite, " · ")))
	}
	if len(similar) > 0 {
		sb.WriteString(fmt.Sprintf("\n**≈ Tương đồng:** %s", strings.Join(similar, " · ")))
	}
	if len(partOf) > 0 {
		sb.WriteString(fmt.Sprintf("\n**⊂ Bao gồm:** %s", strings.Join(partOf, " · ")))
	}
	if len(memberOf) > 0 {
		sb.WriteString(fmt.Sprintf("\n**∈ Thuộc:** %s", strings.Join(memberOf, " · ")))
	}

	total := len(causes) + len(opposite) + len(similar) + len(partOf) + len(memberOf)
	sb.WriteString(fmt.Sprintf("\n\n_%d silk edges từ node này_", total))

	b.glowNode(node, hops) // 🌟 SSE live glow
	return b.resp("know", sb.String())
}

// pendingKnowledge — kiến thức mới chờ user xác nhận
type pendingKnowledge struct {
	Key   string // từ/cụm từ user hỏi
	Query string // câu query gốc (để context)
	Lang  string
}
