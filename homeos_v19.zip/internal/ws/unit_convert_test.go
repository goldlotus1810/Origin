package ws

import (
	"math"
	"testing"
)

func TestUnitConvert(t *testing.T) {
	t.Log("═══════════════════════════════")
	t.Log("Unit Conversion Engine")
	t.Log("═══════════════════════════════")

	tests := []struct {
		from   string
		to     string
		expect float64
		tol    float64 // tolerance %
		label  string
	}{
		// Currency
		{"100 usd", "vnd",   2545000, 5,  "100 USD → VND"},
		{"1 eur",   "usd",   1.087,   5,  "1 EUR → USD"},
		// Length
		{"1 km",    "mile",  0.6214,  1,  "1 km → mile"},
		{"100 cm",  "m",     1.0,     0,  "100 cm → m"},
		{"1 foot",  "cm",    30.48,   0.1,"1 foot → cm"},
		// Mass
		{"1 kg",    "lb",    2.2046,  0.1,"1 kg → lb"},
		{"1 ton",   "kg",    1000,    0,  "1 tấn → kg"},
		// Temperature
		{"100 °c",  "°f",    212.0,   0,  "100°C → °F"},
		{"0 °c",    "k",     273.15,  0,  "0°C → K"},
		{"32 °f",   "°c",    0.0,     0,  "32°F → 0°C"},
		// Data
		{"1 gb",    "mb",    1024,    0,  "1 GB → 1024 MB"},
		{"1 tb",    "gb",    1024,    0,  "1 TB → 1024 GB"},
		// Speed
		{"100 km/h","m/s",   27.78,   0.1,"100 km/h → m/s"},
		{"1 mph",   "km/h",  1.609,   0.1,"1 mph → km/h"},
		// Energy
		{"1 kcal",  "kj",    4.184,   0.1,"1 kcal → kJ"},
		// Time
		{"1 h",     "min",   60,      0,  "1 giờ → 60 phút"},
		{"1 day",   "h",     24,      0,  "1 ngày → 24 giờ"},
	}

	pass, fail := 0, 0
	for _, tc := range tests {
		result, ok := tryUnitConvert(tc.from, tc.to, "vi")
		if !ok {
			t.Logf("  ✗ %s → KHÔNG PARSE ĐƯỢC", tc.label)
			fail++; continue
		}

		// Lấy số kết quả từ tryUnitConvert để verify
		res, _, got := convert(func() float64 {
			v, _ := parseValueUnit(tc.from); return v
		}(), func() string {
			_, u := parseValueUnit(tc.from); return u
		}(), func() string {
			_, u := parseValueUnit(tc.to)
			if u == "" { return tc.to }
			return u
		}())
		_ = res
		_ = got

		// Dùng trực tiếp
		v, fromU := parseValueUnit(tc.from)
		_, toU := parseValueUnit(tc.to)
		if toU == "" { toU = tc.to }
		actual, _, _ := convert(v, fromU, toU)

		diff := math.Abs(actual-tc.expect) / (tc.expect + 1e-10) * 100
		if diff <= tc.tol || tc.tol == 0 && math.Abs(actual-tc.expect) < 0.01 {
			t.Logf("  ✓ %s → %s", tc.label, result)
			pass++
		} else {
			t.Logf("  ✗ %s got=%.4f want=%.4f (diff=%.1f%%)", tc.label, actual, tc.expect, diff)
			fail++
		}
	}

	t.Logf("\n[%d/%d PASS]", pass, pass+fail)
	if fail > 0 { t.Fail() }
}
