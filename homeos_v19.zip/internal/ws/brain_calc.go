// internal/ws/brain_calc.go
// CalcSkill — eval biểu thức số học đơn giản
// Trigger: câu có số + toán tử, hoặc "tính", "căn", "bình phương", "phần trăm"
//
// Hỗ trợ:
//   2+2, 15×7, 100/4, 2^10
//   căn bậc hai 144, sqrt 144
//   bình phương 12, 12^2
//   20% của 300, 15 phần trăm của 200
//   (3+4) * 2

package ws

import (
	"fmt"
	"math"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

// calcExpr nhận biểu thức thô, trả về kết quả dạng string
func (b *Brain) calcExpr(expr, lang string) string {
	if expr == "" {
		if lang == "vi" {
			return "Vui lòng nhập biểu thức, ví dụ: **2 + 2**, **căn bậc hai 144**, **20% của 300**"
		}
		return "Please enter an expression, e.g. **2 + 2**, **sqrt 144**, **20% of 300**"
	}

	lo := strings.ToLower(strings.TrimSpace(expr))

	// ── Căn bậc hai ────────────────────────────────────────────────────────
	if n, ok := extractSingleNum(lo, "căn bậc hai", "căn", "sqrt", "√"); ok {
		if n < 0 {
			return fmtCalcErr("căn bậc hai của số âm không xác định", lang)
		}
		res := math.Sqrt(n)
		return fmtCalcResult(fmt.Sprintf("√%.6g", n), res, lang)
	}

	// ── Bình phương ────────────────────────────────────────────────────────
	if n, ok := extractSingleNum(lo, "bình phương", "squared"); ok {
		return fmtCalcResult(fmt.Sprintf("%.6g²", n), n*n, lang)
	}

	// ── Phần trăm: "20% của 300" hoặc "20 phần trăm của 300" ───────────────
	if pct, base, ok := extractPercent(lo); ok {
		res := pct / 100.0 * base
		return fmtCalcResult(fmt.Sprintf("%.6g%% × %.6g", pct, base), res, lang)
	}

	// ── Biểu thức thông thường: thay ký tự tiếng Việt rồi eval ────────────
	normalized := normalizeExpr(lo)
	res, err := evalExpr(normalized)
	if err != nil {
		return fmtCalcErr(err.Error(), lang)
	}
	return fmtCalcResult(expr, res, lang)
}

// ── Helpers ────────────────────────────────────────────────────────────────

var reNum = regexp.MustCompile(`[-]?\d+(\.\d+)?`)

// extractSingleNum tìm số sau các từ khóa prefix
func extractSingleNum(lo string, prefixes ...string) (float64, bool) {
	for _, p := range prefixes {
		if idx := strings.Index(lo, p); idx >= 0 {
			rest := strings.TrimSpace(lo[idx+len(p):])
			m := reNum.FindString(rest)
			if m != "" {
				n, err := strconv.ParseFloat(m, 64)
				if err == nil {
					return n, true
				}
			}
		}
	}
	return 0, false
}

// extractPercent tìm "X% của Y" hoặc "X phần trăm của Y"
var rePct1 = regexp.MustCompile(`([\d.]+)\s*%\s*(của|of|×|x)?\s*([\d.]+)`)
var rePct2 = regexp.MustCompile(`([\d.]+)\s*ph[aầ]n\s*tr[aă]m\s*(của|of)?\s*([\d.]+)`)

func extractPercent(lo string) (pct, base float64, ok bool) {
	for _, re := range []*regexp.Regexp{rePct1, rePct2} {
		m := re.FindStringSubmatch(lo)
		if m != nil {
			p, e1 := strconv.ParseFloat(m[1], 64)
			b, e2 := strconv.ParseFloat(m[len(m)-1], 64)
			if e1 == nil && e2 == nil {
				return p, b, true
			}
		}
	}
	return 0, 0, false
}

// normalizeExpr chuẩn hoá ký tự để eval
func normalizeExpr(s string) string {
	// Tiếng Việt / ký tự đặc biệt → ASCII
	r := strings.NewReplacer(
		"×", "*", "✕", "*", "÷", "/", ":", "/",
		"^", "**", "²", "**2", "³", "**3",
		"cộng", "+", "trừ", "-", "nhân", "*", "chia", "/",
		"plus", "+", "minus", "-", "times", "*", "divided by", "/",
		"bằng", "", "=", "", " ", "",
	)
	normalized := r.Replace(s)
	// Bỏ ký tự không hợp lệ ngoài số và toán tử
	var sb strings.Builder
	for _, c := range normalized {
		if unicode.IsDigit(c) || strings.ContainsRune("+-*/.()%", c) {
			sb.WriteRune(c)
		}
	}
	return sb.String()
}

// evalExpr: recursive descent parser — hỗ trợ +, -, *, /, **, %
// Không dùng thư viện ngoài.
func evalExpr(s string) (float64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, fmt.Errorf("biểu thức rỗng")
	}
	p := &calcParser{src: s, pos: 0}
	val, err := p.parseExpr()
	if err != nil {
		return 0, err
	}
	if p.pos < len(p.src) {
		return 0, fmt.Errorf("ký tự không hợp lệ tại vị trí %d: %q", p.pos, string(p.src[p.pos]))
	}
	return val, nil
}

type calcParser struct {
	src string
	pos int
}

func (p *calcParser) peek() byte {
	if p.pos >= len(p.src) { return 0 }
	return p.src[p.pos]
}

func (p *calcParser) consume() byte {
	c := p.src[p.pos]; p.pos++; return c
}

// parseExpr: + và -
func (p *calcParser) parseExpr() (float64, error) {
	left, err := p.parseTerm()
	if err != nil { return 0, err }
	for {
		c := p.peek()
		if c != '+' && c != '-' { break }
		p.consume()
		right, err := p.parseTerm()
		if err != nil { return 0, err }
		if c == '+' { left += right } else { left -= right }
	}
	return left, nil
}

// parseTerm: * và /
func (p *calcParser) parseTerm() (float64, error) {
	left, err := p.parsePower()
	if err != nil { return 0, err }
	for {
		c := p.peek()
		if c != '*' && c != '/' && c != '%' { break }
		p.consume()
		right, err := p.parsePower()
		if err != nil { return 0, err }
		switch c {
		case '*': left *= right
		case '/':
			if right == 0 { return 0, fmt.Errorf("chia cho 0") }
			left /= right
		case '%': left = math.Mod(left, right)
		}
	}
	return left, nil
}

// parsePower: ** (right-associative)
func (p *calcParser) parsePower() (float64, error) {
	base, err := p.parseUnary()
	if err != nil { return 0, err }
	if p.pos+1 < len(p.src) && p.src[p.pos] == '*' && p.src[p.pos+1] == '*' {
		p.pos += 2
		exp, err := p.parsePower() // right-associative
		if err != nil { return 0, err }
		return math.Pow(base, exp), nil
	}
	return base, nil
}

// parseUnary: dấu âm
func (p *calcParser) parseUnary() (float64, error) {
	if p.peek() == '-' {
		p.consume()
		v, err := p.parsePrimary()
		return -v, err
	}
	if p.peek() == '+' {
		p.consume()
	}
	return p.parsePrimary()
}

// parsePrimary: số hoặc (expr)
func (p *calcParser) parsePrimary() (float64, error) {
	if p.peek() == '(' {
		p.consume()
		v, err := p.parseExpr()
		if err != nil { return 0, err }
		if p.peek() != ')' { return 0, fmt.Errorf("thiếu dấu )") }
		p.consume()
		return v, nil
	}
	// Đọc số
	start := p.pos
	if p.peek() == '-' { p.pos++ }
	for p.pos < len(p.src) && (p.src[p.pos] >= '0' && p.src[p.pos] <= '9' || p.src[p.pos] == '.') {
		p.pos++
	}
	if p.pos == start { return 0, fmt.Errorf("không tìm thấy số") }
	return strconv.ParseFloat(p.src[start:p.pos], 64)
}

// fmtCalcResult format kết quả đẹp
func fmtCalcResult(expr string, result float64, lang string) string {
	var resStr string
	if result == math.Trunc(result) && math.Abs(result) < 1e15 {
		resStr = fmt.Sprintf("%.0f", result)
	} else {
		resStr = strconv.FormatFloat(result, 'f', -1, 64)
	}
	if lang == "vi" {
		return fmt.Sprintf("**%s = %s**", expr, resStr)
	}
	return fmt.Sprintf("**%s = %s**", expr, resStr)
}

func fmtCalcErr(msg, lang string) string {
	if lang == "vi" {
		return fmt.Sprintf("Không thể tính: %s", msg)
	}
	return fmt.Sprintf("Cannot evaluate: %s", msg)
}

// detectCalcExpr kiểm tra xem câu có phải biểu thức toán học không
// Trả về (expr, true) nếu match
func detectCalcExpr(lo string) (string, bool) {
	// Trigger keyword rõ ràng
	calcPrefixes := []string{"tính ", "calculate ", "compute ", "eval "}
	for _, p := range calcPrefixes {
		if strings.HasPrefix(lo, p) {
			return strings.TrimSpace(lo[len(p):]), true
		}
	}

	// Căn bậc hai / sqrt
	for _, p := range []string{"căn bậc hai", "căn ", "sqrt", "√"} {
		if strings.Contains(lo, p) {
			return lo, true
		}
	}

	// Bình phương
	if strings.Contains(lo, "bình phương") || strings.Contains(lo, "squared") {
		return lo, true
	}

	// Phần trăm: "X% của Y" hoặc "X phần trăm"
	if rePct1.MatchString(lo) || rePct2.MatchString(lo) {
		return lo, true
	}

	// Biểu thức thuần: chứa số và toán tử (+, -, *, /, ×, ÷, ^)
	hasNum := reNum.MatchString(lo)
	hasOp  := strings.ContainsAny(lo, "+-×÷*/^") ||
		strings.Contains(lo, "cộng") || strings.Contains(lo, "trừ") ||
		strings.Contains(lo, "nhân") || strings.Contains(lo, "chia")
	// Phải ngắn (không phải câu hỏi dài) và có cả số lẫn toán tử
	if hasNum && hasOp && len([]rune(lo)) <= 60 {
		// Loại trừ nếu có nhiều từ thông thường (không phải biểu thức)
		wordCount := len(strings.Fields(lo))
		numCount  := len(reNum.FindAllString(lo, -1))
		if numCount > 0 && wordCount <= numCount*3 {
			return lo, true
		}
	}

	return "", false
}
