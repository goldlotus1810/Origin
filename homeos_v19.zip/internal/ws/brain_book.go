// internal/ws/brain_book.go
// Brain.LoadBook — đọc file text → BookMemory (ĐN) → FlushToSilk (QR)
//
// Pipeline:
//   user: "đọc sách /path/to/book.txt"
//   → IntentReadBook → Brain.loadBookFile(path)
//   → BookShelf.Read(title, paragraphs)
//   → BookMemory.FlushToSilk(graph)    ← ĐN → QR (QT7)
//   → brain trả lời EmotionalProfile
//
// Quy tắc:
//   - Chỉ đọc .txt / .md (plaintext)
//   - Tách đoạn bằng dòng trống (double newline)
//   - Không đọc file > 5MB (QT2: ∞-1)
//   - FlushToSilk ngay — không cần Dream cycle vì user đã trigger chủ động

package ws

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const maxBookSize = 5 * 1024 * 1024 // 5MB — QT2

// loadBookFile đọc file → BookShelf → FlushToSilk
// Trả về response text để hiển thị cho user
func (b *Brain) loadBookFile(path, lang string) string {
	// ── 1. Đọc file ──────────────────────────────────────────────
	info, err := os.Stat(path)
	if err != nil {
		if lang == "vi" {
			return fmt.Sprintf("❌ Không tìm thấy file: `%s`\n\n_Hãy dùng đường dẫn đầy đủ, VD: `/home/user/sach.txt`_", path)
		}
		return fmt.Sprintf("❌ File not found: `%s`", path)
	}
	if info.Size() > maxBookSize {
		if lang == "vi" {
			return fmt.Sprintf("❌ File quá lớn (%.1f MB > 5MB). Vui lòng dùng file nhỏ hơn.", float64(info.Size())/1e6)
		}
		return fmt.Sprintf("❌ File too large (%.1fMB > 5MB).", float64(info.Size())/1e6)
	}

	ext := strings.ToLower(filepath.Ext(path))
	if ext != ".txt" && ext != ".md" && ext != "" {
		if lang == "vi" {
			return fmt.Sprintf("❌ Chỉ hỗ trợ .txt và .md (nhận được: `%s`)", ext)
		}
		return fmt.Sprintf("❌ Only .txt and .md supported (got: `%s`)", ext)
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		return fmt.Sprintf("❌ Lỗi đọc file: %v", err)
	}

	// ── 2. Tách đoạn ─────────────────────────────────────────────
	title := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	content := string(raw)
	paragraphs := splitParagraphs(content)
	if len(paragraphs) == 0 {
		if lang == "vi" {
			return fmt.Sprintf("❌ File trống hoặc không có nội dung: `%s`", path)
		}
		return fmt.Sprintf("❌ Empty file: `%s`", path)
	}

	// ── 3. Đọc vào BookShelf ─────────────────────────────────────
	mem := b.bookShelf.Read(title, paragraphs)

	// ── 4. FlushToSilk — ĐN → QR ─────────────────────────────────
	var flushResult string
	if b.s != nil && b.s.world != nil {
		result := mem.FlushToSilk(b.s.world.Graph)
		flushResult = fmt.Sprintf(
			"\n\n**Ghi vào Silk Tree:**\n"+
			"  • %d từ → node (ĐN/QR)\n"+
			"  • %d cạnh ngữ nghĩa\n"+
			"  • %d bỏ qua (chưa đủ confidence)",
			result.WordsCommitted, result.EdgesAdded, result.WordsSkipped)
	}

	// ── 5. Trả về EmotionalProfile ───────────────────────────────
	profile := mem.EmotionalProfile()

	if lang == "vi" {
		return fmt.Sprintf(
			"✅ **Đã đọc xong!**\n\n"+
			"**%s** — %d đoạn văn\n\n"+
			"```\n%s\n```"+
			"%s\n\n"+
			"_Hỏi tôi về sách: `%s cảm giác gì?` hoặc `từ [từ] trong sách`_",
			title, len(paragraphs), profile, flushResult, title)
	}
	return fmt.Sprintf(
		"✅ **Done reading!**\n\n"+
		"**%s** — %d paragraphs\n\n"+
		"```\n%s\n```"+
		"%s",
		title, len(paragraphs), profile, flushResult)
}

// respondAboutBook tìm sách trong shelf và trả lời câu hỏi
func (b *Brain) respondAboutBook(query, lang string) string {
	mem, title := b.bookShelf.Find(query)
	if mem == nil {
		// Liệt kê sách đã đọc
		titles := b.bookShelf.AllTitles()
		if len(titles) == 0 {
			if lang == "vi" {
				return "Tôi chưa đọc sách nào. Dùng: `đọc sách /path/to/file.txt`"
			}
			return "No books loaded yet. Use: `read book /path/to/file.txt`"
		}
		if lang == "vi" {
			return fmt.Sprintf("Sách đã đọc: **%s**\n\nHỏi tôi về một trong số chúng.", strings.Join(titles, "**, **"))
		}
		return fmt.Sprintf("Books loaded: **%s**", strings.Join(titles, "**, **"))
	}

	resp := mem.RespondAboutBook(query, b.curve)
	if lang == "vi" {
		return fmt.Sprintf("📖 **%s**\n\n%s", title, resp)
	}
	return fmt.Sprintf("📖 **%s**\n\n%s", title, resp)
}

// splitParagraphs tách text thành đoạn bằng dòng trống
func splitParagraphs(text string) []string {
	// Normalize line endings
	text = strings.ReplaceAll(text, "\r\n", "\n")
	text = strings.ReplaceAll(text, "\r", "\n")

	// Tách bằng double newline
	raw := strings.Split(text, "\n\n")
	var result []string
	for _, p := range raw {
		p = strings.TrimSpace(p)
		if len([]rune(p)) >= 10 { // bỏ đoạn quá ngắn
			result = append(result, p)
		}
	}
	return result
}
