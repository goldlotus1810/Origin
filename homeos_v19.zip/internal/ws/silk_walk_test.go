package ws

import (
	"os"
	"strings"
	"testing"
)

func TestSilkWalkDepth(t *testing.T) {
	if _, err := os.Stat("../../homeos.olang"); err != nil { t.Skip("homeos.olang not found") }
	if err := os.Chdir("../.."); err != nil { t.Skip(err) }
	defer os.Chdir("internal/ws")

	b := NewBrain(nil)
	if b.nodeLookup == nil { t.Skip("nodeLookup not ready") }

	queries := []struct{ q string; minLen int }{
		{"transformer", 30},
		{"deep learning", 30},
		{"phân tích sâu reinforcement learning", 50},
		{"bạn nghĩ gì về AI", 30},
		{"claude nghĩ gì về consciousness", 30},
		{"hippocampus", 30},
		{"LLM", 30},
	}
	for _, tc := range queries {
		p := b.Parse(tc.q)
		r := b.Respond(p)
		preview := []rune(r.Answer)
		if len(preview) > 160 { preview = preview[:160] }
		t.Logf("Q: %-42s tag=%-9s len=%d  %s", tc.q, r.Tag, len(r.Answer), string(preview))
		if len(r.Answer) < tc.minLen {
			t.Errorf("Q=%q: too short (%d < %d)", tc.q, len(r.Answer), tc.minLen)
		}
		_ = strings.TrimSpace(r.Answer)
	}
}

func TestSilkWalkEdgesWork(t *testing.T) {
	if _, err := os.Stat("../../homeos.olang"); err != nil { t.Skip() }
	if err := os.Chdir("../.."); err != nil { t.Skip(err) }
	defer os.Chdir("internal/ws")

	nl := NewNodeLookup("homeos.olang")
	root, hops := nl.SearchAndWalk("transformer", 3)
	if root == nil { t.Fatal("transformer not found") }
	t.Logf("Root: %s (%s), hops: %d", root.Name, root.Label, len(hops))
	for _, h := range hops {
		if h.Node != nil {
			t.Logf("  hop[%d]: %s (%s)", h.Depth, h.Node.Name, h.Node.Label)
		}
	}
	if len(hops) == 0 {
		t.Log("  No hops — edge section may not be at expected position")
	}
}
