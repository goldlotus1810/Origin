package ws

// score_search.go — Semantic derivative search
//
// Thay thế hardcoded pattern matching bằng token-score overlap.
//
// Triết lý (từ user):
//   node     = đạo hàm của các node tạo nên nó
//   silk     = đạo hàm của các node được liên kết
//   node == silk
//   search(câu) = tìm giao điểm đạo hàm
//
// Kỹ thuật: TF-IDF lite + cosine overlap trên token bag
//   - Mỗi node có token bag = tokenize(label + desc + aliases)
//   - Inverted index: token → []*KnownNode (build 1 lần khi load)
//   - ScoreSearch(query): tính score = |query_tokens ∩ node_tokens| / |node_tokens|
//   - ParseDerivative(query): phát hiện intent từ token overlap với intent-seeds

import (
	"math"
	"sort"
	"strings"
	"unicode"
)

// tokenIndex: inverted index token → node score entries
// Được build 1 lần trong buildTokenIndex(), dùng cho ScoreSearch
type tokenIndex map[string][]*KnownNode

// ScoredNode — kết quả search có score
type ScoredNode struct {
	Node  *KnownNode
	Score float64
}

// buildTokenIndex xây inverted index từ tất cả nodes
// Gọi 1 lần sau build() + buildAdjCache()
func (nl *NodeLookup) buildTokenIndex() {
	nl.mu.Lock()
	defer nl.mu.Unlock()

	idx := make(tokenIndex, len(nl.byISLU)*8)
	for _, node := range nl.byISLU {
		toks := nodeTokens(node)
		seen := map[string]bool{}
		for _, t := range toks {
			if seen[t] || len(t) < 2 { continue }
			seen[t] = true
			idx[t] = append(idx[t], node)
		}
	}
	nl.tokIdx = idx
}

// nodeTokens: tokenize label + desc + aliases của 1 node
func nodeTokens(node *KnownNode) []string {
	var out []string
	add := func(s string) {
		for _, t := range tokenize(s) {
			out = append(out, t)
		}
	}
	add(node.Label)
	add(node.Desc)
	add(node.Name)
	for _, a := range node.Aliases {
		add(a)
	}
	return out
}

// tokenize: tách chuỗi thành tokens tiếng Việt + English
// - lowercase
// - tách theo space và dấu câu
// - giữ nguyên dấu tiếng Việt (quan trọng cho "liên quan")
func tokenize(s string) []string {
	s = strings.ToLower(strings.TrimSpace(s))
	var tokens []string
	var cur strings.Builder
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			cur.WriteRune(r)
		} else {
			if cur.Len() >= 2 {
				tokens = append(tokens, cur.String())
			}
			cur.Reset()
		}
	}
	if cur.Len() >= 2 {
		tokens = append(tokens, cur.String())
	}
	return tokens
}

// ScoreSearch: tìm top-N nodes có score cao nhất với query
// Score = TF-IDF lite: |query_toks ∩ node_toks| weighted by IDF
func (nl *NodeLookup) ScoreSearch(query string, topN int) []ScoredNode {
	nl.mu.RLock()
	defer nl.mu.RUnlock()

	if nl.tokIdx == nil || len(nl.tokIdx) == 0 {
		return nil
	}

	qToks := tokenize(query)
	if len(qToks) == 0 { return nil }

	// IDF: log(total_nodes / nodes_with_token)
	totalNodes := float64(len(nl.byISLU))

	// Tích lũy score cho từng node
	scores := map[uint64]float64{}
	for _, tok := range qToks {
		nodes, ok := nl.tokIdx[tok]
		if !ok { continue }
		idf := math.Log(totalNodes/float64(len(nodes)) + 1)
		for _, n := range nodes {
			scores[n.ISLU] += idf
		}
	}

	// Normalize bởi số tokens của node (tránh ưu tiên node desc dài)
	qLower := strings.ToLower(strings.TrimSpace(query))
	results := make([]ScoredNode, 0, len(scores))
	for islu, sc := range scores {
		node := nl.byISLU[islu]
		if node == nil { continue }
		nToks := float64(len(nodeTokens(node)))
		if nToks < 1 { nToks = 1 }
		normalized := sc / math.Sqrt(nToks)

		// Accuracy bonus: exact/prefix/contains name match
		nameLower := strings.ToLower(node.Name)
		labelLower := strings.ToLower(node.Label)
		switch {
		case nameLower == qLower || labelLower == qLower:
			normalized *= 4.0 // exact match → luôn đứng đầu
		case strings.HasPrefix(nameLower, qLower) || strings.HasPrefix(labelLower, qLower):
			normalized *= 2.0
		case strings.Contains(nameLower, qLower) || strings.Contains(labelLower, qLower):
			normalized *= 1.5
		}

		results = append(results, ScoredNode{Node: node, Score: normalized})
	}

	sort.Slice(results, func(i, j int) bool {
		return results[i].Score > results[j].Score
	})

	if topN > 0 && len(results) > topN {
		results = results[:topN]
	}
	return results
}

// ParseDerivative: phân tích intent + entities từ câu bằng token scoring
// Thay thế hardcoded pattern matching cho các intent phổ biến:
//   PathQuery, Related, Explain, QueryNode
//
// Trả về (intent, slots) — slots["path_a"], slots["path_b"], slots["subject"]
func (nl *NodeLookup) ParseDerivative(query string) (derivIntent, map[string]string) {
	slots := map[string]string{}
	lo := strings.ToLower(strings.TrimSpace(query))
	qToks := tokenize(lo)
	if len(qToks) == 0 { return DerUnknown, slots }

	// Guard: emotion queries không phải derivative intent
	emotionGuard := []string{"cảm thấy thế nào", "cảm xúc gì", "đang cảm thấy", "how do you feel", "bạn cảm thấy"}
	for _, g := range emotionGuard {
		if strings.Contains(lo, g) { return DerUnknown, slots }
	}

	// ── Bước 1: Phát hiện "relation tokens" trong câu ─────────────────────
	// Các từ này là derivative của "edge/relation" — không phải entity
	relationToks := map[string]float64{
		// tiếng Việt
		"liên":    0.6, "quan":   0.6, "đến":   0.4,
		"kết":     0.5, "nối":    0.5,
		"ảnh":     0.4, "hưởng": 0.4,
		"so":      0.5, "sánh": 0.5, "với": 0.3,
		// tiếng Anh
		"related": 0.8, "connect": 0.8, "link": 0.7,
		"between": 0.7, "path":   0.7, "versus": 0.6,
		"compare": 0.6, "vs":     0.6,
	}

	explainToks := map[string]float64{
		"tại":   0.5, "sao":  0.7,
		"vì":    0.5,
		"thế":   0.4, "nào": 0.4,
		"how":   0.8, "why": 0.8,
		"giải":  0.6, "thích": 0.6,
		"explain": 0.9,
	}

	// Tính tổng relation score và explain score
	relScore := 0.0
	expScore := 0.0
	entityToks := []string{}

	for _, tok := range qToks {
		if w, ok := relationToks[tok]; ok {
			relScore += w
		} else if w, ok := explainToks[tok]; ok {
			expScore += w
		} else {
			// Không phải stop/relation word → là entity token
			entityToks = append(entityToks, tok)
		}
	}

	// ── Bước 2: Tìm nodes từ entity tokens ───────────────────────────────
	if len(entityToks) == 0 { return DerUnknown, slots }

	// Tìm tất cả entity nodes có score cao
	entityQuery := strings.Join(entityToks, " ")
	topNodes := nl.ScoreSearch(entityQuery, 8)
	if len(topNodes) == 0 { return DerUnknown, slots }

	// ── Bước 3: Xác định intent từ scores ────────────────────────────────

	// PathQuery: có relation tokens mạnh VÀ có ít nhất 2 entity tokens khác nhau
	// → tìm 2 node peaks trong entity tokens
	if relScore >= 0.8 && len(entityToks) >= 2 {
		// Chia entity tokens thành 2 cụm: trước và sau relation word
		splitIdx := findRelationSplit(qToks, relationToks)
		if splitIdx > 0 {
			leftToks := entityTokensBefore(qToks, splitIdx, relationToks)
			rightToks := entityTokensAfter(qToks, splitIdx, relationToks)

			if len(leftToks) > 0 && len(rightToks) > 0 {
				leftQ  := strings.Join(leftToks, " ")
				rightQ := strings.Join(rightToks, " ")
				leftN  := nl.scoredFirst(leftQ)
				rightN := nl.scoredFirst(rightQ)
				if leftN != nil && rightN != nil && leftN.Name != rightN.Name {
					slots["path_a"] = leftN.Label
					slots["path_b"] = rightN.Label
					slots["path_a_node"] = leftN.Name
					slots["path_b_node"] = rightN.Name
					return DerPathQuery, slots
				}
			}
		}
	}

	// Explain: có explain tokens mạnh
	if expScore >= 0.8 && len(topNodes) > 0 {
		slots["subject"] = topNodes[0].Node.Label
		slots["subject_node"] = topNodes[0].Node.Name
		return DerExplain, slots
	}

	// Related: có relation tokens nhưng chỉ 1 entity
	if relScore >= 0.5 && len(topNodes) > 0 {
		slots["subject"] = topNodes[0].Node.Label
		slots["subject_node"] = topNodes[0].Node.Name
		return DerRelated, slots
	}

	// QueryNode: query đơn giản
	if len(topNodes) > 0 {
		slots["subject"] = topNodes[0].Node.Label
		slots["subject_node"] = topNodes[0].Node.Name
		return DerQueryNode, slots
	}

	return DerUnknown, slots
}

// derivIntent — intent từ ParseDerivative
type derivIntent int

const (
	DerUnknown   derivIntent = iota
	DerQueryNode             // tra cứu 1 node
	DerPathQuery             // X liên quan Y
	DerRelated               // liên quan đến X
	DerExplain               // giải thích / tại sao X
)

// scoredFirst: tìm node score cao nhất cho 1 query nhỏ
func (nl *NodeLookup) scoredFirst(query string) *KnownNode {
	// Thử exact match trước
	if n := nl.Search(query); n != nil { return n }
	// Fallback: score search
	top := nl.ScoreSearch(query, 1)
	if len(top) > 0 { return top[0].Node }
	return nil
}

// findRelationSplit: tìm index token quan hệ đầu tiên trong qToks
func findRelationSplit(toks []string, relMap map[string]float64) int {
	for i, t := range toks {
		if w := relMap[t]; w >= 0.5 {
			return i
		}
	}
	return -1
}

// entityTokensBefore: lấy entity tokens TRƯỚC split index
func entityTokensBefore(toks []string, split int, relMap map[string]float64) []string {
	var out []string
	for i := 0; i < split; i++ {
		if _, skip := relMap[toks[i]]; !skip {
			out = append(out, toks[i])
		}
	}
	return out
}

// entityTokensAfter: lấy entity tokens SAU split index, bỏ stop words cuối
func entityTokensAfter(toks []string, split int, relMap map[string]float64) []string {
	stopEnd := map[string]bool{
		"không": true, "chứ": true, "nhỉ": true, "hả": true,
		"phải": true, "đúng": true, "vậy": true,
	}
	var out []string
	for i := split + 1; i < len(toks); i++ {
		t := toks[i]
		if _, skip := relMap[t]; skip { continue }
		if stopEnd[t] { continue }
		out = append(out, t)
	}
	return out
}
