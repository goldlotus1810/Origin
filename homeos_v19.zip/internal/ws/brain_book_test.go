package ws

import (
	"strings"
	"testing"
	"os"
	"github.com/goldlotus1810/HomeOS/internal/agents"
)

func TestLoadBook_GWTW(t *testing.T) {
	shelf := agents.NewBookShelf()
	mem := shelf.Read("gwtw", agents.GWTWCorpus())

	profile := mem.EmotionalProfile()
	if !strings.Contains(profile, "gwtw") {
		t.Errorf("EmotionalProfile thiếu title: %s", profile)
	}
	if len(mem.TopEmotionalWords(5)) == 0 {
		t.Error("Không học được từ nào")
	}
	titles := shelf.AllTitles()
	if len(titles) != 1 || titles[0] != "gwtw" {
		t.Errorf("AllTitles sai: %v", titles)
	}
	t.Logf("✅ Learned %d words, %d pairs", len(mem.Words), len(mem.Pairs))
	t.Logf("Profile:\n%s", profile)
}

func TestBrain_LoadBookFile(t *testing.T) {
	// Tạo file txt tạm
	content := strings.Join(agents.GWTWCorpus(), "\n\n")
	path := "/tmp/homeos_test_book.txt"
	if err := os.WriteFile(path, []byte(content), 0644); err != nil {
		t.Fatal(err)
	}
	defer os.Remove(path)

	b := &Brain{
		bookShelf: agents.NewBookShelf(),
	}
	resp := b.loadBookFile(path, "vi")
	if !strings.Contains(resp, "✅") {
		t.Errorf("Expected success, got: %s", resp)
	}
	t.Log("Response:", resp[:200])
}

func TestBrain_LoadBook_NotFound(t *testing.T) {
	b := &Brain{bookShelf: agents.NewBookShelf()}
	resp := b.loadBookFile("/tmp/khong_ton_tai.txt", "vi")
	if !strings.Contains(resp, "❌") {
		t.Errorf("Expected error, got: %s", resp)
	}
}

func TestBrain_LoadBook_TooBig(t *testing.T) {
	// Tạo file > 5MB
	path := "/tmp/homeos_huge.txt"
	f, _ := os.Create(path)
	for i := 0; i < 6*1024; i++ {
		f.WriteString(strings.Repeat("x", 1024) + "\n\n")
	}
	f.Close()
	defer os.Remove(path)

	b := &Brain{bookShelf: agents.NewBookShelf()}
	resp := b.loadBookFile(path, "vi")
	if !strings.Contains(resp, "❌") {
		t.Errorf("Expected size error, got: %s", resp)
	}
}
