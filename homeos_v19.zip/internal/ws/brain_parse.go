// internal/ws/brain_parse.go
// Parse input, detect intent, ProcessISL

package ws

import (
	"fmt"
	"strings"
	"unicode"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func (b *Brain) Parse(raw string) ParsedInput {
	p := ParsedInput{
		Raw:   raw,
		Lower: strings.ToLower(strings.TrimSpace(raw)),
		Slots: make(map[string]string),
	}

	// Detect language
	p.Lang = detectLang(p.Lower)

	// Detect intent
	p.Intent = b.detectIntent(p.Lower, p.Slots)

	return p
}

func detectLang(s string) string {
	for _, r := range s {
		if r > unicode.MaxASCII {
			return "vi"
		}
	}
	return "en"
}

func (b *Brain) detectIntent(lo string, slots map[string]string) Intent {

	// IntentAsk: "claude nghĩ gì về X" / "hỏi claude X" / "theo bạn X"
	askPrefixes := []string{
		"claude nghĩ gì về ", "claude nghi gi ve ", "claude nghĩ về ",
		"hỏi claude ", "hoi claude ", "claude cho biết ", "claude nói về ",
		"theo claude ", "theo bạn ", "theo ban ", "claude ơi ", "claude oi ",
	}
	for _, pre := range askPrefixes {
		if strings.HasPrefix(lo, pre) {
			subj := strings.TrimSpace(strings.TrimPrefix(lo, pre))
			if len([]rune(subj)) >= 2 { slots["subject"] = subj; return IntentAsk }
		}
	}
	// IntentOpinion: "bạn nghĩ gì về X" / "your take on X" / "nhận xét về X"
	opinionPrefixes := []string{
		"bạn nghĩ gì về ", "ban nghi gi ve ", "bạn nghĩ về ",
		"your take on ", "what do you think about ", "opinion on ",
		"nhận xét về ", "nhan xet ve ", "đánh giá về ", "quan điểm về ",
	}
	for _, pre := range opinionPrefixes {
		if strings.HasPrefix(lo, pre) {
			subj := strings.TrimSpace(strings.TrimPrefix(lo, pre))
			if len([]rune(subj)) >= 2 { slots["subject"] = subj; return IntentOpinion }
		}
	}
	// Quiz-continue: "đố thêm" / "tiếp" → IntentQuiz
	quizContinue := []string{"đố thêm", "đố nữa", "tiếp theo quiz", "more quiz", "next quiz"}
	for _, qc := range quizContinue {
		if lo == qc { slots["quiz_subject"] = ""; return IntentQuiz }
	}
	if lo == "tiếp" || lo == "next" || lo == "more" {
		// Chỉ là quiz-continue nếu không match node nào
		// → check sau, để switch bình thường
	}

	// Actuator TRƯỚC TIÊN — tắt/bật đèn không được nhầm sang queryNode
	// Summary guard — "tóm tắt X" không phải actuator dù chứa "tắt"
	isSummaryPrefix := strings.HasPrefix(lo, "tóm tắt ") || strings.HasPrefix(lo, "tóm gọn ") || strings.HasPrefix(lo, "tóm gỏn ") ||
		strings.HasPrefix(lo, "tổng hợp về ") || strings.HasPrefix(lo, "tom tat ") ||
		strings.HasPrefix(lo, "summarize ") || strings.HasPrefix(lo, "summary of ") ||
		strings.HasPrefix(lo, "brief overview of ") || strings.HasPrefix(lo, "tóm lược ")
	// ── Derivative search: phân tích intent bằng token scoring ───────────────
	// Chạy khi câu dài ≥ 3 từ (cầu ngắn đả thường đú thẳng ngắn gọn hơn)
	if !isSummaryPrefix && b.nodeLookup != nil && len(strings.Fields(lo)) >= 3 {
		di, ds := b.nodeLookup.ParseDerivative(lo)
		switch di {
		case DerPathQuery:
			if ds["path_a_node"] != "" && ds["path_b_node"] != "" {
				slots["path_a"] = ds["path_a"]
				slots["path_b"] = ds["path_b"]
				return IntentPathQuery
			}
		case DerRelated:
			if ds["subject_node"] != "" {
				slots["related_subject"] = ds["subject"]
				return IntentRelated
			}
		case DerExplain:
			if ds["subject_node"] != "" {
				slots["explain_subject"] = ds["subject"]
				slots["explain_question"] = lo
				return IntentExplain
			}
		}
	}

	if isSummaryPrefix {
		// fall through to summary detection below
	} else if cmd := b.parseActuator(lo); cmd != nil {
		// Không trigger actuator nếu query là tên một node đã biết
		// "mã nguồn mở" chứa "mở" nhưng là tên node L3, không phải lệnh
		if b.nodeLookup != nil && b.nodeLookup.Search(lo) != nil {
			// skip actuator → fall through to QueryNode
		} else {
			slots["actuator_action"]   = cmd.Action
			slots["actuator_device"]   = cmd.Device
			slots["actuator_location"] = cmd.Location
			return IntentActuator
		}
	}
	// Thử IntentMatcher từ homeos.olang
	if b.matcher != nil {
		iid, _ := b.matcher.Match(lo)
		switch iid {
		case IIDGreeting: return IntentGreeting
		case IIDFarewell: return IntentFarewell
		case IIDIdentity: return IntentIdentity
		case IIDNaming:
			// Vẫn cần extract tên — fallthrough để slots["name"] được set
		case IIDLearn:
			// Vẫn cần extract value — fallthrough
		case IIDForget:
			// Vẫn cần extract subject — fallthrough
		case IIDRules:
			// Extract rule cụ thể nếu có: "qt3", "quy tắc 3"
			for i := 1; i <= 7; i++ {
				q := fmt.Sprintf("qt%d", i)
				if strings.Contains(lo, q) || strings.Contains(lo, fmt.Sprintf("quy tắc %d", i)) {
					slots["rule"] = q
				}
			}
			return IntentQueryRule
		case IIDStatus:
			// Nếu query khớp với một node trong knowledge base → ưu tiên IntentKnowledge
			// Ví dụ: "running" là en alias của SPORT_RUNNING
			if b.nodeLookup != nil {
				queryTrimmed := strings.TrimSpace(lo)
				// Chỉ override nếu query là 1-3 từ (không phải câu dài hỏi về status)
				if len(strings.Fields(queryTrimmed)) <= 3 {
					if n := b.nodeLookup.Search(queryTrimmed); n != nil {
						return IntentQueryNode
					}
				}
			}
			return IntentStatus
		case IIDSelf:    return IntentQuerySelf
		}
	}
	// Fallback: if/else logic cũ (cho Naming/Learn/Forget cần extract slots)
	return b.detectIntentFallback(lo, slots)
}

// detectIntentFallback — logic cũ, chỉ dùng khi cần extract slots
// detectIntentFallback — dùng vocab nodes + slot extraction
// Keywords đến từ INTENT_*/LOCATION_*/DEVICE_* nodes (không hardcode)

func (b *Brain) ProcessISL(pm PerceptMessage) PerceptMessage {
	// Không có primary → không biết về cái gì
	if pm.Primary.Uint64() == 0 {
		return PerceptMessage{}
	}

	// Bước 1: Walk từ primary address
	primaryWalks := b.percept.Walk(pm.Primary, 1)

	// Bước 2: Nếu có context, Intersect để tìm điểm chung
	var candidates []isl.Address
	if len(pm.Context) > 0 && pm.Context[0].Uint64() != 0 {
		allAddrs := append([]isl.Address{pm.Primary}, pm.Context...)
		candidates = b.percept.Intersect(allAddrs, 1)
	}

	// Bước 3: Build response ISL message
	// Primary của response = candidate tốt nhất (silk walk answer)
	var responsePrimary isl.Address
	var responseContext []isl.Address

	if len(candidates) > 0 {
		responsePrimary = candidates[0]
		if len(candidates) > 1 {
			responseContext = candidates[1:]
		}
	} else if len(primaryWalks) > 0 {
		// Fallback: dùng kết quả walk đơn từ primary
		for _, w := range primaryWalks {
			if len(w.Reached) > 0 {
				responsePrimary = w.Reached[0]
				break
			}
		}
	}

	// Context response = các địa chỉ đến được từ primary
	for _, w := range primaryWalks {
		for _, r := range w.Reached {
			responseContext = append(responseContext, r)
		}
	}

	ctx0 := isl.Address{}
	if len(responseContext) > 0 {
		ctx0 = responseContext[0]
	}

	return PerceptMessage{
		Msg: isl.ISLMessage{
			Version:     1,
			MsgType:     isl.MsgResponse,
			PrimaryAddr: responsePrimary,
			ContextAddr: ctx0,
			Confidence:  pm.Msg.Confidence,
		},
		Primary: responsePrimary,
		Context: responseContext,
		Frames:  pm.Frames, // frames gốc để decode nếu cần
	}
}

// ─── Respond (text bridge) ─────────────────────────────────────
// Respond vẫn là cầu nối cho UI text.
// Bên trong nó gọi ProcessISL, sau đó decode kết quả về text.
// Về lâu dài: UI tự nhận ISL và render trực tiếp.

// ─── Respond ───────────────────────────────────────────────────
// ─── Multi-turn Conversation Context ────────────────────────────────────────

// ConvContext lưu ngữ cảnh cuộc trò chuyện: node đang nói, lịch sử intent