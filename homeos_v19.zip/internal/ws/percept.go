// internal/ws/percept.go
//
// PERCEPTION LAYER — cổng chuyển thế giới ngoài thành ISL thuần
//
// Nguyên tắc (OLANG.md L6):
//   Text  → tokenize → ISL address per token → ISLMessage stream
//   Audio → FFT → nearest IPA phoneme → ISL address (tương lai)
//   Image → rayMarch → ISL address per region (tương lai)
//
// Agent KHÔNG nhận string. Agent nhận []ISLMessage.
// String chỉ tồn tại ở biên (user interface), không bên trong.
//
// Luồng:
//   User input (text/audio/image)
//       ↓ Percept.Encode()
//   []ISLMessage  ← đây là "ngôn ngữ" nội tại
//       ↓ Brain.ProcessISL()
//   []ISLMessage  ← response cũng là ISL
//       ↓ Percept.Decode()
//   User output (text/audio/image)

package ws

import (
	"strings"
	"unicode"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─── PerceptLayer ──────────────────────────────────────────────

// PerceptLayer — tầng cảm quan
// Chuyển đổi input thô → ISLMessage và ngược lại
type PerceptLayer struct {
	nl *NodeLookup // silk tree lookup
}

func NewPerceptLayer(olangPath string) *PerceptLayer {
	return &PerceptLayer{
		nl: NewNodeLookup(olangPath),
	}
}

// ─── ISLFrame — đơn vị tri thức sau perception ────────────────

// ISLFrame là kết quả perception của 1 token/vùng/âm
// Tương đương với "agent thấy/nghe/cảm nhận cái gì"
type ISLFrame struct {
	Addr       isl.Address  // địa chỉ ISL của concept này
	Node       *KnownNode   // node trong silk tree (có thể nil nếu chưa biết)
	Token      string       // token gốc (chỉ dùng để debug/decode về text)
	Confidence float32      // 0.0-1.0
	FrameType  FrameType
}

type FrameType uint8

const (
	FrameUnknown  FrameType = 0
	FrameConcept  FrameType = 1  // từ có nghĩa → node trong silk tree
	FrameAction   FrameType = 2  // động từ / lệnh
	FrameTarget   FrameType = 3  // tân ngữ
	FrameContext  FrameType = 4  // ngữ cảnh bổ sung
	FrameQuantity FrameType = 5  // số lượng
	FrameModifier FrameType = 6  // tính từ / trạng từ
)

// ─── PerceptMessage — ISL message sau khi encode ──────────────

// PerceptMessage là output của Perception Layer
// Đây là những gì agent thật sự "nhìn thấy" — không có string
type PerceptMessage struct {
	Msg     isl.ISLMessage  // ISL message chuẩn
	Frames  []ISLFrame      // các frames được nhận diện
	Primary isl.Address     // concept chính (high confidence)
	Intent  isl.Address     // intent/action được nhận diện
	Context []isl.Address   // ngữ cảnh bổ sung
}

// ─── Text Perception ──────────────────────────────────────────

// EncodeText — chuyển text → PerceptMessage (ISL thuần)
// Đây là bước đầu tiên thay thế string matching trong brain.go
func (p *PerceptLayer) EncodeText(text string) PerceptMessage {
	tokens := tokenizeVI(text)
	frames  := make([]ISLFrame, 0, len(tokens))

	// Pass 1: lookup từng token trong silk tree
	for _, tok := range tokens {
		if isStopWord(tok) { continue }

		node := p.nl.Search(tok)
		if node != nil {
			ft := frameTypeFromPOS(node.POS)
			frames = append(frames, ISLFrame{
				Addr:       islFromNode(node),
				Node:       node,
				Token:      tok,
				Confidence: 0.9,
				FrameType:  ft,
			})
			continue
		}

		// Không tìm thấy trong silk tree → unknown frame
		// Ghi lại để LeoAI học sau
		frames = append(frames, ISLFrame{
			Addr:       isl.Address{}, // zero addr = chưa biết
			Token:      tok,
			Confidence: 0.0,
			FrameType:  FrameUnknown,
		})
	}

	// Pass 2: xác định primary + intent từ frames
	primary, intent, context := extractSemantics(frames)

	// Build ISLMessage
	msg := isl.ISLMessage{
		Version:       1,
		MsgType:       isl.MsgQuery,
		PrimaryAddr:   primary,
		SecondaryAddr: intent,
		ContextAddr:   context[0], // context đầu tiên
		Confidence:    uint32(avgConfidence(frames) * 100),
	}

	return PerceptMessage{
		Msg:     msg,
		Frames:  frames,
		Primary: primary,
		Intent:  intent,
		Context: context,
	}
}

// DecodeToText — ISL address → text (để hiển thị cho user)
// Ngược lại với EncodeText — chỉ dùng ở biên giao tiếp
func (p *PerceptLayer) DecodeToText(addr isl.Address) string {
	islu := addr.Uint64()
	if islu == 0 { return "?" }

	p.nl.mu.RLock()
	defer p.nl.mu.RUnlock()

	if node, ok := p.nl.byISLU[islu]; ok {
		return node.Label
	}
	return addr.String() // fallback: hiển thị address dạng text
}

// ─── ISL Walk — agent "suy nghĩ" bằng Silk edges ─────────────

// WalkResult — kết quả walk từ 1 địa chỉ
type WalkResult struct {
	From     isl.Address
	Reached  []isl.Address  // các địa chỉ đến được
	Path     []isl.Address  // đường đi
	Confidence float32
}

// Walk — từ 1 ISL address, đi theo sợi tơ trong silk tree
// Đây là "suy nghĩ" của agent — không có string, chỉ có địa chỉ
func (p *PerceptLayer) Walk(from isl.Address, maxHops int) []WalkResult {
	islu := from.Uint64()
	if islu == 0 { return nil }

	p.nl.mu.RLock()
	node, ok := p.nl.byISLU[islu]
	p.nl.mu.RUnlock()

	if !ok { return nil }

	// Dùng SearchAndWalk để lấy hops
	_, hops := p.nl.SearchAndWalk(node.Label, maxHops)
	if len(hops) == 0 { return nil }

	results := make([]WalkResult, 0, len(hops))
	for _, hop := range hops {
		if hop.Node == nil { continue }
		results = append(results, WalkResult{
			From:       from,
			Reached:    []isl.Address{islFromNode(hop.Node)},
			Confidence: 0.85, // mỗi hop giảm confidence
		})
	}
	return results
}

// Intersect — tìm địa chỉ chung khi walk từ nhiều điểm khác nhau
// Đây là cách agent "suy luận": A∩B∩C → điểm giao = câu trả lời
//
// Ví dụ từ spec:
//   Walk([FAa8]) → {..., [ABa1.003], ...}
//   Walk([GCa4]) → {..., [ABa1.003], ...}
//   Walk([DCb4]) → {..., [ABa1.003], ...}
//   Intersect    → [ABa1.003] với confidence 0.97
func (p *PerceptLayer) Intersect(addrs []isl.Address, maxHops int) []isl.Address {
	if len(addrs) == 0 { return nil }

	// Walk từ mỗi điểm
	type reachSet map[uint64]float32
	sets := make([]reachSet, 0, len(addrs))

	for _, addr := range addrs {
		rs := make(reachSet)
		// Tự điểm xuất phát cũng tính
		rs[addr.Uint64()] = 1.0

		walks := p.Walk(addr, maxHops)
		for _, w := range walks {
			for _, reached := range w.Reached {
				key := reached.Uint64()
				if existing, ok := rs[key]; !ok || w.Confidence > existing {
					rs[key] = w.Confidence
				}
			}
		}
		sets = append(sets, rs)
	}

	if len(sets) == 0 { return nil }

	// Tìm giao điểm — các địa chỉ xuất hiện trong TẤT CẢ sets
	// Confidence = min của tất cả (điểm yếu nhất trong chain)
	type candidate struct {
		addr       uint64
		confidence float32
	}
	candidates := []candidate{}

	for k, conf := range sets[0] {
		inAll := true
		minConf := conf
		for _, s := range sets[1:] {
			c2, ok := s[k]
			if !ok { inAll = false; break }
			if c2 < minConf { minConf = c2 }
		}
		if inAll {
			candidates = append(candidates, candidate{k, minConf})
		}
	}

	// Sort theo confidence
	for i := 0; i < len(candidates); i++ {
		for j := i+1; j < len(candidates); j++ {
			if candidates[j].confidence > candidates[i].confidence {
				candidates[i], candidates[j] = candidates[j], candidates[i]
			}
		}
	}

	result := make([]isl.Address, 0, len(candidates))
	p.nl.mu.RLock()
	defer p.nl.mu.RUnlock()
	for _, c := range candidates {
		// Chuyển uint64 ngược lại thành Address
		for _, node := range p.nl.byISLU {
			if node.ISLU == c.addr {
				result = append(result, islFromNode(node))
				break
			}
		}
	}
	return result
}

// ─── Helpers ──────────────────────────────────────────────────

// islFromNode — KnownNode → isl.Address
func islFromNode(n *KnownNode) isl.Address {
	if n == nil { return isl.Address{} }
	return isl.FromBytes(n.ISL[:])
}

// frameTypeFromPOS — POS → FrameType
func frameTypeFromPOS(pos uint8) FrameType {
	switch pos {
	case POSNoun:  return FrameConcept
	case POSVerb:  return FrameAction
	case POSAdj:   return FrameModifier
	case POSAdv:   return FrameModifier
	}
	return FrameConcept
}

// extractSemantics — từ []ISLFrame rút ra primary/intent/context
func extractSemantics(frames []ISLFrame) (primary, intent isl.Address, context []isl.Address) {
	context = make([]isl.Address, 0)

	for _, f := range frames {
		if f.Addr.Uint64() == 0 { continue }

		switch f.FrameType {
		case FrameAction:
			if intent.Uint64() == 0 { intent = f.Addr }
		case FrameConcept:
			if primary.Uint64() == 0 {
				primary = f.Addr
			} else {
				context = append(context, f.Addr)
			}
		case FrameModifier, FrameContext:
			context = append(context, f.Addr)
		}
	}

	// Nếu không có gì, dùng frame đầu tiên có addr
	if primary.Uint64() == 0 {
		for _, f := range frames {
			if f.Addr.Uint64() != 0 {
				primary = f.Addr
				break
			}
		}
	}

	// Đảm bảo context không nil
	if len(context) == 0 {
		context = []isl.Address{{}} // zero addr
	}
	return
}

func avgConfidence(frames []ISLFrame) float32 {
	if len(frames) == 0 { return 0 }
	total := float32(0)
	n := 0
	for _, f := range frames {
		if f.Addr.Uint64() != 0 {
			total += f.Confidence
			n++
		}
	}
	if n == 0 { return 0 }
	return total / float32(n)
}

// ─── Vietnamese tokenizer ─────────────────────────────────────

// tokenizeVI — tách text tiếng Việt thành tokens có nghĩa
// Ưu tiên multi-word expressions trước
func tokenizeVI(text string) []string {
	text  = strings.TrimSpace(text)
	words := strings.Fields(text)
	if len(words) == 0 { return nil }

	result := make([]string, 0, len(words))
	i := 0
	for i < len(words) {
		// Thử 3-gram, 2-gram, rồi unigram
		if i+2 < len(words) {
			tri := strings.Join(words[i:i+3], " ")
			if !isStopWord(tri) && len([]rune(tri)) >= 4 {
				result = append(result, tri)
				i += 3
				continue
			}
		}
		if i+1 < len(words) {
			bi := strings.Join(words[i:i+2], " ")
			if !isStopWord(bi) && len([]rune(bi)) >= 3 {
				result = append(result, bi)
				i += 2
				continue
			}
		}
		w := words[i]
		if !isStopWord(w) && len([]rune(w)) >= 2 {
			result = append(result, w)
		}
		i++
	}
	return result
}

// isStopWord — từ không mang nghĩa, bỏ qua
func isStopWord(w string) bool {
	stops := map[string]bool{
		"là": true, "của": true, "và": true, "hoặc": true,
		"có": true, "được": true, "này": true, "đó": true,
		"thì": true, "mà": true, "để": true, "cho": true,
		"với": true, "về": true, "khi": true, "nếu": true,
		"the": true, "a": true, "an": true, "is": true,
		"are": true, "was": true, "were": true, "be": true,
		"in": true, "on": true, "at": true, "to": true,
		"of": true, "and": true, "or": true, "but": true,
		"tôi": true, "bạn": true, "nó": true, "họ": true,
		"tắt": true, "bật": true, "mở": true, "đóng": true, // actuator verbs handled separately
	}
	if stops[strings.ToLower(w)] { return true }
	// Bỏ qua từ toàn dấu câu
	for _, r := range w {
		if unicode.IsLetter(r) || unicode.IsDigit(r) { return false }
	}
	return true
}
