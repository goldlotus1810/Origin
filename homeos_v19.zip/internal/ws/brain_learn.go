// internal/ws/brain_learn.go
// Tách từ brain.go — learning — sendLearn, handleStatement, handleParagraph
// package ws — cùng package, truy cập Brain methods trực tiếp

package ws

import (
	"fmt"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func (b *Brain) sendLearn(key, value string, fire int) {
	if b.s == nil || b.s.bus == nil {
		return
	}
	conf := float64(fire) / 3.0
	if conf > 1.0 { conf = 1.0 }
	payload := fmt.Sprintf(`{"key":%q,"value":%q,"confidence":%.2f,"confirmed":%d}`,
		key, value, conf, fire)
	select {
	case b.s.bus <- &isl.ISLMessage{
		Version: 1,
		MsgType: isl.MsgLearn,
		Payload: []byte(payload),
	}:
	default: // không block nếu bus đầy
	}
}

// sendConfirmMsg gửi MsgLearn với confirmed++ để TeachSkill tăng confidence
func (b *Brain) sendConfirmMsg(key string) {
	if b.s == nil || b.s.bus == nil {
		return
	}
	payload := fmt.Sprintf(`{"key":%q,"confirmed":1}`, key)
	select {
	case b.s.bus <- &isl.ISLMessage{
		Version: 1,
		MsgType: isl.MsgLearn,
		Payload: []byte(payload),
	}:
	default:
	}
}

// sendPropose gửi MsgPropose khi ĐN đủ điều kiện promote QR
func (b *Brain) sendPropose(key string) {
	if b.s == nil || b.s.bus == nil {
		return
	}
	select {
	case b.s.bus <- &isl.ISLMessage{
		Version: 1,
		MsgType: isl.MsgPropose,
		Payload: []byte(key),
	}:
	default:
	}
}

// ─── Confirm / Reject helpers ──────────────────────────────────

// isConfirmSignal phát hiện user xác nhận ĐN gần nhất
func isConfirmSignal(lo string) bool {
	confirms := []string{
		// Tiếng Việt
		"có", "có ạ", "có chứ", "có đó",
		"ok", "oke", "okay",
		"được", "được ạ", "được rồi",
		"vâng", "vâng ạ", "vâng đúng",
		"ừ", "ừ đúng", "ừ được",
		"đồng ý", "đồng ý rồi", "đồng ý nhé",
		"nhớ đi", "ghi nhớ đi", "lưu lại đi",
		"đúng rồi", "đúng vậy", "đúng", "chính xác",
		"có muốn", "muốn nhớ", "nhớ nhé",
		// Tiếng Anh
		"yes", "yes please", "yep", "yeah", "yup",
		"ok sure", "sure", "alright",
		"correct", "right", "ok đúng",
	}
	for _, c := range confirms {
		if lo == c || strings.HasPrefix(lo, c+" ") || strings.HasSuffix(lo, " "+c) {
			return true
		}
	}
	return false
}

// isRejectSignal phát hiện user bác bỏ ĐN gần nhất (QT7 correction)
func isRejectSignal(lo string) bool {
	rejects := []string{
		// Tiếng Việt
		"không", "không ạ", "không cần", "không nhớ", "không cần nhớ",
		"thôi", "thôi không", "thôi khỏi",
		"bỏ đi", "bỏ qua",
		"sai rồi", "sai", "không đúng", "không phải", "không phải vậy",
		// Tiếng Anh
		"no", "nope", "nah", "no thanks",
		"wrong", "incorrect",
	}
	for _, r := range rejects {
		// "không" — chỉ reject khi đứng riêng (lo == r), đầu câu, hoặc cuối câu ngắn (<=3 words)
		isShort := len(strings.Fields(lo)) <= 3
		if lo == r {
			return true
		}
		if strings.HasPrefix(lo, r+" ") && isShort {
			return true
		}
		if strings.HasSuffix(lo, " "+r) && isShort {
			return true
		}
	}
	return false
}

// ─── IntentStatement & IntentParagraph handlers ────────────────

// isSentimentPhrase — phát hiện câu cảm thán / nói một mình
// Dấu hiệu: có cụm tính từ mức độ, không có dấu hỏi, không có động từ chính
func isSentimentPhrase(lo string) bool {
	intensifiers := []string{
		// "thật X" / "X thật"
		"thật đẹp", "thật tuyệt", "thật hay", "thật buồn", "thật vui",
		"thật tốt", "thật xấu", "thật lạ", "thật thú vị", "thật tệ",
		"thật ngon", "thật dở", "thật lớn", "thật nhỏ", "thật nhanh",
		// "X quá"
		"đẹp quá", "tuyệt quá", "hay quá", "buồn quá", "vui quá",
		"xấu quá", "ngon quá", "tệ quá", "lớn quá", "nhỏ quá",
		"đáng yêu quá", "nguy hiểm quá", "thú vị quá",
		// "X ghê" / "X nhỉ" / "X nhé"
		"đẹp ghê", "tuyệt ghê", "hay nhỉ", "đẹp nhỉ", "vui nhỉ",
		"đẹp nhé", "hay đấy", "tuyệt đấy", "tuyệt vời",
		// Cảm giác vật lý
		"mát quá", "lạnh quá", "nóng quá", "ấm quá", "lạnh ghê",
		"ấm quá trời", "nóng quá trời", "lạnh quá trời", "mát quá trời",
		"nóng ghê", "mát ghê", "lạnh nhỉ", "nóng nhỉ", "mát nhỉ",
		// "thật sự X"
		"thật sự đẹp", "thật sự tuyệt", "thật sự hay",
		// English
		"so beautiful", "so amazing", "so great", "so sad", "too bad",
		"looks great", "feels good",
	}
	for _, p := range intensifiers {
		if strings.Contains(lo, p) {
			return true
		}
	}
	return false
}

// extractStatementSubject — tách danh từ chính từ câu cảm thán
// "cái cây này thật đẹp" → "cây"
// "hoa này đẹp quá" → "hoa"
func extractStatementSubject(raw string) string {
	lo := strings.ToLower(strings.TrimSpace(raw))

	// Xóa prefix mở đầu
	for _, pre := range []string{"cái ", "con ", "cái con ", "những ", "các "} {
		lo = strings.TrimPrefix(lo, pre)
	}

	// Xóa suffix cảm thán
	suffixes := []string{
		" này thật đẹp", " thật đẹp", " đẹp quá", " tuyệt quá", " hay quá",
		" này thật tuyệt", " thật tuyệt", " này đẹp quá", " này hay quá",
		" đẹp ghê", " hay nhỉ", " đẹp nhỉ", " tuyệt vời", " tuyệt đấy",
		" buồn quá", " vui quá", " ngon quá", " tệ quá", " lớn quá",
		" thật hay", " thật vui", " thật buồn", " thật tốt",
		" này.", " này!", " này",
		".", "!", "?",
	}
	for _, suf := range suffixes {
		if strings.HasSuffix(lo, suf) {
			lo = strings.TrimSuffix(lo, suf)
		}
	}
	// Trim "này" ở cuối nếu còn
	lo = strings.TrimSuffix(strings.TrimSpace(lo), " này")
	lo = strings.TrimSuffix(strings.TrimSpace(lo), " đó")
	return strings.TrimSpace(lo)
}

// handleStatement — xử lý câu cảm thán
// Hành vi theo QT10: Agent im lặng mặc định
// Nhưng nếu nhận ra subject → "đồng ý" ngắn gọn
// extractQuerySubject tách subject chính từ câu hỏi dài
// "Tokyo là thủ đô của nước nào?" → "Tokyo"
// "Vịnh Hạ Long ở đâu?" → "Vịnh Hạ Long"
// "thép được làm từ gì?" → "thép"
// "vaccine là gì?" → "vaccine" (đã xử lý bởi detectIntentFallback nhưng thêm fallback)
// tryMultiKeyword xử lý câu hỏi có nhiều keyword: "A và B", "A với B", "A and B"
// Nếu cả hai A và B đều có trong NodeLookup → trả lời tổng hợp
func (b *Brain) tryMultiKeyword(p ParsedInput) *ChatResponse {
	lo := p.Lower
	// Separators: "và", "với", "cùng", " and ", " or ", " & "
	separators := []string{" và ", " với ", " cùng ", " and ", " or ", " & "}
	for _, sep := range separators {
		if !strings.Contains(lo, sep) { continue }
		parts := strings.SplitN(lo, sep, 2)
		if len(parts) != 2 { continue }
		a := strings.TrimSpace(parts[0])
		b2 := strings.TrimSpace(parts[1])
		// Bỏ qua nếu a hoặc b2 quá dài (câu, không phải keyword)
		if len([]rune(a)) > 30 || len([]rune(b2)) > 30 { continue }
		nodeA := b.nodeLookup.Search(a)
		nodeB := b.nodeLookup.Search(b2)
		if nodeA == nil || nodeB == nil { continue }
		// Cả hai đều biết → trả lời tổng hợp
		_, hopsA := b.nodeLookup.SearchAndWalk(a, 2)
		_, hopsB := b.nodeLookup.SearchAndWalk(b2, 2)
		sentA := b.nodeLookup.NaturalSentence(nodeA, hopsA)
		sentB := b.nodeLookup.NaturalSentence(nodeB, hopsB)
		combined := sentA + "\n\n---\n\n" + sentB
		r := b.resp("know", combined)
		return &r
	}
	return nil
}

func extractQuerySubject(lo string) string {
	lo = strings.TrimSpace(lo)
	// Xóa dấu câu cuối
	lo = strings.TrimRight(lo, "?!.")

	// Patterns: "X là [gì/ai/ở đâu/như thế nào/...]"
	questionSuffixes := []string{
		" là gì", " là ai", " là ở đâu", " ở đâu", " là thứ gì",
		" là cái gì", " là loại gì", " như thế nào", " hoạt động thế nào",
		" được làm từ gì", " được tạo ra như thế nào", " có nghĩa là gì",
		" là thủ đô của nước nào", " là thủ đô", " thuộc nước nào",
		" có ở đâu", " xuất xứ từ đâu", " có tác dụng gì",
		" là bao nhiêu", " bằng bao nhiêu",
	}
	for _, suf := range questionSuffixes {
		if idx := strings.Index(lo, suf); idx > 0 {
			subj := strings.TrimSpace(lo[:idx])
			if len([]rune(subj)) >= 2 {
				return subj
			}
		}
	}

	// "X có ... không?" → X
	if idx := strings.Index(lo, " có "); idx > 0 {
		before := strings.TrimSpace(lo[:idx])
		// Chỉ lấy nếu before là 1-3 từ (tên riêng, không phải câu dài)
		if len(strings.Fields(before)) <= 4 && len([]rune(before)) >= 2 {
			return before
		}
	}

	// "X [là/được/có/gồm] ..." → X nếu X match node
	parts := strings.SplitN(lo, " là ", 2)
	if len(parts) == 2 && len([]rune(strings.TrimSpace(parts[0]))) >= 2 {
		return strings.TrimSpace(parts[0])
	}

	return ""
}

func (b *Brain) handleStatement(p ParsedInput) ChatResponse {
	text := p.Slots["statement_text"]
	if text == "" {
		text = p.Raw
	}

	subj := extractStatementSubject(text)

	// Thử tìm node cho subject
	if subj != "" {
		node := b.nodeLookup.Search(subj)
		if node != nil {
			_, hops := b.nodeLookup.SearchAndWalk(subj, 2)
			b.glowNode(node, hops)
			// Trả lời ngắn — đồng ý + 1 câu về subject
			sent := b.nodeLookup.NaturalSentence(node, hops)
			// Cắt chỉ lấy câu đầu (trước \n\n)
			if idx := strings.Index(sent, "\n\n"); idx > 0 {
				sent = sent[:idx]
			}
			if p.Lang == "vi" {
				return b.resp("agree", "Đúng vậy! "+sent)
			}
			return b.resp("agree", "Indeed! "+sent)
		}
	}

	// Không nhận ra subject → đồng cảm ngắn
	if p.Lang == "vi" {
		return b.resp("agree", "Đúng vậy!")
	}
	return b.resp("agree", "Indeed!")
}

// handleParagraph — xử lý đoạn văn dài
// 1. Tokenize → tìm known/unknown
// 2. Trả lời những gì biết
// 3. Hỏi muốn ghi nhớ những gì chưa biết
func (b *Brain) handleParagraph(p ParsedInput) ChatResponse {
	text := p.Raw

	// Tokenize: bigram + unigram từ đoạn văn
	tokens := extractKeywords(text)

	known   := []string{}
	unknown := []string{}
	seenKnown   := map[string]bool{}
	seenUnknown := map[string]bool{}

	// Hư từ không được vào unknown
	hardStop := map[string]bool{
		"là": true, "và": true, "của": true, "trong": true, "với": true,
		"các": true, "những": true, "được": true, "cho": true, "từ": true,
		"đến": true, "hay": true, "hoặc": true, "nhưng": true, "khi": true,
		"đã": true, "sẽ": true, "đang": true, "bởi": true, "vì": true,
	}

	for _, tok := range tokens {
		if seenKnown[tok] || seenUnknown[tok] {
			continue
		}

		// Known node?
		node := b.nodeLookup.Search(tok)
		if node != nil {
			if !seenKnown[node.Label] {
				known = append(known, node.Label)
				seenKnown[node.Label] = true
			}
			continue
		}

		// Known ĐN?
		results := b.state.Search(tok)
		if len(results) > 0 {
			if !seenKnown[tok] {
				known = append(known, tok)
				seenKnown[tok] = true
			}
			continue
		}

		// Unknown — chỉ giữ nếu có vẻ là compound word thật
		// Bigram: cả 2 từ phải ≥3 rune VÀ không phải hư từ
		parts := strings.Fields(tok)
		if len(parts) == 2 {
			w1, w2 := parts[0], parts[1]
			if hardStop[w1] || hardStop[w2] { continue }
			if len([]rune(w1)) < 3 || len([]rune(w2)) < 3 { continue }
			// Bigram hợp lệ
			seenUnknown[tok] = true
			unknown = append(unknown, tok)
		} else if len(parts) == 1 {
			// Unigram: ≥4 rune, không hư từ
			if len([]rune(tok)) < 4 || hardStop[tok] { continue }
			seenUnknown[tok] = true
			unknown = append(unknown, tok)
		}
	}

	// Giới hạn để response gọn
	if len(known) > 6 {
		known = known[:6]
	}
	if len(unknown) > 5 {
		unknown = unknown[:5]
	}

	var sb strings.Builder

	if len(known) > 0 {
		// Lấy câu mô tả ngắn cho node đầu tiên (quan trọng nhất)
		mainNode := b.nodeLookup.Search(known[0])
		if mainNode != nil {
			_, hops := b.nodeLookup.SearchAndWalk(known[0], 2)
			b.glowNode(mainNode, hops)
			desc := b.nodeLookup.NaturalSentence(mainNode, hops)
			if idx := strings.Index(desc, "\n\n"); idx > 0 {
				desc = desc[:idx]
			}
			sb.WriteString(desc)
			sb.WriteString("\n\n")
		}

		if len(known) > 1 {
			boldList := make([]string, len(known)-1)
			for i, k := range known[1:] {
				boldList[i] = "**" + k + "**"
			}
			sb.WriteString("Tôi cũng biết về: " + strings.Join(boldList, ", ") + ".\n\n")
		}
	}

	if len(unknown) > 0 {
		boldU := make([]string, len(unknown))
		for i, u := range unknown {
			boldU[i] = "**" + u + "**"
		}
		sb.WriteString("Tôi chưa biết: " + strings.Join(boldU, ", ") + ".\n\n")
		sb.WriteString("💡 Muốn tôi ghi nhớ những khái niệm này không?")

		// Lưu danh sách unknown vào pendingNew (từ đầu tiên)
		if len(unknown) > 0 {
			b.pendingNew = &pendingKnowledge{
				Key:   strings.Join(unknown, "|"),
				Query: text,
				Lang:  p.Lang,
			}
		}
		return b.respAsk("paragraph", sb.String(), "paragraph:"+strings.Join(unknown, ","))
	}

	if sb.Len() == 0 {
		if p.Lang == "vi" {
			return b.resp("unknown", "Tôi chưa hiểu đoạn này. Thử hỏi từng khái niệm riêng lẻ.")
		}
		return b.resp("unknown", "I don't recognize this. Try asking about specific concepts.")
	}

	return b.resp("know", strings.TrimSpace(sb.String()))
}

// extractKeywords — tách từ khóa ngữ nghĩa từ đoạn văn
// Chiến lược đơn giản & hiệu quả:
//   1. Chuẩn hóa text (xóa dấu câu)
//   2. Bigram tất cả các cặp từ liền nhau (không filter stopword)
//   3. Unigram tất cả từ ≥4 rune
//   4. handleParagraph tự phân loại known/unknown qua NodeLookup
func extractKeywords(text string) []string {
	// Normalize: thay dấu câu bằng dấu cách
	var norm strings.Builder
	for _, r := range text {
		switch r {
		case ',', '.', ';', ':', '(', ')', '\n', '\r', '-', '!', '?', '…', '_':
			norm.WriteRune(' ')
		default:
			norm.WriteRune(r)
		}
	}
	words := strings.Fields(norm.String())

	result := []string{}
	seen := map[string]bool{}

	// Bước 1: Bigram — ưu tiên cao nhất
	// Tiếng Việt nhiều compound word 2 âm tiết
	for i := 0; i+1 < len(words); i++ {
		w1 := strings.ToLower(words[i])
		w2 := strings.ToLower(words[i+1])
		// Bỏ bigram nếu word ngắn quá (≤1 rune = chữ số, ký tự đặc biệt)
		if len([]rune(w1)) < 2 || len([]rune(w2)) < 2 { continue }
		bg := w1 + " " + w2
		if !seen[bg] {
			result = append(result, bg)
			seen[bg] = true
		}
	}

	// Bước 2: Unigram ≥4 rune
	hardStop := map[string]bool{
		"là": true, "và": true, "của": true, "trong": true, "với": true,
		"các": true, "những": true, "được": true, "cho": true, "từ": true,
		"đến": true, "hay": true, "hoặc": true, "nhưng": true, "khi": true,
		"đã": true, "sẽ": true, "đang": true, "bởi": true, "vì": true,
		"the": true, "and": true, "for": true, "with": true, "that": true,
		"this": true, "are": true, "has": true, "have": true, "been": true,
	}
	for _, w := range words {
		lo := strings.ToLower(w)
		if len([]rune(lo)) < 4 { continue }
		if hardStop[lo] { continue }
		if !seen[lo] {
			result = append(result, lo)
			seen[lo] = true
		}
	}

	return result
}

// ── IntentAsk handler ────────────────────────────────────────────────────────
// "Claude nghĩ gì về X" / "hỏi Claude X"
func (b *Brain) respondAsk(p ParsedInput) ChatResponse {
	subj := p.Slots["subject"]
	if subj == "" { subj = p.Raw }

	if b.nodeLookup != nil {
		node := b.nodeLookup.Search(subj)
		if node != nil {
			_, hops := b.nodeLookup.SearchAndWalk(node.Label, 3)
			base := b.nodeLookup.NaturalSentence(node, hops)
			return b.resp("ask", base+"\n\nBạn muốn tìm hiểu thêm khía cạnh nào?")
		}
	}
	return b.resp("ask", fmt.Sprintf("Tôi chưa có thông tin về \"%s\". Bạn có thể cho tôi biết thêm không?", subj))
}

// ── IntentOpinion handler ────────────────────────────────────────────────────
// "bạn nghĩ gì về X" / "your take on X"
func (b *Brain) respondOpinion(p ParsedInput) ChatResponse {
	subj := p.Slots["subject"]
	if subj == "" { subj = p.Raw }

	if b.nodeLookup != nil {
		node := b.nodeLookup.Search(subj)
		if node != nil {
			_, hops := b.nodeLookup.SearchAndWalk(node.Label, 4)
			base := b.nodeLookup.NaturalSentence(node, hops)

			// Góc nhìn: walk tu si, lấy node có desc
			perspectives := []string{}
			for _, h := range hops {
				if h.Node != nil && h.Node.Label != node.Label && h.Node.Desc != "" {
					perspectives = append(perspectives, "**"+h.Node.Label+"**")
				}
				if len(perspectives) >= 4 { break }
			}
			answer := base
			if len(perspectives) > 0 {
				answer += "\n\nCác góc nhìn liên quan: " + strings.Join(perspectives, ", ") + "."
			}
			answer += "\n\nBạn đồng ý hay có góc nhìn khác?"
			return b.resp("opinion", answer)
		}
	}
	return b.resp("opinion", fmt.Sprintf("Tôi chưa đủ dữ liệu về \"%s\" để có quan điểm có căn cứ. Chia sẻ thêm để tôi học nhé.", subj))
}
