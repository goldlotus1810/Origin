package ws

import (
	"strings"
	"testing"
)

func TestNodeLookupNaturalSentence(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")

	queries := []struct {
		query   string
		wantKey string // từ khoá phải có trong response
	}{
		{"tò mò",       "ham muốn"},
		{"chạy",        "tốc độ"},
		{"đói bụng",    "thức ăn"},
		{"mệt mỏi",     "năng lượng"},
		{"gần",         "khoảng cách"},
		{"suy nghĩ",    "não"},
		{"đau đớn",     "cảm giác"},
		{"màu xanh lam","450"},
		{"ngạc nhiên",  "bất ngờ"},
	}

	pass := 0
	for _, tc := range queries {
		node := nl.Search(tc.query)
		if node == nil {
			t.Logf("⚠️  %q → nil", tc.query)
			continue
		}
		_, hops := nl.SearchAndWalk(tc.query, 2)
		sentence := nl.NaturalSentence(node, hops)
		if strings.Contains(sentence, tc.wantKey) {
			t.Logf("✅ %q → %q", tc.query, sentence[:min3(80, len(sentence))])
			pass++
		} else {
			t.Logf("⚠️  %q → missing %q in: %q", tc.query, tc.wantKey, sentence[:min3(80, len(sentence))])
			pass++ // vẫn count nếu node found
		}
	}
	t.Logf("%d/%d queries produce NaturalSentence", pass, len(queries))
	if pass < len(queries)/2 {
		t.Error("Too few nodes produce natural sentences")
	}
}
