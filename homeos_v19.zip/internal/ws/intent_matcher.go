// internal/ws/intent_matcher.go
//
// IntentMatcher — đọc INTENT_* nodes từ homeos.olang, match input
//
// Thay thế hoàn toàn detectIntent() if/else trong brain.go
// Go chỉ còn: load nodes → hash input words → compare → trả intent_id
//
// Khi muốn thêm intent mới hoặc sửa patterns:
//   → OlangAppendNode("INTENT_XXX", dna với patterns mới)
//   → KHÔNG cần sửa Go code, KHÔNG cần recompile

package ws

import (
	"crypto/sha256"
	"encoding/binary"
	"log"
	"os"
	"sort"
	"strings"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// Opcode
const opEmit = 0x52

// IntentID — map từ byte trong DNA
const (
	IIDGreeting = 1
	IIDFarewell = 2
	IIDIdentity = 3
	IIDNaming   = 4
	IIDLearn    = 5
	IIDForget   = 6
	IIDRules    = 7
	IIDStatus   = 8
	IIDSelf     = 9
)

// intentNode — 1 INTENT_* node đã parse
type intentNode struct {
	name       string
	intentID   uint8
	priority   uint8
	patterns   [][4]byte // SHA256[:4] của mỗi pattern string
}

// IntentMatcher — load từ .olang, match input
type IntentMatcher struct {
	mu      sync.RWMutex
	nodes   []*intentNode
	olangPath string
}

func NewIntentMatcher(olangPath string) *IntentMatcher {
	m := &IntentMatcher{olangPath: olangPath}
	m.load()
	return m
}

// load đọc homeos.olang, parse tất cả INTENT_* nodes
func (m *IntentMatcher) load() {
	raw, err := os.ReadFile(m.olangPath)
	nedgesX := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedgesX*olang.EdgeSize
	if edgeStart < 280 { edgeStart = len(raw) }
	if err != nil {
		log.Printf("○ IntentMatcher: cannot read %s: %v", m.olangPath, err)
		return
	}

	var nodes []*intentNode

	// Scan tất cả ND records, lọc INTENT_* trong L7
	for off := 0; off+14 < edgeStart; {
		if raw[off] != 'N' || raw[off+1] != 'D' { off++; continue }
		off += 2
		if off+16 > len(raw) { break }

		layerID := raw[off]; off++
		off += 8  // skip ISL
		off += 4  // skip codepoint
		dnaLen  := int(binary.BigEndian.Uint32(raw[off:off+4])); off += 4
		nameLen := int(raw[off]); off++

		if off+dnaLen+nameLen > len(raw) { break }
		dna  := raw[off : off+dnaLen]; off += dnaLen
		name := string(raw[off : off+nameLen]); off += nameLen

		// Chỉ quan tâm L7 INTENT_*
		if layerID != 7 { continue }
		if !strings.HasPrefix(name, "INTENT_") { continue }
		if len(dna) < 5 { continue }

		// Parse DNA: EMIT(0x52) + intentID(1B) + priority(1B) + flags(1B) + count(1B) + hashes...
		if dna[0] != opEmit { continue }
		iid      := dna[1]
		priority := dna[2]
		// flags  := dna[3]  // reserved
		count    := int(dna[4])

		pats := make([][4]byte, 0, count)
		base := 5
		for i := 0; i < count && base+4 <= len(dna); i++ {
			var h [4]byte
			copy(h[:], dna[base:base+4])
			pats = append(pats, h)
			base += 4
		}

		nodes = append(nodes, &intentNode{
			name:     name,
			intentID: iid,
			priority: priority,
			patterns: pats,
		})
	}

	// Sort by priority (cao → thấp)
	sort.Slice(nodes, func(i, j int) bool {
		return nodes[i].priority > nodes[j].priority
	})

	m.mu.Lock()
	m.nodes = nodes
	m.mu.Unlock()

	log.Printf("○ IntentMatcher: loaded %d intent nodes from %s", len(nodes), m.olangPath)
}

// Match trả về intentID và tên node match, hoặc 0 nếu không tìm thấy
func (m *IntentMatcher) Match(input string) (uint8, string) {
	m.mu.RLock()
	nodes := m.nodes
	m.mu.RUnlock()

	lo := strings.ToLower(input)

	// Tạo set các hash của: toàn bộ input + từng từ + bigrams
	inputHashes := buildHashes(lo)

	for _, node := range nodes {
		for _, pat := range node.patterns {
			if _, ok := inputHashes[pat]; ok {
				return node.intentID, node.name
			}
		}
	}
	return 0, ""
}

// Reload — gọi sau khi OlangAppendNode thêm INTENT_* mới
func (m *IntentMatcher) Reload() {
	m.load()
}

// buildHashes — hash input string nhiều cách để match flexible
func buildHashes(lo string) map[[4]byte]struct{} {
	set := make(map[[4]byte]struct{})

	add := func(s string) {
		h := sha256.Sum256([]byte(s))
		var k [4]byte; copy(k[:], h[:4])
		set[k] = struct{}{}
	}

	// Toàn bộ input
	add(lo)

	// Từng từ
	words := strings.Fields(lo)
	for _, w := range words {
		add(w)
	}

	// Bigrams (2 từ liên tiếp) — để match "xin chào", "tên bạn"
	for i := 0; i+1 < len(words); i++ {
		add(words[i] + " " + words[i+1])
	}

	// Trigrams (3 từ) — để match "tên bạn là", "bạn là ai"
	for i := 0; i+2 < len(words); i++ {
		add(words[i] + " " + words[i+1] + " " + words[i+2])
	}

	// Prefix match: nếu input bắt đầu bằng pattern
	// VD: "nhớ rằng X" → hash("nhớ rằng")
	for n := 2; n <= 4 && n <= len(words); n++ {
		add(strings.Join(words[:n], " "))
	}

	return set
}
