package ws

import (
	"fmt"
	"testing"
)

func TestNodeLookupNewNodes(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")

	tests := []struct {
		query string
		want  string
	}{
		{"tò mò",     "LIFE_CURIOSITY"},
		{"suy nghĩ",  "LIFE_THINK"},
		{"chạy",      "LIFE_RUN"},
		{"đói bụng",  "PERCEPT_HUNGER"},
		{"mệt mỏi",   "PERCEPT_TIRED"},
		{"gần",       "PERCEPT_NEAR"},
		{"đau đớn",   "PERCEPT_PAIN"},
		{"chim",      "LIFE_BIRD"},
		{"màu xanh lam", "PERCEPT_BLUE"},
	}

	pass := 0
	for _, tc := range tests {
		n := nl.Search(tc.query)
		if n != nil {
			t.Logf("✅ %q → %s [%s] desc=%q", tc.query, n.Name, n.Label, n.Desc[:min3(40, len(n.Desc))])
			pass++
		} else {
			t.Logf("⚠️  %q → nil (want %s)", tc.query, tc.want)
		}
	}
	t.Logf("%d/%d NodeLookup queries pass", pass, len(tests))
	if pass == 0 {
		t.Error("NodeLookup cannot find any new L3/L6 nodes")
	}
}

func min3(a, b int) int {
	if a < b { return a }
	return b
}

func TestNodeLookupL5Programs(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	tests := []string{
		"mô hình ngôn ngữ lớn", "agent", "Silk Tree",
		"HomeOS", "ISL", "thuật toán", "mã hóa",
	}
	pass := 0
	for _, q := range tests {
		n := nl.Search(q)
		if n != nil {
			t.Logf("✅ %q → %s [L%d]", q, n.Name, n.LayerID)
			pass++
		} else {
			t.Logf("⚠️  %q → nil", q)
		}
	}
	t.Logf("%d/%d L5 queries pass", pass, len(tests))
	if pass == 0 { t.Error("No L5 nodes found") }
}

func TestSilkWalkEdges(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")

	// Test: node LIFE_FEAR có tìm được không
	node, hops := nl.SearchAndWalk("sợ hãi", 3)
	if node == nil {
		t.Fatal("LIFE_FEAR not found")
	}
	t.Logf("Root: %s [L%d]", node.Name, node.LayerID)
	t.Logf("Hops from walk: %d", len(hops))
	// Note: homeos.olang dùng format đơn giản (seed scripts)
	// Chưa có edge table — walk trả về 0 hops là đúng
	// Test chỉ xác nhận node tồn tại và SearchAndWalk không panic
	t.Log("✓ SearchAndWalk không panic — edge table sẽ được thêm sau")

	// Test walk từ LIFE_JOY
	node2, hops2 := nl.SearchAndWalk("vui vẻ", 3)
	if node2 != nil {
		t.Logf("LIFE_JOY hops: %d", len(hops2))
		t.Log("✓ Silk walk LIFE_JOY OK")
	}
}

func edgeTypeName(t uint8) string {
	m := map[uint8]string{0x08:"∈",0x09:"⊂",0x0A:"∘",0x0B:"≡",0x0C:"≈",0x0D:"⊥"}
	if s, ok := m[t]; ok { return s }
	return fmt.Sprintf("%02x", t)
}

func TestL4ObjectsWalk(t *testing.T) {
	nl := NewNodeLookup("../../homeos.olang")
	tests := []struct{ q, want string }{
		{"đèn bật",  "PERCEPT_BRIGHT"},
		{"cà phê",   "PERCEPT_BITTER"},
		{"xe hơi",   "PERCEPT_FAST"},
		{"tủ lạnh",  "PERCEPT_COLD"},
		{"nước",     "PERCEPT_THIRST"},
	}
	pass := 0
	for _, tc := range tests {
		node, hops := nl.SearchAndWalk(tc.q, 2)
		if node == nil { t.Logf("❌ %q not found", tc.q); continue }
		found := false
		for _, h := range hops {
			if h.Node != nil && h.Node.Name == tc.want { found = true }
		}
		if found {
			t.Logf("✅ %q → hops include %s", tc.q, tc.want)
			pass++
		} else {
			ns := nl.NaturalSentence(node, hops)
			t.Logf("⚠️  %q → %s hops:%d  ns:%q", tc.q, node.Name, len(hops), ns[:min3(60,len(ns))])
		}
	}
	t.Logf("%d/%d L4 walk tests pass", pass, len(tests))
}
