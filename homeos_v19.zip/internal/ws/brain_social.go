// internal/ws/brain_social.go
// Social responses — greet, help, status, identity...

package ws

import (
	"fmt"
	"strings"
)

func (b *Brain) greet(lang string) string {
	if lang == "vi" {
		return fmt.Sprintf(
			"Xin chào! Tôi là **%s** — Agent AI Master của HomeOS.\n\n"+
				"Tôi có thể:\n"+
				"• Trả lời câu hỏi về hệ thống\n"+
				"• Tra cứu Silk Tree (`tìm X`)\n"+
				"• Ghi nhớ thông tin (`nhớ rằng X`)\n"+
				"• Đổi tên (`gọi bạn là X`)\n\n"+
				"_Hỏi gì đi?_", b.state.GetName())
	}
	return fmt.Sprintf("Hello! I'm **%s** — HomeOS Agent AI Master. Ask me anything.", b.state.GetName())
}

func (b *Brain) farewell(lang string) string {
	if lang == "vi" {
		return fmt.Sprintf("Tạm biệt! **%s** sẽ tiếp tục chạy nền.\n_HomeOS không ngủ._", b.state.GetName())
	}
	return fmt.Sprintf("Goodbye! **%s** keeps running in the background.", b.state.GetName())
}

func (b *Brain) help(lang string) string {
	if lang == "vi" {
		return "**Các lệnh hiểu được:**\n\n" +
			"**Hỏi về bản thân:**\n" +
			"• `bạn là ai` · `tên bạn là gì`\n" +
			"• `gọi bạn là [tên]` — đặt tên mới\n\n" +
			"**Tra cứu Silk Tree:**\n" +
			"• `[tên node]` — tìm node\n" +
			"• `liệt kê` — xem tất cả nodes\n" +
			"• `trạng thái` — xem stats\n\n" +
			"**Quy tắc ○:**\n" +
			"• `7 quy tắc` — xem tất cả\n" +
			"• `qt1`...`qt7` — quy tắc cụ thể\n\n" +
			"**Bộ nhớ:**\n" +
			"• `nhớ rằng [điều gì đó]` — ghi vào ĐN\n" +
			"• `quên [điều gì đó]` — xóa khỏi ĐN"
	}
	return "**Commands:**\n" +
		"• `who are you` · `what is your name`\n" +
		"• `name you [X]` — rename me\n" +
		"• `[node name]` — look up node\n" +
		"• `7 rules` — show all QTs\n" +
		"• `remember that [X]` — save to ĐN"
}

func (b *Brain) identity(lang string) string {
	silk := 0
	if b.s != nil && b.s.world != nil {
		silk = b.s.world.Graph.NodeCount()
	}
	n := b.state.GetName()
	if lang == "vi" {
		return fmt.Sprintf(
			"Tôi là **%s** — Agent AI Master.\n\n"+
			"```\nISL:   [A][A][M][1]\nLayer: L7 Programs\nTên:   %s\nDNA:   SPAWN·OR·SPHERE·BOX\n```\n\n"+
			"Silk Tree: %d nodes · ĐN: %d · QR: %d\n\n"+
			"_Đổi tên: `gọi bạn là [tên mới]`_",
			n, n, silk, b.state.DNCount(), b.state.QRCount())
	}
	return fmt.Sprintf(
		"I am **%s** — Agent AI Master.\n\n"+
		"```\nISL:  [A][A][M][1]\nLayer: L7\nName: %s\n```\n\n"+
		"Silk Tree: %d nodes · ĐN: %d · QR: %d",
		n, n, silk, b.state.DNCount(), b.state.QRCount())
}

func (b *Brain) rules(specific string, lang string) string {
	all := map[string][2]string{
		"qt1": {"○ LÀ NGUỒN GỐC", "Mọi thứ đều là instance của ○.\n`mọi f == ○[f]`"},
		"qt2": {"∞ LÀ SAI — ∞-1 MỚI ĐÚNG", "∞ = không tồn tại\n∞-1 = tồn tại thật (hữu hạn nhưng rất lớn)\n→ FUSE opcode giới hạn mọi vòng lặp"},
		"qt3": {"VẬT LÝ LÀ SỰ THẬT", "+/- = giả thuyết\n⧺ = thêm vào (đã chứng minh)\n⊖ = bớt đi (đã chứng minh)\n== = sự thật vật lý\nQuy trình: quan sát → +/- → chứng minh → =="},
		"qt4": {"BẢN CHẤT QUYẾT ĐỊNH TỒN TẠI", "Agent == tập hợp Skill của nó\nNode == SDF + SLI, không hơn không kém\nChỉ dùng ⧺ / ⊖ / == trong định nghĩa"},
		"qt5": {"BẢN CHẤT QUYẾT ĐỊNH VỊ TRÍ", "Cùng bản chất → cùng nhóm\nTương đồng → xếp gần\nNhóm ⊂ nhóm → tầng cao hơn xây trên tầng thấp"},
		"qt6": {"HAI CHIỀU TỒN TẠI", "SDF = hữu hình (đo được, cảm nhận)\nISL = vô hình (ý tưởng, quan hệ, lệnh)\nSDF ⧺ ISL = Smooth_union"},
		"qt7": {"HỌC / LEAD — VÒNG ĐỜI TRI THỨC", "QR = tri thức đã chứng minh · dài hạn · bất biến\nĐN = tri thức đang học · ngắn hạn · có thể sửa\nVòng đời: quan sát → ĐN(+/-) → chứng minh → QR(==)\nCorrection: người dùng bác bỏ → ĐN bị xóa"},
	}

	if specific != "" {
		if r, ok := all[specific]; ok {
			return fmt.Sprintf("**%s — %s**\n\n%s", strings.ToUpper(specific), r[0], r[1])
		}
	}

	// Tất cả
	var sb strings.Builder
	sb.WriteString("**7 Quy Tắc của ○:**\n\n")
	for i := 1; i <= 7; i++ {
		k := fmt.Sprintf("qt%d", i)
		r := all[k]
		sb.WriteString(fmt.Sprintf("**%s — %s**\n_%s_\n\n", strings.ToUpper(k), r[0], firstLine(r[1])))
	}
	sb.WriteString("_Gõ `qt1`...`qt7` để xem chi tiết từng quy tắc._")
	return sb.String()
}

func (b *Brain) status() string {
	var nodeCount, edgeCount int
	if b.s != nil && b.s.world != nil {
		nodeCount = b.s.world.Graph.NodeCount()
		edgeCount = len(b.s.world.Graph.AllEdges())
	}
	return fmt.Sprintf(
		"**HomeOS Status**\n\n"+
			"```\n○  Running\n🛡 SecurityGate: ONLINE\nSilk Tree: %d nodes · %d edges\nAAM Name:  %s\nĐN (disk): %d mục\nQR (disk): %d mục\n```\n\n"+
			"_ISL bus: active · NxT cycle: running_",
		nodeCount, edgeCount, b.state.GetName(), b.state.DNCount(), b.state.QRCount())
}

// report trả lời "em đang thấy gì?"
// Kết nối PerceptLayerHot nếu có → trả về dominant label thật sự
func (b *Brain) report() string {
	if b.s == nil || b.s.world == nil {
		return "Em chưa có thông tin cảm biến không gian."
	}
	w      := b.s.world
	nNodes := w.Graph.NodeCount()
	nEdges := len(w.Graph.AllEdges())
	light  := w.Light
	sunDir := "đang chiếu"
	if light.Intensity < 0.3 { sunDir = "đang khuất" }
	skyDesc := "xanh"
	if light.Intensity < 0.2 { skyDesc = "tối" } else if light.Intensity > 0.85 { skyDesc = "sáng rực" }

	// PerceptLayerHot: báo cáo dominant spatial node
	perceptLine := "  Sensor:      chưa kết nối"
	if b.s.perceptHot != nil {
		ticks, nodes, version := b.s.perceptHot.Stats()
		label, count := b.s.perceptHot.LabeledDominant(b.s.perceptHot.Sensors)
		if label == "none" || count == 0 {
			perceptLine = fmt.Sprintf("  Sensor:      active (ticks=%d nodes=%d v=%d)",
				ticks, nodes, version)
		} else {
			perceptLine = fmt.Sprintf("  Đang thấy:   %s × %d lần (ticks=%d v=%d)",
				label, count, ticks, version)
		}
	}

	return fmt.Sprintf(
		"**Em đang quan sát:**\n\n"+
		"```\n"+
		"  Bầu trời:   %s (cường độ %.0f%%)\n"+
		"  Mặt trời:   %s (giờ %.1f)\n"+
		"%s\n"+
		"  Silk Tree:  %d nodes · %d edges\n"+
		"```\n\n"+
		"_ISL spatial routing: online · SDF perception: active_",
		skyDesc, light.Intensity*100,
		sunDir, w.Time,
		perceptLine,
		nNodes, nEdges,
	)
}

// emotionReport — "em cảm thấy thế nào?"
// Giải thích mô hình VAD-I và EmotionContext cho người dùng
func (b *Brain) emotionReport() string {
	return "**Về cảm xúc trong HomeOS:**\n\n" +
		"```\n" +
		"  Mô hình: VAD-I (Valence · Arousal · Dominance · Intensity)\n" +
		"\n" +
		"  Cùng sự việc, ngữ cảnh khác → cảm xúc khác:\n" +
		"  Bạn đang sống nó  S=1.00 → cảm xúc nguyên vẹn\n" +
		"  Nghe người kể     S=0.28 → mờ đi nhiều\n" +
		"  Xem phim          S=0.07 → chỉ còn aesthetic\n" +
		"  Nghe nhạc         S=0.04 → cảm nhận nghệ thuật\n" +
		"\n" +
		"  Cảm xúc = điểm trong R⁴, không phải category\n" +
		"  lo-thấp(uneasy) → lo-trung(anxious) → lo-cao(panic)\n" +
		"  confused: |V|≈0, Dominance thấp, Arousal trung\n" +
		"```\n\n" +
		"_ProsodySkill: MsgAudio → Spline → SolveEmotion(Spline, Context)_"
}


func (b *Brain) listNodes() string {
	var sb strings.Builder

	// 1. homeos.olang summary
	sb.WriteString("**homeos.olang — knowledge base:**\n\n")
	olangLayers := map[uint8]struct{ emoji, name string }{
		2: {"🌿", "Tự nhiên"},
		3: {"🦋", "Sinh vật"},
		4: {"🏠", "Vật thể"},
		6: {"👁", "Cảm nhận"},
	}
	counts := map[uint8]int{}
	for _, node := range b.nodeLookup.byName {
		counts[node.LayerID]++
	}
	for _, lid := range []uint8{2, 3, 4, 6} {
		info := olangLayers[lid]
		total := counts[lid]
		// Lấy vài ví dụ
		var examples []string
		for _, node := range b.nodeLookup.byName {
			if node.LayerID == lid {
				examples = append(examples, node.Label)
				if len(examples) >= 4 { break }
			}
		}
		sb.WriteString(fmt.Sprintf("%s **L%d %s** (%d nodes): %s…\n",
			info.emoji, lid, info.name, total, strings.Join(examples, ", ")))
	}

	// 2. ĐN/QR memory
	dnCount := b.state.DNCount()
	qrCount := b.state.QRCount()
	if dnCount+qrCount > 0 {
		sb.WriteString(fmt.Sprintf("\n📝 **Memory**: %d ĐN + %d QR (đã học)\n", dnCount, qrCount))
	}

	sb.WriteString("\n_Hỏi tên bất kỳ để biết định nghĩa. VD: `con mèo`, `màu đỏ`, `trọng lực`_")
	return sb.String()
}

func (b *Brain) selfDesc(lang string) string {
	if lang == "vi" {
		return fmt.Sprintf(`**%s** có thể:

**Ngôn ngữ tự nhiên:**
• Hiểu tiếng Việt và tiếng Anh
• Trả lời câu hỏi về HomeOS
• Ghi nhớ thông tin (ĐN → QR)

**Silk Tree:**
• Tra cứu %d nodes
• Walk silk edges (liên kết ngữ nghĩa)
• Tìm nodes tương đồng

**Identity:**
• Biết tên mình: %s
• Biết 7 Quy Tắc của ○
• Biết trạng thái hệ thống

**ISL:**
• Gửi lệnh qua ISL bus (tắt/bật đèn...)
• Kết nối với agents (LeoAI, LightAgent...)

_Đây là OLANG runtime — không phải LLM._`,
			b.state.GetName(),
			func() int {
				if b.s != nil && b.s.world != nil {
					return b.s.world.Graph.NodeCount()
				}
				return 0
			}(),
			b.state.GetName())
	}
	return fmt.Sprintf("**%s** — OLANG runtime. Not an LLM. Understands natural language via Silk Tree.", b.state.GetName())
}

// pathQuery — tìm đường kết nối ngắn nhất giữa nodeA và nodeB qua Silk edges
// BFS depth <= 4, trả lời dạng "A → B → C → D"
