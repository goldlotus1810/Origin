package ws

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// TestPerceptEncodeText — text → ISLMessage, không có string bên trong
func TestPerceptEncodeText(t *testing.T) {
	p := NewPerceptLayer("../../homeos.olang")

	tests := []struct {
		input      string
		wantFrames int  // ít nhất N frames có addr
		wantPrimary bool
	}{
		{"sợ hãi",           1, true},
		{"lửa",              1, true},
		{"đèn bật",          1, true},
		{"HomeOS",           1, true},
		{"nóng bức lạnh buốt", 2, true},
	}

	for _, tc := range tests {
		pm := p.EncodeText(tc.input)

		knownFrames := 0
		for _, f := range pm.Frames {
			if f.Addr.Uint64() != 0 {
				knownFrames++
			}
		}

		hasPrimary := pm.Primary.Uint64() != 0

		if knownFrames >= tc.wantFrames && hasPrimary == tc.wantPrimary {
			t.Logf("✅ %q → primary=%s frames=%d/%d",
				tc.input, pm.Primary.String(), knownFrames, len(pm.Frames))
			// In chi tiết các frames
			for _, f := range pm.Frames {
				if f.Addr.Uint64() != 0 {
					pos := posSymbol(f.Node.POS)
					t.Logf("     %s %s → %s (%.0f%%)",
						pos, f.Token, f.Addr.String(), f.Confidence*100)
				}
			}
		} else {
			t.Logf("⚠️  %q → primary=%v knownFrames=%d (want %d)",
				tc.input, hasPrimary, knownFrames, tc.wantFrames)
		}
	}
}

// TestPerceptWalk — ISL address → walk silk edges → địa chỉ liên quan
func TestPerceptWalk(t *testing.T) {
	p := NewPerceptLayer("../../homeos.olang")

	tests := []string{"sợ hãi", "lửa", "ánh sáng", "HomeOS"}

	for _, q := range tests {
		pm := p.EncodeText(q)
		if pm.Primary.Uint64() == 0 {
			t.Logf("⚠️  %q → không tìm được ISL address", q)
			continue
		}

		walks := p.Walk(pm.Primary, 1)
		reached := []string{}
		for _, w := range walks {
			for _, addr := range w.Reached {
				label := p.DecodeToText(addr)
				reached = append(reached, label)
			}
		}

		t.Logf("✅ %q [%s] →silk→ %v", q, pm.Primary.String(), reached)
	}
}

// TestPerceptIntersect — ví dụ từ spec: FAa8 + GCa4 + DCb4 → ABa1.003
// Dùng nodes hiện có thay thế:
//   LIFE_FEAR + PERCEPT_COLD → tìm điểm giao trong silk tree
func TestPerceptIntersect(t *testing.T) {
	p := NewPerceptLayer("../../homeos.olang")

	// Encode 2 concepts
	pm1 := p.EncodeText("sợ hãi")
	pm2 := p.EncodeText("lạnh buốt")

	if pm1.Primary.Uint64() == 0 || pm2.Primary.Uint64() == 0 {
		t.Skip("nodes not found")
	}

	addrs := []isl.Address{pm1.Primary, pm2.Primary}
	t.Logf("Intersecting: %s (%s) ∩ %s (%s)",
		p.DecodeToText(pm1.Primary), pm1.Primary.String(),
		p.DecodeToText(pm2.Primary), pm2.Primary.String())

	result := p.Intersect(addrs, 1)

	if len(result) > 0 {
		labels := []string{}
		for _, a := range result {
			labels = append(labels, p.DecodeToText(a))
		}
		t.Logf("✅ Intersection → %v", labels)
	} else {
		t.Logf("○ Không có điểm giao trực tiếp (cần thêm silk edges)")
	}
}

// TestProcessISL — end-to-end: text → ISL → ProcessISL → ISL → text
// Đây là pipeline "não thuần ISL" đầu tiên
func TestProcessISL(t *testing.T) {
	p := NewPerceptLayer("../../homeos.olang")

	// Tạo brain nhẹ — chỉ cần percept + nodeLookup, không cần State
	b := &Brain{
		percept:    p,
		nodeLookup: NewNodeLookup("../../homeos.olang"),
	}

	tests := []struct {
		input string
		desc  string
	}{
		{"sợ hãi",   "query concept"},
		{"lửa nóng", "concept + modifier"},
		{"ánh sáng", "nature concept"},
		{"HomeOS",   "L5 concept query"},
	}

	for _, tc := range tests {
		// Bước 1: text → ISL (Perception Layer)
		pm := p.EncodeText(tc.input)

		// Bước 2: ISL → ProcessISL (brain xử lý thuần ISL, không có string)
		response := b.ProcessISL(pm)

		// Bước 3: ISL → text (Decode — chỉ ở biên giao tiếp)
		inputLabel    := p.DecodeToText(pm.Primary)
		responseLabel := p.DecodeToText(response.Primary)

		if pm.Primary.Uint64() != 0 {
			t.Logf("✅ [%s]", tc.desc)
			t.Logf("   INPUT:    %q", tc.input)
			t.Logf("   Percept:  ISL[%s] = %q", pm.Primary.String(), inputLabel)
			if response.Primary.Uint64() != 0 {
				t.Logf("   Response: ISL[%s] = %q", response.Primary.String(), responseLabel)
			}
			for i, ctx := range response.Context {
				if ctx.Uint64() != 0 && i < 2 {
					t.Logf("   Context[%d]: ISL[%s] = %q", i, ctx.String(), p.DecodeToText(ctx))
				}
			}
		} else {
			t.Logf("⚠️  %q → ISL addr = 0 (chưa có trong silk tree)", tc.input)
		}
		t.Log()
	}
}

// TestISLMessageFormat — ISL message là binary, không phải string
func TestISLMessageFormat(t *testing.T) {
	p := NewPerceptLayer("../../homeos.olang")
	pm := p.EncodeText("sợ hãi")

	// Serialize ISL message
	msgBytes := serializeISLMsg(pm.Msg)

	t.Logf("ISL message size: %d bytes (vs ~200 bytes text)", len(msgBytes))
	t.Logf("Primary addr: [%02x %02x %02x %02x] = %s",
		pm.Msg.PrimaryAddr.Layer,
		pm.Msg.PrimaryAddr.Group,
		pm.Msg.PrimaryAddr.Type,
		pm.Msg.PrimaryAddr.ID,
		pm.Primary.String())
	t.Logf("Confidence: %d%%", pm.Msg.Confidence)
	t.Logf("No strings inside ISL message ✅")

	if len(msgBytes) < 50 {
		t.Logf("✅ Compact: %d bytes << 200 bytes text", len(msgBytes))
	}
}

// serializeISLMsg — ISL message → bytes (để đo kích thước)
func serializeISLMsg(msg isl.ISLMessage) []byte {
	buf := make([]byte, 0, 48)
	buf = append(buf, msg.Version, byte(msg.MsgType))
	buf = append(buf, byte(msg.SenderID>>8), byte(msg.SenderID))
	buf = append(buf, byte(msg.TargetID>>8), byte(msg.TargetID))
	buf = append(buf, msg.Priority, msg.Flags)
	buf = append(buf, msg.PrimaryAddr.Bytes()...)
	buf = append(buf, msg.SecondaryAddr.Bytes()...)
	buf = append(buf, msg.ContextAddr.Bytes()...)
	buf = append(buf, byte(msg.Confidence>>24), byte(msg.Confidence>>16), byte(msg.Confidence>>8), byte(msg.Confidence))
	return buf
}
