// internal/ws/brain_actuator.go
// Tách từ brain.go — actuator + char lookup + reasoner
// package ws — cùng package, truy cập Brain methods trực tiếp

package ws

import (
	"fmt"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func (b *Brain) lastISL(key, value string) [8]byte {
	return nameToISL(key)
}

// ─── Actuator Intent ───────────────────────────────────────────
type ActuatorCmd struct {
	Action   string // "on" | "off" | "toggle"
	Device   string // "light" | "hvac" | "lock"
	Location string // "living_room" | "bedroom" | "all" | ...
	Raw      string
}

// parseActuator — dùng vocab nodes (INTENT_ACTUATOR, DEVICE_*, LOCATION_*)
// không còn hardcode keyword nào trong Go
func (b *Brain) parseActuator(lo string) *ActuatorCmd {
	isOff    := b.vocab.HasIntent(lo, "off")
	isOn     := b.vocab.HasIntent(lo, "on")
	isToggle := b.vocab.HasIntent(lo, "toggle")
	if !isOff && !isOn && !isToggle { return nil }

	device   := b.vocab.ParseDevice(lo)
	location := b.vocab.ParseLocation(lo)

	if device == "" {
		if location != "" { device = b.vocab.ActuatorDef["device"] } else { return nil }
	}
	if location == "" { location = b.vocab.ActuatorDef["location"] }

	action := "on"
	if isOff    { action = "off" }
	if isToggle { action = "toggle" }
	return &ActuatorCmd{Action: action, Device: device, Location: location, Raw: lo}
}

// actuatorResponse tạo response text cho lệnh actuator
func (b *Brain) actuatorResponse(cmd *ActuatorCmd, success bool) string {
	devDisplay := b.vocab.DisplayDevice(cmd.Device)
	locDisplay := b.vocab.DisplayLocation(cmd.Location)
	if devDisplay == "" { devDisplay = cmd.Device }
	if locDisplay == "" { locDisplay = cmd.Location }

	if !success {
		return fmt.Sprintf("⚠ Không thể %s %s %s — thiết bị không phản hồi.",
			actionVI(cmd.Action), devDisplay, locDisplay)
	}
	icon := b.vocab.DeviceIconFor(cmd.Device)

	stateVI := "BẬT"
	if cmd.Action == "off"    { stateVI = "TẮT" }
	if cmd.Action == "toggle" { stateVI = "CHUYỂN" }

	if cmd.Location == "all" {
		return fmt.Sprintf("%s %s tất cả %s → **%s** ✓", icon, stateVI, devDisplay, stateVI)
	}
	return fmt.Sprintf("%s %s %s %s → **%s** ✓", icon, stateVI, devDisplay, locDisplay, stateVI)
}


// ─── SilkReasoner: Suy luận qua graph ────────────────────────
// MASTER.md §1.5 + §4.1: confidence*0.85/hop, không text matching

// lookupChar — tra ký tự: GlyphSDF + ConceptSDF + silk walk
func (b *Brain) lookupChar(query, lang string) ChatResponse {
	b.initReasoner()
	query = strings.TrimSpace(query)
	if query == "" {
		return b.resp("unknown", "Bạn muốn tra ký tự nào?")
	}
	if b.reasoner == nil {
		if node := b.nodeLookup.Search(query); node != nil {
			_, hops := b.nodeLookup.SearchAndWalk(query, 2)
			return b.resp("know", b.nodeLookup.NaturalSentence(node, hops))
		}
		return b.resp("unknown", fmt.Sprintf("UTF32 bridge chưa sẵn sàng cho \"%s\".", query))
	}
	rr := b.reasoner.Reason(query)
	if rr.HasResult() {
		if len(rr.DirectMatches) == 1 && len([]rune(query)) == 1 {
			detail := silk.FormatCharDetail(rr.DirectMatches[0].Node)
			if extra := rr.FormatVI(); extra != "" {
				detail += "\n" + extra
			}
			return b.resp("know", detail)
		}
		return b.resp("know", rr.FormatVI())
	}
	return b.resp("unknown", fmt.Sprintf(
		"**\"%s\"** chưa có trong UTF32 bridge (M1 đang build L1 UTF32).\n\n"+
			"Hiện có: L0 primitives + ký tự mẫu trong `utf32_bridge.go`.", query))
}

// reasonSilk — suy luận từ chuỗi lạ qua silk graph
// MASTER.md §1.5: "L-i-e-b-e → nodes lá → silk edges → ISL[Concept][Love]"
func (b *Brain) reasonSilk(query, lang string) ChatResponse {
	b.initReasoner()
	if b.reasoner != nil {
		rr := b.reasoner.Reason(query)
		if rr.HasResult() {
			return b.resp("know", rr.FormatVI())
		}
	}
	return b.queryNode(ParsedInput{Raw: query, Lower: strings.ToLower(query),
		Lang: lang, Slots: map[string]string{}})
}

// initReasoner — lazy init SilkReasoner từ world graph
func (b *Brain) initReasoner() {
	if b.reasoner == nil && b.s != nil && b.s.world != nil {
		b.reasoner = silk.NewSilkReasoner(b.s.world.Graph)
	}
}

// ─── MsgLearn bus helpers ──────────────────────────────────────
// Gửi ISL messages qua bus → LeoAI agent skills xử lý
// MASTER.md §6: "Agent im lặng mặc định — chỉ phát tín hiệu khi có ∆"

// sendLearn gửi MsgLearn khi user dạy hệ thống điều mới
