// internal/ws/ws.go
package ws

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net/http"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/agents"
	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

type WorldSnapshot struct {
	Time    float64     `json:"time"`
	Nodes   []NodeState `json:"nodes"`
	Signals []SigState  `json:"signals"`
	Stats   StatsState  `json:"stats"`
}
type NodeState struct {
	ID   string   `json:"id"`
	Glow float64  `json:"glow,omitempty"`
	Sig  float64  `json:"sig,omitempty"`
	X    *float64 `json:"x,omitempty"`
	Y    *float64 `json:"y,omitempty"`
	Z    *float64 `json:"z,omitempty"`
}
type SigState struct {
	From string  `json:"from"`
	To   string  `json:"to"`
	P    float64 `json:"p"`
}
type StatsState struct {
	QR int `json:"qr"`
	DN int `json:"dn"`
	NT int `json:"nt"`
}

type World struct {
	mu      sync.RWMutex
	Seed    int64
	Time    float64
	Genes   []gene.Gene
	Light   gene.LightInfo
	Graph   *silk.SilkGraph
	glowing map[string]float64
	signals []SigState
	nt      int
}

func NewWorld(seed int64, graph *silk.SilkGraph) *World {
	w := &World{Seed: seed, Time: 10.0, Graph: graph, glowing: make(map[string]float64)}
	w.Light = gene.SunLight(w.Time)
	return w
}

func (w *World) Tick(dt float64) {
	w.mu.Lock(); defer w.mu.Unlock()
	w.Time = modF(w.Time+dt, 24.0)
	w.Light = gene.SunLight(w.Time)
	w.nt++
	for _, g := range w.Genes { g.Animate(w.Time) }
	for k, v := range w.glowing {
		v -= 0.015
		if v <= 0 { delete(w.glowing, k) } else { w.glowing[k] = v }
	}
	active := w.signals[:0]
	for _, s := range w.signals { s.P += 0.018; if s.P < 1.0 { active = append(active, s) } }
	w.signals = active
}

func (w *World) Glow(id string) { w.mu.Lock(); w.glowing[id] = 1.0; w.mu.Unlock() }

func (w *World) FireSignal(from, to string) {
	w.mu.Lock(); w.signals = append(w.signals, SigState{From: from, To: to}); w.mu.Unlock()
}

func (w *World) Snapshot(qr, dn int) WorldSnapshot {
	w.mu.RLock(); defer w.mu.RUnlock()
	var nodes []NodeState
	for id, glow := range w.glowing { nodes = append(nodes, NodeState{ID: id, Glow: glow}) }
	sigs := make([]SigState, len(w.signals)); copy(sigs, w.signals)
	return WorldSnapshot{Time: w.Time, Nodes: nodes, Signals: sigs, Stats: StatsState{QR: qr, DN: dn, NT: w.nt}}
}

func (w *World) SDF(p gene.Vec3) float64 {
	w.mu.RLock(); defer w.mu.RUnlock()
	d := math.Inf(1)
	for _, g := range w.Genes { d = gene.SmoothUnion(d, g.SDF(p), 0.1) }
	return d
}

func modF(x, m float64) float64 { r := math.Mod(x, m); if r < 0 { r += m }; return r }

type Server struct {
	uiLoader   *UILoader
	world      *World
	owner      *OwnershipManager
	mu         sync.RWMutex
	clients    map[string]chan []byte
	qr, dn     *int
	staticPath string
	bus        chan<- *isl.ISLMessage
	msgBus     *agents.MessageBus   // agents MessageBus — LeoAI học từ user input
	registry   *agents.AgentRegistry
	aamInbox   chan<- *isl.ISLMessage // AAM inbox — actuator commands qua AAM (QT5)
	brain      *Brain
	perceptHot *agents.PerceptLayerHot  // spatial perception (optional)
}

func NewServer(world *World, qr, dn *int, staticPath string) *Server {
	s := &Server{world: world, clients: make(map[string]chan []byte), qr: qr, dn: dn, staticPath: staticPath}
	s.uiLoader = NewUILoader("homeos.olang")
	s.owner    = NewOwnershipManager("homeos.olang")
	s.brain = NewBrain(s)
	return s
}

func (s *Server) SetBus(bus chan<- *isl.ISLMessage)           { s.bus = bus }
func (s *Server) SetMessageBus(mb *agents.MessageBus)        { s.msgBus = mb }
func (s *Server) SetRegistry(r *agents.AgentRegistry)        { s.registry = r }
func (s *Server) SetAAMInbox(ch chan<- *isl.ISLMessage)       { s.aamInbox = ch }
func (s *Server) SetPerceptHot(pl *agents.PerceptLayerHot)   { s.perceptHot = pl }
func (s *Server) SetShortTerm(st *memory.ShortTerm)          {
	if s.brain != nil && s.brain.state != nil {
		s.brain.state.WithShortTerm(st)
	}
}

// dispatchActuator — AAM gửi MsgActuatorCmd đến home_chief
// Chief sẽ route đến worker đúng (QT: AAM ↔ Chief ↔ Worker)
func (s *Server) dispatchActuator(cmd *ActuatorCmd) bool {
	// Payload: "action:device:location"
	payload := cmd.Action + ":" + cmd.Device + ":" + cmd.Location

	msg := &isl.ISLMessage{
		Version:     1,
		MsgType:     isl.MsgActuatorCmd,
		PrimaryAddr: isl.AddrHomeChief,
		Payload:     []byte(payload),
	}

	// QT5: lệnh qua AAM → home_chief → worker (không bypass tầng)
	if s.aamInbox != nil {
		select {
		case s.aamInbox <- msg:
			return true
		default:
			log.Printf("⚠️  dispatch: aamInbox full, fallback direct")
		}
	}

	// Fallback: gửi thẳng home_chief nếu aamInbox chưa wire
	if s.registry != nil {
		if s.registry.Send("home_chief", msg) {
			return true
		}
		log.Printf("⚠️  dispatch: home_chief not found (ids=%v)", s.registry.IDs())
	}
	return false
}
func (s *Server) Serve(addr string) error {
	mux := http.NewServeMux()
	cors := func(h http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Access-Control-Allow-Origin", "*")
			if r.Method == "OPTIONS" { return }
			h(w, r)
		}
	}
	mux.HandleFunc("/health", cors(s.handleHealth))
	mux.HandleFunc("/api/tree", cors(s.handleTree))
	mux.HandleFunc("/api/edges", cors(s.handleEdges))
	mux.HandleFunc("/ws/sse", cors(s.handleSSE))
	s.RegisterAPI(mux)
	s.RegisterOwnershipAPI(mux)
	if s.uiLoader != nil && s.uiLoader.HasUI() {
		mux.HandleFunc("/", s.serveFromOlang)
		log.Println("○ UI: serving from homeos.olang (L5 UI_INDEX)")
	} else if s.staticPath != "" {
		mux.Handle("/", http.FileServer(http.Dir(s.staticPath)))
		log.Println("○ UI: serving from web/static/ (fallback)")
	}
	go s.broadcastLoop()
	log.Printf("HomeOS: %s", addr)
	return http.ListenAndServe(addr, mux)
}

func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"status":"ok","time":%.2f}`, s.world.Time)
}

func (s *Server) handleTree(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	nodes, _ := OlangGraph("homeos.olang", s.brain.nodeLookup)
	json.NewEncoder(w).Encode(nodes)
}

func (s *Server) handleEdges(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_, edges := OlangGraph("homeos.olang", s.brain.nodeLookup)
	json.NewEncoder(w).Encode(edges)
}

func (s *Server) handleSSE(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	flusher, ok := w.(http.Flusher)
	if !ok { http.Error(w, "streaming unsupported", 500); return }
	id := fmt.Sprintf("%d", time.Now().UnixNano())
	ch := make(chan []byte, 32)
	s.mu.Lock(); s.clients[id] = ch; s.mu.Unlock()
	defer func() { s.mu.Lock(); delete(s.clients, id); s.mu.Unlock() }()
	for {
		select {
		case <-r.Context().Done(): return
		case data := <-ch:
			fmt.Fprintf(w, "data: %s\n\n", data)
			flusher.Flush()
		}
	}
}

func (s *Server) broadcastLoop() {
	t := time.NewTicker(50 * time.Millisecond)
	defer t.Stop()
	for range t.C {
		s.world.Tick(0.004)
		snap := s.world.Snapshot(*s.qr, *s.dn)
		data, err := json.Marshal(snap)
		if err != nil { continue }
		s.mu.RLock()
		for _, ch := range s.clients { select { case ch <- data: default: } }
		s.mu.RUnlock()
	}
}

// serveFromOlang — serve UI từ homeos.olang L5 nodes
func (s *Server) serveFromOlang(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path

	// / → UI_INDEX
	if path == "/" || path == "/index.html" {
		if asset, ok := s.uiLoader.Get("UI_INDEX"); ok {
			w.Header().Set("Content-Type", asset.ContentType)
			w.Header().Set("X-Source", "homeos.olang:L5:UI_INDEX")
			w.Header().Set("Cache-Control", "no-cache")
			w.Write(asset.Data)
			return
		}
	}

	// /renderer.js → UI_RENDERER (nếu có)
	if path == "/renderer.js" {
		if asset, ok := s.uiLoader.Get("UI_RENDERER"); ok {
			w.Header().Set("Content-Type", asset.ContentType)
			w.Write(asset.Data)
			return
		}
	}

	// Fallback: 404
	http.NotFound(w, r)
}

// ── Test helpers (export cho package main test) ────────────────

// GetBrain trả về Brain instance — dùng cho test
func (s *Server) GetBrain() *Brain { return s.brain }

// LoadWorldFromOlang tạo World từ file .olang — shortcut cho test
func LoadWorldFromOlang(path string) *World {
	g := silk.NewSilkGraph()
	silk.LoadFromOlang(g, path)
	return NewWorld(42, g)
}

// TestInferLayer export logic inferLayerID để test — trả về string "2","3"...
// Tự khởi tạo VocabLoader nếu globalVocab chưa có
func TestInferLayer(key, value string) string {
	if globalVocab == nil {
		v := NewVocabLoader("homeos.olang")
		globalVocab = v
	}
	l := globalVocab.InferLayerID(key, value)
	if l == 0 { l = inferLayerID(key, value) }
	if l > 9 { return string(rune('0'+9)) }
	return string(rune('0' + l))
}
