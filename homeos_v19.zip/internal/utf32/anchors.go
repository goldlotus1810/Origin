// internal/utf32/anchors.go
//
// UTF-32 ANCHOR STRUCTURE — điểm neo bất biến
//
// MỤC ĐÍCH:
//   Khi chương trình đọc sách/code và phát hiện symbol mới,
//   nó PHẢI add vào đúng anchor. Không add lung tung.
//
// THIẾT KẾ:
//   Unicode 18.0 có 154,998 characters, chia 330 blocks.
//   Chúng ta KHÔNG lưu hết — chỉ lưu những gì có ý nghĩa với HomeOS.
//
//   3 tầng anchor:
//     PLANE   — không gian lớn (0=BMP, 1=SMP, 2=SIP...)
//     BLOCK   — nhóm Unicode chính thức
//     CLUSTER — nhóm chức năng của HomeOS (không theo Unicode)
//
// QUY TẮC ADD SYMBOL MỚI:
//   1. Tìm CLUSTER phù hợp theo chức năng
//   2. Nếu không có cluster → tạo cluster mới trong đúng block
//   3. Không bao giờ skip cluster để add thẳng vào block/plane
//
// Unicode ver 18.0: https://unicode.org/charts/

package utf32

// BlockAnchor — Unicode block chính thức
type BlockAnchor struct {
	ID    string
	Start uint32
	End   uint32
	Name  string // tên Unicode chính thức
	Plane int    // 0=BMP, 1=SMP, 2=SIP
	Note  string // tại sao relevant với HomeOS
}

// ClusterAnchor — nhóm theo chức năng HomeOS
type ClusterAnchor struct {
	ID      string
	Name    string
	Block   string   // BlockAnchor.ID
	Members []uint32 // codepoints — append-only
	Desc    string
	Tags    []string
}

// ─────────────────────────────────────────────────────────────
// BLOCKS — Unicode blocks được dùng
// ─────────────────────────────────────────────────────────────

var Blocks = []BlockAnchor{
	// Plane 0 — BMP
	{"LATIN_BASIC",     0x0000, 0x007F, "Basic Latin",                          0, "ASCII, code symbols"},
	{"LATIN_SUPP",      0x0080, 0x00FF, "Latin-1 Supplement",                  0, "·×÷±° phổ biến"},
	{"LATIN_EXT_A",     0x0100, 0x024F, "Latin Extended-A/B",                  0, "tiếng Việt, châu Âu"},
	{"GREEK",           0x0370, 0x03FF, "Greek and Coptic",                     0, "π φ λ α β γ δ θ"},
	{"MATH_ALPHA_SYM",  0x2100, 0x214F, "Letterlike Symbols",                  0, "ℝ ℤ ℕ ℂ ℯ ℏ"},
	{"NUMBER_FORMS",    0x2150, 0x218F, "Number Forms",                         0, "⅓ Ⅰ Ⅱ Roman numerals"},
	{"ARROWS",          0x2190, 0x21FF, "Arrows",                               0, "← → ↑ ↓ ↔ ↻ ↺"},
	{"MATH_OPS",        0x2200, 0x22FF, "Mathematical Operators",               0, "∀∃∈∩∪∑∂∇∞≈≡⊂⊕⊖"},
	{"MISC_TECH",       0x2300, 0x23FF, "Miscellaneous Technical",              0, "⌀⌇⌘⌛ hardware"},
	{"ENCLOSED_ALPHA",  0x2460, 0x24FF, "Enclosed Alphanumerics",               0, "①②③ đánh số"},
	{"BOX_DRAWING",     0x2500, 0x257F, "Box Drawing",                          0, "─│┌┐└┘ UI"},
	{"BLOCK_ELEM",      0x2580, 0x259F, "Block Elements",                       0, "▀▄█▌ density/fill"},
	{"GEO_SHAPES",      0x25A0, 0x25FF, "Geometric Shapes",                     0, "●○□△▽◎◌⬭ SDF"},
	{"MISC_SYMS",       0x2600, 0x26FF, "Miscellaneous Symbols",                0, "☀☁★♻⚡⚖⚙"},
	{"DINGBATS",        0x2700, 0x27BF, "Dingbats",                             0, "✓✗✦✧❖"},
	{"MATH_MISC_A",     0x27C0, 0x27EF, "Misc Mathematical Symbols-A",         0, "⟋⟌⟍⟳"},
	{"ARROWS_SUPP_A",   0x27F0, 0x27FF, "Supplemental Arrows-A",               0, "⟵⟶⟷⟼"},
	{"ARROWS_SUPP_B",   0x2900, 0x297F, "Supplemental Arrows-B",               0, "⤴⤵⇒⇐"},
	{"MATH_MISC_B",     0x2980, 0x29FF, "Misc Mathematical Symbols-B",         0, "⦿⦾⧜⧝"},
	{"MATH_OPS_SUPP",   0x2A00, 0x2AFF, "Supplemental Mathematical Operators", 0, "⨁⨂⨃⨄"},
	{"MISC_SYMS_ARR",   0x2B00, 0x2BFF, "Miscellaneous Symbols and Arrows",    0, "⬭⟳⭮"},
	// Plane 1 — SMP
	{"MUSIC_FULL",      0x1D100, 0x1D1FF, "Musical Symbols",                   1, "𝄞𝄢 notation"},
	{"MATH_ALPHA",      0x1D400, 0x1D7FF, "Mathematical Alphanumeric Symbols", 1, "𝑡𝑥𝑦 italic"},
	{"ALCHEMICAL",      0x1F700, 0x1F77F, "Alchemical Symbols",                1, "🜁🜂🜃🜄 elements"},
	{"GEO_EXT",         0x1F780, 0x1F7FF, "Geometric Shapes Extended",         1, "🞀🞁🞂 extra shapes"},
	{"EMOJI_NATURE",    0x1F300, 0x1F5FF, "Misc Symbols and Pictographs",      1, "🌍🌱🔒📜📡"},
	{"EMOJI_PERSON",    0x1F600, 0x1F64F, "Emoticons",                         1, "👁🧠 face/person"},
	{"EMOJI_TRANSPORT", 0x1F680, 0x1F6FF, "Transport and Map Symbols",         1, "🛡🚀📡"},
	{"EMOJI_SCIENCE",   0x1F9A0, 0x1F9FF, "Supplemental Symbols and Pictographs", 1, "🧬🧪🧵🧱"},
}

// ─────────────────────────────────────────────────────────────
// CLUSTERS — nhóm chức năng HomeOS (điểm neo thực sự)
// ─────────────────────────────────────────────────────────────

var Clusters = []ClusterAnchor{

	// ════════════════════════════════════════
	// SDF — Signed Distance Field
	// ════════════════════════════════════════
	{
		ID: "SDF_PRIMITIVES", Name: "SDF Primitives — Hình thể", Block: "GEO_SHAPES",
		Members: []uint32{
			0x25CF, // ● BLACK CIRCLE            → SDFSphere
			0x1F48A,// 💊 PILL                    → SDFCapsule
			0x25A1, // □ WHITE SQUARE             → SDFBox
			0x25CB, // ○ WHITE CIRCLE             → SDFCylinder
			0x25B3, // △ WHITE UP-POINTING TRIANGLE → SDFCone
			0x25CE, // ◎ BULLSEYE                 → SDFTorus
			0x25CC, // ◌ DOTTED CIRCLE            → SDFVoid
			0x2B2D, // ⬭ WHITE HORIZONTAL ELLIPSE → SDFEllipsoid
		},
		Desc: "SDF geometric primitives — 8 basic shapes",
		Tags: []string{"sdf", "geometry"},
	},
	{
		ID: "SDF_BOOLEAN", Name: "SDF Boolean Ops", Block: "MATH_OPS",
		Members: []uint32{
			0x222A, // ∪ UNION                → SmoothUnion
			0x2216, // ∖ SET MINUS            → SmoothSubtract
			0x2229, // ∩ INTERSECTION         → SmoothIntersect
			0x2295, // ⊕ CIRCLED PLUS         → HardUnion
			0x2296, // ⊖ CIRCLED MINUS        → HardSubtract
		},
		Desc: "Boolean SDF operations — smooth and hard",
		Tags: []string{"sdf", "math"},
	},
	{
		ID: "SDF_TRANSFORM", Name: "SDF Spatial Transforms", Block: "ARROWS",
		Members: []uint32{
			0x21BB, // ↻ CLOCKWISE OPEN CIRCLE ARROW  → Rotate
			0x2194, // ↔ LEFT RIGHT ARROW             → Mirror
			0x27F3, // ⟳ CLOCKWISE GAPPED CIRCLE ARROW → Repeat
		},
		Desc: "Spatial transforms — rotate, mirror, tile repeat",
		Tags: []string{"sdf", "geometry"},
	},

	// ════════════════════════════════════════
	// MATHEMATICS
	// ════════════════════════════════════════
	{
		ID: "MATH_QUANTIFIERS", Name: "Quantifiers — Logic", Block: "MATH_OPS",
		Members: []uint32{
			0x2200, // ∀ FOR ALL              → broadcast/map/forEach
			0x2203, // ∃ THERE EXISTS         → find/any/some
			0x2208, // ∈ ELEMENT OF           → contains/member
			0x2209, // ∉ NOT AN ELEMENT OF    → not-member
			0x2282, // ⊂ SUBSET OF            → subset
			0x2283, // ⊃ SUPERSET OF          → superset
		},
		Desc: "Logical quantifiers — for-all, exists, membership",
		Tags: []string{"math", "lang"},
	},
	{
		ID: "MATH_CALCULUS", Name: "Calculus & Analysis", Block: "MATH_OPS",
		Members: []uint32{
			0x2207, // ∇ NABLA                → Gradient (surface normal)
			0x2202, // ∂ PARTIAL DIFFERENTIAL → partial derivative
			0x2218, // ∘ RING OPERATOR        → function composition
			0x223F, // ∿ SINE WAVE            → FBM terrain noise
			0x221E, // ∞ INFINITY             → infinite/unbounded
			0x2206, // ∆ INCREMENT            → delta/change
			0x222B, // ∫ INTEGRAL             → accumulate (historical)
		},
		Desc: "Calculus — gradient, FBM, derivative, infinity, delta",
		Tags: []string{"math", "physics"},
	},
	{
		ID: "MATH_ALGEBRA", Name: "Algebra & Aggregation", Block: "MATH_OPS",
		Members: []uint32{
			0x2211, // ∑ N-ARY SUMMATION      → Aggregate/sum
			0x220F, // ∏ N-ARY PRODUCT        → product/reduce
			0x221A, // √ SQUARE ROOT          → Sqrt
			0x2248, // ≈ ALMOST EQUAL TO      → Approx
			0x2261, // ≡ IDENTICAL TO         → exact equal
		},
		Desc: "Algebraic — sum, product, sqrt, equality",
		Tags: []string{"math"},
	},
	{
		ID: "MATH_VECTOR", Name: "Vector Products", Block: "LATIN_SUPP",
		Members: []uint32{
			0x00B7, // · MIDDLE DOT           → DotProduct
			0x00D7, // × MULTIPLICATION SIGN  → CrossProduct
			0x2297, // ⊗ CIRCLED TIMES        → Tensor product
		},
		Desc: "Vector algebra — dot, cross, tensor products",
		Tags: []string{"math", "physics"},
	},
	{
		ID: "MATH_CONSTANTS", Name: "Constants & Greek", Block: "GREEK",
		Members: []uint32{
			0x03C0, // π PI
			0x03C6, // φ PHI → golden ratio
			0x03BB, // λ LAMBDA → anonymous function
			0x03B1, // α ALPHA → alpha/angle
			0x03B2, // β BETA
			0x03B3, // γ GAMMA → gamma correction
			0x03B4, // δ DELTA → small change
			0x03B5, // ε EPSILON → tolerance
			0x03B8, // θ THETA → angle
			0x03C3, // σ SIGMA → standard deviation
			0x212F, // ℯ SCRIPT SMALL E → Euler's number
		},
		Desc: "Math constants — pi, phi, lambda, euler, greek letters",
		Tags: []string{"math"},
	},
	{
		ID: "MATH_SETS", Name: "Number Sets", Block: "MATH_ALPHA_SYM",
		Members: []uint32{
			0x211D, // ℝ REAL numbers
			0x2124, // ℤ INTEGER numbers
			0x2115, // ℕ NATURAL numbers
			0x2102, // ℂ COMPLEX numbers
			0x211A, // ℚ RATIONAL numbers
			0x210B, // ℋ HAMILTONIAN
			0x2112, // ℒ LAPLACIAN
		},
		Desc: "Mathematical number sets and spaces",
		Tags: []string{"math"},
	},

	// ════════════════════════════════════════
	// PHYSICS & SIGNALS
	// ════════════════════════════════════════
	{
		ID: "PHYSICS_LIGHT", Name: "Light & Energy", Block: "MISC_SYMS",
		Members: []uint32{
			0x2600,  // ☀ BLACK SUN WITH RAYS   → SunLight
			0x26A1,  // ⚡ HIGH VOLTAGE SIGN     → EnergyDecay
			0x1F321, // 🌡 THERMOMETER           → Temperature
			0x2609,  // ☉ SUN                   → orbital/sun alt
			0x263C,  // ☼ WHITE SUN WITH RAYS   → bright ambient
		},
		Desc: "Light, energy, heat physics",
		Tags: []string{"physics", "sdf"},
	},
	{
		ID: "PHYSICS_WAVE", Name: "Wave & Oscillation", Block: "MISC_TECH",
		Members: []uint32{
			0x2307, // ⌇ WAVY LINE              → Oscillate
			0x223E, // ∾ INVERTED LAZY S        → damped wave
			0x266B, // ♫ BEAMED EIGHTH NOTES    → audio/music
			0x266A, // ♪ EIGHTH NOTE            → single tone
		},
		Desc: "Waves, oscillation, audio signals",
		Tags: []string{"physics", "audio", "signal"},
	},

	// ════════════════════════════════════════
	// FLOW & DIRECTION
	// ════════════════════════════════════════
	{
		ID: "FLOW_DIRECTION", Name: "Direction — Data Flow", Block: "ARROWS",
		Members: []uint32{
			0x2192, // → RIGHTWARDS ARROW       → channel/pipe (Go chan)
			0x2190, // ← LEFTWARDS ARROW        → reverse/read
			0x21D2, // ⇒ RIGHTWARDS DOUBLE ARROW → compile/transform
			0x21A9, // ↩ LEFTWARDS ARROW WITH HOOK → callback/return
			0x21B3, // ↳ DOWNWARDS ARROW TIP RIGHT → branch/child
			0x219D, // ↝ RIGHTWARDS WAVE ARROW  → async/lazy
		},
		Desc: "Data flow direction — channels, pipes, async",
		Tags: []string{"flow", "lang"},
	},
	{
		ID: "FLOW_CYCLE", Name: "Cycle & Iteration", Block: "MISC_SYMS",
		Members: []uint32{
			0x267B, // ♻ RECYCLING SYMBOL       → Cycle/infinite loop
			0x267E, // ♾ PERMANENT PAPER SIGN   → infinite
			0x21BA, // ↺ ANTICLOCKWISE OPEN CIRCLE ARROW → loop back
		},
		Desc: "Iteration, cycle, infinite loop",
		Tags: []string{"flow", "lang"},
	},

	// ════════════════════════════════════════
	// LANGUAGE PARADIGMS
	// ════════════════════════════════════════
	{
		ID: "LANG_FUNCTION", Name: "Function & Lambda", Block: "ARROWS_SUPP_A",
		Members: []uint32{
			0x03BB, // λ LAMBDA                 → anonymous function
			0x21A6, // ↦ RIGHTWARDS ARROW FROM BAR → maps-to (f: a↦b)
			0x27FC, // ⟼ LONG RIGHTWARDS ARROW FROM BAR → maps-to long
			0x0192, // ƒ LATIN F WITH HOOK      → function symbol
		},
		Desc: "Function definition — lambda, maps-to",
		Tags: []string{"lang", "functional"},
	},
	{
		ID: "LANG_TYPE", Name: "Type System", Block: "MATH_OPS",
		Members: []uint32{
			0x22A2, // ⊢ RIGHT TACK             → type judgment (Haskell ::)
			0x22A4, // ⊤ DOWN TACK              → Top/True type
			0x22A5, // ⊥ UP TACK               → Bottom/False/undefined
			0x2293, // ⊓ SQUARE CAP             → intersection type
			0x2294, // ⊔ SQUARE CUP             → union type (Rust enum)
		},
		Desc: "Type system — judgment, top/bottom, union types",
		Tags: []string{"lang", "types"},
	},
	{
		ID: "LANG_PARALLEL", Name: "Concurrency", Block: "MISC_SYMS",
		Members: []uint32{
			0x2016, // ‖ DOUBLE VERTICAL LINE   → parallel execution
			0x2225, // ∥ PARALLEL TO            → parallel (math)
		},
		Desc: "Concurrent, parallel execution",
		Tags: []string{"lang", "concurrent"},
	},
	{
		ID: "LANG_OPTION", Name: "Option & Error", Block: "MATH_OPS",
		Members: []uint32{
			0x2205, // ∅ EMPTY SET              → null/None/Nothing
			0x22A5, // ⊥ UP TACK               → undefined/panic
			0x2757, // ❗ EXCLAMATION           → error/panic
		},
		Desc: "Null, None, error, undefined — Option/Result types",
		Tags: []string{"lang", "types"},
	},

	// ════════════════════════════════════════
	// BIOLOGY & GROWTH
	// ════════════════════════════════════════
	{
		ID: "BIO_GENE", Name: "Genetics & Biology", Block: "EMOJI_SCIENCE",
		Members: []uint32{
			0x1F9EC, // 🧬 DNA DOUBLE HELIX      → GeneRegistry
			0x1F9A0, // 🦠 MICROBE               → micro-agent
			0x1F9EA, // 🧪 TEST TUBE             → experiment
			0x1F9F1, // 🧱 BRICK                 → building block
		},
		Desc: "Genes, biology, experiment",
		Tags: []string{"bio"},
	},
	{
		ID: "BIO_LIFECYCLE", Name: "Life Cycle", Block: "EMOJI_NATURE",
		Members: []uint32{
			0x1F331, // 🌱 SEEDLING              → Grow
			0x2696,  // ⚖ SCALES                → Balance
			0x1F33F, // 🌿 HERB                  → mature/grown
		},
		Desc: "Life cycle — grow, mature, balance",
		Tags: []string{"bio", "flow"},
	},
	{
		ID: "BIO_ALCHEMICAL", Name: "Alchemical Elements", Block: "ALCHEMICAL",
		Members: []uint32{
			0x1F702, // 🜂 ALCHEMICAL FIRE        → fire element
			0x1F704, // 🜄 ALCHEMICAL WATER       → water element
			0x1F701, // 🜁 ALCHEMICAL AIR         → air/wind
			0x1F703, // 🜃 ALCHEMICAL EARTH       → earth/terrain
		},
		Desc: "Classical elements — fire, water, air, earth",
		Tags: []string{"bio", "physics"},
	},

	// ════════════════════════════════════════
	// SYSTEM & INFRASTRUCTURE
	// ════════════════════════════════════════
	{
		ID: "SYS_WORLD", Name: "World Root", Block: "EMOJI_NATURE",
		Members: []uint32{
			0x1F30D, // 🌍 EARTH GLOBE EUROPE-AFRICA → WorldRoot
			0x1F30E, // 🌎 EARTH GLOBE AMERICAS
			0x1F30F, // 🌏 EARTH GLOBE ASIA-AUSTRALIA
		},
		Desc: "World root — global scope, universe seed",
		Tags: []string{"system"},
	},
	{
		ID: "SYS_SECURITY", Name: "Security Gate", Block: "EMOJI_TRANSPORT",
		Members: []uint32{
			0x1F6E1, // 🛡 SHIELD                → SecurityGate (Rule 1 bất biến)
			0x1F512, // 🔒 LOCKED                → locked
			0x1F513, // 🔓 UNLOCKED              → open
			0x26D4,  // ⛔ NO ENTRY              → blocked/denied
		},
		Desc: "Security — shield, lock, gate",
		Tags: []string{"system", "security"},
	},
	{
		ID: "SYS_NETWORK", Name: "Network & Broadcast", Block: "EMOJI_NATURE",
		Members: []uint32{
			0x1F4E1, // 📡 SATELLITE ANTENNA     → Broadcast
			0x1F310, // 🌐 GLOBE WITH MERIDIANS  → internet/web
			0x1F517, // 🔗 LINK                  → connection
			0x1F4E5, // 📥 INBOX TRAY            → receive
			0x1F4E4, // 📤 OUTBOX TRAY           → send
		},
		Desc: "Network, broadcast, send/receive",
		Tags: []string{"system", "comm"},
	},
	{
		ID: "SYS_STORAGE", Name: "Storage & Memory Tiers", Block: "EMOJI_NATURE",
		Members: []uint32{
			0x1F4DC, // 📜 SCROLL                → Commit (append-only Ledger)
			0x1F5C3, // 🗃 CARD FILE BOX         → database/index
			0x1F4DD, // 📝 MEMO                  → short-term note
			0x1F5C4, // 🗄 FILE CABINET          → long-term archive
		},
		Desc: "Storage tiers — scroll=ledger, box=db, memo=RAM, cabinet=archive",
		Tags: []string{"system", "memory"},
	},
	{
		ID: "SYS_PROCESS", Name: "Process & Runtime", Block: "MISC_SYMS",
		Members: []uint32{
			0x1F504, // 🔄 ANTICLOCKWISE ARROWS  → Sync
			0x2699,  // ⚙ GEAR                  → worker process
			0x1F9F5, // 🧵 THREAD                → goroutine/thread
			0x23F1,  // ⏱ STOPWATCH             → tick/timer
		},
		Desc: "Process, thread, sync, tick",
		Tags: []string{"system", "process"},
	},

	// ════════════════════════════════════════
	// COGNITION & AI
	// ════════════════════════════════════════
	{
		ID: "COG_BRAIN", Name: "Brain & Intelligence", Block: "EMOJI_SCIENCE",
		Members: []uint32{
			0x1F9E0, // 🧠 BRAIN                 → LeoAI/intelligence
			0x1F4A1, // 💡 LIGHT BULB            → insight/idea
			0x1F4C8, // 📈 CHART INCREASING      → learning/improve
		},
		Desc: "Intelligence, insight, learning growth",
		Tags: []string{"cognition", "learning"},
	},
	{
		ID: "COG_VISION", Name: "Vision & Perception", Block: "EMOJI_PERSON",
		Members: []uint32{
			0x1F441, // 👁 EYE                   → RayCast/vision
			0x1F50D, // 🔍 MAGNIFYING GLASS LEFT → search/query
			0x1F4F7, // 📷 CAMERA                → capture/perception
		},
		Desc: "Vision, search, capture",
		Tags: []string{"cognition", "perception"},
	},

	// ════════════════════════════════════════
	// ORIGIN — Nền tảng triết học
	// ════════════════════════════════════════
	{
		ID: "ORIGIN_SYMBOL", Name: "The ○ Origin Symbol", Block: "GEO_SHAPES",
		Members: []uint32{
			0x25CB, // ○ WHITE CIRCLE            → ○ gốc (origin)
			0x25EF, // ◯ LARGE CIRCLE            → ○ lớn
			0x233E, // ⌾ APL CIRCLE JOT          → ○ với tâm
			0x29BE, // ⦾ CIRCLED WHITE BULLET    → ○ có điểm
		},
		Desc: "○ — the origin symbol, source of all",
		Tags: []string{"origin", "meta"},
	},
	{
		ID: "ORIGIN_LOGIC", Name: "Logical Foundations", Block: "MATH_OPS",
		Members: []uint32{
			0x2205, // ∅ EMPTY SET               → void/null (∅≠∞)
			0x2218, // ∘ RING OPERATOR           → composition (○∘○=○)
			0x29BB, // ⦻ CIRCLE WITH X           → ∞ false (QT2)
		},
		Desc: "Logical basis — void, composition, marked-infinity",
		Tags: []string{"origin", "meta"},
	},

	// ════════════════════════════════════════
	// HARDWARE / ASSEMBLY (từ .md files)
	// ════════════════════════════════════════
	{
		ID: "HW_ARCH", Name: "Hardware Architecture", Block: "MISC_SYMS",
		Members: []uint32{
			0x2699,  // ⚙ GEAR                  → CPU/processor
			0x1F527, // 🔧 WRENCH                → configure/build
			0x1F528, // 🔨 HAMMER                → compile
			0x1F4BB, // 💻 PERSONAL COMPUTER     → compute target
		},
		Desc: "Hardware — CPU, configure, compile, compute",
		Tags: []string{"hardware", "assembly"},
	},
	{
		ID: "HW_MEMORY", Name: "Memory & Stack", Block: "MISC_TECH",
		Members: []uint32{
			0x2397, // ⎗ PREVIOUS PAGE           → stack pop
			0x2398, // ⎘ NEXT PAGE               → stack push
			0x231B, // ⌛ HOURGLASS               → lifetime/scope
		},
		Desc: "Memory layout — stack, lifetime, scope",
		Tags: []string{"hardware", "memory"},
	},
}

// ─────────────────────────────────────────────────────────────
// LOOKUP
// ─────────────────────────────────────────────────────────────

func FindCluster(cp uint32) *ClusterAnchor {
	for i := range Clusters {
		for _, m := range Clusters[i].Members {
			if m == cp {
				return &Clusters[i]
			}
		}
	}
	return nil
}

func FindBlock(cp uint32) *BlockAnchor {
	for i := range Blocks {
		if cp >= Blocks[i].Start && cp <= Blocks[i].End {
			return &Blocks[i]
		}
	}
	return nil
}

// SuggestCluster — chương trình đọc sách gặp symbol mới
// → tìm cluster phù hợp để add vào
func SuggestCluster(cp uint32, tags []string) []string {
	block := FindBlock(cp)
	if block == nil {
		return nil
	}
	tagSet := make(map[string]bool)
	for _, t := range tags {
		tagSet[t] = true
	}
	var suggestions []string
	for _, cl := range Clusters {
		if cl.Block != block.ID {
			continue
		}
		for _, ct := range cl.Tags {
			if tagSet[ct] {
				suggestions = append(suggestions, cl.ID)
				break
			}
		}
	}
	return suggestions
}

// Stats — bao nhiêu symbols đã được anchor
func Stats() (blocks, clusters, members int) {
	blocks = len(Blocks)
	clusters = len(Clusters)
	for _, cl := range Clusters {
		members += len(cl.Members)
	}
	return
}
