// internal/utf32/seeder.go
//
// Unicode PDF Seeder — tự động đọc PDF → parse chars → gen SDF via AI → seed vào .olang
//
// Pipeline:
//   URL → fetch PDF → pdftotext → parse Unicode chart
//       → gọi Anthropic API để gen vSDF CAPSULE DNA cho từng char
//       → appendL1Node vào homeos.olang

package utf32

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// CharEntry — một ký tự từ Unicode chart
type CharEntry struct {
	Codepoint uint32
	Name      string
	Group     string // uppercase/lowercase/digit/punct/symbol/modifier/ligature/letter
	ScriptID  uint8
}

// SeedResult — kết quả
type SeedResult struct {
	Added   int
	Skipped int
	Failed  int
}

var scriptIDs = map[string]uint8{
	"latin": 0x00, "latin_ext": 0x01, "ipa": 0x02,
	"greek": 0x03, "cyrillic": 0x04,
	"hebrew": 0x06, "arabic": 0x07, "hiragana": 0x08,
	"katakana": 0x09, "armenian": 0x0A, "cjk": 0x0B,
	"hangul": 0x0C, "math": 0x0D, "digits": 0x0E,
	"georgian": 0x0F, "ethiopic": 0x10, "tibetan": 0x11,
	"devanagari": 0x12, "thai": 0x13, "khmer": 0x14,
	"myanmar": 0x15, "tamil": 0x17, "telugu": 0x18,
	"kannada": 0x19, "malayalam": 0x1A, "bengali": 0x1B,
	"lao": 0x1F, "symbols": 0x20, "emoji": 0x21,
	"unknown": 0xFF,
}

var groupIDs = map[string]uint8{
	"uppercase": 0x01, "lowercase": 0x02, "ligature": 0x03,
	"punct": 0x04, "symbol": 0x05, "modifier": 0x06,
	"combining": 0x07, "digit": 0x08, "letter": 0x09,
}

// ─────────────────────────────────────────────────────────────
// SeedFromURL — entry point chính
// ─────────────────────────────────────────────────────────────

func SeedFromURL(ctx context.Context, olangPath, pdfURL string) (*SeedResult, error) {
	fmt.Printf("📥 Fetching %s\n", pdfURL)
	pdfBytes, err := fetchURL(pdfURL)
	if err != nil {
		return nil, fmt.Errorf("fetch: %w", err)
	}
	fmt.Printf("   PDF: %d bytes\n", len(pdfBytes))

	text, err := extractText(pdfBytes)
	if err != nil {
		return nil, fmt.Errorf("extract: %w", err)
	}

	script, chars := parseChart(text, pdfURL)
	if len(chars) == 0 {
		return nil, fmt.Errorf("parse: không tìm thấy ký tự nào trong PDF")
	}
	fmt.Printf("   Script: %s | Chars: %d\n", script, len(chars))

	existing := existingCodepoints(olangPath)
	sid := scriptIDs[script]
	var todo []CharEntry
	for _, c := range chars {
		if !existing[c.Codepoint] {
			c.ScriptID = sid
			todo = append(todo, c)
		}
	}
	fmt.Printf("   Cần seed: %d (đã có: %d)\n", len(todo), len(chars)-len(todo))
	if len(todo) == 0 {
		return &SeedResult{Skipped: len(chars)}, nil
	}

	// Download PDF về local để SkillGlyphToSDF đọc
	pdfPath, pdfErr := downloadPDF(pdfURL, pdfBytes)
	if pdfErr != nil {
		fmt.Printf("   ⚠️  PDF cache: %v\n", pdfErr)
		pdfPath = ""
	} else {
		defer os.Remove(pdfPath)
	}
	ctxWithPDF := context.WithValue(ctx, ctxPDFPath{}, pdfPath)
	ctxWithPDF = context.WithValue(ctxWithPDF, ctxPDFURL{}, pdfURL)
	fmt.Printf("🔬 Extracting SDF from PDF glyphs (no AI)...\n")
	dnas := genSDFAll(ctxWithPDF, todo, script)

	result := &SeedResult{}
	counters := map[[2]uint8]uint8{}
	for i, c := range todo {
		gid := groupIDs[c.Group]
		if gid == 0 {
			gid = 0x09
		}
		k := [2]uint8{c.ScriptID, gid}
		counters[k]++
		id := counters[k]

		isl := [8]byte{0x01, c.ScriptID, gid, id}
		dna := dnas[i]
		if len(dna) == 0 {
			dna = metaDNA(c.ScriptID, gid, c.Codepoint)
		}

		nodeName := normName(script + "_" + c.Name)
		err := appendL1(olangPath, isl, c.Codepoint, dna, nodeName)
		if err != nil {
			if err.Error() == "duplicate ISL" {
				result.Skipped++
			} else {
				result.Failed++
				fmt.Printf("   ❌ U+%04X %s: %v\n", c.Codepoint, c.Name, err)
			}
			continue
		}
		result.Added++
		tag := "meta"
		if len(dna) > 15 {
			tag = fmt.Sprintf("SDF %dB", len(dna))
		}
		fmt.Printf("   ✅ U+%04X %-34s [%s]\n", c.Codepoint, c.Name, tag)
	}
	return result, nil
}

// ─────────────────────────────────────────────────────────────
// Fetch + Extract
// ─────────────────────────────────────────────────────────────

func fetchURL(url string) ([]byte, error) {
	resp, err := (&http.Client{Timeout: 30 * time.Second}).Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(resp.Body)
}

func extractText(pdfBytes []byte) (string, error) {
	tmp, err := os.CreateTemp("", "olang_seed_*.pdf")
	if err != nil {
		return "", err
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.Write(pdfBytes); err != nil {
		tmp.Close()
		return "", err
	}
	tmp.Close()

	out, err := exec.Command("pdftotext", "-layout", tmp.Name(), "-").Output()
	if err == nil && len(out) > 50 {
		return string(out), nil
	}
	// Fallback: tìm text patterns trong PDF stream
	re := regexp.MustCompile(`\(([^\)\n]{1,80})\)`)
	var sb strings.Builder
	for _, m := range re.FindAllSubmatch(pdfBytes, -1) {
		sb.Write(m[1])
		sb.WriteByte('\n')
	}
	return sb.String(), nil
}

// ─────────────────────────────────────────────────────────────
// Parse Unicode Chart
// ─────────────────────────────────────────────────────────────

func parseChart(text, url string) (string, []CharEntry) {
	script := detectScript(text, url)

	// Pattern 1 (full name): "0531 Ա ARMENIAN CAPITAL LETTER AYB"
	// Pattern 2 (2-column layout từ pdftotext): cùng dòng có 2 entries
	// Dùng regex không anchor ^ để bắt cả 2-column
	re := regexp.MustCompile(`([0-9A-Fa-f]{4,6})\s+\S*\s+([A-Z][A-Z0-9 '\-]{3,60})`)
	seen := map[uint32]bool{}
	var out []CharEntry
	skipWords := []string{"UNICODE", "THE UNICODE", "THIS FILE", "SEE HTTPS",
		"COPYRIGHT", "DISCLAIMER", "VERSION", "STANDARD", "ENCODED"}
	for _, m := range re.FindAllStringSubmatch(text, -1) {
		v, err := strconv.ParseUint(m[1], 16, 32)
		if err != nil {
			continue
		}
		cp := uint32(v)
		name := strings.TrimSpace(m[2])
		// Trim trailing notes (sau "=", "•", "→")
		for _, sep := range []string{" =", " •", " →", "  "} {
			if idx := strings.Index(name, sep); idx > 0 {
				name = strings.TrimSpace(name[:idx])
			}
		}
		if len(name) < 3 || seen[cp] {
			continue
		}
		skip := false
		for _, w := range skipWords {
			if strings.HasPrefix(name, w) {
				skip = true
				break
			}
		}
		if skip {
			continue
		}
		// Filter: codepoint phải nằm trong range hợp lý (không phải số trang, năm...)
		if cp < 0x0080 || cp > 0x10FFFF {
			continue
		}
		seen[cp] = true
		out = append(out, CharEntry{
			Codepoint: cp,
			Name:      name,
			Group:     classifyGroup(name),
		})
	}
	return script, out
}

func detectScript(text, url string) string {
	u := strings.ToLower(url)
	table := [][2]string{
		{"u0530", "armenian"}, {"u0590", "hebrew"},   {"u0600", "arabic"},
		{"u0400", "cyrillic"}, {"u0370", "greek"},    {"u0900", "devanagari"},
		{"u0e00", "thai"},     {"u0f00", "tibetan"},  {"u1000", "myanmar"},
		{"u3040", "hiragana"}, {"u30a0", "katakana"}, {"u4e00", "cjk"},
		{"u1200", "ethiopic"}, {"u10a0", "georgian"}, {"u1100", "hangul"},
		{"u0100", "latin_ext"},{"u0250", "ipa"},      {"u0000", "latin"},
	}
	for _, kv := range table {
		if strings.Contains(u, kv[0]) {
			return kv[1]
		}
	}
	tl := strings.ToLower(text)
	for _, kv := range table {
		if strings.Contains(tl, kv[1]) {
			return kv[1]
		}
	}
	return "unknown"
}

func classifyGroup(name string) string {
	n := strings.ToUpper(name)
	check := func(keywords ...string) bool {
		for _, k := range keywords {
			if strings.Contains(n, k) {
				return true
			}
		}
		return false
	}
	switch {
	case check("CAPITAL", "UPPERCASE", "MAJUSCULE"):
		return "uppercase"
	case check("SMALL LETTER", "LOWERCASE", "MINUSCULE"):
		return "lowercase"
	case check("LIGATURE"):
		return "ligature"
	case check("DIGIT", "NUMBER"):
		return "digit"
	case check("MODIFIER"):
		return "modifier"
	case check("COMBINING"):
		return "combining"
	case check("STOP", "COMMA", "HYPHEN", "APOSTROPHE", "QUESTION", "EXCLAMATION",
		"PUNCTUATION", "ABBREVIATION"):
		return "punct"
	case check("SIGN", "SYMBOL", "CURRENCY", "DRAM", "ETERNITY", "SHEKEL"):
		return "symbol"
	default:
		return "letter"
	}
}

// ─────────────────────────────────────────────────────────────
// SDF Generation via Anthropic API
// ─────────────────────────────────────────────────────────────

// genSDFAll — gọi SkillGlyphToSDF (Python) để gen capsules từ PDF glyph images
// Không dùng AI/API — tất cả local: render PDF → skeleton → capsule fitting
func genSDFAll(ctx context.Context, chars []CharEntry, script string) [][]byte {
	results := make([][]byte, len(chars))

	// Build cp→index map
	cpIdx := map[uint32]int{}
	for i, c := range chars {
		cpIdx[c.Codepoint] = i
	}

	// Gọi skill_glyph_to_sdf.py nếu có PDF path trong ctx
	pdfPath, _ := ctx.Value(ctxPDFPath{}).(string)
	if pdfPath == "" {
		return results // fallback: caller sẽ dùng metaDNA
	}

	sdfs, err := runGlyphSkill(ctx, pdfPath)
	if err != nil {
		fmt.Printf("   ⚠️  SkillGlyphToSDF: %v\n", err)
		return results
	}

	hit := 0
	for _, item := range sdfs {
		idx, ok := cpIdx[item.CP]
		if !ok {
			continue
		}
		dna := encodeSDFDNA(float32(item.Scale), item.Capsules)
		if len(dna) > 0 {
			results[idx] = dna
			hit++
		}
	}
	fmt.Printf("   SkillGlyphToSDF: %d glyphs → %d SDF hits\n", len(sdfs), hit)
	return results
}

// ctxPDFPath — context key để truyền PDF path vào pipeline
type ctxPDFPath struct{}

// ctxPDFURL — context key để truyền URL gốc (chứa block info: U0530 etc.)
type ctxPDFURL struct{}

// glyphItem — output từ skill_glyph_to_sdf.py
type glyphItem struct {
	CP       uint32    `json:"cp"`
	Scale    float64   `json:"scale"`
	Capsules []capItem `json:"capsules"`
}

// runGlyphSkill — chạy Python skill và parse JSON output
func runGlyphSkill(ctx context.Context, pdfPath string) ([]glyphItem, error) {
	// Tìm skill script (relative to binary hoặc OLANG_HOME)
	skillPath := findSkillScript("skill_glyph_to_sdf.py")
	if skillPath == "" {
		return nil, fmt.Errorf("skill_glyph_to_sdf.py not found")
	}

	// Lấy block base từ context (URL chứa U0530 etc.)
	pdfURL, _ := ctx.Value(ctxPDFURL{}).(string)
	cmd := exec.CommandContext(ctx, "python3", skillPath, pdfPath,
		"--page", "2", "--dpi", "150", "--max-caps", "5",
		"--source-url", pdfURL)
	out, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("skill exec: %w", err)
	}

	var items []glyphItem
	if err := json.Unmarshal(out, &items); err != nil {
		return nil, fmt.Errorf("skill JSON: %w", err)
	}
	return items, nil
}

func findSkillScript(name string) string {
	// Thử các vị trí theo thứ tự
	candidates := []string{
		// Cùng thư mục với binary
		filepath.Join(filepath.Dir(os.Args[0]), "internal", "utf32", name),
		// Từ working directory
		filepath.Join("internal", "utf32", name),
		// OLANG_HOME env
		filepath.Join(os.Getenv("OLANG_HOME"), "internal", "utf32", name),
		// Absolute fallback
		"/home/claude/session146/Origin/internal/utf32/" + name,
	}
	for _, p := range candidates {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return ""
}

// capItem — một capsule primitive
type capItem struct {
	Ax float64 `json:"ax"`
	Ay float64 `json:"ay"`
	Az float64 `json:"az"`
	Bx float64 `json:"bx"`
	By float64 `json:"by"`
	Bz float64 `json:"bz"`
	R  float64 `json:"r"`
}

// encodeSDFDNA — capsules → vSDF bytecode với b[0]=STATE|TYPE header
//
// Layout: [b0=QR|SDF=0x42] [OpUnion=0x10 n smooth_k_f32] [OpCapsule=0x02 ax ay az bx by bz r]*
// b[0] = 0x42 = QR(0x40) | SDF(0x02) — theo NODE_Spec
// Executor phải skip b[0] (dùng để dispatch TYPE), bắt đầu exec từ b[1].
//
// Nếu có scale: [b0=QR|SDF=0x42] [0x9A scale_f32] [OpUnion n k] [OpCapsule...]*
func encodeSDFDNA(scale float32, caps []capItem) []byte {
	if len(caps) == 0 {
		return nil
	}
	var buf bytes.Buffer
	// b[0] = STATE|TYPE header theo NODE_Spec
	// QR=0x40 | SDF=0x02 = 0x42
	buf.WriteByte(0x42) // QR|SDF
	if scale > 0 && math.Abs(float64(scale)-1.0) > 0.01 {
		buf.WriteByte(0x9A)
		buf.Write(f32be(scale))
	}
	buf.WriteByte(0x10) // OpUnion
	buf.WriteByte(uint8(len(caps)))
	buf.Write(f32be(0.02))
	for _, c := range caps {
		buf.WriteByte(0x02) // OpCapsule
		for _, v := range []float32{
			float32(c.Ax), float32(c.Ay), float32(c.Az),
			float32(c.Bx), float32(c.By), float32(c.Bz),
			float32(c.R),
		} {
			buf.Write(f32be(v))
		}
	}
	return buf.Bytes()
}

type sdfItem struct {
	CP       uint32 `json:"cp"`
	Scale    float64 `json:"scale"`
	Capsules []struct {
		Ax float64 `json:"ax"`
		Ay float64 `json:"ay"`
		Az float64 `json:"az"`
		Bx float64 `json:"bx"`
		By float64 `json:"by"`
		Bz float64 `json:"bz"`
		R          float64 `json:"r"`
	} `json:"capsules"`
}

func callSDF(ctx context.Context, chars []CharEntry, script string) ([][]byte, error) {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Script: %s\nGenerate vSDF capsule primitives for Unicode chars.\n\n", script))
	sb.WriteString("Rules:\n- Coordinate space: x∈[-0.5,0.5] y∈[-0.5,0.5] z=0 always\n")
	sb.WriteString("- r=0.05 default. scale=0.8 default.\n")
	sb.WriteString("- Capsule count by group: uppercase 2-5, lowercase 1-4, punct 1-2, symbol 1-2\n")
	sb.WriteString("- Capture main strokes of glyph shape with capsules\n\n")
	sb.WriteString("Characters:\n")
	for i, c := range chars {
		sb.WriteString(fmt.Sprintf("%d. U+%04X '%c' \"%s\" [%s]\n",
			i+1, c.Codepoint, rune(c.Codepoint), c.Name, c.Group))
	}
	sb.WriteString("\nReturn ONLY JSON array:\n")
	sb.WriteString(`[{"cp":1329,"scale":0.8,"capsules":[{"ax":-0.25,"ay":0.5,"az":0,"bx":-0.25,"by":-0.5,"bz":0,"r":0.05}]}]`)

	type msg struct {
		Role    string `json:"role"`
		Content string `json:"content"`
	}
	body, _ := json.Marshal(map[string]interface{}{
		"model":      "claude-sonnet-4-20250514",
		"max_tokens": 4096,
		"system":     "You are a vSDF geometry engine. Output ONLY valid JSON array. No markdown, no explanation.",
		"messages":   []msg{{Role: "user", Content: sb.String()}},
	})

	req, _ := http.NewRequestWithContext(ctx, "POST",
		"https://api.anthropic.com/v1/messages", bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("anthropic-version", "2023-06-01")
	if k := os.Getenv("ANTHROPIC_API_KEY"); k != "" {
		req.Header.Set("x-api-key", k)
	}

	resp, err := (&http.Client{Timeout: 90 * time.Second}).Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		n := len(b)
		if n > 200 {
			n = 200
		}
		return nil, fmt.Errorf("HTTP %d: %s", resp.StatusCode, b[:n])
	}

	var ar struct {
		Content []struct {
			Type string `json:"type"`
			Text string `json:"text"`
		} `json:"content"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&ar); err != nil {
		return nil, err
	}
	if len(ar.Content) == 0 {
		return nil, fmt.Errorf("empty response")
	}

	raw := strings.TrimSpace(ar.Content[0].Text)
	// Strip markdown nếu có
	if i := strings.Index(raw, "["); i > 0 {
		raw = raw[i:]
	}
	if i := strings.LastIndex(raw, "]"); i >= 0 && i < len(raw)-1 {
		raw = raw[:i+1]
	}

	var items []sdfItem
	if err := json.Unmarshal([]byte(raw), &items); err != nil {
		n := len(raw)
		if n > 300 {
			n = 300
		}
		return nil, fmt.Errorf("JSON: %w\nraw: %s", err, raw[:n])
	}

	cpMap := map[uint32]*sdfItem{}
	for i := range items {
		cpMap[items[i].CP] = &items[i]
	}

	results := make([][]byte, len(chars))
	for i, c := range chars {
		it := cpMap[c.Codepoint]
		if it == nil || len(it.Capsules) == 0 {
			continue
		}
		var buf bytes.Buffer
		sc := float32(it.Scale)
		if sc > 0 && math.Abs(float64(sc)-1.0) > 0.01 {
			buf.WriteByte(0x9A)
			buf.Write(f32be(sc))
		}
		buf.WriteByte(0x10)
		buf.WriteByte(uint8(len(it.Capsules)))
		buf.Write(f32be(0.02))
		for _, cap := range it.Capsules {
			buf.WriteByte(0x02)
			for _, v := range []float32{
				float32(cap.Ax), float32(cap.Ay), float32(cap.Az),
				float32(cap.Bx), float32(cap.By), float32(cap.Bz),
				float32(cap.R),
			} {
				buf.Write(f32be(v))
			}
		}
		results[i] = buf.Bytes()
	}
	return results, nil
}

// downloadPDF — lưu PDF bytes vào temp file để Python skill đọc
func downloadPDF(pdfURL string, pdfBytes []byte) (string, error) {
	tmp, err := os.CreateTemp("", "olang_glyph_*.pdf")
	if err != nil {
		return "", err
	}
	if _, err := tmp.Write(pdfBytes); err != nil {
		tmp.Close()
		os.Remove(tmp.Name())
		return "", err
	}
	tmp.Close()
	return tmp.Name(), nil
}

func f32be(v float32) []byte {
	b := make([]byte, 4)
	binary.BigEndian.PutUint32(b, math.Float32bits(v))
	return b
}

// ─────────────────────────────────────────────────────────────
// Binary helpers
// ─────────────────────────────────────────────────────────────

func normName(s string) string {
	s = strings.ToUpper(s)
	s = strings.ReplaceAll(s, " ", "_")
	s = strings.ReplaceAll(s, "'", "")
	s = strings.ReplaceAll(s, "-", "_")
	if len(s) > 48 {
		s = s[:48]
	}
	return s
}

// metaDNA — fallback DNA khi không có SDF thật
// Layout theo NODE_Spec ATOM:
//   b[0] = QR|ATOM = 0x40|0x01 = 0x41  ← STATE|TYPE
//   b[1] = EMIT    = 0x14               ← L0 opcode (ATOM luôn bắt đầu EMIT)
//   b[2..5] = val float32 big-endian    ← val = float32(codepoint)
//   b[6] = id_hi = (cp >> 16) & 0xFF   ← nhận dạng high
//   b[7..13] = 0                        ← padding
//
// Executor ATOM: skip b[0], đọc val từ b[1..4] — nhưng b[1]=EMIT (0x14) không phải val
// → Theo spec đúng: executor ATOM đọc val tại b[1..4] = [EMIT][val:3B] = sai!
// → Cần executor đọc val tại b[2..5] (sau EMIT byte)
//
// NOTE: executor hiện đọc val tại b[1..4] (sau skip b[0])
// → val ở b[1..4] = [EMIT=0x14][cp_byte2][cp_byte1][cp_byte0]
// → Để đơn giản: đặt val tại b[1..4] trực tiếp (skip EMIT, đặt val ngay)
// → b[1..4] = f32(codepoint) big-endian
// metaDNA — DNA cho L1 UTF32 ATOM node
// Layout đúng NODE_Spec:
//   b[0]    = QR|ATOM = 0x41
//   b[1]    = EMIT    = 0x14
//   b[2..5] = val     = f32(codepoint)  ← executor đọc tại đây
//   b[6]    = id_hi   = scriptID
//   b[7]    = id_lo   = groupID
//   b[8]    = 0 padding
func metaDNA(scriptID, groupID uint8, cp uint32) []byte {
	dna := make([]byte, 9)
	dna[0] = 0x41 // QR(0x40)|ATOM(0x01)
	dna[1] = 0x14 // EMIT opcode
	bits := math.Float32bits(float32(cp))
	dna[2] = byte(bits >> 24)
	dna[3] = byte(bits >> 16)
	dna[4] = byte(bits >> 8)
	dna[5] = byte(bits)
	dna[6] = scriptID // id_hi
	dna[7] = groupID  // id_lo
	// dna[8] = 0
	return dna
}

func existingCodepoints(olangPath string) map[uint32]bool {
	raw, _ := os.ReadFile(olangPath)
	seen := map[uint32]bool{}
	for i := 280; i+20 < len(raw); {
		if raw[i] == 'N' && raw[i+1] == 'D' && raw[i+2] == 0x01 {
			seen[binary.BigEndian.Uint32(raw[i+11:i+15])] = true
		}
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		if dl < 0 || nl < 0 || dl > 65536 || nl > 255 {
			break
		}
		i += 20 + dl + nl
	}
	return seen
}

func appendL1(path string, isl [8]byte, cp uint32, dna []byte, name string) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if len(raw) < 280 || string(raw[0:4]) != "OLNG" {
		return fmt.Errorf("bad file")
	}
	nb := []byte(name)
	if len(nb) > 255 {
		nb = nb[:255]
	}

	// Dup ISL check
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 {
		edgeStart = 280
	}
	for i := 280; i+20 < edgeStart; {
		if raw[i] == 'N' && raw[i+1] == 'D' {
			if string(raw[i+3:i+11]) == string(isl[:]) {
				return fmt.Errorf("duplicate ISL")
			}
		}
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		if dl < 0 || nl < 0 || dl > 65536 || nl > 255 {
			i++
			continue
		}
		i += 20 + dl + nl
	}

	// Build record
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'
	rec[1] = 'D'
	rec[2] = 0x01
	copy(rec[3:11], isl[:])
	binary.BigEndian.PutUint32(rec[11:], cp)
	binary.BigEndian.PutUint32(rec[15:], uint32(len(dna)))
	rec[19] = uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)

	// Layer index
	type li struct{ off, sz uint64 }
	layers := [9]li{}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		layers[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].sz = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}
	var at uint64
	if layers[1].sz > 0 {
		at = layers[1].off + layers[1].sz
	} else {
		at = 280
		for i := 0; i < 9; i++ {
			if layers[i].sz > 0 {
				cand := layers[i].off + layers[i].sz
				if cand > at {
					at = cand
				}
			}
		}
	}

	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:at]...)
	out = append(out, rec...)
	out = append(out, raw[at:]...)

	o1 := 64 + 1*24
	if layers[1].sz == 0 {
		binary.BigEndian.PutUint64(out[o1+4:], at)
	}
	binary.BigEndian.PutUint64(out[o1+12:], layers[1].sz+uint64(len(rec)))
	binary.BigEndian.PutUint32(out[o1+20:], binary.BigEndian.Uint32(out[o1+20:])+1)
	for i := 2; i < 9; i++ {
		o := 64 + i*24
		if layers[i].sz > 0 {
			binary.BigEndian.PutUint64(out[o+4:], binary.BigEndian.Uint64(out[o+4:])+uint64(len(rec)))
		}
	}
	binary.BigEndian.PutUint32(out[9:13], binary.BigEndian.Uint32(out[9:13])+1)
	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// L1NodeSpec — spec cho một L1 node cần append (dùng cho batch)
type L1NodeSpec struct {
	ISL  [8]byte
	CP   uint32
	DNA  []byte
	Name string
}

// AppendL1Batch đọc file 1 lần, insert nhiều L1 records, ghi 1 lần.
// Hiệu quả hơn nhiều so với appendL1 từng lần (O(1) I/O thay vì O(n)).
// Trả về (added, skipped, error).
// AppendNodeBatch — như AppendL1Batch nhưng layer lấy từ ISL[0]
// Dùng để seed nodes ở bất kỳ layer nào (L0-L8).
// QTConceptNodes dùng layer=3, SymbolTable dùng layer=1.
func AppendNodeBatch(path string, nodes []L1NodeSpec) (added, skipped int, err error) {
	raw, err := os.ReadFile(path)
	if err != nil { return 0, 0, err }
	if len(raw) < 280 || string(raw[0:4]) != "OLNG" {
		return 0, 0, fmt.Errorf("AppendNodeBatch: bad file magic")
	}

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 { edgeStart = 280 }

	existing := map[[8]byte]struct{}{}
	for i := 280; i+20 < edgeStart; {
		if raw[i] == 'N' && raw[i+1] == 'D' {
			var k [8]byte
			copy(k[:], raw[i+3:i+11])
			existing[k] = struct{}{}
			dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
			nl := int(raw[i+19])
			if dl < 0 || dl > 65536 || nl > 255 { i++; continue }
			i += 20 + dl + nl
		} else { i++ }
	}

	// Group nodes by layer — insert each layer's bulk at the right position
	type layerBulk struct {
		layer byte
		data  []byte
		count int
	}
	byLayer := map[byte]*layerBulk{}
	layerOrder := []byte{}

	for _, n := range nodes {
		if _, dup := existing[n.ISL]; dup { skipped++; continue }
		layer := n.ISL[0] // layer từ ISL[0]
		if layer == 0 { layer = 1 }

		nb := []byte(n.Name)
		if len(nb) > 255 { nb = nb[:255] }
		dna := n.DNA
		if len(dna) > 65536 { dna = dna[:65536] }

		rec := make([]byte, 20+len(dna)+len(nb))
		rec[0] = 'N'; rec[1] = 'D'
		rec[2] = layer
		copy(rec[3:11], n.ISL[:])
		binary.BigEndian.PutUint32(rec[11:], n.CP)
		binary.BigEndian.PutUint32(rec[15:], uint32(len(dna)))
		rec[19] = uint8(len(nb))
		copy(rec[20:], dna)
		copy(rec[20+len(dna):], nb)

		if _, ok := byLayer[layer]; !ok {
			byLayer[layer] = &layerBulk{layer: layer}
			layerOrder = append(layerOrder, layer)
		}
		byLayer[layer].data = append(byLayer[layer].data, rec...)
		byLayer[layer].count++
		existing[n.ISL] = struct{}{}
		added++
	}
	if added == 0 { return 0, skipped, nil }

	type li struct{ off, sz uint64 }
	layers := [9]li{}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		layers[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].sz  = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}

	// Insert each layer's bulk right after existing data for that layer
	out := make([]byte, len(raw), len(raw)+len(raw)/10)
	copy(out, raw)

	// Sort layerOrder để insert từ cuối → đầu (không ảnh hưởng offsets đã tính)
	for i := 0; i < len(layerOrder)-1; i++ {
		for j := i + 1; j < len(layerOrder); j++ {
			if layerOrder[j] < layerOrder[i] { layerOrder[i], layerOrder[j] = layerOrder[j], layerOrder[i] }
		}
	}
	// Insert từ layer lớn nhất xuống nhỏ nhất (giữ offsets đúng)
	for li2 := len(layerOrder) - 1; li2 >= 0; li2-- {
		l := layerOrder[li2]
		lb := byLayer[l]
		var insertAt uint64
		if layers[l].sz > 0 {
			insertAt = layers[l].off + layers[l].sz
		} else {
			insertAt = 280
			for i := 0; i < 9; i++ {
				if layers[i].sz > 0 {
					if c := layers[i].off + layers[i].sz; c > insertAt { insertAt = c }
				}
			}
		}
		// Insert lb.data at insertAt
		newOut := make([]byte, 0, len(out)+len(lb.data))
		newOut = append(newOut, out[:insertAt]...)
		newOut = append(newOut, lb.data...)
		newOut = append(newOut, out[insertAt:]...)
		out = newOut
		_ = lb
	}

	// Update layer indices in header — recalculate from scratch
	// Re-scan nodes to get accurate layer sizes
	nodeCounts := [9]int{}
	layerSizes  := [9]uint64{}
	layerOffs   := [9]uint64{}
	pos := 280
	totalNodes := 0
	for pos+20 < len(out)-nedges*olang.EdgeSize {
		if out[pos] == 'N' && out[pos+1] == 'D' {
			l := int(out[pos+2])
			if l >= 0 && l < 9 {
				if layerOffs[l] == 0 { layerOffs[l] = uint64(pos) }
				dl := int(binary.BigEndian.Uint32(out[pos+15 : pos+19]))
				nl := int(out[pos+19])
				recLen := 20 + dl + nl
				layerSizes[l] += uint64(recLen)
				nodeCounts[l]++
				totalNodes++
				pos += recLen
			} else { pos++ }
		} else { pos++ }
	}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		binary.BigEndian.PutUint64(out[o+4:],  layerOffs[i])
		binary.BigEndian.PutUint64(out[o+12:], layerSizes[i])
		binary.BigEndian.PutUint32(out[o+20:], uint32(nodeCounts[i]))
	}
	binary.BigEndian.PutUint32(out[9:13], uint32(totalNodes))

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := path + ".node.tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return 0, skipped, err }
	return added, skipped, os.Rename(tmp, path)
}

func AppendL1Batch(path string, nodes []L1NodeSpec) (added, skipped int, err error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return 0, 0, err
	}
	if len(raw) < 280 || string(raw[0:4]) != "OLNG" {
		return 0, 0, fmt.Errorf("AppendL1Batch: bad file magic")
	}

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 {
		edgeStart = 280
	}

	// Build ISL lookup set từ existing nodes
	existing := map[[8]byte]struct{}{}
	for i := 280; i+20 < edgeStart; {
		if raw[i] == 'N' && raw[i+1] == 'D' {
			var k [8]byte
			copy(k[:], raw[i+3:i+11])
			existing[k] = struct{}{}
			dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
			nl := int(raw[i+19])
			if dl < 0 || dl > 65536 || nl > 255 {
				i++
				continue
			}
			i += 20 + dl + nl
		} else {
			i++
		}
	}

	// Build tất cả records cần thêm
	var bulk []byte
	for _, n := range nodes {
		if _, dup := existing[n.ISL]; dup {
			skipped++
			continue
		}
		nb := []byte(n.Name)
		if len(nb) > 255 {
			nb = nb[:255]
		}
		dna := n.DNA
		if len(dna) > 65536 {
			dna = dna[:65536]
		}
		rec := make([]byte, 20+len(dna)+len(nb))
		rec[0] = 'N'
		rec[1] = 'D'
		rec[2] = 0x01 // layer 1
		copy(rec[3:11], n.ISL[:])
		binary.BigEndian.PutUint32(rec[11:], n.CP)
		binary.BigEndian.PutUint32(rec[15:], uint32(len(dna)))
		rec[19] = uint8(len(nb))
		copy(rec[20:], dna)
		copy(rec[20+len(dna):], nb)
		bulk = append(bulk, rec...)
		existing[n.ISL] = struct{}{} // prevent dup within batch
		added++
	}

	if added == 0 {
		return 0, skipped, nil
	}

	// Layer index
	type li struct{ off, sz uint64 }
	layers := [9]li{}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		layers[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].sz = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}
	var at uint64
	if layers[1].sz > 0 {
		at = layers[1].off + layers[1].sz
	} else {
		at = 280
		for i := 0; i < 9; i++ {
			if layers[i].sz > 0 {
				if c := layers[i].off + layers[i].sz; c > at {
					at = c
				}
			}
		}
	}

	out := make([]byte, 0, len(raw)+len(bulk))
	out = append(out, raw[:at]...)
	out = append(out, bulk...)
	out = append(out, raw[at:]...)

	o1 := 64 + 1*24
	if layers[1].sz == 0 {
		binary.BigEndian.PutUint64(out[o1+4:], at)
	}
	binary.BigEndian.PutUint64(out[o1+12:], layers[1].sz+uint64(len(bulk)))
	binary.BigEndian.PutUint32(out[o1+20:], binary.BigEndian.Uint32(out[o1+20:])+uint32(added))
	for i := 2; i < 9; i++ {
		o := 64 + i*24
		if layers[i].sz > 0 {
			binary.BigEndian.PutUint64(out[o+4:], binary.BigEndian.Uint64(out[o+4:])+uint64(len(bulk)))
		}
	}
	binary.BigEndian.PutUint32(out[9:13], binary.BigEndian.Uint32(out[9:13])+uint32(added))

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := path + ".batch.tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil {
		return 0, skipped, err
	}
	if err := os.Rename(tmp, path); err != nil {
		return 0, skipped, err
	}
	return added, skipped, nil
}
