// internal/utf32/pdf_sdf_engine.go
//
// PDFSeedEngine — tự động gen vSDF thật từ Unicode chart PDFs (utf32.txt).
//
// Pipeline (không cần AI API, không cần font):
//   utf32.txt → parse URLs → priority sort
//       ↓
//   fetchPDFCached (cache /tmp/pdf_cache/)
//       ↓
//   skill_glyph_to_sdf.py → JSON capsules  (skeleton + PCA local)
//       ↓
//   validate + clamp capsules
//       ↓
//   patchDNAInPlace hoặc growNodeDNA
//       ↓
//   checkpoint (resumable) + recomputeSHA256

package utf32

import (
	"context"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// ─── Config ───────────────────────────────────────────────────────────────────

type PDFSeedConfig struct {
	OlangPath      string
	UTF32TxtPath   string // /mnt/project/utf32.txt
	SkillPath      string // skill_glyph_to_sdf.py
	CacheDir       string // /tmp/pdf_cache/
	CheckpointPath string
	MaxErrors      int
	DPI            int
	MaxCaps        int
	BlockFilter    []uint32 // nếu không rỗng: chỉ process blocks này
	Verbose        bool
}

func DefaultPDFSeedConfig(olangPath string) PDFSeedConfig {
	return PDFSeedConfig{
		OlangPath:      olangPath,
		UTF32TxtPath:   "/mnt/project/utf32.txt",
		SkillPath:      findSkillScript("skill_glyph_to_sdf.py"),
		CacheDir:       "/tmp/pdf_cache",
		CheckpointPath: olangPath + ".pdfseed.ckpt",
		MaxErrors:      10,
		DPI:            200,
		MaxCaps:        5,
	}
}

// ─── Result ───────────────────────────────────────────────────────────────────

type PDFSeedResult struct {
	PDFs     int
	Glyphs   int
	Patched  int
	Skipped  int
	Failed   int
	Duration time.Duration
}

func (r *PDFSeedResult) String() string {
	return fmt.Sprintf(
		"pdf-seed: pdfs=%d glyphs=%d patched=%d skipped=%d failed=%d time=%.0fs",
		r.PDFs, r.Glyphs, r.Patched, r.Skipped, r.Failed, r.Duration.Seconds(),
	)
}

// ─── Block priority ───────────────────────────────────────────────────────────

type pdfBlock struct {
	url      string
	base     uint32
	priority int // thấp hơn = xử lý trước
}

// blockPriorityMap — Unicode block base → priority (lower = earlier)
var blockPriorityMap = map[uint32]int{
	// Latin
	0x0000: 1, 0x0080: 2, 0x0100: 3, 0x0180: 4,
	// IPA / Phonetic Extensions
	0x0250: 6, 0x02B0: 7,
	// Greek / Coptic
	0x0370: 10,
	// Cyrillic
	0x0400: 11, 0x0500: 12,
	// Armenian / Georgian
	0x0530: 20, 0x10A0: 21,
	// Hebrew / Arabic / Syriac
	0x0590: 22, 0x0600: 23, 0x0700: 24, 0x0750: 25,
	// Devanagari + other Indic
	0x0900: 30, 0x0980: 31, 0x0A00: 32, 0x0A80: 33,
	0x0B00: 34, 0x0B80: 35, 0x0C00: 36, 0x0C80: 37, 0x0D00: 38,
	// Thai / Lao / Myanmar / Khmer
	0x0E00: 40, 0x0E80: 41, 0x1000: 42, 0x1780: 43,
	// General Punctuation / Symbols / Math / Arrows
	0x2000: 50, 0x2100: 51, 0x2150: 52, 0x2190: 53,
	0x2200: 54, 0x2300: 55, 0x2400: 56, 0x2440: 57,
	0x2460: 58, 0x2500: 59, 0x2580: 60, 0x25A0: 61,
	0x2600: 62, 0x2700: 63, 0x27C0: 64, 0x27F0: 65,
	0x2900: 66, 0x2980: 67, 0x2B00: 68,
	// CJK Radicals
	0x2E80: 70, 0x2F00: 71,
	// CJK Symbols / Hiragana / Katakana / Bopomofo
	0x3000: 80, 0x3040: 81, 0x30A0: 82, 0x3100: 83,
	0x3130: 84, 0x31A0: 85, 0x31C0: 86, 0x31F0: 87,
	// CJK Extension A
	0x3400: 90,
	// CJK Unified Ideographs
	0x4E00: 100,
	// Hangul
	0xAC00: 110, 0x1100: 111,
	// CJK Compatibility / Fullwidth
	0xF900: 120, 0xFF00: 121,
	// Mathematical Alphanumeric Symbols
	0x1D400: 130,
	// Emoji / Misc Symbols Extended
	0x1F300: 150, 0x1F600: 151, 0x1F700: 152, 0x1FA70: 153,
}

// ─── Parse utf32.txt ─────────────────────────────────────────────────────────

var rePDFBlock = regexp.MustCompile(`U(?:[0-9A-Fa-f]+-)?([0-9A-Fa-f]{4,6})\.pdf`)

func parsePDFBlocks(utf32Path string) ([]pdfBlock, error) {
	data, err := os.ReadFile(utf32Path)
	if err != nil {
		return nil, err
	}

	seen := map[string]bool{}
	var blocks []pdfBlock

	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if !strings.HasPrefix(line, "https://") {
			continue
		}
		url := strings.Fields(line)[0]
		if seen[url] {
			continue
		}
		seen[url] = true

		// Unicode-18.0 delta charts: chỉ có chars mới, vẫn parse được
		m := rePDFBlock.FindStringSubmatch(url)
		if m == nil {
			continue
		}
		base64, _ := strconv.ParseUint(m[1], 16, 32)
		base := uint32(base64)

		pri, ok := blockPriorityMap[base]
		if !ok {
			pri = 200
		}

		blocks = append(blocks, pdfBlock{url: url, base: base, priority: pri})
	}
	return blocks, nil
}

// ─── Download + cache ─────────────────────────────────────────────────────────

func fetchPDFCached(url, cacheDir string) (string, error) {
	fname := filepath.Base(url)
	cached := filepath.Join(cacheDir, fname)

	if fi, err := os.Stat(cached); err == nil && fi.Size() > 2000 {
		return cached, nil // cache hit
	}

	client := &http.Client{Timeout: 60 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return "", fmt.Errorf("HTTP %d for %s", resp.StatusCode, url)
	}

	pdfData, err := io.ReadAll(io.LimitReader(resp.Body, 12*1024*1024))
	if err != nil {
		return "", err
	}
	if len(pdfData) < 1000 {
		return "", fmt.Errorf("PDF too small (%d B)", len(pdfData))
	}

	if err := os.WriteFile(cached, pdfData, 0644); err != nil {
		return "", err
	}
	return cached, nil
}

// ─── Run Python glyph skill ───────────────────────────────────────────────────

type pdfGlyphResult struct {
	CP       uint32  `json:"cp"`
	Name     string  `json:"name"`
	Scale    float32 `json:"scale"`
	Capsules []struct {
		Ax float32 `json:"ax"`
		Ay float32 `json:"ay"`
		Az float32 `json:"az"`
		Bx float32 `json:"bx"`
		By float32 `json:"by"`
		Bz float32 `json:"bz"`
		R  float32 `json:"r"`
	} `json:"capsules"`
}

// runPDFGlyphSkill — scan tất cả pages từ 2 đến maxPage
// trả về tất cả glyphs từ tất cả pages (dedup by CP)
func runPDFGlyphSkill(ctx context.Context, pdfPath, sourceURL, skillPath string, dpi, maxCaps int) ([]pdfGlyphResult, error) {
	// Đếm pages
	nPages := countPDFPages(pdfPath)
	if nPages < 2 { nPages = 2 }
	if nPages > 60 { nPages = 60 } // safety cap

	seen := map[uint32]bool{}
	var all []pdfGlyphResult

	for page := 2; page <= nPages; page++ {
		cmd := exec.CommandContext(ctx, "python3", skillPath,
			pdfPath,
			"--page", strconv.Itoa(page),
			"--dpi", strconv.Itoa(dpi),
			"--max-caps", strconv.Itoa(maxCaps),
			"--source-url", sourceURL,
		)
		out, err := cmd.Output()
		if err != nil || len(out) == 0 { continue }

		var results []pdfGlyphResult
		if json.Unmarshal(out, &results) != nil { continue }
		if len(results) == 0 { break } // empty page = done

		for _, r := range results {
			if !seen[r.CP] {
				seen[r.CP] = true
				all = append(all, r)
			}
		}
	}

	if len(all) == 0 {
		return nil, fmt.Errorf("no glyphs found in %d pages", nPages)
	}
	return all, nil
}

// countPDFPages dung pdfinfo
func countPDFPages(pdfPath string) int {
	out, err := exec.Command("pdfinfo", pdfPath).Output()
	if err != nil { return 2 }
	for _, line := range strings.Split(string(out), "\n") {
		if strings.HasPrefix(line, "Pages:") {
			parts := strings.Fields(line)
			if len(parts) >= 2 {
				n, _ := strconv.Atoi(parts[1])
				return n
			}
		}
	}
	return 2
}

// ─── Patch glyphs vào olang ───────────────────────────────────────────────────

// patchGlyphBatch — đọc olang, in-place patch tất cả glyphs có thể,
// còn lại dùng growNodeDNA.
func patchGlyphBatch(olangPath string, glyphs []pdfGlyphResult) (patched, skipped, failed int) {
	if len(glyphs) == 0 {
		return
	}

	raw, err := os.ReadFile(olangPath)
	if err != nil {
		return 0, 0, len(glyphs)
	}

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 {
		edgeStart = 280
	}

	// Build cp → {nodePos, dnaLen} map
	type nodeInfo struct{ pos, dl int }
	cpMap := map[uint32]nodeInfo{}
	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' {
			pos++
			continue
		}
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 {
			pos++
			continue
		}
		end := pos + 20 + dl + nl
		if end > edgeStart {
			break
		}
		if layer == 0x01 {
			cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
			cpMap[cp] = nodeInfo{pos, dl}
		}
		pos = end
	}

	// In-place patches
	modified := false
	type growReq struct {
		cp  uint32
		dna []byte
	}
	var growQueue []growReq

	for _, g := range glyphs {
		if len(g.Capsules) == 0 {
			failed++
			continue
		}

		// Validate & clamp capsules
		caps := make([]capItem, 0, len(g.Capsules))
		for _, c := range g.Capsules {
			ax := clamp(c.Ax, -0.55, 0.55)
			ay := clamp(c.Ay, -0.55, 0.55)
			bx := clamp(c.Bx, -0.55, 0.55)
			by := clamp(c.By, -0.55, 0.55)
			r := clamp(c.R, 0.02, 0.12)
			dx := ax - bx
			dy := ay - by
			if dx*dx+dy*dy < 0.0004 { // degenerate stub
				continue
			}
			caps = append(caps, capItem{
				Ax: float64(ax), Ay: float64(ay), Az: 0,
				Bx: float64(bx), By: float64(by), Bz: 0,
				R:  float64(r),
			})
		}
		if len(caps) == 0 {
			failed++
			continue
		}

		sc := g.Scale
		if sc <= 0 || sc > 2.0 {
			sc = 0.8
		}
		newDNA := encodeSDFDNA(sc, caps)
		if len(newDNA) == 0 {
			failed++
			continue
		}

		info, ok := cpMap[g.CP]
		if !ok {
			failed++ // node không tồn tại trong olang
			continue
		}

		// Đã có SDF thật?
		dna := raw[info.pos+20 : info.pos+20+info.dl]
		if info.dl >= 30 && len(dna) > 0 && dna[0] == 0x42 {
			skipped++
			continue
		}

		if len(newDNA) <= info.dl {
			if patchDNAInPlace(raw, info.pos, info.dl, newDNA) {
				modified = true
				patched++
			} else {
				failed++
			}
		} else {
			cp := g.CP
			dnaClone := make([]byte, len(newDNA))
			copy(dnaClone, newDNA)
			growQueue = append(growQueue, growReq{cp, dnaClone})
		}
	}

	// Flush in-place patches
	if modified {
		tmp := olangPath + ".pdftmp"
		if err := os.WriteFile(tmp, raw, 0644); err == nil {
			os.Rename(tmp, olangPath)
		}
	}

	// Grow queue — dung growNodeDNABulk (1 lan doc+ghi)
	if len(growQueue) > 0 {
		bulkMap := make(map[uint32][]byte, len(growQueue))
		for _, req := range growQueue {
			bulkMap[req.cp] = req.dna
		}
		bp, _, bf := growNodeDNABulk(olangPath, bulkMap)
		patched += bp
		failed  += bf
	}
	return
}

// ─── Checkpoint ──────────────────────────────────────────────────────────────

func loadPDFSeedCkpt(path string) map[string]bool {
	done := map[string]bool{}
	data, err := os.ReadFile(path)
	if err != nil {
		return done
	}
	for _, l := range strings.Split(string(data), "\n") {
		l = strings.TrimSpace(l)
		if l != "" {
			done[l] = true
		}
	}
	return done
}

func savePDFSeedCkpt(path string, done map[string]bool) {
	lines := make([]string, 0, len(done))
	for u := range done {
		lines = append(lines, u)
	}
	sort.Strings(lines)
	os.WriteFile(path, []byte(strings.Join(lines, "\n")+"\n"), 0644)
}

// ─── Main entry ──────────────────────────────────────────────────────────────

func RunPDFSeed(ctx context.Context, cfg PDFSeedConfig) (*PDFSeedResult, error) {
	t0 := time.Now()
	res := &PDFSeedResult{}

	if cfg.SkillPath == "" {
		return nil, fmt.Errorf("skill_glyph_to_sdf.py not found — set OLANG_HOME or run from project root")
	}
	if err := os.MkdirAll(cfg.CacheDir, 0755); err != nil {
		return nil, err
	}

	blocks, err := parsePDFBlocks(cfg.UTF32TxtPath)
	if err != nil {
		return nil, fmt.Errorf("parse utf32.txt: %w", err)
	}
	fmt.Printf("📋 utf32.txt: %d PDF blocks\n", len(blocks))

	// Optional block filter
	if len(cfg.BlockFilter) > 0 {
		fs := map[uint32]bool{}
		for _, b := range cfg.BlockFilter {
			fs[b] = true
		}
		var tmp []pdfBlock
		for _, b := range blocks {
			if fs[b.base] {
				tmp = append(tmp, b)
			}
		}
		blocks = tmp
		fmt.Printf("   Filter applied: %d blocks\n", len(blocks))
	}

	sort.Slice(blocks, func(i, j int) bool {
		return blocks[i].priority < blocks[j].priority
	})

	done := loadPDFSeedCkpt(cfg.CheckpointPath)
	if len(done) > 0 {
		fmt.Printf("♻️  Resume: %d blocks đã xong\n", len(done))
	}

	errStreak := 0

	for i, blk := range blocks {
		select {
		case <-ctx.Done():
			fmt.Println("\n⏸  Interrupted — checkpoint saved")
			res.Duration = time.Since(t0)
			return res, ctx.Err()
		default:
		}

		if done[blk.url] {
			continue
		}

		pdfPath, ferr := fetchPDFCached(blk.url, cfg.CacheDir)
		if ferr != nil {
			if cfg.Verbose {
				fmt.Printf("\n  ❌ download %s: %v\n", filepath.Base(blk.url), ferr)
			}
			errStreak++
			if errStreak >= cfg.MaxErrors {
				return res, fmt.Errorf("too many consecutive errors (%d)", errStreak)
			}
			continue
		}

		glyphs, gerr := runPDFGlyphSkill(ctx, pdfPath, blk.url, cfg.SkillPath, cfg.DPI, cfg.MaxCaps)
		if gerr != nil {
			if cfg.Verbose {
				fmt.Printf("\n  ❌ skill %s: %v\n", filepath.Base(pdfPath), gerr)
			}
			errStreak++
			if errStreak >= cfg.MaxErrors {
				return res, fmt.Errorf("too many consecutive errors (%d)", errStreak)
			}
			continue
		}
		errStreak = 0

		res.PDFs++
		res.Glyphs += len(glyphs)

		p, s, f := patchGlyphBatch(cfg.OlangPath, glyphs)
		res.Patched += p
		res.Skipped += s
		res.Failed += f

		done[blk.url] = true

		// Checkpoint + SHA256 mỗi PDF
		if true {
			savePDFSeedCkpt(cfg.CheckpointPath, done)
			recomputeSHA256(cfg.OlangPath)
		}

		pct := float64(i+1) / float64(len(blocks)) * 100
		fmt.Printf("\r  [%5.1f%%] pdf=%4d glyphs=%6d patched=%6d  %-28s",
			pct, res.PDFs, res.Glyphs, res.Patched,
			filepath.Base(pdfPath))

		time.Sleep(120 * time.Millisecond)
	}

	fmt.Println()
	savePDFSeedCkpt(cfg.CheckpointPath, done)
	recomputeSHA256(cfg.OlangPath)
	res.Duration = time.Since(t0)
	return res, nil
}
