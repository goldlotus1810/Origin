// internal/utf32/cangjie_sdf.go
//
// CangjieSDFBridge — gen vSDF cho CJK chars từ Cangjie decomposition.
//
// Cangjie input method: mỗi CJK char = chuỗi 1-5 shape keys (A-Z)
// 24 basic shapes → 24 SDF primitives → compose thành SDF của char
//
// Pipeline:
//   Unihan_DictionaryLikeData.txt → kCangjie field
//       → parse shape sequence (e.g. "日月" = AB)
//       → lookup capsule set cho mỗi shape
//       → compose: spatial layout theo vị trí trong sequence
//       → encodeSDFDNA → patch node
//
// Coverage: ~29,189 CJK chars có kCangjie data

package utf32

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
	"time"
)

// ─── 24 Cangjie shape primitives → capsule definitions ───────────────────────
//
// Coordinate system: x∈[-0.5,0.5] y∈[-0.5,0.5] center=(0,0)
// Tham chiếu: mỗi shape được định nghĩa trong bounding box [-0.45, 0.45]
// Khi compose: scale xuống + translate theo layout

type cangjieShape struct {
	name    string   // tên shape
	radical string   // radical tương ứng
	caps    []capItem // capsules trong [-0.45, 0.45] normalized
}

// 24 Cangjie shapes — hand-crafted capsules
// Mỗi shape = 2-5 capsules đặc trưng
var cangjieShapes = map[byte]cangjieShape{
	// A = 日 (sun/rectangle) — 4 strokes: top, bottom, left, right
	'A': {"sun_rect", "日", []capItem{
		{Ax: -0.35, Ay: 0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.05},  // top
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: -0.35, Bz: 0, R: 0.05}, // bottom
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: -0.35, By: 0.35, Bz: 0, R: 0.05}, // left
		{Ax: 0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.05},  // right
		{Ax: -0.35, Ay: 0.0, Az: 0, Bx: 0.35, By: 0.0, Bz: 0, R: 0.04},    // middle
	}},
	// B = 月 (moon/crescent) — arc + vertical
	'B': {"moon_crescent", "月", []capItem{
		{Ax: -0.3, Ay: 0.35, Az: 0, Bx: 0.1, By: 0.35, Bz: 0, R: 0.05},   // top
		{Ax: -0.3, Ay: -0.35, Az: 0, Bx: 0.1, By: -0.35, Bz: 0, R: 0.05}, // bottom
		{Ax: -0.3, Ay: -0.35, Az: 0, Bx: -0.3, By: 0.35, Bz: 0, R: 0.05}, // left
		{Ax: 0.1, Ay: 0.1, Az: 0, Bx: 0.3, By: -0.1, Bz: 0, R: 0.06},     // right arc
		{Ax: -0.3, Ay: 0.05, Az: 0, Bx: 0.1, By: 0.05, Bz: 0, R: 0.04},   // mid stroke
	}},
	// C = 金 (metal/diamond) — diamond shape
	'C': {"metal_diamond", "金", []capItem{
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: 0.3, By: 0.0, Bz: 0, R: 0.05},   // top-right
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: -0.3, By: 0.0, Bz: 0, R: 0.05},  // top-left
		{Ax: 0.3, Ay: 0.0, Az: 0, Bx: 0.0, By: -0.35, Bz: 0, R: 0.05}, // right-bottom
		{Ax: -0.3, Ay: 0.0, Az: 0, Bx: 0.0, By: -0.35, Bz: 0, R: 0.05},// left-bottom
		{Ax: -0.3, Ay: -0.1, Az: 0, Bx: 0.3, By: -0.1, Bz: 0, R: 0.04},// cross bar
	}},
	// D = 木 (tree/cross) — vertical + horizontal + two descenders
	'D': {"tree_cross", "木", []capItem{
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: 0.0, By: -0.4, Bz: 0, R: 0.05},   // vertical
		{Ax: -0.35, Ay: 0.1, Az: 0, Bx: 0.35, By: 0.1, Bz: 0, R: 0.05}, // horizontal
		{Ax: 0.0, Ay: -0.1, Az: 0, Bx: -0.3, By: -0.4, Bz: 0, R: 0.04}, // left-down
		{Ax: 0.0, Ay: -0.1, Az: 0, Bx: 0.3, By: -0.4, Bz: 0, R: 0.04},  // right-down
	}},
	// E = 水 (water/3 drops on left)
	'E': {"water_drops", "水", []capItem{
		{Ax: 0.1, Ay: 0.35, Az: 0, Bx: 0.1, By: -0.35, Bz: 0, R: 0.05},  // main vertical
		{Ax: 0.1, Ay: 0.1, Az: 0, Bx: -0.1, By: 0.3, Bz: 0, R: 0.04},    // top-left
		{Ax: 0.1, Ay: -0.05, Az: 0, Bx: -0.25, By: 0.1, Bz: 0, R: 0.04}, // mid-left
		{Ax: 0.1, Ay: -0.2, Az: 0, Bx: -0.1, By: -0.35, Bz: 0, R: 0.04}, // bot-left
	}},
	// F = 火 (fire/two diagonal strokes)
	'F': {"fire_diag", "火", []capItem{
		{Ax: -0.2, Ay: 0.3, Az: 0, Bx: 0.0, By: -0.4, Bz: 0, R: 0.05},  // left stroke
		{Ax: 0.2, Ay: 0.3, Az: 0, Bx: 0.0, By: -0.4, Bz: 0, R: 0.05},   // right stroke
		{Ax: -0.35, Ay: -0.1, Az: 0, Bx: 0.0, By: 0.2, Bz: 0, R: 0.04}, // left wing
		{Ax: 0.35, Ay: -0.1, Az: 0, Bx: 0.0, By: 0.2, Bz: 0, R: 0.04},  // right wing
	}},
	// G = 土 (earth/T-shape) — horizontal + vertical + bottom
	'G': {"earth_T", "土", []capItem{
		{Ax: -0.35, Ay: 0.25, Az: 0, Bx: 0.35, By: 0.25, Bz: 0, R: 0.05},  // top horiz
		{Ax: 0.0, Ay: 0.25, Az: 0, Bx: 0.0, By: -0.2, Bz: 0, R: 0.05},     // vertical
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: -0.35, Bz: 0, R: 0.05},// bottom horiz
	}},
	// H = 竹 (bamboo/two up-strokes)
	'H': {"bamboo_up", "竹", []capItem{
		{Ax: -0.25, Ay: -0.1, Az: 0, Bx: -0.15, By: 0.4, Bz: 0, R: 0.05}, // left stalk
		{Ax: 0.15, Ay: -0.1, Az: 0, Bx: 0.25, By: 0.4, Bz: 0, R: 0.05},   // right stalk
		{Ax: -0.35, Ay: 0.1, Az: 0, Bx: -0.15, By: 0.1, Bz: 0, R: 0.04},  // left leaf
		{Ax: 0.15, Ay: 0.25, Az: 0, Bx: 0.4, By: 0.25, Bz: 0, R: 0.04},   // right leaf
	}},
	// I = 戈 (weapon/diagonal spear)
	'I': {"weapon_spear", "戈", []capItem{
		{Ax: -0.1, Ay: 0.4, Az: 0, Bx: 0.35, By: -0.1, Bz: 0, R: 0.05},  // main diagonal
		{Ax: 0.35, Ay: -0.1, Az: 0, Bx: 0.2, By: -0.4, Bz: 0, R: 0.05},  // hook down
		{Ax: -0.1, Ay: 0.4, Az: 0, Bx: -0.35, By: 0.1, Bz: 0, R: 0.04},  // cross bar
		{Ax: -0.05, Ay: -0.05, Az: 0, Bx: -0.3, By: -0.35, Bz: 0, R: 0.04},// left down
	}},
	// J = 十 (ten/plus cross)
	'J': {"ten_plus", "十", []capItem{
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: 0.0, By: -0.4, Bz: 0, R: 0.06},   // vertical
		{Ax: -0.4, Ay: 0.1, Az: 0, Bx: 0.4, By: 0.1, Bz: 0, R: 0.06},   // horizontal
	}},
	// K = 大 (big/spread-arms)
	'K': {"big_spread", "大", []capItem{
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: 0.0, By: -0.15, Bz: 0, R: 0.05},   // head
		{Ax: -0.4, Ay: 0.1, Az: 0, Bx: 0.4, By: 0.1, Bz: 0, R: 0.05},    // arms
		{Ax: 0.0, Ay: -0.15, Az: 0, Bx: -0.3, By: -0.4, Bz: 0, R: 0.04}, // left leg
		{Ax: 0.0, Ay: -0.15, Az: 0, Bx: 0.3, By: -0.4, Bz: 0, R: 0.04},  // right leg
	}},
	// L = 中 (middle/vertical through box)
	'L': {"middle_vert", "中", []capItem{
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: 0.0, By: -0.4, Bz: 0, R: 0.06},   // center line
		{Ax: -0.3, Ay: 0.2, Az: 0, Bx: 0.3, By: 0.2, Bz: 0, R: 0.04},   // top box
		{Ax: -0.3, Ay: -0.2, Az: 0, Bx: 0.3, By: -0.2, Bz: 0, R: 0.04}, // bot box
		{Ax: -0.3, Ay: -0.2, Az: 0, Bx: -0.3, By: 0.2, Bz: 0, R: 0.04}, // left box
		{Ax: 0.3, Ay: -0.2, Az: 0, Bx: 0.3, By: 0.2, Bz: 0, R: 0.04},   // right box
	}},
	// M = 一 (one/horizontal stroke)
	'M': {"one_horiz", "一", []capItem{
		{Ax: -0.45, Ay: 0.0, Az: 0, Bx: 0.45, By: 0.0, Bz: 0, R: 0.07},
	}},
	// N = 弓 (bow/curved)
	'N': {"bow_curve", "弓", []capItem{
		{Ax: 0.15, Ay: 0.4, Az: 0, Bx: -0.15, By: 0.15, Bz: 0, R: 0.05},  // top
		{Ax: -0.15, Ay: 0.15, Az: 0, Bx: 0.1, By: 0.0, Bz: 0, R: 0.04},   // mid-right
		{Ax: 0.1, Ay: 0.0, Az: 0, Bx: -0.15, By: -0.2, Bz: 0, R: 0.05},   // mid-left
		{Ax: -0.15, Ay: -0.2, Az: 0, Bx: 0.15, By: -0.4, Bz: 0, R: 0.04}, // bottom
	}},
	// O = 人 (person/two diagonal legs)
	'O': {"person_legs", "人", []capItem{
		{Ax: 0.0, Ay: 0.35, Az: 0, Bx: -0.3, By: -0.4, Bz: 0, R: 0.06},  // left leg
		{Ax: 0.0, Ay: 0.35, Az: 0, Bx: 0.35, By: -0.25, Bz: 0, R: 0.06}, // right leg
	}},
	// P = 心 (heart/three dots + curve)
	'P': {"heart_dots", "心", []capItem{
		{Ax: -0.3, Ay: 0.0, Az: 0, Bx: 0.3, By: -0.1, Bz: 0, R: 0.06},   // main curve
		{Ax: -0.3, Ay: 0.2, Az: 0, Bx: -0.2, By: 0.3, Bz: 0, R: 0.05},   // left dot
		{Ax: 0.0, Ay: 0.3, Az: 0, Bx: 0.05, By: 0.4, Bz: 0, R: 0.05},    // mid dot
		{Ax: 0.3, Ay: 0.1, Az: 0, Bx: 0.4, By: 0.2, Bz: 0, R: 0.05},     // right dot
	}},
	// Q = 手 (hand/horizontal strokes)
	'Q': {"hand_strokes", "手", []capItem{
		{Ax: -0.35, Ay: 0.3, Az: 0, Bx: 0.35, By: 0.3, Bz: 0, R: 0.05},  // top stroke
		{Ax: -0.35, Ay: 0.0, Az: 0, Bx: 0.35, By: 0.0, Bz: 0, R: 0.05},  // mid stroke
		{Ax: -0.35, Ay: -0.2, Az: 0, Bx: 0.35, By: -0.2, Bz: 0, R: 0.05},// bot stroke
		{Ax: 0.1, Ay: 0.3, Az: 0, Bx: 0.0, By: -0.4, Bz: 0, R: 0.04},    // vertical
	}},
	// R = 口 (mouth/square)
	'R': {"mouth_box", "口", []capItem{
		{Ax: -0.35, Ay: 0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.06},  // top
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: -0.35, Bz: 0, R: 0.06},// bottom
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: -0.35, By: 0.35, Bz: 0, R: 0.06},// left
		{Ax: 0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.06}, // right
	}},
	// S = 尸 (corpse/hook shape)
	'S': {"hook_shape", "尸", []capItem{
		{Ax: -0.2, Ay: 0.4, Az: 0, Bx: 0.35, By: 0.4, Bz: 0, R: 0.05},    // top horiz
		{Ax: -0.2, Ay: 0.4, Az: 0, Bx: -0.2, By: -0.3, Bz: 0, R: 0.05},   // left vert
		{Ax: -0.2, Ay: -0.3, Az: 0, Bx: 0.35, By: -0.3, Bz: 0, R: 0.04},  // mid horiz
	}},
	// T = 廿 (twenty/H with top bar)
	'T': {"twenty_H", "廿", []capItem{
		{Ax: -0.4, Ay: 0.35, Az: 0, Bx: 0.4, By: 0.35, Bz: 0, R: 0.05},   // top bar
		{Ax: -0.3, Ay: 0.35, Az: 0, Bx: -0.3, By: -0.35, Bz: 0, R: 0.05}, // left vert
		{Ax: 0.3, Ay: 0.35, Az: 0, Bx: 0.3, By: -0.35, Bz: 0, R: 0.05},   // right vert
		{Ax: -0.3, Ay: 0.0, Az: 0, Bx: 0.3, By: 0.0, Bz: 0, R: 0.04},     // mid bar
	}},
	// U = 山 (mountain/three peaks)
	'U': {"mountain_3", "山", []capItem{
		{Ax: 0.0, Ay: -0.2, Az: 0, Bx: 0.0, By: 0.4, Bz: 0, R: 0.06},    // center peak
		{Ax: -0.35, Ay: -0.2, Az: 0, Bx: -0.35, By: 0.15, Bz: 0, R: 0.05},// left peak
		{Ax: 0.35, Ay: -0.2, Az: 0, Bx: 0.35, By: 0.15, Bz: 0, R: 0.05}, // right peak
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: -0.35, Bz: 0, R: 0.05},// base
	}},
	// V = 女 (woman/X-like with curve)
	'V': {"woman_X", "女", []capItem{
		{Ax: -0.35, Ay: 0.35, Az: 0, Bx: 0.35, By: -0.1, Bz: 0, R: 0.05},  // top-left diagonal
		{Ax: -0.1, Ay: 0.0, Az: 0, Bx: 0.3, By: 0.35, Bz: 0, R: 0.04},     // top-right
		{Ax: -0.4, Ay: -0.3, Az: 0, Bx: 0.4, By: -0.35, Bz: 0, R: 0.05},   // bottom horiz
	}},
	// W = 田 (field/grid)
	'W': {"field_grid", "田", []capItem{
		{Ax: -0.35, Ay: 0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.05},  // top
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: -0.35, Bz: 0, R: 0.05},// bottom
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: -0.35, By: 0.35, Bz: 0, R: 0.05},// left
		{Ax: 0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.05}, // right
		{Ax: 0.0, Ay: -0.35, Az: 0, Bx: 0.0, By: 0.35, Bz: 0, R: 0.04},   // vertical
		{Ax: -0.35, Ay: 0.0, Az: 0, Bx: 0.35, By: 0.0, Bz: 0, R: 0.04},   // horizontal
	}},
	// X = 難 (difficult/complex squiggle — simplified)
	'X': {"hard_complex", "難", []capItem{
		{Ax: -0.2, Ay: 0.35, Az: 0, Bx: 0.2, By: 0.15, Bz: 0, R: 0.05},
		{Ax: 0.2, Ay: 0.15, Az: 0, Bx: -0.2, By: -0.05, Bz: 0, R: 0.05},
		{Ax: -0.2, Ay: -0.05, Az: 0, Bx: 0.2, By: -0.25, Bz: 0, R: 0.05},
		{Ax: 0.2, Ay: -0.25, Az: 0, Bx: -0.2, By: -0.4, Bz: 0, R: 0.05},
	}},
	// Y = 卜 (divination/L-shape)
	'Y': {"divination_L", "卜", []capItem{
		{Ax: 0.0, Ay: 0.4, Az: 0, Bx: 0.0, By: -0.35, Bz: 0, R: 0.06},   // vertical
		{Ax: 0.0, Ay: -0.1, Az: 0, Bx: 0.3, By: -0.35, Bz: 0, R: 0.05},  // right stroke
	}},
	// Z = 重 (heavy/stacked) — simplified
	'Z': {"heavy_stack", "重", []capItem{
		{Ax: -0.35, Ay: 0.35, Az: 0, Bx: 0.35, By: 0.35, Bz: 0, R: 0.05},
		{Ax: -0.35, Ay: 0.1, Az: 0, Bx: 0.35, By: 0.1, Bz: 0, R: 0.05},
		{Ax: -0.35, Ay: -0.15, Az: 0, Bx: 0.35, By: -0.15, Bz: 0, R: 0.05},
		{Ax: 0.0, Ay: 0.35, Az: 0, Bx: 0.0, By: -0.35, Bz: 0, R: 0.04},
		{Ax: -0.35, Ay: -0.35, Az: 0, Bx: 0.35, By: -0.35, Bz: 0, R: 0.05},
	}},
}

// ─── Spatial layout cho composite glyphs ─────────────────────────────────────
//
// Khi 1 char có nhiều shapes (e.g. 明=AB → 日+月), cần layout chúng cạnh nhau.
// Layout strategy: chia bounding box theo số shapes, xếp trái-phải

type layoutRegion struct {
	cx, cy float64 // center
	scale  float64 // scale factor
}

func computeLayout(nShapes int, idx int) layoutRegion {
	switch nShapes {
	case 1:
		return layoutRegion{0, 0, 0.9}
	case 2:
		// Left-right split
		if idx == 0 {
			return layoutRegion{-0.22, 0, 0.55}
		}
		return layoutRegion{0.22, 0, 0.55}
	case 3:
		// Left | Middle | Right
		switch idx {
		case 0: return layoutRegion{-0.3, 0, 0.42}
		case 1: return layoutRegion{0.0, 0, 0.42}
		default: return layoutRegion{0.3, 0, 0.42}
		}
	case 4:
		// 2x2 grid
		row := idx / 2
		col := idx % 2
		x := -0.2 + float64(col)*0.4
		y := 0.2 - float64(row)*0.4
		return layoutRegion{x, y, 0.45}
	default:
		// 5+ shapes: compact 2-3 layout
		if idx < 2 {
			x := -0.25 + float64(idx)*0.5
			return layoutRegion{x, 0.18, 0.38}
		}
		// Bottom row
		n := nShapes - 2
		xi := idx - 2
		x := -0.2*(float64(n-1)) + float64(xi)*0.4
		if n == 1 { x = 0 }
		return layoutRegion{x, -0.2, 0.38}
	}
}

// transformCaps — apply layout region to capsule set
func transformCaps(caps []capItem, region layoutRegion) []capItem {
	result := make([]capItem, len(caps))
	for i, c := range caps {
		result[i] = capItem{
			Ax: c.Ax*region.scale + region.cx,
			Ay: c.Ay*region.scale + region.cy,
			Az: 0,
			Bx: c.Bx*region.scale + region.cx,
			By: c.By*region.scale + region.cy,
			Bz: 0,
			R:  math.Max(0.02, c.R*region.scale*0.8),
		}
	}
	return result
}

// ─── Compose Cangjie sequence → capsules ─────────────────────────────────────

func cangjieCompose(seq string, maxCaps int) []capItem {
	var allCaps []capItem
	shapes := []byte(seq)
	nShapes := len(shapes)
	if nShapes == 0 { return nil }

	for i, ch := range shapes {
		sh, ok := cangjieShapes[ch]
		if !ok { continue }
		region := computeLayout(nShapes, i)
		transformed := transformCaps(sh.caps, region)
		allCaps = append(allCaps, transformed...)
	}

	// Clamp + limit
	var result []capItem
	for _, c := range allCaps {
		c.Ax = float64(clamp(float32(c.Ax), -0.5, 0.5))
		c.Ay = float64(clamp(float32(c.Ay), -0.5, 0.5))
		c.Bx = float64(clamp(float32(c.Bx), -0.5, 0.5))
		c.By = float64(clamp(float32(c.By), -0.5, 0.5))
		c.R  = float64(clamp(float32(c.R), 0.02, 0.1))
		result = append(result, c)
		if len(result) >= maxCaps { break }
	}
	return result
}

// ─── Parse kCangjie từ Unihan file ───────────────────────────────────────────

type CangjieEntry struct {
	CP  uint32
	Seq string // e.g. "AB", "HMR"
}

func LoadCangjieData(unihanDictPath string) (map[uint32]string, error) {
	f, err := os.Open(unihanDictPath)
	if err != nil { return nil, err }
	defer f.Close()

	result := make(map[uint32]string, 30000)
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := scanner.Text()
		if len(line) == 0 || line[0] == '#' { continue }

		parts := strings.Fields(line)
		if len(parts) < 3 { continue }
		if parts[1] != "kCangjie" { continue }

		cpStr := strings.TrimPrefix(parts[0], "U+")
		cp, err := strconv.ParseUint(cpStr, 16, 32)
		if err != nil { continue }

		seq := strings.ToUpper(parts[2])
		// Validate: only A-Z
		valid := true
		for _, c := range seq {
			if c < 'A' || c > 'Z' { valid = false; break }
		}
		if !valid { continue }

		result[uint32(cp)] = seq
	}
	return result, scanner.Err()
}

// ─── Cangjie SDF seed ─────────────────────────────────────────────────────────

type CangjieResult struct {
	Processed int
	Patched   int
	Skipped   int // đã có SDF thật
	Failed    int
	Duration  time.Duration
}

func (r *CangjieResult) String() string {
	return fmt.Sprintf("cangjie-sdf: processed=%d patched=%d skipped=%d failed=%d time=%.0fs",
		r.Processed, r.Patched, r.Skipped, r.Failed, r.Duration.Seconds())
}

func RunCangjieSDFSeed(olangPath, unihanDictPath string, maxCaps int) (*CangjieResult, error) {
	t0 := time.Now()
	res := &CangjieResult{}

	cangjieMap, err := LoadCangjieData(unihanDictPath)
	if err != nil { return nil, fmt.Errorf("load cangjie: %w", err) }
	fmt.Printf("📖 Cangjie data: %d entries\n", len(cangjieMap))

	// Build glyphs list dùng pdfGlyphResult (shared type với pdf_sdf_engine.go)
	var glyphs []pdfGlyphResult
	for cp, seq := range cangjieMap {
		caps := cangjieCompose(seq, maxCaps)
		if len(caps) == 0 { continue }
		capItems := make([]struct {
			Ax float32 `json:"ax"`; Ay float32 `json:"ay"`; Az float32 `json:"az"`
			Bx float32 `json:"bx"`; By float32 `json:"by"`; Bz float32 `json:"bz"`
			R  float32 `json:"r"`
		}, len(caps))
		for i, c := range caps {
			capItems[i].Ax = float32(c.Ax); capItems[i].Ay = float32(c.Ay)
			capItems[i].Bx = float32(c.Bx); capItems[i].By = float32(c.By)
			capItems[i].R  = float32(c.R)
		}
		glyphs = append(glyphs, pdfGlyphResult{
			CP:       cp,
			Name:     fmt.Sprintf("CANGJIE_%s", seq),
			Scale:    0.85,
			Capsules: capItems,
		})
	}

	res.Processed = len(glyphs)
	fmt.Printf("🔢 Composing %d Cangjie glyphs...\n", len(glyphs))

	// Pass 1: in-place patch (DNA fits trong slot cu)
	p1, s1, _ := patchGlyphBatch(olangPath, glyphs)
	res.Patched += p1
	res.Skipped += s1
	fmt.Printf("  pass1 (in-place): patched=%d skipped=%d\n", p1, s1)

	// Pass 2: bulk grow cho chars can expand (doc+ghi file 1 lan)
	cpDNA := map[uint32][]byte{}
	for _, g := range glyphs {
		caps := make([]capItem, len(g.Capsules))
		for i, c := range g.Capsules {
			caps[i] = capItem{
				Ax: float64(c.Ax), Ay: float64(c.Ay),
				Bx: float64(c.Bx), By: float64(c.By),
				R:  float64(c.R),
			}
		}
		dna := encodeSDFDNA(g.Scale, caps)
		if len(dna) > 0 {
			cpDNA[g.CP] = dna
		}
	}
	p2, s2, f2 := growNodeDNABulk(olangPath, cpDNA)
	res.Patched += p2
	res.Skipped += s2
	res.Failed  += f2
	fmt.Printf("  pass2 (bulk grow): patched=%d skipped=%d failed=%d\n", p2, s2, f2)

	recomputeSHA256(olangPath)
	res.Duration = time.Since(t0)
	return res, nil
}
