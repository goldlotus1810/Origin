// internal/utf32/migrate_dna.go
//
// MigrateDNAHeaders — patch tất cả nodes trong .olang file
// thêm b[0]=STATE|TYPE header nếu chưa có.
//
// NODE_Spec: b[0] = STATE(2bit) | TYPE(6bit)
//   STATE: DN=0x00  QR=0x40  BLOWN=0x80
//   TYPE:  RAW=0x00 ATOM=0x01 SDF=0x02 FORK=0x03 COMPOSE=0x04 BOND=0x05
//
// Logic nhận dạng DNA cũ (chưa có header):
//   b[0]==0x10 → OpUnion → vSDF với capsules → thêm 0x42 (QR|SDF)
//   b[0]==0x9A → scale header → vSDF với scale → thêm 0x42 (QR|SDF)
//   b[0]==0x01 && len==7 → metaDNA cũ → thêm 0x01 (DN|ATOM), shift nội dung
//     *** metaDNA cũ: [0x01 scriptID groupID cp:4B] = 7B
//     *** metaDNA mới: [0x01 scriptID groupID cp:4B] = 7B — b[0] ĐÃ LÀ 0x01=ATOM đúng rồi
//     *** NHƯNG b[0]=0x01=OpSphere trong executor cũ → bây giờ b[0]=TYPE=ATOM → đúng
//   b[0]==0x03 → dna3 cũ (L3=0x03) → thêm 0x42 (QR|SDF)
//   b[0]==0x42 → đã có header → skip
//   b[0]==0x01 && len>=5 → đã là ATOM header → skip (metaDNA mới)
//
// Sau migration: tất cả nodes có b[0]=STATE|TYPE đúng spec.

package utf32

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math"
	"os"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// buildAtomDNA — tạo ATOM DNA đúng NODE_Spec từ codepoint
// Layout: b[0]=QR|ATOM(0x41) b[1]=EMIT(0x14) b[2..5]=f32(cp) b[6]=scriptID b[7]=groupID b[8]=0
func buildAtomDNA(cp uint32, scriptID, groupID byte) []byte {
	dna := make([]byte, 9)
	dna[0] = 0x41 // QR|ATOM
	dna[1] = 0x14 // EMIT
	bits := math.Float32bits(float32(cp))
	dna[2] = byte(bits >> 24)
	dna[3] = byte(bits >> 16)
	dna[4] = byte(bits >> 8)
	dna[5] = byte(bits)
	dna[6] = scriptID
	dna[7] = groupID
	return dna
}

// isAtomNeedsRebuild — ATOM node đã có b[0]=0x41 nhưng val ở sai vị trí
// Nhận dạng: b[0]=0x41, b[1]!=0x14 (thiếu EMIT), len<9
func isAtomNeedsRebuild(dna []byte) bool {
	if len(dna) < 2 {
		return false
	}
	b0 := dna[0]
	isAtom := (b0 & 0xC0) <= 0x40 && (b0&0x3F) == 0x01 // STATE<=QR, TYPE=ATOM
	return isAtom && (len(dna) < 9 || dna[1] != 0x14)
}

// MigrateResult — kết quả migration
type MigrateResult struct {
	Total    int
	Patched  int
	Skipped  int
	Errors   int
}

// needsHeader — kiểm tra DNA có cần thêm b[0] header không
// Trả về (needsPatch bool, newHeader byte)
func needsHeader(dna []byte, layer uint8) (bool, byte) {
	if len(dna) == 0 {
		return false, 0
	}
	b0 := dna[0]

	// Đã có header đúng — STATE∈{0x00,0x40,0x80} && TYPE∈{0x00..0x06}
	state := b0 & 0xC0
	typ   := b0 & 0x3F
	if (state == 0x00 || state == 0x40 || state == 0x80) && typ <= 0x06 {
		if b0 == 0x42 { return false, 0 } // QR|SDF — đúng
		if b0 == 0x01 && len(dna) == 7  { return false, 0 } // DN|ATOM metaDNA
		if b0 == 0x00 && len(dna) != 8 { return false, 0 } // DN|RAW — chỉ skip nếu không phải old 8B placeholder
	if b0 == 0x00 && len(dna) == 8 { return true, 0x41 } // old 8B placeholder → rebuild ATOM
		if b0 == 0x06 { return false, 0 } // DN|TEXT
		if b0 == 0x46 { return false, 0 } // QR|TEXT
	}

	// vSDF không có header
	if b0 == 0x10 { return true, 0x42 } // OpUnion → QR|SDF
	if b0 == 0x9A { return true, 0x42 } // scale → QR|SDF

	// dna3 cũ — b[0]=0x03 (L3 byte), b[1]=qtNum (1-9), không phải TYPE
	if b0 == 0x03 && len(dna) >= 7 && layer == 3 {
		// Phân biệt với QRWriter: QRWriter có b[1]=0x51='Q'
		if len(dna) >= 2 && dna[1] == 0x51 {
			// QRWriter cũ: [0x03][0x51][ISL:8]... → prepend 0x42
			return true, 0x42
		}
		// dna3: [0x03][qtNum][cp:4][len][text] → prepend 0x42
		return true, 0x42
	}

	// metaDNA cũ len=10 (3 bytes thừa)
	if b0 == 0x01 && len(dna) == 10 { return true, 0x01 }

	// QRWriter cũ format: b[0]=0xD0 (old marker), len=10: [0xD0][conf:1B][ISL:8B]
	// 0xD0 = 0b11010000 → state=0xC0 invalid → prepend QR|SDF=0x42
	if b0 == 0xD0 && len(dna) >= 9 { return true, 0x42 }

	// L7 Program nodes: b[0]=0x20(FBM) hoặc b[0]=0x37(opcode>0x06)
	// Đây là binary DNA không phải STATE|TYPE → cần wrap QR|SDF
	if layer == 7 && b0 > 0x06 && !isTextDNA(dna) { return true, 0x42 }

	// L6 Perception: b[0]=0xA2 (opcode)
	if layer == 6 && b0 > 0x06 && !isTextDNA(dna) { return true, 0x42 }

	// L0 opcode definition nodes (layer==0, tên bắt đầu OP_)
	// DNA của chúng = chính opcode byte, cần wrap thành QR|RAW = 0x40
	// Nhận dạng: layer==0 && b[0] không phải STATE|TYPE hợp lệ
	// và b[0] là opcode L0 thực (0x01-0xFF range không phải text)
	if layer == 0 && !isTextDNA(dna) && b0 > 0x06 {
		return true, 0x40 // QR|RAW — L0 primitives luôn là QR (bất biến)
	}
	// Dấu hiệu: b[0] >= 0x20 (space) và không phải STATE|TYPE hợp lệ
	// "label=", "love:", "emotion:", "infl:", tên UTF-8 CJK/Korean...
	if isTextDNA(dna) {
		// L3 concept/word nodes = QR|TEXT nếu layer==3, DN|TEXT nếu khác
		if layer == 3 { return true, 0x46 } // QR|TEXT = 0x40|0x06
		return true, 0x06                   // DN|TEXT = 0x00|0x06
	}

	return false, 0
}

// isTextDNA — kiểm tra DNA có phải plain text không
// Text DNA = bytes không phải L0 opcode hợp lệ, có vẻ là UTF-8 printable
func isTextDNA(dna []byte) bool {
	if len(dna) == 0 { return false }
	b0 := dna[0]
	// L0 opcodes: 0x01-0x17, 0x20, 0x22, 0x40-0x46, 0x50-0x53, 0x60-0x64, 0xa4, 0xa5, 0xff
	// STATE|TYPE đã xử lý ở trên
	// Text thường bắt đầu bằng ASCII chữ cái: a-z, A-Z (0x41-0x7A)
	// hoặc UTF-8 multi-byte: 0x80-0xFF (CJK, Korean, Vietnamese)
	// Kiểm tra đơn giản: có chứa ':' hoặc '=' không?
	for _, c := range dna {
		if c == ':' || c == '=' || c == '|' { return true }
	}
	// Text UTF-8: b[0] trong range alpha và không phải opcode
	if b0 >= 'A' && b0 <= 'z' { return true }
	// Korean/CJK UTF-8: 0xEC, 0xEB, 0xEA, 0xE6, 0xE5, 0xE4, 0xE3...
	if b0 >= 0xE0 && b0 <= 0xFF { return true }
	return false
}

// MigrateDNAHeaders — đọc file, patch tất cả nodes, ghi lại
func MigrateDNAHeaders(olangPath string) (*MigrateResult, error) {
	raw, err := os.ReadFile(olangPath)
	if err != nil { return nil, err }
	if len(raw) < 280 || string(raw[0:4]) != "OLNG" {
		return nil, fmt.Errorf("MigrateDNA: bad file magic")
	}

	res := &MigrateResult{}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 { edgeStart = 280 }

	// Scan tất cả nodes, build new body
	var newBody []byte
	pos := 280

	for pos+20 < edgeStart {
		if raw[pos] != 'N' || raw[pos+1] != 'D' {
			newBody = append(newBody, raw[pos])
			pos++
			continue
		}

		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))
		nl := int(raw[pos+19])
		if dl < 0 || dl > 65536 || nl < 0 || nl > 255 {
			newBody = append(newBody, raw[pos])
			pos++
			res.Errors++
			continue
		}

		recEnd := pos + 20 + dl + nl
		if recEnd > edgeStart {
			newBody = append(newBody, raw[pos])
			pos++
			res.Errors++
			continue
		}

		dna := raw[pos+20 : pos+20+dl]
		name := raw[pos+20+dl : recEnd]

		res.Total++
		needsPatch, header := needsHeader(dna, layer)

		var newDNA []byte
		if needsPatch && header != 0 {
			// Rebuild ATOM nodes hoàn toàn theo NODE_Spec
			// Nhận dạng ATOM cũ: b[0]=0x01 (DN|ATOM) với val sai vị trí
			// hoặc b[0]=0x41 (QR|ATOM) nhưng thiếu EMIT byte
			b0 := dna[0]
			isAtomOld := (b0 == 0x01 || b0 == 0x41) && len(dna) <= 10
			if isAtomOld && layer == 1 {
				// Rebuild: codepoint từ record header (pos+11..14)
				cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
				// scriptID, groupID từ ISL[1], ISL[2]
				scriptID := raw[pos+4] // ISL[1]
				groupID  := raw[pos+5] // ISL[2]
				newDNA = buildAtomDNA(cp, scriptID, groupID)
			} else {
				// Prepend header byte cho các loại khác
				newDNA = make([]byte, 1+len(dna))
				newDNA[0] = header
				copy(newDNA[1:], dna)
			}
			res.Patched++
		} else if isAtomNeedsRebuild(dna) {
			// ATOM node đã có b[0]=0x41 nhưng val ở sai vị trí (cũ)
			cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
			scriptID := raw[pos+4]
			groupID  := raw[pos+5]
			newDNA = buildAtomDNA(cp, scriptID, groupID)
			res.Patched++
		} else {
			newDNA = dna
			res.Skipped++
		}

		// Viết lại record với DNA mới
		rec := make([]byte, 20+len(newDNA)+len(name))
		rec[0] = 'N'; rec[1] = 'D'
		rec[2] = layer
		copy(rec[3:11], raw[pos+3:pos+11]) // ISL
		copy(rec[11:15], raw[pos+11:pos+15]) // codepoint
		binary.BigEndian.PutUint32(rec[15:19], uint32(len(newDNA)))
		rec[19] = uint8(len(name))
		copy(rec[20:], newDNA)
		copy(rec[20+len(newDNA):], name)

		newBody = append(newBody, rec...)
		pos = recEnd
	}

	// Append phần còn lại (edges + sau edgeStart)
	if pos < len(raw) {
		newBody = append(newBody, raw[pos:]...)
	}

	// Build output: header(280B) + newBody
	out := make([]byte, 280+len(newBody))
	copy(out[:280], raw[:280])
	copy(out[280:], newBody)

	// Update node counts + layer indices
	nodeCounts  := [9]int{}
	layerSizes  := [9]uint64{}
	layerOffs   := [9]uint64{}
	totalNodes  := 0

	newEdgeStart := len(out) - nedges*olang.EdgeSize
	if newEdgeStart < 280 { newEdgeStart = 280 }

	p := 280
	for p+20 < newEdgeStart {
		if out[p] == 'N' && out[p+1] == 'D' {
			l := int(out[p+2])
			if l >= 0 && l < 9 {
				dl2 := int(binary.BigEndian.Uint32(out[p+15 : p+19]))
				nl2 := int(out[p+19])
				recLen := 20 + dl2 + nl2
				if layerOffs[l] == 0 { layerOffs[l] = uint64(p) }
				layerSizes[l] += uint64(recLen)
				nodeCounts[l]++
				totalNodes++
				p += recLen
				continue
			}
		}
		p++
	}

	for i := 0; i < 9; i++ {
		o := 64 + i*24
		binary.BigEndian.PutUint64(out[o+4:],  layerOffs[i])
		binary.BigEndian.PutUint64(out[o+12:], layerSizes[i])
		binary.BigEndian.PutUint32(out[o+20:], uint32(nodeCounts[i]))
	}
	binary.BigEndian.PutUint32(out[9:13], uint32(totalNodes))

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := olangPath + ".migrate.tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return res, err }
	if err := os.Rename(tmp, olangPath); err != nil { return res, err }

	return res, nil
}
