// internal/utf32/sdf_gen.go
//
// SDFGen — tự động gen vSDF capsule DNA cho toàn bộ L1 nodes còn thiếu.
//
// Pipeline:
//   load nodes chưa có SDF thật
//       ↓ group theo script
//       ↓ batch 50 chars/call (10 cho CJK/Arabic)
//       ↓ gọi Claude API → JSON capsules
//       ↓ encodeSDFDNA → patch node in-place
//       ↓ checkpoint mỗi 500 nodes (resumable)
//
// SDF format (theo encodeSDFDNA):
//   [0x42]                  ← QR|SDF header
//   [0x9A scale_f32]        ← optional scale
//   [0x10 nCaps k_f32]      ← UNION opcode
//   [0x02 ax ay az bx by bz r] * nCaps ← CAPSULE opcodes
//
// Coordinate space: x∈[-0.5,0.5] y∈[-0.5,0.5] z=0
// Capsule = đoạn thẳng từ A đến B, bán kính r → 1 nét bút
//
// Resume: checkpoint file lưu set codepoints đã done.

package utf32

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"sort"
	"strings"
	"time"
)

// SDFGenConfig — cấu hình
type SDFGenConfig struct {
	OlangPath      string
	CheckpointPath string // file lưu progress (mặc định: olangPath + ".sdfgen.ckpt")
	BatchSize      int    // chars per API call (mặc định: 40)
	CJKBatchSize   int    // cho CJK (mặc định: 15)
	MaxErrors      int    // dừng nếu lỗi quá nhiều (mặc định: 20)
	ScriptFilter   []uint8 // nếu không rỗng: chỉ gen cho scripts này
	Verbose        bool
}

func DefaultSDFGenConfig(olangPath string) SDFGenConfig {
	return SDFGenConfig{
		OlangPath:      olangPath,
		CheckpointPath: olangPath + ".sdfgen.ckpt",
		BatchSize:      40,
		CJKBatchSize:   15,
		MaxErrors:      20,
	}
}

// SDFGenResult — thống kê
type SDFGenResult struct {
	Total   int
	Done    int
	Skipped int // đã có SDF
	Failed  int
	Duration time.Duration
}

func (r *SDFGenResult) String() string {
	return fmt.Sprintf(
		"sdf-gen: total=%d done=%d skipped=%d failed=%d time=%.0fs",
		r.Total, r.Done, r.Skipped, r.Failed, r.Duration.Seconds(),
	)
}

// sdfNode — node cần gen SDF
type sdfNode struct {
	cp       uint32
	name     string
	cat      string  // Unicode category
	scriptID uint8
	groupID  uint8
	filePos  int     // vị trí trong file để patch
	dnaLen   int     // len DNA hiện tại
}

// ─── Entry point ─────────────────────────────────────────────────────────────

func RunSDFGen(ctx context.Context, cfg SDFGenConfig) (*SDFGenResult, error) {
	t0 := time.Now()
	res := &SDFGenResult{}

	// Load checkpoint
	done := loadCheckpoint(cfg.CheckpointPath)
	if len(done) > 0 {
		fmt.Printf("♻️  Resume: %d nodes đã done từ checkpoint\n", len(done))
	}

	// Scan file → lấy nodes cần gen
	fmt.Printf("🔍 Scanning nodes cần SDF...\n")
	nodes, err := scanNodesNeedSDF(cfg.OlangPath, done, cfg.ScriptFilter)
	if err != nil {
		return nil, err
	}
	res.Total = len(nodes)
	fmt.Printf("   Cần gen: %d nodes\n", res.Total)

	if res.Total == 0 {
		res.Duration = time.Since(t0)
		return res, nil
	}

	// Group theo scriptID
	byScript := map[uint8][]sdfNode{}
	for _, n := range nodes {
		byScript[n.scriptID] = append(byScript[n.scriptID], n)
	}

	// Sort scripts: ưu tiên Latin/Greek/Digits trước
	priority := []uint8{0x00, 0x0E, 0x03, 0x04, 0x01, 0x02, 0x06, 0x07, 0x0D, 0x20, 0x21,
		0x08, 0x09, 0x0C, 0x12, 0x13, 0x0B, 0xFF}
	seen := map[uint8]bool{}
	var scriptOrder []uint8
	for _, s := range priority {
		if _, ok := byScript[s]; ok {
			scriptOrder = append(scriptOrder, s)
			seen[s] = true
		}
	}
	for s := range byScript {
		if !seen[s] {
			scriptOrder = append(scriptOrder, s)
		}
	}

	errCount := 0
	totalProcessed := 0

	for _, scriptID := range scriptOrder {
		batch := byScript[scriptID]
		if len(batch) == 0 { continue }

		batchSize := cfg.BatchSize
		if isCJKLike(scriptID) {
			batchSize = cfg.CJKBatchSize
		}

		scriptName := scriptIDName(scriptID)
		fmt.Printf("\n📝 Script %-12s  %d nodes  (batch=%d)\n", scriptName, len(batch), batchSize)

		for start := 0; start < len(batch); start += batchSize {
			// Check context
			select {
			case <-ctx.Done():
				fmt.Printf("\n⏸  Interrupted. Checkpoint saved.\n")
				res.Duration = time.Since(t0)
				return res, ctx.Err()
			default:
			}

			end := start + batchSize
			if end > len(batch) { end = len(batch) }
			chunk := batch[start:end]

			// Gọi API
			dnaMap, err := genSDFBatch(ctx, chunk, scriptID)
			if err != nil {
				errCount++
				fmt.Printf("   ❌ batch[%d..%d]: %v\n", start, end, err)
				if errCount >= cfg.MaxErrors {
					return res, fmt.Errorf("quá nhiều lỗi (%d), dừng", errCount)
				}
				time.Sleep(3 * time.Second)
				continue
			}

			// Patch nodes vào file
			patched, failed := patchSDFNodes(cfg.OlangPath, chunk, dnaMap)
			res.Done += patched
			res.Failed += failed
			totalProcessed += len(chunk)

			// Update checkpoint
			for _, n := range chunk {
				if dnaMap[n.cp] != nil {
					done[n.cp] = true
				}
			}
			if totalProcessed % 200 == 0 || totalProcessed == res.Total {
				saveCheckpoint(cfg.CheckpointPath, done)
			}

			pct := float64(totalProcessed) / float64(res.Total) * 100
			fmt.Printf("\r   [%.0f%%] processed=%d done=%d failed=%d",
				pct, totalProcessed, res.Done, res.Failed)

			// Rate limit: 0.5s giữa các calls
			time.Sleep(500 * time.Millisecond)
		}
		fmt.Println()
	}

	// Recompute SHA256
	if err := recomputeSHA256(cfg.OlangPath); err != nil {
		fmt.Printf("⚠️  SHA256 recompute: %v\n", err)
	}

	res.Duration = time.Since(t0)
	return res, nil
}

// ─── Scan nodes cần gen ──────────────────────────────────────────────────────

func scanNodesNeedSDF(olangPath string, done map[uint32]bool, scriptFilter []uint8) ([]sdfNode, error) {
	raw, err := os.ReadFile(olangPath)
	if err != nil { return nil, err }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	filterSet := map[uint8]bool{}
	for _, s := range scriptFilter { filterSet[s] = true }

	var nodes []sdfNode
	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15:pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
		end := pos + 20 + dl + nl
		if end > edgeStart { break }

		if layer == 0x01 {
			isl      := raw[pos+3:pos+11]
			scriptID := isl[1]
			dna      := raw[pos+20:pos+20+dl]
			cp       := binary.BigEndian.Uint32(raw[pos+11:pos+15])
			name     := string(raw[pos+20+dl:end])

			isRealSDF := dl >= 30 && len(dna) > 0 && dna[0] == 0x42 &&
				len(dna) > 6 && dna[1] != 0x00 // tránh garbage

			if isRealSDF || done[cp] {
				pos = end
				continue
			}

			if len(filterSet) > 0 && !filterSet[scriptID] {
				pos = end
				continue
			}

			nodes = append(nodes, sdfNode{
				cp:       cp,
				name:     normNameForSDF(name),
				scriptID: scriptID,
				groupID:  isl[2],
				filePos:  pos,
				dnaLen:   dl,
			})
		}
		pos = end
	}

	// Sort by codepoint để nhất quán
	sort.Slice(nodes, func(i,j int) bool {
		return nodes[i].cp < nodes[j].cp
	})
	return nodes, nil
}

// ─── Gen SDF via Claude API ──────────────────────────────────────────────────

func genSDFBatch(ctx context.Context, nodes []sdfNode, scriptID uint8) (map[uint32][]byte, error) {
	prompt := buildSDFPrompt(nodes, scriptID)

	body, _ := json.Marshal(map[string]interface{}{
		"model":      "claude-sonnet-4-20250514",
		"max_tokens": 8192,
		"system": "You are a vSDF geometry engine for Unicode glyphs. " +
			"Output ONLY valid JSON array. No markdown, no explanation, no commentary. " +
			"Every character must appear in output with at least 1 capsule.",
		"messages": []map[string]string{
			{"role": "user", "content": prompt},
		},
	})

	req, err := http.NewRequestWithContext(ctx, "POST",
		"https://api.anthropic.com/v1/messages", bytes.NewReader(body))
	if err != nil { return nil, err }
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("anthropic-version", "2023-06-01")
	if k := os.Getenv("ANTHROPIC_API_KEY"); k != "" {
		req.Header.Set("x-api-key", k)
	}

	client := &http.Client{Timeout: 120 * time.Second}
	resp, err := client.Do(req)
	if err != nil { return nil, err }
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 300))
		return nil, fmt.Errorf("HTTP %d: %s", resp.StatusCode, b)
	}

	var ar struct {
		Content []struct {
			Type string `json:"type"`
			Text string `json:"text"`
		} `json:"content"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&ar); err != nil {
		return nil, err
	}
	if len(ar.Content) == 0 { return nil, fmt.Errorf("empty response") }

	raw := strings.TrimSpace(ar.Content[0].Text)
	// Strip markdown
	if i := strings.Index(raw, "["); i >= 0 { raw = raw[i:] }
	if i := strings.LastIndex(raw, "]"); i >= 0 { raw = raw[:i+1] }

	var items []struct {
		CP       uint32  `json:"cp"`
		Scale    float32 `json:"scale"`
		Capsules []struct {
			Ax float32 `json:"ax"`
			Ay float32 `json:"ay"`
			Az float32 `json:"az"`
			Bx float32 `json:"bx"`
			By float32 `json:"by"`
			Bz float32 `json:"bz"`
			R          float32 `json:"r"`
		} `json:"capsules"`
	}
	if err := json.Unmarshal([]byte(raw), &items); err != nil {
		return nil, fmt.Errorf("json parse: %w  raw[:%d]=%s", err, min(200,len(raw)), raw[:min(200,len(raw))])
	}

	result := map[uint32][]byte{}
	for _, item := range items {
		if len(item.Capsules) == 0 { continue }

		caps := make([]capItem, len(item.Capsules))
		for i, c := range item.Capsules {
			caps[i] = capItem{
				Ax: float64(clamp(c.Ax, -0.6, 0.6)),
				Ay: float64(clamp(c.Ay, -0.6, 0.6)),
				Az: float64(c.Az),
				Bx: float64(clamp(c.Bx, -0.6, 0.6)),
				By: float64(clamp(c.By, -0.6, 0.6)),
				Bz: float64(c.Bz),
				R:  float64(clamp(c.R, 0.01, 0.15)),
			}
		}
		scale := item.Scale
		if scale <= 0 || scale > 2 { scale = 0.8 }
		result[item.CP] = encodeSDFDNA(scale, caps)
	}
	return result, nil
}

// buildSDFPrompt — tạo prompt theo script
func buildSDFPrompt(nodes []sdfNode, scriptID uint8) string {
	var sb strings.Builder
	scriptName := scriptIDName(scriptID)

	sb.WriteString(fmt.Sprintf("Generate vSDF capsule primitives for %s Unicode characters.\n\n", scriptName))
	sb.WriteString("Rules:\n")
	sb.WriteString("- Coordinate space: x∈[-0.5,0.5] y∈[-0.5,0.5] z=0 always\n")
	sb.WriteString("- r=0.05 default. r=0.04 for thin strokes. r=0.06 for bold.\n")
	sb.WriteString("- scale=0.8 default\n")
	sb.WriteString("- Capture VISUAL SHAPE of glyph with capsule strokes:\n")
	sb.WriteString("  uppercase letters: 2-6 capsules (main strokes)\n")
	sb.WriteString("  lowercase letters: 1-4 capsules\n")
	sb.WriteString("  digits: 1-4 capsules\n")
	sb.WriteString("  symbols/math: 1-3 capsules\n")
	sb.WriteString("  CJK/Hanzi: 2-8 capsules (main radicals/strokes)\n")
	sb.WriteString("  emoji/pictograph: 2-5 capsules (simplified silhouette)\n")
	sb.WriteString("- Capsule A=top/start, B=bottom/end of stroke\n")
	sb.WriteString("- y+ = up, y- = down, x+ = right, x- = left\n\n")

	// Thêm ví dụ theo script
	switch scriptID {
	case 0x00, 0x01: // Latin
		sb.WriteString("Examples:\n")
		sb.WriteString(`{"cp":65,"scale":0.8,"capsules":[{"ax":-0.2,"ay":-0.5,"az":0,"bx":0,"by":0.5,"bz":0,"r":0.05},{"ax":0.2,"ay":-0.5,"az":0,"bx":0,"by":0.5,"bz":0,"r":0.05},{"ax":-0.15,"ay":0,"az":0,"bx":0.15,"by":0,"bz":0,"r":0.04}]}`)
		sb.WriteString("\n")
	case 0x03: // Greek
		sb.WriteString("Examples:\n")
		sb.WriteString(`{"cp":913,"scale":0.8,"capsules":[{"ax":-0.2,"ay":-0.5,"az":0,"bx":0,"by":0.5,"bz":0,"r":0.05},{"ax":0.2,"ay":-0.5,"az":0,"bx":0,"by":0.5,"bz":0,"r":0.05},{"ax":-0.15,"ay":0,"az":0,"bx":0.15,"by":0,"bz":0,"r":0.04}]}`)
		sb.WriteString("\n")
	case 0x0B, 0xFF: // CJK / Unknown (many are also CJK)
		sb.WriteString("For CJK/Hanzi: decompose into main radical strokes.\n")
		sb.WriteString("Examples: 一(U+4E00)=1 horizontal, 人(U+4EBA)=2 diagonal strokes\n")
	case 0x20, 0x21: // Symbols / Emoji
		sb.WriteString("For emoji: simplified geometric silhouette.\n")
		sb.WriteString("For symbols: match the visual form (arrows=line+tip, etc.)\n")
	}

	sb.WriteString("\nCharacters:\n")
	for i, n := range nodes {
		char := ""
		if n.cp >= 0x20 && n.cp < 0x10000 {
			char = fmt.Sprintf("'%c'", rune(n.cp))
		}
		sb.WriteString(fmt.Sprintf("%d. U+%04X %s \"%s\"\n",
			i+1, n.cp, char, n.name))
	}

	sb.WriteString("\nReturn ONLY JSON array, one object per character:\n")
	sb.WriteString(`[{"cp":NUMBER,"scale":0.8,"capsules":[{"ax":f,"ay":f,"az":0,"bx":f,"by":f,"bz":0,"r":0.05},...]}]`)
	sb.WriteString("\nEvery input character must appear. Output nothing else.")

	return sb.String()
}

// ─── Patch nodes in file ─────────────────────────────────────────────────────

// patchSDFNodes — cập nhật DNA của các nodes trong file
// Nếu newDNA ngắn hơn oldDNA: zero-pad
// Nếu newDNA dài hơn: không patch (log warning)
func patchSDFNodes(olangPath string, nodes []sdfNode, dnaMap map[uint32][]byte) (patched, failed int) {
	raw, err := os.ReadFile(olangPath)
	if err != nil { return 0, len(nodes) }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	modified := false

	for _, n := range nodes {
		newDNA, ok := dnaMap[n.cp]
		if !ok || len(newDNA) == 0 { failed++; continue }

		// Tìm lại node trong file theo codepoint (filePos có thể stale sau batch inserts)
		found := false
		for pos := 280; pos+20 < edgeStart; {
			if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
			layer := raw[pos+2]
			dl := int(binary.BigEndian.Uint32(raw[pos+15:pos+19]))
			nl := int(raw[pos+19])
			if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
			end := pos + 20 + dl + nl
			if end > edgeStart { break }

			if layer == 0x01 {
				cp := binary.BigEndian.Uint32(raw[pos+11:pos+15])
				if cp == n.cp {
					// Patch DNA in-place
					patchOK := patchDNAInPlace(raw, pos, dl, newDNA)
					if patchOK {
						patched++
						modified = true
					} else {
						// DNA mới dài hơn — cần rebuild node (phức tạp hơn, skip)
						failed++
					}
					found = true
					break
				}
			}
			pos = end
		}
		if !found { failed++ }
	}

	if modified {
		tmp := olangPath + ".patch.tmp"
		if err := os.WriteFile(tmp, raw, 0644); err == nil {
			os.Rename(tmp, olangPath)
		}
	}
	return patched, failed
}

// patchDNAInPlace — ghi newDNA vào vùng dna hiện tại
// Nếu newDNA <= oldDNALen: ghi + zero-pad
// Nếu newDNA > oldDNALen: thất bại (cần rebuild, không làm inline)
func patchDNAInPlace(raw []byte, nodePos, oldDNALen int, newDNA []byte) bool {
	dnaStart := nodePos + 20

	if len(newDNA) <= oldDNALen {
		// Ghi newDNA, zero-pad phần còn lại
		copy(raw[dnaStart:dnaStart+oldDNALen], make([]byte, oldDNALen))
		copy(raw[dnaStart:], newDNA)
		// Cập nhật dnaLen trong header
		binary.BigEndian.PutUint32(raw[nodePos+15:], uint32(len(newDNA)))
		return true
	}

	// newDNA dài hơn — cần append + update offset
	// TODO: implement grow (phức tạp hơn)
	return false
}

// ─── Checkpoint ──────────────────────────────────────────────────────────────

func loadCheckpoint(path string) map[uint32]bool {
	done := map[uint32]bool{}
	data, err := os.ReadFile(path)
	if err != nil { return done }
	for i := 0; i+4 <= len(data); i += 4 {
		cp := binary.BigEndian.Uint32(data[i:i+4])
		done[cp] = true
	}
	return done
}

func saveCheckpoint(path string, done map[uint32]bool) {
	cps := make([]uint32, 0, len(done))
	for cp := range done { cps = append(cps, cp) }
	sort.Slice(cps, func(i,j int) bool { return cps[i] < cps[j] })
	buf := make([]byte, len(cps)*4)
	for i, cp := range cps {
		binary.BigEndian.PutUint32(buf[i*4:], cp)
	}
	os.WriteFile(path, buf, 0644)
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

func isCJKLike(scriptID uint8) bool {
	return scriptID == 0x0B || scriptID == 0x0C || scriptID == 0xFF
}

func scriptIDName(id uint8) string {
	names := map[uint8]string{
		0x00:"Latin", 0x01:"LatinExt", 0x02:"IPA",
		0x03:"Greek", 0x04:"Cyrillic", 0x06:"Hebrew",
		0x07:"Arabic", 0x08:"Hiragana", 0x09:"Katakana",
		0x0B:"CJK", 0x0C:"Hangul", 0x0D:"Math",
		0x0E:"Digits", 0x12:"Devanagari", 0x13:"Thai",
		0x20:"Symbols", 0x21:"Emoji", 0xFF:"Unknown",
	}
	if n, ok := names[id]; ok { return n }
	return fmt.Sprintf("Script_0x%02X", id)
}

func normNameForSDF(name string) string {
	name = strings.TrimPrefix(name, "UC_")
	name = strings.TrimPrefix(name, "LC_")
	name = strings.TrimPrefix(name, "DG_")
	name = strings.TrimPrefix(name, "MT_")
	name = strings.TrimPrefix(name, "IC_")
	name = strings.TrimPrefix(name, "CH_")
	name = strings.TrimPrefix(name, "SYM_")
	name = strings.ReplaceAll(name, "_", " ")
	if len(name) > 40 { name = name[:40] }
	return name
}

func clamp(v, lo, hi float32) float32 {
	if v < lo { return lo }
	if v > hi { return hi }
	return v
}



// growNodeDNA — rebuild node với DNA mới dài hơn DNA cũ.
// Tìm node theo codepoint, xóa old record, chèn new record vào cùng vị trí.
func growNodeDNA(olangPath string, cp uint32, newDNA []byte) error {
	raw, err := os.ReadFile(olangPath)
	if err != nil { return err }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15:pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
		end := pos + 20 + dl + nl
		if end > edgeStart { break }

		if layer == 0x01 {
			nodeCp := binary.BigEndian.Uint32(raw[pos+11:pos+15])
			if nodeCp == cp {
				// Build new record
				name := raw[pos+20+dl : end]
				rec := make([]byte, 20+len(newDNA)+len(name))
				copy(rec, raw[pos:pos+20])
				binary.BigEndian.PutUint32(rec[15:], uint32(len(newDNA)))
				copy(rec[20:], newDNA)
				copy(rec[20+len(newDNA):], name)

				// Splice
				newFile := make([]byte, 0, len(raw)-( end-pos)+len(rec))
				newFile = append(newFile, raw[:pos]...)
				newFile = append(newFile, rec...)
				newFile = append(newFile, raw[end:]...)

				// Reseal SHA256 + ghi
				if len(newFile) >= 280 {
					h := sha256.Sum256(newFile[280:])
					copy(newFile[28:60], h[:])
				}
				tmp := olangPath + ".grow.tmp"
				if err := os.WriteFile(tmp, newFile, 0644); err != nil { return err }
				return os.Rename(tmp, olangPath)
			}
		}
		pos = end
	}
	return fmt.Errorf("cp U+%04X not found", cp)
}

// growNodeDNABulk — batch version: đọc file 1 lần, grow tất cả CPs, ghi 1 lần
// cpDNA: map[codepoint]newDNA. Chỉ grow nếu newDNA dài hơn DNA hiện tại.
// Returns: patched, skipped, failed
func growNodeDNABulk(olangPath string, cpDNA map[uint32][]byte) (patched, skipped, failed int) {
	raw, err := os.ReadFile(olangPath)
	if err != nil { return 0, 0, len(cpDNA) }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	// Một pass: build new file từ chunks
	// Tính total size trước để alloc
	type patch struct {
		pos    int
		oldLen int // old record len (pos..pos+20+dl+nl)
		newRec []byte
	}
	var patches []patch

	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15:pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
		end := pos + 20 + dl + nl
		if end > edgeStart { break }

		if layer == 0x01 {
			cp := binary.BigEndian.Uint32(raw[pos+11:pos+15])
			if newDNA, ok := cpDNA[cp]; ok {
				oldDNA := raw[pos+20 : pos+20+dl]
				// Skip nếu đã có SDF thật
				if len(oldDNA) > 0 && oldDNA[0] == 0x42 && dl >= 20 {
					skipped++
					delete(cpDNA, cp)
				} else if len(newDNA) <= dl {
					// In-place — không cần rebuild record
					// (handled by patchDNAInPlace already)
					skipped++
					delete(cpDNA, cp)
				} else {
					// Cần grow
					name := raw[pos+20+dl : end]
					rec := make([]byte, 20+len(newDNA)+len(name))
					copy(rec, raw[pos:pos+20])
					binary.BigEndian.PutUint32(rec[15:], uint32(len(newDNA)))
					copy(rec[20:], newDNA)
					copy(rec[20+len(newDNA):], name)
					patches = append(patches, patch{pos, end - pos, rec})
					delete(cpDNA, cp)
				}
			}
		}
		pos = end
	}

	failed = len(cpDNA) // còn lại trong map = không tìm thấy trong file
	if len(patches) == 0 {
		return 0, skipped, failed
	}

	// Build new file với tất cả patches
	// Tính size
	sizeDelta := 0
	for _, p := range patches {
		sizeDelta += len(p.newRec) - p.oldLen
	}
	newFile := make([]byte, 0, len(raw)+sizeDelta)

	cursor := 0
	for _, p := range patches {
		newFile = append(newFile, raw[cursor:p.pos]...)
		newFile = append(newFile, p.newRec...)
		cursor = p.pos + p.oldLen
	}
	newFile = append(newFile, raw[cursor:]...)

	// Reseal SHA256
	if len(newFile) >= 280 {
		h := sha256.Sum256(newFile[280:])
		copy(newFile[28:60], h[:])
	}

	tmp := olangPath + ".bulk.tmp"
	if err := os.WriteFile(tmp, newFile, 0644); err != nil {
		return 0, skipped, failed + len(patches)
	}
	if err := os.Rename(tmp, olangPath); err != nil {
		return 0, skipped, failed + len(patches)
	}

	patched = len(patches)
	return
}
