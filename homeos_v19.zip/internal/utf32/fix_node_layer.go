package utf32

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"os"

	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// FixNodeLayers — sửa layer byte trong record của các nodes có ISL mismatch.
// Dùng sau khi phát hiện nodes đã được seed với layer byte sai (AppendL1Batch hardcode 0x01).
// ISL[0] là layer đúng — sync record byte với ISL.
func FixNodeLayers(path string) (fixed int, err error) {
	raw, err := os.ReadFile(path)
	if err != nil { return 0, err }
	if len(raw) < 280 || string(raw[0:4]) != "OLNG" {
		return 0, fmt.Errorf("FixNodeLayers: bad magic")
	}
	out := make([]byte, len(raw))
	copy(out, raw)

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 { edgeStart = 280 }

	for pos := 280; pos+20 < edgeStart; {
		if out[pos] == 'N' && out[pos+1] == 'D' {
			recordLayer := out[pos+2]
			islLayer    := out[pos+3] // ISL[0] = true layer
			if recordLayer != islLayer && islLayer > 0 && islLayer < 9 {
				out[pos+2] = islLayer
				fixed++
			}
			dl := int(binary.BigEndian.Uint32(out[pos+15 : pos+19]))
			nl := int(out[pos+19])
			if dl >= 0 && dl <= 65536 && nl <= 255 {
				pos += 20 + dl + nl
			} else { pos++ }
		} else { pos++ }
	}

	if fixed == 0 { return 0, nil }

	// Rebuild layer indices
	type li struct{ off, sz uint64 }
	layers := [9]li{}
	nodeCounts := [9]int{}
	totalNodes := 0
	for pos := 280; pos+20 < edgeStart; {
		if out[pos] == 'N' && out[pos+1] == 'D' {
			l := int(out[pos+2])
			if l >= 0 && l < 9 {
				if layers[l].off == 0 { layers[l].off = uint64(pos) }
				dl := int(binary.BigEndian.Uint32(out[pos+15 : pos+19]))
				nl := int(out[pos+19])
				recLen := 20 + dl + nl
				layers[l].sz += uint64(recLen)
				nodeCounts[l]++
				totalNodes++
				pos += recLen
			} else { pos++ }
		} else { pos++ }
	}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		binary.BigEndian.PutUint64(out[o+4:],  layers[i].off)
		binary.BigEndian.PutUint64(out[o+12:], layers[i].sz)
		binary.BigEndian.PutUint32(out[o+20:], uint32(nodeCounts[i]))
	}
	binary.BigEndian.PutUint32(out[9:13], uint32(totalNodes))

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := path + ".fixlayer.tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil { return 0, err }
	return fixed, os.Rename(tmp, path)
}
