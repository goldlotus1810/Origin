// internal/utf32/scripts_fix.go
//
// FixScriptIDs — đọc Scripts.txt (Unicode official) → fix scriptID cho tất cả nodes
// có scriptID=0xFF (Unknown) hoặc scriptID sai.
//
// Scripts.txt format: "0700..074F ; Syriac # ..."
// → map codepoint range → script name → scriptID
//
// Script name → scriptID mapping được extend từ seeder.go + Scripts.txt coverage.

package utf32

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

const ScriptsTxtURL = "https://www.unicode.org/Public/UCD/latest/ucd/Scripts.txt"

// scriptNameToID — official Unicode script name → homeOS scriptID
// Nhóm các scripts liên quan vào cùng 1 ID khi phù hợp
var scriptNameToID = map[string]uint8{
	// Latin family
	"Latin":              0x00,
	"Common":             0x00, // spaces, punctuation, symbols dùng chung

	// Extensions
	"Inherited":          0x01, // combining marks inherit script

	// IPA / Phonetic
	// (dùng range-based trong cpToScriptID — không map tên)

	// Greek
	"Greek":              0x03,
	"Coptic":             0x03, // derived from Greek

	// Cyrillic
	"Cyrillic":           0x04,

	// Armenian / Georgian
	"Armenian":           0x0A,
	"Georgian":           0x0F,

	// Hebrew
	"Hebrew":             0x06,
	"Samaritan":          0x06,

	// Arabic
	"Arabic":             0x07,
	"Syriac":             0x07,
	"Thaana":             0x07,
	"Mandaic":            0x07,
	"Manichaean":         0x07,
	"Nabataean":          0x07,
	"Palmyrene":          0x07,
	"Hatran":             0x07,
	"Old_North_Arabian":  0x07,
	"Old_South_Arabian":  0x07,
	"Inscriptional_Parthian": 0x07,
	"Inscriptional_Pahlavi":  0x07,
	"Psalter_Pahlavi":    0x07,
	"Avestan":            0x07,
	"Sogdian":            0x07,
	"Old_Sogdian":        0x07,
	"Old_Uyghur":         0x07,
	"Chorasmian":         0x07,
	"Yezidi":             0x07,
	"Nko":                0x07,
	"Adlam":              0x07,

	// Devanagari & Indic
	"Devanagari":         0x12,
	"Bengali":            0x1B,
	"Gurmukhi":           0x1C,
	"Gujarati":           0x1D,
	"Oriya":              0x17,
	"Tamil":              0x17,
	"Telugu":             0x18,
	"Kannada":            0x19,
	"Malayalam":          0x1A,
	"Sinhala":            0x1E,
	"Brahmi":             0x12,
	"Kaithi":             0x12,
	"Sharada":            0x12,
	"Khojki":             0x12,
	"Mahajani":           0x12,
	"Multani":            0x12,
	"Khudawadi":          0x12,
	"Tirhuta":            0x12,
	"Modi":               0x12,
	"Newa":               0x12,
	"Nandinagari":        0x12,
	"Dogra":              0x12,
	"Takri":              0x12,
	"Siddham":            0x12,
	"Grantha":            0x17,
	"Dives_Akuru":        0x1E,
	"Syloti_Nagri":       0x1B,
	"Chakma":             0x1B,
	"Limbu":              0x12,
	"Lepcha":             0x12,
	"Medefaidrin":        0x10,
	"Tulu_Tigalari":      0x19,

	// Thai / Lao / Khmer / Myanmar
	"Thai":               0x13,
	"Lao":                0x1F,
	"Khmer":              0x14,
	"Myanmar":            0x15,
	"Tai_Le":             0x13,
	"New_Tai_Lue":        0x13,
	"Tai_Tham":           0x13,
	"Tai_Viet":           0x13,
	"Cham":               0x13,
	"Kayah_Li":           0x13,
	"Rejang":             0x13,
	"Javanese":           0x13,
	"Balinese":           0x13,
	"Sundanese":          0x13,
	"Buginese":           0x13,
	"Buhid":              0x13,
	"Hanunoo":            0x13,
	"Tagalog":            0x13,
	"Tagbanwa":           0x13,
	"Pau_Cin_Hau":        0x13,
	"Pahawh_Hmong":       0x13,
	"Nyiakeng_Puachue_Hmong": 0x13,
	"Wancho":             0x13,
	"Nag_Mundari":        0x13,
	"Kirat_Rai":          0x13,
	"Tai_Yo":             0x13,
	"Ol_Onal":            0x13,
	"Sunuwar":            0x13,
	"Tolong_Siki":        0x13,

	// Tibetan
	"Tibetan":            0x11,
	"Marchen":            0x11,
	"Zanabazar_Square":   0x11,
	"Soyombo":            0x11,
	"Bhaiksuki":          0x11,
	"Phags_Pa":           0x11,
	"Mongolian":          0x16,
	"Old_Turkic":         0x16,
	"Old_Hungarian":      0x16,

	// CJK ecosystem
	"Han":                0x0B,
	"Bopomofo":           0x0B,
	"Hiragana":           0x08,
	"Katakana":           0x09,
	"Hangul":             0x0C,
	"Tangut":             0x0B, // Tangut script → group with CJK family
	"Nushu":              0x0B,
	"Khitan_Small_Script": 0x0B,
	"Kawi":               0x09,

	// Ethiopian
	"Ethiopic":           0x10,

	// Other African
	"Bamum":              0x22,
	"Vai":                0x22,
	"Mende_Kikakui":      0x22,
	"N'Ko":               0x22,
	"Tifinagh":           0x22,
	"Garay":              0x22,
	"Beria_Erfe":         0x22,

	// Indigenous Americas
	"Canadian_Aboriginal": 0x23,
	"Cherokee":           0x23,
	"Osage":              0x23,
	"Ol_Chiki":           0x23,
	"Mro":                0x23,
	"Warang_Citi":        0x23,
	"Todhri":             0x23,

	// Historical / Ancient
	"Egyptian_Hieroglyphs": 0x24,
	"Anatolian_Hieroglyphs": 0x24,
	"Cuneiform":          0x24,
	"Linear_A":           0x24,
	"Linear_B":           0x24,
	"Ugaritic":           0x24,
	"Old_Persian":        0x24,
	"Gothic":             0x24,
	"Runic":              0x24,
	"Ogham":              0x24,
	"Old_Italic":         0x24,
	"Phoenician":         0x24,
	"Lydian":             0x24,
	"Lycian":             0x24,
	"Carian":             0x24,
	"Imperial_Aramaic":   0x24,
	"Cypriot":            0x24,
	"Cypro_Minoan":       0x24,
	"Meroitic_Hieroglyphs": 0x24,
	"Meroitic_Cursive":   0x24,
	"Deseret":            0x24,
	"Shavian":            0x24,
	"Elbasan":            0x24,
	"Elymaic":            0x24,

	// Braille / SignWriting / Special
	"Braille":            0x25,
	"SignWriting":        0x25,
	"Duployan":           0x25,

	// Math / Symbols → already handled by range
	"Yi":                 0x26,
	"Lisu":               0x26,
	"Miao":               0x26,
	"Saurashtra":         0x26,

	// Misc
	"Glagolitic":         0x27,
	"Old_Permic":         0x27,
	"Caucasian_Albanian": 0x27,
	"Vithkuqi":           0x27,
	"Sidetic":            0x27,
}

type scriptRange struct {
	lo, hi   uint32
	scriptID uint8
}

// LoadScriptRanges download + parse Scripts.txt → []scriptRange
func LoadScriptRanges(scriptsPath string) ([]scriptRange, error) {
	var data []byte
	var err error

	if scriptsPath == "" || scriptsPath == "download" {
		// Download
		client := &http.Client{Timeout: 30 * time.Second}
		resp, e := client.Get(ScriptsTxtURL)
		if e != nil { return nil, e }
		defer resp.Body.Close()
		buf := make([]byte, 0, 200*1024)
		tmp := make([]byte, 4096)
		for {
			n, e := resp.Body.Read(tmp)
			buf = append(buf, tmp[:n]...)
			if e != nil { break }
		}
		data = buf
	} else {
		data, err = os.ReadFile(scriptsPath)
		if err != nil { return nil, err }
	}

	var ranges []scriptRange
	sc := bufio.NewScanner(strings.NewReader(string(data)))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") { continue }
		parts := strings.SplitN(line, ";", 2)
		if len(parts) < 2 { continue }
		cpPart := strings.TrimSpace(parts[0])
		scriptPart := strings.TrimSpace(parts[1])
		if i := strings.Index(scriptPart, "#"); i >= 0 {
			scriptPart = strings.TrimSpace(scriptPart[:i])
		}

		var lo, hi uint32
		if i := strings.Index(cpPart, ".."); i >= 0 {
			v1, _ := strconv.ParseUint(cpPart[:i], 16, 32)
			v2, _ := strconv.ParseUint(cpPart[i+2:], 16, 32)
			lo, hi = uint32(v1), uint32(v2)
		} else {
			v, _ := strconv.ParseUint(cpPart, 16, 32)
			lo, hi = uint32(v), uint32(v)
		}

		sid, ok := scriptNameToID[scriptPart]
		if !ok {
			sid = 0xFF // still unknown — không có trong map
		}
		ranges = append(ranges, scriptRange{lo, hi, sid})
	}
	return ranges, sc.Err()
}

// LookupScriptID tìm scriptID cho codepoint từ []scriptRange
func LookupScriptID(ranges []scriptRange, cp uint32) uint8 {
	for _, r := range ranges {
		if cp >= r.lo && cp <= r.hi { return r.scriptID }
	}
	return cpToScriptID(cp) // fallback về existing logic
}

// FixScriptIDsResult — thống kê
type FixScriptIDsResult struct {
	Total   int
	Fixed   int
	Skipped int // đã đúng
}

func (r *FixScriptIDsResult) String() string {
	return fmt.Sprintf("fix-scripts: total=%d fixed=%d skipped=%d", r.Total, r.Fixed, r.Skipped)
}

// FixScriptIDs — cập nhật scriptID trong ISL và DNA cho tất cả nodes 0xFF
// hoặc nodes có scriptID sai (so với Scripts.txt).
func FixScriptIDs(olangPath, scriptsPath string, fixAll bool) (*FixScriptIDsResult, error) {
	ranges, err := LoadScriptRanges(scriptsPath)
	if err != nil { return nil, fmt.Errorf("load scripts: %w", err) }
	fmt.Printf("📋 Loaded %d script ranges\n", len(ranges))

	raw, err := os.ReadFile(olangPath)
	if err != nil { return nil, err }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	res := &FixScriptIDsResult{}
	modified := false

	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15:pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
		end := pos + 20 + dl + nl
		if end > edgeStart { break }

		if layer == 0x01 {
			res.Total++
			oldScriptID := raw[pos+4] // isl[1]
			cp := binary.BigEndian.Uint32(raw[pos+11:pos+15])

			// Fix condition: fixAll OR scriptID==0xFF
			if !fixAll && oldScriptID != 0xFF {
				res.Skipped++
				goto next
			}

			{
				newScriptID := LookupScriptID(ranges, cp)
				if newScriptID == oldScriptID {
					res.Skipped++
					goto next
				}

				// Patch ISL[1] = scriptID
				raw[pos+4] = newScriptID

				// Patch DNA scriptID nếu là metaDNA (9B, b[6]=scriptID)
				dna := raw[pos+20 : pos+20+dl]
				if dl == 9 && dna[0] == 0x41 && dna[6] == oldScriptID {
					raw[pos+20+6] = newScriptID
				}

				res.Fixed++
				modified = true
			}
		}
	next:
		pos = end
	}

	if modified {
		tmp := olangPath + ".scripts.tmp"
		if err := os.WriteFile(tmp, raw, 0644); err != nil {
			return res, err
		}
		if err := os.Rename(tmp, olangPath); err != nil {
			os.Remove(tmp)
			return res, err
		}
		if err := recomputeSHA256(olangPath); err != nil {
			return res, fmt.Errorf("sha256: %w", err)
		}
	}
	return res, nil
}
