#!/usr/bin/env python3
"""
skill_glyph_to_sdf.py — SkillGlyphToSDF

Đọc PDF Unicode chart (không dùng API/font) → render page → detect glyph grid
→ crop + clean từng glyph bitmap → skeleton → trace strokes (PCA fit) → capsule DNA

Pipeline (QT4 — 1 skill = 1 trách nhiệm):
  SkillReadPDF     — render PDF page → grayscale raster
  SkillDetectGrid  — tìm grid lines bằng dark row/col projection
  SkillGlyphCrop   — crop cell + xóa grid border artifacts
  SkillSkeleton    — binary → skeletonize (scikit-image)
  SkillTraceStroke — skeleton graph → DFS trace paths endpoint→endpoint
  SkillFitCapsule  — path points → PCA principal axis → capsule (a,b,r)
  SkillTextParse   — pdftotext → {codepoint: name}
  SkillMapCells    — (row,col) → codepoint (từ block base trong URL/filename)

Output: JSON array [{cp, name, scale, capsules:[{ax,ay,az,bx,by,bz,r}]}]
"""

import sys, os, json, math, re, subprocess, tempfile, glob
import numpy as np
from PIL import Image
from skimage.morphology import skeletonize
from scipy.ndimage import distance_transform_edt, label as ndlabel


# ── SkillReadPDF ──────────────────────────────────────────────

def skill_read_pdf(pdf_path, page, dpi=200):
    """Render 1 trang PDF → numpy grayscale array"""
    with tempfile.TemporaryDirectory() as td:
        base = os.path.join(td, 'p')
        subprocess.run(
            ['pdftoppm', '-r', str(dpi), '-f', str(page), '-l', str(page),
             pdf_path, base],
            check=True, capture_output=True
        )
        files = glob.glob(base + '*.ppm') + glob.glob(base + '*.pgm')
        if not files:
            raise FileNotFoundError("pdftoppm produced no output")
        return np.array(Image.open(files[0]).convert('L'))


# ── SkillDetectGrid ───────────────────────────────────────────

def skill_detect_grid(arr):
    """
    Tìm grid lines bằng dark pixel projection.
    Unicode charts: các horizontal/vertical lines đen full-width.
    Returns: row_lines (list int), col_lines (list int)
    """
    row_dark = (arr < 50).sum(axis=1)
    col_dark = (arr < 50).sum(axis=0)

    def cluster(indices, gap=3):
        if not indices: return []
        cs = [[indices[0]]]
        for l in indices[1:]:
            if l - cs[-1][-1] <= gap: cs[-1].append(l)
            else: cs.append([l])
        return [int(np.mean(c)) for c in cs]

    rl = cluster([i for i, v in enumerate(row_dark) if v >= row_dark.max() * 0.80])
    cl = cluster([i for i, v in enumerate(col_dark) if v >= col_dark.max() * 0.80])
    return rl, cl


# ── SkillGlyphCrop ────────────────────────────────────────────

def skill_glyph_crop(arr, row_lines, col_lines, ri, ci):
    """
    Crop cell (ri, ci) → clean binary glyph.
    Clean: xóa 3px border, xóa connected components nhỏ chạm edge (grid artifacts).
    """
    r0, r1 = row_lines[ri], row_lines[ri + 1]
    c0, c1 = col_lines[ci], col_lines[ci + 1]
    cell = arr[r0:r1, c0:c1].copy()

    # Xóa border pixels (grid lines)
    cell[:3, :]  = 255
    cell[-3:, :] = 255
    cell[:, :3]  = 255
    cell[:, -3:] = 255

    binary = (cell < 128).astype(np.uint8)
    if binary.sum() == 0:
        return binary

    # Xóa small edge-touching components (grid line fragments)
    labeled, _ = ndlabel(binary)
    edge_labels = set()
    for border in [labeled[0,:], labeled[-1,:], labeled[:,0], labeled[:,-1]]:
        edge_labels.update(border.tolist())
    edge_labels.discard(0)

    total = binary.sum()
    for lbl in edge_labels:
        comp = labeled == lbl
        if comp.sum() < total * 0.08:   # fragment nhỏ hơn 8% → xóa
            binary[comp] = 0

    return binary


# ── SkillSkeleton ─────────────────────────────────────────────

def skill_skeleton(binary):
    """Binary glyph → skeleton (scikit-image Zhang-Suen)"""
    if binary.sum() < 8:
        return None
    padded = np.pad(binary, 1, constant_values=0)
    skel = skeletonize(padded)[1:-1, 1:-1].astype(np.uint8)
    return skel if skel.sum() > 0 else None


# ── SkillTraceStroke ──────────────────────────────────────────

def skill_trace_strokes(skel):
    """
    Skeleton graph → DFS trace từ endpoints.
    Returns: list of paths, mỗi path = list of (y,x) pixel coords.
    """
    if skel is None:
        return []

    pts_set = set(map(tuple, np.argwhere(skel)))
    if not pts_set:
        return []

    def nbrs(y, x):
        return [(y+dy, x+dx) for dy in [-1,0,1] for dx in [-1,0,1]
                if (dy,dx) != (0,0) and (y+dy,x+dx) in pts_set]

    degree   = {p: len(nbrs(*p)) for p in pts_set}
    endpoints = [p for p, d in degree.items() if d == 1]
    branches  = {p for p, d in degree.items() if d >= 3}

    if not endpoints:
        # Closed loop — chọn 2 điểm cực
        all_pts = sorted(pts_set)
        endpoints = [all_pts[0], all_pts[-1]]

    visited = set()
    paths = []

    def trace(start):
        path = [start]
        visited.add(start)
        prev = None
        cur = start
        while True:
            nxt = [n for n in nbrs(*cur) if n != prev and n not in visited]
            if not nxt:
                break
            non_br = [n for n in nxt if n not in branches]
            nxt = (non_br if non_br else nxt)[0]
            visited.add(nxt)
            path.append(nxt)
            prev = cur
            cur = nxt
            if cur in branches or (cur in set(endpoints) and len(path) > 1):
                break
        return path

    for ep in sorted(endpoints):
        if ep not in visited:
            paths.append(trace(ep))

    return paths


# ── SkillFitCapsule ───────────────────────────────────────────

def skill_fit_capsule(paths, binary, max_caps=5):
    """
    Paths → capsules via PCA principal axis fit.
    Radius = mean distance transform along path.
    """
    h, w = binary.shape
    dist = distance_transform_edt(binary)

    def pca_endpoints(path):
        pts = np.array(path, dtype=float)
        center = pts.mean(0)
        c = pts - center
        _, eigvecs = np.linalg.eigh(c.T @ c)
        axis = eigvecs[:, -1]
        proj = c @ axis
        return center + proj.min() * axis, center + proj.max() * axis

    def to_norm(y, x):
        return round(float(x) / w - 0.5, 4), round(0.5 - float(y) / h, 4)

    caps = []
    seen = set()

    for path in sorted(paths, key=lambda p: -len(p)):
        if len(path) < 2:
            continue
        a, b = pca_endpoints(path)
        length_px = math.hypot(a[0]-b[0], a[1]-b[1])
        if length_px < 5:       # stub < 5px → skip
            continue
        key = (round(a[0]), round(a[1]), round(b[0]), round(b[1]))
        if key in seen:
            continue
        seen.add(key)

        r_vals = [dist[int(y), int(x)]
                  for y, x in path if 0 <= int(y) < h and 0 <= int(x) < w]
        r = round(min(0.08, max(0.03, np.mean(r_vals) / max(h, w))), 4) if r_vals else 0.04

        anx, any_ = to_norm(a[0], a[1])
        bnx, bny_ = to_norm(b[0], b[1])
        caps.append({'ax': anx, 'ay': any_, 'az': 0.0,
                     'bx': bnx, 'by': bny_, 'bz': 0.0, 'r': r})
        if len(caps) >= max_caps:
            break

    # Fallback: bounding box capsule
    if not caps and binary.sum() > 0:
        ys, xs = np.where(binary)
        xc = int(xs.mean())
        anx, any_ = to_norm(ys.min(), xc)
        bnx, bny_ = to_norm(ys.max(), xc)
        caps.append({'ax': anx, 'ay': any_, 'az': 0.0,
                     'bx': bnx, 'by': bny_, 'bz': 0.0, 'r': 0.05})

    return caps


# ── SkillTextParse ────────────────────────────────────────────

def skill_text_parse(pdf_path):
    """pdftotext → {codepoint: name}"""
    r = subprocess.run(['pdftotext', '-layout', pdf_path, '-'],
                       capture_output=True, text=True, errors='replace')
    cp_names = {}
    re_char = re.compile(r'([0-9A-Fa-f]{4,6})\s+\S*\s+([A-Z][A-Z0-9 \'\-]{3,60})')
    noise = {'UNICODE', 'THE UNICODE', 'COPYRIGHT', 'DISCLAIMER',
             'VERSION', 'STANDARD', 'ENCODED', 'SEE HTTPS', 'THIS FILE'}
    for m in re_char.finditer(r.stdout):
        try:
            cp = int(m.group(1), 16)
        except ValueError:
            continue
        name = m.group(2).strip()
        for sep in [' =', ' •', ' →', '  ']:
            idx = name.find(sep)
            if idx > 3:
                name = name[:idx].strip()
        if any(name.upper().startswith(w) for w in noise):
            continue
        if cp not in cp_names:
            cp_names[cp] = name
    return cp_names


# ── SkillMapCells ─────────────────────────────────────────────

def detect_block_start_from_page(pdf_path, page):
    """Detect block_start từ pdftotext của page cụ thể."""
    r = subprocess.run(
        ['pdftotext', '-f', str(page), '-l', str(page), pdf_path, '-'],
        capture_output=True, text=True, errors='replace'
    )
    # Tìm hex address ở đầu page (vd: "AD00", "AC00", "1F600")
    m = re.search(r'\b([0-9A-Fa-f]{4,5})[0\s]', r.stdout)
    if m:
        try:
            base = int(m.group(1), 16)
            return (base >> 4) << 4
        except ValueError:
            pass
    return None


def skill_map_cells(pdf_path, row_lines, col_lines, page=None):
    """
    (row_idx, col_idx) → codepoint.
    Unicode chart layout: col_lines = upper hex groups, row_lines = lower nibble.
    """
    base = None

    # 1) Thử detect từ page text (chính xác nhất cho multipage)
    if page is not None:
        base = detect_block_start_from_page(pdf_path, page)

    # 2) Fallback: từ filename/url
    if base is None:
        fname = os.path.basename(pdf_path).upper()
        m = re.search(r'U([0-9A-F]{4,6})', fname)
        base = int(m.group(1), 16) if m else 0x0000

    block_start = (base >> 4) << 4   # align to 0x10

    cell_map = {}
    n_cols = len(col_lines) - 1
    n_rows = len(row_lines) - 1
    for ci in range(n_cols):
        for ri in range(n_rows):
            cp = block_start + ci * 16 + ri
            if 0 <= cp <= 0x10FFFF:
                cell_map[(ri, ci)] = cp
    return cell_map


# ── Pipeline ──────────────────────────────────────────────────

def process_pdf(pdf_path, page=2, dpi=200, max_caps=5, url_hint=None):
    """
    Full pipeline: PDF → [{cp, name, scale, capsules}]
    Không dùng AI/API. Tất cả local computation.
    """
    arr        = skill_read_pdf(pdf_path, page, dpi)
    row_lines, col_lines = skill_detect_grid(arr)

    if len(row_lines) < 2 or len(col_lines) < 2:
        raise ValueError(f"Grid not detected: {len(row_lines)}r × {len(col_lines)}c")

    cp_names   = skill_text_parse(pdf_path)
    cell_map   = skill_map_cells(pdf_path, row_lines, col_lines, page=page)

    results = []
    n_rows = len(row_lines) - 1
    n_cols = len(col_lines) - 1

    for ci in range(n_cols):
        for ri in range(n_rows):
            cp = cell_map.get((ri, ci))
            if cp is None:
                continue

            binary = skill_glyph_crop(arr, row_lines, col_lines, ri, ci)
            if binary.sum() < 8:
                continue

            skel   = skill_skeleton(binary)
            paths  = skill_trace_strokes(skel)
            caps   = skill_fit_capsule(paths, binary, max_caps=max_caps)

            if not caps:
                continue

            name = cp_names.get(cp, f'U{cp:04X}')
            results.append({
                'cp':       cp,
                'name':     name,
                'scale':    0.8,
                'capsules': caps,
            })

    return results


# ── CLI ───────────────────────────────────────────────────────

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('pdf')
    ap.add_argument('--page',     type=int, default=2)
    ap.add_argument('--dpi',      type=int, default=200)
    ap.add_argument('--max-caps', type=int, default=5)
    ap.add_argument('--out',        default='-')
    ap.add_argument('--source-url', default='', help='Original PDF URL (để detect block range)')
    args = ap.parse_args()

    # Nếu source-url được truyền, dùng nó để detect script/block
    pdf_hint = args.source_url or args.pdf
    results = process_pdf(args.pdf, page=args.page, dpi=args.dpi, max_caps=args.max_caps,
                          url_hint=pdf_hint)

    out = sys.stdout if args.out == '-' else open(args.out, 'w')
    json.dump(results, out, indent=2, ensure_ascii=False)
    out.write('\n')
    if args.out != '-':
        out.close()

    print(f"# {len(results)} glyphs → capsules", file=sys.stderr)
