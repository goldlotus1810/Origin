package utf32

import (
	"fmt"
	"testing"
	"unicode"
)

func TestAnchorStructure(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  UTF-32 ANCHOR STRUCTURE — điểm neo trước khi nhập liệu    ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	blocks, clusters, members := Stats()
	t.Logf("  Blocks:   %d Unicode blocks được theo dõi", blocks)
	t.Logf("  Clusters: %d nhóm chức năng HomeOS", clusters)
	t.Logf("  Members:  %d symbols đã có điểm neo\n", members)

	// Kiểm tra mỗi cluster
	t.Log("  CLUSTERS CHI TIẾT:")
	t.Log("  ─────────────────────────────────────────────────────────────")
	for _, cl := range Clusters {
		t.Logf("  [%s] %s (%d symbols)", cl.ID, cl.Name, len(cl.Members))
		for _, cp := range cl.Members {
			ch := rune(cp)
			name := "UNKNOWN"
			if unicode.IsLetter(ch) || unicode.IsSymbol(ch) || unicode.IsPunct(ch) || unicode.IsNumber(ch) {
				// Go's unicode package không có Name(), dùng fmt
				name = fmt.Sprintf("U+%04X", cp)
			}
			t.Logf("    %s  %s", string(ch), name)
		}
	}

	t.Log()
	t.Log("  LOOKUP TEST:")
	testCases := []struct {
		cp       uint32
		expected string
	}{
		{0x25CF, "SDF_PRIMITIVES"},  // ● sphere
		{0x222A, "SDF_BOOLEAN"},     // ∪ union
		{0x2200, "MATH_QUANTIFIERS"},// ∀ for-all
		{0x1F9EC, "BIO_GENE"},       // 🧬 DNA
		{0x1F6E1, "SYS_SECURITY"},   // 🛡 shield
		{0x2192, "FLOW_DIRECTION"},  // → arrow
		{0x03C0, "MATH_CONSTANTS"},  // π pi
		{0x25CB, "SDF_PRIMITIVES"},  // ○ cylinder (also in ORIGIN, first wins)
	}

	allPass := true
	for _, tc := range testCases {
		cl := FindCluster(tc.cp)
		ch := string(rune(tc.cp))
		if cl == nil {
			t.Errorf("  ✗ %s U+%04X → NOT FOUND (expected %s)", ch, tc.cp, tc.expected)
			allPass = false
		} else if cl.ID != tc.expected {
			t.Logf("  ? %s U+%04X → %s (expected %s) — first match wins", ch, tc.cp, cl.ID, tc.expected)
		} else {
			t.Logf("  ✓ %s U+%04X → %s", ch, tc.cp, cl.ID)
		}
	}

	t.Log()
	t.Log("  BLOCK LOOKUP:")
	blockTests := []uint32{0x25CF, 0x2200, 0x03C0, 0x1F9EC, 0x221A}
	for _, cp := range blockTests {
		b := FindBlock(cp)
		if b != nil {
			t.Logf("  %s U+%04X → Block [%s] %s", string(rune(cp)), cp, b.ID, b.Name)
		}
	}

	t.Log()
	t.Log("  SUGGEST TEST — symbol mới gặp trong sách:")
	newSymbols := []struct {
		cp   uint32
		tags []string
	}{
		{0x2227, []string{"math", "lang"}},  // ∧ LOGICAL AND
		{0x2228, []string{"math", "lang"}},  // ∨ LOGICAL OR
		{0x1F525, []string{"physics", "bio"}}, // 🔥 FIRE
	}
	for _, ns := range newSymbols {
		suggestions := SuggestCluster(ns.cp, ns.tags)
		t.Logf("  %s U+%04X tags=%v → suggest: %v", string(rune(ns.cp)), ns.cp, ns.tags, suggestions)
	}

	t.Log()
	t.Log("  QUY TẮC ADD SYMBOL MỚI (bất biến):")
	t.Log("  1. Chương trình đọc sách gặp symbol")
	t.Log("  2. FindCluster(cp) → đã có? dùng luôn")
	t.Log("  3. Chưa có? SuggestCluster(cp, tags) → chọn cluster")
	t.Log("  4. Không có cluster phù hợp? tạo cluster mới trong đúng block")
	t.Log("  5. KHÔNG bao giờ add symbol mà không qua anchor")

	if !allPass {
		t.Error("Some lookups failed")
	}
}
