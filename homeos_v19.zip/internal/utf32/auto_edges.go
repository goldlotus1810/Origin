// internal/utf32/auto_edges.go
//
// AutoWireEdges — engine tự động suy ra silk edges từ Unicode properties.
// KHÔNG hard-code gì cả. Mọi edge đều được suy ra từ bản chất ký tự:
//
//   Logic 1 — Case:
//     unicode.ToLower(H) = h  → H──EdgeUppercase──►h, h──EdgeLowercase──►H
//
//   Logic 2 — Script/Block equivalence:
//     A(Latin) ≡ Α(Greek) ≡ А(Cyrillic): cùng hình, khác script → EdgeSameShape
//     A ≡ a: cùng âm → EdgeSameSound (qua IPA block)
//
//   Logic 3 — Unicode Name keywords:
//     "HEART" xuất hiện trong tên → group thành cluster → EdgeSameMeaning
//     "LOVE", "YEU", "AI" (爱)... → cross-language SameMeaning
//
//   Logic 4 — Codepoint arithmetic:
//     Uppercase↔Lowercase Latin: cp ± 32
//     Greek capital↔small: cp ± 32
//     Digits 0-9: sequential EdgeSubset trong block
//
// Kết quả: edges được append vào homeos.olang qua ws.OlangAppendEdgeWeighted

package utf32

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"strings"
	"unicode"

	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/ws"
)

// AutoEdgeResult thống kê kết quả wiring
type AutoEdgeResult struct {
	Total     int
	CaseEdges int // uppercase↔lowercase
	ShapeEdges int // cùng hình khác script
	NameEdges  int // cùng keyword trong Unicode name
	BlockEdges int // cùng block/script
	Skipped   int
	Errors    int
}

func (r *AutoEdgeResult) String() string {
	return fmt.Sprintf(
		"auto-wire: total=%d case=%d shape=%d name=%d block=%d skipped=%d errors=%d",
		r.Total, r.CaseEdges, r.ShapeEdges, r.NameEdges, r.BlockEdges, r.Skipped, r.Errors,
	)
}

// nodeRec là bản ghi tối giản đọc từ file
type nodeRec struct {
	layer uint8
	isl   [8]byte
	cp    uint32
	dna   []byte
	name  string
}

// AutoWireEdges đọc toàn bộ nodes từ olangPath,
// suy ra edges theo logic Unicode, append vào file.
func AutoWireEdges(olangPath string) (*AutoEdgeResult, error) {
	res := &AutoEdgeResult{}

	// ── 1. Đọc tất cả nodes ──────────────────────────────────────
	nodes, err := readAllNodes(olangPath)
	if err != nil {
		return nil, fmt.Errorf("readAllNodes: %w", err)
	}

	// Build index: codepoint → ISL
	cpIndex := make(map[uint32][8]byte, len(nodes))
	for _, n := range nodes {
		cpIndex[n.cp] = n.isl
	}

	// Build index: name-keywords → []nodeRec
	nameIndex := buildNameIndex(nodes)

	// ── 2. Existing edges — dedup ────────────────────────────────
	existing, err := readExistingEdges(olangPath)
	if err != nil {
		return nil, fmt.Errorf("readExistingEdges: %w", err)
	}

	addEdge := func(srcISL, dstISL [8]byte, edgeType uint8) {
		key := edgeKey(srcISL, dstISL, edgeType)
		if existing[key] {
			res.Skipped++
			return
		}
		if err := ws.OlangAppendEdge(olangPath, srcISL, dstISL, edgeType); err != nil {
			res.Errors++
			return
		}
		existing[key] = true
		res.Total++
	}

	// ── 3. Logic 1: Case pairs ───────────────────────────────────
	// H và h cùng là 1 symbol — silk EdgeEquiv (≡), không phải Lower/Upper.
	// Silk không biết "uppercase" hay "lowercase" — chỉ biết "cùng ý nghĩa".
	// 1 silk per pair: src = codepoint nhỏ hơn (quy ước normalize).
	seenCase := make(map[[2]uint32]bool)
	for _, n := range nodes {
		cp := rune(n.cp)
		other := unicode.ToLower(cp)
		if other == cp {
			other = unicode.ToUpper(cp)
		}
		if other == cp {
			continue
		}
		lo, hi := uint32(cp), uint32(other)
		if lo > hi {
			lo, hi = hi, lo
		}
		pair := [2]uint32{lo, hi}
		if seenCase[pair] {
			continue
		}
		seenCase[pair] = true

		loISL, okLo := cpIndex[lo]
		hiISL, okHi := cpIndex[hi]
		if !okLo || !okHi {
			continue
		}
		addEdge(loISL, hiISL, olang.EdgeEquiv)
		res.CaseEdges++
	}

	// ── 4. Logic 2: Cross-script same symbol ─────────────────────
	// A(Latin) Α(Greek) А(Cyrillic) — cùng 1 symbol, khác script → EdgeEquiv
	shapeGroups := buildShapeGroups(nodes)
	for _, group := range shapeGroups {
		if len(group) < 2 {
			continue
		}
		for i := 0; i < len(group); i++ {
			for j := i + 1; j < len(group); j++ {
				a, b := group[i], group[j]
				lo, hi := islUint64(a.isl), islUint64(b.isl)
				var srcISL, dstISL [8]byte
				if lo <= hi {
					srcISL, dstISL = a.isl, b.isl
				} else {
					srcISL, dstISL = b.isl, a.isl
				}
				addEdge(srcISL, dstISL, olang.EdgeEquiv)
				res.ShapeEdges++
			}
		}
	}

	// ── 5. Logic 3: Cross-language same meaning ───────────────────
	// HEART ♥ ❤ YÊU LOVE 爱 — cùng concept → EdgeEquiv
	meaningGroups := buildMeaningGroups(nameIndex)
	for _, group := range meaningGroups {
		if len(group) < 2 {
			continue
		}
		for i := 0; i < len(group); i++ {
			for j := i + 1; j < len(group); j++ {
				a, b := group[i], group[j]
				lo, hi := islUint64(a.isl), islUint64(b.isl)
				var srcISL, dstISL [8]byte
				if lo <= hi {
					srcISL, dstISL = a.isl, b.isl
				} else {
					srcISL, dstISL = b.isl, a.isl
				}
				addEdge(srcISL, dstISL, olang.EdgeEquiv)
				res.NameEdges++
			}
		}
	}

	// ── 6. Logic 4: Block membership ─────────────────────────────
	// Ký tự trong cùng Unicode block → EdgeMember (thuộc cùng script/nhóm)
	// Chain thay vì full mesh
	blockGroups := buildBlockGroups(nodes)
	for _, group := range blockGroups {
		if len(group) < 2 {
			continue
		}
		for i := 0; i+1 < len(group); i++ {
			a, b := group[i], group[i+1]
			lo, hi := islUint64(a.isl), islUint64(b.isl)
			var srcISL, dstISL [8]byte
			if lo <= hi {
				srcISL, dstISL = a.isl, b.isl
			} else {
				srcISL, dstISL = b.isl, a.isl
			}
			addEdge(srcISL, dstISL, olang.EdgeMember)
			res.BlockEdges++
		}
	}

	// ── 7. Logic 5: L0 opcode groups ────────────────────────────
	// L0 opcodes nhóm theo chức năng → EdgeMember trong nhóm
	// Bản chất quyết định vị trí (QT5) — không hard-code tên, dùng name prefix
	l0Groups := buildL0Groups(nodes)
	for _, group := range l0Groups {
		if len(group) < 2 {
			continue
		}
		for i := 0; i+1 < len(group); i++ {
			a, b := group[i], group[i+1]
			lo, hi := islUint64(a.isl), islUint64(b.isl)
			var srcISL, dstISL [8]byte
			if lo <= hi {
				srcISL, dstISL = a.isl, b.isl
			} else {
				srcISL, dstISL = b.isl, a.isl
			}
			addEdge(srcISL, dstISL, olang.EdgeMember)
			res.BlockEdges++
		}
	}

	return res, nil
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

func readAllNodes(path string) ([]nodeRec, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 280 {
		edgeStart = 280
	}

	var nodes []nodeRec
	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' {
			pos++
			continue
		}
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl < 0 || nl > 255 {
			pos++
			continue
		}
		end := pos + 20 + dl + nl
		if end > edgeStart {
			break
		}
		var isl [8]byte
		copy(isl[:], raw[pos+3:pos+11])
		cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
		dna := make([]byte, dl)
		copy(dna, raw[pos+20:pos+20+dl])
		name := string(raw[pos+20+dl : end])

		nodes = append(nodes, nodeRec{
			layer: layer,
			isl:   isl,
			cp:    cp,
			dna:   dna,
			name:  name,
		})
		pos = end
	}
	return nodes, nil
}

func readExistingEdges(path string) (map[string]bool, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	existing := make(map[string]bool, nedges)
	edgeStart := len(raw) - nedges*olang.EdgeSize
	if edgeStart < 0 {
		return existing, nil
	}
	for i := 0; i < nedges; i++ {
		off := edgeStart + i*olang.EdgeSize
		if off+olang.EdgeSize > len(raw) {
			break
		}
		var src, dst [8]byte
		copy(src[:], raw[off:off+8])
		copy(dst[:], raw[off+8:off+16])
		t := raw[off+16]
		existing[edgeKey(src, dst, t)] = true
	}
	return existing, nil
}

func edgeKey(src, dst [8]byte, t uint8) string {
	var buf [17]byte
	copy(buf[:8], src[:])
	copy(buf[8:16], dst[:])
	buf[16] = t
	return string(buf[:])
}

func islUint64(isl [8]byte) uint64 {
	return binary.BigEndian.Uint64(isl[:])
}

// buildL0Groups: nhóm L0 opcodes theo chức năng từ tên
// Logic: OP_SIN, OP_COS, OP_TAN → group "trig"
// Không hard-code — phân nhóm dựa trên suffix/keyword trong tên OP
func buildL0Groups(nodes []nodeRec) [][]nodeRec {
	// Map từ keyword → group name (tự động từ tên opcode)
	groupOf := func(name string) string {
		name = strings.ToUpper(name)
		switch {
		case contains(name, "SIN", "COS", "TAN", "ASIN", "ACOS", "ATAN"):
			return "trig"
		case contains(name, "ADD", "SUB", "MUL", "DIV", "MOD", "POW", "SQRT", "ABS", "SIGN", "FLOOR", "CEIL", "FRAC", "MIN", "MAX", "MIX", "CLAMP"):
			return "math"
		case contains(name, "SPHERE", "BOX", "CAPSULE", "TORUS", "VOID"):
			return "sdf_prim"
		case contains(name, "UNION", "INTERSECT", "SUB_N"):
			return "sdf_op"
		case contains(name, "DOT", "CROSS", "NORM", "LEN", "VEC3", "ROT", "REFLECT", "REFRACT"):
			return "vector"
		case contains(name, "GRADIENT", "FBM", "LIGHT", "SPLINE"):
			return "field"
		case contains(name, "IF", "IFF", "LOOP", "CALL", "RET", "YIELD", "EMIT", "GATE", "SPAWN", "AWAIT"):
			return "control"
		case contains(name, "LOAD", "STORE", "PUSH", "POP", "BCAST"):
			return "memory"
		case contains(name, "DREAM", "SEQ", "IMPL", "AND", "OR", "NOT", "EQ", "NEQ", "LT", "GT"):
			return "logic"
		case contains(name, "TRANSLATE", "SCALE"):
			return "transform"
		case contains(name, "POS_", "NOUN", "VERB", "ADJ", "ADV", "CONJ", "PREP", "INTERJ", "DET", "NUM", "QUANT", "DEMO", "PART", "MODAL"):
			return "pos_tag"
		default:
			return ""
		}
	}

	groups := make(map[string][]nodeRec)
	for _, n := range nodes {
		if n.layer != 0 {
			continue
		}
		g := groupOf(n.name)
		if g == "" {
			continue
		}
		groups[g] = append(groups[g], n)
	}
	var result [][]nodeRec
	for _, g := range groups {
		if len(g) >= 2 {
			result = append(result, g)
		}
	}
	return result
}

func contains(s string, subs ...string) bool {
	for _, sub := range subs {
		if strings.Contains(s, sub) {
			return true
		}
	}
	return false
}
func buildNameIndex(nodes []nodeRec) map[string][]nodeRec {
	idx := make(map[string][]nodeRec)
	for _, n := range nodes {
		for _, word := range nameKeywords(n.name) {
			idx[word] = append(idx[word], n)
		}
	}
	return idx
}

// nameKeywords trích từ khóa có nghĩa từ Unicode name
// "LATIN CAPITAL LETTER H" → ["LETTER", "H"]
// "BLACK HEART SUIT" → ["HEART"]
// "SNOWFLAKE" → ["SNOWFLAKE"]
func nameKeywords(name string) []string {
	stopWords := map[string]bool{
		"LATIN": true, "GREEK": true, "CYRILLIC": true, "ARABIC": true,
		"CAPITAL": true, "SMALL": true, "LETTER": true, "DIGIT": true,
		"SIGN": true, "SYMBOL": true, "WITH": true, "AND": true,
		"FOR": true, "OF": true, "THE": true, "TO": true, "IN": true,
		"BLACK": true, "WHITE": true, "HEAVY": true, "LIGHT": true,
		"COMBINING": true, "MODIFIER": true, "ABOVE": true, "BELOW": true,
	}
	// Keyword có nghĩa thực sự — concept words
	conceptWords := map[string]bool{
		"HEART": true, "STAR": true, "MOON": true, "SUN": true,
		"FIRE": true, "WATER": true, "EARTH": true, "WIND": true,
		"LOVE": true, "PEACE": true, "FLOWER": true, "TREE": true,
		"FISH": true, "BIRD": true, "SNAKE": true, "DRAGON": true,
		"CIRCLE": true, "SQUARE": true, "TRIANGLE": true, "ARROW": true,
		"PLUS": true, "MINUS": true, "CROSS": true, "CHECK": true,
		"SNOWFLAKE": true, "LIGHTNING": true, "CLOUD": true, "RAIN": true,
		"HAND": true, "EYE": true, "EAR": true, "MOUTH": true,
		"MUSIC": true, "WAVE": true, "INFINITY": true, "ZERO": true,
	}

	var keys []string
	parts := strings.Fields(strings.ToUpper(name))
	for _, p := range parts {
		p = strings.Trim(p, "-()")
		if len(p) == 0 {
			continue
		}
		if stopWords[p] {
			continue
		}
		if conceptWords[p] {
			keys = append(keys, p)
		}
		// Chữ cái đơn (A, B, ..., Z, Α, ...) — keyword là chữ cái đó
		if len([]rune(p)) == 1 && unicode.IsLetter([]rune(p)[0]) {
			keys = append(keys, "LETTER_"+p)
		}
	}
	return keys
}

// buildShapeGroups: nhóm nodes có cùng "visual skeleton"
// Logic: Unicode name kết thúc bằng "LETTER X" (cùng X) nhưng khác script
func buildShapeGroups(nodes []nodeRec) [][]nodeRec {
	groups := make(map[string][]nodeRec)
	for _, n := range nodes {
		key := visualKey(n.name)
		if key == "" {
			continue
		}
		groups[key] = append(groups[key], n)
	}
	var result [][]nodeRec
	for _, g := range groups {
		if len(g) >= 2 {
			result = append(result, g)
		}
	}
	return result
}

// visualKey: "LATIN CAPITAL LETTER A" → "LETTER_A"
// "GREEK CAPITAL LETTER ALPHA" → "" (khác tên)
// Chỉ match khi tên kết thúc bằng "LETTER <single-char>"
func visualKey(name string) string {
	parts := strings.Fields(strings.ToUpper(name))
	for i, p := range parts {
		if p == "LETTER" && i+1 < len(parts) {
			next := parts[i+1]
			if len([]rune(next)) == 1 {
				return "LETTER_" + next
			}
		}
	}
	return ""
}

// buildMeaningGroups: nhóm nodes có cùng concept keyword trong name
func buildMeaningGroups(nameIndex map[string][]nodeRec) [][]nodeRec {
	var result [][]nodeRec
	seen := make(map[string]bool)
	for key, group := range nameIndex {
		if seen[key] || len(group) < 2 {
			continue
		}
		// Chỉ lấy concept keywords (không phải LETTER_X)
		if strings.HasPrefix(key, "LETTER_") {
			continue
		}
		seen[key] = true
		result = append(result, group)
	}
	return result
}

// buildBlockGroups: nhóm nodes trong cùng Unicode block
func buildBlockGroups(nodes []nodeRec) [][]nodeRec {
	groups := make(map[string][]nodeRec)
	for _, n := range nodes {
		block := unicodeBlock(rune(n.cp))
		if block == "" {
			continue
		}
		groups[block] = append(groups[block], n)
	}
	var result [][]nodeRec
	for _, g := range groups {
		if len(g) >= 2 && len(g) <= 256 { // tránh bùng nổ
			result = append(result, g)
		}
	}
	return result
}

// unicodeBlock trả về tên block của codepoint
// Dùng ranges cứng vì Go không có built-in Unicode block API
func unicodeBlock(cp rune) string {
	switch {
	case cp >= 0x0000 && cp <= 0x007F:
		return "BasicLatin"
	case cp >= 0x0080 && cp <= 0x00FF:
		return "Latin1Supplement"
	case cp >= 0x0100 && cp <= 0x017F:
		return "LatinExtendedA"
	case cp >= 0x0370 && cp <= 0x03FF:
		return "Greek"
	case cp >= 0x0400 && cp <= 0x04FF:
		return "Cyrillic"
	case cp >= 0x0600 && cp <= 0x06FF:
		return "Arabic"
	case cp >= 0x0900 && cp <= 0x097F:
		return "Devanagari"
	case cp >= 0x3040 && cp <= 0x309F:
		return "Hiragana"
	case cp >= 0x30A0 && cp <= 0x30FF:
		return "Katakana"
	case cp >= 0x4E00 && cp <= 0x9FFF:
		return "CJKUnified"
	case cp >= 0xAC00 && cp <= 0xD7AF:
		return "HangulSyllables"
	case cp >= 0x2200 && cp <= 0x22FF:
		return "MathOperators"
	case cp >= 0x2500 && cp <= 0x257F:
		return "BoxDrawing"
	case cp >= 0x25A0 && cp <= 0x25FF:
		return "GeometricShapes"
	case cp >= 0x2600 && cp <= 0x26FF:
		return "MiscSymbols"
	case cp >= 0x1F300 && cp <= 0x1F5FF:
		return "MiscSymbolsPictographs"
	case cp >= 0x1F600 && cp <= 0x1F64F:
		return "Emoticons"
	default:
		return ""
	}
}

// sdfSimilarity tính độ tương đồng SDF giữa 2 DNA
// Dùng Jaccard trên byte set (proxy cho visual similarity)
func sdfSimilarity(a, b []byte) float32 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	setA := make(map[byte]bool)
	setB := make(map[byte]bool)
	for _, v := range a {
		setA[v] = true
	}
	for _, v := range b {
		setB[v] = true
	}
	inter, union := 0, 0
	for k := range setA {
		if setB[k] {
			inter++
		}
	}
	for k := range setA {
		union++
		_ = k
	}
	for k := range setB {
		if !setA[k] {
			union++
		}
		_ = k
	}
	if union == 0 {
		return 0
	}
	return float32(inter) / float32(union)
}

// Đảm bảo math không bị unused
var _ = math.MaxFloat32
