// internal/utf32/bulk_seed.go
//
// BulkSeed — seed toàn bộ Unicode L1 từ UnicodeData.txt (Unicode Consortium).
//
// Nguồn chính thức: https://www.unicode.org/Public/15.0.0/ucd/UnicodeData.txt
// Format: cp;name;category;...;uppercase;lowercase;titlecase
//
// Pipeline:
//   UnicodeData.txt
//       ↓ parse: codepoint, name, category, upper/lower pair
//       ↓ filter: chỉ printable (loại Cc/Cs/Co/Cn/Cf)
//       ↓ map: category → scriptID + groupID (từ codepoint range)
//       ↓ build ISL [0x01][scriptID][groupID][id]
//       ↓ metaDNA (ATOM format)
//       ↓ batch OlangAppendNode → L1
//       ↓ update SHA256 → verify
//
// ISL scheme L1:
//   b[0] = 0x01 (layer 1)
//   b[1] = scriptID (từ codepoint range)
//   b[2] = groupID  (từ Unicode category)
//   b[3] = id       (sequential per script+group, wraps 0x01-0xFF)
//   b[4..7] = 0
//
// Chạy một lần duy nhất: cmd/olang bulk-seed homeos.olang [path/to/UnicodeData.txt]

package utf32

import (
	"bufio"
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

// BulkSeedResult — thống kê
type BulkSeedResult struct {
	Total   int
	Added   int
	Skipped int // đã có trong file
	Failed  int
	Duration time.Duration
}

func (r *BulkSeedResult) String() string {
	return fmt.Sprintf(
		"bulk-seed: total=%d added=%d skipped=%d failed=%d time=%.1fs",
		r.Total, r.Added, r.Skipped, r.Failed, r.Duration.Seconds(),
	)
}

// unicodeEntry — một codepoint đã parse
type unicodeEntry struct {
	cp       uint32
	name     string
	cat      string // Unicode category (Lu, Ll, Lo, Sm, So, ...)
	upper    uint32 // uppercase mapping (0 = none)
	lower    uint32 // lowercase mapping (0 = none)
	scriptID uint8
	groupID  uint8
}

// ─── Categories hữu ích (loại bỏ control, surrogate, private use) ─────────────
var usefulCats = map[string]bool{
	"Lu": true, // Letter, Uppercase
	"Ll": true, // Letter, Lowercase
	"Lt": true, // Letter, Titlecase
	"Lm": true, // Letter, Modifier
	"Lo": true, // Letter, Other
	"Nd": true, // Number, Decimal
	"Nl": true, // Number, Letter
	"No": true, // Number, Other
	"Sm": true, // Symbol, Math
	"Sc": true, // Symbol, Currency
	"Sk": true, // Symbol, Modifier
	"So": true, // Symbol, Other
	"Po": true, // Punctuation, Other
	"Ps": true, // Punctuation, Open
	"Pe": true, // Punctuation, Close
	"Pi": true, // Punctuation, Initial quote
	"Pf": true, // Punctuation, Final quote
	"Pd": true, // Punctuation, Dash
	"Pc": true, // Punctuation, Connector
	"Mn": true, // Mark, Nonspacing (combining diacritics, vowel marks)
	"Mc": true, // Mark, Spacing (Indic vowel signs, matras)
	"Me": true, // Mark, Enclosing
	"Cf": true, // Format (soft hyphen, ZWJ, ZWNJ, directional)
	"Zs": true, // Separator, Space
	"Zl": true, // Separator, Line
	"Zp": true, // Separator, Paragraph
}

// ─── Category → groupID ───────────────────────────────────────────────────────
func catToGroupID(cat string) uint8 {
	switch cat {
	case "Lu", "Lt":
		return 0x01 // uppercase
	case "Ll":
		return 0x02 // lowercase
	case "Lm":
		return 0x03 // modifier letter / ligature
	case "Lo":
		return 0x09 // letter (other script)
	case "Nd":
		return 0x08 // decimal digit
	case "Nl", "No":
		return 0x0A // number (other)
	case "Sm":
		return 0x0B // math symbol
	case "Sc":
		return 0x0C // currency
	case "Sk":
		return 0x06 // modifier symbol
	case "So":
		return 0x05 // symbol (other)
	case "Po", "Pd", "Pc":
		return 0x04 // punctuation
	case "Ps", "Pe", "Pi", "Pf":
		return 0x0D // bracket / quote
	case "Mn", "Me":
		return 0x0E // nonspacing / enclosing mark
	case "Mc":
		return 0x0F // spacing mark (Indic matras)
	case "Cf":
		return 0x10 // format / invisible
	case "Zs", "Zl", "Zp":
		return 0x11 // separator
	default:
		return 0x09
	}
}

// ─── Codepoint range → scriptID ──────────────────────────────────────────────
// Nguồn: Unicode block definitions — bất biến
func cpToScriptID(cp uint32) uint8 {
	switch {
	// Latin & IPA
	case cp >= 0x0020 && cp <= 0x007F: return 0x00 // Basic Latin
	case cp >= 0x0080 && cp <= 0x00FF: return 0x00 // Latin-1 Supplement
	case cp >= 0x0100 && cp <= 0x024F: return 0x01 // Latin Extended A/B
	case cp >= 0x0250 && cp <= 0x02AF: return 0x02 // IPA Extensions
	case cp >= 0x02B0 && cp <= 0x02FF: return 0x02 // Spacing Modifiers
	case cp >= 0x1D00 && cp <= 0x1DBF: return 0x02 // Phonetic Extensions
	case cp >= 0x1E00 && cp <= 0x1EFF: return 0x01 // Latin Extended Additional (Việt)

	// Greek & Coptic
	case cp >= 0x0300 && cp <= 0x036F: return 0x03 // Combining Diacritical
	case cp >= 0x0370 && cp <= 0x03FF: return 0x03 // Greek and Coptic
	case cp >= 0x1F00 && cp <= 0x1FFF: return 0x03 // Greek Extended

	// Cyrillic
	case cp >= 0x0400 && cp <= 0x052F: return 0x04 // Cyrillic

	// Armenian, Georgian
	case cp >= 0x0530 && cp <= 0x058F: return 0x0F // Armenian
	case cp >= 0x10A0 && cp <= 0x10FF: return 0x0F // Georgian

	// Hebrew
	case cp >= 0x0590 && cp <= 0x05FF: return 0x06 // Hebrew
	case cp >= 0xFB1D && cp <= 0xFB4F: return 0x06 // Hebrew Presentation

	// Arabic
	case cp >= 0x0600 && cp <= 0x06FF: return 0x07 // Arabic
	case cp >= 0x0750 && cp <= 0x077F: return 0x07 // Arabic Supplement
	case cp >= 0xFB50 && cp <= 0xFDFF: return 0x07 // Arabic Presentation A
	case cp >= 0xFE70 && cp <= 0xFEFF: return 0x07 // Arabic Presentation B

	// Devanagari & Indic
	case cp >= 0x0900 && cp <= 0x097F: return 0x12 // Devanagari
	case cp >= 0x0980 && cp <= 0x09FF: return 0x1B // Bengali
	case cp >= 0x0A80 && cp <= 0x0AFF: return 0x19 // Gujarati
	case cp >= 0x0B00 && cp <= 0x0B7F: return 0x17 // Oriya
	case cp >= 0x0B80 && cp <= 0x0BFF: return 0x17 // Tamil
	case cp >= 0x0C00 && cp <= 0x0C7F: return 0x18 // Telugu
	case cp >= 0x0C80 && cp <= 0x0CFF: return 0x19 // Kannada
	case cp >= 0x0D00 && cp <= 0x0D7F: return 0x1A // Malayalam

	// Thai, Lao, Khmer
	case cp >= 0x0E00 && cp <= 0x0E7F: return 0x13 // Thai
	case cp >= 0x0E80 && cp <= 0x0EFF: return 0x1F // Lao
	case cp >= 0x1780 && cp <= 0x17FF: return 0x14 // Khmer
	case cp >= 0x1000 && cp <= 0x109F: return 0x15 // Myanmar

	// Tibetan, Ethiopic
	case cp >= 0x0F00 && cp <= 0x0FFF: return 0x11 // Tibetan
	case cp >= 0x1200 && cp <= 0x137F: return 0x10 // Ethiopic

	// CJK ecosystem
	case cp >= 0x3000 && cp <= 0x303F: return 0x0B // CJK Symbols & Punct
	case cp >= 0x3040 && cp <= 0x309F: return 0x08 // Hiragana
	case cp >= 0x30A0 && cp <= 0x30FF: return 0x09 // Katakana
	case cp >= 0x3100 && cp <= 0x312F: return 0x0B // Bopomofo
	case cp >= 0x3400 && cp <= 0x4DBF: return 0x0B // CJK Ext A
	case cp >= 0x4E00 && cp <= 0x9FFF: return 0x0B // CJK Unified
	case cp >= 0xF900 && cp <= 0xFAFF: return 0x0B // CJK Compat Ideographs
	case cp >= 0x20000 && cp <= 0x2A6DF: return 0x0B // CJK Ext B

	// Hangul
	case cp >= 0x1100 && cp <= 0x11FF: return 0x0C // Hangul Jamo
	case cp >= 0xAC00 && cp <= 0xD7AF: return 0x0C // Hangul Syllables
	case cp >= 0xA960 && cp <= 0xA97F: return 0x0C // Hangul Jamo Extended

	// Math & Technical
	case cp >= 0x2200 && cp <= 0x22FF: return 0x0D // Mathematical Operators
	case cp >= 0x2100 && cp <= 0x214F: return 0x0D // Letterlike Symbols
	case cp >= 0x2150 && cp <= 0x218F: return 0x0D // Number Forms
	case cp >= 0x27C0 && cp <= 0x27EF: return 0x0D // Misc Math A
	case cp >= 0x2980 && cp <= 0x29FF: return 0x0D // Misc Math B
	case cp >= 0x1D400 && cp <= 0x1D7FF: return 0x0D // Math Alphanumeric

	// Digits
	case cp >= 0x0030 && cp <= 0x0039: return 0x0E // ASCII digits
	case cp >= 0xFF10 && cp <= 0xFF19: return 0x0E // Fullwidth digits

	// Symbols & Misc
	case cp >= 0x2190 && cp <= 0x21FF: return 0x20 // Arrows
	case cp >= 0x2300 && cp <= 0x23FF: return 0x20 // Technical
	case cp >= 0x2400 && cp <= 0x243F: return 0x20 // Control Pictures
	case cp >= 0x2500 && cp <= 0x257F: return 0x20 // Box Drawing
	case cp >= 0x25A0 && cp <= 0x25FF: return 0x20 // Geometric Shapes
	case cp >= 0x2600 && cp <= 0x26FF: return 0x20 // Misc Symbols
	case cp >= 0x2700 && cp <= 0x27BF: return 0x20 // Dingbats
	case cp >= 0x2900 && cp <= 0x297F: return 0x20 // Supplemental Arrows
	case cp >= 0x3200 && cp <= 0x32FF: return 0x20 // Enclosed CJK
	case cp >= 0xFFF0 && cp <= 0xFFFF: return 0x20 // Specials

	// Emoji & Pictographs
	case cp >= 0x1F000 && cp <= 0x1F02F: return 0x21 // Mahjong / Domino
	case cp >= 0x1F0A0 && cp <= 0x1F0FF: return 0x21 // Playing Cards
	case cp >= 0x1F100 && cp <= 0x1F1FF: return 0x21 // Enclosed Alphanum Supp
	case cp >= 0x1F200 && cp <= 0x1F2FF: return 0x21 // Enclosed Ideo Supp
	case cp >= 0x1F300 && cp <= 0x1F5FF: return 0x21 // Misc Symbols & Pictographs
	case cp >= 0x1F600 && cp <= 0x1F64F: return 0x21 // Emoticons
	case cp >= 0x1F680 && cp <= 0x1F6FF: return 0x21 // Transport & Map
	case cp >= 0x1F700 && cp <= 0x1F77F: return 0x21 // Alchemical
	case cp >= 0x1F900 && cp <= 0x1F9FF: return 0x21 // Supplemental Symbols

	// Fullwidth & Halfwidth
	case cp >= 0xFF00 && cp <= 0xFFEF: return 0x00 // Fullwidth Latin → group with Latin

	default:
		return 0xFF // unknown
	}
}

// ─── Parse UnicodeData.txt ────────────────────────────────────────────────────

// ParseUnicodeData đọc UnicodeData.txt, trả về entries hữu ích
func ParseUnicodeData(path string) ([]unicodeEntry, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var entries []unicodeEntry
	scanner := bufio.NewScanner(f)

	// CJK ranges được khai báo dạng <First>..<Last> — cần mở rộng
	var cjkRangeFirst *unicodeEntry

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		parts := strings.Split(line, ";")
		if len(parts) < 15 {
			continue
		}

		cpHex := parts[0]
		name := parts[1]
		cat := parts[2]
		upperHex := parts[12]
		lowerHex := parts[13]

		// Parse codepoint
		cpVal, err := strconv.ParseUint(cpHex, 16, 32)
		if err != nil {
			continue
		}
		cp := uint32(cpVal)

		// Xử lý CJK range <..., First> → <..., Last>
		if strings.Contains(name, ", First>") {
			baseName := strings.ReplaceAll(name, "<", "")
			baseName = strings.ReplaceAll(baseName, ", First>", "")
			baseName = strings.TrimSpace(baseName)
			if usefulCats[cat] {
				e := unicodeEntry{cp: cp, name: baseName, cat: cat}
				e.scriptID = cpToScriptID(cp)
				e.groupID = catToGroupID(cat)
				cjkRangeFirst = &e
			}
			continue
		}
		if strings.Contains(name, ", Last>") {
			if cjkRangeFirst != nil {
				lastCP := cp
				// Expand range — thêm từng codepoint
				for c := cjkRangeFirst.cp; c <= lastCP; c++ {
					e := unicodeEntry{
						cp:       c,
						name:     fmt.Sprintf("%s U+%04X", cjkRangeFirst.name, c),
						cat:      cjkRangeFirst.cat,
						scriptID: cpToScriptID(c),
						groupID:  catToGroupID(cjkRangeFirst.cat),
					}
					entries = append(entries, e)
				}
				cjkRangeFirst = nil
			}
			continue
		}

		// Filter: chỉ lấy useful categories
		if !usefulCats[cat] {
			continue
		}

		// Skip control names
		if strings.HasPrefix(name, "<") {
			continue
		}

		var upper, lower uint32
		if upperHex != "" {
			if v, err := strconv.ParseUint(upperHex, 16, 32); err == nil {
				upper = uint32(v)
			}
		}
		if lowerHex != "" {
			if v, err := strconv.ParseUint(lowerHex, 16, 32); err == nil {
				lower = uint32(v)
			}
		}

		e := unicodeEntry{
			cp:       cp,
			name:     name,
			cat:      cat,
			upper:    upper,
			lower:    lower,
			scriptID: cpToScriptID(cp),
			groupID:  catToGroupID(cat),
		}
		entries = append(entries, e)
	}
	return entries, scanner.Err()
}

// ─── ISL builder ─────────────────────────────────────────────────────────────

// buildISL cho L1 node — dùng codepoint làm ID thay vì sequential counter.
// Lý do: ISL phải stable & unique kể cả khi seed lại từ đầu.
//
// Format: [0x01][scriptID][groupID][cp_byte3][cp_byte4][cp_byte5][cp_byte6][cp_byte7]
// → Đủ cho 5 bytes codepoint (Unicode max U+10FFFF = 3 bytes)
//
// b[0] = 0x01 (L1)
// b[1] = scriptID
// b[2] = groupID
// b[3..6] = cp big-endian uint32
// b[7] = 0
func buildL1ISL(e unicodeEntry) [8]byte {
	var isl [8]byte
	isl[0] = 0x01
	isl[1] = e.scriptID
	isl[2] = e.groupID
	binary.BigEndian.PutUint32(isl[3:7], e.cp)
	return isl
}

// ─── Bulk append (atomic batch) ──────────────────────────────────────────────

const bulkBatchSize = 500 // nodes per batch write

var bulkMu sync.Mutex

// BulkSeed đọc UnicodeData.txt và seed tất cả codepoints còn thiếu vào olangPath.
func BulkSeed(olangPath, unicodeDataPath string) (*BulkSeedResult, error) {
	t0 := time.Now()
	res := &BulkSeedResult{}

	// ── 1. Parse UnicodeData.txt ─────────────────────────────
	fmt.Printf("📖 Parsing %s ...\n", unicodeDataPath)
	entries, err := ParseUnicodeData(unicodeDataPath)
	if err != nil {
		return nil, fmt.Errorf("parse: %w", err)
	}
	res.Total = len(entries)
	fmt.Printf("   Parsed: %d entries\n", res.Total)

	// ── 2. Load existing codepoints ──────────────────────────
	fmt.Printf("🔍 Scanning existing nodes ...\n")
	existingCP, existingISL := loadExisting(olangPath)
	fmt.Printf("   Existing: %d codepoints\n", len(existingCP))

	// ── 3. Filter: chỉ seed những cái chưa có ───────────────
	var todo []unicodeEntry
	for _, e := range entries {
		if existingCP[e.cp] {
			res.Skipped++
			continue
		}
		isl := buildL1ISL(e)
		if existingISL[isl] {
			res.Skipped++
			continue
		}
		todo = append(todo, e)
	}
	fmt.Printf("   To seed: %d  (skip: %d)\n", len(todo), res.Skipped)

	// ── 4. Batch seed ────────────────────────────────────────
	total := len(todo)
	for start := 0; start < total; start += bulkBatchSize {
		end := start + bulkBatchSize
		if end > total {
			end = total
		}
		batch := todo[start:end]

		added, failed, err := appendBatch(olangPath, batch)
		res.Added += added
		res.Failed += failed
		if err != nil {
			fmt.Printf("   ❌ batch error: %v\n", err)
		}
		pct := float64(start+len(batch)) / float64(total) * 100
		fmt.Printf("\r   Progress: %d/%d (%.0f%%)  added=%d", start+len(batch), total, pct, res.Added)
	}
	fmt.Println()

	// ── 5. Recompute SHA256 ──────────────────────────────────
	if err := recomputeSHA256(olangPath); err != nil {
		return res, fmt.Errorf("sha256: %w", err)
	}

	res.Duration = time.Since(t0)
	return res, nil
}

// appendBatch ghi 1 batch nodes vào file atomically
func appendBatch(olangPath string, batch []unicodeEntry) (added, failed int, err error) {
	bulkMu.Lock()
	defer bulkMu.Unlock()

	raw, err := os.ReadFile(olangPath)
	if err != nil {
		return 0, len(batch), err
	}
	if len(raw) < 280 || string(raw[:4]) != "OLNG" {
		return 0, len(batch), fmt.Errorf("bad file")
	}

	// Parse layer index
	type linfo struct{ offset, size uint64; nnodes uint32 }
	layers := [9]linfo{}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		layers[i].offset = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].size   = binary.BigEndian.Uint64(raw[o+12 : o+20])
		layers[i].nnodes = binary.BigEndian.Uint32(raw[o+20 : o+24])
	}

	// Existing ISL index trong RAM (để dedup trong batch)
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	islSeen := make(map[[8]byte]bool, int(layers[1].nnodes))
	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		dl := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
		var isl [8]byte
		copy(isl[:], raw[pos+3:pos+11])
		islSeen[isl] = true
		pos += 20 + dl + nl
	}

	// Build records
	var recs []byte
	addedLocal := 0
	for _, e := range batch {
		isl := buildL1ISL(e)
		if islSeen[isl] {
			failed++
			continue
		}
		islSeen[isl] = true

		dna := buildL1DNA(e)
		name := buildL1Name(e)
		nb := []byte(name)
		if len(nb) > 255 { nb = nb[:255] }

		rec := make([]byte, 20+len(dna)+len(nb))
		rec[0] = 'N'; rec[1] = 'D'; rec[2] = 0x01
		copy(rec[3:11], isl[:])
		binary.BigEndian.PutUint32(rec[11:], e.cp)
		binary.BigEndian.PutUint32(rec[15:], uint32(len(dna)))
		rec[19] = uint8(len(nb))
		copy(rec[20:], dna)
		copy(rec[20+len(dna):], nb)

		recs = append(recs, rec...)
		addedLocal++
	}

	if addedLocal == 0 {
		return 0, failed, nil
	}

	// Insert vào sau cuối L1 layer (trước edge table)
	insertAt := uint64(0)
	if layers[1].size > 0 {
		insertAt = layers[1].offset + layers[1].size
	} else {
		insertAt = uint64(280)
		for i := 0; i >= 0; i-- {
			if layers[i].size > 0 {
				insertAt = layers[i].offset + layers[i].size
				break
			}
		}
	}

	// Đảm bảo insertAt không vượt edgeStart
	if insertAt > uint64(edgeStart) {
		insertAt = uint64(edgeStart)
	}

	// Assemble
	newFile := make([]byte, 0, len(raw)+len(recs))
	newFile = append(newFile, raw[:insertAt]...)
	newFile = append(newFile, recs...)
	newFile = append(newFile, raw[insertAt:]...)

	// Update header.nnodes
	oldN := binary.BigEndian.Uint32(newFile[12:16])
	binary.BigEndian.PutUint32(newFile[12:], oldN+uint32(addedLocal))

	// Update layer index
	delta := uint64(len(recs))
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		lo := binary.BigEndian.Uint64(newFile[o+4 : o+12])
		ls := binary.BigEndian.Uint64(newFile[o+12 : o+20])
		ln := binary.BigEndian.Uint32(newFile[o+20 : o+24])

		if i == 1 { // L1
			if ls == 0 { binary.BigEndian.PutUint64(newFile[o+4:], insertAt) }
			binary.BigEndian.PutUint64(newFile[o+12:], ls+delta)
			binary.BigEndian.PutUint32(newFile[o+20:], ln+uint32(addedLocal))
		} else if lo > 0 && lo >= insertAt {
			binary.BigEndian.PutUint64(newFile[o+4:], lo+delta)
		}
	}

	// SHA256 sẽ được recompute sau batch cuối — dùng .tmp
	tmp := olangPath + ".bulk.tmp"
	if err := os.WriteFile(tmp, newFile, 0644); err != nil {
		return 0, addedLocal + failed, err
	}
	if err := os.Rename(tmp, olangPath); err != nil {
		os.Remove(tmp)
		return 0, addedLocal + failed, err
	}

	return addedLocal, failed, nil
}

// buildL1DNA — DNA cho L1 ATOM node (metaDNA format)
func buildL1DNA(e unicodeEntry) []byte {
	dna := make([]byte, 9)
	dna[0] = 0x41 // QR(0x40)|ATOM(0x01)
	dna[1] = 0x14 // EMIT opcode
	bits := math.Float32bits(float32(e.cp))
	dna[2] = byte(bits >> 24)
	dna[3] = byte(bits >> 16)
	dna[4] = byte(bits >> 8)
	dna[5] = byte(bits)
	dna[6] = e.scriptID
	dna[7] = e.groupID
	return dna
}

// buildL1Name — tên node: "SYM_LATIN_CAPITAL_LETTER_A"
func buildL1Name(e unicodeEntry) string {
	name := strings.ToUpper(e.name)
	name = strings.ReplaceAll(name, " ", "_")
	name = strings.ReplaceAll(name, "-", "_")
	name = strings.ReplaceAll(name, "'", "")
	// Prefix dựa theo category
	prefix := "SYM"
	switch {
	case e.cat == "Lu" || e.cat == "Lt":
		prefix = "UC" // UpperCase
	case e.cat == "Ll":
		prefix = "LC" // LowerCase
	case e.cat == "Nd":
		prefix = "DG" // DiGit
	case e.cat == "Sm":
		prefix = "MT" // MaTh
	case e.cat == "So":
		prefix = "IC" // Icon/Symbol
	case e.cat == "Lo":
		prefix = "CH" // CHaracter (non-Latin letter)
	}
	full := prefix + "_" + name
	if len(full) > 48 {
		full = full[:48]
	}
	return full
}

// loadExisting đọc cả codepoints và ISL đã có trong file
func loadExisting(olangPath string) (map[uint32]bool, map[[8]byte]bool) {
	raw, _ := os.ReadFile(olangPath)
	cpMap  := make(map[uint32]bool)
	islMap := make(map[[8]byte]bool)
	if len(raw) < 280 { return cpMap, islMap }

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*21
	if edgeStart < 280 { edgeStart = 280 }

	for pos := 280; pos+20 < edgeStart; {
		if raw[pos] != 'N' || raw[pos+1] != 'D' { pos++; continue }
		layer := raw[pos+2]
		dl := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))
		nl := int(raw[pos+19])
		if dl <= 0 || dl > 65536 || nl > 255 { pos++; continue }
		end := pos + 20 + dl + nl
		if end > edgeStart { break }
		if layer == 0x01 {
			cp := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
			cpMap[cp] = true
			var isl [8]byte
			copy(isl[:], raw[pos+3:pos+11])
			islMap[isl] = true
		}
		pos = end
	}
	return cpMap, islMap
}

// recomputeSHA256 — tính lại SHA256 header sau khi bulk write
func recomputeSHA256(olangPath string) error {
	raw, err := os.ReadFile(olangPath)
	if err != nil { return err }
	sum := sha256.Sum256(raw[280:])
	copy(raw[28:60], sum[:])
	return os.WriteFile(olangPath, raw, 0644)
}
