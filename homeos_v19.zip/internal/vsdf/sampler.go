package vsdf

import (
	"math"
	"sort"

	"github.com/goldlotus1810/HomeOS/internal/gene"
)

// ═══════════════════════════════════════════════════════════════
// BƯỚC 1+2 — Ô cố định + chiếu vSDF
// ═══════════════════════════════════════════════════════════════

const (
	CellN   = 32
	CellMin = -0.5
	CellMax =  0.5
)

type SampleGrid struct {
	CP   uint32
	Data [CellN * CellN]float32
}

func SampleChar(cp uint32, sdf func(gene.Vec3) float64) *SampleGrid {
	g := &SampleGrid{CP: cp}
	step := (CellMax - CellMin) / float64(CellN-1)
	for row := 0; row < CellN; row++ {
		y := CellMax - float64(row)*step
		for col := 0; col < CellN; col++ {
			x := CellMin + float64(col)*step
			g.Data[row*CellN+col] = float32(sdf(gene.Vec3{X: x, Y: y}))
		}
	}
	return g
}

// ═══════════════════════════════════════════════════════════════
// BƯỚC 3 — Lan tỏa: tìm centerline của mỗi nét
// ═══════════════════════════════════════════════════════════════

type StrokeCandidate struct {
	X0, Y0   float32
	X1, Y1   float32
	MX, MY   float32
	IsCurve  bool
	Length   float32
	Angle    float32 // radian [0..π)
	Thickness float32
	CurveDev float32 // độ cong (0=thẳng)
	Score    float32
}

func ExtractStrokes(g *SampleGrid) []StrokeCandidate {
	step := (CellMax - CellMin) / float64(CellN-1)

	type cpt struct {
		x, y  float64
		angle float64
		used  bool
	}
	var centers []cpt

	for row := 1; row < CellN-1; row++ {
		y := CellMax - float64(row)*step
		for col := 1; col < CellN-1; col++ {
			x := CellMin + float64(col)*step
			d := float64(g.Data[row*CellN+col])
			if d > -0.01 || d < -0.12 { continue }

			// Gradient (finite diff)
			dx := float64(g.Data[row*CellN+(col+1)]-g.Data[row*CellN+(col-1)]) / (2 * step)
			dy := float64(g.Data[(row-1)*CellN+col]-g.Data[(row+1)*CellN+col]) / (2 * step)
			gLen := math.Sqrt(dx*dx + dy*dy)
			if gLen < 0.1 { continue }

			angle := math.Atan2(dy, dx)
			centers = append(centers, cpt{x, y, angle, false})
		}
	}
	if len(centers) < 4 { return nil }

	eps := step * 4.0
	var strokes []StrokeCandidate

	for i := range centers {
		if centers[i].used { continue }
		var clust []int
		for j := range centers {
			if centers[j].used { continue }
			dx := centers[i].x - centers[j].x
			dy := centers[i].y - centers[j].y
			if dx*dx+dy*dy < eps*eps { clust = append(clust, j) }
		}
		if len(clust) < 4 { continue }
		for _, k := range clust { centers[k].used = true }

		// Centroid
		cx, cy := 0.0, 0.0
		for _, k := range clust { cx += centers[k].x; cy += centers[k].y }
		cx /= float64(len(clust)); cy /= float64(len(clust))

		// PCA
		xx, xy, yy := 0.0, 0.0, 0.0
		for _, k := range clust {
			dx := centers[k].x - cx; dy := centers[k].y - cy
			xx += dx*dx; xy += dx*dy; yy += dy*dy
		}
		trace := xx + yy
		det := xx*yy - xy*xy
		disc := math.Sqrt(math.Max(0, trace*trace/4-det))
		lam := trace/2 + disc

		var dirX, dirY float64
		if math.Abs(xy) > 1e-10 {
			dirX = lam - yy; dirY = xy
		} else if xx > yy {
			dirX = 1; dirY = 0
		} else {
			dirX = 0; dirY = 1
		}
		dLen := math.Sqrt(dirX*dirX + dirY*dirY)
		if dLen < 1e-10 { continue }
		dirX /= dLen; dirY /= dLen

		// Extent
		minT, maxT := math.MaxFloat64, -math.MaxFloat64
		for _, k := range clust {
			t := (centers[k].x-cx)*dirX + (centers[k].y-cy)*dirY
			if t < minT { minT = t }
			if t > maxT { maxT = t }
		}
		if maxT-minT < 0.04 { continue }

		// Residual → curve detection
		residual := 0.0
		var maxResX, maxResY float64
		maxRes := 0.0
		for _, k := range clust {
			px := centers[k].x - cx; py := centers[k].y - cy
			d := math.Abs(px*(-dirY) + py*dirX)
			residual += d
			if d > maxRes { maxRes = d; maxResX = centers[k].x; maxResY = centers[k].y }
		}
		residual /= float64(len(clust))
		isCurve := residual > 0.025

		angle := float32(math.Atan2(dirY, dirX))
		if angle < 0 { angle += math.Pi }

		sc := StrokeCandidate{
			X0: float32(cx + dirX*minT), Y0: float32(cy + dirY*minT),
			X1: float32(cx + dirX*maxT), Y1: float32(cy + dirY*maxT),
			MX: float32(maxResX), MY: float32(maxResY),
			IsCurve:   isCurve,
			Length:    float32(maxT - minT),
			Angle:     angle,
			Thickness: 0.055,
			CurveDev:  float32(residual),
			Score:     float32(len(clust)),
		}
		strokes = append(strokes, sc)
	}
	return strokes
}

// ═══════════════════════════════════════════════════════════════
// BƯỚC 4 — Công thức toán học
// ═══════════════════════════════════════════════════════════════

type StrokeClass uint8

const (
	ClassV   StrokeClass = iota // │ Vertical
	ClassH                      // ─ Horizontal
	ClassD1                     // ╱ Diagonal up-right
	ClassD2                     // ╲ Diagonal down-right
	ClassCR                     // ) Curve right
	ClassCL                     // ( Curve left
	ClassCU                     // ∪ Curve up
	ClassCD                     // ∩ Curve down
	ClassDot                    // · Dot
	ClassArc                    // ○ Arc/circle
	ClassN    = 10
)

var classNames = [ClassN]string{"V","H","D1","D2","CR","CL","CU","CD","dot","arc"}
func (c StrokeClass) String() string {
	if c < ClassN { return classNames[c] }
	return "?"
}

type MolecularFormula struct {
	Class  StrokeClass
	Angle  uint8 // 0..255 = 0..π
	Length uint8 // 0..255 = 0..√2
	Curve  uint8 // 0=straight, 255=max curve
	X      uint8 // position 0..63
	Y      uint8 // position 0..63
}

func (sc *StrokeCandidate) ToFormula() MolecularFormula {
	a := float64(sc.Angle)
	for a < 0 { a += math.Pi }
	a = math.Mod(a, math.Pi)
	qa := uint8(a / math.Pi * 255)
	ql := uint8(math.Min(float64(sc.Length)/math.Sqrt2, 1) * 255)
	qc := uint8(math.Min(float64(sc.CurveDev)/0.15, 1) * 255)

	cx := (float64(sc.X0)+float64(sc.X1))/2
	cy := (float64(sc.Y0)+float64(sc.Y1))/2
	px := uint8(math.Max(0, math.Min(63, (cx-CellMin)/(CellMax-CellMin)*63)))
	py := uint8(math.Max(0, math.Min(63, (cy-CellMin)/(CellMax-CellMin)*63)))

	return MolecularFormula{
		Class: classifyStroke(sc),
		Angle: qa, Length: ql, Curve: qc,
		X: px, Y: py,
	}
}

func classifyStroke(sc *StrokeCandidate) StrokeClass {
	if float64(sc.Length) < 0.06 { return ClassDot }
	a := float64(sc.Angle)
	for a < 0 { a += math.Pi }
	deg := math.Mod(a, math.Pi) * 180 / math.Pi

	if sc.IsCurve {
		if float64(sc.Length) > 0.35 { return ClassArc }
		cx := (float64(sc.X0)+float64(sc.X1))/2
		cy := (float64(sc.Y0)+float64(sc.Y1))/2
		dx := float64(sc.MX) - cx
		dy := float64(sc.MY) - cy
		if math.Abs(dy) > math.Abs(dx) {
			if dy > 0 { return ClassCU } else { return ClassCD }
		}
		if dx > 0 { return ClassCR } else { return ClassCL }
	}
	if deg < 15 || deg > 165  { return ClassH }
	if deg > 75 && deg < 105  { return ClassV }
	if deg >= 15 && deg <= 75 { return ClassD1 }
	return ClassD2
}

// ═══════════════════════════════════════════════════════════════
// BƯỚC 5+6 — Cluster + Bảng mã phân tử
// ═══════════════════════════════════════════════════════════════

type MoleculeEntry struct {
	ID      uint8
	Class   StrokeClass
	AngleQ  uint8
	LengthQ uint8
	CurveQ  uint8
	Freq    int
	Name    string
}

type MoleculeTable struct {
	Entries []MoleculeEntry
	Index   map[uint32]uint8 // (class<<16|angleQ<<8|lengthQ) → id
}

func BuildMoleculeTable(allStrokes []StrokeCandidate) *MoleculeTable {
	type bucket struct{ class StrokeClass; aq, lq, cq uint8 }
	freq := make(map[bucket]int)
	for _, sc := range allStrokes {
		f := sc.ToFormula()
		freq[bucket{f.Class, f.Angle >> 4, f.Length >> 5, f.Curve >> 6}]++
	}

	type bf struct { b bucket; f int }
	var sorted []bf
	for b, f := range freq { sorted = append(sorted, bf{b, f}) }
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].f > sorted[j].f })

	t := &MoleculeTable{Index: make(map[uint32]uint8)}
	for i, item := range sorted {
		if i >= 255 { break }
		id := uint8(i + 1)
		size := [8]string{"xs","s","sm","m","ml","l","xl","xxl"}[item.b.lq]
		name := item.b.class.String() + "_" + size
		t.Entries = append(t.Entries, MoleculeEntry{
			ID: id, Class: item.b.class,
			AngleQ: item.b.aq, LengthQ: item.b.lq, CurveQ: item.b.cq,
			Freq: item.f, Name: name,
		})
		key := uint32(item.b.class)<<16 | uint32(item.b.aq)<<8 | uint32(item.b.lq)
		t.Index[key] = id
	}
	return t
}

func (mt *MoleculeTable) Lookup(f MolecularFormula) uint8 {
	if mt == nil || len(mt.Entries) == 0 { return 0 }
	bestID := uint8(0)
	bestDist := uint32(math.MaxUint32)
	aq := f.Angle >> 4; lq := f.Length >> 5; cq := f.Curve >> 6
	for _, e := range mt.Entries {
		if e.Class != f.Class { continue }
		da := absDiff8(e.AngleQ, aq)*2
		dl := absDiff8(e.LengthQ, lq)*2
		dc := absDiff8(e.CurveQ, cq)
		if d := uint32(da+dl+dc); d < bestDist { bestDist = d; bestID = e.ID }
	}
	return bestID
}

func absDiff8(a, b uint8) uint8 { if a>=b { return a-b }; return b-a }

// ─── Encode/Serialize ────────────────────────────────────────────────────

type GlyphMolecule struct{ MID, X, Y uint8 }

type MolecularGlyph struct {
	CP        uint32
	Molecules []GlyphMolecule
}

func EncodeGlyph(cp uint32, sdf func(gene.Vec3) float64, mt *MoleculeTable) *MolecularGlyph {
	grid := SampleChar(cp, sdf)
	strokes := ExtractStrokes(grid)
	g := &MolecularGlyph{CP: cp}
	for _, sc := range strokes {
		f := sc.ToFormula()
		mid := mt.Lookup(f)
		g.Molecules = append(g.Molecules, GlyphMolecule{MID: mid, X: f.X, Y: f.Y})
	}
	return g
}

func (g *MolecularGlyph) Bytes() []byte {
	n := len(g.Molecules)
	if n > 255 { n = 255 }
	b := make([]byte, 1+n*3)
	b[0] = uint8(n)
	for i := 0; i < n; i++ {
		b[1+i*3] = g.Molecules[i].MID
		b[2+i*3] = g.Molecules[i].X
		b[3+i*3] = g.Molecules[i].Y
	}
	return b
}

// ─── Serialize / Deserialize MoleculeTable ───────────────────────────────
// Format: [n(1B)] + [class(1B)+angleQ(1B)+lengthQ(1B)+curveQ(1B)+freq_hi(1B)+freq_lo(1B)] × n
// = 1 + n×6 bytes  (max n=255 → 1531B)

func (mt *MoleculeTable) Serialize() []byte {
	n := len(mt.Entries)
	if n > 255 { n = 255 }
	buf := make([]byte, 1+n*6)
	buf[0] = uint8(n)
	for i := 0; i < n; i++ {
		e := mt.Entries[i]
		f := e.Freq
		if f > 65535 { f = 65535 }
		buf[1+i*6] = uint8(e.Class)
		buf[2+i*6] = e.AngleQ
		buf[3+i*6] = e.LengthQ
		buf[4+i*6] = e.CurveQ
		buf[5+i*6] = uint8(f >> 8)
		buf[6+i*6] = uint8(f & 0xFF)
	}
	return buf
}

func DeserializeMoleculeTable(data []byte) *MoleculeTable {
	if len(data) < 1 { return &MoleculeTable{Index: make(map[uint32]uint8)} }
	n := int(data[0])
	if len(data) < 1+n*6 { return &MoleculeTable{Index: make(map[uint32]uint8)} }
	mt := &MoleculeTable{Index: make(map[uint32]uint8)}
	sizes := [8]string{"xs","s","sm","m","ml","l","xl","xxl"}
	for i := 0; i < n; i++ {
		class := StrokeClass(data[1+i*6])
		aq    := data[2+i*6]
		lq    := data[3+i*6]
		cq    := data[4+i*6]
		freq  := int(data[5+i*6])<<8 | int(data[6+i*6])
		id    := uint8(i + 1)
		name  := class.String() + "_" + sizes[lq&7]
		mt.Entries = append(mt.Entries, MoleculeEntry{
			ID: id, Class: class, AngleQ: aq, LengthQ: lq, CurveQ: cq,
			Freq: freq, Name: name,
		})
		key := uint32(class)<<16 | uint32(aq)<<8 | uint32(lq)
		mt.Index[key] = id
	}
	return mt
}
