package vsdf

import (
	"fmt"
	"math"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene/alphabet"
)

// ─── Fake "worst case" glyph: 57 strokes ─────────────────────────────────
func makeWorstCase(mt *MoleculeTable) *MolecularGlyph {
	g := &MolecularGlyph{CP: 0x9FFF}
	for i := 0; i < 57; i++ {
		angle := float64(i) / 57 * math.Pi
		x := 0.5 + math.Cos(angle)*0.4
		y := 0.5 + math.Sin(angle)*0.4
		g.Molecules = append(g.Molecules, GlyphMolecule{
			MID: uint8(i%len(mt.Entries) + 1),
			X:   uint8(x * 63),
			Y:   uint8(y * 63),
		})
	}
	return g
}

func buildTestTable() *MoleculeTable {
	var all []StrokeCandidate
	for _, ch := range alphabet.LatinUpper {
		if ch.SDF == nil { continue }
		all = append(all, ExtractStrokes(SampleChar(ch.Codepoint, ch.SDF))...)
	}
	return BuildMoleculeTable(all)
}

// ─── Benchmark: Decode → EvalSDF tại 1 pixel ────────────────────────────
func BenchmarkDecodeEval1px(b *testing.B) {
	mt := buildTestTable()
	g := makeWorstCase(mt)
	data := g.Bytes()

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		EvalSDF(data, 0.0, 0.0)
	}
}

// ─── Benchmark: render 1 glyph lên grid 32×32 (1024 pixels) ─────────────
func BenchmarkRender32x32(b *testing.B) {
	mt := buildTestTable()
	g := makeWorstCase(mt)
	data := g.Bytes()
	grid := make([]float32, 32*32)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		renderGrid(data, grid, 32)
	}
}

// ─── Benchmark: render 1 glyph lên grid 64×64 ───────────────────────────
func BenchmarkRender64x64(b *testing.B) {
	mt := buildTestTable()
	g := makeWorstCase(mt)
	data := g.Bytes()
	grid := make([]float32, 64*64)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		renderGrid(data, grid, 64)
	}
}

// ─── Benchmark: render full screen text (80 chars × 24 lines = 1920 chars)
func BenchmarkRenderScreen(b *testing.B) {
	mt := buildTestTable()

	// Encode tất cả Latin
	var glyphs [][]byte
	for _, ch := range alphabet.LatinUpper {
		if ch.SDF == nil { continue }
		gg := EncodeGlyph(ch.Codepoint, ch.SDF, mt)
		glyphs = append(glyphs, gg.Bytes())
	}

	grid := make([]float32, 16*16)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		// 1920 chars, mỗi char render 16×16
		for j := 0; j < 1920; j++ {
			renderGrid(glyphs[j%len(glyphs)], grid, 16)
		}
	}
}

// ─── Benchmark: worst case 57-stroke char, 16×16 ─────────────────────────
func BenchmarkWorstCase16x16(b *testing.B) {
	mt := buildTestTable()
	g := makeWorstCase(mt)
	data := g.Bytes()
	grid := make([]float32, 16*16)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		renderGrid(data, grid, 16)
	}
}

// ─── Render helper ────────────────────────────────────────────────────────
func renderGrid(data []byte, out []float32, res int) {
	step := 1.0 / float64(res-1)
	for row := 0; row < res; row++ {
		y := 1.0 - float64(row)*step
		for col := 0; col < res; col++ {
			x := float64(col) * step
			out[row*res+col] = float32(EvalSDF(data, x, y))
		}
	}
}

// ─── Manual timing test ──────────────────────────────────────────────────
func TestRenderTiming(t *testing.T) {
	mt := buildTestTable()
	worst := makeWorstCase(mt)
	worstData := worstData(worst)

	// Encode Latin chars
	var latinData [][]byte
	for _, ch := range alphabet.LatinUpper {
		if ch.SDF == nil { continue }
		gg := EncodeGlyph(ch.Codepoint, ch.SDF, mt)
		latinData = append(latinData, gg.Bytes())
	}

	grid16 := make([]float32, 16*16)
	grid32 := make([]float32, 32*32)
	grid64 := make([]float32, 64*64)

	type testCase struct {
		name string
		data []byte
		grid []float32
		res  int
	}

	cases := []testCase{
		{"worst(57 nét) 16×16",  worstData, grid16, 16},
		{"worst(57 nét) 32×32",  worstData, grid32, 32},
		{"worst(57 nét) 64×64",  worstData, grid64, 64},
		{"Latin avg 32×32",      latinData[0], grid32, 32},
	}

	for _, tc := range cases {
		N := 10000
		start := time.Now()
		for i := 0; i < N; i++ {
			renderGrid(tc.data, tc.grid, tc.res)
		}
		elapsed := time.Since(start)
		perChar := elapsed / time.Duration(N)
		fps60 := time.Second / 60
		charsPerFrame := fps60 / perChar

		t.Logf("%-22s: %6.1fµs/char  →  %5d chars/frame @60fps",
			tc.name, float64(perChar.Microseconds()), charsPerFrame)
	}

	// Screen render: 1920 chars × 16×16
	t.Log("")
	N := 1000
	start := time.Now()
	for i := 0; i < N; i++ {
		for j := 0; j < 1920; j++ {
			renderGrid(latinData[j%len(latinData)], grid16, 16)
		}
	}
	elapsed := time.Since(start)
	perFrame := elapsed / time.Duration(N)
	t.Logf("Full screen 80×24 @16px: %dms/frame → %.1f fps",
		perFrame.Milliseconds(), float64(time.Second)/float64(perFrame))

	fmt.Println()
}

func worstData(g *MolecularGlyph) []byte { return g.Bytes() }

// ─── Go kiến trúc: parallel render ───────────────────────────────────────
func TestParallelRender(t *testing.T) {
	mt := buildTestTable()
	worst := makeWorstCase(mt)
	data := worst.Bytes()
	grid := make([]float32, 32*32)

	// Single core
	N := 5000
	start := time.Now()
	for i := 0; i < N; i++ { renderGrid(data, grid, 32) }
	single := time.Since(start) / time.Duration(N)

	// Estimate multi-core (8 cores)
	multi := single / 8

	t.Logf("Single core:  %5.1fµs/char", float64(single.Microseconds()))
	t.Logf("8-core est:   %5.1fµs/char", float64(multi.Microseconds()))

	// Pixels/second
	pixels_per_char := 32 * 32
	pixels_per_sec_single := float64(pixels_per_char) / float64(single.Seconds())
	pixels_per_sec_multi  := float64(pixels_per_char) / float64(multi.Seconds())

	t.Logf("Throughput single: %.0f Mpx/s", pixels_per_sec_single/1e6)
	t.Logf("Throughput 8core:  %.0f Mpx/s", pixels_per_sec_multi/1e6)

	// 4K screen = 3840×2160 = 8.3M pixels
	// @60fps cần: 8.3M × 60 = 498M px/s
	need4k60 := 3840.0 * 2160.0 * 60.0
	t.Logf("\n4K@60fps cần: %.0f Mpx/s", need4k60/1e6)
	t.Logf("Single core đáp ứng: %.1f%%", pixels_per_sec_single/need4k60*100)
	t.Logf("8-core đáp ứng:      %.1f%%", pixels_per_sec_multi/need4k60*100)
	t.Logf("→ GPU cần: SDF eval = 1 shader, trivially parallel")
}
