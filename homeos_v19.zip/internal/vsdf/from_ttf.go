//go:build ignore
// +build ignore

// Standalone tool: python3 builder.py generates stroke_data.go
// This file documents the TTF extraction pipeline (Python side)
// For Go-side TTF extraction, use cmd/vsdf_gen/main.go

package vsdf
