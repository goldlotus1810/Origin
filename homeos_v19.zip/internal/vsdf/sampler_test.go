package vsdf

import (
	"fmt"
	"math"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/gene/alphabet"
)

// ─── Test toàn bộ pipeline trên Latin alphabet ───────────────────────────

func TestPipeline_LatinABC(t *testing.T) {
	chars := alphabet.LatinUpper
	if len(chars) == 0 {
		t.Fatal("LatinUpper empty")
	}

	// BƯỚC 5: thu thập strokes từ toàn bộ alphabet
	var allStrokes []StrokeCandidate
	for _, ch := range chars {
		if ch.SDF == nil { continue }
		grid := SampleChar(ch.Codepoint, ch.SDF)
		ss := ExtractStrokes(grid)
		allStrokes = append(allStrokes, ss...)
	}
	t.Logf("Total strokes extracted: %d from %d chars", len(allStrokes), len(chars))

	// BƯỚC 6: xây bảng phân tử
	mt := BuildMoleculeTable(allStrokes)
	t.Logf("Molecule table: %d entries", len(mt.Entries))

	if len(mt.Entries) == 0 {
		t.Fatal("Molecule table empty — stroke extraction failed")
	}

	// Show top 15 molecules
	t.Log("\nTop 15 molecules:")
	for i, e := range mt.Entries {
		if i >= 15 { break }
		t.Logf("  [%3d] %s  freq=%d", e.ID, e.Name, e.Freq)
	}

	// Distribution by class
	classDist := make(map[StrokeClass]int)
	for _, e := range mt.Entries { classDist[e.Class] += e.Freq }
	t.Log("\nClass distribution:")
	for c := StrokeClass(0); c < ClassN; c++ {
		if classDist[c] > 0 {
			t.Logf("  %-6s: %d", c, classDist[c])
		}
	}
}

func TestPipeline_EncodeChar(t *testing.T) {
	// Build table từ Latin
	var allStrokes []StrokeCandidate
	for _, ch := range alphabet.LatinUpper {
		if ch.SDF == nil { continue }
		ss := ExtractStrokes(SampleChar(ch.Codepoint, ch.SDF))
		allStrokes = append(allStrokes, ss...)
	}
	mt := BuildMoleculeTable(allStrokes)

	// Encode từng ký tự
	type result struct{ ch string; n int; bytes int }
	var results []result
	for _, ch := range alphabet.LatinUpper {
		if ch.SDF == nil { continue }
		g := EncodeGlyph(ch.Codepoint, ch.SDF, mt)
		results = append(results, result{ch.Glyph, len(g.Molecules), len(g.Bytes())})
	}

	t.Log("\nEncoded chars:")
	totalBytes := 0
	for _, r := range results {
		t.Logf("  '%s': %d molecules × 3B = %dB", r.ch, r.n, r.bytes)
		totalBytes += r.bytes
	}
	avgB := float64(totalBytes) / float64(len(results))
	t.Logf("\nAvg: %.1fB/char", avgB)
	t.Logf("Est 160K chars: %.2fMB", avgB*160000/1024/1024)
}

func TestPipeline_ASCII_Render(t *testing.T) {
	// Build table
	var allStrokes []StrokeCandidate
	for _, ch := range alphabet.LatinUpper {
		if ch.SDF == nil { continue }
		ss := ExtractStrokes(SampleChar(ch.Codepoint, ch.SDF))
		allStrokes = append(allStrokes, ss...)
	}
	mt := BuildMoleculeTable(allStrokes)

	// Encode + decode + render 'A', 'H', 'O'
	targets := []byte{'A', 'H', 'O'}
	for _, target := range targets {
		var ch *alphabet.OlangChar
		for _, c := range alphabet.LatinUpper {
			if c.Codepoint == uint32(target) { ch = c; break }
		}
		if ch == nil || ch.SDF == nil { continue }

		g := EncodeGlyph(ch.Codepoint, ch.SDF, mt)
		fmt.Printf("\n'%s' → %d molecules:\n", ch.Glyph, len(g.Molecules))
		for _, m := range g.Molecules {
			// Find entry
			var name string
			for _, e := range mt.Entries { if e.ID == m.MID { name = e.Name; break } }
			fmt.Printf("  [%3d] %-12s x=%d y=%d\n", m.MID, name, m.X, m.Y)
		}

		// ASCII render từ original SDF (để verify)
		fmt.Printf("Original '%s' (32×16):\n", ch.Glyph)
		res := 16
		for row := 0; row < res; row++ {
			y := 0.44 - float64(row)/float64(res-1)*0.88
			line := ""
			for col := 0; col < res*2; col++ {
				x := -0.28 + float64(col)/float64(res*2-1)*0.56
				d := ch.SDF(gene.Vec3{X: x, Y: y})
				if d < 0 { line += "█" } else if d < 0.06 { line += "·" } else { line += " " }
			}
			fmt.Printf("  |%s|\n", line)
		}
	}
}

func TestSampleGrid_Values(t *testing.T) {
	// Test sample grid với SDF đơn giản: hình tròn
	circle := func(p gene.Vec3) float64 {
		return math.Sqrt(p.X*p.X+p.Y*p.Y) - 0.3
	}
	grid := SampleChar(0x4F, circle) // 'O'

	// Center phải < 0 (bên ngoài vòng)
	center := grid.Data[CellN/2*CellN+CellN/2]
	edge   := grid.Data[CellN/2*CellN+int(CellN*8/10)]
	t.Logf("Center SDF: %.3f (expect ≈ -0.3)", center)
	t.Logf("Edge SDF:   %.3f (expect ≈ 0)", edge)
	if float64(center) > 0 {
		t.Errorf("Center should be inside circle (< 0), got %.3f", center)
	}
}
