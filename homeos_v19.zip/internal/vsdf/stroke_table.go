// Package vsdf — Molecular Stroke Encoding
// Mỗi glyph = chuỗi tham chiếu vào stroke table + radical table
// Giống mã hóa chuỗi phân tử: amino acid → protein
//
// Format:
//   Stroke Table  : 256 entries × 5B  = 1.25KB
//   Radical Table : 256 entries × 32B = 8KB
//   Glyph:
//     Latin/simple : 0x00 + n(1B) + [sid(1B)+x(1B)+y(1B)]×n
//     CJK          : 0x01 + n(1B) + [rid(1B)+x(1B)+y(1B)+scale(1B)]×n
//     Empty        : 0x02
package vsdf

import (
	"math"
)

// ─── Stroke Shape (5 bytes) ───────────────────────────────────────────────
//   type(1B): 0=Line 1=Curve
//   angle(1B): 0..255 = 0..360° (Line: direction, Curve: end angle)
//   ctrl(1B):  Curve: control angle 0..255; Line: 0
//   length(1B): 0..255 = 0%..100% of em-square diagonal
//   flags(1B):  reserved
type StrokeShape struct {
	Type   uint8 // 0=Line 1=Curve
	Angle  uint8 // direction 0..255 = 0..2π
	Ctrl   uint8 // curve control angle
	Length uint8 // relative length 0..255
	Flags  uint8
}

// ─── Stroke Instance (3 bytes dalam glyph) ───────────────────────────────
//   sid(1B): index vào StrokeTable
//   x(1B): 0..255 = 0%..100% em-square width
//   y(1B): 0..255 = 0%..100% em-square height
type StrokeInst struct {
	SID uint8
	X   uint8
	Y   uint8
}

// ─── Radical Instance (4 bytes trong glyph CJK) ──────────────────────────
//   rid(1B): index vào RadicalTable
//   x(1B):   position
//   y(1B):   position
//   scale(1B): 0..255 = 25%..200%
type RadicalInst struct {
	RID   uint8
	X     uint8
	Y     uint8
	Scale uint8
}

// ─── Glyph encoding ──────────────────────────────────────────────────────
const (
	GlyphTypeSimple  = 0x00 // Latin, Greek, Arabic, ...
	GlyphTypeCJK     = 0x01 // CJK — dùng radical refs
	GlyphTypeEmpty   = 0x02 // không có glyph (placeholder)
)

// ─── Stroke Table: 256 canonical stroke shapes ───────────────────────────
// Được build từ toàn bộ Noto font collection
// Đây là "bảng amino acid" của hệ thống
var StrokeTable [256]StrokeShape

// ─── Radical Table: 256 canonical radicals ───────────────────────────────
// 214 Kangxi radicals + common Latin composites
// Mỗi radical = list StrokeInst (tối đa 16 strokes)
type RadicalDef struct {
	Name    string // ví dụ "sanzui", "radical_person"
	NStroke uint8
	Strokes [16]StrokeInst
}

var RadicalTable [256]RadicalDef

// ─── Math helpers ─────────────────────────────────────────────────────────

func angleToUint8(rad float64) uint8 {
	// Normalize 0..2π → 0..255
	for rad < 0 { rad += 2 * math.Pi }
	rad = math.Mod(rad, 2*math.Pi)
	return uint8(rad / (2 * math.Pi) * 255)
}

func uint8ToAngle(a uint8) float64 {
	return float64(a) / 255.0 * 2 * math.Pi
}

func lengthToUint8(l float64) uint8 {
	// l = 0..√2 (diagonal of unit square)
	v := l / math.Sqrt2
	if v > 1 { v = 1 }
	return uint8(v * 255)
}

func uint8ToLength(l uint8) float64 {
	return float64(l) / 255.0 * math.Sqrt2
}

func posToUint8(v float64) uint8 {
	if v < 0 { v = 0 }
	if v > 1 { v = 1 }
	return uint8(v * 255)
}

func uint8ToPos(v uint8) float64 {
	return float64(v) / 255.0
}

func scaleToUint8(s float64) uint8 {
	// 0.25..2.0 → 0..255
	s = (s - 0.25) / 1.75
	if s < 0 { s = 0 }
	if s > 1 { s = 1 }
	return uint8(s * 255)
}

func uint8ToScale(s uint8) float64 {
	return 0.25 + float64(s)/255.0*1.75
}
