package vsdf

import "math"

// ─── Decoded stroke for rendering ────────────────────────────────────────
type RenderedStroke struct {
	X0, Y0 float64 // start [0..1]
	X1, Y1 float64 // end
	MX, MY float64 // control (Curve)
	IsCurve bool
	Radius  float64 // stroke width
}

// ─── Decode molecular bytes → []RenderedStroke ───────────────────────────
func Decode(data []byte) []RenderedStroke {
	if len(data) == 0 { return nil }
	switch data[0] {
	case GlyphTypeEmpty: return nil
	case GlyphTypeSimple: return decodeSimple(data[1:])
	case GlyphTypeCJK:    return decodeCJK(data[1:])
	}
	return nil
}

func decodeSimple(data []byte) []RenderedStroke {
	if len(data) < 2 { return nil }
	n := int(data[0])
	data = data[1:]
	res := make([]RenderedStroke, 0, n)
	for i := 0; i < n && len(data) >= 3; i++ {
		sid := data[0]; x0 := data[1]; y0 := data[2]
		data = data[3:]
		rs := strokeFromTable(sid, x0, y0, 255)
		if rs != nil { res = append(res, *rs) }
	}
	return res
}

func decodeCJK(data []byte) []RenderedStroke {
	if len(data) < 2 { return nil }
	n := int(data[0])
	data = data[1:]
	var res []RenderedStroke
	for i := 0; i < n && len(data) >= 4; i++ {
		rid := data[0]; x := data[1]; y := data[2]; scale := data[3]
		data = data[4:]
		res = append(res, radicalToStrokes(rid, x, y, scale)...)
	}
	return res
}

// strokeFromTable: rebuild stroke geometry từ table
func strokeFromTable(sid, x0, y0, scale uint8) *RenderedStroke {
	if sid == 0 || sid >= 255 { return nil }
	shape := StrokeTable[sid]
	angle := uint8ToAngle(shape.Angle)
	length := uint8ToLength(shape.Length) * uint8ToScale(scale)
	px := uint8ToPos(x0)
	py := uint8ToPos(y0)
	x1 := px + math.Cos(angle)*length
	y1 := py + math.Sin(angle)*length

	rs := &RenderedStroke{
		X0: px, Y0: py,
		X1: x1, Y1: y1,
		Radius: 0.035,
	}
	if shape.Type == 1 {
		ctrl := uint8ToAngle(shape.Ctrl)
		cl := length * 0.5
		rs.MX = px + math.Cos(ctrl)*cl
		rs.MY = py + math.Sin(ctrl)*cl
		rs.IsCurve = true
	}
	return rs
}

// radicalToStrokes: expand radical → individual strokes, transform by x/y/scale
func radicalToStrokes(rid, rx, ry, rscale uint8) []RenderedStroke {
	if rid == 0 { return nil }
	r := &RadicalTable[rid]
	if r.NStroke == 0 { return nil }

	ox := uint8ToPos(rx)
	oy := uint8ToPos(ry)
	sc := uint8ToScale(rscale)

	var res []RenderedStroke
	for j := 0; j < int(r.NStroke); j++ {
		si := r.Strokes[j]
		if si.SID == 0 { continue }
		shape := StrokeTable[si.SID]
		angle  := uint8ToAngle(shape.Angle)
		length := uint8ToLength(shape.Length) * sc
		lx := uint8ToPos(si.X)*sc + ox
		ly := uint8ToPos(si.Y)*sc + oy
		x1 := lx + math.Cos(angle)*length
		y1 := ly + math.Sin(angle)*length
		rs := RenderedStroke{
			X0: lx, Y0: ly,
			X1: x1, Y1: y1,
			Radius: 0.035 * sc,
		}
		if shape.Type == 1 {
			ctrl := uint8ToAngle(shape.Ctrl)
			cl := length * 0.5
			rs.MX = lx + math.Cos(ctrl)*cl
			rs.MY = ly + math.Sin(ctrl)*cl
			rs.IsCurve = true
		}
		res = append(res, rs)
	}
	return res
}

// ─── SDF evaluation ──────────────────────────────────────────────────────
// Dùng cho renderer: evaluate SDF tại point (px,py)

func EvalSDF(data []byte, px, py float64) float64 {
	strokes := Decode(data)
	if len(strokes) == 0 { return 1e9 }
	d := 1e9
	for _, s := range strokes {
		sd := capsuleSDF(px, py, s.X0, s.Y0, s.X1, s.Y1, s.Radius)
		if sd < d { d = sd }
	}
	return d
}

func capsuleSDF(px, py, ax, ay, bx, by, r float64) float64 {
	abx, aby := bx-ax, by-ay
	apx, apy := px-ax, py-ay
	ab2 := abx*abx + aby*aby
	t := 0.0
	if ab2 > 0 {
		t = (apx*abx + apy*aby) / ab2
		if t < 0 { t = 0 } else if t > 1 { t = 1 }
	}
	qx := px - (ax + abx*t)
	qy := py - (ay + aby*t)
	return math.Sqrt(qx*qx+qy*qy) - r
}
