package vsdf

import (
	"bytes"
	"math"
)

// ─── Encoder ─────────────────────────────────────────────────────────────
// Encode một glyph từ TTF path segments → molecular bytes

// RawStroke = 1 path segment đã normalized (position + shape)
type RawStroke struct {
	Type       byte    // 'L' or 'C'
	X0, Y0     float64 // start position [0..1]
	X1, Y1     float64 // end position
	MX, MY     float64 // control point (Curve only)
	DX, DY     float64 // direction vector
	Len        float64 // length [0..√2]
}

// shapeKey tính toán key để tra stroke table
func shapeKey(s RawStroke) (byte, byte, byte) {
	// angle (0..255 = 0..2π)
	angle := math.Atan2(s.DY, s.DX)
	for angle < 0 { angle += 2 * math.Pi }
	angle = math.Mod(angle, 2*math.Pi)
	// quantize to 32 levels
	qa := uint8(math.Round(angle/(2*math.Pi)*32) / 32 * 255)

	// length (0..255)
	ql := lengthToUint8(s.Len)

	// curve control (0..255)
	var qc uint8
	if s.Type == 'C' {
		ca := math.Atan2(s.MY, s.MX)
		for ca < 0 { ca += 2 * math.Pi }
		ca = math.Mod(ca, 2*math.Pi)
		qc = uint8(math.Round(ca/(2*math.Pi)*16) / 16 * 255)
	}
	return qa, qc, ql
}

// findStrokeID tìm stroke trong table gần nhất
func findStrokeID(s RawStroke) uint8 {
	stype := uint8(0)
	if s.Type == 'C' { stype = 1 }
	qa, qc, ql := shapeKey(s)

	bestID := uint8(0)
	bestDist := uint32(math.MaxUint32)

	for id := 1; id < 256; id++ {
		e := StrokeTable[id]
		if e.Type != stype { continue }
		da := abs8(e.Angle, qa)
		dc := abs8(e.Ctrl, qc)
		dl := abs8(e.Length, ql)
		dist := uint32(da)*2 + uint32(dc) + uint32(dl)*2
		if dist < bestDist {
			bestDist = dist
			bestID = uint8(id)
		}
	}
	return bestID
}

func abs8(a, b uint8) uint8 {
	if a >= b { return a - b }
	return b - a
}

// ─── EncodeSimple: Latin/Greek/Arabic/etc ────────────────────────────────
// Output: [0x00][n_strokes(1B)][stroke_inst×n]
// Mỗi stroke_inst = [sid(1B)][x(1B)][y(1B)] = 3B
func EncodeSimple(strokes []RawStroke) []byte {
	var buf bytes.Buffer
	buf.WriteByte(GlyphTypeSimple)
	n := len(strokes)
	if n > 255 { n = 255 }
	buf.WriteByte(uint8(n))
	for i := 0; i < n; i++ {
		s := strokes[i]
		sid := findStrokeID(s)
		x   := posToUint8(s.X0)
		y   := posToUint8(s.Y0)
		buf.Write([]byte{sid, x, y})
	}
	return buf.Bytes()
}

// ─── EncodeCJK: CJK — dùng radical refs ─────────────────────────────────
// Output: [0x01][n_radicals(1B)][radical_inst×n]
// Mỗi radical_inst = [rid(1B)][x(1B)][y(1B)][scale(1B)] = 4B
// Nếu không match radical → fallback về EncodeSimple
func EncodeCJK(strokes []RawStroke) []byte {
	// Thử group strokes thành radicals
	// Simple heuristic: mỗi contour = 1 radical
	radicals := groupIntoRadicals(strokes)
	if len(radicals) == 0 {
		return EncodeSimple(strokes)
	}

	var buf bytes.Buffer
	buf.WriteByte(GlyphTypeCJK)
	n := len(radicals)
	if n > 255 { n = 255 }
	buf.WriteByte(uint8(n))
	for i := 0; i < n; i++ {
		r := radicals[i]
		buf.Write([]byte{r.RID, r.X, r.Y, r.Scale})
	}
	return buf.Bytes()
}

// groupIntoRadicals: group stroke sequences → radical instances
// Dùng stroke pattern matching với RadicalTable
func groupIntoRadicals(strokes []RawStroke) []RadicalInst {
	var result []RadicalInst

	i := 0
	for i < len(strokes) {
		best, n := matchRadical(strokes, i)
		if best == 0 || n == 0 {
			i++
			continue
		}
		// Position = centroid của n strokes
		cx, cy := 0.0, 0.0
		for j := i; j < i+n && j < len(strokes); j++ {
			cx += strokes[j].X0
			cy += strokes[j].Y0
		}
		cx /= float64(n); cy /= float64(n)
		result = append(result, RadicalInst{
			RID:   best,
			X:     posToUint8(cx),
			Y:     posToUint8(cy),
			Scale: scaleToUint8(1.0),
		})
		i += n
	}
	return result
}

// matchRadical: tìm radical khớp nhất với strokes[start:]
// Trả về (radical_id, n_strokes_consumed)
func matchRadical(strokes []RawStroke, start int) (uint8, int) {
	bestID := uint8(0)
	bestScore := -1
	bestN := 0

	avail := len(strokes) - start
	if avail <= 0 { return 0, 0 }

	for rid := 1; rid < 256; rid++ {
		r := &RadicalTable[rid]
		if r.NStroke == 0 { continue }
		n := int(r.NStroke)
		if n > avail { n = avail }

		score := 0
		for j := 0; j < n; j++ {
			ts := strokes[start+j]
			rs := r.Strokes[j]
			if rs.SID == 0 { continue }
			sid := findStrokeID(ts)
			if sid == rs.SID { score += 2 } else if abs8(sid, rs.SID) < 10 { score++ }
		}

		if score > bestScore && score >= n {
			bestScore = score
			bestID = uint8(rid)
			bestN = n
		}
	}
	return bestID, bestN
}

// ─── EncodeEmpty ─────────────────────────────────────────────────────────
func EncodeEmpty() []byte {
	return []byte{GlyphTypeEmpty}
}

// ─── IsCJK ───────────────────────────────────────────────────────────────
func IsCJK(cp rune) bool {
	return (cp >= 0x4E00 && cp <= 0x9FFF) ||
		(cp >= 0x3400 && cp <= 0x4DBF) ||
		(cp >= 0x20000 && cp <= 0x2A6DF) ||
		(cp >= 0xF900 && cp <= 0xFAFF)
}

// ─── GetGlyphDNA: lấy SDF bytes từ DNA slice ─────────────────────────────
func GetGlyphDNA(dna []byte) []byte {
	if len(dna) == 0 { return EncodeEmpty() }
	return dna
}
