#!/usr/bin/env python3
"""
Build stroke table + radical table từ Noto fonts
Output: stroke_data.go — Go source với các table được init
"""

import math, glob, struct, sys
from fontTools.ttLib import TTFont
from fontTools.pens.recordingPen import RecordingPen
from collections import defaultdict

NOTO_DIR = '/usr/share/fonts/truetype/noto/'
OTF_DIR  = '/usr/share/fonts/opentype/noto/'

# ─── Extract & normalize ─────────────────────────────────────────────────

def extract_strokes(gname, gs):
    pen = RecordingPen()
    try: gs[gname].draw(pen)
    except: return [], (0,1,0,1)
    pts=[]; ops=[]
    cur=None
    for op,args in pen.value:
        if op=='moveTo': cur=args[0]; pts.append(cur)
        elif op=='lineTo':
            if cur: ops.append(('L',cur,args[0])); cur=args[0]; pts.append(cur)
        elif op in('qCurveTo','curveTo'):
            end=args[-1]; mid=args[len(args)//2]
            if cur: ops.append(('C',cur,mid,end)); cur=end; pts.append(cur)
        elif op=='endPath': cur=None
    if not pts: return [],( 0,1,0,1)
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys)
    scale=max(xmax-xmin,ymax-ymin,1)
    def n(pt): return ((pt[0]-xmin)/scale,(pt[1]-ymin)/scale)
    res=[]
    for od in ops:
        if od[0]=='L':
            p0,p1=od[1],od[2]
            dx,dy=(p1[0]-p0[0])/scale,(p1[1]-p0[1])/scale
            l=math.sqrt(dx*dx+dy*dy)
            if l<0.02: continue
            res.append({'type':'L','p0':n(p0),'p1':n(p1),'dx':dx,'dy':dy,'len':l})
        elif od[0]=='C':
            p0,pm,p1=od[1],od[2],od[3]
            dx,dy=(p1[0]-p0[0])/scale,(p1[1]-p0[1])/scale
            mx,my=(pm[0]-p0[0])/scale,(pm[1]-p0[1])/scale
            l=math.sqrt(dx*dx+dy*dy)
            if l<0.02: continue
            res.append({'type':'C','p0':n(p0),'p1':n(p1),'pm':(mx,my),'dx':dx,'dy':dy,'len':l})
    return res, (xmin,xmax,ymin,ymax)

def stroke_shape_key(s, levels_angle=32, levels_len=16):
    """Shape key (bỏ position) để cluster"""
    angle = math.atan2(s['dy'], s['dx']) % (2*math.pi)
    qa = round(angle/(2*math.pi)*levels_angle)/levels_angle
    ql = round(s['len']*levels_len)/levels_len
    if s['type']=='C':
        mx,my=s['pm']
        ca=math.atan2(my,mx)%(2*math.pi)
        qca=round(ca/(2*math.pi)*levels_angle//2)/(levels_angle//2)
        return ('C',qa,qca,ql)
    return ('L',qa,ql)

def shape_to_bytes(key):
    """Convert shape key → 5 bytes"""
    if key[0]=='L':
        _,qa,ql=key
        angle=int(qa*255)&0xFF
        length=int(min(ql/math.sqrt(2),1)*255)&0xFF
        return bytes([0,angle,0,length,0])
    else:
        _,qa,qca,ql=key
        angle=int(qa*255)&0xFF
        ctrl=int(qca*255)&0xFF
        length=int(min(ql/math.sqrt(2),1)*255)&0xFF
        return bytes([1,angle,ctrl,length,0])

# ─── Main build ───────────────────────────────────────────────────────────

print("Phase 1: Collect all stroke shapes...", file=sys.stderr)
shape_freq = defaultdict(int)
all_paths = (sorted(glob.glob(NOTO_DIR+'NotoSans*-Regular.ttf')) +
             sorted(glob.glob(OTF_DIR+'NotoSansCJK*-Regular.ttc')))

total_g=0
for path in all_paths:
    try:
        f=TTFont(path,lazy=True,fontNumber=0)
        cmap=f.getBestCmap() or {}
        gs=f.getGlyphSet()
        for cp,gname in cmap.items():
            ss,_=extract_strokes(gname,gs)
            for s in ss: shape_freq[stroke_shape_key(s)]+=1
            total_g+=1
        f.close()
    except: pass

print(f"  Glyphs: {total_g:,}  Unique shapes: {len(shape_freq):,}", file=sys.stderr)

# Top 255 shapes (0xFF = inline escape)
top255 = sorted(shape_freq.items(),key=lambda x:-x[1])[:255]
shape_table = {k:i+1 for i,(k,_) in enumerate(top255)}  # 1-indexed, 0=undefined
print(f"  Top 255 coverage: {sum(v for k,v in top255)/sum(shape_freq.values())*100:.1f}%", file=sys.stderr)

# ─── Kangxi 214 radicals ─────────────────────────────────────────────────
# Map Unicode code points của 214 Kangxi radicals
KANGXI = [
    0x4E00,0x4E28,0x4E36,0x4E3F,0x4E59,0x4E85,0x4E8C,0x4EA0,
    0x4EBA,0x5182,0x5196,0x51AB,0x51E0,0x51F5,0x5200,0x529B,
    0x52F9,0x5315,0x531A,0x5338,0x5341,0x535C,0x5369,0x5382,
    0x53B6,0x53C8,0x53E3,0x56D7,0x571F,0x58EB,0x5902,0x590A,
    0x5915,0x5927,0x5973,0x5B50,0x5B80,0x5BF8,0x5C0F,0x5C22,
    0x5C38,0x5C6E,0x5C71,0x5DDB,0x5DE5,0x5DF1,0x5DFE,0x5E72,
    0x5E9A,0x5EF4,0x5EFE,0x5F0B,0x5F13,0x5F50,0x5F61,0x5F73,
    0x5FC3,0x6208,0x6236,0x624B,0x652F,0x6534,0x6587,0x6597,
    0x65A4,0x65B9,0x65E0,0x65E5,0x66F0,0x6708,0x6728,0x6B20,
    0x6B62,0x6B79,0x6BB3,0x6BCB,0x6BD4,0x6BDB,0x6C0F,0x6C14,
    0x6C34,0x706B,0x722A,0x7236,0x723B,0x723F,0x7247,0x7259,
    0x725B,0x72AC,0x7384,0x7389,0x74DC,0x74E6,0x7518,0x751F,
    0x7528,0x7530,0x758B,0x7592,0x7676,0x767D,0x76AE,0x76BF,
    0x76EE,0x76F4,0x76F8,0x7701,0x771F,0x77E2,0x77F3,0x793A,
    0x79B8,0x79BE,0x7A74,0x7ACB,0x7B52,0x7C73,0x7CF8,0x7F36,
    0x7F51,0x7F8A,0x7FBD,0x8001,0x800C,0x8012,0x8033,0x807F,
    0x8089,0x81E3,0x81EA,0x81F3,0x81FC,0x820C,0x821B,0x821F,
    0x826E,0x8272,0x8278,0x864D,0x866B,0x8840,0x884C,0x8863,
    0x897E,0x898B,0x89D2,0x8A00,0x8C37,0x8C46,0x8C55,0x8C78,
    0x8C9D,0x8D64,0x8D70,0x8DB3,0x8EAB,0x8ECA,0x8F9B,0x8FB0,
    0x8FB5,0x9091,0x9149,0x91C6,0x91CC,0x91D1,0x9577,0x9580,
    0x961C,0x96B6,0x96B9,0x96E8,0x9751,0x975E,0x9762,0x9769,
    0x97CB,0x97ED,0x97F3,0x9801,0x98A8,0x98DB,0x98DF,0x9996,
    0x9999,0x99AC,0x9AA8,0x9AD8,0x9ADF,0x9B25,0x9B2F,0x9B32,
    0x9B3C,0x9B5A,0x9CE5,0x9E75,0x9E7F,0x9EA5,0x9EBB,0x9EC3,
    0x9ECD,0x9ED1,0x9EF9,0x9EFD,0x9F0E,0x9F13,0x9F20,0x9F3B,
    0x9F4A,0x9F52,0x9F8D,0x9F9C,0x9FA0,
]

# ─── Generate Go source ───────────────────────────────────────────────────
print("Phase 2: Generate Go source...", file=sys.stderr)

out = []
out.append('// Code generated by builder.py — DO NOT EDIT')
out.append('// Molecular Stroke Encoding tables')
out.append('package vsdf')
out.append('')
out.append('func init() {')
out.append('\tinitStrokeTable()')
out.append('\tinitRadicalTable()')
out.append('}')
out.append('')

# StrokeTable init
out.append('func initStrokeTable() {')
out.append('\t// 255 canonical stroke shapes (index 0 = undefined)')
for i,(key,freq) in enumerate(top255):
    b = shape_to_bytes(key)
    comment = f"// freq={freq} key={key[0]}"
    out.append(f'\tStrokeTable[{i+1}] = StrokeShape{{{b[0]},{b[1]},{b[2]},{b[3]},{b[4]}}} {comment}')
out.append('}')
out.append('')

# RadicalTable init — load actual glyph data for each Kangxi radical
out.append('func initRadicalTable() {')
out.append('\t// 214 Kangxi radicals (index 1..214)')

# Load NotoSansCJK for radical glyphs
cjk_font = None
for p in glob.glob(OTF_DIR+'NotoSansCJK*-Regular.ttc'):
    try: cjk_font=TTFont(p,lazy=False,fontNumber=0); break
    except: pass
if not cjk_font:
    for p in glob.glob(OTF_DIR+'NotoSansCJK*.otf'):
        try: cjk_font=TTFont(p,lazy=False,fontNumber=0); break
        except: pass

radical_names = [
    "yi","gun","zhu","pie","yi2","jue","er","tou","ren","er2",
    "dao","li","ji","fen","dao2","li2","bao","bi","fang","xi",
    "shi","bo","you","han","si","you2","kou","wei","tu","shi2",
    "xi2","zhi","xi3","da","nü","zi","mian","cun","xiao","wang",
    "shi3","gong","shan","chuan","gong2","ji2","ji3","gan",
    "yao","ji4","fei","shi4","gong3","tu2","shan2","chi",
    "xin","ge","hu","shou","zhi2","pu","wen","dou","jin",
    "fang2","wu","ri","yue","yue2","mu","qian","zhi3","sui",
    "e","bi","mao","qi","shui","huo","zhua","fu","qiang",
    "ji5","niu","quan","xuan","yu","gua","wa","sheng","yong",
    "tian","pi","su","bai","ge2","bai2","pi2","min","mu2",
    "zhi4","yi3","shi5","shi6","zhi5","ya","shi7","bing",
    "he","he2","mi","shu","si2","wang2","yang","lao","er3",
    "er4","er5","yi4","er6","yi5","rou","chen","zi2","zhi6",
    "yi6","yin","zhou","nong","se","cao","hu2","chong","xue",
    "hang2","yi7","xian","gu","yan","gu2","yong2","wei2",
    "li3","jian","zu","che","xin2","chen2","fu2","bu","yi8",
    "yi9","li4","gun2","ji6","zhou2","niao","lu","mai","yu2",
    "ma","gu3","gao","biao","dou2","chang","gui","gui2","xia",
    "gui3","bing2","yu3","dao3","mian2","zhu2","she","gui4",
    "mo","bao2","luan","gui5","yu4","long","gui6",
]
if len(radical_names) < 214:
    radical_names += [f"r{i}" for i in range(len(radical_names),214)]

if cjk_font:
    cjk_cmap = cjk_font.getBestCmap() or {}
    cjk_gs   = cjk_font.getGlyphSet()
    
    for ridx,cp in enumerate(KANGXI[:214],1):
        gname = cjk_cmap.get(cp)
        name = radical_names[ridx-1] if ridx-1 < len(radical_names) else f"r{ridx}"
        
        if not gname:
            out.append(f'\tRadicalTable[{ridx}] = RadicalDef{{Name:"{name}",NStroke:0}}')
            continue
        
        ss,_ = extract_strokes(gname,cjk_gs)
        if not ss:
            out.append(f'\tRadicalTable[{ridx}] = RadicalDef{{Name:"{name}",NStroke:0}}')
            continue
        
        # Max 16 strokes per radical
        ss = ss[:16]
        n = len(ss)
        
        stroke_insts = []
        for s in ss:
            key = stroke_shape_key(s)
            sid = shape_table.get(key,0)
            x = int(s['p0'][0]*255)&0xFF
            y = int(s['p0'][1]*255)&0xFF
            stroke_insts.append(f'{{SID:{sid},X:{x},Y:{y}}}')
        
        # Pad to 16
        while len(stroke_insts)<16: stroke_insts.append('{0,0,0}')
        
        si_str = ','.join(stroke_insts)
        out.append(f'\tRadicalTable[{ridx}] = RadicalDef{{')
        out.append(f'\t\tName:"{name}",NStroke:{n},')
        out.append(f'\t\tStrokes:[16]StrokeInst{{{si_str}}},')
        out.append(f'\t}}')
else:
    out.append('\t// CJK font not found — radical table empty')
    print("  WARNING: CJK font not found", file=sys.stderr)

out.append('}')

src = '\n'.join(out)
print(src)
print(f"Done. Lines: {len(out)}", file=sys.stderr)
