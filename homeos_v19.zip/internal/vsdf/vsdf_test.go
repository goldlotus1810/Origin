package vsdf

import (
	"fmt"
	"math"
	"testing"
)

// ─── Test StrokeTable được init ───────────────────────────────────────────
func TestStrokeTableInit(t *testing.T) {
	count := 0
	for i := 1; i < 256; i++ {
		if StrokeTable[i].Length > 0 { count++ }
	}
	t.Logf("Stroke table entries: %d/255", count)
	if count < 50 {
		t.Errorf("Expected ≥50 stroke entries, got %d", count)
	}
}

// ─── Test RadicalTable được init ─────────────────────────────────────────
func TestRadicalTableInit(t *testing.T) {
	count := 0
	for i := 1; i < 215; i++ {
		if RadicalTable[i].NStroke > 0 { count++ }
	}
	t.Logf("Radical table entries: %d/214", count)
}

// ─── Test encode/decode round-trip ───────────────────────────────────────
func TestEncodeDecodeSimple(t *testing.T) {
	// Tạo fake strokes cho 'A'
	strokes := []RawStroke{
		{Type: 'L', X0: 0.5, Y0: 1.0, X1: 0.1, Y1: 0.0, DX: -0.4, DY: -1.0, Len: math.Sqrt(0.16+1.0)},
		{Type: 'L', X0: 0.5, Y0: 1.0, X1: 0.9, Y1: 0.0, DX: 0.4, DY: -1.0, Len: math.Sqrt(0.16+1.0)},
		{Type: 'L', X0: 0.3, Y0: 0.5, X1: 0.7, Y1: 0.5, DX: 0.4, DY: 0.0, Len: 0.4},
	}

	data := EncodeSimple(strokes)
	t.Logf("'A' encoded: %d bytes  %v", len(data), data[:min(10,len(data))])

	if data[0] != GlyphTypeSimple {
		t.Errorf("Expected type 0x00, got 0x%02X", data[0])
	}
	nStrokes := int(data[1])
	t.Logf("n_strokes decoded: %d", nStrokes)
	if nStrokes != 3 {
		t.Errorf("Expected 3 strokes, got %d", nStrokes)
	}

	rendered := Decode(data)
	t.Logf("Rendered strokes: %d", len(rendered))
	if len(rendered) == 0 {
		t.Error("No strokes decoded")
	}
}

// ─── Test EvalSDF ─────────────────────────────────────────────────────────
func TestEvalSDF(t *testing.T) {
	strokes := []RawStroke{
		{Type: 'L', X0: 0.2, Y0: 0.5, X1: 0.8, Y1: 0.5, DX: 0.6, DY: 0.0, Len: 0.6},
	}
	data := EncodeSimple(strokes)

	// Center của stroke phải có SDF nhỏ
	dCenter := EvalSDF(data, 0.5, 0.5)
	dFar    := EvalSDF(data, 0.5, 0.9)
	t.Logf("SDF center=%.3f  far=%.3f", dCenter, dFar)
	if dFar <= dCenter {
		t.Errorf("Expected far > center, got center=%.3f far=%.3f", dCenter, dFar)
	}
}

// ─── Test EncodeEmpty ────────────────────────────────────────────────────
func TestEncodeEmpty(t *testing.T) {
	data := EncodeEmpty()
	if data[0] != GlyphTypeEmpty {
		t.Errorf("Expected 0x02, got 0x%02X", data[0])
	}
	rendered := Decode(data)
	if len(rendered) != 0 {
		t.Errorf("Expected 0 strokes for empty, got %d", len(rendered))
	}
}

// ─── ASCII render test ────────────────────────────────────────────────────
func TestRenderASCII(t *testing.T) {
	// Encode 'H' shape
	strokes := []RawStroke{
		{Type:'L', X0:0.1,Y0:0.0, X1:0.1,Y1:1.0, DX:0.0,DY:1.0, Len:1.0},
		{Type:'L', X0:0.9,Y0:0.0, X1:0.9,Y1:1.0, DX:0.0,DY:1.0, Len:1.0},
		{Type:'L', X0:0.1,Y0:0.5, X1:0.9,Y1:0.5, DX:0.8,DY:0.0, Len:0.8},
	}
	data := EncodeSimple(strokes)
	rendered := Decode(data)
	t.Logf("'H' strokes: %d", len(rendered))

	// Render 16×16
	res := 16
	r := 0.06
	var grid [16][32]bool
	for _, s := range rendered {
		for row := 0; row < res; row++ {
			py := float64(row)/float64(res-1)
			for col := 0; col < res*2; col++ {
				px := float64(col)/float64(res*2-1)
				d := capsuleSDF(px,py, s.X0,s.Y0, s.X1,s.Y1, r)
				if d < 0 { grid[row][col] = true }
			}
		}
	}
	fmt.Println("'H' render 16×16:")
	for row := res-1; row >= 0; row-- {
		line := ""
		for col := 0; col < res*2; col++ {
			if grid[row][col] { line += "█" } else { line += " " }
		}
		fmt.Printf("  |%s|\n", line)
	}
}

func min(a,b int) int { if a<b{return a}; return b }
