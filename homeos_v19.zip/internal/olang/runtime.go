// internal/olang/runtime.go — Runtime query .olang nodes
package olang

import (
	"sync"
)

// Runtime — query nodes đã load qua OlangFile
type Runtime struct {
	mu      sync.RWMutex
	byCp    map[uint32]*OlangNode
	byISL   map[uint64]*OlangNode
	byLayer map[uint8][]*OlangNode
}

func NewRuntime() *Runtime {
	return &Runtime{
		byCp:    make(map[uint32]*OlangNode),
		byISL:   make(map[uint64]*OlangNode),
		byLayer: make(map[uint8][]*OlangNode),
	}
}

// Index thêm nodes từ OlangFile vào runtime index
func (r *Runtime) Index(nodes []*OlangNode) {
	r.mu.Lock(); defer r.mu.Unlock()
	for _, n := range nodes {
		if n.Codepoint != 0 {
			r.byCp[n.Codepoint] = n
		}
		if n.ISLAddr != 0 {
			r.byISL[n.ISLAddr] = n
		}
		layer := n.Layer()
		r.byLayer[layer] = append(r.byLayer[layer], n)
	}
}

func (r *Runtime) GetByCodepoint(cp rune) (*OlangNode, bool) {
	r.mu.RLock(); defer r.mu.RUnlock()
	n, ok := r.byCp[uint32(cp)]
	return n, ok
}

func (r *Runtime) GetByISL(addr uint64) (*OlangNode, bool) {
	r.mu.RLock(); defer r.mu.RUnlock()
	n, ok := r.byISL[addr]
	return n, ok
}

func (r *Runtime) Layer(id uint8) []*OlangNode {
	r.mu.RLock(); defer r.mu.RUnlock()
	return r.byLayer[id]
}

func (r *Runtime) Stats() map[string]interface{} {
	r.mu.RLock(); defer r.mu.RUnlock()
	total := 0
	for _, v := range r.byLayer { total += len(v) }
	return map[string]interface{}{
		"total":  total,
		"layers": len(r.byLayer),
	}
}
