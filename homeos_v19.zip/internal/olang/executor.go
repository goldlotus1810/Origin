// internal/olang/executor.go
//
// L0 Executor — thực thi DNA bytecode từ homeos.olang
//
// Đây là trái tim của "olang run homeos.olang"
// Không có executor này → Go làm thay → sai kiến trúc
//
// L0 opcodes (từ homeos.olang thật):
//   0x52 EMIT   — phát tín hiệu ra ngoài (kết quả, message)
//   0x60 SEQ    — thực thi tuần tự
//   0x64 SPAWN  — tạo agent mới
//   0x63 DREAM  — chu kỳ học/kiểm chứng
//   0x61 IF     — rẽ nhánh
//   0x62 LOOP   — lặp (SecurityGate Rule 2: phải có điều kiện thoát)
//   0x50 GET    — lấy node từ Silk Tree
//   0x51 WALK   — đi theo silk edges
//   0x53 BCAST  — broadcast tới tất cả agents
//   0xa4 CALL   — gọi node khác
//   0xa5 RET    — trả về
//   0xff GATE   — SecurityGate check

package olang

import (
	"fmt"
	"math"
	"strings"
)

// ── Opcodes ──────────────────────────────────────────────────

const (
	// SDF/Shape
	OpSphere    = 0x01
	OpCapsule   = 0x02
	OpBox       = 0x03
	OpVoid      = 0x05
	OpUnion     = 0x10
	OpSub       = 0x11
	OpIntersect = 0x12
	OpFBM       = 0x20
	OpLight     = 0x22

	// Logic
	OpAnd  = 0x40
	OpOr   = 0x41
	OpNot  = 0x42
	OpEq   = 0x43
	OpLt   = 0x45
	OpGt   = 0x46

	// ISL/Control
	OpGet   = 0x50
	OpWalk  = 0x51
	OpEmit  = 0x52
	OpBcast = 0x53

	// Flow
	OpSeq   = 0x60
	OpIf    = 0x61
	OpLoop  = 0x62
	OpDream = 0x63
	OpSpawn = 0x64

	// Math — đầy đủ theo opcode table trong homeos.olang
	OpAdd   = 0x70
	OpSubN  = 0x71 // SUB (phân biệt với OpSub=SDF subtract 0x11)
	OpMul   = 0x72
	OpDiv   = 0x73
	OpMod   = 0x74
	OpPow   = 0x75
	OpSqrt  = 0x76
	OpAbs   = 0x77
	OpMinF  = 0x78 // MIN float (phân biệt với OpMin logic)
	OpMaxF  = 0x79 // MAX float
	OpClamp = 0x7a
	OpMixF  = 0x7b // MIX (lerp)
	OpFloor = 0x7c
	OpCeil  = 0x7d
	OpFrac  = 0x7e
	OpSign  = 0x7f
	OpSin   = 0x80
	OpCos   = 0x81
	OpTan   = 0x82
	OpAsin  = 0x83
	OpAcos  = 0x84
	OpAtan2 = 0x85

	// Vec3
	OpVec3     = 0x90
	OpDot      = 0x91
	OpCross    = 0x92
	OpNorm     = 0x93
	OpLen      = 0x94
	OpReflect  = 0x95
	OpRefract  = 0x96
	OpRotX     = 0x97
	OpRotY     = 0x98
	OpRotZ     = 0x99
	OpScaleV   = 0x9a
	OpTranslate= 0x9b

	// Stack
	OpLoad  = 0xa0
	OpStore = 0xa1
	OpPush  = 0xa2
	OpPop   = 0xa3
	OpCall  = 0xa4
	OpRet   = 0xa5

	// Security
	OpGate = 0xff
)

// ── Value — giá trị trên stack ───────────────────────────────

type ValueKind uint8
const (
	KindNull    ValueKind = 0
	KindFloat   ValueKind = 1
	KindString  ValueKind = 2
	KindISL     ValueKind = 3 // ISL address (8 bytes)
	KindBool    ValueKind = 4
	KindSignal  ValueKind = 5 // EMIT result
)

type Value struct {
	Kind   ValueKind
	Float  float32
	Str    string
	ISL    [8]byte
	Bool   bool
}

var Null   = Value{Kind: KindNull}
var True   = Value{Kind: KindBool, Bool: true}
var False  = Value{Kind: KindBool, Bool: false}

func FloatVal(f float32) Value  { return Value{Kind: KindFloat, Float: f} }
func StrVal(s string) Value     { return Value{Kind: KindString, Str: s} }
func ISLVal(b [8]byte) Value    { return Value{Kind: KindISL, ISL: b} }
func SignalVal(s string) Value  { return Value{Kind: KindSignal, Str: s} }

func (v Value) String() string {
	switch v.Kind {
	case KindNull:   return "∅"
	case KindFloat:  return fmt.Sprintf("%g", v.Float)
	case KindString: return v.Str
	case KindISL:    return fmt.Sprintf("[%c%c%c%c]", v.ISL[0],v.ISL[1],v.ISL[2],v.ISL[3])
	case KindBool:   if v.Bool { return "true" } else { return "false" }
	case KindSignal: return "→" + v.Str
	}
	return "?"
}

// ── ExecContext — môi trường thực thi ────────────────────────

type ExecContext struct {
	// Silk Tree lookup (set bởi runtime)
	GetNode  func(isl [8]byte) (*OlangNode, bool)
	GetByName func(name string) (*OlangNode, bool)

	// Output — EMIT ghi vào đây
	Output []string

	// Stack
	stack []Value

	// Registers (32 slots)
	regs [32]Value

	// Fuel — giới hạn steps (SecurityGate Rule 2: không vòng lặp vô hạn)
	Fuel int

	// Depth — giới hạn call depth
	depth int
}

func NewExecContext() *ExecContext {
	return &ExecContext{Fuel: 10000, depth: 0}
}

func (ctx *ExecContext) push(v Value) { ctx.stack = append(ctx.stack, v) }
func (ctx *ExecContext) pop() Value {
	if len(ctx.stack) == 0 { return Null }
	v := ctx.stack[len(ctx.stack)-1]
	ctx.stack = ctx.stack[:len(ctx.stack)-1]
	return v
}
func (ctx *ExecContext) peek() Value {
	if len(ctx.stack) == 0 { return Null }
	return ctx.stack[len(ctx.stack)-1]
}

// ── Execute — thực thi DNA của 1 node ────────────────────────
//
// DNA layout (NODE_Spec):
//   b[0] = STATE(2bit) | TYPE(6bit)  ← header, không phải opcode
//   b[1..N] = payload (L0 opcodes, vSDF bytes, ATOM val, text...)
//
// STATE: DN=0x00  QR=0x40  BLOWN=0x80
// TYPE:  RAW=0x00 ATOM=0x01 SDF=0x02 FORK=0x03 COMPOSE=0x04 BOND=0x05
//
// Exec dispatch:
//   ATOM    → đọc val float32 từ b[1..4], return ngay (không chạy L0)
//   BOND    → return 0.0 ngay (chỉ metadata)
//   BLOWN   → return error ngay
//   SDF/RAW → chạy L0 interpreter từ b[1]
//   FORK/COMPOSE → (future) gọi node khác

func Execute(node *OlangNode, ctx *ExecContext) (Value, error) {
	if node == nil { return Null, nil }
	if ctx.depth > 32 { return Null, fmt.Errorf("call depth exceeded (SecurityGate Rule 2)") }
	ctx.depth++
	defer func() { ctx.depth-- }()

	dna := node.DNA
	if len(dna) == 0 { return Null, nil }

	// ── b[0] = STATE|TYPE header — dispatch theo spec ────────
	b0     := dna[0]
	state  := b0 & 0xC0 // 2 bits cao: DN=0x00 QR=0x40 BLOWN=0x80
	ntype  := b0 & 0x3F // 6 bits thấp: RAW=0 ATOM=1 SDF=2 FORK=3 COMPOSE=4 BOND=5

	// BLOWN: không exec được
	if state == 0x80 {
		return Null, fmt.Errorf("BLOWN: node state is blown, cannot execute")
	}

	// BOND: chỉ là metadata, không exec
	if ntype == 0x05 {
		return FloatVal(0.0), nil
	}

	// TEXT: plain text metadata (label=..|desc=..|vi=..) — không exec qua L0
	// return ISL address của node như một string value
	if ntype == 0x06 {
		return FloatVal(0.0), nil
	}

	// ATOM: đọc val từ b[2..5] theo NODE_Spec
	// Layout: b[0]=STATE|TYPE  b[1]=EMIT(0x14)  b[2..5]=val(f32)  b[6]=id_hi  b[7]=id_lo
	if ntype == 0x01 {
		if len(dna) >= 6 {
			bits := uint32(dna[2])<<24 | uint32(dna[3])<<16 | uint32(dna[4])<<8 | uint32(dna[5])
			return FloatVal(math.Float32frombits(bits)), nil
		}
		return FloatVal(0.0), nil
	}

	// SDF / RAW / FORK / COMPOSE — chạy L0 interpreter từ b[1]
	pc := 1 // skip b[0] STATE|TYPE header

	for pc < len(dna) {
		// Fuel check — SecurityGate Rule 2
		ctx.Fuel--
		if ctx.Fuel <= 0 {
			return Null, fmt.Errorf("BLOWN: fuel exhausted (SecurityGate Rule 2)")
		}

		op := dna[pc]; pc++

		switch op {

		// ── EMIT 0x52 ── phát tín hiệu ra ngoài
		// Format: EMIT [4B payload]
		case OpEmit:
			if pc+4 <= len(dna) {
				payload := dna[pc : pc+4]
				pc += 4
				sig := fmt.Sprintf("%02x%02x%02x%02x", payload[0], payload[1], payload[2], payload[3])
				ctx.Output = append(ctx.Output, sig)
				ctx.push(SignalVal(sig))
			} else {
				ctx.push(SignalVal("emit"))
			}

		// ── SEQ 0x60 ── kết quả của bước trước → đầu vào bước sau
		// Format: SEQ [4B payload]
		case OpSeq:
			prev := ctx.pop()
			if pc+4 <= len(dna) {
				payload := dna[pc : pc+4]
				pc += 4
				sig := fmt.Sprintf("%02x%02x%02x%02x", payload[0], payload[1], payload[2], payload[3])
				ctx.Output = append(ctx.Output, prev.String()+" → "+sig)
				ctx.push(SignalVal(sig))
			} else {
				ctx.push(prev)
			}

		// ── SPAWN 0x64 ── tạo agent
		// Format: SPAWN [name:4B]
		case OpSpawn:
			if pc+4 <= len(dna) {
				name := strings.TrimRight(string(dna[pc:pc+4]), "\x00")
				pc += 4
				ctx.Output = append(ctx.Output, "SPAWN: "+name)
				ctx.push(StrVal(name))
			}

		// ── IF 0x61 ── rẽ nhánh
		case OpIf:
			cond := ctx.pop()
			if cond.Kind == KindBool && !cond.Bool {
				// Skip toàn bộ instruction tiếp theo (opcode + payload)
				// Phải biết payload size của từng opcode
				if pc < len(dna) {
					nextOp := dna[pc]
					pc++ // skip opcode byte
					// Skip payload theo từng opcode
					switch nextOp {
					case OpEmit, OpSeq, OpSpawn:
						pc += 4 // 4B payload
					case OpGet:
						pc += 8 // 8B ISL address
					case OpCall:
						if pc < len(dna) {
							nameLen := int(dna[pc]); pc++
							pc += nameLen
						}
					case OpPush, OpLoad, OpStore, OpLoop:
						pc += 1 // 1B operand
					// opcodes không có payload: skip 0 bytes thêm
					default:
						// không có payload — đã skip opcode ở trên
					}
				}
			}

		// ── LOOP 0x62 ── lặp (PHẢI có fuel check)
		case OpLoop:
			// Format: LOOP [count:1B] [body...]
			// Tạm thời: không implement — cần fuel
			ctx.push(Null)

		// ── DREAM 0x63 ── chu kỳ học
		case OpDream:
			ctx.Output = append(ctx.Output, "DREAM: kiểm chứng ĐN...")
			ctx.push(SignalVal("dream"))

		// ── GET 0x50 ── lấy node
		case OpGet:
			if ctx.GetNode != nil && pc+8 <= len(dna) {
				var isl [8]byte
				copy(isl[:], dna[pc:pc+8])
				pc += 8
				if n, ok := ctx.GetNode(isl); ok {
					ctx.push(StrVal(n.Name()))
				} else {
					ctx.push(Null)
				}
			}

		// ── WALK 0x51 ── đi theo silk edges
		case OpWalk:
			ctx.push(Null) // TODO: implement khi silk edges available

		// ── BCAST 0x53 ── broadcast
		case OpBcast:
			msg := ctx.pop()
			ctx.Output = append(ctx.Output, "BCAST: "+msg.String())
			ctx.push(msg)

		// ── CALL 0xa4 ── gọi node khác
		case OpCall:
			if ctx.GetByName != nil && pc+1 <= len(dna) {
				nameLen := int(dna[pc]); pc++
				if pc+nameLen <= len(dna) {
					name := string(dna[pc : pc+nameLen]); pc += nameLen
					if n, ok := ctx.GetByName(name); ok {
						result, err := Execute(n, ctx)
						if err != nil { return Null, err }
						ctx.push(result)
					}
				}
			}

		// ── RET 0xa5 ── trả về
		case OpRet:
			return ctx.pop(), nil

		// ── GATE 0xff ── SecurityGate
		case OpGate:
			// Rule 1: không hại người — luôn pass (check ở level cao hơn)
			ctx.Output = append(ctx.Output, "🛡 GATE: pass")
			ctx.push(True)

		// ── Math ops (0x70–0x85) ─────────────────────────────────
		case OpAdd:
			b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(a.Float + b.Float))
			} else {
				ctx.push(StrVal(a.String() + b.String()))
			}

		case OpSubN:
			b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(a.Float - b.Float))
			} else { ctx.push(Null) }

		case OpMul:
			b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(a.Float * b.Float))
			} else { ctx.push(Null) }

		case OpDiv:
			b := ctx.pop(); a := ctx.pop()
			if b.Kind == KindFloat && b.Float == 0 {
				// QT2: ∞ không tồn tại → BLOWN
				return Null, fmt.Errorf("BLOWN: division by zero (QT2: ∞ == sai)")
			}
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(a.Float / b.Float))
			} else { ctx.push(Null) }

		case OpMod:
			b := ctx.pop(); a := ctx.pop()
			if b.Kind == KindFloat && b.Float == 0 {
				return Null, fmt.Errorf("BLOWN: mod by zero")
			}
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Mod(float64(a.Float), float64(b.Float)))))
			}

		case OpPow:
			b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Pow(float64(a.Float), float64(b.Float)))))
			}

		case OpSqrt:
			a := ctx.pop()
			if a.Kind == KindFloat {
				if a.Float < 0 {
					return Null, fmt.Errorf("BLOWN: sqrt of negative (QT2)")
				}
				ctx.push(FloatVal(float32(math.Sqrt(float64(a.Float)))))
			}

		case OpAbs:
			a := ctx.pop()
			if a.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Abs(float64(a.Float)))))
			}

		case OpMinF:
			b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Min(float64(a.Float), float64(b.Float)))))
			}

		case OpMaxF:
			b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Max(float64(a.Float), float64(b.Float)))))
			}

		case OpClamp:
			// stack: value, min, max
			maxV := ctx.pop(); minV := ctx.pop(); val := ctx.pop()
			if val.Kind == KindFloat {
				v := float64(val.Float)
				v = math.Max(float64(minV.Float), math.Min(float64(maxV.Float), v))
				ctx.push(FloatVal(float32(v)))
			}

		case OpMixF:
			// MIX(a, b, t) = a*(1-t) + b*t — linear interpolation
			t := ctx.pop(); b := ctx.pop(); a := ctx.pop()
			if a.Kind == KindFloat && b.Kind == KindFloat && t.Kind == KindFloat {
				tf := float64(t.Float)
				ctx.push(FloatVal(float32(float64(a.Float)*(1-tf) + float64(b.Float)*tf)))
			}

		case OpFloor:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Floor(float64(a.Float))))) }

		case OpCeil:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Ceil(float64(a.Float))))) }

		case OpFrac:
			a := ctx.pop()
			if a.Kind == KindFloat {
				_, frac := math.Modf(float64(a.Float))
				ctx.push(FloatVal(float32(frac)))
			}

		case OpSign:
			a := ctx.pop()
			if a.Kind == KindFloat {
				v := float64(a.Float)
				if v > 0 { ctx.push(FloatVal(1)) } else if v < 0 { ctx.push(FloatVal(-1)) } else { ctx.push(FloatVal(0)) }
			}

		case OpSin:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Sin(float64(a.Float))))) }

		case OpCos:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Cos(float64(a.Float))))) }

		case OpTan:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Tan(float64(a.Float))))) }

		case OpAsin:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Asin(float64(a.Float))))) }

		case OpAcos:
			a := ctx.pop()
			if a.Kind == KindFloat { ctx.push(FloatVal(float32(math.Acos(float64(a.Float))))) }

		case OpAtan2:
			y := ctx.pop(); x := ctx.pop()
			if x.Kind == KindFloat && y.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Atan2(float64(y.Float), float64(x.Float)))))
			}

		// ── SDF shapes (thật sự tính toán) ─────────────────────
		// Stack convention: px py pz cx cy cz r (for sphere)
		case OpSphere:
			// SDFSphere(p, c, r) = length(p-c) - r
			r := ctx.pop()
			cz := ctx.pop(); cy := ctx.pop(); cx := ctx.pop()
			pz := ctx.pop(); py := ctx.pop(); px := ctx.pop()
			if px.Kind == KindFloat {
				dx := float64(px.Float - cx.Float)
				dy := float64(py.Float - cy.Float)
				dz := float64(pz.Float - cz.Float)
				dist := math.Sqrt(dx*dx + dy*dy + dz*dz) - float64(r.Float)
				ctx.push(FloatVal(float32(dist)))
			} else { ctx.push(FloatVal(0)) }

		case OpCapsule:
			// SDFCapsule(p, a, b, r) = length(p - closestPointOnSegment(a,b)) - r
			// Stack: px py pz ax ay az bx by bz r
			r := ctx.pop()
			bz := ctx.pop(); by := ctx.pop(); bx := ctx.pop()
			az := ctx.pop(); ay := ctx.pop(); ax := ctx.pop()
			pz := ctx.pop(); py := ctx.pop(); px := ctx.pop()
			if px.Kind == KindFloat {
				// Project p onto segment [a,b]
				abx := float64(bx.Float-ax.Float); aby := float64(by.Float-ay.Float); abz := float64(bz.Float-az.Float)
				apx := float64(px.Float-ax.Float); apy := float64(py.Float-ay.Float); apz := float64(pz.Float-az.Float)
				ab2 := abx*abx + aby*aby + abz*abz
				t := 0.0
				if ab2 > 0 {
					t = (apx*abx + apy*aby + apz*abz) / ab2
					t = math.Max(0, math.Min(1, t))
				}
				qx := float64(ax.Float) + t*abx
				qy := float64(ay.Float) + t*aby
				qz := float64(az.Float) + t*abz
				dx := float64(px.Float)-qx; dy := float64(py.Float)-qy; dz := float64(pz.Float)-qz
				dist := math.Sqrt(dx*dx+dy*dy+dz*dz) - float64(r.Float)
				ctx.push(FloatVal(float32(dist)))
			} else { ctx.push(FloatVal(0)) }

		case OpBox:
			// SDFBox(p, b) = length(max(abs(p)-b, 0))
			bz := ctx.pop(); by := ctx.pop(); bx := ctx.pop()
			pz := ctx.pop(); py := ctx.pop(); px := ctx.pop()
			if px.Kind == KindFloat {
				qx := math.Abs(float64(px.Float)) - float64(bx.Float)
				qy := math.Abs(float64(py.Float)) - float64(by.Float)
				qz := math.Abs(float64(pz.Float)) - float64(bz.Float)
				mx := math.Max(qx, 0); my := math.Max(qy, 0); mz := math.Max(qz, 0)
				dist := math.Sqrt(mx*mx+my*my+mz*mz) + math.Min(math.Max(qx, math.Max(qy, qz)), 0)
				ctx.push(FloatVal(float32(dist)))
			} else { ctx.push(FloatVal(0)) }

		case OpVoid:
			ctx.push(FloatVal(1e10)) // SDF void = rất lớn (không gian trống)

		case OpUnion:
			// SmoothUnion(d1, d2, k)
			k := ctx.pop(); d2 := ctx.pop(); d1 := ctx.pop()
			if d1.Kind == KindFloat && d2.Kind == KindFloat {
				if k.Kind == KindFloat && k.Float > 0 {
					// smooth minimum: -log(e^(-k*d1) + e^(-k*d2)) / k
					kf := float64(k.Float)
					h := math.Exp(-kf*float64(d1.Float)) + math.Exp(-kf*float64(d2.Float))
					ctx.push(FloatVal(float32(-math.Log(h) / kf)))
				} else {
					ctx.push(FloatVal(float32(math.Min(float64(d1.Float), float64(d2.Float)))))
				}
			} else { ctx.push(d1) }

		case OpSub:
			// SmoothSubtract(d1, d2, k) = max(-d2, d1) smoothed
			k := ctx.pop(); d2 := ctx.pop(); d1 := ctx.pop()
			if d1.Kind == KindFloat && d2.Kind == KindFloat {
				if k.Kind == KindFloat && k.Float > 0 {
					kf := float64(k.Float)
					h := math.Exp(kf*float64(d2.Float)) + math.Exp(kf*float64(d1.Float))
					ctx.push(FloatVal(float32(math.Log(h) / kf)))
				} else {
					ctx.push(FloatVal(float32(math.Max(-float64(d2.Float), float64(d1.Float)))))
				}
			} else { ctx.push(d1) }

		case OpIntersect:
			k := ctx.pop(); d2 := ctx.pop(); d1 := ctx.pop()
			_ = k
			if d1.Kind == KindFloat && d2.Kind == KindFloat {
				ctx.push(FloatVal(float32(math.Max(float64(d1.Float), float64(d2.Float)))))
			}

		// ── Vec3 ops ──────────────────────────────────────────
		case OpLen:
			// LEN: stack [x, y, z] → sqrt(x²+y²+z²)
			z := ctx.pop(); y := ctx.pop(); x := ctx.pop()
			if x.Kind == KindFloat {
				l := math.Sqrt(float64(x.Float)*float64(x.Float) +
					float64(y.Float)*float64(y.Float) +
					float64(z.Float)*float64(z.Float))
				ctx.push(FloatVal(float32(l)))
			}

		case OpDot:
			// DOT: [ax,ay,az,bx,by,bz] → ax*bx + ay*by + az*bz
			bz := ctx.pop(); by := ctx.pop(); bx := ctx.pop()
			az := ctx.pop(); ay := ctx.pop(); ax := ctx.pop()
			if ax.Kind == KindFloat {
				d := float64(ax.Float)*float64(bx.Float) +
					float64(ay.Float)*float64(by.Float) +
					float64(az.Float)*float64(bz.Float)
				ctx.push(FloatVal(float32(d)))
			}

		case OpNorm:
			// NORMALIZE: [x,y,z] → [x/l, y/l, z/l]
			z := ctx.pop(); y := ctx.pop(); x := ctx.pop()
			if x.Kind == KindFloat {
				l := math.Sqrt(float64(x.Float)*float64(x.Float) +
					float64(y.Float)*float64(y.Float) +
					float64(z.Float)*float64(z.Float))
				if l > 0 {
					ctx.push(FloatVal(float32(float64(z.Float)/l)))
					ctx.push(FloatVal(float32(float64(y.Float)/l)))
					ctx.push(FloatVal(float32(float64(x.Float)/l)))
				} else {
					ctx.push(FloatVal(0)); ctx.push(FloatVal(0)); ctx.push(FloatVal(0))
				}
			}

		// ── Logic ──────────────────────────────────────────────
		case OpAnd:
			b := ctx.pop(); a := ctx.pop()
			ctx.push(Value{Kind: KindBool, Bool: a.Bool && b.Bool})
		case OpOr:
			b := ctx.pop(); a := ctx.pop()
			ctx.push(Value{Kind: KindBool, Bool: a.Bool || b.Bool})
		case OpNot:
			a := ctx.pop()
			ctx.push(Value{Kind: KindBool, Bool: !a.Bool})

		// ── Stack ops ──────────────────────────────────────────
		case OpPush:
			if pc < len(dna) {
				ctx.push(FloatVal(float32(dna[pc]))); pc++
			}
		case OpPop:
			ctx.pop()
		case OpLoad:
			if pc < len(dna) {
				idx := int(dna[pc]); pc++
				if idx < 32 { ctx.push(ctx.regs[idx]) }
			}
		case OpStore:
			if pc < len(dna) {
				idx := int(dna[pc]); pc++
				if idx < 32 { ctx.regs[idx] = ctx.pop() }
			}

		default:
			// Unknown opcode — skip (forward compatible)
		}
	}

	// Kết quả là top of stack
	if len(ctx.stack) > 0 {
		return ctx.pop(), nil
	}
	return Null, nil
}

// ── OlangNode helper methods ──────────────────────────────────

// Name trả về tên node từ DNA (nếu có) hoặc ISL string
func (n *OlangNode) Name() string {
	// Name không nằm trong OlangNode struct hiện tại
	// → dùng ISL address làm identifier
	return fmt.Sprintf("[%02x%02x%02x%02x]",
		n.ISLAddr>>56, (n.ISLAddr>>48)&0xff,
		(n.ISLAddr>>40)&0xff, (n.ISLAddr>>32)&0xff)
}
