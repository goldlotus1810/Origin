package olang

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

// Đường dẫn đến homeos.olang thực tế
const testOlangPath = "../../homeos.olang"

func TestExporter_LoadFile(t *testing.T) {
	if _, err := os.Stat(testOlangPath); os.IsNotExist(err) {
		t.Skip("homeos.olang not found, skip")
	}
	exp, err := NewExporter(testOlangPath)
	if err != nil {
		t.Fatalf("NewExporter: %v", err)
	}
	t.Logf("Loaded: nodes=%d edges=%d", len(exp.source.Nodes), len(exp.source.Edges))
	if len(exp.source.Nodes) < 100 {
		t.Errorf("expected ≥100 nodes, got %d", len(exp.source.Nodes))
	}
}

func TestExporter_SelectNodes_L0Always(t *testing.T) {
	if _, err := os.Stat(testOlangPath); os.IsNotExist(err) {
		t.Skip("homeos.olang not found, skip")
	}
	exp, err := NewExporter(testOlangPath)
	if err != nil {
		t.Fatalf("NewExporter: %v", err)
	}

	spec := WorkerSpec{
		WorkerID:   "test_worker",
		DeviceType: "light",
		Layers:     []uint8{LayerObjects},
		CreatedAt:  time.Now(),
	}

	selected := exp.selectNodes(spec)

	// L0 phải luôn có
	hasL0 := false
	for _, n := range selected {
		if n.Layer == LayerPrimitives {
			hasL0 = true
			break
		}
	}
	if !hasL0 {
		t.Error("L0 Primitives must always be included")
	}
	t.Logf("Selected %d nodes (includes L0)", len(selected))
}

func TestExporter_ExportLight(t *testing.T) {
	if _, err := os.Stat(testOlangPath); os.IsNotExist(err) {
		t.Skip("homeos.olang not found, skip")
	}

	tmpDir := t.TempDir()
	exp, err := NewExporter(testOlangPath)
	if err != nil {
		t.Fatalf("NewExporter: %v", err)
	}

	spec := SpecForLight("light_living", "192.168.1.101")
	result, err := exp.Export(spec, tmpDir)
	if err != nil {
		t.Fatalf("Export: %v", err)
	}

	t.Logf("Export result: %s", result)

	// Kiểm tra file được tạo
	if _, err := os.Stat(result.OutputPath); os.IsNotExist(err) {
		t.Error("output file not created")
	}

	// Kiểm tra size nhỏ hơn source
	sourceInfo, _ := os.Stat(testOlangPath)
	if sourceInfo != nil && result.SizeBytes >= sourceInfo.Size() {
		t.Errorf("worker.olang (%d B) should be smaller than homeos.olang (%d B)",
			result.SizeBytes, sourceInfo.Size())
	}

	// Kiểm tra magic bytes
	data, _ := os.ReadFile(result.OutputPath)
	if len(data) < 4 || string(data[:4]) != "OLNG" {
		t.Error("output file missing OLNG magic")
	}

	t.Logf("Light worker: %d nodes, %d edges, %d KB (source: %d KB)",
		result.NodeCount, result.EdgeCount,
		result.SizeBytes/1024,
		sourceInfo.Size()/1024)
}

func TestExporter_ExportCamera(t *testing.T) {
	if _, err := os.Stat(testOlangPath); os.IsNotExist(err) {
		t.Skip("homeos.olang not found, skip")
	}
	tmpDir := t.TempDir()
	exp, _ := NewExporter(testOlangPath)

	spec := SpecForCamera("camera_01", "192.168.1.150")
	result, err := exp.Export(spec, tmpDir)
	if err != nil {
		t.Fatalf("Export camera: %v", err)
	}

	// Camera cần thêm L6 Perception — phải nhiều node hơn light
	lightResult, _ := exp.Export(SpecForLight("light_test", ""), tmpDir)
	t.Logf("Camera: %d nodes vs Light: %d nodes", result.NodeCount, lightResult.NodeCount)
}

func TestExporter_MultipleWorkers(t *testing.T) {
	if _, err := os.Stat(testOlangPath); os.IsNotExist(err) {
		t.Skip("homeos.olang not found, skip")
	}
	tmpDir := t.TempDir()
	exp, _ := NewExporter(testOlangPath)

	specs := []WorkerSpec{
		SpecForLight("light_living", "192.168.1.101"),
		SpecForLight("light_bed", "192.168.1.102"),
		SpecForHVAC("hvac_main", "192.168.1.110"),
		SpecForLock("lock_front", "192.168.1.120"),
	}

	for _, spec := range specs {
		result, err := exp.Export(spec, tmpDir)
		if err != nil {
			t.Errorf("Export %s: %v", spec.WorkerID, err)
			continue
		}
		t.Logf("  %s", result)

		// Verify file tồn tại
		if _, err := os.Stat(result.OutputPath); os.IsNotExist(err) {
			t.Errorf("Missing output: %s", result.OutputPath)
		}
	}

	// List files trong tmpDir
	entries, _ := os.ReadDir(tmpDir)
	t.Logf("Files in output dir: %d", len(entries))
	for _, e := range entries {
		info, _ := os.Stat(filepath.Join(tmpDir, e.Name()))
		t.Logf("  %s (%d KB)", e.Name(), info.Size()/1024)
	}
}

func TestEncodeNode_RoundTrip(t *testing.T) {
	// Encode một node, parse lại để verify format
	n := &NodeRecord{
		Layer:   LayerObjects,
		ISLAddr: 0x4441613100000001,
		CP:      0x1F4A1, // 💡
		DNA:     []byte{0x10, 0x20, 0x30},
		Name:    "light_bulb",
	}

	encoded := encodeNode(n)

	// Verify magic
	if encoded[0] != 'N' || encoded[1] != 'D' {
		t.Error("missing ND magic")
	}
	// Verify layer
	if encoded[2] != LayerObjects {
		t.Errorf("layer wrong: got %d", encoded[2])
	}
	// Verify size
	// 2(ND) + 1(layer) + 8(ISL) + 4(CP) + 4(dnaLen) + 1(nameLen) + 3(DNA) + 10(name)
	expected := 2 + 1 + 8 + 4 + 4 + 1 + 3 + 10
	if len(encoded) != expected {
		t.Errorf("encoded size: got %d, want %d", len(encoded), expected)
	}
	t.Logf("Encoded node: %d bytes", len(encoded))
}

func TestSpecForLight_Fields(t *testing.T) {
	spec := SpecForLight("light_living", "192.168.1.101")
	if spec.WorkerID != "light_living" {
		t.Errorf("WorkerID: %s", spec.WorkerID)
	}
	if spec.DeviceType != "light" {
		t.Errorf("DeviceType: %s", spec.DeviceType)
	}
	if len(spec.Layers) == 0 {
		t.Error("Layers empty")
	}
	// L0 phải trong Layers hoặc tự động add
	hasL0 := false
	for _, l := range spec.Layers {
		if l == LayerPrimitives {
			hasL0 = true
		}
	}
	if !hasL0 {
		t.Log("L0 not in spec.Layers — ok, selectNodes adds it automatically")
	}
	t.Logf("Light spec: layers=%v names=%d", spec.Layers, len(spec.NodeNames))
}
