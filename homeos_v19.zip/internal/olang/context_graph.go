// internal/olang/context_graph.go
//
// ContextGraph — đồ thị ngữ cảnh cho HomeOS
//
// Vấn đề: cùng một ký tự/từ có nhiều nghĩa khác nhau tuỳ hoàn cảnh.
//
//   HEART  + biology   → bộ phận cơ thể (tim)
//   HEART  + emotion   → yêu thương, tình cảm
//   EARTH  + astronomy → hành tinh hệ mặt trời
//   EARTH  + computing → biểu tượng internet (🌍)
//
// Giải pháp (QT4: BẢN CHẤT QUYẾT ĐỊNH TỒN TẠI):
//   Mỗi nghĩa = node riêng biệt với ISL address riêng
//   Node gốc --[LinkContext 0x07]--> Node ngữ cảnh
//   Node ngữ cảnh --[LinkSameMeaning 0x03]--> Concept node
//
// Composition (QT6: SDF ⧺ ISL):
//   "HEATH" = H ∘ E ∘ A ∘ T ∘ H
//   Node chữ cái --[LinkPart 0x06]--> Node từ
//   "HEATH" ≡ "LOVE" ≡ "YÊU" ≡ "YEU" --[LinkSameMeaning 0x03]-->

package olang

import (
	"encoding/binary"
	"fmt"
)

// Context types — hoàn cảnh xác định nghĩa
const (
	CtxBiology   = 0x01 // sinh học, cơ thể
	CtxEmotion   = 0x02 // cảm xúc, tâm lý
	CtxAstronomy = 0x03 // thiên văn, vũ trụ
	CtxComputing = 0x04 // máy tính, internet
	CtxLanguage  = 0x05 // ngôn ngữ học
	CtxMath      = 0x06 // toán học
	CtxPhysics   = 0x07 // vật lý
	CtxHistory   = 0x08 // lịch sử
	CtxCulture   = 0x09 // văn hoá
	CtxGeography = 0x0A // địa lý
)

var ContextNames = map[uint8]string{
	CtxBiology:   "biology",
	CtxEmotion:   "emotion",
	CtxAstronomy: "astronomy",
	CtxComputing: "computing",
	CtxLanguage:  "language",
	CtxMath:      "math",
	CtxPhysics:   "physics",
	CtxHistory:   "history",
	CtxCulture:   "culture",
	CtxGeography: "geography",
}

// ContextEdge — một nghĩa của node trong một hoàn cảnh cụ thể
type ContextEdge struct {
	SourceISL [8]byte // node gốc (ký tự / từ)
	TargetISL [8]byte // node nghĩa cụ thể
	Context   uint8   // CtxBiology, CtxEmotion, ...
	Weight    float32 // độ phổ biến của nghĩa này
}

// MakeContextISL tạo ISL address cho một node trong hoàn cảnh cụ thể
// Format: [04][ctx:1B][concept:1B][hash:5B]
// Layer 4 = Objects = "contextualised meanings"
func MakeContextISL(baseISL [8]byte, ctx uint8) [8]byte {
	var addr [8]byte
	addr[0] = 0x04 // layer 4
	addr[1] = ctx
	// hash từ baseISL + ctx để tránh collision
	h := baseISL[0]^baseISL[1]^baseISL[2]^baseISL[3] ^ ctx
	addr[2] = baseISL[4] ^ h
	addr[3] = baseISL[5] ^ h
	addr[4] = baseISL[6]
	addr[5] = baseISL[7]
	addr[6] = baseISL[2]
	addr[7] = ctx ^ baseISL[0]
	return addr
}

// MakeCompositionISL tạo ISL address cho một từ hợp thành từ nhiều ký tự
// "HEATH" → hash của chuỗi ký tự
func MakeCompositionISL(chars []rune) [8]byte {
	var addr [8]byte
	addr[0] = 0x03 // layer 3 = Life = "composed meanings"
	h := uint64(0)
	for i, c := range chars {
		h ^= uint64(c) << (uint(i*7) % 48)
		h = h*1103515245 + 12345 // LCG mix
	}
	binary.BigEndian.PutUint64(addr[:], h)
	addr[0] = 0x03 // restore layer
	return addr
}

// ContextDef — định nghĩa đầy đủ của một nghĩa trong một hoàn cảnh
type ContextDef struct {
	// Ký tự hoặc từ gốc
	Codepoint rune   // 0 nếu là từ nhiều ký tự
	Word      string // từ nếu không phải single char
	Chars     []rune // ký tự cấu thành (cho composition)

	// Hoàn cảnh
	Context uint8
	CtxName string

	// Nghĩa trong hoàn cảnh này
	Meaning    string   // mô tả ngắn
	Equivalents []string // các từ tương đương trong ngôn ngữ khác
	ConceptNode string   // concept node ISL (nếu có)

	// Silk edges cần tạo
	SameMeaning []string // các từ có cùng nghĩa (ISL hoặc name)
	DerivedFrom []string // nguồn gốc
	PartOf      []string // thuộc về
}

// ─── Định nghĩa context database ────────────────────────────────

// HeartContexts — HEART trong 2 hoàn cảnh khác nhau
var HeartContexts = []ContextDef{
	{
		Codepoint: 0x2764, // ❤
		Word:      "HEART",
		Chars:     []rune{'H', 'E', 'A', 'R', 'T'},
		Context:   CtxBiology,
		CtxName:   "biology",
		Meaning:   "bộ phận cơ thể — cơ quan bơm máu",
		Equivalents: []string{
			"tim",        // Vietnamese
			"心臓",        // Japanese (shinzou)
			"心",          // CJK (xīn)
			"coeur",      // French
			"Herz",       // German
			"corazón",    // Spanish
			"قلب",        // Arabic (qalb)
		},
		SameMeaning: []string{"LIFE_ORGAN_HEART", "BODY_HEART"},
		PartOf:      []string{"LIFE_BODY", "LIFE_CIRCULATORY"},
	},
	{
		Codepoint: 0x2764, // ❤
		Word:      "HEART",
		Chars:     []rune{'H', 'E', 'A', 'R', 'T'},
		Context:   CtxEmotion,
		CtxName:   "emotion",
		Meaning:   "tình yêu, yêu thương, tình cảm",
		Equivalents: []string{
			"love",   // English
			"yêu",    // Vietnamese
			"yeu",    // Vietnamese (ASCII)
			"愛",      // CJK ài (love)
			"사랑",     // Korean (sarang)
			"liebe",  // German
			"amour",  // French
			"amor",   // Spanish/Portuguese
			"حب",     // Arabic (ḥubb)
		},
		// Composition: HEATH = H+E+A+T+H = LOVE = YÊU
		SameMeaning: []string{
			"EMOTION_LOVE",
			"LIFE_LOVE",
			"HEATH",   // composition target
		},
	},
}

// EarthContexts — 🌍 trong 2 hoàn cảnh
var EarthContexts = []ContextDef{
	{
		Codepoint: 0x1F30D, // 🌍
		Word:      "EARTH",
		Chars:     []rune{'E', 'A', 'R', 'T', 'H'},
		Context:   CtxAstronomy,
		CtxName:   "astronomy",
		Meaning:   "hành tinh thứ 3 trong hệ mặt trời",
		Equivalents: []string{
			"địa cầu",   // Vietnamese
			"地球",       // CJK (dìqiú)
			"Erde",      // German
			"Terre",     // French
			"Tierra",    // Spanish
		},
		SameMeaning: []string{"NATURE_EARTH", "ASTRONOMY_PLANET_3"},
		PartOf:      []string{"SOLAR_SYSTEM", "MILKY_WAY"},
	},
	{
		Codepoint: 0x1F30D, // 🌍
		Word:      "EARTH_GLOBE",
		Chars:     []rune{'🌍'},
		Context:   CtxComputing,
		CtxName:   "computing",
		Meaning:   "biểu tượng internet, kết nối toàn cầu",
		Equivalents: []string{
			"internet",
			"web",
			"www",
			"online",
			"網",        // CJK web/net
		},
		SameMeaning: []string{"TECH_INTERNET", "COMPUTING_NETWORK"},
		PartOf:      []string{"COMPUTING_SYMBOLS", "EMOJI_TRAVEL"},
	},
}

// HeathComposition — HEATH = H+E+A+T+H = LOVE = YÊU
// Đây là ví dụ composition: một từ được hợp thành từ các ký tự,
// và từ đó có nghĩa tương đương với các từ khác
var HeathComposition = struct {
	Word     string
	Chars    []rune
	Meaning  string
	Equivalents []string
	Context  uint8
}{
	Word:    "HEATH",
	Chars:   []rune{'H', 'E', 'A', 'T', 'H'},
	Meaning: "tình yêu (composition)",
	Equivalents: []string{
		"LOVE",  // English
		"YÊU",   // Vietnamese (có dấu)
		"YEU",   // Vietnamese (ASCII)
		"愛",     // CJK ài
		"❤",     // Symbol
		"사랑",    // Korean
	},
	Context: CtxEmotion,
}

// ─── Serializer: tạo L4 node specs cho batch append ─────────────

// ContextNodeSpec — spec để tạo context node trong homeos.olang
type ContextNodeSpec struct {
	ISL     [8]byte
	Name    string
	DNA     []byte // [ctx:1B][codepoint:4B][meaning_len:1B][meaning:var]
	Layer   uint8
}

// BuildContextNodes tạo tất cả context nodes từ ContextDef slice
func BuildContextNodes(defs []ContextDef) []ContextNodeSpec {
	var specs []ContextNodeSpec
	seen := map[[8]byte]bool{}

	for _, d := range defs {
		// Tạo ISL cho base char
		var baseISL [8]byte
		if d.Codepoint != 0 {
			baseISL[0] = 0x01 // L1
			baseISL[1] = 0x4E // CJK group (hoặc computed)
			binary.BigEndian.PutUint32(baseISL[4:], uint32(d.Codepoint))
		}

		// Tạo context node
		ctxISL := MakeContextISL(baseISL, d.Context)
		if seen[ctxISL] {
			continue
		}
		seen[ctxISL] = true

		// DNA: [ctx][cp:4B][meanings...]
		meaning := []byte(d.Meaning)
		if len(meaning) > 200 {
			meaning = meaning[:200]
		}
		dna := make([]byte, 6+len(meaning))
		dna[0] = d.Context
		binary.BigEndian.PutUint32(dna[1:5], uint32(d.Codepoint))
		dna[5] = uint8(len(meaning))
		copy(dna[6:], meaning)

		// Thêm equivalents vào DNA
		for _, eq := range d.Equivalents {
			eb := []byte(eq)
			if len(dna)+1+len(eb) < 4000 {
				dna = append(dna, uint8(len(eb)))
				dna = append(dna, eb...)
			}
		}

		name := fmt.Sprintf("CTX_%s_%s", d.Word, d.CtxName)

		specs = append(specs, ContextNodeSpec{
			ISL:   ctxISL,
			Name:  name,
			DNA:   dna,
			Layer: 0x04, // L4
		})
	}
	return specs
}

// BuildCompositionEdges tạo silk edges cho word composition
// "HEATH" = H∘E∘A∘T∘H  →  [Part] H→HEATH, E→HEATH, etc.
// "HEATH" ≡ "LOVE" ≡ "YÊU"  →  [SameMeaning]
func BuildCompositionEdges(word string, chars []rune, equivalents []string, wordISL [8]byte) []SilkEdgeEntry {
	var edges []SilkEdgeEntry

	// Char nodes → word node via LinkPart
	charISLs := LatinCharISLs()
	for _, c := range chars {
		if cISL, ok := charISLs[c]; ok {
			edges = append(edges, SilkEdgeEntry{
				Src:    binary.BigEndian.Uint64(cISL[:]),
				Dst:    binary.BigEndian.Uint64(wordISL[:]),
				Type:   EdgeMember,
				Weight: 1.0,
			})
		}
	}

	// Equivalents → word node via LinkSameMeaning
	for _, eq := range equivalents {
		eqISL := MakeWordISL(eq)
		edges = append(edges, SilkEdgeEntry{
			Src:    binary.BigEndian.Uint64(wordISL[:]),
			Dst:    binary.BigEndian.Uint64(eqISL[:]),
			Type:   EdgeEquiv,
			Weight: 1.0,
		})
	}

	return edges
}

// MakeWordISL tạo ISL cho một từ (không phải single codepoint)
func MakeWordISL(word string) [8]byte {
	chars := []rune(word)
	return MakeCompositionISL(chars)
}

// LatinCharISLs — ISL addresses cho các ký tự Latin A-Z
// (đã được load vào L1 từ seeder)
func LatinCharISLs() map[rune][8]byte {
	m := map[rune][8]byte{}
	// Latin A (U+0041) - Z (U+005A)
	for c := rune('A'); c <= 'Z'; c++ {
		var isl [8]byte
		// Latin chars được load với ISL từ seeder Unicode
		// Format seeder: dùng sha256-based hash
		// Đơn giản hơn: dùng codepoint trực tiếp
		isl[0] = 0x01 // L1
		isl[1] = byte(c >> 8)
		isl[2] = byte(c & 0xFF)
		binary.BigEndian.PutUint32(isl[4:], uint32(c))
		m[c] = isl
	}
	// Lowercase a-z
	for c := rune('a'); c <= 'z'; c++ {
		var isl [8]byte
		isl[0] = 0x01
		isl[1] = byte(c >> 8)
		isl[2] = byte(c & 0xFF)
		binary.BigEndian.PutUint32(isl[4:], uint32(c))
		m[c] = isl
	}
	return m
}
