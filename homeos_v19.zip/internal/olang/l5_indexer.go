// internal/olang/l5_indexer.go
//
// L5GoIndexer — phân tích Go source code → L5 nodes trong homeos.olang
//
// Quy trình (QT7):
//   1. go/ast parse source file
//   2. Trích xuất: package, func, type, const, var declarations
//   3. Mỗi declaration → L5 node với ISL address
//   4. Gọi appendL5 để ghi vào file
//
// ISL format cho L5 nodes:
//   [05][pkg_group][decl_type][index][attrs(4B)]
//   decl_type: 0x01=func, 0x02=type, 0x03=const, 0x04=var, 0x05=pkg

package olang

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"strings"
)

// L5Decl — một Go declaration đã được trích xuất
type L5Decl struct {
	Name     string // "MyFunc", "MyType", etc.
	Kind     L5Kind
	Pkg      string // package name
	File     string // source file
	Line     int
	Comment  string // godoc comment (nếu có)
	Receiver string // cho methods: "*MyStruct"
}

type L5Kind uint8

const (
	L5KindFunc  L5Kind = 0x01
	L5KindType  L5Kind = 0x02
	L5KindConst L5Kind = 0x03
	L5KindVar   L5Kind = 0x04
	L5KindPkg   L5Kind = 0x05
)

func (k L5Kind) String() string {
	switch k {
	case L5KindFunc:  return "func"
	case L5KindType:  return "type"
	case L5KindConst: return "const"
	case L5KindVar:   return "var"
	case L5KindPkg:   return "pkg"
	default:          return "unknown"
	}
}

// L5IndexResult kết quả index một Go package
type L5IndexResult struct {
	Pkg      string
	Added    int
	Skipped  int
	Failed   int
	Decls    []L5Decl
}

// IndexGoFile phân tích một .go file và trả về declarations
func IndexGoFile(filePath string) ([]L5Decl, error) {
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, filePath, nil, parser.ParseComments)
	if err != nil {
		return nil, fmt.Errorf("parse %s: %w", filePath, err)
	}

	pkg := f.Name.Name
	base := filepath.Base(filePath)
	var decls []L5Decl

	// Package itself
	decls = append(decls, L5Decl{
		Name: pkg,
		Kind: L5KindPkg,
		Pkg:  pkg,
		File: base,
		Line: 1,
	})

	for _, decl := range f.Decls {
		switch d := decl.(type) {
		case *ast.FuncDecl:
			name := d.Name.Name
			recv := ""
			if d.Recv != nil && len(d.Recv.List) > 0 {
				recv = formatExpr(d.Recv.List[0].Type)
				name = recv + "." + name
			}
			comment := ""
			if d.Doc != nil {
				comment = strings.TrimSpace(d.Doc.Text())
				if len(comment) > 120 {
					comment = comment[:120] + "…"
				}
			}
			decls = append(decls, L5Decl{
				Name:     name,
				Kind:     L5KindFunc,
				Pkg:      pkg,
				File:     base,
				Line:     fset.Position(d.Pos()).Line,
				Comment:  comment,
				Receiver: recv,
			})

		case *ast.GenDecl:
			for _, spec := range d.Specs {
				switch s := spec.(type) {
				case *ast.TypeSpec:
					comment := ""
					if d.Doc != nil {
						comment = strings.TrimSpace(d.Doc.Text())
						if len(comment) > 120 {
							comment = comment[:120] + "…"
						}
					}
					decls = append(decls, L5Decl{
						Name:    s.Name.Name,
						Kind:    L5KindType,
						Pkg:     pkg,
						File:    base,
						Line:    fset.Position(s.Pos()).Line,
						Comment: comment,
					})
				case *ast.ValueSpec:
					kind := L5KindVar
					if d.Tok == token.CONST {
						kind = L5KindConst
					}
					for _, name := range s.Names {
						decls = append(decls, L5Decl{
							Name: name.Name,
							Kind: kind,
							Pkg:  pkg,
							File: base,
							Line: fset.Position(name.Pos()).Line,
						})
					}
				}
			}
		}
	}

	return decls, nil
}

// IndexGoPackage phân tích tất cả .go files trong một directory
func IndexGoPackage(dir string) ([]L5Decl, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}

	var all []L5Decl
	seen := map[string]bool{}

	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".go") {
			continue
		}
		if strings.HasSuffix(e.Name(), "_test.go") {
			continue // bỏ test files
		}
		decls, err := IndexGoFile(filepath.Join(dir, e.Name()))
		if err != nil {
			continue
		}
		for _, d := range decls {
			key := d.Pkg + "." + d.Name
			if !seen[key] {
				seen[key] = true
				all = append(all, d)
			}
		}
	}
	return all, nil
}

// DeclToISL tạo ISL address 8 bytes cho một L5 declaration
// Format: [05][pkg_hash:1B][kind:1B][name_hash:1B][attrs:4B]
func DeclToISL(d L5Decl) [8]byte {
	var isl [8]byte
	isl[0] = 0x05 // layer 5
	// pkg hash (1B)
	ph := sha256.Sum256([]byte(d.Pkg))
	isl[1] = ph[0]
	// kind (1B)
	isl[2] = uint8(d.Kind)
	// name hash (1B)
	nh := sha256.Sum256([]byte(d.Name))
	isl[3] = nh[0]
	// attrs: full name hash truncated to 4B
	combined := sha256.Sum256([]byte(d.Pkg + "." + d.Name))
	binary.BigEndian.PutUint32(isl[4:8], binary.BigEndian.Uint32(combined[:4]))
	return isl
}

// AppendL5ToFile ghi một L5Decl vào homeos.olang
// DNA của L5 node = metadata về declaration (kind, pkg, file, line)
func AppendL5ToFile(olangPath string, d L5Decl) error {
	islAddr := DeclToISL(d)

	// Build DNA: kind(1) + line(2) + filename(var) + NUL + comment(var)
	meta := fmt.Sprintf("%s:%d", d.File, d.Line)
	if d.Comment != "" {
		meta += "\x00" + d.Comment
	}
	dna := append([]byte{uint8(d.Kind)}, []byte(meta)...)

	// Node name: "pkg.Name"
	nodeName := d.Pkg + "." + d.Name

	return appendL5Node(olangPath, islAddr, dna, nodeName)
}

// appendL5Node — low-level append vào layer 5
func appendL5Node(path string, islAddr [8]byte, dna []byte, name string) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if len(raw) < 280 || string(raw[:4]) != "OLNG" {
		return fmt.Errorf("bad file")
	}

	nb := []byte(name)
	if len(nb) > 255 {
		nb = nb[:255]
	}
	if len(dna) > 4096 {
		dna = dna[:4096]
	}

	// Dup ISL check
	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	edgeStart := len(raw) - nedges*EdgeSize
	if edgeStart < 280 {
		edgeStart = 280
	}
	for i := 280; i+20 < edgeStart; {
		if raw[i] == 'N' && raw[i+1] == 'D' {
			if string(raw[i+3:i+11]) == string(islAddr[:]) {
				return fmt.Errorf("duplicate ISL: %s", name)
			}
		}
		dl := int(binary.BigEndian.Uint32(raw[i+15 : i+19]))
		nl := int(raw[i+19])
		if dl < 0 || nl < 0 || dl > 65536 || nl > 255 {
			i++
			continue
		}
		i += 20 + dl + nl
	}

	// Build record
	rec := make([]byte, 20+len(dna)+len(nb))
	rec[0] = 'N'
	rec[1] = 'D'
	rec[2] = 0x05 // layer 5
	copy(rec[3:11], islAddr[:])
	binary.BigEndian.PutUint32(rec[11:], 0) // codepoint = 0 for L5
	binary.BigEndian.PutUint32(rec[15:], uint32(len(dna)))
	rec[19] = uint8(len(nb))
	copy(rec[20:], dna)
	copy(rec[20+len(dna):], nb)

	// Find insertion point: end of L5 section
	type layerInfo struct{ off, sz uint64 }
	layers := [9]layerInfo{}
	for i := 0; i < 9; i++ {
		o := 64 + i*24
		layers[i].off = binary.BigEndian.Uint64(raw[o+4 : o+12])
		layers[i].sz = binary.BigEndian.Uint64(raw[o+12 : o+20])
	}
	var at uint64
	if layers[5].sz > 0 {
		at = layers[5].off + layers[5].sz
	} else {
		// Hết các layer trước
		at = 280
		for i := 0; i < 5; i++ {
			if layers[i].sz > 0 {
				cand := layers[i].off + layers[i].sz
				if cand > at {
					at = cand
				}
			}
		}
	}

	out := make([]byte, 0, len(raw)+len(rec))
	out = append(out, raw[:at]...)
	out = append(out, rec...)
	out = append(out, raw[at:]...)

	// Update layer 5 index
	o5 := 64 + 5*24
	if layers[5].sz == 0 {
		binary.BigEndian.PutUint64(out[o5+4:], at)
	}
	binary.BigEndian.PutUint64(out[o5+12:], layers[5].sz+uint64(len(rec)))
	binary.BigEndian.PutUint32(out[o5+20:], binary.BigEndian.Uint32(out[o5+20:])+1)

	// Update layers after L5
	for i := 6; i < 9; i++ {
		o := 64 + i*24
		if layers[i].sz > 0 {
			binary.BigEndian.PutUint64(out[o+4:], binary.BigEndian.Uint64(out[o+4:])+uint64(len(rec)))
		}
	}
	binary.BigEndian.PutUint32(out[9:13], binary.BigEndian.Uint32(out[9:13])+1)

	h := sha256.Sum256(out[280:])
	copy(out[28:60], h[:])

	tmp := path + ".l5.tmp"
	if err := os.WriteFile(tmp, out, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// formatExpr chuyển ast.Expr thành string
func formatExpr(e ast.Expr) string {
	switch t := e.(type) {
	case *ast.StarExpr:
		return "*" + formatExpr(t.X)
	case *ast.Ident:
		return t.Name
	case *ast.SelectorExpr:
		return formatExpr(t.X) + "." + t.Sel.Name
	case *ast.ArrayType:
		return "[]" + formatExpr(t.Elt)
	default:
		return "?"
	}
}
