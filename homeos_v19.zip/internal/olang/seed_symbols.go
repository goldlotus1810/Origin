// internal/olang/seed_symbols.go
//
// SeedOpSymbols — gắn UTF-32 codepoints với L0 opcodes
//
// Vấn đề: L0 nodes (OP_SPHERE, OP_UNION...) không có codepoint
//         L1 nodes (●, ∪...) chưa được seed, không có silk edge → L0
//
// Giải pháp (QT5: bản chất quyết định vị trí):
//   ● (U+25CF BLACK CIRCLE) ─[EdgeWorldLink]─► OP_SPHERE (L0)
//   ∪ (U+222A UNION)        ─[EdgeWorldLink]─► OP_UNION  (L0)
//   ... etc.
//
// EdgeWorldLink (0x0E): "ký tự này đại diện cho khái niệm thực trong world"
// Đây là cầu nối từ ký hiệu ngôn ngữ → hành động thực thi

package olang

// SymbolOpMapping — ánh xạ đầy đủ symbol → opcode
// Unicode name → bản chất → opcode
type SymbolOpMapping struct {
	Codepoint   uint32
	Symbol      string
	UnicodeName string // tên chính thức Unicode
	OpName      string // tên opcode trong L0
	Opcode      byte   // DNA[0] của L0 node tương ứng
	L0ISL       [8]byte // ISL của L0 node (để tạo edge)

	// Ngữ nghĩa đầy đủ
	MathDef   string // định nghĩa toán học
	SDF_Sig   string // SDF function signature nếu có
	Langs     []string // cách đọc trong các ngôn ngữ
}

// SymbolTable — bảng ánh xạ chính thức
// QT3: đây là "sự thật vật lý" — đã chứng minh, dùng ==
var SymbolTable = []SymbolOpMapping{

	// ═══ SDF PRIMITIVES ══════════════════════════════════════
	{
		Codepoint:   0x25CF,
		Symbol:      "●",
		UnicodeName: "BLACK CIRCLE",
		OpName:      "OP_SPHERE",
		Opcode:      0x01,
		MathDef:     "SDFSphere(p, c, r) = length(p-c) - r",
		SDF_Sig:     "●(cx,cy,cz, r) → float",
		Langs:       []string{"sphere", "cầu", "球", "пуля"},
	},
	{
		Codepoint:   0x2300,
		Symbol:      "⌀",
		UnicodeName: "DIAMETER SIGN",
		OpName:      "OP_CAPSULE",
		Opcode:      0x02,
		MathDef:     "SDFCapsule(p, a, b, r) = length(p - proj(p, a→b)) - r",
		SDF_Sig:     "⌀(ax,ay,az, bx,by,bz, r) → float",
		Langs:       []string{"capsule", "nang", "カプセル"},
	},
	{
		Codepoint:   0x25A1,
		Symbol:      "□",
		UnicodeName: "WHITE SQUARE",
		OpName:      "OP_BOX",
		Opcode:      0x03,
		MathDef:     "SDFBox(p, b) = length(max(abs(p)-b, 0)) + min(max(p.x-b.x, max(p.y-b.y, p.z-b.z)), 0)",
		SDF_Sig:     "□(bx,by,bz) → float",
		Langs:       []string{"box", "hộp", "箱", "куб"},
	},
	{
		Codepoint:   0x25CC,
		Symbol:      "◌",
		UnicodeName: "DOTTED CIRCLE",
		OpName:      "OP_VOID",
		Opcode:      0x05,
		MathDef:     "SDFVoid() = +∞-1 (không gian trống — QT2: ∞-1, không phải ∞)",
		SDF_Sig:     "◌() → 1e10",
		Langs:       []string{"void", "rỗng", "空", "пустота"},
	},

	// ═══ SDF BOOLEAN OPS ══════════════════════════════════════
	{
		Codepoint:   0x222A,
		Symbol:      "∪",
		UnicodeName: "UNION",
		OpName:      "OP_UNION",
		Opcode:      0x10,
		MathDef:     "SmoothUnion(d1,d2,k) = -log(e^(-k*d1) + e^(-k*d2)) / k",
		SDF_Sig:     "∪(d1, d2, k) → float",
		Langs:       []string{"union", "hợp", "合", "объединение"},
	},
	{
		Codepoint:   0x2216,
		Symbol:      "∖",
		UnicodeName: "SET MINUS",
		OpName:      "OP_SUB",
		Opcode:      0x11,
		MathDef:     "SmoothSubtract(d1,d2,k) = log(e^(k*d2) + e^(k*d1)) / k",
		SDF_Sig:     "∖(d1, d2, k) → float",
		Langs:       []string{"subtract", "trừ", "差", "разность"},
	},
	{
		Codepoint:   0x2229,
		Symbol:      "∩",
		UnicodeName: "INTERSECTION",
		OpName:      "OP_INTERSECT",
		Opcode:      0x12,
		MathDef:     "SmoothIntersect(d1,d2,k) = max(d1, d2) smoothed",
		SDF_Sig:     "∩(d1, d2, k) → float",
		Langs:       []string{"intersect", "giao", "積", "пересечение"},
	},

	// ═══ TERRAIN / LIGHT ══════════════════════════════════════
	{
		Codepoint:   0x222B,
		Symbol:      "∫",
		UnicodeName: "INTEGRAL",
		OpName:      "OP_FBM",
		Opcode:      0x20,
		MathDef:     "FBM(p, octaves, H) = sum_{i=0}^{oct} amplitude^i * noise(freq^i * p)",
		SDF_Sig:     "∫(fbm, oct:int, h:float) → float",
		Langs:       []string{"fbm", "fractal brownian", "địa hình"},
	},
	{
		Codepoint:   0x2207,
		Symbol:      "∇",
		UnicodeName: "NABLA",
		OpName:      "OP_GRADIENT",
		Opcode:      0x21,
		MathDef:     "∇f(p) = (f(p+ε,y,z)-f(p-ε,y,z), ...) / 2ε — normal vector",
		SDF_Sig:     "∇(sdf_fn, p, ε) → vec3",
		Langs:       []string{"gradient", "nabla", "法線", "градиент"},
	},
	{
		Codepoint:   0x2600,
		Symbol:      "☀",
		UnicodeName: "BLACK SUN WITH RAYS",
		OpName:      "OP_LIGHT",
		Opcode:      0x22,
		MathDef:     "SunLight(t) = orbital_spline(t, inclination) → vec3 direction",
		SDF_Sig:     "☀(t:float) → vec3",
		Langs:       []string{"sunlight", "ánh sáng mặt trời", "太陽光", "солнце"},
	},

	// ═══ ORIGIN / CONTROL ══════════════════════════════════════
	{
		Codepoint:   0x25CB,
		Symbol:      "○",
		UnicodeName: "WHITE CIRCLE",
		OpName:      "OP_SEQ",
		Opcode:      0x60,
		MathDef:     "○(x) == x (identity) · ○(∅) == ○ (tự tạo sinh)",
		SDF_Sig:     "○ = Origin · tất cả là instance của ○",
		Langs:       []string{"origin", "nguồn gốc", "起源", "начало"},
	},

	// ═══ WORLD SYMBOLS ════════════════════════════════════════
	{
		Codepoint:   0x1F30D,
		Symbol:      "🌍",
		UnicodeName: "EARTH GLOBE EUROPE-AFRICA",
		OpName:      "OP_WORLD",
		Opcode:      0x00, // không có opcode trực tiếp — là WorldRoot
		MathDef:     "WorldRoot(seed) — gốc của SDF universe",
		SDF_Sig:     "🌍(seed:int) → world_sdf",
		Langs:       []string{"earth", "địa cầu", "地球", "세계"},
	},
	{
		Codepoint:   0x1F9EC,
		Symbol:      "🧬",
		UnicodeName: "DNA DOUBLE HELIX",
		OpName:      "OP_GENE",
		Opcode:      0x00, // GeneRegistry, không phải opcode
		MathDef:     "Gene.DNA() → string · mọi Gene có DNA string",
		SDF_Sig:     "🧬 = GeneRegistry",
		Langs:       []string{"dna", "gene", "遺伝子", "ген"},
	},
	{
		Codepoint:   0x1F6E1,
		Symbol:      "🛡",
		UnicodeName: "SHIELD",
		OpName:      "OP_GATE",
		Opcode:      0xFF,
		MathDef:     "Rule1: ¬harm_human (bất biến tuyệt đối)",
		SDF_Sig:     "🛡 = SecurityGate · 0xff",
		Langs:       []string{"gate", "bảo vệ", "防衛", "защита"},
	},

	// ═══ CONCEPT SYMBOLS ══════════════════════════════════════
	{
		Codepoint:   0x2764,
		Symbol:      "❤",
		UnicodeName: "HEAVY BLACK HEART",
		OpName:      "CONCEPT_LOVE",
		Opcode:      0x00, // concept, không phải opcode
		MathDef:     "❤ ≡ 💓 ≡ 💗 → ISL[K][Concept][Love]",
		Langs:       []string{"love", "yêu", "愛", "사랑", "liebe", "amour"},
	},

	// ═══ MATH CONCEPTS ════════════════════════════════════════
	{
		Codepoint:   0x2218,
		Symbol:      "∘",
		UnicodeName: "RING OPERATOR",
		OpName:      "OP_COMPOSE",
		Opcode:      0x0A, // OpCompose trong executor
		MathDef:     "(f∘g)(x) = f(g(x)) · COMPOSE op trong Node system",
		Langs:       []string{"compose", "hợp thành", "合成"},
	},
	{
		Codepoint:   0x221E,
		Symbol:      "∞",
		UnicodeName: "INFINITY",
		OpName:      "OP_INF_FORBIDDEN",
		Opcode:      0x00,
		MathDef:     "QT2: ∞ == SAI · ∞-1 == đúng · executor BLOWN khi gặp ∞",
		Langs:       []string{"infinity", "vô cực", "無限", "бесконечность"},
	},
	{
		Codepoint:   0x2205,
		Symbol:      "∅",
		UnicodeName: "EMPTY SET",
		OpName:      "OP_EMPTY",
		Opcode:      0x05, // tương đương OP_VOID
		MathDef:     "∅ = rỗng · tương đương ◌ (OP_VOID)",
		Langs:       []string{"empty", "rỗng", "空", "пустое"},
	},
}

// L0ISLFor trả về ISL của L0 node theo opcode
// Format thực tế trong file: dùng gene node registry format
// Nhìn vào dữ liệu: OP_SPHERE = 4f01010100000000
func L0ISLFor(opcode byte) [8]byte {
	// Tra bảng thực tế từ file (đã đo được)
	table := map[byte][8]byte{
		0x01: {0x4f, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00}, // OP_SPHERE
		0x02: {0x4f, 0x01, 0x01, 0x02, 0x00, 0x00, 0x00, 0x00}, // OP_CAPSULE
		0x03: {0x4f, 0x01, 0x01, 0x03, 0x00, 0x00, 0x00, 0x00}, // OP_BOX
		0x05: {0x50, 0x30, 0x70, 0x05, 0x00, 0x00, 0x00, 0x00}, // OP_VOID
		0x10: {0x4f, 0x02, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00}, // OP_UNION
		0x11: {0x4f, 0x02, 0x01, 0x02, 0x00, 0x00, 0x00, 0x00}, // OP_SUB
		0x12: {0x50, 0x30, 0x70, 0x12, 0x00, 0x00, 0x00, 0x00}, // OP_INTERSECT
		0x20: {0x50, 0x30, 0x70, 0x20, 0x00, 0x00, 0x00, 0x00}, // OP_FBM
		0x21: {0x50, 0x30, 0x70, 0x21, 0x00, 0x00, 0x00, 0x00}, // OP_GRADIENT
		0x22: {0x4f, 0x04, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00}, // OP_LIGHT
		0x60: {0x50, 0x30, 0x70, 0x60, 0x00, 0x00, 0x00, 0x00}, // OP_SEQ
		0xFF: {0x50, 0x30, 0x70, 0xFF, 0x00, 0x00, 0x00, 0x00}, // OP_GATE
		0x0A: {0x50, 0x30, 0x70, 0x0A, 0x00, 0x00, 0x00, 0x00}, // OP_COMPOSE (approx)
	}
	if isl, ok := table[opcode]; ok {
		return isl
	}
	// fallback: generic
	return [8]byte{0x50, 0x30, 0x70, opcode}
}

// SymbolL1ISL — tạo ISL cho L1 node của symbol
// Format chuẩn seeder: [0x01][0x09][hi][lo][cp:4B]
// (giống như các L1 nodes đã seed)
func SymbolL1ISL(cp uint32) [8]byte {
	var isl [8]byte
	isl[0] = 0x01 // L1
	isl[1] = 0x09 // math/symbol group (giống ∪ ∩ ∫ đã seed)
	isl[2] = byte(cp >> 24)
	isl[3] = byte(cp >> 16)
	isl[4] = byte(cp >> 8)
	isl[5] = byte(cp & 0xFF)
	// isl[6..7] = hash từ codepoint để tránh collision
	isl[6] = byte(cp>>12) ^ byte(cp>>4)
	isl[7] = byte(cp) ^ byte(cp>>8)
	return isl
}
