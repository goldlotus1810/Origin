package olang

import (
	"os"
	"strings"
	"testing"
)

func TestIndexGoFile_Basic(t *testing.T) {
	// Tạo temp Go file để test
	src := `package mytest

import "fmt"

// MyFunc does something useful
func MyFunc(x int) string {
	return fmt.Sprintf("%d", x)
}

// MyType là một struct mẫu
type MyType struct {
	Name string
	Age  int
}

// Method của MyType
func (m *MyType) String() string {
	return m.Name
}

const MaxItems = 100

var DefaultName = "HomeOS"
`
	f, err := os.CreateTemp("", "l5_test_*.go")
	if err != nil { t.Fatal(err) }
	defer os.Remove(f.Name())
	f.WriteString(src)
	f.Close()

	decls, err := IndexGoFile(f.Name())
	if err != nil { t.Fatalf("IndexGoFile: %v", err) }

	t.Logf("Found %d declarations:", len(decls))
	counts := map[L5Kind]int{}
	for _, d := range decls {
		t.Logf("  [%s] %s.%s (line %d)", d.Kind, d.Pkg, d.Name, d.Line)
		counts[d.Kind]++
	}

	// Verify expected declarations
	if counts[L5KindFunc] < 2 {
		t.Errorf("expected >= 2 funcs, got %d", counts[L5KindFunc])
	}
	if counts[L5KindType] < 1 {
		t.Errorf("expected >= 1 type, got %d", counts[L5KindType])
	}
	if counts[L5KindConst] < 1 {
		t.Errorf("expected >= 1 const, got %d", counts[L5KindConst])
	}
	if counts[L5KindVar] < 1 {
		t.Errorf("expected >= 1 var, got %d", counts[L5KindVar])
	}
	if counts[L5KindPkg] < 1 {
		t.Errorf("expected 1 pkg, got %d", counts[L5KindPkg])
	}
}

func TestDeclToISL_Unique(t *testing.T) {
	decls := []L5Decl{
		{Name: "MyFunc", Kind: L5KindFunc, Pkg: "agents"},
		{Name: "MyType", Kind: L5KindType, Pkg: "agents"},
		{Name: "MyFunc", Kind: L5KindFunc, Pkg: "silk"}, // same name, diff pkg
		{Name: "NewBrain", Kind: L5KindFunc, Pkg: "ws"},
		{Name: "SilkEdge", Kind: L5KindType, Pkg: "silk"},
	}

	seen := map[[8]byte]string{}
	for _, d := range decls {
		isl := DeclToISL(d)
		key := d.Pkg + "." + d.Name
		if prev, exists := seen[isl]; exists {
			t.Errorf("ISL collision: %s and %s have same ISL", key, prev)
		}
		seen[isl] = key
		// Verify layer byte = 0x05
		if isl[0] != 0x05 {
			t.Errorf("%s: layer byte = %02x, want 05", key, isl[0])
		}
		// Verify kind byte
		if isl[2] != uint8(d.Kind) {
			t.Errorf("%s: kind byte = %02x, want %02x", key, isl[2], uint8(d.Kind))
		}
		t.Logf("  %s → %x", key, isl)
	}
	t.Logf("All %d ISL addresses unique ✅", len(decls))
}

func TestIndexGoPackage_HomeOS(t *testing.T) {
	// Index package olang thật (package này)
	decls, err := IndexGoPackage(".")
	if err != nil { t.Fatalf("IndexGoPackage: %v", err) }

	t.Logf("Package olang: %d declarations", len(decls))
	if len(decls) < 10 {
		t.Errorf("expected >= 10 decls from olang package, got %d", len(decls))
	}

	// Verify có L5Decl struct
	found := false
	for _, d := range decls {
		if d.Name == "L5Decl" && d.Kind == L5KindType {
			found = true
			t.Logf("  Found L5Decl type at %s:%d", d.File, d.Line)
		}
	}
	if !found {
		t.Error("expected to find L5Decl type in olang package")
	}
}

func TestAppendL5ToFile(t *testing.T) {
	// Tạo temp olang file
	tmpDir := t.TempDir()
	olangPath := tmpDir + "/test.olang"

	// Copy homeos.olang header structure (280 bytes)
	header := make([]byte, 280)
	copy(header[0:4], "OLNG")
	header[4] = 0; header[5] = 18 // version 18
	header[8] = 5                  // 5 layers

	if err := os.WriteFile(olangPath, header, 0644); err != nil {
		t.Fatal(err)
	}

	// Append L5 node
	decl := L5Decl{
		Name:    "TestFunc",
		Kind:    L5KindFunc,
		Pkg:     "testpkg",
		File:    "test.go",
		Line:    42,
		Comment: "TestFunc là hàm test",
	}

	if err := AppendL5ToFile(olangPath, decl); err != nil {
		t.Fatalf("AppendL5ToFile: %v", err)
	}

	// Verify node được ghi
	raw, _ := os.ReadFile(olangPath)
	nnodes := int(raw[9])<<24 | int(raw[10])<<16 | int(raw[11])<<8 | int(raw[12])
	if nnodes != 1 {
		t.Errorf("expected 1 node, got %d", nnodes)
	}

	// Verify ND marker tồn tại
	if !strings.Contains(string(raw[280:]), "testpkg.TestFunc") {
		t.Error("node name not found in file")
	}

	// Verify SHA256 updated (bytes [28:60] không còn all-zero)
	allZero := true
	for _, b := range raw[28:60] {
		if b != 0 { allZero = false; break }
	}
	if allZero {
		t.Error("SHA256 not updated")
	}

	t.Logf("✅ L5 node appended: nnodes=%d size=%d", nnodes, len(raw))
}
