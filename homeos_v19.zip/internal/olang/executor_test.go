// internal/olang/executor_test.go
//
// Test L0 executor — kiểm tra từng opcode thực sự hoạt động đúng không
// QT3: toán học trừu tượng → vật lý là sự thật
// Mỗi test = chứng minh opcode đúng

package olang

import (
	"math"
	"testing"
)

// ─── helper: build OlangNode từ raw DNA bytes ──────────────────
//
// nodeFromDNA tự động prepend b[0]=QR|SDF=0x42 nếu chưa có header.
// Tests chỉ truyền L0 opcodes thuần ([OpAdd, OpRet]...) → b[0] header tự động.

func nodeFromDNA(dna []byte) *OlangNode {
	// Thêm b[0]=DNAHeaderQRSDF nếu chưa có
	fullDNA := make([]byte, 1+len(dna))
	fullDNA[0] = DNAHeaderQRSDF // 0x42 = QR|SDF
	copy(fullDNA[1:], dna)
	return &OlangNode{
		OlangNodeHeader: OlangNodeHeader{DNALen: uint32(len(fullDNA))},
		DNA: fullDNA,
	}
}

// ─── Math ops ─────────────────────────────────────────────────

func TestExecute_ADD(t *testing.T) {
	// PUSH 3.0, PUSH 4.0, ADD → 7.0
	ctx := NewExecContext()
	ctx.push(FloatVal(3.0))
	ctx.push(FloatVal(4.0))
	node := nodeFromDNA([]byte{OpAdd, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 7.0 {
		t.Errorf("ADD: got %v want 7.0", result)
	}
	t.Logf("✅ ADD: 3.0 + 4.0 = %g", result.Float)
}

func TestExecute_MUL(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(6.0))
	ctx.push(FloatVal(7.0))
	node := nodeFromDNA([]byte{OpMul, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 42.0 {
		t.Errorf("MUL: got %v want 42.0", result)
	}
	t.Logf("✅ MUL: 6.0 × 7.0 = %g", result.Float)
}

func TestExecute_DIV(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(10.0))
	ctx.push(FloatVal(2.0))
	node := nodeFromDNA([]byte{OpDiv, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 5.0 {
		t.Errorf("DIV: got %v want 5.0", result)
	}
	t.Logf("✅ DIV: 10.0 / 2.0 = %g", result.Float)
}

func TestExecute_DIV_ByZero(t *testing.T) {
	// QT2: ∞ == không tồn tại → DIV/0 phải bị BLOWN
	ctx := NewExecContext()
	ctx.push(FloatVal(1.0))
	ctx.push(FloatVal(0.0))
	node := nodeFromDNA([]byte{OpDiv, OpRet})
	_, err := Execute(node, ctx)
	if err == nil {
		t.Error("DIV/0 should return BLOWN error (QT2: ∞ không tồn tại)")
	} else {
		t.Logf("✅ DIV/0 BLOWN: %v", err)
	}
}

func TestExecute_SUB(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(10.0))
	ctx.push(FloatVal(3.0))
	node := nodeFromDNA([]byte{OpSubN, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 7.0 {
		t.Errorf("SUB: got %v want 7.0", result)
	}
	t.Logf("✅ SUB: 10.0 - 3.0 = %g", result.Float)
}

func TestExecute_ABS(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(-5.5))
	node := nodeFromDNA([]byte{OpAbs, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 5.5 {
		t.Errorf("ABS: got %v want 5.5", result)
	}
	t.Logf("✅ ABS: |-5.5| = %g", result.Float)
}

func TestExecute_SQRT(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(9.0))
	node := nodeFromDNA([]byte{OpSqrt, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float-3.0)) > 0.0001 {
		t.Errorf("SQRT: got %v want 3.0", result)
	}
	t.Logf("✅ SQRT: √9 = %g", result.Float)
}

func TestExecute_SIN(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(0.0)) // sin(0) = 0
	node := nodeFromDNA([]byte{OpSin, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)) > 0.0001 {
		t.Errorf("SIN(0): got %v want 0.0", result)
	}
	t.Logf("✅ SIN(0) = %g", result.Float)
}

func TestExecute_SIN_HalfPi(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(float32(math.Pi / 2))) // sin(π/2) = 1
	node := nodeFromDNA([]byte{OpSin, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)-1.0) > 0.0001 {
		t.Errorf("SIN(π/2): got %v want 1.0", result)
	}
	t.Logf("✅ SIN(π/2) = %g", result.Float)
}

func TestExecute_COS_Zero(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(0.0)) // cos(0) = 1
	node := nodeFromDNA([]byte{OpCos, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)-1.0) > 0.0001 {
		t.Errorf("COS(0): got %v want 1.0", result)
	}
	t.Logf("✅ COS(0) = %g", result.Float)
}

func TestExecute_MIN(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(3.0))
	ctx.push(FloatVal(7.0))
	node := nodeFromDNA([]byte{OpMinF, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 3.0 {
		t.Errorf("MIN: got %v want 3.0", result)
	}
	t.Logf("✅ MIN(3, 7) = %g", result.Float)
}

func TestExecute_MAX(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(3.0))
	ctx.push(FloatVal(7.0))
	node := nodeFromDNA([]byte{OpMaxF, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 7.0 {
		t.Errorf("MAX: got %v want 7.0", result)
	}
	t.Logf("✅ MAX(3, 7) = %g", result.Float)
}

func TestExecute_MIX(t *testing.T) {
	// MIX(a, b, t) = a*(1-t) + b*t
	// MIX(0, 10, 0.3) = 3.0
	ctx := NewExecContext()
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(10.0))
	ctx.push(FloatVal(0.3))
	node := nodeFromDNA([]byte{OpMixF, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)-3.0) > 0.001 {
		t.Errorf("MIX(0, 10, 0.3): got %v want 3.0", result)
	}
	t.Logf("✅ MIX(0, 10, 0.3) = %g", result.Float)
}

func TestExecute_CLAMP(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(FloatVal(5.0)) // value
	ctx.push(FloatVal(0.0)) // min
	ctx.push(FloatVal(3.0)) // max → 5 clamped to 3
	node := nodeFromDNA([]byte{OpClamp, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float != 3.0 {
		t.Errorf("CLAMP(5, 0, 3): got %v want 3.0", result)
	}
	t.Logf("✅ CLAMP(5, 0, 3) = %g", result.Float)
}

// ─── Logic ops ────────────────────────────────────────────────

func TestExecute_Logic(t *testing.T) {
	tests := []struct {
		name    string
		a, b    bool
		op      byte
		want    bool
	}{
		{"AND T T", true, true,  OpAnd, true},
		{"AND T F", true, false, OpAnd, false},
		{"OR  F T", false, true, OpOr,  true},
		{"OR  F F", false, false, OpOr, false},
	}
	for _, tc := range tests {
		ctx := NewExecContext()
		ctx.push(Value{Kind: KindBool, Bool: tc.a})
		ctx.push(Value{Kind: KindBool, Bool: tc.b})
		node := nodeFromDNA([]byte{tc.op, OpRet})
		result, err := Execute(node, ctx)
		if err != nil { t.Errorf("%s: %v", tc.name, err); continue }
		if result.Kind != KindBool || result.Bool != tc.want {
			t.Errorf("%s: got %v want %v", tc.name, result.Bool, tc.want)
		} else {
			t.Logf("✅ %s = %v", tc.name, result.Bool)
		}
	}
}

func TestExecute_NOT(t *testing.T) {
	ctx := NewExecContext()
	ctx.push(Value{Kind: KindBool, Bool: true})
	node := nodeFromDNA([]byte{OpNot, OpRet})
	result, _ := Execute(node, ctx)
	if result.Bool != false {
		t.Error("NOT true should be false")
	}
	t.Logf("✅ NOT true = false")
}

// ─── SDF ops ──────────────────────────────────────────────────

func TestExecute_SDF_Sphere_AtSurface(t *testing.T) {
	// SDFSphere(p, center, r): dist = |p - center| - r
	// Point (1,0,0), center (0,0,0), r=1 → dist=0 (on surface)
	ctx := NewExecContext()
	// Stack: px py pz cx cy cz r
	ctx.push(FloatVal(1.0)) // px
	ctx.push(FloatVal(0.0)) // py
	ctx.push(FloatVal(0.0)) // pz
	ctx.push(FloatVal(0.0)) // cx
	ctx.push(FloatVal(0.0)) // cy
	ctx.push(FloatVal(0.0)) // cz
	ctx.push(FloatVal(1.0)) // r
	node := nodeFromDNA([]byte{OpSphere, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)) > 0.001 {
		t.Errorf("SDFSphere surface: got %v want 0.0", result)
	}
	t.Logf("✅ SDFSphere(p=(1,0,0), c=(0,0,0), r=1) = %g (on surface)", result.Float)
}

func TestExecute_SDF_Sphere_Inside(t *testing.T) {
	// Point (0,0,0), center (0,0,0), r=1 → dist=-1 (inside)
	ctx := NewExecContext()
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(1.0))
	node := nodeFromDNA([]byte{OpSphere, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)+1.0) > 0.001 {
		t.Errorf("SDFSphere inside: got %v want -1.0", result)
	}
	t.Logf("✅ SDFSphere(p=(0,0,0), c=(0,0,0), r=1) = %g (inside)", result.Float)
}

func TestExecute_SDF_Sphere_Outside(t *testing.T) {
	// Point (3,0,0), center (0,0,0), r=1 → dist=2 (outside)
	ctx := NewExecContext()
	ctx.push(FloatVal(3.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(1.0))
	node := nodeFromDNA([]byte{OpSphere, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || math.Abs(float64(result.Float)-2.0) > 0.001 {
		t.Errorf("SDFSphere outside: got %v want 2.0", result)
	}
	t.Logf("✅ SDFSphere(p=(3,0,0), c=(0,0,0), r=1) = %g (outside)", result.Float)
}

func TestExecute_SDF_SmoothUnion(t *testing.T) {
	// SmoothUnion(d1, d2, k) = min(d1, d2) blended
	// k=0 → exact min
	// SmoothUnion(1.0, 3.0, k→0) ≈ 1.0
	ctx := NewExecContext()
	ctx.push(FloatVal(1.0)) // d1
	ctx.push(FloatVal(3.0)) // d2
	ctx.push(FloatVal(0.01)) // k (small = close to min)
	node := nodeFromDNA([]byte{OpUnion, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat || result.Float > 1.1 {
		t.Errorf("SmoothUnion(1,3,0.01): got %v want ≈1.0", result)
	}
	t.Logf("✅ SmoothUnion(1.0, 3.0, k=0.01) = %g", result.Float)
}

func TestExecute_SDF_SmoothUnion_Blend(t *testing.T) {
	// SmoothUnion(0.0, 0.0, k=0.3) = blended → kết quả < 0
	ctx := NewExecContext()
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.3))
	node := nodeFromDNA([]byte{OpUnion, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindFloat {
		t.Error("SmoothUnion should return float")
	}
	t.Logf("✅ SmoothUnion(0, 0, k=0.3) = %g (smooth blend region)", result.Float)
}

// ─── Flow ops ─────────────────────────────────────────────────

func TestExecute_GATE(t *testing.T) {
	ctx := NewExecContext()
	node := nodeFromDNA([]byte{OpGate, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindBool || !result.Bool {
		t.Error("GATE should return true (pass)")
	}
	if len(ctx.Output) == 0 || ctx.Output[0] != "🛡 GATE: pass" {
		t.Error("GATE should log '🛡 GATE: pass'")
	}
	t.Logf("✅ GATE: %v | log: %v", result, ctx.Output)
}

func TestExecute_EMIT(t *testing.T) {
	ctx := NewExecContext()
	node := nodeFromDNA([]byte{OpEmit, 0xDE, 0xAD, 0xBE, 0xEF, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindSignal || result.Str != "deadbeef" {
		t.Errorf("EMIT: got %v want signal:deadbeef", result)
	}
	t.Logf("✅ EMIT 0xDEADBEEF → signal:%s", result.Str)
}

func TestExecute_DREAM(t *testing.T) {
	ctx := NewExecContext()
	node := nodeFromDNA([]byte{OpDream, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindSignal {
		t.Error("DREAM should emit signal")
	}
	t.Logf("✅ DREAM: %v | output: %v", result, ctx.Output)
}

func TestExecute_Fuel_Limit(t *testing.T) {
	// SecurityGate Rule 2: không vòng lặp vô hạn → fuel exhausted
	ctx := NewExecContext()
	ctx.Fuel = 5 // very low fuel

	// Nhiều NOPs (ADD sau khi stack rỗng)
	dna := make([]byte, 100)
	for i := range dna { dna[i] = OpAdd }
	node := nodeFromDNA(dna)
	_, err := Execute(node, ctx)
	if err == nil {
		t.Error("Should BLOWN when fuel = 0")
	}
	t.Logf("✅ Fuel limit enforced: %v", err)
}

func TestExecute_IF_True(t *testing.T) {
	// IF true → thực thi EMIT tiếp theo
	ctx := NewExecContext()
	ctx.push(Value{Kind: KindBool, Bool: true})
	node := nodeFromDNA([]byte{OpIf, OpEmit, 0x01, 0x02, 0x03, 0x04, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	if result.Kind != KindSignal {
		t.Errorf("IF true: should execute EMIT, got %v", result)
	}
	t.Logf("✅ IF true → EMIT executed: %v", result)
}

func TestExecute_IF_False(t *testing.T) {
	// IF false → skip EMIT(4B), RET → pop 3.0
	// Stack lúc IF: cond phải là TOP → push 3.0 TRƯỚC, push false SAU
	ctx := NewExecContext()
	ctx.push(FloatVal(3.0))                                         // sẽ là kết quả sau RET
	ctx.push(Value{Kind: KindBool, Bool: false})                    // cond — TOP of stack
	node := nodeFromDNA([]byte{OpIf, OpEmit, 0x01, 0x02, 0x03, 0x04, OpRet})
	result, err := Execute(node, ctx)
	if err != nil { t.Fatal(err) }
	// IF pop false → skip EMIT+4B → pc=6 → OpRet → pop FloatVal(3.0)
	if result.Kind == KindSignal {
		t.Errorf("IF false: EMIT should be skipped, got signal %v", result)
	}
	if result.Kind != KindFloat || result.Float != 3.0 {
		t.Errorf("IF false: expected FloatVal(3.0), got %v", result)
	}
	t.Logf("✅ IF false → EMIT+payload skipped, RET pops 3.0 = %v", result)
}

// ─── Composition test (QT6: SDF ⧺ ISL) ───────────────────────

func TestExecute_SphereAtOrigin_ComposeUnion(t *testing.T) {
	// Tạo 2 spheres rồi SmoothUnion
	// sphere1: center(0,0,0) r=1 tại điểm (2,0,0) → dist=1
	// sphere2: center(3,0,0) r=1 tại điểm (2,0,0) → dist=0 (surface)
	// SmoothUnion(1, 0, k=0.3) ≈ gần 0

	ctx := NewExecContext()

	// Sphere 1: dist=1
	ctx.push(FloatVal(2.0)); ctx.push(FloatVal(0.0)); ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(0.0)); ctx.push(FloatVal(0.0)); ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(1.0))
	d1Node := nodeFromDNA([]byte{OpSphere, OpRet})
	d1, _ := Execute(d1Node, ctx)

	// Sphere 2: dist=0
	ctx.push(FloatVal(2.0)); ctx.push(FloatVal(0.0)); ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(3.0)); ctx.push(FloatVal(0.0)); ctx.push(FloatVal(0.0))
	ctx.push(FloatVal(1.0))
	d2, _ := Execute(d1Node, ctx)

	// SmoothUnion
	ctx.push(d1)
	ctx.push(d2)
	ctx.push(FloatVal(0.3))
	unionNode := nodeFromDNA([]byte{OpUnion, OpRet})
	result, err := Execute(unionNode, ctx)
	if err != nil { t.Fatal(err) }
	t.Logf("✅ Sphere1(dist=%g) ∪ Sphere2(dist=%g) k=0.3 → %g",
		d1.Float, d2.Float, result.Float)
}
