package olang

import (
	"path/filepath"
	"runtime"
	"testing"
)

// olangPath tìm homeos.olang từ repo root
func olangPath() string {
	_, file, _, _ := runtime.Caller(0)
	root := filepath.Join(filepath.Dir(file), "..", "..")
	return filepath.Join(root, "homeos.olang")
}

func TestReadFile_RealFile(t *testing.T) {
	res, err := ReadFile(olangPath())
	if err != nil {
		t.Fatalf("ReadFile: %v", err)
	}

	t.Logf("Stats: %s", res.Stats())

	// Verify node count matches TRUTH.md
	if res.NodeCount < 4800 {
		t.Errorf("expected ≥4800 nodes, got %d", res.NodeCount)
	}

	// Verify edge count
	if res.EdgeCount < 1400 {
		t.Errorf("expected ≥1400 edges, got %d", res.EdgeCount)
	}

	// Verify layers hiện diện
	for _, layer := range []uint8{0, 1, 2, 3, 4, 5, 6, 7} {
		if len(res.ByLayer[layer]) == 0 {
			t.Errorf("L%d: expected nodes, got 0", layer)
		} else {
			t.Logf("  L%d: %d nodes", layer, len(res.ByLayer[layer]))
		}
	}

	// Verify L0 có OP_ nodes
	l0 := res.ByLayer[0]
	hasOP := false
	for _, n := range l0 {
		if len(n.Name) > 3 && n.Name[:3] == "OP_" {
			hasOP = true
			break
		}
	}
	if !hasOP {
		t.Errorf("L0: expected OP_ nodes")
	}

	// Corrupt nodes phải ít (< 5)
	if len(res.Corrupt) > 5 {
		t.Errorf("too many corrupt nodes: %d", len(res.Corrupt))
		for _, c := range res.Corrupt {
			t.Logf("  corrupt: layer=%d isl=%016x name=%q", c.Layer, c.ISLAddr, c.Name)
		}
	} else if len(res.Corrupt) > 0 {
		t.Logf("Corrupt nodes (%d):", len(res.Corrupt))
		for _, c := range res.Corrupt {
			t.Logf("  layer=%d isl=%016x name=%q", c.Layer, c.ISLAddr, c.Name)
		}
	}

	// Verify edges có src/dst hợp lệ
	if len(res.Edges) > 0 {
		e := res.Edges[0]
		if e.Src == 0 || e.Dst == 0 {
			t.Errorf("edge[0] has zero src/dst: src=%016x dst=%016x", e.Src, e.Dst)
		}
		t.Logf("  Edge[0]: src=%016x dst=%016x type=0x%02x", e.Src, e.Dst, e.Type)
	}
}

func TestParseBytes_Minimal(t *testing.T) {
	// Build 1 node nhỏ nhất hợp lệ
	// Format: "OLNG" + 12B header + ... + "ND" + layer + ISL(8) + cp(4,BE) + dnaLen(4,BE) + nameLen(1) + dna + name
	raw := make([]byte, 0, 200)

	// Header: 20 bytes minimum
	raw = append(raw, 'O', 'L', 'N', 'G')  // magic
	raw = append(raw, 0, 0, 0, 0)           // [4:8]
	raw = append(raw, 0, 0, 0, 0)           // [8:12] node count
	raw = append(raw, 0, 0, 0, 0)           // [12:16]
	raw = append(raw, 0, 0, 0, 0)           // [16:20] nedges = 0

	// Pad to 280 bytes (where nodes start)
	for len(raw) < 280 {
		raw = append(raw, 0)
	}

	// 1 node: layer=3, ISL=0x0102030400000000, cp=0x00004E00, DNA="hello"
	dna := []byte("hello")
	name := []byte("test_node")
	raw = append(raw, 'N', 'D')           // magic
	raw = append(raw, 3)                  // layer L3
	raw = append(raw, 0x01,0x02,0x03,0x04,0,0,0,0) // ISL addr (8B)
	raw = append(raw, 0,0,0x4E,0x00)     // cp = U+4E00 (一)
	raw = append(raw, 0,0,0,byte(len(dna)))  // dnaLen BE
	raw = append(raw, byte(len(name)))    // nameLen
	raw = append(raw, dna...)
	raw = append(raw, name...)

	res, err := ParseBytes(raw)
	if err != nil {
		t.Fatalf("ParseBytes: %v", err)
	}

	if res.NodeCount != 1 {
		t.Errorf("want 1 node, got %d", res.NodeCount)
	}
	n := res.ByLayer[3][0]
	if n.Name != "test_node" {
		t.Errorf("want name %q, got %q", "test_node", n.Name)
	}
	if string(n.DNA) != "hello" {
		t.Errorf("want DNA %q, got %q", "hello", n.DNA)
	}
	t.Logf("✓ ParseBytes: node %q layer=%d DNA=%q", n.Name, n.Layer, n.DNA)
}

func TestLoadFile_Populated(t *testing.T) {
	f, err := LoadFile(olangPath())
	if err != nil {
		t.Fatalf("LoadFile: %v", err)
	}

	// Verify layers được populate
	total := 0
	for l := uint8(0); l <= 8; l++ {
		n := len(f.Layers[l])
		total += n
		if n > 0 {
			t.Logf("  L%d: %d nodes", l, n)
		}
	}
	if total < 4800 {
		t.Errorf("want ≥4800 total nodes, got %d", total)
	}
	if f.TotalNodes != total {
		t.Errorf("TotalNodes mismatch: field=%d counted=%d", f.TotalNodes, total)
	}
	if f.TotalEdges < 1400 {
		t.Errorf("want ≥1400 edges, got %d", f.TotalEdges)
	}

	// Spot check: L0 node có DNA
	l0 := f.Layers[0]
	if len(l0) == 0 {
		t.Fatal("L0 empty")
	}
	first := l0[0]
	if len(first.DNA) == 0 {
		t.Errorf("L0[0] has empty DNA")
	}
	t.Logf("✓ LoadFile: %d nodes %d edges, L0[0].DNA=%v", total, f.TotalEdges, first.DNA[:min(4, len(first.DNA))])
}

func min(a, b int) int {
	if a < b { return a }
	return b
}
