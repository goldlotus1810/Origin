// internal/olang/export.go
//
// OlangExport — Chief trích xuất subtree từ homeos.olang
// thành worker_X.olang nhỏ để ship đến thiết bị.
//
// Nguyên tắc (TRUTH.md):
//   Worker = HomeOS tại thiết bị — cần đúng những gì nó làm
//   Worker KHÔNG cần toàn bộ L1 UTF32 (168K ký tự)
//   Worker KHÔNG cần L5 Programming, L6 Perception (nếu không dùng)
//
// Cấu trúc worker.olang (ví dụ light worker, ~64KB):
//   L0 Primitives  — bắt buộc (logic, SDF opcodes)
//   L4 Objects     — đèn, thiết bị cụ thể
//   L7 Programs    — Skill code của worker này
//   Silk edges     — chỉ edges liên quan
//
// Flow:
//   Chief.ExportWorker("light_living") → WorkerSpec
//       → LoadFile("homeos.olang")
//       → ExtractSubtree(spec)        — lọc nodes theo spec
//       → resolveEdges()              — giữ edges giữa nodes đã chọn
//       → WriteTo("worker_light_living.olang")
//       → ship qua LAN → olang run worker_light_living.olang

package olang

import (
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// WorkerSpec — mô tả những gì worker cần
// Chief điền spec này dựa trên thiết bị và skills của worker
type WorkerSpec struct {
	// ID duy nhất của worker — dùng làm tên file output
	WorkerID string // e.g. "light_living", "hvac_main", "camera_01"

	// Layers cần thiết (L0 luôn được include)
	Layers []uint8

	// ISL addresses cụ thể cần include
	// Chief lấy từ: device capabilities + skill dependencies
	ISLAddrs []uint64

	// Codepoints cần thiết (UTF32 subset)
	// Chỉ include ký tự worker thực sự dùng
	Codepoints []uint32

	// NodeNames — tên nodes cần include (fallback nếu không có ISL)
	NodeNames []string

	// IncludeAllQR — include mọi QR node trong layers đã chọn
	IncludeAllQR bool

	// Metadata
	DeviceType string // "light", "hvac", "camera", "lock"
	DeviceIP   string
	CreatedAt  time.Time
}

// ExportResult — kết quả export
type ExportResult struct {
	WorkerID   string
	OutputPath string
	NodeCount  int
	EdgeCount  int
	SizeBytes  int64
	Layers     map[uint8]int // nodes per layer
	Duration   time.Duration
}

func (r ExportResult) String() string {
	layerInfo := []string{}
	for l := uint8(0); l <= 8; l++ {
		if n, ok := r.Layers[l]; ok && n > 0 {
			layerInfo = append(layerInfo, fmt.Sprintf("L%d=%d", l, n))
		}
	}
	return fmt.Sprintf("worker=%s nodes=%d edges=%d size=%dKB layers=[%s] time=%v",
		r.WorkerID, r.NodeCount, r.EdgeCount,
		r.SizeBytes/1024,
		strings.Join(layerInfo, " "),
		r.Duration.Round(time.Millisecond))
}

// Exporter — trích xuất subtree từ homeos.olang
type Exporter struct {
	sourcePath string
	source     *ReadResult
}

// NewExporter load source olang file và sẵn sàng export
func NewExporter(sourcePath string) (*Exporter, error) {
	f, err := os.Open(sourcePath)
	if err != nil {
		return nil, fmt.Errorf("export: open %q: %w", sourcePath, err)
	}
	defer f.Close()

	result, err := ReadFrom(f)
	if err != nil {
		return nil, fmt.Errorf("export: parse %q: %w", sourcePath, err)
	}

	return &Exporter{sourcePath: sourcePath, source: result}, nil
}

// Export trích xuất worker.olang theo spec
// outputDir: thư mục để lưu file output
func (e *Exporter) Export(spec WorkerSpec, outputDir string) (*ExportResult, error) {
	start := time.Now()
	if spec.WorkerID == "" {
		return nil, fmt.Errorf("export: WorkerID required")
	}
	if spec.CreatedAt.IsZero() {
		spec.CreatedAt = time.Now()
	}

	// 1. Chọn nodes theo spec
	selected := e.selectNodes(spec)

	// 2. Resolve edges — chỉ giữ edges giữa selected nodes
	islSet := make(map[uint64]bool, len(selected))
	for _, n := range selected {
		islSet[n.ISLAddr] = true
	}
	var edges []*EdgeRecord
	for _, edge := range e.source.Edges {
		if islSet[edge.Src] && islSet[edge.Dst] {
			edges = append(edges, edge)
		}
	}

	// 3. Ghi worker.olang
	filename := fmt.Sprintf("worker_%s.olang", spec.WorkerID)
	outputPath := filepath.Join(outputDir, filename)

	layerCounts := make(map[uint8]int)
	for _, n := range selected {
		layerCounts[n.Layer]++
	}

	if err := writeWorkerOlang(outputPath, spec, selected, edges); err != nil {
		return nil, fmt.Errorf("export: write %q: %w", outputPath, err)
	}

	info, _ := os.Stat(outputPath)
	size := int64(0)
	if info != nil {
		size = info.Size()
	}

	return &ExportResult{
		WorkerID:   spec.WorkerID,
		OutputPath: outputPath,
		NodeCount:  len(selected),
		EdgeCount:  len(edges),
		SizeBytes:  size,
		Layers:     layerCounts,
		Duration:   time.Since(start),
	}, nil
}

// selectNodes chọn nodes phù hợp với spec
func (e *Exporter) selectNodes(spec WorkerSpec) []*NodeRecord {
	// Build lookup sets
	islSet := make(map[uint64]bool, len(spec.ISLAddrs))
	for _, a := range spec.ISLAddrs {
		islSet[a] = true
	}
	cpSet := make(map[uint32]bool, len(spec.Codepoints))
	for _, cp := range spec.Codepoints {
		cpSet[cp] = true
	}
	nameSet := make(map[string]bool, len(spec.NodeNames))
	for _, nm := range spec.NodeNames {
		nameSet[strings.ToLower(nm)] = true
	}
	layerSet := make(map[uint8]bool, len(spec.Layers))
	for _, l := range spec.Layers {
		layerSet[l] = true
	}
	// L0 luôn bắt buộc
	layerSet[LayerPrimitives] = true

	seen := make(map[uint64]bool)
	var result []*NodeRecord

	add := func(n *NodeRecord) {
		if seen[n.ISLAddr] {
			return
		}
		seen[n.ISLAddr] = true
		result = append(result, n)
	}

	for _, n := range e.source.Nodes {
		// Rule 1: L0 — luôn include
		if n.Layer == LayerPrimitives {
			add(n)
			continue
		}

		// Rule 2: Explicit ISL address match
		if islSet[n.ISLAddr] {
			add(n)
			continue
		}

		// Rule 3: Codepoint match
		if cpSet[n.CP] {
			add(n)
			continue
		}

		// Rule 4: Name match
		if nameSet[strings.ToLower(n.Name)] {
			add(n)
			continue
		}

		// Rule 5: Layer match + IncludeAllQR
		if layerSet[n.Layer] && spec.IncludeAllQR {
			add(n)
			continue
		}

		// Rule 6: Layer match (L0 đã xử lý ở trên)
		if layerSet[n.Layer] && n.Layer != LayerUTF32 {
			// L1 quá lớn — chỉ include nếu explicit
			add(n)
			continue
		}
	}

	return result
}

// writeWorkerOlang ghi worker.olang binary
// Format giống homeos.olang nhưng chỉ chứa nodes đã chọn
func writeWorkerOlang(path string, spec WorkerSpec, nodes []*NodeRecord, edges []*EdgeRecord) error {
	// Tính size để estimate buffer
	// Header: 64B + LayerIndex: 9*24B = 280B
	// Mỗi node: 20B header + dna + name
	// Mỗi edge: 17B

	const headerSize = 64
	const layerIndexSize = 9 * 24

	// Build layer index
	type layerInfo struct {
		nodes  []*NodeRecord
		offset uint64
		size   uint64
	}
	layers := make(map[uint8]*layerInfo)
	for _, n := range nodes {
		if layers[n.Layer] == nil {
			layers[n.Layer] = &layerInfo{}
		}
		layers[n.Layer].nodes = append(layers[n.Layer].nodes, n)
	}

	// Encode nodes per layer
	type encodedLayer struct {
		id   uint8
		data []byte
	}
	var encodedLayers []encodedLayer

	currentOffset := uint64(headerSize + layerIndexSize)

	layerIndex := make([]encodedLayer, 9) // placeholder
	for i := range layerIndex {
		layerIndex[i].id = uint8(i)
	}

	for layerID := uint8(0); layerID <= 8; layerID++ {
		li, ok := layers[layerID]
		if !ok || len(li.nodes) == 0 {
			continue
		}

		var buf []byte
		for _, n := range li.nodes {
			buf = append(buf, encodeNode(n)...)
		}
		encodedLayers = append(encodedLayers, encodedLayer{id: layerID, data: buf})
		layers[layerID].offset = currentOffset
		layers[layerID].size = uint64(len(buf))
		currentOffset += uint64(len(buf))
	}

	// Encode edges — V2 format: [src:8B][dst:8B][type:1B][weight:4B]
	edgeData := make([]byte, len(edges)*EdgeSize)
	for i, e := range edges {
		binary.BigEndian.PutUint64(edgeData[i*EdgeSize:], e.Src)
		binary.BigEndian.PutUint64(edgeData[i*EdgeSize+8:], e.Dst)
		edgeData[i*EdgeSize+16] = e.Type
		// Weight: float32 → 4 bytes big-endian
		w := e.Weight
		if w == 0 {
			w = 1.0 // default weight
		}
		binary.BigEndian.PutUint32(edgeData[i*EdgeSize+17:], math.Float32bits(w))
	}
	edgeOffset := currentOffset

	// Assemble file bytes
	totalSize := int(edgeOffset) + len(edgeData)
	out := make([]byte, totalSize)

	// Magic
	copy(out[0:4], "OLNG")
	// Version
	binary.BigEndian.PutUint16(out[4:6], Version18)
	// Flags (no zstd/AES for worker — readable)
	binary.BigEndian.PutUint16(out[6:8], 0)
	// NLayers
	out[8] = 9
	// Padding [9:12]
	// NNodes
	binary.BigEndian.PutUint32(out[12:16], uint32(len(nodes)))
	// Reserved [16:20] 
	// NEdges
	binary.BigEndian.PutUint32(out[16:20], uint32(len(edges)))
	// Created timestamp
	binary.BigEndian.PutUint64(out[20:28], uint64(spec.CreatedAt.UnixNano()))
	// WorkerID string in spare header bytes [28:60]
	wid := spec.WorkerID
	if len(wid) > 31 {
		wid = wid[:31]
	}
	out[28] = byte(len(wid))
	copy(out[29:60], []byte(wid))
	// DeviceType [60:64]
	dt := spec.DeviceType
	if len(dt) > 3 {
		dt = dt[:3]
	}
	copy(out[60:64], []byte(dt))

	// Layer index (9 × 24B = 216B, starts at offset 64)
	for i := 0; i < 9; i++ {
		li := layers[uint8(i)]
		off := headerSize + i*24
		out[off] = uint8(i) // layer ID
		if li != nil && len(li.nodes) > 0 {
			out[off+1] = StatusQR // all exported = QR
			binary.BigEndian.PutUint16(out[off+2:off+4], 0)       // flags
			binary.BigEndian.PutUint64(out[off+4:off+12], li.offset)
			binary.BigEndian.PutUint64(out[off+12:off+20], li.size)
			binary.BigEndian.PutUint32(out[off+20:off+24], uint32(len(li.nodes)))
		}
	}

	// Write encoded layers
	writePos := headerSize + layerIndexSize
	for _, el := range encodedLayers {
		copy(out[writePos:], el.data)
		writePos += len(el.data)
	}

	// Write edges
	copy(out[edgeOffset:], edgeData)

	// SHA256 over entire file except signature bytes
	// (position [28:60] contains workerID — already written)
	// Simple: hash entire content → store nowhere (worker verifies at runtime)

	return os.WriteFile(path, out, 0644)
}

// encodeNode serializes một NodeRecord thành binary (format V18 — có nameLen+name)
// Format: "ND" + layer(1) + ISL(8) + cp(4,BE) + dnaLen(4,BE) + nameLen(1) + dna + name
// Dùng cho backward compat với V18 files.
func encodeNode(n *NodeRecord) []byte {
	dnaLen := len(n.DNA)
	nameBytes := []byte(n.Name)
	nameLen := len(nameBytes)
	if nameLen > 255 {
		nameBytes = nameBytes[:255]
		nameLen = 255
	}

	buf := make([]byte, NodeHeaderSizeV18+dnaLen+nameLen)
	pos := 0
	buf[pos] = 'N'; pos++
	buf[pos] = 'D'; pos++
	buf[pos] = n.Layer; pos++
	binary.BigEndian.PutUint64(buf[pos:pos+8], n.ISLAddr); pos += 8
	binary.BigEndian.PutUint32(buf[pos:pos+4], n.CP); pos += 4
	binary.BigEndian.PutUint32(buf[pos:pos+4], uint32(dnaLen)); pos += 4
	buf[pos] = byte(nameLen); pos++
	copy(buf[pos:pos+dnaLen], n.DNA); pos += dnaLen
	copy(buf[pos:], nameBytes)
	return buf
}

// encodeNodeV19 serializes một NodeRecord thành binary (format V19 — không có nameLen)
// Format: "ND" + layer(1) + ISL(8) + cp(4,BE) + dnaLen(4,BE) + dna
// Name được lưu riêng trong NamesTable.
func encodeNodeV19(n *NodeRecord) []byte {
	dnaLen := len(n.DNA)
	buf := make([]byte, NodeHeaderSizeV19+dnaLen)
	pos := 0
	buf[pos] = 'N'; pos++
	buf[pos] = 'D'; pos++
	buf[pos] = n.Layer; pos++
	binary.BigEndian.PutUint64(buf[pos:pos+8], n.ISLAddr); pos += 8
	binary.BigEndian.PutUint32(buf[pos:pos+4], n.CP); pos += 4
	binary.BigEndian.PutUint32(buf[pos:pos+4], uint32(dnaLen)); pos += 4
	copy(buf[pos:], n.DNA)
	return buf
}

// ═══════════════════════════════════════════════════════════════
// PREDEFINED SPECS — Chief dùng để export worker chuẩn
// ═══════════════════════════════════════════════════════════════

// SpecForLight tạo WorkerSpec cho light worker
// Include: L0 + L4(Objects) + L7(Programs) + light-related names
func SpecForLight(workerID, deviceIP string) WorkerSpec {
	return WorkerSpec{
		WorkerID:     workerID,
		DeviceType:   "light",
		DeviceIP:     deviceIP,
		Layers:       []uint8{LayerPrimitives, LayerObjects, LayerPrograms},
		IncludeAllQR: true,
		NodeNames: []string{
			"light", "lamp", "bulb", "brightness", "color",
			"on", "off", "dim", "living_room", "bedroom",
			"actuator", "sensor", "control",
		},
		CreatedAt: time.Now(),
	}
}

// SpecForHVAC tạo WorkerSpec cho HVAC worker
func SpecForHVAC(workerID, deviceIP string) WorkerSpec {
	return WorkerSpec{
		WorkerID:     workerID,
		DeviceType:   "hvac",
		DeviceIP:     deviceIP,
		Layers:       []uint8{LayerPrimitives, LayerObjects, LayerPrograms},
		IncludeAllQR: true,
		NodeNames: []string{
			"hvac", "temperature", "heat", "cool", "fan",
			"thermostat", "air", "humidity", "ventilation",
		},
		CreatedAt: time.Now(),
	}
}

// SpecForCamera tạo WorkerSpec cho camera/vision worker
// Cần thêm L6 Perception
func SpecForCamera(workerID, deviceIP string) WorkerSpec {
	return WorkerSpec{
		WorkerID:     workerID,
		DeviceType:   "camera",
		DeviceIP:     deviceIP,
		Layers:       []uint8{LayerPrimitives, LayerLife, LayerObjects, LayerPerception, LayerPrograms},
		IncludeAllQR: true,
		NodeNames: []string{
			"camera", "vision", "face", "person", "motion",
			"detect", "recognize", "human", "identity",
		},
		CreatedAt: time.Now(),
	}
}

// SpecForLock tạo WorkerSpec cho smart lock worker
func SpecForLock(workerID, deviceIP string) WorkerSpec {
	return WorkerSpec{
		WorkerID:     workerID,
		DeviceType:   "lock",
		DeviceIP:     deviceIP,
		Layers:       []uint8{LayerPrimitives, LayerObjects, LayerPrograms},
		IncludeAllQR: true,
		NodeNames: []string{
			"lock", "unlock", "door", "key", "access",
			"authorize", "deny", "open", "close", "secure",
		},
		CreatedAt: time.Now(),
	}
}

// ═══════════════════════════════════════════════════════════════
// ExportSkill — SkillExportSkill cho Chief agent
// Chief dùng skill này để export workers theo yêu cầu
// ═══════════════════════════════════════════════════════════════

// ExportInfo — kết quả export để ghi vào State
type ExportInfo struct {
	WorkerID   string        `json:"worker_id"`
	OutputPath string        `json:"output_path"`
	SizeKB     int64         `json:"size_kb"`
	NodeCount  int           `json:"node_count"`
	EdgeCount  int           `json:"edge_count"`
	ExportedAt time.Time     `json:"exported_at"`
}
