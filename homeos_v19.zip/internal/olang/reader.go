// internal/olang/reader.go
//
// ParseBytes — đọc homeos.olang binary → ReadResult
//
// Hỗ trợ 2 format:
//
// FORMAT V18 (cũ, header[4:8] version < 19):
//   Node: "ND" + layer(1) + ISL(8) + cp(4,BE) + dnaLen(4,BE) + nameLen(1) + dna + name
//   Layout: [header 280B][nodes...][edges]
//
// FORMAT V19 (mới, header[4:8] version >= 19):
//   Node: "ND" + layer(1) + ISL(8) + cp(4,BE) + dnaLen(4,BE) + dna   (không có nameLen)
//   NamesTable: "NT" + count(4BE) + [isl(8)+nameLen(1)+name] × N
//   Layout: [header 280B][nodes...][NamesTable][edges]
//
// Edges (bất biến — không thay đổi):
//   V1: src(8)+dst(8)+type(1) = 17B
//   V2: src(8)+dst(8)+type(1)+weight(4) = 21B  ← active
//
// ReadResult.NamesTable: non-nil nếu file có NamesTable (V19)
// ReadResult.Nodes[i].Name: populated từ NamesTable (V19) hoặc inline (V18)

package olang

import (
	"encoding/binary"
	"fmt"
	"io"
	"math"
	"os"
)

// NodeRecord là node đã parse từ binary
type NodeRecord struct {
	Layer   uint8
	ISLAddr uint64 // 8 bytes raw (BigEndian uint64)
	CP      uint32 // codepoint
	DNA     []byte
	Name    string // populated từ NamesTable (V19) hoặc inline (V18)
}

// EdgeRecord là edge đã parse từ binary
type EdgeRecord struct {
	Src    uint64
	Dst    uint64
	Type   uint8
	Weight float32 // 1.0 nếu V1, thực tế nếu V2
}

// ReadResult chứa kết quả parse toàn bộ file
type ReadResult struct {
	NodeCount  int
	EdgeCount  int
	Nodes      []*NodeRecord
	Edges      []*EdgeRecord
	ByLayer    map[uint8][]*NodeRecord
	Corrupt    []*NodeRecord
	Names      *NamesTable // non-nil nếu file V19 có NamesTable riêng
	FileV19    bool        // true nếu dùng format V19
}

// Stats hiện thống kê ngắn gọn
func (r *ReadResult) Stats() string {
	s := fmt.Sprintf("nodes=%d edges=%d", r.NodeCount, r.EdgeCount)
	for l := uint8(0); l <= 8; l++ {
		if nodes := r.ByLayer[l]; len(nodes) > 0 {
			s += fmt.Sprintf(" L%d=%d", l, len(nodes))
		}
	}
	if len(r.Corrupt) > 0 {
		s += fmt.Sprintf(" corrupt=%d", len(r.Corrupt))
	}
	if r.Names != nil {
		s += fmt.Sprintf(" names=%d", r.Names.Len())
	}
	return s
}

// ReadFrom đọc homeos.olang từ reader
func ReadFrom(r io.ReadSeeker) (*ReadResult, error) {
	raw, err := io.ReadAll(r)
	if err != nil {
		return nil, fmt.Errorf("ReadFrom: read: %w", err)
	}
	return ParseBytes(raw)
}

// ReadFile đọc file từ path
func ReadFile(path string) (*ReadResult, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("ReadFile: open %q: %w", path, err)
	}
	defer f.Close()
	return ReadFrom(f)
}

// ParseBytes parse raw bytes → ReadResult
// Tự động detect V18 vs V19 dựa trên header version byte.
func ParseBytes(raw []byte) (*ReadResult, error) {
	if len(raw) < 20 {
		return nil, fmt.Errorf("file too small: %d bytes", len(raw))
	}
	if string(raw[0:4]) != "OLNG" {
		return nil, fmt.Errorf("invalid magic: %q", raw[0:4])
	}

	// Version detect: header[4:6] = version uint16 BE
	// V18 file có version=18 hoặc 0; V19 có version>=19
	fileVersion := binary.BigEndian.Uint16(raw[4:6])
	isV19 := fileVersion >= 19

	nedges := int(binary.BigEndian.Uint32(raw[16:20]))
	if nedges < 0 || nedges > 1_000_000 {
		return nil, fmt.Errorf("invalid edge count: %d", nedges)
	}

	// Edge section ở CUỐI file
	edgeStart := len(raw) - nedges*EdgeSize
	if edgeStart < 64 {
		return nil, fmt.Errorf("edge_start=%d too small", edgeStart)
	}

	res := &ReadResult{
		ByLayer: make(map[uint8][]*NodeRecord),
		FileV19: isV19,
	}

	if isV19 {
		// NamesTable offset lưu tại header[28:32] (V19+)
		namesOffset := int(binary.BigEndian.Uint32(raw[28:32]))
		if namesOffset > 280 && namesOffset < edgeStart {
			// Parse nodes chỉ đến namesOffset
			parseNodesV19(raw, namesOffset, res)
			t, _ := ParseNamesTable(raw[namesOffset:])
			res.Names = t
		} else {
			// Fallback: không có offset hợp lệ, parse đến edgeStart
			parseNodesV19(raw, edgeStart, res)
			res.Names = findNamesTable(raw, res, edgeStart)
		}
		// Populate Name từ NamesTable
		if res.Names != nil {
			for _, n := range res.Nodes {
				n.Name = res.Names.Get(n.ISLAddr)
			}
		}
	} else {
		parseNodesV18(raw, edgeStart, res)
	}

	parseEdges(raw, edgeStart, nedges, res)

	res.NodeCount = len(res.Nodes)
	res.EdgeCount = len(res.Edges)
	return res, nil
}

// ── V19: node không có nameLen field ─────────────────────────

func parseNodesV19(raw []byte, edgeStart int, res *ReadResult) {
	pos := 0
	limit := edgeStart - NodeHeaderSizeV19
	for pos < limit {
		if pos+2 > len(raw) { break }
		if raw[pos] != 'N' || raw[pos+1] != 'D' {
			pos++
			continue
		}
		if pos+NodeHeaderSizeV19 > len(raw) { break }

		layer   := raw[pos+2]
		islAddr := binary.BigEndian.Uint64(raw[pos+3 : pos+11])
		cp      := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
		dnaLen  := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))

		if dnaLen < 0 || dnaLen > 65536 {
			pos++
			continue
		}
		totalSize := NodeHeaderSizeV19 + dnaLen
		if pos+totalSize > len(raw) {
			pos++
			continue
		}

		dna := make([]byte, dnaLen)
		copy(dna, raw[pos+NodeHeaderSizeV19:pos+NodeHeaderSizeV19+dnaLen])

		node := &NodeRecord{
			Layer:   layer,
			ISLAddr: islAddr,
			CP:      cp,
			DNA:     dna,
			// Name: được populate sau từ NamesTable
		}
		if layer <= 8 {
			res.Nodes = append(res.Nodes, node)
			res.ByLayer[layer] = append(res.ByLayer[layer], node)
		} else {
			res.Corrupt = append(res.Corrupt, node)
		}
		pos += totalSize
	}
}

// ── V18: node có nameLen(1) + name (format cũ) ───────────────

func parseNodesV18(raw []byte, edgeStart int, res *ReadResult) {
	pos := 0
	limit := edgeStart - NodeHeaderSizeV18
	for pos < limit {
		if pos+2 > len(raw) { break }
		if raw[pos] != 'N' || raw[pos+1] != 'D' {
			pos++
			continue
		}
		if pos+NodeHeaderSizeV18 > len(raw) { break }

		layer   := raw[pos+2]
		islAddr := binary.BigEndian.Uint64(raw[pos+3 : pos+11])
		cp      := binary.BigEndian.Uint32(raw[pos+11 : pos+15])
		dnaLen  := int(binary.BigEndian.Uint32(raw[pos+15 : pos+19]))
		nameLen := int(raw[pos+19])

		if dnaLen > 65536 || nameLen > 255 {
			pos++
			continue
		}
		totalSize := NodeHeaderSizeV18 + dnaLen + nameLen
		if pos+totalSize > len(raw) {
			pos++
			continue
		}

		dna  := make([]byte, dnaLen)
		copy(dna, raw[pos+20:pos+20+dnaLen])
		name := string(raw[pos+20+dnaLen : pos+20+dnaLen+nameLen])

		node := &NodeRecord{
			Layer:   layer,
			ISLAddr: islAddr,
			CP:      cp,
			DNA:     dna,
			Name:    name,
		}
		if layer <= 8 {
			res.Nodes = append(res.Nodes, node)
			res.ByLayer[layer] = append(res.ByLayer[layer], node)
		} else {
			res.Corrupt = append(res.Corrupt, node)
		}
		pos += totalSize
	}
}

// ── NamesTable discovery ──────────────────────────────────────
// Tìm "NT" marker ngay trước edgeStart
// NamesTable nằm giữa node section và edge section.

func findNamesTable(raw []byte, res *ReadResult, edgeStart int) *NamesTable {
	// Scan ngược từ edgeStart để tìm "NT" magic
	// NamesTable size = 2+4 + sum(9+nameLen per entry)
	// Ta scan từ edgeStart-6 trở về (ít nhất 6B cho empty table)
	for start := edgeStart - 6; start >= 280; start-- {
		if start+2 > len(raw) { continue }
		if raw[start] != 'N' || raw[start+1] != 'T' { continue }
		// Thử parse
		t, consumed := ParseNamesTable(raw[start:])
		if consumed > 0 && start+consumed == edgeStart {
			return t
		}
	}
	return nil
}

// ── Edges ─────────────────────────────────────────────────────

func parseEdges(raw []byte, edgeStart, nedges int, res *ReadResult) {
	isV2 := (len(raw)-edgeStart) == nedges*EdgeSizeV2
	actualSize := EdgeSizeV1
	if isV2 { actualSize = EdgeSizeV2 }

	for i := 0; i < nedges; i++ {
		base := edgeStart + i*actualSize
		if base+17 > len(raw) { break }
		src    := binary.BigEndian.Uint64(raw[base : base+8])
		dst    := binary.BigEndian.Uint64(raw[base+8 : base+16])
		etype  := raw[base+16]
		var weight float32 = 1.0
		if isV2 && base+21 <= len(raw) {
			weight = math.Float32frombits(binary.BigEndian.Uint32(raw[base+17 : base+21]))
		}
		res.Edges = append(res.Edges, &EdgeRecord{
			Src: src, Dst: dst, Type: etype, Weight: weight,
		})
	}
}
