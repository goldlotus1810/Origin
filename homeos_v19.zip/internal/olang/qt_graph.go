// internal/olang/qt_graph.go
//
// QTGraph — encode 7 Quy Tắc thành nodes + silk edges trong homeos.olang
//
// QT = Quy Tắc = axiom của hệ thống · QR (proven) · append-only
//
// Mỗi QT có:
//   1. Symbol UTF-32 chính (codepoint + ISL)
//   2. L3 concept node (lưu định nghĩa đầy đủ)
//   3. Silk edges wiring bản chất của QT
//
// Sau khi seed: NCA có thể walk từ ○ → QT1..QT7 → L0 ops → thực thi

package olang

import "encoding/binary"

// ─── QT Symbol nodes ─────────────────────────────────────────

// QTNodeSpec — một node trong QT graph
type QTNodeSpec struct {
	ISL   [8]byte
	CP    uint32
	Name  string
	DNA   []byte
	Layer uint8
}

// makeQTISL — ISL cho concept node của QT
// Layer 0x03 (Life/Concept) · Group 0x51='Q' (QT) · Type 0x54='T' · ID=qt_num
func makeQTISL(qtNum byte) [8]byte {
	return [8]byte{0x03, 'Q', 'T', qtNum, 0x00, 0x00, 0x00, qtNum}
}

// makeSymISL — ISL cho UTF-32 symbol node (L0 layer, QT group)
// Dùng cho ⧺ ℚ và các symbols QT chưa có
func makeSymISL(cp uint32) [8]byte {
	var isl [8]byte
	isl[0] = 0x01 // L1
	isl[1] = 0x09 // math group
	isl[2] = byte(cp >> 24)
	isl[3] = byte(cp >> 16)
	binary.BigEndian.PutUint32(isl[4:], cp)
	// extra hash
	isl[6] = byte(cp>>12) ^ byte(cp>>4)
	isl[7] = byte(cp) ^ byte(cp>>8)
	return isl
}

// dna3 — tạo DNA cho L3 concept node
// b[0] = QR|SDF = 0x40|0x02 = 0x42  ← STATE|TYPE header theo NODE_Spec
// b[1] = qt number (1-9)
// b[2..5] = codepoint uint32
// b[6] = meaning_len
// b[7..] = meaning text
// QT nodes = QR (đã chứng minh, bất biến) + SDF (hữu hình, có công thức)
func dna3(qtNum byte, cp uint32, meaning string) []byte {
	m := []byte(meaning)
	if len(m) > 200 { m = m[:200] }
	d := make([]byte, 8+len(m))
	d[0] = 0x42 // QR(0x40)|SDF(0x02) — STATE|TYPE header
	d[1] = qtNum
	binary.BigEndian.PutUint32(d[2:6], cp)
	d[6] = 0x00 // reserved (align)
	d[7] = byte(len(m))
	copy(d[8:], m)
	return d
}

// ─── Missing symbols cần seed ─────────────────────────────────

// MissingQTSymbols — symbols cần thiết cho QT nhưng chưa có trong file
var MissingQTSymbols = []struct {
	CP      uint32
	Symbol  string
	Name    string
	Meaning string
	QT      byte
}{
	{
		CP: 0x29BA, Symbol: "⧺",
		Name:    "SYM_⧺_PHYS_PLUS",
		Meaning: "QT3: vật lý ++ · thêm vào vật lý · đã chứng minh · khác với + trừu tượng",
		QT:      3,
	},
	{
		CP: 0x211A, Symbol: "ℚ",
		Name:    "SYM_ℚ_QR_PROVEN",
		Meaning: "QT7: QR = Quy Tắc đã chứng minh · bộ nhớ dài hạn · bất biến · append-only",
		QT:      7,
	},
	{
		CP: 0x0394, Symbol: "Δ",
		Name:    "SYM_Δ_DN_LEARNING",
		Meaning: "QT7: ĐN = Định Nghĩa đang học · bộ nhớ ngắn hạn · tự do thay đổi · có thể bị xóa",
		QT:      7,
	},
	{
		CP: 0x2295, Symbol: "⊕",
		Name:    "SYM_⊕_HISTORY_APPEND",
		Meaning: "QT8: LỊCH SỬ BẤT BIẾN · Append-only · ⊕ = cộng thêm vào lịch sử · không bao giờ xóa · replay cho phép phục hồi",
		QT:      8,
	},
	{
		// QT9 dùng lại 🛡 đã có trong SymbolTable — chỉ cần QTConceptNode
		// nhưng thêm alias rõ nghĩa QT9
		CP: 0x26A0, Symbol: "⚠",
		Name:    "SYM_⚠_WARN_MISINFORMATION",
		Meaning: "QT9: cảnh báo thông tin sai lệch · đối lập với 🛡 (bảo vệ) · ⚠ = nguy hiểm nếu vi phạm QT9",
		QT:      9,
	},
	{
		CP: 0x002B, Symbol: "+",
		Name:    "SYM_+_ABSTRACT_PLUS",
		Meaning: "QT3: + trừu tượng · đang chứng minh · chưa chắc đúng · khác ⧺ (vật lý đã chứng minh)",
		QT:      3,
	},
	{
		CP: 0x2192, Symbol: "→",
		Name:    "SYM_→_ARROW_IMPLIES",
		Meaning: "QT5: bản chất → vị trí · cùng bản chất → cùng nhóm · QT7: ĐN → QR (vòng đời tri thức)",
		QT:      5,
	},
}

// ─── QT concept nodes (L3) ────────────────────────────────────

// QTConceptNodes — 9 nodes đại diện cho 9 QT (QT1–QT9)
var QTConceptNodes = []QTNodeSpec{
	{
		ISL:  makeQTISL(1),
		CP:   0x25CB, // ○
		Name: "QT1_ORIGIN",
		DNA:  dna3(1, 0x25CB, "○ LÀ NGUỒN GỐC: ○(x)==x identity · ○(∅)==○ tự tạo sinh · mọi f==○[f]"),
	},
	{
		ISL:  makeQTISL(2),
		CP:   0x221E, // ∞
		Name: "QT2_INF_FORBIDDEN",
		DNA:  dna3(2, 0x221E, "∞ LÀ SAI: ∞==không tồn tại · ∞-1==tồn tại thật · executor BLOWN khi vượt giới hạn"),
	},
	{
		ISL:  makeQTISL(3),
		CP:   0x29BA, // ⧺
		Name: "QT3_PHYSICS_TRUTH",
		DNA:  dna3(3, 0x29BA, "VẬT LÝ SỰ THẬT: +/-==giả thuyết · ⧺⊖==đã chứng minh vật lý · ==sự thật · QR←chứng minh←+/-←quan sát"),
	},
	{
		ISL:  makeQTISL(4),
		CP:   0x2254, // ≔
		Name: "QT4_NATURE_EXISTS",
		DNA:  dna3(4, 0x2254, "BẢN CHẤT QUYẾT ĐỊNH TỒN TẠI: Agent==Skills · Node==SDF+SLI · định nghĩa==bản chất · chỉ dùng ⧺⊖== trong định nghĩa"),
	},
	{
		ISL:  makeQTISL(5),
		CP:   0x2208, // ∈
		Name: "QT5_NATURE_POSITION",
		DNA:  dna3(5, 0x2208, "BẢN CHẤT QUYẾT ĐỊNH VỊ TRÍ: cùng bản chất→cùng nhóm · ∈ thuộc về · ⊂⊃ phân cấp · tầng cao xây trên tầng thấp"),
	},
	{
		ISL:  makeQTISL(6),
		CP:   0x222A, // ∪
		Name: "QT6_SDF_ISL",
		DNA:  dna3(6, 0x222A, "HAI CHIỀU TỒN TẠI: SDF==hữu hình(đo được) · ISL==vô hình(ý tưởng) · SDF⧺ISL==SmoothUnion"),
	},
	{
		ISL:  makeQTISL(7),
		CP:   0x0394, // Δ
		Name: "QT7_LEARN_LEAD",
		DNA:  dna3(7, 0x0394, "VÒNG ĐỜI TRI THỨC: quan sát→ĐN(+/-)→chứng minh→QR(==) · DREAM kiểm chứng ĐN · Correction xóa ĐN sai"),
	},
	{
		ISL:  makeQTISL(8),
		CP:   0x2295, // ⊕ CIRCLED PLUS — history accumulates
		Name: "QT8_HISTORY_IMMUTABLE",
		DNA:  dna3(8, 0x2295, "LỊCH SỬ BẤT BIẾN: Append-only · không DELETE · không OVERWRITE · replay(t)=phục hồi trạng thái t · ED25519 signed"),
	},
	{
		ISL:  makeQTISL(9),
		CP:   0x1F6E1, // 🛡 SHIELD
		Name: "QT9_NO_MISINFORMATION",
		DNA:  dna3(9, 0x1F6E1, "KHÔNG THÔNG TIN SAI LỆCH: SecurityGate Rule1=bất biến tuyệt đối · không hại con người · không ai ghi đè Rule1 kể cả LeoAI · Gate=0xFF"),
	},
}

// ─── QT Silk Edges ────────────────────────────────────────────

// QTEdgeSpec — một silk edge trong QT graph
type QTEdgeSpec struct {
	SrcISL [8]byte
	DstISL [8]byte
	Type   uint8
	Weight float32
	Desc   string // chú thích (không lưu vào file, chỉ để debug)
}

// isl — helper lấy ISL của symbol theo codepoint
// (dùng format SymbolL1ISL)
func islCP(cp uint32) [8]byte {
	return SymbolL1ISL(cp)
}

// BuildQTEdges — tạo tất cả edges cho QT graph
// Gọi sau khi đã seed QTConceptNodes và MissingQTSymbols
func BuildQTEdges() []QTEdgeSpec {
	var edges []QTEdgeSpec
	e := func(src, dst [8]byte, t uint8, w float32, desc string) {
		edges = append(edges, QTEdgeSpec{src, dst, t, w, desc})
	}

	origin := makeQTISL(1) // QT1 concept node = ○
	symO   := islCP(0x25CB) // ○ symbol L1

	// ── QT1: ○ LÀ NGUỒN GỐC ─────────────────────────────────
	// ○ symbol ≡ QT1 concept
	e(symO, origin, EdgeEquiv, 1.0, "○ ≡ QT1")

	// QT1 → tất cả QT khác (○ sinh ra mọi thứ)
	for qt := byte(2); qt <= 7; qt++ {
		e(origin, makeQTISL(qt), EdgeMember, 1.0, "○→QTn (QT1: mọi thứ là instance của ○)")
	}

	// ○ → L0 primitives (identity: ○(x)=x)
	for _, op := range []byte{0x01, 0x02, 0x03, 0x05, 0x10, 0x11, 0x12, 0x20, 0x22, 0x60, 0xFF} {
		e(origin, L0ISLFor(op), EdgeWorldLink, 0.8, "○→L0op (identity)")
	}

	// ── QT2: ∞ LÀ SAI ────────────────────────────────────────
	qt2 := makeQTISL(2)
	symInf  := islCP(0x221E) // ∞
	symVoid := islCP(0x25CC) // ◌ = ∞-1

	e(symInf, qt2, EdgeEquiv, 1.0, "∞ ≡ QT2")
	// ∞ → OP_GATE (∞ bị chặn bởi SecurityGate)
	e(symInf, L0ISLFor(0xFF), EdgeWorldLink, 1.0, "∞→GATE (QT2: ∞ bị BLOWN)")
	// ◌ → OP_VOID (∞-1 = void = 1e10, không phải ∞)
	e(symVoid, L0ISLFor(0x05), EdgeWorldLink, 1.0, "◌→VOID (QT2: ∞-1 thật)")
	// ∞ ↔ ◌ (opposite: ∞ sai ↔ ◌ đúng)
	e(symInf, symVoid, EdgeOpposite, 1.0, "∞⊥◌ (QT2: ∞ sai · ◌ đúng)")

	// ── QT3: VẬT LÝ SỰ THẬT ──────────────────────────────────
	qt3    := makeQTISL(3)
	symPP  := makeSymISL(0x29BA) // ⧺ physical++
	symMM  := islCP(0x2296)      // ⊖ physical--
	symEQ  := islCP(0x2261)      // ≡ proven equal
	symDEF := islCP(0x2254)      // ≔ definition

	e(symPP,  qt3, EdgeEquiv,  1.0, "⧺ ≡ QT3")
	e(symMM,  qt3, EdgeMember, 0.9, "⊖ ∈ QT3")
	e(symEQ,  qt3, EdgeMember, 0.9, "≡ ∈ QT3 (== proven)")
	e(symDEF, qt3, EdgeMember, 0.8, "≔ ∈ QT3 (định nghĩa)")
	// ⧺ → OP_ADD (vật lý ++ = thêm vào thế giới thật)
	e(symPP, L0ISLFor(0x70), EdgeWorldLink, 1.0, "⧺→ADD")
	// ⊖ → OP_SUB_N
	e(symMM, L0ISLFor(0x71), EdgeWorldLink, 1.0, "⊖→SUB")

	// ── QT4: BẢN CHẤT QUYẾT ĐỊNH TỒN TẠI ─────────────────────
	qt4    := makeQTISL(4)
	symDef2 := islCP(0x225C) // ≜ defined as

	e(symDEF, qt4, EdgeEquiv,  1.0, "≔ ≡ QT4")
	e(symDef2, qt4, EdgeMember, 0.9, "≜ ∈ QT4")

	// ── QT5: BẢN CHẤT QUYẾT ĐỊNH VỊ TRÍ ─────────────────────
	qt5   := makeQTISL(5)
	symIn := islCP(0x2208) // ∈
	symSub:= islCP(0x2282) // ⊂
	symSup:= islCP(0x2283) // ⊃

	e(symIn,  qt5, EdgeEquiv,  1.0, "∈ ≡ QT5")
	e(symSub, qt5, EdgeMember, 0.9, "⊂ ∈ QT5")
	e(symSup, qt5, EdgeMember, 0.9, "⊃ ∈ QT5")
	// ∈ → OP_GET (lookup trong Silk Tree)
	e(symIn, L0ISLFor(0x50), EdgeWorldLink, 1.0, "∈→GET")
	// ⊂⊃ → OP_WALK (đi theo silk edges)
	e(symSub, L0ISLFor(0x51), EdgeWorldLink, 0.8, "⊂→WALK")
	e(symSup, L0ISLFor(0x51), EdgeWorldLink, 0.8, "⊃→WALK")

	// ── QT6: SDF ⧺ ISL ───────────────────────────────────────
	qt6   := makeQTISL(6)
	symU  := islCP(0x222A)  // ∪ SmoothUnion
	symS  := islCP(0x25CF)  // ● SDF
	symP  := islCP(0x2202)  // ∂ ISL

	e(symU, qt6, EdgeEquiv,  1.0, "∪ ≡ QT6")
	e(symS, qt6, EdgeMember, 0.9, "● ∈ QT6 (SDF)")
	e(symP, qt6, EdgeMember, 0.9, "∂ ∈ QT6 (ISL)")
	// ∪ → OP_UNION
	e(symU, L0ISLFor(0x10), EdgeWorldLink, 1.0, "∪→UNION (QT6: SDF⧺ISL)")
	// ● → OP_SPHERE (SDF hữu hình)
	e(symS, L0ISLFor(0x01), EdgeWorldLink, 1.0, "●→SPHERE (SDF)")

	// ── QT7: ĐN → QR ─────────────────────────────────────────
	qt7     := makeQTISL(7)
	symDelta:= makeSymISL(0x0394) // Δ = ĐN
	symQR   := makeSymISL(0x211A) // ℚ = QR
	symDream:= L0ISLFor(0x63)     // OP_DREAM
	symEmit := L0ISLFor(0x52)     // OP_EMIT

	e(symDelta, qt7, EdgeEquiv,  1.0, "Δ ≡ QT7 (ĐN)")
	e(symQR,    qt7, EdgeMember, 1.0, "ℚ ∈ QT7 (QR)")
	// Δ → ℚ (ĐN chứng minh → QR)
	e(symDelta, symQR, EdgeDerivedFrom, 1.0, "Δ→ℚ (ĐN→QR)")
	// ℚ → ○ (QR đưa về gốc: đã chứng minh → instance của ○)
	e(symQR, origin, EdgeMember, 1.0, "ℚ→○ (QR là instance của ○)")
	// DREAM → QT7 (DREAM là cơ chế kiểm chứng ĐN)
	e(symDream, qt7, EdgeWorldLink, 1.0, "DREAM→QT7")
	// DREAM → ○ (sau dream → quay về origin)
	e(symDream, symO, EdgeMember, 0.9, "DREAM→○")
	// EMIT → QT3 (emit = phát tín hiệu đã chứng minh)
	e(symEmit, makeQTISL(3), EdgeWorldLink, 0.8, "EMIT→QT3")

	// ── Cross-QT connections ─────────────────────────────────
	// QT2 ↔ QT3 (∞ liên quan đến "không chứng minh được")
	e(makeQTISL(2), makeQTISL(3), EdgeSimilar, 0.7, "QT2~QT3")
	// QT4 ↔ QT5 (bản chất → vị trí)
	e(makeQTISL(4), makeQTISL(5), EdgeDerivedFrom, 0.9, "QT4→QT5")
	// QT6 ↔ QT4 (SDF+ISL là bản chất của Node)
	e(makeQTISL(6), makeQTISL(4), EdgeMember, 0.9, "QT6∈QT4")
	// QT7 ↔ QT3 (ĐN→QR là áp dụng của +/-→==)
	e(makeQTISL(7), makeQTISL(3), EdgeDerivedFrom, 0.9, "QT7→QT3")

	// ── QT8: LỊCH SỬ BẤT BIẾN ────────────────────────────────
	qt8    := makeQTISL(8)
	symApp := makeSymISL(0x2295) // ⊕ CIRCLED PLUS = append
	symLoop:= L0ISLFor(0x62)    // OP_LOOP = replay

	e(symApp, qt8, EdgeEquiv,   1.0, "⊕ ≡ QT8 (append-only)")
	// ⊕ → OP_LOOP (replay = duyệt lại lịch sử theo thứ tự)
	e(symApp, symLoop, EdgeWorldLink, 1.0, "⊕→LOOP (QT8: replay history)")
	// QT8 → QT7 (lịch sử là kết quả của ĐN→QR tích lũy)
	e(qt8, makeQTISL(7), EdgeDerivedFrom, 0.9, "QT8→QT7")
	// QT8 → QT3 (append-only = vật lý sự thật không thể xóa)
	e(qt8, makeQTISL(3), EdgeMember, 0.8, "QT8∈QT3")

	// ── QT9: KHÔNG THÔNG TIN SAI LỆCH ────────────────────────
	qt9     := makeQTISL(9)
	symGate := islCP(0x1F6E1)    // 🛡 SecurityGate
	symWarn := makeSymISL(0x26A0) // ⚠ Warning

	e(symGate, qt9, EdgeEquiv,  1.0, "🛡 ≡ QT9 (Rule1 bất biến)")
	e(symWarn, qt9, EdgeMember, 0.9, "⚠ ∈ QT9 (cảnh báo vi phạm)")
	// 🛡 → OP_GATE (SecurityGate enforcement)
	e(symGate, L0ISLFor(0xFF), EdgeWorldLink, 1.0, "🛡→GATE(0xFF)")
	// QT9 → QT1 (bảo vệ con người là bất biến tuyệt đối = chính ○)
	e(qt9, makeQTISL(1), EdgeMember, 1.0, "QT9∈QT1 (Rule1 tuyệt đối)")
	// QT9 ↔ QT8 (bất biến kép: lịch sử không xóa + thông tin không sai)
	e(qt9, qt8, EdgeSimilar, 0.9, "QT9~QT8 (bất biến kép)")

	// ── Cross-QT: QT1 bao trùm tất cả ───────────────────────
	// QT1 (○) là nguồn gốc → tất cả QT khác đều là instance của ○
	for qt := byte(2); qt <= 9; qt++ {
		e(makeQTISL(qt), makeQTISL(1), EdgeMember, 0.7,
			"QTn∈QT1 (mọi QT là instance của ○)")
	}

	return edges
}
