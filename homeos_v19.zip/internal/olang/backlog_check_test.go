package olang

import (
	"encoding/binary"
	"testing"
)

// isl8ToU64 chuyển [8]byte ISL → uint64 để so sánh với NodeRecord.ISLAddr
func isl8ToU64(b [8]byte) uint64 { return binary.BigEndian.Uint64(b[:]) }

func TestBacklogCheck(t *testing.T) {
	f, err := ReadFile("../../homeos.olang")
	if err != nil { t.Fatal(err) }

	// index nhanh: ISLAddr → có hay không
	present := make(map[uint64]bool, len(f.Nodes))
	for _, n := range f.Nodes { present[n.ISLAddr] = true }

	missing := 0

	// ── 1. Symbol L1 nodes ─────────────────────────────────────
	t.Log("=== 1. SYMBOL L1 NODES ===")
	syms := []struct{ label string; cp uint32 }{
		{"⧺ U+29BA  QT3 phys++",   0x29BA},
		{"ℚ U+211A  QR proven",     0x211A},
		{"○ U+25CB  QT1 origin",    0x25CB},
		{"🛡 U+1F6E1 QT9 gate",     0x1F6E1},
		{"∞ U+221E  QT2 inf",       0x221E},
		{"Δ U+0394  QT7 learn",     0x0394},
		{"⊕ U+2295  QT8 history",   0x2295},
		{"⚠ U+26A0  QT9 warn",      0x26A0},
	}
	for _, c := range syms {
		u := isl8ToU64(SymbolL1ISL(c.cp))
		if present[u] {
			t.Logf("  ✅ %s", c.label)
		} else {
			t.Logf("  ❌ MISSING  %s  (ISL:%016x)", c.label, u)
			missing++
		}
	}

	// ── 2. QTConceptNodes (L3) ─────────────────────────────────
	t.Log("=== 2. QT CONCEPT NODES L3 ===")
	for _, qt := range QTConceptNodes {
		u := isl8ToU64(qt.ISL)
		sym := string(rune(qt.CP))
		if present[u] {
			t.Logf("  ✅ %s %-30s ISL:%016x", sym, qt.Name, u)
		} else {
			t.Logf("  ❌ MISSING  %s %-30s ISL:%016x", sym, qt.Name, u)
			missing++
		}
	}

	// ── 3. ISL unique check ─────────────────────────────────────
	t.Log("=== 3. QT ISL UNIQUE ID ===")
	seen := map[uint64]string{}
	for _, qt := range QTConceptNodes {
		u := isl8ToU64(qt.ISL)
		if prev, dup := seen[u]; dup {
			t.Errorf("  ❌ DUPLICATE ISL %016x: %s vs %s", u, qt.Name, prev)
		} else {
			seen[u] = qt.Name
			t.Logf("  ✅ unique  %s  ISL:%016x", qt.Name, u)
		}
	}

	if missing > 0 {
		t.Errorf("TOTAL MISSING FROM homeos.olang: %d — cần chạy 'seed-qt'", missing)
	} else {
		t.Log("✅ ALL BACKLOG ITEMS PRESENT IN homeos.olang")
	}
}
