// internal/perception/vision.go
// VisionSkill — nhận diện vật thể qua vSDF + Fibonacci
//
// KHÔNG march rays. KHÔNG có pixel.
// Chiếu lên không gian ISL:
//   1. Nhận danh sách probe points (từ sensor/agent)
//   2. Evaluate SDF tại từng điểm → SDFResult
//   3. Phân tích Fibonacci ratio tại bề mặt
//   4. Trả về ISLAddr của node được nhận diện

package perception

import (
	"math"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

const phi = 1.6180339887

// VisionResult kết quả nhận diện tại 1 probe point
type VisionResult struct {
	Addr       isl.Address
	Confidence float64
	Label      string
	FibScore   float64 // Fibonacci structure score
	SDF        float64 // khoảng cách đến bề mặt gần nhất
	Inside     bool    // probe nằm bên trong node
}

// ProbeSet — tập hợp các điểm cần evaluate
// Sensor / Agent quyết định probe ở đâu, không phải VisionSkill
type ProbeSet struct {
	Points []gene.Vec3 // các điểm thăm dò trong world space
	Radius float64     // bán kính mỗi probe (cho Fibonacci sampling)
}

// SpatialNode — 1 thực thể trong không gian vSDF
type SpatialNode struct {
	Addr  uint64               // ISLAddr
	Label string               // tên
	SDF   func(gene.Vec3) float64 // hàm SDF của node
}

// VisionSkill phân tích không gian qua vSDF
type VisionSkill struct {
	Nodes    []SpatialNode // danh sách thực thể cần check
	ViewDist float64       // ngưỡng khoảng cách tối đa
}

func NewVisionSkill(viewDist float64) *VisionSkill {
	return &VisionSkill{ViewDist: viewDist}
}

// AddNode thêm thực thể vào không gian quan sát
func (v *VisionSkill) AddNode(n SpatialNode) {
	v.Nodes = append(v.Nodes, n)
}

// Observe evaluate tất cả nodes tại probe point p
// Trả về SDFResult của node gần nhất
func (v *VisionSkill) Observe(p gene.Vec3) gene.SDFResult {
	results := make([]gene.SDFResult, 0, len(v.Nodes))
	for _, n := range v.Nodes {
		r := gene.SDFResult{
			Addr:   n.Addr,
			Dist:   n.SDF(p),
		}
		r.Inside = r.Dist < 0
		results = append(results, r)
	}
	return gene.SDFNearest(results)
}

// ObserveAll evaluate tất cả nodes tại p — trả về danh sách đầy đủ
func (v *VisionSkill) ObserveAll(p gene.Vec3) []gene.SDFResult {
	results := make([]gene.SDFResult, 0, len(v.Nodes))
	for _, n := range v.Nodes {
		r := gene.SDFResult{
			Addr:   n.Addr,
			Dist:   n.SDF(p),
		}
		r.Inside = r.Dist < 0
		results = append(results, r)
	}
	return results
}

// ScanProbes evaluate trên toàn bộ ProbeSet
// Tổng hợp → VisionResult cho mỗi node được nhận diện
func (v *VisionSkill) ScanProbes(ps ProbeSet) []VisionResult {
	// Tổng hợp hit count per node
	type nodeStats struct {
		label   string
		minDist float64
		hits    int
		fibSum  float64
	}
	stats := map[uint64]*nodeStats{}
	for _, n := range v.Nodes {
		stats[n.Addr] = &nodeStats{label: n.Label, minDist: 1e18}
	}

	for _, p := range ps.Points {
		for _, n := range v.Nodes {
			d := n.SDF(p)
			st := stats[n.Addr]
			if d < st.minDist { st.minDist = d }
			if d < ps.Radius {
				st.hits++
				// Fibonacci analysis tại điểm này
				fib := v.fibScore(p, n.SDF, ps.Radius)
				st.fibSum += fib
			}
		}
	}

	// Chuyển stats → VisionResult
	out := make([]VisionResult, 0, len(v.Nodes))
	nProbes := float64(len(ps.Points))
	if nProbes < 1 { nProbes = 1 }

	for addr, st := range stats {
		if st.minDist > v.ViewDist { continue }
		hitRate := float64(st.hits) / nProbes
		fibAvg := 0.0
		if st.hits > 0 { fibAvg = st.fibSum / float64(st.hits) }
		confidence := hitRate*0.6 + fibAvg*0.4

		out = append(out, VisionResult{
			Addr:       isl.Address{ID: byte(addr)},
			Confidence: confidence,
			Label:      st.label,
			FibScore:   fibAvg,
			SDF:        st.minDist,
			Inside:     st.minDist < 0,
		})
	}
	return out
}

// fibScore tính Fibonacci structure score tại điểm p
// Lấy mẫu SDF theo 8 hướng quanh p, so sánh tỉ lệ khoảng cách với φ
func (v *VisionSkill) fibScore(p gene.Vec3, sdf func(gene.Vec3) float64, r float64) float64 {
	scores := make([]float64, 0, 8)
	// 8 hướng đều trong mặt phẳng XZ
	for i := 0; i < 8; i++ {
		angle := float64(i) / 8 * 2 * math.Pi
		dir := gene.Vec3{X: math.Cos(angle), Z: math.Sin(angle)}
		d1 := math.Abs(sdf(p.Add(dir.Scale(r * 0.618))))
		d2 := math.Abs(sdf(p.Add(dir.Scale(r))))
		if d2 > 1e-9 {
			scores = append(scores, isFibRatio(d1/d2))
		}
	}
	if len(scores) == 0 { return 0 }
	sum := 0.0
	for _, s := range scores { sum += s }
	return sum / float64(len(scores))
}

// isFibRatio kiểm tra tỉ lệ có gần φ, 1/φ, φ², 1/φ² không
func isFibRatio(r float64) float64 {
	if r <= 0 { return 0 }
	targets := []float64{phi, 1 / phi, phi * phi, 1 / (phi * phi)}
	best := 0.0
	for _, t := range targets {
		score := math.Max(0, 1-math.Abs(r-t)/t/0.15)
		if score > best { best = score }
	}
	return best
}

// CanHandle — Skill interface
func (v *VisionSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgQuery && msg.PrimaryAddr.Group == 'V'
}

// Name — Skill interface
func (v *VisionSkill) Name() string { return "vision_vsdf" }
