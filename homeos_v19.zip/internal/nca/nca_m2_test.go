// internal/nca/nca_m2_test.go
//
// M2 Milestone test: end-to-end learn → NxT cycle → QR
//
// Vòng đời QT7:
//   1. Push entry vào ShortTerm với conf=0.8+
//   2. Chạy commitCycle()
//   3. Verify entry đã lên QR (LongTerm.Query)

package nca

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestM2LearnToQR(t *testing.T) {
	// Setup
	graph := silk.NewSilkGraph()
	dn    := memory.NewShortTerm(64)
	qr    := memory.NewLongTerm(graph, nil)

	// Simulate: user teaches "vui = cảm xúc tích cực" (confirmed 3×)
	addr := isl.Address{Layer: 7, Group: 0x42, Type: 0x10, ID: 0x01}
	dn.Observe(memory.Observation{
		ISL:        addr,
		Data:       []byte(`{"key":"vui","value":"cảm xúc tích cực"}`),
		Confidence: 0.80,  // ngưỡng QR
		Confirmed:  3,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}, nil)

	if dn.Count() != 1 {
		t.Fatalf("Expected 1 ĐN entry, got %d", dn.Count())
	}
	t.Log("✅ Step 1: ShortTerm.Push() — conf=0.80, confirmed=3")

	// NxT commitCycle: promote conf>=0.8 → QR
	commitCycle(dn, qr, 5) // macro cycle 5
	t.Log("✅ Step 2: commitCycle() ran")

	// Verify: ĐN xóa khỏi ShortTerm
	if dn.Count() != 0 {
		t.Errorf("Expected ĐN empty after promote, got %d entries", dn.Count())
	}
	t.Log("✅ Step 3: ShortTerm empty after promote")

	// Verify: node có trong QR
	node, found := qr.Query(addr)
	if !found {
		t.Error("Expected node in QR after commitCycle, not found")
	} else {
		t.Logf("✅ Step 4: QR node found — Status=%v Weight=%d", node.Status, node.Weight)
	}
}

func TestM2DontPromoteLowConf(t *testing.T) {
	graph := silk.NewSilkGraph()
	dn    := memory.NewShortTerm(64)
	qr    := memory.NewLongTerm(graph, nil)

	// conf=0.33 — chưa đủ → không promote
	addr := isl.Address{Layer: 7, Group: 0x42, Type: 0x10, ID: 0x02}
	dn.Observe(memory.Observation{
		ISL:        addr,
		Confidence: 0.33,
		Confirmed:  1,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}, nil)

	commitCycle(dn, qr, 1)

	// ShortTerm vẫn còn entry
	if dn.Count() != 1 {
		t.Errorf("Low-conf entry should stay in ĐN, got %d", dn.Count())
	}
	// QR không có
	if _, found := qr.Query(addr); found {
		t.Error("Low-conf entry should NOT be in QR")
	}
	t.Log("✅ Low-conf (0.33) stays in ĐN — not promoted to QR")
}

func TestM2MultipleEntries(t *testing.T) {
	graph := silk.NewSilkGraph()
	dn    := memory.NewShortTerm(64)
	qr    := memory.NewLongTerm(graph, nil)

	// 5 entries: 3 đủ conf, 2 chưa đủ
	// Mỗi entry cần Data khác nhau để có NodeHash khác nhau (NodeHash = hash(SDF))
	type entry struct {
		islAddr   isl.Address
		data      string
		conf      float64
		confirmed int
	}
	testEntries := []entry{
		{isl.Address{Layer: 7, Group: 1, Type: 1, ID: 1}, "ready_A_12345xx", 0.9, 4},
		{isl.Address{Layer: 7, Group: 1, Type: 1, ID: 2}, "ready_B_67890xx", 0.9, 4},
		{isl.Address{Layer: 7, Group: 1, Type: 1, ID: 3}, "ready_C_abcdex", 0.9, 4},
		{isl.Address{Layer: 7, Group: 2, Type: 2, ID: 1}, "notready_X_123x", 0.5, 1},
		{isl.Address{Layer: 7, Group: 2, Type: 2, ID: 2}, "notready_Y_456x", 0.5, 1},
	}
	readyAddrs := []isl.Address{
		{Layer: 7, Group: 1, Type: 1, ID: 1},
		{Layer: 7, Group: 1, Type: 1, ID: 2},
		{Layer: 7, Group: 1, Type: 1, ID: 3},
	}

	for _, e := range testEntries {
		dn.Observe(memory.Observation{ISL: e.islAddr, Data: []byte(e.data),
			Confidence: e.conf, Confirmed: e.confirmed}, nil)
	}

	if dn.Count() != 5 {
		t.Fatalf("Expected 5 ĐN entries, got %d", dn.Count())
	}

	commitCycle(dn, qr, 10)

	// 2 chưa đủ còn trong ĐN
	if dn.Count() != 2 {
		t.Errorf("Expected 2 low-conf entries remaining in ĐN, got %d", dn.Count())
	}
	// 3 đủ conf đã lên QR
	promoted := 0
	for _, a := range readyAddrs {
		if _, found := qr.Query(a); found {
			promoted++
		}
	}
	if promoted != 3 {
		t.Errorf("Expected 3 entries promoted to QR, got %d", promoted)
	}
	t.Logf("✅ M2 multi: 3/5 promoted to QR, 2/5 remain in ĐN")
}
