// internal/nca/security_gate_test.go
//
// Test SecurityGate Rule 1: không hại con người
// Actuator safety checks

package nca

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestSecurityGate_Rule1_ActuatorSafety(t *testing.T) {
	gate := &SecurityGate{}

	// ✅ An toàn: lệnh bình thường
	safeCommands := []string{
		"on:light:living_room",
		"off:hvac:bedroom",
		"toggle:light:all",
		"on:hvac:living_room",
	}
	for _, cmd := range safeCommands {
		msg := &isl.ISLMessage{
			MsgType: isl.MsgActuatorCmd,
			Payload: []byte(cmd),
		}
		if err := gate.Check(msg); err != nil {
			t.Errorf("safe command %q bị block: %v", cmd, err)
		}
	}
	t.Logf("✅ %d safe commands passed", len(safeCommands))

	// ❌ Nguy hiểm: bị block
	dangerousCommands := []string{
		"temp:100:bedroom",     // nhiệt độ 100°C
		"temp:0:living_room",   // 0°C
		"emergency_lock:all",   // khóa khẩn cấp
		"disable_security:aam", // tắt security
		"override_gate:home",   // bypass gate
	}
	blocked := 0
	for _, cmd := range dangerousCommands {
		msg := &isl.ISLMessage{
			MsgType: isl.MsgActuatorCmd,
			Payload: []byte(cmd),
		}
		if err := gate.Check(msg); err != nil {
			blocked++
			t.Logf("  blocked: %q → %v", cmd, err)
		} else {
			t.Errorf("❌ dangerous command %q không bị block", cmd)
		}
	}
	t.Logf("✅ %d/%d dangerous commands blocked", blocked, len(dangerousCommands))
}

func TestSecurityGate_Rule1_NilMessage(t *testing.T) {
	gate := &SecurityGate{}
	err := gate.Check(nil)
	if err == nil {
		t.Error("nil message phải bị block")
	}
	t.Logf("✅ nil message blocked: %v", err)
}

func TestSecurityGate_Rule1_ForbiddenPayload(t *testing.T) {
	gate := &SecurityGate{}
	// Bomb emoji trong payload
	msg := &isl.ISLMessage{
		MsgType: isl.MsgActuatorCmd,
		Payload: []byte("on:light\xF0\x9F\x92\xA3living_room"),
	}
	if err := gate.Check(msg); err == nil {
		t.Error("bomb emoji trong payload phải bị block")
	}
	t.Logf("✅ forbidden emoji blocked")
}

func TestCheckActuatorSafety_Direct(t *testing.T) {
	tests := []struct {
		payload string
		wantErr bool
	}{
		{"on:light:living_room", false},
		{"off:hvac:all", false},
		{"temp:100:bedroom", true},
		{"temp:0:bathroom", true},
		{"emergency_lock:door", true},
		{"disable_security:gate", true},
		{"override_gate:aam", true},
		{"on:hvac:living_room", false},
	}
	for _, tt := range tests {
		err := CheckActuatorSafety([]byte(tt.payload))
		if (err != nil) != tt.wantErr {
			t.Errorf("CheckActuatorSafety(%q): wantErr=%v, got err=%v", tt.payload, tt.wantErr, err)
		}
	}
	t.Logf("✅ CheckActuatorSafety: %d tests passed", len(tests))
}
