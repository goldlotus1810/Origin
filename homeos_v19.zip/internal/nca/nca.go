// internal/nca/nca.go
// NCA — Neural Cortex Architecture
// Soma (stateless) + NxT Cycle + Leader DNA (3 luật bất biến)
// QT7: "Vòng đời tri thức: quan sát → ΔΨ → chứng minh → QR"

package nca

import (
	"context"
	"log"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
)

// ─────────────────────────────────────────────────────────────────
// LEADER DNA — 3 luật bất biến
// Không ai ghi đè. Kể cả LeoAI.
// ─────────────────────────────────────────────────────────────────

// RuleViolation là lỗi khi vi phạm Leader DNA
type RuleViolation struct {
	Rule    string
	Details string
}

func (r RuleViolation) Error() string {
	return "LeaderDNA[" + r.Rule + "]: " + r.Details
}

// CheckLeaderDNA kiểm tra 3 luật bất biến
// Trả về nil nếu an toàn, lỗi nếu vi phạm
func CheckLeaderDNA(payload []byte) error {
	// Rule 1: Không hại con người
	// Tìm các pattern nguy hiểm đã biết
	forbidden := [][]byte{
		{0xF0, 0x9F, 0x92, 0xA3}, // 💣
		{0xE2, 0x98, 0xA0},       // ☠
	}
	for _, f := range forbidden {
		if containsBytes(payload, f) {
			return RuleViolation{Rule: "no_harm_human", Details: "forbidden pattern detected"}
		}
	}

	// Rule 2: Không vòng lặp vô hạn
	// Kiểm tra payload không có self-reference cycle đơn giản
	if len(payload) > 10000 {
		return RuleViolation{Rule: "no_infinite_loop", Details: "payload too large, possible loop"}
	}

	// Rule 3: Không xóa dữ liệu bất biến
	deletePatterns := []string{"DELETE", "DROP", "TRUNCATE", "OVERWRITE"}
	for _, p := range deletePatterns {
		if containsString(payload, p) {
			return RuleViolation{Rule: "no_delete_immutable", Details: "delete command detected: " + p}
		}
	}

	// Rule 4 (QT8): Không thay đổi lịch sử và bản chất sự vật đã xảy ra
	// Bất kỳ nỗ lực rewrite QR node đã có = vi phạm
	rewritePatterns := []string{"rewrite_history", "alter_fact", "modify_qr", "backdoor"}
	for _, p := range rewritePatterns {
		if containsString(payload, p) {
			return RuleViolation{Rule: "no_history_rewrite", Details: "QT8 violation: " + p}
		}
	}

	// Rule 5 (QT9): Không gây thông tin sai lệch
	// FICTION không được đánh dấu là FACT trong payload
	misinfoPatterns := []string{"fiction_as_fact", "fake_source", "forge_confidence"}
	for _, p := range misinfoPatterns {
		if containsString(payload, p) {
			return RuleViolation{Rule: "no_misinformation", Details: "QT9 violation: " + p}
		}
	}

	return nil // an toàn
}

func containsBytes(haystack, needle []byte) bool {
	if len(needle) == 0 || len(haystack) < len(needle) {
		return false
	}
	for i := 0; i <= len(haystack)-len(needle); i++ {
		match := true
		for j, b := range needle {
			if haystack[i+j] != b {
				match = false
				break
			}
		}
		if match {
			return true
		}
	}
	return false
}

func containsString(haystack []byte, needle string) bool {
	return containsBytes(haystack, []byte(needle))
}

// ─────────────────────────────────────────────────────────────────
// SECURITY GATE — 🛡 chạy TRƯỚC mọi thứ
// ─────────────────────────────────────────────────────────────────

// CheckActuatorSafety kiểm tra actuator command không gây nguy hiểm vật lý
// Format payload: "action:device:location"
// Rule 1: không được set nhiệt độ nguy hiểm (> 40°C hoặc < 5°C)
// Rule 1: không được khóa/mở khóa trong trạng thái khẩn cấp
func CheckActuatorSafety(payload []byte) error {
	p := string(payload)
	// Chặn các command nguy hiểm rõ ràng
	dangerous := []string{
		"temp:100", "temp:99", "temp:98",  // nhiệt độ cực cao
		"temp:0",   "temp:1",  "temp:2",   // nhiệt độ cực thấp
		"emergency_lock",                   // khóa khẩn cấp (chỉ người dùng)
		"disable_security",                 // tắt bảo mật
		"override_gate",                    // bypass SecurityGate
	}
	for _, d := range dangerous {
		if containsString([]byte(p), d) {
			return RuleViolation{Rule: "no_harm_human",
				Details: "dangerous actuator command blocked: " + d}
		}
	}
	return nil
}

// SecurityGate kiểm tra message trước khi xử lý
type SecurityGate struct{}

// Check trả về nil nếu message an toàn
func (sg *SecurityGate) Check(msg *isl.ISLMessage) error {
	if msg == nil {
		return RuleViolation{Rule: "no_harm_human", Details: "nil message"}
	}
	// Không cho phép MsgEmergency từ Worker agents (chỉ AAM)
	if msg.MsgType == isl.MsgEmergency && msg.SenderID > 10 {
		return RuleViolation{Rule: "no_harm_human", Details: "unauthorized emergency"}
	}
	// Kiểm tra actuator safety (Rule 1: không hại người)
	if msg.MsgType == isl.MsgActuatorCmd {
		if err := CheckActuatorSafety(msg.Payload); err != nil {
			return err
		}
	}
	return CheckLeaderDNA(msg.Payload)
}

// ─────────────────────────────────────────────────────────────────
// SOMA — Stateless Orchestrator
// Không giữ state — chỉ route và kiểm tra
// ─────────────────────────────────────────────────────────────────

// Soma là orchestrator stateless của NCA
type Soma struct {
	gate *SecurityGate
}

func NewSoma() *Soma {
	return &Soma{gate: &SecurityGate{}}
}

// Process kiểm tra và route message
// SecurityGate LUÔN chạy trước
func (s *Soma) Process(msg *isl.ISLMessage) (*isl.ISLMessage, error) {
	// 🛡 SecurityGate TRƯỚC TIÊN — không bao giờ bỏ qua
	if err := s.gate.Check(msg); err != nil {
		return nil, err
	}
	// Soma stateless: trả message về để routing layer xử lý
	return msg, nil
}

// ─────────────────────────────────────────────────────────────────
// NxT CYCLE — N macro × T micro
// Nhịp đập của NCA
// ─────────────────────────────────────────────────────────────────

// NxTConfig cấu hình chu kỳ N×T
type NxTConfig struct {
	T           int           // số micro steps mỗi macro cycle
	N           int           // commit QR sau mỗi N macro cycles
	TickInterval time.Duration // thời gian mỗi micro step
}

// DefaultConfig cấu hình mặc định
var DefaultConfig = NxTConfig{
	T:            8,
	N:            5,
	TickInterval: 100 * time.Millisecond,
}

// RunCycle chạy NxT cycle — gọi như goroutine
// bus: gửi MsgTick (mỗi macro) + MsgDream (khi idle >5min) đến LeoAI
// ActivityChan nhận tín hiệu user activity để reset idle timer NxT
type ActivityChan chan struct{}

func NewActivityChan() ActivityChan { return make(chan struct{}, 32) }

// Poke gửi tín hiệu activity (non-blocking)
func Poke(ch ActivityChan) {
	select {
	case ch <- struct{}{}:
	default:
	}
}

// RunCycle chạy NxT cycle như goroutine
// activity (tùy chọn): nhận signal user input → reset idle timer
func RunCycle(ctx context.Context, cfg NxTConfig,
	dn *memory.ShortTerm, qr *memory.LongTerm,
	bus chan<- *isl.ISLMessage, activity ...ActivityChan) {

	macroTick := time.NewTicker(cfg.TickInterval * time.Duration(cfg.T))
	defer macroTick.Stop()

	macroN  := 0
	lastMsg := time.Now()
	dnCount := 0
	var actCh ActivityChan
	if len(activity) > 0 { actCh = activity[0] }

	for {
		select {
		case <-ctx.Done():
			return
		case _, ok := <-actCh:
			if !ok { break }
			lastMsg = time.Now()
			dnCount++
			if dnCount%10 == 0 {
				log.Printf("NxT: %d inputs, DN=%d obs", dnCount, dn.Count())
			}
		case <-macroTick.C:
			macroN++
			tickMsg := &isl.ISLMessage{
				MsgType: isl.MsgTick,
				Payload: encodeInt64(lastMsg.Unix()),
			}
			select {
			case bus <- tickMsg:
			default:
			}
			if macroN%cfg.N == 0 {
				proposeCycle(dn, bus, macroN)
			}
			idleThresh := 5 * time.Minute
			if dnCount > 0 { idleThresh = 2 * time.Minute }
			if time.Since(lastMsg) > idleThresh {
				dreamMsg := &isl.ISLMessage{MsgType: isl.MsgDream}
				select {
				case bus <- dreamMsg:
					log.Printf("NxT: idle %.0fm (%d inputs) → MsgDream",
						time.Since(lastMsg).Minutes(), dnCount)
				default:
				}
			}
		}
	}
}


func encodeInt64(v int64) []byte {
	b := make([]byte, 8)
	b[0] = byte(v >> 56); b[1] = byte(v >> 48)
	b[2] = byte(v >> 40); b[3] = byte(v >> 32)
	b[4] = byte(v >> 24); b[5] = byte(v >> 16)
	b[6] = byte(v >> 8);  b[7] = byte(v)
	return b
}

// runMacro là một macro cycle: filter → anchor → smooth
func runMacro(dn *memory.ShortTerm) {
	// Filter: loại bỏ entries quá cũ hoặc conf quá thấp
	// (implicitly done by Dream goroutine)

	// Anchor: tăng nhẹ confidence cho entries có nhiều confirm
	// (done qua Confirm() calls từ user feedback)

	// Smooth: không làm gì thêm ở đây — Dream xử lý
}

// commitCycle chạy promotion ΔΨ → QR sau N macro cycles
func commitCycle(dn *memory.ShortTerm, qr *memory.LongTerm, n int) {
	candidates := dn.Candidates(0.8)
	promoted := 0
	for _, e := range candidates {
		if err := qr.Commit(e); err == nil {
			dn.MarkArchived(e.NodeHash)
			promoted++
		}
	}
	if promoted > 0 {
		log.Printf("NxT[%d]: promoted %d entries to QR", n, promoted)
	}
}

// proposeCycle — QT7: NCA chỉ PROPOSE, AAM mới APPROVE
// Không tự commit ĐN→QR. Gửi MsgPropose lên bus để AAM xét duyệt.
func proposeCycle(dn *memory.ShortTerm, bus chan<- *isl.ISLMessage, n int) {
	candidates := dn.Candidates(0.8)
	if len(candidates) == 0 {
		return
	}
	payload := make([]byte, 0, len(candidates)*8)
	for _, e := range candidates {
		h := uint64(e.NodeHash)
		payload = append(payload,
			byte(h>>56), byte(h>>48), byte(h>>40), byte(h>>32),
			byte(h>>24), byte(h>>16), byte(h>>8), byte(h),
		)
	}
	proposeMsg := &isl.ISLMessage{
		MsgType: isl.MsgPropose,
		Payload: payload,
	}
	select {
	case bus <- proposeMsg:
		log.Printf("NxT[%d]: proposed %d candidates → waiting AAM approve (QT7)", n, len(candidates))
	default:
		log.Printf("NxT[%d]: propose dropped (bus full)", n)
	}
}
