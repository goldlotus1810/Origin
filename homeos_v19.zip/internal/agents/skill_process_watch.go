// internal/agents/skill_process_watch.go
//
// ProcessWatchSkill — giám sát process đang chạy
// Anchor: SYS_PROCESS (⚙ U+2699)
//
// Phát hiện:
//   - process lạ không có trong whitelist
//   - process gọi network bất thường  
//   - process chạy với quyền cao bất thường
//   - hidden process (pid trong /proc nhưng không có trong ps)
//
// Output → state["processes.*"] → DataLeakDetectSkill đọc tiếp

package agents

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ProcessInfo — thông tin 1 process
type ProcessInfo struct {
	PID        int
	Name       string
	Cmdline    string
	State      string // R=running S=sleeping Z=zombie
	UID        int
	HasNetwork bool   // có kết nối mạng không
	RiskLevel  string // "normal" | "suspicious" | "critical"
	RiskReason string
}

// ProcessSnapshot — trạng thái tại 1 thời điểm
type ProcessSnapshot struct {
	At          time.Time
	Processes   []ProcessInfo
	Suspicious  []ProcessInfo
	Hidden      []ProcessInfo // pid tồn tại nhưng ẩn
	TotalCount  int
}

// Whitelist process bình thường — học thêm qua TeachSkill
var defaultWhitelist = map[string]bool{
	// Linux core
	"systemd": true, "init": true, "kthreadd": true,
	"ksoftirqd": true, "kworker": true, "rcu_sched": true,
	"migration": true, "watchdog": true, "kdevtmpfs": true,
	// Common
	"sshd": true, "bash": true, "sh": true, "zsh": true,
	"fish": true, "login": true, "getty": true,
	// Brave browser
	"brave": true, "brave-browser": true, "chrome": true,
	// Network
	"NetworkManager": true, "dhcpcd": true, "wpa_supplicant": true,
	"avahi-daemon": true, "dnsmasq": true,
	// HomeOS itself
	"homeos": true, "go": true,
}

// ProcessWatchSkill — scan /proc, phát hiện bất thường
type ProcessWatchSkill struct {
	whitelist   map[string]bool
	lastSnap    *ProcessSnapshot
	alertChan   chan ProcessInfo
}

func NewProcessWatchSkill(extraWhitelist ...string) *ProcessWatchSkill {
	wl := make(map[string]bool)
	for k, v := range defaultWhitelist {
		wl[k] = v
	}
	for _, name := range extraWhitelist {
		wl[name] = true
	}
	return &ProcessWatchSkill{
		whitelist: wl,
		alertChan: make(chan ProcessInfo, 32),
	}
}

func (s *ProcessWatchSkill) Name() string { return "process_watch" }

func (s *ProcessWatchSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgSync
}

func (s *ProcessWatchSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Chỉ scan trên Linux
	if runtime.GOOS != "linux" {
		snap := s.mockSnapshot() // test/dev environment
		s.storeSnapshot(ctx, snap)
		return SkillResult{Data: map[string]interface{}{
			"processes.os":    runtime.GOOS,
			"processes.count": snap.TotalCount,
		}}
	}

	snap := s.scanProc()
	s.storeSnapshot(ctx, snap)

	// Nếu có suspicious → cần notify
	var notifyMsg *isl.ISLMessage
	if len(snap.Suspicious) > 0 || len(snap.Hidden) > 0 {
		alert := s.buildAlert(snap)
		notifyMsg = &isl.ISLMessage{
			MsgType: isl.MsgKnowledge,
			Payload: []byte(alert),
		}
	}

	return SkillResult{
		Data:    s.toStateData(snap),
		Message: notifyMsg,
	}
}

// scanProc — đọc /proc trên Linux
func (s *ProcessWatchSkill) scanProc() *ProcessSnapshot {
	snap := &ProcessSnapshot{At: time.Now()}

	entries, err := os.ReadDir("/proc")
	if err != nil {
		return snap
	}

	pidSet := make(map[int]bool)

	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		pid, err := strconv.Atoi(e.Name())
		if err != nil {
			continue // không phải PID dir
		}
		pidSet[pid] = true

		info := s.readProcInfo(pid)
		if info == nil {
			continue
		}

		snap.Processes = append(snap.Processes, *info)
		snap.TotalCount++

		if info.RiskLevel == "suspicious" || info.RiskLevel == "critical" {
			snap.Suspicious = append(snap.Suspicious, *info)
		}
	}

	return snap
}

func (s *ProcessWatchSkill) readProcInfo(pid int) *ProcessInfo {
	base := fmt.Sprintf("/proc/%d", pid)

	// Đọc /proc/PID/comm (tên process)
	commBytes, err := os.ReadFile(filepath.Join(base, "comm"))
	if err != nil {
		return nil
	}
	name := strings.TrimSpace(string(commBytes))

	// Đọc /proc/PID/cmdline
	cmdBytes, _ := os.ReadFile(filepath.Join(base, "cmdline"))
	cmdline := strings.ReplaceAll(string(cmdBytes), "\x00", " ")
	if len(cmdline) > 120 {
		cmdline = cmdline[:120] + "..."
	}

	// Đọc /proc/PID/status — UID và state
	uid := 0
	state := "?"
	statusBytes, _ := os.ReadFile(filepath.Join(base, "status"))
	for _, line := range strings.Split(string(statusBytes), "\n") {
		if strings.HasPrefix(line, "Uid:") {
			parts := strings.Fields(line)
			if len(parts) >= 2 {
				uid, _ = strconv.Atoi(parts[1])
			}
		}
		if strings.HasPrefix(line, "State:") {
			parts := strings.Fields(line)
			if len(parts) >= 2 {
				state = parts[1]
			}
		}
	}

	// Kiểm tra kết nối mạng
	hasNet := s.hasNetworkConn(pid)

	info := &ProcessInfo{
		PID:        pid,
		Name:       name,
		Cmdline:    strings.TrimSpace(cmdline),
		State:      state,
		UID:        uid,
		HasNetwork: hasNet,
		RiskLevel:  "normal",
	}

	// Đánh giá rủi ro
	s.assessRisk(info)
	return info
}

func (s *ProcessWatchSkill) hasNetworkConn(pid int) bool {
	// Kiểm tra /proc/PID/net/tcp và tcp6
	for _, netFile := range []string{
		fmt.Sprintf("/proc/%d/net/tcp", pid),
		fmt.Sprintf("/proc/%d/net/tcp6", pid),
	} {
		data, err := os.ReadFile(netFile)
		if err != nil {
			continue
		}
		lines := strings.Split(string(data), "\n")
		if len(lines) > 2 { // có connection (không chỉ header)
			return true
		}
	}
	return false
}

func (s *ProcessWatchSkill) assessRisk(info *ProcessInfo) {
	name := info.Name

	// Whitelist → safe
	if s.whitelist[name] {
		return
	}

	reasons := []string{}

	// Zombie process
	if info.State == "Z" {
		reasons = append(reasons, "zombie process")
	}

	// Process tên lạ có kết nối mạng
	if info.HasNetwork && !s.whitelist[name] {
		reasons = append(reasons, fmt.Sprintf("unknown process '%s' has network", name))
		info.RiskLevel = "suspicious"
	}

	// Process chạy với UID=0 (root) không quen
	if info.UID == 0 && !s.whitelist[name] {
		reasons = append(reasons, "unknown process running as root")
		info.RiskLevel = "suspicious"
	}

	// Tên giống malware patterns
	malwarePatterns := []string{"miner", "xmrig", "cryptonight", "minerd",
		"kthreads", "kthread2", ".hidden", "update_checker"}
	for _, pattern := range malwarePatterns {
		if strings.Contains(strings.ToLower(name), pattern) ||
			strings.Contains(strings.ToLower(info.Cmdline), pattern) {
			reasons = append(reasons, fmt.Sprintf("malware pattern match: %s", pattern))
			info.RiskLevel = "critical"
		}
	}

	if len(reasons) > 0 {
		info.RiskReason = strings.Join(reasons, "; ")
		if info.RiskLevel == "normal" {
			info.RiskLevel = "suspicious"
		}
	}
}

func (s *ProcessWatchSkill) mockSnapshot() *ProcessSnapshot {
	// Mock cho non-Linux
	return &ProcessSnapshot{
		At:         time.Now(),
		TotalCount: 42,
		Processes: []ProcessInfo{
			{PID: 1, Name: "systemd", State: "S", RiskLevel: "normal"},
			{PID: 1337, Name: "homeos", State: "R", RiskLevel: "normal"},
		},
	}
}

func (s *ProcessWatchSkill) storeSnapshot(ctx *ExecContext, snap *ProcessSnapshot) {
	ctx.State["processes.total"]      = snap.TotalCount
	ctx.State["processes.suspicious"] = len(snap.Suspicious)
	ctx.State["processes.hidden"]     = len(snap.Hidden)
	ctx.State["processes.at"]         = snap.At.Format(time.RFC3339)
	ctx.State["processes.snapshot"]   = snap
	s.lastSnap = snap
}

func (s *ProcessWatchSkill) toStateData(snap *ProcessSnapshot) map[string]interface{} {
	d := map[string]interface{}{
		"processes.total":      snap.TotalCount,
		"processes.suspicious": len(snap.Suspicious),
		"processes.hidden":     len(snap.Hidden),
	}
	if len(snap.Suspicious) > 0 {
		names := make([]string, len(snap.Suspicious))
		for i, p := range snap.Suspicious {
			names[i] = fmt.Sprintf("%s(pid=%d)", p.Name, p.PID)
		}
		d["processes.suspicious_list"] = strings.Join(names, ", ")
	}
	return d
}

func (s *ProcessWatchSkill) buildAlert(snap *ProcessSnapshot) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("⚠ ProcessWatch: %d suspicious, %d hidden\n",
		len(snap.Suspicious), len(snap.Hidden)))
	for _, p := range snap.Suspicious {
		sb.WriteString(fmt.Sprintf("  [%s] pid=%d uid=%d net=%v — %s\n",
			p.RiskLevel, p.PID, p.UID, p.HasNetwork, p.RiskReason))
	}
	return sb.String()
}
