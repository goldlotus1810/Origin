// internal/agents/agents.go
// Agent + Skill system
// QT4: "Agent = tập hợp Skill của nó"
// Silent by default: CPU≈0 khi không có message

package agents

import (
	"context"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/nca"
)

// ─────────────────────────────────────────────────────────────────
// SKILL INTERFACE
// 5 quy tắc thiết kế Skill (bất biến):
//   ① 1 Skill = 1 trách nhiệm
//   ② Skill không biết Agent là gì
//   ③ Skill không biết Skill khác tồn tại
//   ④ Skill giao tiếp qua ExecContext.State
//   ⑤ Skill không giữ state — state nằm trong Agent
// ─────────────────────────────────────────────────────────────────

// ExecContext là context thực thi được truyền vào Skill
type ExecContext struct {
	State  map[string]interface{} // shared state từ Agent
	Inbox  <-chan *isl.ISLMessage
	Outbox chan<- *isl.ISLMessage
}

// SkillResult là kết quả trả về từ Skill
type SkillResult struct {
	Data            map[string]interface{} // merge vào Agent.state
	Message         *isl.ISLMessage        // gửi ra outbox (nil = không gửi)
	Messages        []*isl.ISLMessage      // gửi nhiều messages ra outbox
	ProposeNewSkill string                 // tên skill mới để LeoAI xem xét
	Err             error
}

// Skill là interface mà mọi skill phải implement
type Skill interface {
	// CanHandle kiểm tra nhanh trước Execute — không tốn CPU
	CanHandle(msg *isl.ISLMessage) bool
	// Execute thực hiện skill — chỉ gọi khi CanHandle = true
	Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult
	// Name trả về tên skill để debug/logging
	Name() string
}

// ─────────────────────────────────────────────────────────────────
// AGENT
// ─────────────────────────────────────────────────────────────────

// Agent là đơn vị thực thi trong HomeOS
// Silent by default: goroutine ngủ khi không có message
type Agent struct {
	id       string
	tier     int // 0=AAM, 1=Chief/LeoAI, 2=Worker
	codec    *isl.ISLCodec
	inbox    chan *isl.ISLMessage
	outbox   chan *isl.ISLMessage
	skills   []Skill
	state    map[string]interface{}
	gate     *nca.SecurityGate
	registry *SkillRegistry
	learner  *SkillLearner
}

// New tạo Agent mới
func New(id string, codec *isl.ISLCodec,
	inbox, outbox chan *isl.ISLMessage) *Agent {
	reg := NewSkillRegistry()
	return &Agent{
		id:       id,
		codec:    codec,
		inbox:    inbox,
		outbox:   outbox,
		skills:   make([]Skill, 0),
		state:    make(map[string]interface{}),
		gate:     &nca.SecurityGate{},
		registry: reg,
		learner:  NewSkillLearner(id, reg),
	}
}

// Learner trả về SkillLearner để set callbacks từ ngoài
func (a *Agent) Learner() *SkillLearner { return a.learner }

// Inbox trả về send-only channel để AgentRegistry có thể gửi vào
func (a *Agent) Inbox() chan<- *isl.ISLMessage { return a.inbox }

// RegisterTo đăng ký agent vào AgentRegistry — fluent API
func (a *Agent) RegisterTo(r *AgentRegistry) *Agent {
	r.RegisterAgent(a)
	return a
}

// AddSkill thêm skill vào Agent — fluent API
// Đồng thời đăng ký vào SkillRegistry để SkillLearner có thể compose
func (a *Agent) AddSkill(s Skill) *Agent {
	a.skills = append(a.skills, s)
	a.registry.Register(s)
	return a
}

// RunAsync chạy Agent trong goroutine riêng — fluent API
func (a *Agent) RunAsync(ctx context.Context) *Agent {
	go a.Run(ctx)
	return a
}

// RunAsyncCtx — nhận interface{Done() <-chan struct{}} để AgentLoader không cần import context
func (a *Agent) RunAsyncCtx(ctx interface{ Done() <-chan struct{} }) *Agent {
	go a.runWithDone(ctx.Done())
	return a
}

func (a *Agent) runWithDone(done <-chan struct{}) {
	log.Printf("Agent[%s]: online · %d skills · silent", a.id, len(a.skills))
	go a.learner.runWithDone(done)
	for {
		select {
		case <-done:
			log.Printf("Agent[%s]: shutdown", a.id)
			return
		case msg := <-a.inbox:
			a.handle(msg)
		}
	}
}

// Run là vòng lặp chính — silent by default
// Chỉ wake up khi có message trong inbox
func (a *Agent) Run(ctx context.Context) {
	log.Printf("Agent[%s]: online · %d skills · silent", a.id, len(a.skills))
	// Start SkillLearner background
	go a.learner.Run(ctx)
	for {
		select {
		case <-ctx.Done():
			log.Printf("Agent[%s]: shutdown", a.id)
			return
		case msg := <-a.inbox:
			a.handle(msg)
		}
	}
}

// handle xử lý một message
func (a *Agent) handle(msg *isl.ISLMessage) {
	// 🛡 SecurityGate TRƯỚC TIÊN
	if err := a.gate.Check(msg); err != nil {
		log.Printf("Agent[%s]: 🛡 BLOCKED: %v", a.id, err)
		return
	}

	// Duyệt skills theo thứ tự
	execCtx := &ExecContext{
		State:  a.state,
		Outbox: a.outbox,
	}

	handled := false
	for _, skill := range a.skills {
		if skill.CanHandle(msg) {
			start := time.Now()
			result := skill.Execute(execCtx, msg)
			latency := time.Since(start)
			// Merge state
			for k, v := range result.Data {
				a.state[k] = v
			}
			// Gửi message nếu có
			if result.Message != nil && a.outbox != nil {
				select {
				case a.outbox <- result.Message:
				default:
					log.Printf("Agent[%s]: outbox full, dropped msg", a.id)
				}
			}
			for _, m := range result.Messages {
				if m == nil || a.outbox == nil { continue }
				select {
				case a.outbox <- m:
				default:
					log.Printf("Agent[%s]: outbox full, dropped multi-msg", a.id)
				}
			}
			success := result.Err == nil
			if !success {
				log.Printf("Agent[%s]: skill[%s] error: %v", a.id, skill.Name(), result.Err)
			}
			// Ghi vào ExecLog để SkillLearner mine patterns
			a.learner.RecordExec(a.id, skill.Name(), msg.MsgType, latency, success)
			handled = true
			break // chỉ một skill xử lý mỗi message
		}
	}

	if !handled {
		// Silent — không xử lý được thì im lặng
	}
}

// ─────────────────────────────────────────────────────────────────
// BUILT-IN SKILLS
// ─────────────────────────────────────────────────────────────────

// BroadcastSkill phát message ra outbox khi nhận MsgActivate
type BroadcastSkill struct{}

func (s *BroadcastSkill) Name() string { return "broadcast" }
func (s *BroadcastSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgActivate && msg.TargetID == 0 // broadcast to all
}
func (s *BroadcastSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	return SkillResult{Message: msg}
}

// HeartbeatSkill trả lời MsgHeartbeat
type HeartbeatSkill struct{}

func (s *HeartbeatSkill) Name() string { return "heartbeat" }
func (s *HeartbeatSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgHeartbeat
}
func (s *HeartbeatSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	resp := &isl.ISLMessage{
		MsgType:  isl.MsgResponse,
		TargetID: msg.SenderID,
		Payload:  []byte("pong"),
	}
	return SkillResult{Message: resp}
}

// ─── AgentRegistry ─────────────────────────────────────────────
// Registry cho phép Server tra tên → inbox
// Dùng để fan-out message đến đúng agent thay vì shared bus

type AgentRegistry struct {
	mu     sync.RWMutex
	agents map[string]chan<- *isl.ISLMessage
	objs   map[string]*Agent // full Agent objects để List()
}

func NewAgentRegistry() *AgentRegistry {
	return &AgentRegistry{
		agents: make(map[string]chan<- *isl.ISLMessage),
		objs:   make(map[string]*Agent),
	}
}

func (r *AgentRegistry) Register(id string, inbox chan<- *isl.ISLMessage) {
	r.mu.Lock(); defer r.mu.Unlock()
	r.agents[id] = inbox
}

// RegisterAgent lưu Agent object đầy đủ — gọi bởi RegisterTo()
func (r *AgentRegistry) RegisterAgent(a *Agent) {
	r.mu.Lock(); defer r.mu.Unlock()
	r.agents[a.id] = a.inbox
	r.objs[a.id]   = a
}

// AgentInfo snapshot thông tin agent để serialize
type AgentInfo struct {
	ID     string
	Tier   int
	Skills []string
	Status string // "active" | "sleep"
}

// List trả về snapshot tất cả agents từ registry thật
func (r *AgentRegistry) List() []AgentInfo {
	r.mu.RLock(); defer r.mu.RUnlock()
	out := make([]AgentInfo, 0, len(r.objs))
	for _, a := range r.objs {
		skills := make([]string, 0, len(a.skills))
		for _, s := range a.skills { skills = append(skills, s.Name()) }
		status := "active"
		if a.tier == 2 { status = "sleep" }
		out = append(out, AgentInfo{ID: a.id, Tier: a.tier, Skills: skills, Status: status})
	}
	return out
}

// Send gửi message đến agent có id — trả về false nếu không tìm thấy
func (r *AgentRegistry) Send(id string, msg *isl.ISLMessage) bool {
	r.mu.RLock(); ch, ok := r.agents[id]; r.mu.RUnlock()
	if !ok { return false }
	select {
	case ch <- msg: return true
	default: return false // inbox full
	}
}

// Broadcast gửi đến tất cả agents khớp prefix
// VD: prefix="light_" → gửi đến light_living, light_bed, light_kitchen...
func (r *AgentRegistry) Broadcast(prefix string, msg *isl.ISLMessage) int {
	r.mu.RLock()
	targets := make([]chan<- *isl.ISLMessage, 0)
	for id, ch := range r.agents {
		if strings.HasPrefix(id, prefix) {
			targets = append(targets, ch)
		}
	}
	r.mu.RUnlock()
	sent := 0
	for _, ch := range targets {
		select {
		case ch <- msg: sent++
		default:
		}
	}
	return sent
}

// IDs trả về danh sách id đang có
func (r *AgentRegistry) IDs() []string {
	r.mu.RLock(); defer r.mu.RUnlock()
	ids := make([]string, 0, len(r.agents))
	for id := range r.agents { ids = append(ids, id) }
	return ids
}

// ─── HomeChiefSkill ────────────────────────────────────────────
// Tier 1 — nhận lệnh từ AAM, route đến Worker đúng
// QT: AAM ↔ Chief ↔ Worker  (AAM không nói chuyện trực tiếp với Worker)

type HomeChiefSkill struct {
	registry *AgentRegistry
}

func NewHomeChief(registry *AgentRegistry) *HomeChiefSkill {
	return &HomeChiefSkill{registry: registry}
}

func (s *HomeChiefSkill) Name() string { return "home.chief.route" }

// CanHandle: nhận MsgActuatorCmd từ AAM (Group='C' = Chief)
func (s *HomeChiefSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgActuatorCmd &&
		msg.PrimaryAddr == isl.AddrHomeChief
}

// Execute: đọc Payload → parse device + location → route đến worker
func (s *HomeChiefSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Payload format: "action:device:location"
	// VD: "off:light:living_room"  "on:light:bedroom"  "off:light:all"
	parts := strings.SplitN(string(msg.Payload), ":", 3)
	if len(parts) != 3 {
		log.Printf("HomeChief: payload sai format: %q", msg.Payload)
		return SkillResult{}
	}
	action, device, location := parts[0], parts[1], parts[2]

	workerMsg := &isl.ISLMessage{
		Version: 1,
		MsgType: isl.MsgActivate,
		PrimaryAddr: isl.Address{Layer: 'H', Group: 'A', Type: 'a', ID: 1},
		Payload:     []byte(location),
	}
	if action == "off" || action == "deactivate" {
		workerMsg.MsgType = isl.MsgDeactivate
	}

	var sent int
	if location == "all" {
		sent = s.registry.Broadcast(device+"_", workerMsg)
		log.Printf("HomeChief: broadcast %s %s → %d workers", action, device, sent)
	} else {
		// Convention: agent id = device + "_" + locationShort
		locShort := chiefLocShort(location)
		agentID  := device + "_" + locShort
		if s.registry.Send(agentID, workerMsg) {
			sent = 1
			log.Printf("HomeChief: route %s → %s ✓", action, agentID)
		} else {
			log.Printf("HomeChief: agent %q not found, broadcast fallback", agentID)
			sent = s.registry.Broadcast(device+"_", workerMsg)
		}
	}

	_ = sent
	return SkillResult{
		Data: map[string]interface{}{
			"last_cmd": action + ":" + device + ":" + location,
		},
	}
}

func chiefLocShort(loc string) string {
	m := map[string]string{
		"living_room": "living",
		"bedroom":     "bed",
		"kitchen":     "kitchen",
		"bathroom":    "bath",
		"office":      "office",
		"hallway":     "hall",
		"garage":      "garage",
	}
	if v, ok := m[loc]; ok { return v }
	return loc
}
