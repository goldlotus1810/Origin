// OSProfileSkill — đọc profile hệ thống: CPU, RAM, disk, distro, kernel
// Anchor: HW_ARCH (⚙ U+2699)
// Dùng bởi: SkillSynthesizer, FirmwareAgent, SecurityAudit
package agents

import (
	"fmt"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type OSProfile struct {
	At        time.Time
	OS        string // linux/darwin/windows
	Arch      string // amd64/arm64
	Kernel    string // từ /proc/version
	Distro    string // từ /etc/os-release
	CPUModel  string
	CPUCores  int
	MemTotalMB  int
	MemFreeMB   int
	MemUsedPct  float64
	SwapTotalMB int
	SwapFreeMB  int
	DiskInfo  []DiskStat
	Hostname  string
	Uptime    string
	LoadAvg   string
}

type DiskStat struct {
	Mount   string
	TotalGB float64
	UsedGB  float64
	UsedPct float64
}

type OSProfileSkill struct {
	lastProfile *OSProfile
	cachedAt    time.Time
	cacheTTL    time.Duration
}

func NewOSProfileSkill() *OSProfileSkill {
	return &OSProfileSkill{cacheTTL: 30 * time.Second}
}

func (s *OSProfileSkill) Name() string { return "os_profile" }

func (s *OSProfileSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgQuery || msg.MsgType == isl.MsgActivate
}

func (s *OSProfileSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Cache 30s — không cần scan liên tục
	if s.lastProfile != nil && time.Since(s.cachedAt) < s.cacheTTL {
		s.storeProfile(ctx, s.lastProfile)
		return SkillResult{Data: s.toStateData(s.lastProfile)}
	}

	p := s.buildProfile()
	s.lastProfile = p
	s.cachedAt = time.Now()
	s.storeProfile(ctx, p)
	return SkillResult{Data: s.toStateData(p)}
}

func (s *OSProfileSkill) buildProfile() *OSProfile {
	p := &OSProfile{
		At:   time.Now(),
		OS:   runtime.GOOS,
		Arch: runtime.GOARCH,
	}

	p.Hostname, _ = os.Hostname()

	if runtime.GOOS == "linux" {
		p.Kernel  = s.readKernel()
		p.Distro  = s.readDistro()
		p.CPUModel, p.CPUCores = s.readCPU()
		p.MemTotalMB, p.MemFreeMB, p.SwapTotalMB, p.SwapFreeMB = s.readMemInfo()
		p.LoadAvg  = s.readLoadAvg()
		p.Uptime   = s.readUptime()
		p.DiskInfo = s.readDisk()
	} else {
		// non-Linux mock
		p.Distro   = "non-linux"
		p.CPUCores = runtime.NumCPU()
	}

	if p.MemTotalMB > 0 {
		used := float64(p.MemTotalMB-p.MemFreeMB) / float64(p.MemTotalMB) * 100
		p.MemUsedPct = used
	}
	return p
}

func (s *OSProfileSkill) readKernel() string {
	data, err := os.ReadFile("/proc/version")
	if err != nil { return "unknown" }
	parts := strings.Fields(string(data))
	if len(parts) >= 3 { return parts[2] }
	return strings.TrimSpace(string(data))
}

func (s *OSProfileSkill) readDistro() string {
	data, err := os.ReadFile("/etc/os-release")
	if err != nil { return "unknown" }
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "PRETTY_NAME=") {
			return strings.Trim(strings.TrimPrefix(line, "PRETTY_NAME="), `"`)
		}
	}
	return "linux"
}

func (s *OSProfileSkill) readCPU() (model string, cores int) {
	cores = runtime.NumCPU()
	data, err := os.ReadFile("/proc/cpuinfo")
	if err != nil { return "unknown", cores }
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "model name") {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) == 2 {
				model = strings.TrimSpace(parts[1])
				return
			}
		}
	}
	return "unknown", cores
}

func (s *OSProfileSkill) readMemInfo() (totalMB, freeMB, swapTotal, swapFree int) {
	data, err := os.ReadFile("/proc/meminfo")
	if err != nil { return }
	get := func(key string) int {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, key) {
				fields := strings.Fields(line)
				if len(fields) >= 2 {
					v, _ := strconv.Atoi(fields[1])
					return v / 1024 // kB → MB
				}
			}
		}
		return 0
	}
	memTotal  := get("MemTotal:")
	memFree   := get("MemFree:")
	memCached := get("Cached:")
	memBuf    := get("Buffers:")
	totalMB   = memTotal
	freeMB    = memFree + memCached + memBuf
	swapTotal = get("SwapTotal:")
	swapFree  = get("SwapFree:")
	return
}

func (s *OSProfileSkill) readLoadAvg() string {
	data, err := os.ReadFile("/proc/loadavg")
	if err != nil { return "?" }
	fields := strings.Fields(string(data))
	if len(fields) >= 3 {
		return strings.Join(fields[:3], " ")
	}
	return strings.TrimSpace(string(data))
}

func (s *OSProfileSkill) readUptime() string {
	data, err := os.ReadFile("/proc/uptime")
	if err != nil { return "?" }
	fields := strings.Fields(string(data))
	if len(fields) == 0 { return "?" }
	secs, _ := strconv.ParseFloat(fields[0], 64)
	h := int(secs) / 3600
	m := (int(secs) % 3600) / 60
	return fmt.Sprintf("%dh%dm", h, m)
}

func (s *OSProfileSkill) readDisk() []DiskStat {
	// Đọc /proc/mounts rồi statvfs từng mount point
	data, err := os.ReadFile("/proc/mounts")
	if err != nil { return nil }

	seen := map[string]bool{}
	var stats []DiskStat
	for _, line := range strings.Split(string(data), "\n") {
		fields := strings.Fields(line)
		if len(fields) < 2 { continue }
		mount := fields[1]
		// Chỉ lấy mount thật (/, /home, /data...)
		if !strings.HasPrefix(mount, "/") ||
			strings.HasPrefix(mount, "/proc") ||
			strings.HasPrefix(mount, "/sys") ||
			strings.HasPrefix(mount, "/dev") ||
			strings.HasPrefix(mount, "/run") {
			continue
		}
		if seen[mount] { continue }
		seen[mount] = true

		var stat_t StatVFS
		if err := statVFS(mount, &stat_t); err != nil { continue }

		total := float64(stat_t.Blocks) * float64(stat_t.Bsize) / 1e9
		free  := float64(stat_t.Bfree)  * float64(stat_t.Bsize) / 1e9
		used  := total - free
		if total < 0.01 { continue }
		pct := used / total * 100

		stats = append(stats, DiskStat{
			Mount:   mount,
			TotalGB: total,
			UsedGB:  used,
			UsedPct: pct,
		})
	}
	return stats
}

func (s *OSProfileSkill) storeProfile(ctx *ExecContext, p *OSProfile) {
	ctx.State["os.distro"]     = p.Distro
	ctx.State["os.kernel"]     = p.Kernel
	ctx.State["os.arch"]       = p.Arch
	ctx.State["os.cpu_model"]  = p.CPUModel
	ctx.State["os.cpu_cores"]  = p.CPUCores
	ctx.State["os.mem_total_mb"] = p.MemTotalMB
	ctx.State["os.mem_free_mb"]  = p.MemFreeMB
	ctx.State["os.mem_used_pct"] = p.MemUsedPct
	ctx.State["os.swap_total_mb"] = p.SwapTotalMB
	ctx.State["os.load_avg"]   = p.LoadAvg
	ctx.State["os.uptime"]     = p.Uptime
	ctx.State["os.hostname"]   = p.Hostname
	ctx.State["os.profile"]    = p
}

func (s *OSProfileSkill) toStateData(p *OSProfile) map[string]interface{} {
	return map[string]interface{}{
		"os.distro":       p.Distro,
		"os.kernel":       p.Kernel,
		"os.cpu_model":    p.CPUModel,
		"os.cpu_cores":    p.CPUCores,
		"os.mem_total_mb": p.MemTotalMB,
		"os.mem_free_mb":  p.MemFreeMB,
		"os.mem_used_pct": fmt.Sprintf("%.1f%%", p.MemUsedPct),
		"os.load_avg":     p.LoadAvg,
		"os.uptime":       p.Uptime,
	}
}

// Summary — human-readable
func (p *OSProfile) Summary() string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Host: %s | %s | %s\n", p.Hostname, p.Distro, p.Kernel))
	sb.WriteString(fmt.Sprintf("CPU:  %s (%d cores) | Load: %s\n", p.CPUModel, p.CPUCores, p.LoadAvg))
	sb.WriteString(fmt.Sprintf("RAM:  %d MB total, %d MB free (%.1f%% used)\n",
		p.MemTotalMB, p.MemFreeMB, p.MemUsedPct))
	if p.SwapTotalMB > 0 {
		sb.WriteString(fmt.Sprintf("Swap: %d MB total, %d MB free\n", p.SwapTotalMB, p.SwapFreeMB))
	}
	sb.WriteString(fmt.Sprintf("Up:   %s\n", p.Uptime))
	for _, d := range p.DiskInfo {
		sb.WriteString(fmt.Sprintf("Disk: %s  %.1fGB / %.1fGB (%.0f%%)\n",
			d.Mount, d.UsedGB, d.TotalGB, d.UsedPct))
	}
	return sb.String()
}
