package agents

import (
	"math"
	"strings"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestBookReader_GWTW(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  BookReader — Cuốn theo chiều gió (Gone With The Wind)       ║")
	t.Log("║  Đọc → tự học EmotionTag → nói chuyện dựa trên bộ nhớ       ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// Corpus — paraphrase từ GWTW (không copy nguyên văn)
	paragraphs := []string{
		// Chương 1 — Giới thiệu
		"Scarlett O'Hara không đẹp theo tiêu chuẩn thông thường, nhưng đàn ông hiếm khi nhận ra điều đó khi bị cuốn hút bởi sức sống và sự quyến rũ của cô.",
		"Cô yêu Ashley Wilkes từ khi còn nhỏ, một tình yêu mà cô tưởng chắc chắn sẽ được đáp lại.",
		"Nhưng Ashley đã đính hôn với Melanie Hamilton, và trái tim Scarlett vỡ tan.",
		"Rhett Butler — người đàn ông nguy hiểm với nụ cười bí ẩn — nhìn thấu cô ngay từ buổi đầu.",

		// Chương 2 — Chiến tranh
		"Chiến tranh ập đến như cơn bão. Atlanta rực lửa. Tiếng súng ngày càng gần hơn.",
		"Rhett Butler bế Scarlett chạy qua những con phố ngập khói và lửa.",
		"Họ để lại tất cả phía sau — ngôi nhà, tài sản, cuộc sống cũ — trong cơn hỗn loạn.",
		"Melanie sinh con giữa tiếng bom đạn. Máu và sợ hãi tràn ngập Atlanta.",

		// Chương 3 — Tara
		"Tara — ngôi nhà cha mẹ Scarlett — đứng vững sau trận chiến, nhưng hoang tàn và đói nghèo.",
		"Mẹ Scarlett đã chết. Cha cô không còn tỉnh táo vì đau buồn.",
		"Scarlett nhìn xuống mảnh đất đỏ, nắm chặt tay. Cơn đói cào cấu ruột gan.",
		"Tôi sẽ không bao giờ đói nữa, cô thề. Dù phải ăn trộm hay nói dối.",

		// Chương 4 — Rhett và Scarlett
		"Rhett yêu Scarlett say đắm dù biết cô chỉ dùng mình để có tiền và địa vị.",
		"Anh nhẫn nhịn năm này qua năm khác, chờ đợi cô nhận ra sự thật về tình yêu.",
		"Nhưng Scarlett mãi mê đuổi theo bóng Ashley — người đàn ông không bao giờ thuộc về cô.",
		"Rhett tặng Scarlett những bộ váy đẹp nhất Atlanta, nhưng trái tim cô không rung động.",

		// Chương 5 — Bi kịch
		"Bonnie Blue — đứa con gái nhỏ yêu dấu của họ — chết trong một tai nạn phi ngựa.",
		"Rhett khóc lặng lẽ bên thi thể con gái. Scarlett lần đầu thấy anh tan vỡ.",
		"Melanie qua đời vì sinh nở khó. Ashley mất đi chỗ dựa tinh thần duy nhất.",
		"Đau buồn chồng chất đau buồn. Atlanta cháy lần nữa trong ký ức Scarlett.",

		// Chương 6 — Kết
		"Frankly my dear, I don't give a damn — Rhett nói và quay đi trong bóng đêm.",
		"Scarlett đứng một mình trong căn nhà trống. Lần đầu cô thấy thực sự cô đơn.",
		"Nhưng Tara vẫn còn đó. Đất đỏ vẫn còn đó. Và ngày mai sẽ là một ngày mới.",
		"Dù sao, ngày mai cũng là một ngày khác — Scarlett tự nhủ và ngẩng cao đầu.",
	}

	// ── ĐỌC SÁCH ─────────────────────────────────────────────────
	t.Log("[ ĐỌC SÁCH ]")
	t.Log("─────────────────────────────────────────────────────────")
	mem := NewBookMemory("Cuốn theo chiều gió")

	for i, para := range paragraphs {
		mem.ReadParagraph(para)
		tag := mem.History.Edges[len(mem.History.Edges)-1].Tag
		inflMark := ""
		if len(mem.Inflections) > 0 && mem.Inflections[len(mem.Inflections)-1].Turn == i {
			inflMark = " ← INFLECT→Silk"
		}
		t.Logf("[%2d] V=%+.2f I=%.2f [%-10s]  %s%s",
			i+1, tag.Valence, tag.Intensity, tag.Label(),
			truncateStr(para, 45), inflMark)
	}

	t.Log()
	t.Log("[ EMOTIONAL PROFILE ]")
	t.Log("─────────────────────────────────────────────────────────")
	t.Log(mem.EmotionalProfile())

	// ── Semantic Pairs ────────────────────────────────────────────
	t.Log("[ SEMANTIC PAIRS học được ]")
	pairs := mem.StrongestPairs(8)
	for _, p := range pairs {
		t.Logf("  %-12s ──(%.2f)──► %-12s  co=%d",
			p.WordA, p.Weight, p.WordB, p.CoOccur)
	}

	// ── NÓI CHUYỆN với hệ thống ───────────────────────────────────
	t.Log()
	t.Log("[ NÓI CHUYỆN DỰA TRÊN BỘ NHỚ SÁCH ]")
	t.Log("─────────────────────────────────────────────────────────")

	userCurve := NewConversationCurve(nil)

	conversations := []struct{ userMsg, desc string }{
		{"bạn nghĩ sao về cuốn sách này?",
			"hỏi chung — user neutral"},
		{"tôi thấy buồn khi đọc phần Bonnie chết",
			"user đang buồn"},
		{"Rhett thật ra rất đáng thương phải không",
			"user đang suy nghĩ về nhân vật"},
		{"tôi thích cách Scarlett không bao giờ bỏ cuộc!",
			"user đang hứng khởi"},
		{"cuốn sách có nhiều cảm xúc quá...",
			"user cảm nhận tổng thể"},
	}

	for _, conv := range conversations {
		// Cập nhật curve của user
		userTag := SentenceAffect(conv.userMsg)
		userCtx := InferContext(conv.userMsg)
		userCurve.Add(userCtx.Apply(userTag), conv.userMsg)
		tone := userCurve.NextTone()

		response := mem.RespondAboutBook(conv.userMsg, userCurve)

		t.Logf("\n  User [%s]:", conv.desc)
		t.Logf("  → \"%s\"", conv.userMsg)
		t.Logf("  User emotion: V=%+.2f Tone=%s",
			userCurve.Window[len(userCurve.Window)-1].Tag.Valence, tone.Style)
		t.Logf("  Hệ thống: \"%s\"", response)
	}

	// ── Verify ───────────────────────────────────────────────────
	t.Log()
	t.Log("[ VERIFY ]")

	// Phải học được từ mới
	if len(mem.Words) < 10 {
		t.Errorf("Chỉ học được %d từ — quá ít", len(mem.Words))
	} else {
		t.Logf("✓ Học được %d từ từ %d đoạn văn", len(mem.Words), mem.Paragraphs)
	}

	// Phải có inflection points
	if len(mem.Inflections) == 0 {
		t.Error("Không có inflection points — phải có bước ngoặt cảm xúc")
	} else {
		t.Logf("✓ %d inflection points → Silk edges", len(mem.Inflections))
	}

	// Từ "chết/chết" phải có V âm
	checkNeg := []string{"chết", "đau", "cháy", "đói"}
	for _, w := range checkNeg {
		if lw, ok := mem.LookupLearned(w); ok {
			if lw.Tag.Valence >= 0 {
				t.Errorf("'%s' V=%.2f phải âm", w, lw.Tag.Valence)
			} else {
				t.Logf("✓ '%s' V=%.2f [%s] (đúng: âm)", w, lw.Tag.Valence, lw.Tag.Label())
			}
		}
	}

	// RAM check
	bytesUsed := len(mem.Words)*120 + len(mem.Pairs)*60 + len(mem.Curve.Window)*90
	t.Logf("✓ RAM estimate: ~%d bytes (~%.1f KB) cho toàn bộ sách",
		bytesUsed, float64(bytesUsed)/1024)
	_ = math.Abs // suppress unused
}

// strings.Repeat helper
var _ = strings.Repeat

func TestBookFlush_ToSilk(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  FlushToLongTerm — ghi THẬT vào Silk + Ledger               ║")
	t.Log("║  ĐN (RAM) → QR (SilkGraph + Ledger, append-only)            ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// Đọc sách
	mem := NewBookMemory("cuốn theo chiều gió")
	for _, p := range GWTWCorpus() {
		mem.ReadParagraph(p)
	}

	t.Logf("Sau khi đọc: %d từ (RAM), %d pairs (RAM), %d inflections",
		len(mem.Words), len(mem.Pairs), len(mem.Inflections))

	// Tạo SilkGraph + LongTerm thật
	graph := silk.NewSilkGraph()
	nodesBefore := graph.NodeCount()
	edgesBefore := graph.EdgeCount()

	// FLUSH THẬT
	result := mem.FlushToSilk(graph)

	nodesAfter := graph.NodeCount()
	edgesAfter := graph.EdgeCount()

	t.Log("[ KẾT QUẢ FLUSH ]")
	t.Logf("  Nodes: %d → %d (+%d words committed)",
		nodesBefore, nodesAfter, result.WordsCommitted)
	t.Logf("  Edges: %d → %d (+%d semantic edges)",
		edgesBefore, edgesAfter, result.EdgesAdded)
	t.Logf("  Skipped (confidence thấp): %d", result.WordsSkipped)
	if len(result.Errors) > 0 {
		t.Logf("  Errors: %v", result.Errors)
	}

	// Verify nodes thật trong graph
	t.Log()
	t.Log("[ TRA CỨU TỪ GRAPH ]")
	checkWords := []string{"buồn", "chết", "yêu", "chiến", "rhett", "scarlett"}
	for _, w := range checkWords {
		addr := emotionAddr(w)
		if node, ok := graph.Get(addr); ok {
			t.Logf("  ✓ %-12s → DNA: %s", w, node.DNA[:min3(len(node.DNA), 60)])
		} else {
			t.Logf("  - %-12s → không có trong graph (confidence thấp)", w)
		}
	}

	// Walk semantic edges
	t.Log()
	t.Log("[ WALK SEMANTIC EDGES ]")
	if addr, ok := findAddrInGraph(graph, "buồn"); ok {
		neighbors := graph.Walk(addr, silk.OpSimilar)
		t.Logf("  buồn ──OpSimilar──► %d neighbors:", len(neighbors))
		for _, n := range neighbors {
			t.Logf("    → %s [%s]", n.Name, n.DNA[:min3(len(n.DNA), 40)])
		}
	}

	// Verify: graph phải có nodes
	if nodesAfter <= nodesBefore {
		t.Error("Không có node nào được ghi vào SilkGraph!")
	} else {
		t.Logf("\n✓ %d nodes mới trong SilkGraph", nodesAfter-nodesBefore)
		t.Log("✓ BookMemory.FlushToLongTerm() → SilkGraph thật")
		t.Log("✓ Không còn chỉ là RAM nữa")
	}
}

func findAddrInGraph(graph *silk.SilkGraph, word string) (isl.Address, bool) {
	addr := emotionAddr(word)
	if _, ok := graph.Get(addr); ok {
		return addr, true
	}
	return isl.Address{}, false
}
