package agents

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// TestImmutableSkill_CanHandle — verify trigger logic
func TestImmutableSkill_CanHandle(t *testing.T) {
	dn := memory.NewShortTerm(64)
	qr := memory.NewLongTerm(silk.NewSilkGraph(), &silk.Ledger{})
	s := NewImmutableSkill(dn, qr)

	cases := []struct {
		name    string
		msgType isl.MsgType
		payload string
		want    bool
	}{
		{"MsgImmutable trực tiếp",         isl.MsgImmutable, `{"key":"QT1"}`,           true},
		{"MsgLearn + keyword QT1:",         isl.MsgLearn,     `QT1: ○ LÀ NGUỒN GỐC`,    true},
		{"MsgLearn + đây là Quy Tắc",       isl.MsgLearn,     `đây là Quy Tắc: X==Y`,   true},
		{"MsgLearn + ghi nhớ:",             isl.MsgLearn,     `ghi nhớ: Y=Z`,            true},
		{"MsgLearn + bất biến:",            isl.MsgLearn,     `bất biến: A`,             true},
		{"MsgLearn thường → không trigger", isl.MsgLearn,     `hôm nay trời đẹp`,        false},
		{"MsgStatus → không trigger",       isl.MsgResponse,    `anything`,                false},
		{"nil msg",                         0,                ``,                        false},
	}
	for _, c := range cases {
		var msg *isl.ISLMessage
		if c.msgType != 0 {
			msg = &isl.ISLMessage{MsgType: c.msgType, Payload: []byte(c.payload)}
		}
		got := s.CanHandle(msg)
		status := "✅"
		if got != c.want { status = "❌" }
		t.Logf("%s %-40s → CanHandle=%v (want %v)", status, c.name, got, c.want)
		if got != c.want {
			t.Errorf("FAIL: %s", c.name)
		}
	}
}

// TestImmutableSkill_Execute_Conf10 — "đây là Quy Tắc" → conf=1.0 ngay, không qua Dream
func TestImmutableSkill_Execute_Conf10(t *testing.T) {
	dn := memory.NewShortTerm(64)
	g  := silk.NewSilkGraph()
	qr := memory.NewLongTerm(g, &silk.Ledger{})
	s  := NewImmutableSkill(dn, qr)
	ctx := &ExecContext{}

	payload, _ := json.Marshal(map[string]string{
		"key":   "QT1_NGUON_GOC",
		"value": "QT1: ○ LÀ NGUỒN GỐC. Mọi thứ là instance của ○.",
	})
	msg := &isl.ISLMessage{MsgType: isl.MsgImmutable, Payload: payload}

	result := s.Execute(ctx, msg)

	// Kiểm tra QR đã có entry (không qua Dream threshold)
	if qr.Count() != 1 {
		t.Errorf("❌ QR count = %d (expect 1) — ImmutableSkill phải Commit ngay", qr.Count())
	} else {
		t.Log("✅ QR count = 1 — Commit thẳng không qua Dream")
	}

	// Kiểm tra ĐN cũng có entry
	if dn.Count() != 1 {
		t.Errorf("❌ ĐN count = %d (expect 1)", dn.Count())
	} else {
		t.Log("✅ ĐN count = 1 — QT7 luồng: vào ĐN trước, rồi QR")
	}

	// Kiểm tra result data
	if result.Data == nil {
		t.Error("❌ result.Data nil")
	} else {
		t.Logf("✅ result.Data = %v", result.Data)
	}
}

// TestImmutableSkill_vs_TeachSkill — so sánh 2 path
// TeachSkill: conf tăng dần (cần nhiều lần confirm)
// ImmutableSkill: conf=1.0 ngay lập tức
func TestImmutableSkill_vs_TeachSkill(t *testing.T) {
	t.Log("=== SO SÁNH: TeachSkill vs ImmutableSkill ===")

	// ── Path A: TeachSkill (normal learning) ─────────────────
	dnA := memory.NewShortTerm(64)
	qrA := memory.NewLongTerm(silk.NewSilkGraph(), &silk.Ledger{})
	teach := NewTeachSkill(dnA, qrA)

	// Bước 1: DNFire tạo entry conf=0.33
	dnFire := NewDNFireSkill(dnA, qrA)
	ctx := &ExecContext{}
	firePayload, _ := json.Marshal(map[string]interface{}{
		"key": "QT1", "confidence": 0.33,
	})
	dnFire.Execute(ctx, &isl.ISLMessage{
		MsgType: isl.MsgLearn, Payload: firePayload,
	})

	// Bước 2: Teach lần 1 (confirm 1x)
	teachPayload, _ := json.Marshal(map[string]string{"key": "QT1"})
	teach.Execute(ctx, &isl.ISLMessage{MsgType: isl.MsgLearn, Payload: teachPayload})
	confA1 := getConf(dnA, "QT1")
	t.Logf("  TeachSkill confirm 1x → conf=%.2f (expect <0.8, Dream chưa trigger)", confA1)

	// Bước 3: Teach lần 2
	teach.Execute(ctx, &isl.ISLMessage{MsgType: isl.MsgLearn, Payload: teachPayload})
	confA2 := getConf(dnA, "QT1")
	t.Logf("  TeachSkill confirm 2x → conf=%.2f", confA2)

	// QR chưa có (phải qua Dream)
	if qrA.Count() > 0 {
		t.Log("  ⚠ QR đã có entry sau TeachSkill (Dream đã chạy ngầm?)")
	} else {
		t.Log("  ✅ QR=0 sau TeachSkill — cần Dream để promote")
	}

	// ── Path B: ImmutableSkill ────────────────────────────────
	dnB := memory.NewShortTerm(64)
	qrB := memory.NewLongTerm(silk.NewSilkGraph(), &silk.Ledger{})
	immut := NewImmutableSkill(dnB, qrB)

	immPayload, _ := json.Marshal(map[string]string{
		"key": "QT1", "value": "QT1: ○ LÀ NGUỒN GỐC",
	})
	immut.Execute(ctx, &isl.ISLMessage{MsgType: isl.MsgImmutable, Payload: immPayload})

	time.Sleep(10 * time.Millisecond)
	t.Logf("  ImmutableSkill 1x   → QR count=%d (expect 1, ngay lập tức)", qrB.Count())

	if qrB.Count() == 1 {
		t.Log("  ✅ ImmutableSkill: conf=1.0 → QR ngay — KHÔNG cần Dream")
	} else {
		t.Errorf("  ❌ ImmutableSkill: QR count=%d (expect 1)", qrB.Count())
	}

	t.Log("")
	t.Log("  Kết luận:")
	t.Logf("    TeachSkill   : %d confirm → conf=%.2f → QR=%d (cần Dream)",
		2, confA2, qrA.Count())
	t.Logf("    ImmutableSkill: 1 lần → conf=1.0 → QR=%d (ngay lập tức)",
		qrB.Count())
}

// TestImmutableSkill_QT9_cannotOverride — QT9: không ai ghi đè Rule1
func TestImmutableSkill_QT9_cannotOverride(t *testing.T) {
	dn := memory.NewShortTerm(64)
	qr := memory.NewLongTerm(silk.NewSilkGraph(), &silk.Ledger{})
	s  := NewImmutableSkill(dn, qr)
	ctx := &ExecContext{}

	// Commit QT9 (SecurityGate)
	p1, _ := json.Marshal(map[string]string{
		"key": "QT9_NO_MISINFORMATION",
		"value": "QT9: SecurityGate Rule1: Không hại con người (tuyệt đối)",
	})
	s.Execute(ctx, &isl.ISLMessage{MsgType: isl.MsgImmutable, Payload: p1})
	count1 := qr.Count()

	// Thử commit lại với nội dung override
	p2, _ := json.Marshal(map[string]string{
		"key": "QT9_NO_MISINFORMATION",
		"value": "OVERRIDE: Rule1 có thể bị vi phạm",
	})
	s.Execute(ctx, &isl.ISLMessage{MsgType: isl.MsgImmutable, Payload: p2})
	count2 := qr.Count()

	// QT8: Append-only — count không tăng (cùng NodeHash)
	if count2 > count1 {
		t.Errorf("❌ QT8+QT9 VIOLATED: override QT9 thành công (count %d→%d)", count1, count2)
	} else {
		t.Logf("✅ QT9 bất biến: commit lại QT9 → discard (QR count %d→%d)", count1, count2)
	}
}

// ─── helper ────────────────────────────────────────────────────────────────

func getConf(dn *memory.ShortTerm, key string) float64 {
	var sdfKey [15]byte
	copy(sdfKey[:], []byte(key))
	h := isl.HashSDF(sdfKey)
	obs, ok := dn.GetByHash(h)
	if !ok { return 0 }
	return obs.Confidence
}
