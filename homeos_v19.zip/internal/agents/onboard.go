// internal/agents/onboard.go
//
// OnboardSkill — AAM quét LAN, phát hiện thiết bị mới, tạo Agent
//
// Quy tắc tạo Agent (bất biến):
//   Agent KHÔNG tự nhân bản
//   Tầng trên tạo tầng dưới:
//     User  → AAM approve → Chief tạo → Worker
//
// Mọi Agent = clone(olang) + []Skill
//   lõi: SecurityGate + Rules + Brain + Memory
//   chức năng: do Skill gắn vào
//   khôi phục: tạo lại Agent + gắn lại Skill → hoạt động ngay

package agents

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ── DeviceDiscovery — AAM quét LAN ───────────────────────────

type DiscoveredDevice struct {
	IP          string
	MAC         string
	DeviceType  string    // "smart_light", "camera", "hvac", "lock"
	Vendor      string    // "Philips", "Xiaomi", ...
	Location    gene.SpaceType
	LocationISL string
	DiscoveredAt time.Time
	NeedsAuth   bool      // cần acc/pass firmware không?
}

// OnboardState — trạng thái của quá trình onboard 1 thiết bị
type OnboardState int

const (
	OnboardDiscovered  OnboardState = iota // vừa phát hiện
	OnboardInspecting                       // Chief đang kiểm tra
	OnboardNeedsAuth                        // cần acc/pass từ user
	OnboardAuthReceived                     // đã nhận auth
	OnboardAgentReady                       // Agent đã tạo xong
	OnboardKnowledgeSent                    // LeoAI đã gửi knowledge
	OnboardComplete                          // hoàn tất, sẵn sàng
)

func (s OnboardState) String() string {
	return [...]string{
		"discovered", "inspecting", "needs_auth",
		"auth_received", "agent_ready", "knowledge_sent", "complete",
	}[s]
}

type OnboardSession struct {
	Device    DiscoveredDevice
	State     OnboardState
	AgentID   string
	AuthToken string // sau khi user cung cấp
	Messages  []string // log các bước
}

func (s *OnboardSession) log(msg string) {
	s.Messages = append(s.Messages, fmt.Sprintf("[%s] %s", s.State, msg))
}

// ── OnboardSkill — sống tại AAM ──────────────────────────────

type OnboardSkill struct {
	sessions map[string]*OnboardSession // IP → session
	scanner  LANScanner
}

// LANScanner interface — implement thật bằng ARP/mDNS
// Ở đây dùng mock cho test
type LANScanner interface {
	Scan() []DiscoveredDevice
}

func NewOnboardSkill(scanner LANScanner) *OnboardSkill {
	return &OnboardSkill{
		sessions: make(map[string]*OnboardSession),
		scanner:  scanner,
	}
}

func (s *OnboardSkill) Name() string { return "onboard" }

func (s *OnboardSkill) CanHandle(msg *isl.ISLMessage) bool {
	// MsgSync = trigger scan (user nói "tôi có thiết bị mới")
	// MsgResponse = Chief xác nhận Agent đã tạo
	// MsgLearn = auth từ user (qua AAM)
	return msg.MsgType == isl.MsgSync ||
		msg.MsgType == isl.MsgResponse ||
		msg.MsgType == isl.MsgLearn
}

func (s *OnboardSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	switch msg.MsgType {

	case isl.MsgSync:
		return s.handleScan(ctx, msg)

	case isl.MsgResponse:
		return s.handleChiefConfirm(ctx, msg)

	case isl.MsgLearn:
		return s.handleUserAuth(ctx, msg)
	}
	return SkillResult{}
}

// Step 1: AAM quét LAN
func (s *OnboardSkill) handleScan(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	devices := s.scanner.Scan()
	if len(devices) == 0 {
		return SkillResult{
			Message: &isl.ISLMessage{
				MsgType: isl.MsgResponse,
				Payload: []byte("scan: không tìm thấy thiết bị mới"),
			},
		}
	}

	var newDevices []DiscoveredDevice
	for _, d := range devices {
		if _, exists := s.sessions[d.IP]; !exists {
			newDevices = append(newDevices, d)
			s.sessions[d.IP] = &OnboardSession{
				Device: d, State: OnboardDiscovered,
			}
		}
	}

	if len(newDevices) == 0 {
		return SkillResult{
			Message: &isl.ISLMessage{
				MsgType: isl.MsgResponse,
				Payload: []byte("scan: không có thiết bị mới (tất cả đã biết)"),
			},
		}
	}

	// Gửi lệnh xuống Chief để kiểm tra
	req := OnboardRequest{
		Action:  "inspect",
		Devices: newDevices,
	}
	s.sessions[newDevices[0].IP].State = OnboardInspecting
	s.sessions[newDevices[0].IP].log("AAM gửi yêu cầu kiểm tra xuống Chief")

	return SkillResult{
		Data: map[string]interface{}{
			"new_devices": len(newDevices),
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgActivate, // AAM → Chief: "kiểm tra thiết bị này"
			Payload: encodePayload(req),
		},
	}
}

// Step 4+5: Chief báo lại, thiết bị cần auth
func (s *OnboardSkill) handleChiefConfirm(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var resp OnboardResponse
	if err := decodePayload(msg.Payload, &resp); err != nil {
		return SkillResult{}
	}

	sess, ok := s.sessions[resp.DeviceIP]
	if !ok { return SkillResult{} }

	if resp.NeedsAuth {
		sess.State = OnboardNeedsAuth
		sess.log("Chief: thiết bị cần xác thực firmware")

		// Hỏi user
		prompt := fmt.Sprintf(
			"Thiết bị '%s' (%s) tại %s đã sẵn sàng.\n"+
				"Cần acc/pass firmware để kết nối.\n"+
				"Vui lòng cung cấp: {\"ip\":\"%s\",\"user\":\"...\",\"pass\":\"...\"}",
			resp.DeviceType, resp.DeviceIP,
			sess.Device.Location, resp.DeviceIP,
		)
		return SkillResult{
			Data: map[string]interface{}{
				"onboard_state": sess.State.String(),
				"needs_auth":    true,
			},
			Message: &isl.ISLMessage{
				MsgType: isl.MsgQuery, // AAM → User: "cần auth"
				Payload: []byte(prompt),
			},
		}
	}

	// Không cần auth → tạo agent ngay
	return s.createAgent(sess)
}

// Step 6+7: User cung cấp auth
func (s *OnboardSkill) handleUserAuth(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var authInfo struct {
		IP   string `json:"ip"`
		User string `json:"user"`
		Pass string `json:"pass"`
	}
	if err := json.Unmarshal(msg.Payload, &authInfo); err != nil {
		return SkillResult{}
	}

	sess, ok := s.sessions[authInfo.IP]
	if !ok || sess.State != OnboardNeedsAuth {
		return SkillResult{}
	}

	// Auth không bao giờ rời khỏi hệ thống nội bộ
	sess.AuthToken = fmt.Sprintf("%s:%s", authInfo.User, authInfo.Pass)
	sess.State = OnboardAuthReceived
	sess.log(fmt.Sprintf("User cung cấp auth cho %s", authInfo.IP))

	return s.createAgent(sess)
}

// Step 8-10: tạo Agent + gửi knowledge
func (s *OnboardSkill) createAgent(sess *OnboardSession) SkillResult {
	sess.AgentID = fmt.Sprintf("%s_%s", sess.Device.DeviceType, sess.Device.LocationISL)
	sess.State = OnboardAgentReady
	sess.log(fmt.Sprintf("tạo Agent '%s'", sess.AgentID))

	// Lệnh xuống Chief: tạo Agent với đúng Skill
	createCmd := AgentCreateCmd{
		AgentID:     sess.AgentID,
		DeviceType:  sess.Device.DeviceType,
		Location:    sess.Device.Location,
		LocationISL: sess.Device.LocationISL,
		IP:          sess.Device.IP,
		AuthToken:   sess.AuthToken,
		Vendor:      sess.Device.Vendor,
		Protocol:    string(detectProtocol(sess.Device.Vendor, sess.Device.IP)),
		Skills:      deviceSkills(sess.Device.DeviceType),
	}

	return SkillResult{
		Data: map[string]interface{}{
			"agent_id":      sess.AgentID,
			"onboard_state": sess.State.String(),
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgPropose, // AAM → Chief: "tạo agent này"
			Payload: encodePayload(createCmd),
		},
	}
}

// deviceSkills: loại thiết bị → danh sách Skill cần gắn
func deviceSkills(deviceType string) []string {
	switch deviceType {
	case "smart_light":
		return []string{"actuator_light"}
	case "camera":
		return []string{"perception"}
	case "hvac":
		return []string{"actuator_hvac", "temp_sensor"}
	case "lock":
		return []string{"actuator_lock"}
	case "microphone":
		return []string{"audio"}
	default:
		return []string{}
	}
}

// ── Payload types ─────────────────────────────────────────────

type OnboardRequest struct {
	Action  string             `json:"action"`
	Devices []DiscoveredDevice `json:"devices"`
}

type OnboardResponse struct {
	DeviceIP   string `json:"ip"`
	DeviceType string `json:"type"`
	NeedsAuth  bool   `json:"needs_auth"`
	AgentReady bool   `json:"agent_ready"`
}

// AgentCreateCmd — Chief nhận lệnh này để tạo Agent
// Mọi Agent = clone(olang) + Skills được chỉ định
type AgentCreateCmd struct {
	AgentID     string         `json:"agent_id"`
	DeviceType  string         `json:"device_type"`
	Location    gene.SpaceType `json:"location"`
	LocationISL string         `json:"location_isl"`
	IP          string         `json:"ip"`
	AuthToken   string         `json:"auth_token"` // không rời LAN
	Protocol    string         `json:"protocol"`   // "hue_api", "miio", "tasmota"...
	Vendor      string         `json:"vendor"`     // để auto-detect nếu protocol rỗng
	Skills      []string       `json:"skills"`
}

// AgentBlueprint — template để tạo lại Agent bất cứ lúc nào
// "gán lại Skill → hoạt động ngay"
type AgentBlueprint struct {
	AgentID     string         `json:"agent_id"`
	Skills      []string       `json:"skills"`
	Location    gene.SpaceType `json:"location"`
	LocationISL string         `json:"location_isl"`
	DeviceIP    string         `json:"ip"`
	CreatedAt   time.Time      `json:"created_at"`
	CreatedBy   string         `json:"created_by"` // "user", "aam", "chief"
}
