package agents

import (
	"testing"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestP1Skills(t *testing.T) {
	t.Log("═══════════════════════════════════════════")
	t.Log("P1 Skills: ProcessWatch · NetworkMonitor · NotifyUser")
	t.Log("═══════════════════════════════════════════")

	codec := isl.NewPlainCodec()
	inbox  := make(chan *isl.ISLMessage, 4)
	outbox := make(chan *isl.ISLMessage, 4)

	// === ProcessWatch ===
	pw := NewProcessWatchSkill()
	ag1 := New("security_agent", codec, inbox, outbox).AddSkill(pw)
	_ = ag1

	ctx1 := &ExecContext{State: make(map[string]interface{})}
	msg1 := &isl.ISLMessage{MsgType: isl.MsgTick}
	r1 := pw.Execute(ctx1, msg1)

	t.Logf("ProcessWatch:")
	t.Logf("  processes.total      = %v", r1.Data["processes.total"])
	t.Logf("  processes.suspicious = %v", r1.Data["processes.suspicious"])
	if r1.Message != nil {
		t.Logf("  ⚠ ALERT: %s", string(r1.Message.Payload[:min(100, len(r1.Message.Payload))]))
	} else {
		t.Log("  ✓ no alerts")
	}

	// === NetworkMonitor ===
	nm := NewNetworkMonitorSkill()
	ctx2 := &ExecContext{State: make(map[string]interface{})}
	msg2 := &isl.ISLMessage{MsgType: isl.MsgTick}
	r2 := nm.Execute(ctx2, msg2)

	t.Logf("\nNetworkMonitor:")
	t.Logf("  network.total      = %v", r2.Data["network.total"])
	t.Logf("  network.external   = %v", r2.Data["network.external"])
	t.Logf("  network.suspicious = %v", r2.Data["network.suspicious"])

	// === NotifyUser ===
	nu := NewNotifyUserSkill()

	// Test nhận alert từ ProcessWatch
	received := []Notification{}
	nu.AddHandler(func(n Notification) {
		received = append(received, n)
	})

	warnMsg := &isl.ISLMessage{
		MsgType: isl.MsgKnowledge,
		Payload: []byte("⚠ ProcessWatch: 2 suspicious, 0 hidden\n  [suspicious] pid=666 uid=0 net=true — unknown process running as root"),
	}
	ctx3 := &ExecContext{State: make(map[string]interface{})}
	r3 := nu.Execute(ctx3, warnMsg)

	t.Logf("\nNotifyUser:")
	t.Logf("  level = %v", r3.Data["notify.last_level"])
	t.Logf("  title = %v", r3.Data["notify.last_title"])
	t.Logf("  handlers triggered = %d", len(received))
	t.Logf("  unread queue = %d", len(nu.GetUnread()))

	// AckAll
	nu.AckAll()
	t.Logf("  after ack = %d unread", len(nu.GetUnread()))

	// === Integration: ProcessWatch → NotifyUser pipeline ===
	t.Log("\nIntegration pipeline: ProcessWatch → NotifyUser")
	if r1.Message != nil {
		ctx4 := &ExecContext{State: make(map[string]interface{})}
		r4 := nu.Execute(ctx4, r1.Message)
		t.Logf("  Forwarded alert, level=%v", r4.Data["notify.last_level"])
	} else {
		t.Log("  No alert to forward (mock env = no suspicious)")
	}

	t.Log("\n✓ P1 Skills PASS")
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
