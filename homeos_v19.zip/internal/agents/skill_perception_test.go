package agents

import (
	"encoding/json"
	"math"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestPerceptionPipeline(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  PERCEPTION PIPELINE — Worker → Chief → AAM                 ║")
	t.Log("║  Không lưu frame. Chỉ lưu ISL events.                      ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	codec, _ := isl.NewISLCodec(nil)
	bus   := make(chan *isl.ISLMessage, 32)

	// ── Khởi tạo 3 tầng ──────────────────────────────────────

	// Worker: SensorAgent (camera bếp)
	sensorKitchen := New("sensor_kitchen", codec, bus, bus).
		AddSkill(NewPerceptionSkill("cam_kitchen", "human_adult_female"))

	// Chief: HomeChief
	homeChief := New("home_chief", codec, bus, bus).
		AddSkill(NewAggregateSkill())

	// AAM
	aam := New("aam", codec, bus, bus).
		AddSkill(NewDecideSkill())

	_ = sensorKitchen
	_ = homeChief
	_ = aam

	t.Log("[ TIER STRUCTURE ]")
	t.Log("  sensor_kitchen (Worker tier=2)")
	t.Log("      ↓ MsgLearn {action, space, conf}    ← không lưu frame")
	t.Log("  home_chief (Chief tier=1)")
	t.Log("      ↓ MsgKnowledge {env: light/temp/fan}")
	t.Log("  aam (AAM tier=0)")
	t.Log("      ↓ MsgActuatorCmd {ISL, levels}")
	t.Log("  home_chief → light_agent / hvac_agent")
	t.Log()

	// ── Simulate pipeline thủ công ────────────────────────────
	// (không dùng goroutine — test synchronous)

	agg := NewAggregateSkill()
	dec := NewDecideSkill()

	type scenario struct {
		label   string
		hour    int
		species string
		action  gene.ActionVerb
		conf    float64
		space   gene.SpaceType
		audio   []gene.AudioCue
	}

	scenarios := []scenario{
		{"07:00 gym tập thể dục",  7, "human_adult_female", gene.ActionExercising, .88, gene.SpaceGym,        []gene.AudioCue{}},
		{"08:00 bếp nấu ăn",       8, "human_adult_female", gene.ActionCooking,    1.0, gene.SpaceKitchen,    []gene.AudioCue{gene.AudioWater}},
		{"09:00 văn phòng làm việc",9, "human_adult_male",   gene.ActionTyping,     .85, gene.SpaceOffice,     []gene.AudioCue{gene.AudioKeyboard}},
		{"20:00 chó chạy phòng khách",20,"dog_medium",       gene.ActionRunning,    .80, gene.SpaceLivingRoom, []gene.AudioCue{}},
		{"22:30 ngủ phòng ngủ",    22, "human_adult_female", gene.ActionSleeping,   .85, gene.SpaceBedroom,    []gene.AudioCue{gene.AudioSilent}},
	}

	t.Log("[ MESSAGES QUA PIPELINE ]")
	t.Log()

	now := time.Date(2026, 3, 10, 7, 0, 0, 0, time.UTC)
	aggCtx := &ExecContext{State: make(map[string]interface{}), Outbox: bus}
	decCtx := &ExecContext{State: make(map[string]interface{}), Outbox: bus}

	pass := 0
	for _, sc := range scenarios {
		ts := now.Add(time.Duration(sc.hour-7) * time.Hour)
		aggCtx.State["now"] = ts

		// Step 1: Worker emit PerceptPayload
		percept := PerceptPayload{
			SensorID:   "cam_" + string(sc.space),
			SpaceISL:   sc.space.ISLAddr(),
			SpaceType:  sc.space,
			Action:     sc.action,
			ActionConf: sc.conf,
			Species:    sc.species,
			AudioCues:  sc.audio,
		}
		learnMsg := &isl.ISLMessage{
			MsgType: isl.MsgLearn,
			Payload: encodePayload(percept),
		}

		// Step 2: Chief nhận → AggregateSkill
		if !agg.CanHandle(learnMsg) {
			t.Errorf("✗ AggregateSkill.CanHandle fail: %s", sc.label)
			continue
		}
		aggResult := agg.Execute(aggCtx, learnMsg)

		t.Logf("━━ %s", sc.label)
		t.Logf("   Worker → Chief: MsgLearn  {%s, %s, %.0f%%}",
			sc.species, sc.action, sc.conf*100)

		if aggResult.Message == nil {
			// Không có thay đổi — skip
			t.Logf("   Chief: no change (same as last)")
			t.Log()
			continue
		}
		t.Logf("   Chief MsgType: %v", aggResult.Message.MsgType)

		// Decode ContextUpdate
		var cu ContextUpdatePayload
		json.Unmarshal(aggResult.Message.Payload, &cu)
		t.Logf("   Chief → AAM:   MsgKnowledge {light=%.0f%% temp=%.0fC fan=%.0f%%}",
			cu.LightLevel*100, cu.Temperature, cu.FanSpeed*100)
		if len(cu.Changes) > 0 {
			t.Logf("   ⚡ changes: %v", cu.Changes)
		}

		// Step 3: AAM nhận → DecideSkill
		if !dec.CanHandle(aggResult.Message) {
			t.Errorf("✗ DecideSkill.CanHandle fail: %s", sc.label)
			continue
		}
		decResult := dec.Execute(decCtx, aggResult.Message)

		if decResult.Message == nil {
			t.Logf("   AAM: no actuate needed")
		} else {
			var cmd ActuateCommand
			json.Unmarshal(decResult.Message.Payload, &cmd)
			t.Logf("   AAM → Chief:   MsgActuatorCmd  ISL=%s", cmd.SpaceISL)
			t.Logf("   Reason: %s", cmd.Reason)

			// Verify: lệnh đúng space
			if cmd.SpaceISL == sc.space.ISLAddr() {
				t.Logf("   ✓ ISL correct: %s", cmd.SpaceISL)
				pass++
			} else {
				t.Errorf("   ✗ ISL wrong: got=%s want=%s", cmd.SpaceISL, sc.space.ISLAddr())
			}
		}
		t.Log()
	}

	t.Log("[ KEY PROPERTIES ]")
	t.Log("  ✓ Worker không biết Agent là gì (Skill rule ②)")
	t.Log("  ✓ Skill không biết Skill khác (Skill rule ③)")
	t.Log("  ✓ Không lưu frame — chỉ lưu ISL payload (<200B)")
	t.Log("  ✓ AAM chỉ nhận MsgKnowledge — không nhận trực tiếp từ Worker")
	t.Log("  ✓ Lệnh xuống: AAM → Chief → Worker (không bao giờ skip tier)")
	t.Log()

	// Memory estimate
	perceptSize := len(encodePayload(PerceptPayload{
		SensorID: "cam_kitchen", SpaceISL: "HAa1",
		SpaceType: gene.SpaceKitchen, Action: gene.ActionCooking,
		ActionConf: 1.0, Species: "human_adult_female",
	}))
	t.Logf("  PerceptPayload size: %dB (vs full frame 1080p = 6.2MB)", perceptSize)
	t.Logf("  Compression ratio:   %.0f:1", float64(1920*1080*3)/float64(perceptSize))
	t.Logf("  1 giây = 1 event = %dB stored", perceptSize)
	t.Log()
	t.Logf("[ RESULT: %d pass ]", pass)
}

// makeDancerSkeleton trả về skeleton đơn giản cho test
func makeDancerSkeleton(t float64) *gene.SDFSkeleton {
	ph := t * math.Pi * 2 / 3
	return &gene.SDFSkeleton{
		CX: .50, CY: .50,
		Joints: []*gene.Joint{
			{Name: "head",  CX: .50, CY: .25},
			{Name: "torso", CX: .50, CY: .50},
			{Name: "arm_r", CX: .50 + .15 + math.Cos(ph)*.12, CY: .40 - math.Sin(ph)*.18},
			{Name: "arm_l", CX: .50 - .15 - math.Cos(ph)*.12, CY: .40 - math.Sin(ph)*.18},
			{Name: "leg_r", CX: .55, CY: .72},
		},
	}
}
