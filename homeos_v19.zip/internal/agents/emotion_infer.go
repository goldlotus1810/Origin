// internal/agents/emotion_infer.go
// InferContext — suy luận EmotionContext từ văn bản người dùng
//
// Không cần tag tường minh — hệ thống đọc ngôn ngữ tự nhiên
// để xác định điều kiện biên trước khi giải phương trình cảm xúc.
//
// Ví dụ:
//   "tôi vừa trải qua..."      → FirstPerson + RealNow  + Recency=1.0
//   "hồi nhỏ tôi đã..."        → FirstPerson + RealPast + Recency=0.2
//   "bạn tôi kể rằng..."       → ThirdPerson + RealOther
//   "trong phim đó có cảnh..." → Observer    + Fiction
//   "bài nhạc này làm tôi..."  → Observer    + Music

package agents

import "strings"

// signal gom các từ khóa + weight để infer context
type ctxSignal struct {
	kw     []string
	role   Role
	src    Source
	recMin float64 // recency tối thiểu
	recMax float64 // recency tối đa
}

var ctxSignals = []ctxSignal{
	// ── FirstPerson + RealNow (đang xảy ra) ─────────────────────────
	{
		kw:     []string{"tôi vừa", "tôi đang", "em vừa", "em đang", "mình vừa", "mình đang",
			"just happened", "right now", "happening to me", "i just", "i am going through"},
		role: RoleFirstPerson, src: SourceRealNow, recMin: 0.85, recMax: 1.0,
	},
	// ── FirstPerson + RealPast (đã qua) ─────────────────────────────
	{
		kw:     []string{"hồi đó", "ngày xưa", "hồi nhỏ", "trước đây tôi", "tôi đã từng",
			"khi còn trẻ", "năm ngoái tôi", "back then", "when i was", "i used to", "years ago"},
		role: RoleFirstPerson, src: SourceRealPast, recMin: 0.1, recMax: 0.4,
	},
	// ── FirstPerson + Memory (ký ức gần) ────────────────────────────
	{
		kw:     []string{"tôi nhớ", "tôi nhớ lại", "em nhớ", "mình nhớ",
			"i remember", "thinking back", "looking back"},
		role: RoleFirstPerson, src: SourceMemory, recMin: 0.5, recMax: 0.75,
	},
	// ── ThirdPerson + RealOther (nghe người khác kể) ─────────────────
	{
		kw:     []string{"bạn tôi kể", "anh ấy nói", "chị ấy trải qua", "người ta nói",
			"họ kể", "nghe kể rằng", "my friend told", "someone i know", "he went through",
			"she experienced", "they said"},
		role: RoleThirdPerson, src: SourceRealOther, recMin: 0.5, recMax: 0.9,
	},
	// ── SecondPerson (nói với bạn) ────────────────────────────────────
	{
		kw:     []string{"bạn đang trải qua", "bạn vừa", "bạn đã",
			"you are going through", "you just", "you experienced"},
		role: RoleSecondPerson, src: SourceRealOther, recMin: 0.7, recMax: 1.0,
	},
	// ── Observer + Fiction (phim, sách, game) ────────────────────────
	{
		kw:     []string{"trong phim", "trong truyện", "nhân vật", "tập phim", "bộ phim",
			"cuốn sách", "tiểu thuyết", "in the movie", "in the book", "the character",
			"fictional", "the story", "in the show", "the series"},
		role: RoleObserver, src: SourceFiction, recMin: 0.3, recMax: 0.7,
	},
	// ── Observer + Music ─────────────────────────────────────────────
	{
		kw:     []string{"bài nhạc", "bài hát", "ca khúc", "nghe nhạc", "âm nhạc",
			"this song", "the music", "listening to", "melody", "bài này"},
		role: RoleObserver, src: SourceMusic, recMin: 0.8, recMax: 1.0,
	},
}

// sharedSignals — từ khóa cho Shared=true
var sharedKW = []string{
	"cùng nhau", "chúng tôi", "chúng mình", "bọn mình",
	"together", "we all", "our group", "everyone felt",
}

// expectedSignals — từ khóa cho Expected=true
var expectedKW = []string{
	"biết trước", "đã chuẩn bị", "không bất ngờ", "dự đoán",
	"knew it was coming", "expected", "prepared for", "anticipated",
}

// InferContext suy luận EmotionContext từ văn bản tự nhiên.
// Trả về DefaultContext nếu không có tín hiệu rõ ràng.
func InferContext(text string) EmotionContext {
	lo := strings.ToLower(text)

	ctx := DefaultContext // baseline

	// Tìm signal mạnh nhất
	for _, sig := range ctxSignals {
		for _, kw := range sig.kw {
			if strings.Contains(lo, kw) {
				ctx.Role    = sig.role
				ctx.Source  = sig.src
				ctx.Recency = (sig.recMin + sig.recMax) / 2
				goto found
			}
		}
	}
found:

	// Shared — cộng hưởng nhóm
	for _, kw := range sharedKW {
		if strings.Contains(lo, kw) { ctx.Shared = true; break }
	}

	// Expected — đã chuẩn bị
	for _, kw := range expectedKW {
		if strings.Contains(lo, kw) { ctx.Expected = true; break }
	}

	return ctx
}

// InferAndSolve — shortcut: infer context từ text rồi solve ngay
func InferAndSolve(text string, sp ProsodySpline) ContextualEmotion {
	return SolveEmotion(sp, InferContext(text))
}

// TextToEmotionTag — heuristic nhanh từ text → EmotionTag raw
// Không dùng audio — chỉ keyword matching
// Dùng trước ctx.Apply() để scale theo ngữ cảnh
func TextToEmotionTag(text string) EmotionTag {
	lo := strings.ToLower(text)
	var v float64
	neg := []string{"buồn", "sợ", "lo", "mệt", "khó", "tệ", "chán", "đau",
		"sad", "fear", "tired", "hard", "bad", "worry", "stress", "angry"}
	pos := []string{"vui", "hay", "tốt", "thích", "tuyệt", "hạnh phúc", "ổn",
		"good", "great", "happy", "nice", "love", "cool", "fun"}
	for _, w := range neg { if strings.Contains(lo, w) { v -= 0.20 } }
	for _, w := range pos { if strings.Contains(lo, w) { v += 0.20 } }
	if v > 0.95  { v = 0.95  }
	if v < -0.95 { v = -0.95 }
	a := 0.40
	high := []string{"!", "??", "OMG", "wow", "trời", "ơi", "chết", "chạy"}
	for _, w := range high { if strings.Contains(lo, w) { a += 0.10 } }
	if a > 0.95 { a = 0.95 }
	i := (func() float64 {
		x := v*v + (a-0.5)*(a-0.5)
		if x < 0 { x = -x }
		r := 0.0
		for x > 0 { r = r + x*0.5; x = x * 0.25 - r*0.1; if x < 0.0001 { break } }
		_ = r
		// simpler: sqrt approx
		return (v*v + (a-0.5)*(a-0.5)) * 0.5
	})()
	if i > 1 { i = 1 }
	return EmotionTag{Valence: v, Arousal: a, Dominance: 0.5 - v*0.2, Intensity: i}
}
