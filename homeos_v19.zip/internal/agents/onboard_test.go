package agents

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestOnboardNewDevice(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  ONBOARD — bóng đèn mới lắp phòng khách                    ║")
	t.Log("║  User → AAM → Chief → Agent(olang+skill) → sẵn sàng        ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	t.Log("[ KIẾN TRÚC ]")
	t.Log("  Mọi Agent = clone(olang) + []Skill")
	t.Log("  lõi bất biến: SecurityGate + Rules + Brain + Memory")
	t.Log("  chức năng: Skill gắn vào")
	t.Log("  khôi phục: tạo lại Agent + gắn Skill → hoạt động ngay")
	t.Log()
	t.Log("  Quyền tạo Agent: tầng TRÊN tạo tầng DƯỚI")
	t.Log("  User→AAM→Chief→Worker — không ai tự nhân bản")
	t.Log()

	// ── Setup ────────────────────────────────────────────────
	scanner := NewMockLANScanner(DiscoveredDevice{
		IP: "192.168.1.105", MAC: "AA:BB:CC:DD:EE:FF",
		DeviceType: "smart_light", Vendor: "Philips Hue",
		Location: gene.SpaceLivingRoom, LocationISL: "HAb1",
		DiscoveredAt: time.Now(), NeedsAuth: true,
	})

	skill := NewOnboardSkill(scanner)
	ctx   := &ExecContext{State: make(map[string]interface{})}

	// ── Step 1: User nói "tôi có bóng đèn mới" ───────────────
	t.Log("[ STEP 1 ] User: 'Tôi có bóng đèn thông minh mới ở phòng khách'")
	scanMsg := &isl.ISLMessage{MsgType: isl.MsgSync, Payload: []byte("new_device")}
	r1 := skill.Execute(ctx, scanMsg)

	t.Logf("  AAM quét LAN → tìm thấy %d thiết bị mới", r1.Data["new_devices"])
	t.Logf("  → gửi MsgActivate xuống LightChief: 'kiểm tra 192.168.1.105'")
	t.Log()

	// ── Step 2: Chief kiểm tra, báo cần auth ─────────────────
	t.Log("[ STEP 2 ] LightChief kiểm tra → thiết bị cần acc/pass firmware")
	chiefResp := OnboardResponse{
		DeviceIP: "192.168.1.105", DeviceType: "smart_light",
		NeedsAuth: true,
	}
	r2 := skill.Execute(ctx, &isl.ISLMessage{
		MsgType: isl.MsgResponse,
		Payload: encodePayload(chiefResp),
	})

	t.Logf("  State: %s", r2.Data["onboard_state"])
	t.Logf("  AAM → User: '%s'", string(r2.Message.Payload[:60])+"...")
	t.Log()

	// ── Step 3: User cung cấp acc/pass ───────────────────────
	t.Log("[ STEP 3 ] User cung cấp acc/pass firmware")
	authPayload, _ := json.Marshal(map[string]string{
		"ip": "192.168.1.105", "user": "admin", "pass": "hue123",
	})
	r3 := skill.Execute(ctx, &isl.ISLMessage{
		MsgType: isl.MsgLearn,
		Payload: authPayload,
	})

	t.Logf("  State: %s", r3.Data["onboard_state"])
	t.Logf("  AgentID: %s", r3.Data["agent_id"])

	// Decode AgentCreateCmd
	var cmd AgentCreateCmd
	json.Unmarshal(r3.Message.Payload, &cmd)
	t.Logf("  → Chief nhận lệnh tạo Agent:")
	t.Logf("    AgentID:  %s", cmd.AgentID)
	t.Logf("    Skills:   %v", cmd.Skills)
	t.Logf("    Location: %s (%s)", cmd.Location, cmd.LocationISL)
	t.Logf("    IP:       %s", cmd.IP)
	t.Logf("    Auth:     [giữ trong LAN, không gửi ra ngoài]")
	t.Log()

	// ── Step 4: Chief tạo Agent, gửi đến thiết bị ────────────
	t.Log("[ STEP 4 ] Chief tạo Agent = clone(olang) + ActuatorLightSkill")
	light := NewActuatorLightSkill(cmd.AgentID, cmd.Location)
	t.Logf("  Agent '%s' online tại %s", cmd.AgentID, cmd.IP)
	t.Logf("  Skills: %v", cmd.Skills)
	t.Logf("  RAM: ~64KB")
	t.Log()

	// ── Step 5: LeoAI gửi knowledge ──────────────────────────
	t.Log("[ STEP 5 ] LeoAI tạo knowledge packet cho agent mới")
	sched := []ScheduleEntry{
		{Hour: 7, Level: 0.80}, {Hour: 18, Level: 0.90}, {Hour: 23, Level: 0},
	}
	raw, _ := json.Marshal(sched)
	syncMsg := &isl.ISLMessage{
		MsgType: isl.MsgSync,
		Payload: encodePayload(LearnPacket{
			Type: PacketSchedule, TargetRole: RoleActuator,
			TargetISL: "HAb1", Payload: raw,
		}),
	}
	lightCtx := &ExecContext{State: make(map[string]interface{})}
	r5 := light.Execute(lightCtx, syncMsg)
	t.Logf("  LightAgent nhận: %d schedule entries", r5.Data["schedule_entries"])
	t.Logf("  h07=%.0f%% h18=%.0f%% h23=%.0f%%",
		light.scheduleLevel(7)*100, light.scheduleLevel(18)*100,
		light.scheduleLevel(23)*100)
	t.Log()

	// ── Step 6: AAM báo user ──────────────────────────────────
	t.Log("[ STEP 6 ] AAM báo User")
	t.Logf("  ✓ Đèn phòng khách (Philips Hue, 192.168.1.105) đã online")
	t.Logf("  ✓ AgentID: %s", cmd.AgentID)
	t.Logf("  ✓ Offline schedule: 7h=80%% 18h=90%% 23h=off")
	t.Log()

	t.Log("[ BẢO MẬT ]")
	t.Log("  ✓ Dữ liệu xử lý tại thiết bị — không gửi ra internet")
	t.Log("  ✓ Auth chỉ đi trong LAN (192.168.1.x)")
	t.Log("  ✓ Không có kết nối server Philips/Xiaomi/Amazon")
	t.Log("  ✓ LAN scanner chạy local — không cần cloud")
	t.Log()

	t.Log("[ KHÔI PHỤC ]")
	t.Log("  Nếu thiết bị reset hoặc Agent bị xóa:")
	blueprint := AgentBlueprint{
		AgentID: cmd.AgentID, Skills: cmd.Skills,
		Location: cmd.Location, LocationISL: cmd.LocationISL,
		DeviceIP: cmd.IP, CreatedAt: time.Now(), CreatedBy: "chief",
	}
	blueprintJSON, _ := json.MarshalIndent(blueprint, "  ", "  ")
	t.Logf("  Blueprint lưu tại Chief:\n  %s", blueprintJSON)
	t.Log()
	t.Log("  Chief tạo lại Agent từ Blueprint → gắn Skills → online ngay")

	// Assertions
	if cmd.AgentID == "" { t.Error("✗ AgentID rỗng") }
	if len(cmd.Skills) == 0 { t.Error("✗ Không có skills") }
	if cmd.Skills[0] != "actuator_light" { t.Errorf("✗ Skill sai: %v", cmd.Skills) }
	if light.scheduleLevel(7) != 0.80 { t.Error("✗ Schedule không đúng") }

	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("  ONBOARD PASS — Agent = clone(olang) + Skill")
}
