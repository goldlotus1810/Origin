// internal/agents/sentence_affect.go
// SentenceAffect — phân tích cảm xúc câu qua Silk graph walk
//
// Insight (2026-03-09):
//   "silk nối các từ, ngữ nghĩa câu, các câu mệnh lệnh, yêu cầu"
//
// Câu ≠ trung bình các từ.
// Câu = token stream → modifier detection → composition rule → CompositeTag
//
// Silk edge "sem:" nối các node ngữ nghĩa — walk để hiểu ngữ cảnh.
// Lớp 3: IntentModifier — urgency/politeness/stress/negation/amplifier.

package agents

import (
	"math"
	"strings"
	"unicode"
)

// ─── Lớp 1: Token phân loại ───────────────────────────────────────────────

type TokenRole uint8

const (
	RoleContent    TokenRole = iota // từ chính mang nghĩa
	RoleAmplifier                   // "rất", "quá", "cực kỳ"
	RoleDiminisher                  // "hơi", "một chút", "tạm"
	RoleNegation                    // "không", "chưa", "đừng"
	RoleCausal                      // "vì", "do", "tại"
	RoleContrast                    // "nhưng", "tuy nhiên"
	RoleAdditive                    // "và", "cùng", "thêm"
	RoleConcession                  // "dù", "mặc dù"
	RoleUrgency                     // "ngay", "gấp", "liền"
	RolePoliteness                  // "làm ơn", "xin", "giúp"
	RoleHedge                       // "có thể", "hình như", "có lẽ"
)

type Token struct {
	Text string
	Role TokenRole
	Tag  EmotionTag // zero nếu không có trong lexicon
	Has  bool       // có trong lexicon không
}

// ─── Lớp 2: Tokenizer + Classifier ───────────────────────────────────────

var roleMap = map[string]TokenRole{
	// Amplifier
	"rất": RoleAmplifier, "quá": RoleAmplifier, "cực kỳ": RoleAmplifier,
	"vô cùng": RoleAmplifier, "siêu": RoleAmplifier, "lắm": RoleAmplifier,
	"hết sức": RoleAmplifier, "thực sự": RoleAmplifier,
	// Diminisher
	"hơi": RoleDiminisher, "một chút": RoleDiminisher, "tạm": RoleDiminisher,
	"khá": RoleDiminisher, "cũng": RoleDiminisher, "tương đối": RoleDiminisher,
	// Negation
	"không": RoleNegation, "chưa": RoleNegation, "đừng": RoleNegation,
	"chẳng": RoleNegation, "chả": RoleNegation, "nào": RoleNegation,
	// Causal
	"vì": RoleCausal, "do": RoleCausal, "tại": RoleCausal,
	"bởi vì": RoleCausal, "bởi": RoleCausal, "nên": RoleCausal,
	// Contrast
	"nhưng": RoleContrast, "tuy nhiên": RoleContrast, "mà": RoleContrast,
	"dẫu": RoleContrast, "song": RoleContrast,
	// Additive
	"và": RoleAdditive, "cùng": RoleAdditive, "thêm": RoleAdditive,
	"cũng như": RoleAdditive, "cộng": RoleAdditive,
	// Concession
	"dù": RoleConcession, "mặc dù": RoleConcession, "dù sao": RoleConcession,
	"dẫu sao": RoleConcession,
	// Urgency
	"ngay": RoleUrgency, "gấp": RoleUrgency, "liền": RoleUrgency,
	"ngay lập tức": RoleUrgency, "khẩn": RoleUrgency, "mau": RoleUrgency,
	// Politeness
	"làm ơn": RolePoliteness, "xin": RolePoliteness, "giúp": RolePoliteness,
	"vui lòng": RolePoliteness, "nhờ": RolePoliteness, "phiền": RolePoliteness,
	// Hedge
	"có thể": RoleHedge, "hình như": RoleHedge, "có lẽ": RoleHedge,
	"chắc": RoleHedge, "nghe có vẻ": RoleHedge, "hơi hướng": RoleHedge,
}

// Tokenize phân tách câu thành tokens có phân loại
func Tokenize(text string) []Token {
	lo := strings.ToLower(strings.TrimSpace(text))
	var tokens []Token

	// Multi-word phrases trước (ưu tiên dài hơn)
	for phrase, role := range roleMap {
		if strings.Contains(lo, phrase) && strings.Count(phrase, " ") > 0 {
			lo = strings.ReplaceAll(lo, phrase, "__"+strings.ReplaceAll(phrase, " ", "_")+"__")
			tokens = append(tokens, Token{Text: phrase, Role: role})
		}
	}

	// Single words
	words := strings.FieldsFunc(lo, func(r rune) bool {
		return unicode.IsSpace(r) || r == ',' || r == '.' || r == ';'
	})
	for _, w := range words {
		if strings.HasPrefix(w, "__") { continue } // đã xử lý
		role := RoleContent
		if r, ok := roleMap[w]; ok { role = r }
		tag, has := LookupAffect(w)
		tokens = append(tokens, Token{Text: w, Role: role, Tag: tag, Has: has})
	}
	return tokens
}

// ─── Lớp 3: IntentModifier ────────────────────────────────────────────────

// IntentModifier — modifier cảm xúc đi kèm intent
type IntentModifier struct {
	Urgency    float64 // 0..1
	Politeness float64 // 0..1
	Stress     float64 // 0..1 (CAPS, !!!)
	Hedge      float64 // 0..1
}

// DetectModifier đọc raw text → IntentModifier
func DetectModifier(raw string) IntentModifier {
	var m IntentModifier
	lo := strings.ToLower(raw)

	// Urgency: từ + dấu !
	urgencyWords := []string{"ngay", "gấp", "liền", "mau", "khẩn", "ngay lập tức"}
	for _, w := range urgencyWords {
		if strings.Contains(lo, w) { m.Urgency += 0.25 }
	}
	m.Urgency += float64(strings.Count(raw, "!")) * 0.15
	m.Urgency += float64(strings.Count(raw, "?")) * 0.08

	// Stress: CAPS
	upper, total := 0, 0
	for _, r := range raw {
		if unicode.IsLetter(r) {
			total++
			if unicode.IsUpper(r) { upper++ }
		}
	}
	if total > 3 && upper*100/max2(total,1) > 50 {
		m.Stress = 0.60
	}
	// Lặp từ (heyyy, ơiiii)
	for _, w := range strings.Fields(lo) {
		if len(w) > 3 {
			for i := 0; i < len(w)-2; i++ {
				if w[i] == w[i+1] && w[i] == w[i+2] { m.Stress += 0.20; break }
			}
		}
	}

	// Politeness
	politeWords := []string{"làm ơn", "xin", "vui lòng", "nhờ", "phiền", "giúp"}
	for _, w := range politeWords {
		if strings.Contains(lo, w) { m.Politeness += 0.25 }
	}

	// Hedge
	hedgeWords := []string{"có thể", "hình như", "có lẽ", "chắc", "nghe có vẻ"}
	for _, w := range hedgeWords {
		if strings.Contains(lo, w) { m.Hedge += 0.20 }
	}

	// Clamp
	m.Urgency    = math.Min(1.0, m.Urgency)
	m.Politeness = math.Min(1.0, m.Politeness)
	m.Stress     = math.Min(1.0, m.Stress)
	m.Hedge      = math.Min(1.0, m.Hedge)
	return m
}

// Apply áp dụng modifier lên EmotionTag gốc
func (m IntentModifier) Apply(base EmotionTag) EmotionTag {
	t := base
	// Urgency → Arousal tăng, Dominance tăng
	t.Arousal    = math.Min(0.95, t.Arousal + m.Urgency*0.35)
	t.Dominance  = math.Min(0.95, t.Dominance + m.Urgency*0.20)
	t.Intensity  = math.Min(0.95, t.Intensity + m.Urgency*0.15)
	// Stress → Arousal tăng mạnh, Valence giảm
	t.Arousal    = math.Min(0.95, t.Arousal + m.Stress*0.40)
	t.Valence    = math.Max(-0.95, t.Valence - m.Stress*0.20)
	// Politeness → Dominance giảm (nhường, khiêm tốn)
	t.Dominance  = math.Max(0.10, t.Dominance - m.Politeness*0.25)
	t.Arousal    = math.Max(0.10, t.Arousal   - m.Politeness*0.10)
	// Hedge → Intensity giảm (không chắc)
	t.Intensity  = math.Max(0.05, t.Intensity - m.Hedge*0.20)
	return t
}

// ─── Lớp 2: SentenceAffect — composition rule ────────────────────────────

// SentenceAffect phân tích EmotionTag của cả câu
func SentenceAffect(text string) EmotionTag {
	tokens := Tokenize(text)
	modifier := DetectModifier(text)

	var (
		baseV, baseA, baseD, baseI float64
		count                      int
		amplify                    = 1.0
		diminish                   = 1.0
		negate                     = false
		prevRole                   TokenRole
		causalBoost                = 1.0
		contrastBlend              = false
	)

	for i, tok := range tokens {
		switch tok.Role {
		case RoleAmplifier:
			amplify *= 1.40
		case RoleDiminisher:
			diminish *= 0.65
		case RoleNegation:
			negate = !negate
		case RoleCausal:
			causalBoost = 1.20 // từ sau "vì" quan trọng hơn
			prevRole = RoleCausal
		case RoleContrast:
			contrastBlend = true
			prevRole = RoleContrast
		case RoleConcession:
			diminish *= 0.75
		case RoleContent:
			if tok.Has {
				v := tok.Tag.Valence
				a := tok.Tag.Arousal
				d := tok.Tag.Dominance
				intensity := tok.Tag.Intensity

				// Áp dụng modifier tích lũy
				weight := amplify / diminish
				if prevRole == RoleCausal { weight *= causalBoost }
				if negate { v = -v * 0.70 }

				if contrastBlend && count > 0 {
					// Contrast: blend 50/50 giữa cũ và mới
					baseV = (baseV + v*weight) / 2.0
					baseA = (baseA + a*weight) / 2.0
					baseD = (baseD + d*weight) / 2.0
					baseI = (baseI + intensity*weight) / 2.0
					contrastBlend = false
				} else {
					// Additive với decay (từ sau ít quan trọng hơn từ đầu)
					decay := math.Pow(0.85, float64(i))
					baseV += v * weight * decay
					baseA += a * weight * decay
					baseD += d * weight * decay
					baseI += intensity * weight * decay
					count++
				}

				// Reset modifier sau khi dùng
				amplify  = 1.0
				diminish = 1.0
				negate   = false
				prevRole = RoleContent
				causalBoost = 1.0
			}
		}
	}

	if count == 0 {
		// Không có từ cảm xúc — dùng modifier trực tiếp
		base := EmotionTag{Valence: 0, Arousal: 0.40, Dominance: 0.50, Intensity: 0.10}
		return modifier.Apply(base)
	}

	// Normalize
	norm := func(v float64) float64 { return math.Max(-0.95, math.Min(0.95, v)) }
	result := EmotionTag{
		Valence:   norm(baseV),
		Arousal:   norm(math.Max(0.10, baseA)),
		Dominance: norm(math.Max(0.10, baseD)),
		Intensity: norm(math.Max(0.05, baseI)),
	}
	return modifier.Apply(result)
}

func max2(a, b int) int {
	if a > b { return a }
	return b
}
