package agents

import (
	"bytes"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"encoding/binary"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// ─── WorkerDeployServer integration tests ────────────────────────

// makeMinimalOlang tạo file .olang tối thiểu hợp lệ (magic + header)
func makeMinimalOlang(t *testing.T) []byte {
	t.Helper()
	buf := make([]byte, 280) // 64 header + 9*24 layer index = 280
	copy(buf[0:4], "OLNG")
	binary.BigEndian.PutUint16(buf[4:6], 18)   // version
	binary.BigEndian.PutUint16(buf[6:8], 0)    // flags
	buf[8] = 1                                 // nlayers
	binary.BigEndian.PutUint32(buf[9:13], 0)   // nnodes
	binary.BigEndian.PutUint32(buf[16:20], 0)  // nedges
	// SHA256 của buf[280:] (empty) — all zeros is fine for test
	return buf
}

func TestWorkerDeployServer_StatusEndpoint(t *testing.T) {
	deployDir := t.TempDir()
	srv := NewWorkerDeployServer(deployDir, 0) // port=0 → không bind

	// Test handler trực tiếp qua httptest
	mux := http.NewServeMux()
	mux.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status":"ok","deploy_dir":%q}`, srv.deployDir)
	})

	req := httptest.NewRequest(http.MethodGet, "/status", nil)
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("status: got %d want 200", w.Code)
	}
	body := w.Body.String()
	if !strings.Contains(body, `"ok"`) {
		t.Errorf("status body: %q", body)
	}
	t.Logf("Status: %s", body)
}

func TestWorkerDeployServer_DeployValid(t *testing.T) {
	deployDir := t.TempDir()
	deployed := make(chan string, 1)

	srv := NewWorkerDeployServer(deployDir, 0).
		WithDeployCallback(func(workerID, filePath string) {
			deployed <- filePath
		})

	// Build handler
	mux := http.NewServeMux()
	mux.HandleFunc("/deploy", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPut {
			http.Error(w, "PUT only", http.StatusMethodNotAllowed)
			return
		}
		workerID := r.Header.Get("X-HomeOS-Worker-ID")
		if workerID == "" {
			http.Error(w, "X-HomeOS-Worker-ID required", http.StatusBadRequest)
			return
		}
		data, err := io.ReadAll(io.LimitReader(r.Body, 10*1024*1024))
		if err != nil {
			http.Error(w, "read error", http.StatusInternalServerError)
			return
		}
		if len(data) < 4 || string(data[:4]) != "OLNG" {
			http.Error(w, "invalid olang file (bad magic)", http.StatusBadRequest)
			return
		}
		filename := fmt.Sprintf("worker_%s.olang", workerID)
		destPath := filepath.Join(srv.deployDir, filename)
		if err := os.WriteFile(destPath, data, 0644); err != nil {
			http.Error(w, "write error", http.StatusInternalServerError)
			return
		}
		if srv.onDeploy != nil {
			go srv.onDeploy(workerID, destPath)
		}
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"ok","worker_id":%q,"size":%d}`, workerID, len(data))
	})

	ts := httptest.NewServer(mux)
	defer ts.Close()

	// Gửi valid olang file
	olangData := makeMinimalOlang(t)
	req, _ := http.NewRequest(http.MethodPut, ts.URL+"/deploy", bytes.NewReader(olangData))
	req.Header.Set("X-HomeOS-Worker-ID", "light_living_room")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("deploy request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		t.Fatalf("deploy: got %d, body=%q", resp.StatusCode, body)
	}

	// Verify file được tạo
	expectedPath := filepath.Join(deployDir, "worker_light_living_room.olang")
	if _, err := os.Stat(expectedPath); os.IsNotExist(err) {
		t.Fatal("worker file not created")
	}

	// Verify callback được gọi
	select {
	case path := <-deployed:
		if path != expectedPath {
			t.Errorf("callback path: got %q want %q", path, expectedPath)
		}
		t.Logf("✅ Deployed to: %s", path)
	case <-time.After(2 * time.Second):
		t.Fatal("deploy callback not called")
	}

	// Verify file content
	written, _ := os.ReadFile(expectedPath)
	if !bytes.Equal(written, olangData) {
		t.Error("written file differs from sent data")
	}
}

func TestWorkerDeployServer_DeployBadMagic(t *testing.T) {
	deployDir := t.TempDir()
	srv := NewWorkerDeployServer(deployDir, 0)

	mux := http.NewServeMux()
	mux.HandleFunc("/deploy", func(w http.ResponseWriter, r *http.Request) {
		data, _ := io.ReadAll(r.Body)
		if len(data) < 4 || string(data[:4]) != "OLNG" {
			http.Error(w, "invalid olang file (bad magic)", http.StatusBadRequest)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	_ = srv

	ts := httptest.NewServer(mux)
	defer ts.Close()

	// Gửi data không hợp lệ
	badData := []byte("NOTOLANG_DATA_HERE")
	req, _ := http.NewRequest(http.MethodPut, ts.URL+"/deploy", bytes.NewReader(badData))
	req.Header.Set("X-HomeOS-Worker-ID", "test_worker")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("expected 400, got %d", resp.StatusCode)
	}
	t.Logf("✅ Bad magic rejected with %d", resp.StatusCode)
}

func TestWorkerDeployServer_DeployNoWorkerID(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/deploy", func(w http.ResponseWriter, r *http.Request) {
		workerID := r.Header.Get("X-HomeOS-Worker-ID")
		if workerID == "" {
			http.Error(w, "X-HomeOS-Worker-ID required", http.StatusBadRequest)
			return
		}
		w.WriteHeader(http.StatusOK)
	})

	ts := httptest.NewServer(mux)
	defer ts.Close()

	req, _ := http.NewRequest(http.MethodPut, ts.URL+"/deploy", bytes.NewReader(makeMinimalOlang(t)))
	// Không set X-HomeOS-Worker-ID

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusBadRequest {
		t.Errorf("expected 400 (no worker ID), got %d", resp.StatusCode)
	}
	t.Logf("✅ Missing Worker-ID rejected with %d", resp.StatusCode)
}

func TestWorkerDeployServer_DeployWrongMethod(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/deploy", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPut {
			http.Error(w, "PUT only", http.StatusMethodNotAllowed)
			return
		}
		w.WriteHeader(http.StatusOK)
	})

	ts := httptest.NewServer(mux)
	defer ts.Close()

	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/deploy", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusMethodNotAllowed {
		t.Errorf("expected 405, got %d", resp.StatusCode)
	}
	t.Logf("✅ Wrong method rejected with %d", resp.StatusCode)
}

func TestWorkerDeployServer_DeployMultipleWorkers(t *testing.T) {
	deployDir := t.TempDir()
	srv := NewWorkerDeployServer(deployDir, 0)

	mux := http.NewServeMux()
	mux.HandleFunc("/deploy", func(w http.ResponseWriter, r *http.Request) {
		workerID := r.Header.Get("X-HomeOS-Worker-ID")
		data, _ := io.ReadAll(r.Body)
		if string(data[:4]) != "OLNG" {
			http.Error(w, "bad magic", http.StatusBadRequest)
			return
		}
		filename := fmt.Sprintf("worker_%s.olang", workerID)
		destPath := filepath.Join(srv.deployDir, filename)
		os.WriteFile(destPath, data, 0644)
		if srv.onDeploy != nil {
			go srv.onDeploy(workerID, destPath)
		}
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"ok","worker_id":%q,"size":%d}`, workerID, len(data))
	})

	ts := httptest.NewServer(mux)
	defer ts.Close()

	// Deploy 3 workers đồng thời
	workers := []string{"light_kitchen", "hvac_living", "lock_front_door"}
	results := make(chan error, len(workers))

	for _, wid := range workers {
		go func(workerID string) {
			data := makeMinimalOlang(t)
			req, _ := http.NewRequest(http.MethodPut, ts.URL+"/deploy", bytes.NewReader(data))
			req.Header.Set("X-HomeOS-Worker-ID", workerID)
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				results <- err
				return
			}
			resp.Body.Close()
			if resp.StatusCode != http.StatusOK {
				results <- fmt.Errorf("worker %s: got %d", workerID, resp.StatusCode)
				return
			}
			results <- nil
		}(wid)
	}

	// Collect results
	for range workers {
		if err := <-results; err != nil {
			t.Errorf("deploy error: %v", err)
		}
	}

	// Verify tất cả files được tạo
	for _, wid := range workers {
		path := filepath.Join(deployDir, fmt.Sprintf("worker_%s.olang", wid))
		if _, err := os.Stat(path); os.IsNotExist(err) {
			t.Errorf("worker file %q not created", wid)
		}
	}
	t.Logf("✅ %d workers deployed concurrently", len(workers))
}

// ─── ExportWorkerSkill tests ─────────────────────────────────────

func TestExportWorkerSkill_CanHandle(t *testing.T) {
	s := NewExportWorkerSkill("chief_home", "homeos.olang")

	// ExportWorkerSkill respond to MsgActuatorCmd với action=spawn_worker/export_worker
	spawnPayload := []byte(`{"action":"spawn_worker","worker_id":"light_01"}`)
	exportPayload := []byte(`{"action":"export_worker","worker_id":"hvac_01"}`)
	otherPayload := []byte(`{"action":"turn_on","device":"light"}`)

	cases := []struct {
		name    string
		msgType isl.MsgType
		payload []byte
		want    bool
	}{
		{"spawn_worker", isl.MsgActuatorCmd, spawnPayload, true},
		{"export_worker", isl.MsgActuatorCmd, exportPayload, true},
		{"other_action", isl.MsgActuatorCmd, otherPayload, false},
		{"wrong_type", isl.MsgTick, spawnPayload, false},
		{"nil_payload", isl.MsgActuatorCmd, nil, false},
	}

	for _, tc := range cases {
		msg := &isl.ISLMessage{MsgType: tc.msgType, Payload: tc.payload}
		got := s.CanHandle(msg)
		if got != tc.want {
			t.Errorf("[%s] CanHandle: got %v want %v", tc.name, got, tc.want)
		}
	}
	t.Logf("✅ ExportWorkerSkill.CanHandle: all cases pass")
}
