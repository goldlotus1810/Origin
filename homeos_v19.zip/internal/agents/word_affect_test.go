package agents

import (
	"fmt"
	"math"
	"testing"
)

func TestWordAffect(t *testing.T) {
	t.Log("╔═══════════════════════════════════════════════════════════╗")
	t.Log("║  WordAffect — lựa từ thích hợp theo đường cong cảm xúc   ║")
	t.Log("╚═══════════════════════════════════════════════════════════╝")
	t.Log()

	// ── Test 1: Lexicon lookup ────────────────────────────────────
	t.Log("[ Lexicon ]")
	for _, word := range []string{"buồn", "vui", "bình yên", "chiến tranh", "thoải mái"} {
		tag, ok := LookupAffect(word)
		if ok {
			t.Logf("  %-14s V=%+.2f A=%.2f I=%.2f  [%s]",
				word, tag.Valence, tag.Arousal, tag.Intensity, tag.Label())
		}
	}
	t.Log()

	// ── Test 2: 3 kịch bản cuộc trò chuyện ───────────────────────
	scenarios := []struct {
		name   string
		turns  []struct{ text string; v, a float64 }
	}{
		{
			"User đang buồn dần → hệ thống dùng từ nhẹ nhàng",
			[]struct{ text string; v, a float64 }{
				{"xin chào", +0.20, 0.40},
				{"hôm nay mệt quá", -0.20, 0.35},
				{"thất bại rồi", -0.50, 0.50},
				{"không biết làm gì nữa", -0.65, 0.40},
			},
		},
		{
			"User đang hồi phục → hệ thống củng cố",
			[]struct{ text string; v, a float64 }{
				{"mình buồn lắm", -0.60, 0.45},
				{"nhưng cố gắng tiếp", -0.30, 0.50},
				{"có vẻ ổn hơn rồi", +0.10, 0.45},
				{"tin tốt đến rồi!", +0.50, 0.65},
			},
		},
		{
			"User đột ngột chia sẻ chuyện nặng nề → pause",
			[]struct{ text string; v, a float64 }{
				{"hôm nay bình thường", +0.15, 0.40},
				{"cũng ổn thôi", +0.20, 0.35},
				{"ba mình vừa mất", -0.90, 0.70},
				{"không biết phải làm gì", -0.75, 0.55},
			},
		},
	}

	for si, sc := range scenarios {
		t.Logf("── Kịch bản %d: %s ──", si+1, sc.name)
		curve := NewConversationCurve(nil)

		for _, turn := range sc.turns {
			tag := EmotionTag{
				Valence: turn.v, Arousal: turn.a,
				Dominance: 0.5, Intensity: math.Abs(turn.v)*0.7 + turn.a*0.2,
			}
			curve.Add(tag, turn.text)
		}

		cur    := curve.Window[len(curve.Window)-1].Tag
		tone   := curve.NextTone()
		target := TargetAffect(curve)
		words  := SelectWords(target, 5)
		sent   := AffectSentence(curve, "vi")

		t.Logf("  Hiện tại:  V=%+.2f [%s]", cur.Valence, cur.Label())
		t.Logf("  f'=%.3f  f''=%.3f  → Tone: %s", curve.D1(), curve.D2(), tone.Style)
		t.Logf("  Target:    V=%+.2f A=%.2f", target.Valence, target.Arousal)
		t.Logf("  Từ phù hợp: %s", func() string {
			s := ""
			for _, w := range words { s += fmt.Sprintf("%s(%.2f) ", w.Word, w.Score) }
			return s
		}())
		if sent != "" {
			t.Logf("  Câu mẫu:  \"%s\"", sent)
		}
		t.Log()
	}

	// ── Test 3: Dẫn dần không nhảy ───────────────────────────────
	t.Log("── Minh họa: dẫn dần V=-0.70 → +0.80 (5 bước) ──")
	t.Log("  (Không nhảy thẳng — tự nhiên hơn)")
	t.Log()

	curve := NewConversationCurve(nil)
	v := -0.70
	targets := []float64{}
	for step := 0; step < 6; step++ {
		tag := EmotionTag{Valence: v, Arousal: 0.45, Dominance: 0.5,
			Intensity: math.Abs(v) * 0.6}
		curve.Add(tag, "...")
		tgt := TargetAffect(curve)
		targets = append(targets, tgt.Valence)
		words := SelectWords(tgt, 2)
		t.Logf("  Bước %d: V=%+.2f → target=%+.2f  từ=[%s, %s]",
			step+1, v, tgt.Valence, words[0].Word, words[1].Word)
		v = tgt.Valence * 0.7 + v * 0.3 // simulate user following
	}

	// Verify: không nhảy quá 0.35/bước
	for i := 1; i < len(targets); i++ {
		jump := math.Abs(targets[i] - targets[i-1])
		if jump > 0.40 {
			t.Errorf("Bước nhảy quá lớn: %.2f tại step %d", jump, i)
		}
	}
	t.Log()
	t.Log("✓ Dẫn dần tự nhiên — không nhảy đột ngột")
	t.Log("✓ Từ ngữ thay đổi theo đường cong: nặng → nhẹ → vui")
	t.Log("✓ Mỗi từ có EmotionTag riêng trong lexicon")
	t.Log("✓ SelectWords: khoảng cách VAD Euclidean với Valence×2 weight")
}
