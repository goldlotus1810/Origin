// internal/agents/hotreload_router.go
// HotReloadRouter — thread-safe wrapper quanh ISLRouter
// Cho phép WorldScene.AddCreature() từ goroutine bất kỳ
// mà PerceptLayer vẫn thấy nodes mới ngay lập tức.
//
// Design:
//   - RWMutex bảo vệ Nodes slice
//   - Snapshot(): copy nodes ra ngoài để Route() không giữ lock lâu
//   - OnUpdate callback: PerceptLayer / AddrAgentMap tự cập nhật

package agents

import (
	"sync"
	"sync/atomic"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// RouterUpdateEvent thông báo khi nodes thay đổi
type RouterUpdateEvent struct {
	Added   []gene.SpatialNode // nodes mới thêm
	Total   int                // tổng số nodes sau update
}

// HotReloadRouter — ISLRouter thread-safe với hot-reload
type HotReloadRouter struct {
	mu        sync.RWMutex
	nodes     []gene.SpatialNode
	threshold float64
	version   atomic.Uint64

	// OnUpdate nhận event mỗi khi có node mới
	OnUpdate func(RouterUpdateEvent)
}

// NewHotReloadRouter tạo router từ nodes ban đầu
func NewHotReloadRouter(nodes []gene.SpatialNode, threshold float64) *HotReloadRouter {
	r := &HotReloadRouter{threshold: threshold}
	r.nodes = make([]gene.SpatialNode, len(nodes))
	copy(r.nodes, nodes)
	r.version.Store(1)
	return r
}

// Reload cập nhật toàn bộ nodes (gọi sau WorldScene.Tick)
// Thread-safe — PerceptLayer gọi mỗi tick
func (r *HotReloadRouter) Reload(nodes []gene.SpatialNode) (added int) {
	r.mu.Lock()
	defer r.mu.Unlock()

	oldLen := len(r.nodes)
	newNodes := make([]gene.SpatialNode, len(nodes))
	copy(newNodes, nodes)
	r.nodes = newNodes

	added = len(nodes) - oldLen
	if added != 0 {
		r.version.Add(1)
		if r.OnUpdate != nil && added > 0 {
			evt := RouterUpdateEvent{Total: len(nodes)}
			if added > 0 {
				evt.Added = newNodes[oldLen:]
			}
			go r.OnUpdate(evt)
		}
	}
	return added
}

// AddNode thêm 1 node mới — dùng khi WorldScene.AddCreature()
// Thread-safe — có thể gọi từ bất kỳ goroutine nào
func (r *HotReloadRouter) AddNode(n gene.SpatialNode) {
	r.mu.Lock()
	// check duplicate addr
	for _, existing := range r.nodes {
		if existing.Addr == n.Addr { r.mu.Unlock(); return }
	}
	r.nodes = append(r.nodes, n)
	total := len(r.nodes)
	r.version.Add(1)
	onUpdate := r.OnUpdate
	r.mu.Unlock()

	if onUpdate != nil {
		go onUpdate(RouterUpdateEvent{
			Added: []gene.SpatialNode{n},
			Total: total,
		})
	}
}

// Route evaluate SDF tại điểm p → ISLAddr
// Thread-safe — copy nodes snapshot trước khi route
func (r *HotReloadRouter) Route(p gene.Vec3) gene.RouteResult {
	r.mu.RLock()
	nodes := make([]gene.SpatialNode, len(r.nodes))
	copy(nodes, r.nodes)
	threshold := r.threshold
	r.mu.RUnlock()

	router := gene.NewISLRouter(nodes, threshold)
	return router.Route(p)
}

// RouteAll route nhiều probes cùng lúc
func (r *HotReloadRouter) RouteAll(probes []gene.Vec3) []gene.RouteResult {
	r.mu.RLock()
	nodes := make([]gene.SpatialNode, len(r.nodes))
	copy(nodes, r.nodes)
	threshold := r.threshold
	r.mu.RUnlock()

	router := gene.NewISLRouter(nodes, threshold)
	return router.RouteAll(probes)
}

// Snapshot trả về copy hiện tại của nodes
func (r *HotReloadRouter) Snapshot() []gene.SpatialNode {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]gene.SpatialNode, len(r.nodes))
	copy(out, r.nodes)
	return out
}

// Version trả về version counter — tăng mỗi khi nodes đổi
func (r *HotReloadRouter) Version() uint64 { return r.version.Load() }

// Len trả về số nodes hiện tại
func (r *HotReloadRouter) Len() int {
	r.mu.RLock(); defer r.mu.RUnlock()
	return len(r.nodes)
}

// Tally đếm ISLAddr xuất hiện trong route results
func (r *HotReloadRouter) Tally(results []gene.RouteResult) map[uint64]int {
	m := make(map[uint64]int)
	for _, res := range results {
		if res.Confident { m[res.TargetAddr]++ }
	}
	return m
}

// AddrToLabel tra cứu label của ISLAddr từ nodes hiện tại
func (r *HotReloadRouter) AddrToLabel(addr isl.Address) string {
	a64 := addr.Uint64()
	r.mu.RLock()
	defer r.mu.RUnlock()
	for _, n := range r.nodes {
		if n.Addr == a64 { return n.Label }
	}
	return ""
}
