package agents

import (
	"strings"
	"testing"
)

func TestSentenceAffect(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  SentenceAffect — câu = walk + composition, không phải mean  ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	cases := []struct{ desc, text string }{
		// ── Modifier cơ bản ──────────────────────────────────────────
		{"Baseline",              "tôi buồn"},
		{"Amplifier",             "tôi rất buồn"},
		{"Diminisher",            "tôi hơi buồn"},
		{"Negation",              "tôi không buồn"},
		{"Double negation",       "tôi không phải không vui"},

		// ── Connector ────────────────────────────────────────────────
		{"Causal (nặng hơn)",     "tôi buồn vì mất mát"},
		{"Contrast (blend)",      "tôi buồn nhưng vui"},
		{"Concession (giảm nhẹ)", "dù mất mát nhưng bình yên"},
		{"Additive",              "vui và hạnh phúc"},

		// ── Câu lệnh / yêu cầu ───────────────────────────────────────
		{"Lệnh bình thường",      "tắt đèn"},
		{"Urgency (ngay!)",       "tắt đèn ngay!"},
		{"Politeness",            "làm ơn tắt đèn giúp tôi"},
		{"Stress (CAPS!!!)",      "TẮT ĐÈN!!!"},
		{"Hedge + request",       "bạn có thể tắt đèn giúp không"},
		{"Stress lặp từ",         "ơiiiiii tắt đèn đi"},

		// ── Câu phức tạp ─────────────────────────────────────────────
		{"Phức tạp 1",            "tôi rất buồn vì mất việc nhưng vẫn cố gắng"},
		{"Phức tạp 2",            "mặc dù khó khăn nhưng tôi vẫn vui vẻ"},
		{"Phức tạp 3",            "làm ơn giúp tôi vì tôi rất lo lắng"},
		{"Phức tạp 4",            "KHÔNG được làm vậy ngay bây giờ!!!"},
	}

	t.Logf("%-28s  %-6s %-6s %-6s %-5s  %-10s  %s",
		"Câu", "V", "A", "D", "I", "Label", "Ghi chú")
	t.Log(strings.Repeat("─", 85))

	for _, c := range cases {
		tag := SentenceAffect(c.text)
		mod := DetectModifier(c.text)
		note := ""
		if mod.Urgency > 0.2  { note += "⚡urgency " }
		if mod.Politeness > 0 { note += "🙏polite " }
		if mod.Stress > 0     { note += "😤stress " }
		if mod.Hedge > 0      { note += "🤔hedge " }
		t.Logf("%-28s  %+.2f  %.2f  %.2f  %.2f  %-10s  %s",
			c.desc, tag.Valence, tag.Arousal, tag.Dominance, tag.Intensity,
			tag.Label(), note)
	}

	t.Log()
	t.Log("── Verify quan trọng ──")

	// "rất buồn" phải âm hơn "buồn"
	buon    := SentenceAffect("tôi buồn")
	ratBuon := SentenceAffect("tôi rất buồn")
	if ratBuon.Valence >= buon.Valence {
		t.Errorf("rất buồn(%.2f) phải < buồn(%.2f)", ratBuon.Valence, buon.Valence)
	} else {
		t.Logf("✓ rất buồn(%.2f) < buồn(%.2f)", ratBuon.Valence, buon.Valence)
	}

	// "không buồn" phải dương hơn "buồn"
	khongBuon := SentenceAffect("tôi không buồn")
	if khongBuon.Valence <= buon.Valence {
		t.Errorf("không buồn(%.2f) phải > buồn(%.2f)", khongBuon.Valence, buon.Valence)
	} else {
		t.Logf("✓ không buồn(%.2f) > buồn(%.2f)", khongBuon.Valence, buon.Valence)
	}

	// "tắt đèn ngay!" phải có Arousal cao hơn "tắt đèn"
	tatDen     := SentenceAffect("tắt đèn")
	tatDenNgay := SentenceAffect("tắt đèn ngay!")
	if tatDenNgay.Arousal <= tatDen.Arousal {
		t.Errorf("urgency Arousal(%.2f) phải > normal(%.2f)", tatDenNgay.Arousal, tatDen.Arousal)
	} else {
		t.Logf("✓ urgency A=%.2f > normal A=%.2f", tatDenNgay.Arousal, tatDen.Arousal)
	}

	// "TẮT ĐÈN!!!" phải có Arousal cao nhất
	tatDenSTRESS := SentenceAffect("TẮT ĐÈN!!!")
	if tatDenSTRESS.Arousal <= tatDenNgay.Arousal {
		t.Errorf("STRESS A(%.2f) phải > urgency A(%.2f)", tatDenSTRESS.Arousal, tatDenNgay.Arousal)
	} else {
		t.Logf("✓ STRESS A=%.2f > urgency A=%.2f > normal A=%.2f",
			tatDenSTRESS.Arousal, tatDenNgay.Arousal, tatDen.Arousal)
	}

	// "làm ơn tắt đèn" Dominance thấp hơn "tắt đèn"
	tatDenPolite := SentenceAffect("làm ơn tắt đèn")
	if tatDenPolite.Dominance >= tatDen.Dominance {
		t.Errorf("polite D(%.2f) phải < normal D(%.2f)", tatDenPolite.Dominance, tatDen.Dominance)
	} else {
		t.Logf("✓ polite D=%.2f < normal D=%.2f (khiêm tốn hơn)", tatDenPolite.Dominance, tatDen.Dominance)
	}

	t.Log()
	t.Log("── Ứng dụng vào Brain ──")
	t.Log("  Mỗi tin nhắn user → SentenceAffect() thay vì TextToEmotionTag()")
	t.Log("  'làm ơn giúp tôi' → tone=supportive + D thấp → trả lời ấm hơn")
	t.Log("  'TẮT ĐÈN!!!'      → tone=pause + urgency → thực hiện ngay + hỏi có ổn không")
}
