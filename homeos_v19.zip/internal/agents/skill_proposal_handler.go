// internal/agents/skill_proposal_handler.go
//
// ProposalHandlerSkill — AAM xử lý MsgPropose từ NCA và ClusterSkill (QT7)
//
// Luồng 1 (NodeHash — từ NCA.proposeCycle):
//   payload = []uint64 NodeHash
//   → GetByHash → conf >= 0.8 → qr.Commit → dn.MarkArchived
//
// Luồng 2 (Cluster — từ ClusterSkill.Execute):
//   payload = "cluster|name|level|childCount" (text)
//   → Parse → clusterSkill.CommitCluster(proposal)
//
// Không vi phạm QT7: AAM (tier 0) mới được approve.
// NCA/LeoAI (tier 1) chỉ propose, không tự commit.

package agents

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// ProposalHandlerSkill — nhận MsgPropose từ NCA và ClusterSkill
type ProposalHandlerSkill struct {
	dn           *memory.ShortTerm
	qr           *memory.LongTerm
	threshold    float64        // conf >= threshold → auto-approve (default 0.8)
	clusterSkill *ClusterSkill  // nil nếu không có ClusterSkill
	graph        *silk.SilkGraph // nil nếu không wire
}

func NewProposalHandlerSkill(dn *memory.ShortTerm, qr *memory.LongTerm) *ProposalHandlerSkill {
	return &ProposalHandlerSkill{dn: dn, qr: qr, threshold: 0.8}
}

// WithClusterSkill đăng ký ClusterSkill để handler có thể commit cluster proposals
func (s *ProposalHandlerSkill) WithClusterSkill(cs *ClusterSkill) *ProposalHandlerSkill {
	s.clusterSkill = cs
	return s
}

// WithGraph wire SilkGraph để approve Hebbian edge proposals
func (s *ProposalHandlerSkill) WithGraph(g *silk.SilkGraph) *ProposalHandlerSkill {
	s.graph = g
	return s
}

func (s *ProposalHandlerSkill) Name() string { return "proposal_handler" }

func (s *ProposalHandlerSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgPropose
}

func (s *ProposalHandlerSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	payload := msg.Payload
	if len(payload) == 0 {
		return SkillResult{}
	}

	// Luồng 2: Cluster proposal — "cluster|name|level|count"
	if bytes.HasPrefix(payload, []byte("cluster|")) {
		return s.handleClusterProposal(msg)
	}

	// Luồng 3: Hebbian edge proposal — "edge|fromHex|toHex"
	if bytes.HasPrefix(payload, []byte("edge|")) {
		return s.handleEdgeProposal(msg)
	}

	// Luồng 1: NodeHash payload — []uint64 (8 bytes/hash)
	return s.handleNodeHashProposal(payload)
}

// handleNodeHashProposal xử lý []NodeHash từ NCA.proposeCycle
func (s *ProposalHandlerSkill) handleNodeHashProposal(payload []byte) SkillResult {
	promoted := 0
	skipped := 0

	for i := 0; i+8 <= len(payload); i += 8 {
		hashVal := binary.BigEndian.Uint64(payload[i : i+8])
		nodeHash := isl.NodeHash(hashVal)

		entry, ok := s.dn.GetByHash(nodeHash)
		if !ok || entry == nil {
			skipped++
			continue
		}

		// Auto-approve nếu confidence >= threshold (QT7: chứng minh pass)
		if entry.Confidence < s.threshold {
			skipped++
			continue
		}

		if err := s.qr.Commit(*entry); err != nil {
			log.Printf("ProposalHandler: commit failed hash=%016x: %v", hashVal, err)
			skipped++
			continue
		}

		s.dn.MarkArchived(nodeHash)
		promoted++
	}

	if promoted > 0 {
		log.Printf("ProposalHandler: AAM approved %d ĐN→QR (skipped %d)", promoted, skipped)
	}

	return SkillResult{
		Message: &isl.ISLMessage{
			MsgType: isl.MsgApproved,
			Payload: encodeInt(promoted),
		},
	}
}

// handleClusterProposal xử lý "cluster|name|level|childCount" từ ClusterSkill
// Format: "cluster|cluster[L][G]|twig|5"
func (s *ProposalHandlerSkill) handleClusterProposal(msg *isl.ISLMessage) SkillResult {
	parts := strings.SplitN(string(msg.Payload), "|", 4)
	if len(parts) != 4 {
		log.Printf("ProposalHandler: cluster payload format sai: %q", msg.Payload)
		return SkillResult{}
	}
	// parts[0]="cluster", [1]=name, [2]=level, [3]=childCount
	name := parts[1]
	level := parts[2]
	childCount, _ := strconv.Atoi(parts[3])

	if s.clusterSkill == nil {
		log.Printf("ProposalHandler: cluster proposal %q nhận được nhưng clusterSkill=nil", name)
		return SkillResult{}
	}

	// Reconstruct ClusterProposal từ payload + PrimaryAddr
	proposal := ClusterProposal{
		ParentAddr: msg.PrimaryAddr,
		Name:       name,
		Level:      level,
		ChildCount: childCount,
		// Children được lấy lại từ ShortTerm theo ParentAddr group
		Children: s.resolveChildren(msg.PrimaryAddr),
	}

	s.clusterSkill.CommitCluster(proposal)
	log.Printf("ProposalHandler: AAM approved cluster %q (%s, %d nodes → SilkGraph)",
		name, level, len(proposal.Children))

	return SkillResult{
		Message: &isl.ISLMessage{
			MsgType: isl.MsgApproved,
			Payload: []byte(fmt.Sprintf("cluster:%s", name)),
		},
	}
}

// resolveChildren tìm lại children addresses từ ShortTerm theo parent group
func (s *ProposalHandlerSkill) resolveChildren(parentAddr isl.Address) []isl.Address {
	if s.dn == nil {
		return nil
	}
	all := s.dn.All()
	var result []isl.Address
	for _, obs := range all {
		if obs.ISL.Layer == parentAddr.Layer && obs.ISL.Group == parentAddr.Group {
			result = append(result, obs.ISL)
		}
	}
	return result
}

// handleEdgeProposal xử lý "edge|fromHex|toHex" từ HebbianSkill
// Tạo edge mới trong SilkGraph (nếu graph được wire)
func (s *ProposalHandlerSkill) handleEdgeProposal(msg *isl.ISLMessage) SkillResult {
	parts := strings.SplitN(string(msg.Payload), "|", 3)
	if len(parts) != 3 {
		log.Printf("ProposalHandler: edge payload format sai: %q", msg.Payload)
		return SkillResult{}
	}
	// parts[0]="edge", [1]=fromHex, [2]=toHex
	var fromU, toU uint64
	fmt.Sscanf(parts[1], "%016x", &fromU)
	fmt.Sscanf(parts[2], "%016x", &toU)

	if s.graph == nil {
		log.Printf("ProposalHandler: edge proposal nhận được nhưng graph=nil")
		return SkillResult{}
	}

	// Tạo Address từ uint64 via big-endian bytes
	var fromB, toB [8]byte
	binary.BigEndian.PutUint64(fromB[:], fromU)
	binary.BigEndian.PutUint64(toB[:], toU)
	fromAddr := isl.FromBytes(fromB[:])
	toAddr   := isl.FromBytes(toB[:])
	s.graph.AddEdge(fromAddr, toAddr, silk.OpSimilar)
	log.Printf("ProposalHandler: AAM approved Hebbian edge %016x→%016x", fromU, toU)

	return SkillResult{
		Message: &isl.ISLMessage{
			MsgType: isl.MsgApproved,
			Payload: []byte(fmt.Sprintf("edge:%016x→%016x", fromU, toU)),
		},
	}
}

func encodeInt(n int) []byte {
	b := make([]byte, 4)
	binary.BigEndian.PutUint32(b, uint32(n))
	return b
}
