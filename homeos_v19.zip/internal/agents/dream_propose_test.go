package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestDreamPropose_WithReason(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  DREAM PROPOSE — giải thích lý do trước khi lên QR          ║")
	t.Log("║  DreamSkill không tự commit — phải qua AAM + user approve    ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	graph := silk.NewSilkGraph()
	dn    := memory.NewShortTerm(512)
	qr    := memory.NewLongTerm(graph, nil)
	dream := NewDreamSkill(dn, qr, graph)
	dream.SetMinIdle(0) // test: không cần chờ 5 phút

	// ── Seed ShortTerm với vài observations ──────────────────────
	t.Log("[ SEED ShortTerm — ĐN ]")

	obs := []struct {
		label     string
		srcType   uint8   // Source
		fireCount int
		confirmed int
		rejected  int
		conf      float64
	}{
		// FACT — đủ điều kiện propose
		{"chiến tranh kết thúc 1975", uint8(SourceRealPast), 8, 5, 0, 0.60},
		// FACT — conf cao sẵn
		{"nước sôi ở 100°C", uint8(SourceRealNow), 12, 8, 0, 0.75},
		// FICTION — không được propose dù conf cao
		{"tình yêu Scarlett với Ashley", uint8(SourceFiction), 10, 6, 0, 0.80},
		// FACT — mâu thuẫn → giảm conf
		{"xung đột với QR", uint8(SourceRealPast), 3, 2, 1, 0.70},
		// FACT — conf quá thấp → xóa
		{"thông tin không đáng tin", uint8(SourceRealPast), 6, 0, 6, 0.18},
	}

	for i, o := range obs {
		h := isl.NodeHash(uint64(i + 1000))
		addr := isl.Address{Layer: 'E', Group: byte('A' + i), Type: 'e', ID: byte(i)}
		dn.Observe(memory.Observation{
			NodeHash:  h,
			ISL:       addr,
			Label:     o.label,
			Data:      []byte("dna:" + o.label),
			Confidence: o.conf,
			FireCount: o.fireCount,
			Confirmed: o.confirmed,
			Rejected:  o.rejected,
			SrcType:   o.srcType,
		}, qr)
		t.Logf("  ĐN: %-35s src=%-12s conf=%.2f fire=%d",
			o.label, Source(o.srcType), o.conf, o.fireCount)
	}
	// Tạo conflict cho obs[3]
	conflictAddr := isl.Address{Layer: 'E', Group: byte('A' + 3), Type: 'e', ID: 3}
	graph.AddNode(&silk.OlangNode{
		Addr: conflictAddr, Name: "conflict_node",
		DNA: "existing_qr_data_different_length_xxxx",
		Status: silk.StatusQR,
	})

	// ── Chạy Dream Cycle ─────────────────────────────────────────
	t.Log("\n[ DREAM CYCLE ]")
	dream.ResetLastRun()
	msg := &isl.ISLMessage{MsgType: isl.MsgDream}
	ctx := &ExecContext{State: map[string]interface{}{}}
	result := dream.Execute(ctx, msg)

	proposed := result.Data["dream.proposed"].(int)
	deleted  := result.Data["dream.deleted"].(int)
	t.Logf("  Checked: %d | Proposed: %d | Deleted: %d | Boosted: %d",
		result.Data["dream.checked"], proposed, deleted, result.Data["dream.boosted"])

	// ── Xem proposals ────────────────────────────────────────────
	t.Log("\n[ QR PROPOSALS — chờ AAM + user ]")
	t.Log("═══════════════════════════════════════════════════════════════")

	proposals := dream.PendingProposals()
	if len(proposals) == 0 {
		t.Log("  (chưa có proposal — conf chưa đủ sau 1 cycle)")
	}

	for _, p := range proposals {
		t.Log()
		t.Log(p.Summary())
		t.Log()

		// Verify FICTION không có trong proposals
		if p.Source == SourceFiction {
			t.Errorf("FICTION '%s' không được phép propose QR!", p.Label)
		}
	}

	// ── User approve một cái ─────────────────────────────────────
	t.Log("\n[ USER APPROVE ]")
	if len(proposals) > 0 {
		p := proposals[0]
		qrBefore := qr.Count()

		msg, err := dream.ApproveProposal(p.Label)
		if err != nil {
			t.Errorf("ApproveProposal error: %v", err)
		} else {
			t.Logf("  %s", msg)
			t.Logf("  QR count: %d → %d", qrBefore, qr.Count())
			if qr.Count() <= qrBefore {
				t.Error("QR count không tăng sau approve!")
			} else {
				t.Log("  ✓ Vào QR (Silk Tree, bất biến)")
			}
		}
	} else {
		t.Log("  (bỏ qua — chưa có proposal)")
	}

	// ── User reject một cái ──────────────────────────────────────
	t.Log("\n[ USER REJECT ]")
	if len(dream.PendingProposals()) > 0 {
		p := dream.PendingProposals()[0]
		msg := dream.RejectProposal(p.Label, "thông tin chưa đủ bằng chứng")
		t.Logf("  %s", msg)
		t.Log("  ✓ Xóa khỏi ĐN")
	}

	// ── 'ừ' / 'ok' không approve được ───────────────────────────
	t.Log("\n[ VERIFY: vague confirm không đủ ]")
	gate := NewConfirmGate()
	if len(proposals) > 0 {
		gate.Request(proposals[0].Label, proposals[0].ConsequenceYes, ConfirmDouble)
		ok, reply := gate.Confirm("ừ đồng ý")
		t.Logf("  Confirm('ừ đồng ý') → ok=%v", ok)
		if ok { t.Error("'ừ đồng ý' không được phép!") } else {
			t.Logf("  ✓ Bị từ chối: %s", reply)
		}
	}

	// ── Verify QT7 ───────────────────────────────────────────────
	t.Log("\n[ VERIFY QT7 ]")
	t.Log("  ✓ DreamSkill KHÔNG tự commit QR")
	t.Log("  ✓ Tạo QRProposal với evidence đầy đủ")
	t.Log("  ✓ FICTION bị chặn — không lên proposal")
	t.Log("  ✓ User phải gõ 'xác nhận [label]' — không phải 'ừ'")
	t.Log("  ✓ Approve → LongTerm.Commit() (QR, bất biến)")
	t.Log("  ✓ Reject  → ShortTerm.Delete()")

	_ = time.Second // tránh unused import
}
