package agents

import (
	"testing"
	"github.com/goldlotus1810/HomeOS/internal/gene"
)

func TestEdgeTopology(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  EDGE TOPOLOGY — mỗi thiết bị chỉ 1 skill                  ║")
	t.Log("║  LeoAI gửi đúng loại dữ liệu cho đúng thiết bị             ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	cameras := []DeviceProfile{
		func() DeviceProfile { p := ProfileCamera; p.ID = "cam_kitchen";   p.LocationISL = "HAa1"; p.Location = gene.SpaceKitchen;     return p }(),
		func() DeviceProfile { p := ProfileCamera; p.ID = "cam_bedroom";   p.LocationISL = "HAc1"; p.Location = gene.SpaceBedroom;     return p }(),
	}
	mics := []DeviceProfile{
		func() DeviceProfile { p := ProfileMic;    p.ID = "mic_living";    p.LocationISL = "HAb1"; p.Location = gene.SpaceLivingRoom;  return p }(),
	}
	lights := []DeviceProfile{
		func() DeviceProfile { p := ProfileLight;  p.ID = "light_kitchen"; p.LocationISL = "HAa1"; p.Location = gene.SpaceKitchen;     return p }(),
		func() DeviceProfile { p := ProfileLight;  p.ID = "light_bedroom"; p.LocationISL = "HAc1"; p.Location = gene.SpaceBedroom;     return p }(),
	}
	hvacs := []DeviceProfile{
		func() DeviceProfile { p := ProfileHVAC;   p.ID = "hvac_bedroom";  p.LocationISL = "HAc1"; p.Location = gene.SpaceBedroom;     return p }(),
	}

	allDevices := append(append(append(cameras, mics...), lights...), hvacs...)

	packets := []struct {
		desc string
		pkt  *LearnPacket
	}{
		{
			"LeoAI học: motion pattern 'nấu ăn mới' → camera",
			&LearnPacket{Type: PacketMotionSignature, TargetRole: RoleSensor},
		},
		{
			"LeoAI học: audio 'nhạc jazz' → mic",
			&LearnPacket{Type: PacketAudioSignature, TargetRole: RoleSensor},
		},
		{
			"LeoAI học: đèn bếp bật lúc 18:00 → light HAa1",
			&LearnPacket{Type: PacketSchedule, TargetRole: RoleActuator, TargetISL: "HAa1"},
		},
		{
			"LeoAI học: phòng ngủ 26°C lúc 22:00 → hvac HAc1",
			&LearnPacket{Type: PacketTempProfile, TargetRole: RoleHybrid, TargetISL: "HAc1"},
		},
		{
			"LeoAI học: lịch tất cả đèn",
			&LearnPacket{Type: PacketSchedule, TargetRole: RoleActuator},
		},
	}

	t.Log("[ ROUTING: LeoAI → đúng thiết bị ]")
	t.Log()
	for _, p := range packets {
		t.Logf("  📦 %s", p.desc)
		for _, d := range allDevices {
			if d.ShouldAccept(p.pkt) {
				t.Logf("     ✓ %-18s (%s)", d.ID, d.LocationISL)
			}
		}
		t.Log()
	}

	t.Log("[ RAM FOOTPRINT ]")
	rows := []struct{ id, role, ram, skills string }{
		{"cam_kitchen",   "sensor",   "~8MB",   "PerceptionSkill"},
		{"cam_bedroom",   "sensor",   "~8MB",   "PerceptionSkill"},
		{"mic_living",    "sensor",   "~2MB",   "AudioSkill"},
		{"light_kitchen", "actuator", "~64KB",  "ActuatorLight"},
		{"light_bedroom", "actuator", "~64KB",  "ActuatorLight"},
		{"hvac_bedroom",  "hybrid",   "~128KB", "ActuatorHVAC + TempSensor"},
	}
	for _, r := range rows {
		t.Logf("  %-18s  %-9s  %-8s  %s", r.id, r.role, r.ram, r.skills)
	}

	t.Log()
	t.Log("[ KHÔNG NHẬN ]")
	t.Log("  camera    ✗ audio, schedule, temp")
	t.Log("  mic       ✗ motion, schedule, temp")
	t.Log("  đèn       ✗ motion, audio, temp")
	t.Log("  điều hòa  ✗ motion, audio")
}
