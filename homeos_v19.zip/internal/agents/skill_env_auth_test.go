package agents

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestEnvironmentAndEphemeralAuth(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  ENVIRONMENT AWARENESS + EPHEMERAL AUTHORITY                ║")
	t.Log("║  Agent tự biết môi trường — quyền tạm thời theo phiên      ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── PART 1: Environment Probe ─────────────────────────────
	t.Log("[ PART 1 ] EnvironmentProbeSkill")

	prober := NewEnvironmentProbeSkill()
	ctx    := &ExecContext{State: make(map[string]interface{})}

	bootMsg := &isl.ISLMessage{MsgType: isl.MsgActivate, Payload: []byte{}}
	r := prober.Execute(ctx, bootMsg)

	t.Logf("  Môi trường: %s", r.Data["env.summary"])
	t.Logf("  Class:      %s", r.Data["env.class"])
	t.Logf("  LeoAI:      %v  |  Vision: %v  |  Actuate: %v  |  Store: %v",
		r.Data["env.can_leoai"],
		r.Data["env.can_perception"],
		r.Data["env.can_actuate"],
		r.Data["env.can_store"])

	info := ctx.State["env.info"].(EnvironmentInfo)
	t.Log()
	t.Log("  Ý nghĩa theo môi trường:")
	switch info.Class {
	case EnvEmbedded:
		t.Log("  → USB drive / MCU: chỉ chạy Actuator Skill, không LeoAI")
	case EnvEdge:
		t.Log("  → Raspberry Pi / Hub: chạy được Perception + Actuator")
	case EnvPersonal:
		t.Log("  → Laptop / Desktop: chạy được tất cả, trừ datacenter workload")
	case EnvDatacenter:
		t.Log("  → Server / Container: full LeoAI + Silk Tree + multi-agent")
	}
	t.Log()

	// ── PART 2: Ephemeral Auth — không có quyền mặc định ─────
	t.Log("[ PART 2 ] EphemeralAuthSkill — Agent không có quyền mặc định")

	authSkill := NewEphemeralAuthSkill("firmware_agent_01")
	aamGrant  := NewAAMGrantSkill()
	authCtx   := &ExecContext{State: make(map[string]interface{})}

	// Agent thử vá firmware KHÔNG có quyền → bị chặn
	t.Log()
	t.Log("  Agent muốn vá firmware:")
	hasPatch := authSkill.HasPermission(ScopeFirmwarePatch)
	t.Logf("  HasPermission(firmware:patch) = %v ← đúng, chưa được cấp", hasPatch)
	if hasPatch { t.Error("✗ Không có quyền nhưng pass") }

	// Step 1: Agent gửi AuthRequest lên AAM
	t.Log()
	t.Log("  → Agent gửi AuthRequest lên AAM:")
	sessionID := "session_" + newTokenID()
	req := AuthRequest{
		AgentID:   "firmware_agent_01",
		SessionID: sessionID,
		Scope:     ScopeFirmwarePatch,
		Reason:    "CVE-2023-38913: Hue Bridge < 1.59 cần update",
		Duration:  "10m",
	}
	reqMsg := &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: encodePayload(req),
	}
	r2 := aamGrant.Execute(authCtx, reqMsg)
	t.Logf("  Risk level: %s", r2.Data["auth.risk"])
	t.Logf("  AAM → User:\n    %s", string(r2.Message.Payload))
	t.Log()

	// Step 2: User xác nhận → AAM cấp token 10 phút
	t.Log("  User: 'xác nhận firmware_agent_01'")
	token := aamGrant.GrantToken(sessionID, 10*time.Minute)
	if token == nil { t.Fatal("✗ GrantToken failed") }
	t.Logf("  Token cấp: %s", token)
	t.Log()

	// Step 3: AAM gửi token xuống Agent
	t.Log("  AAM gửi token xuống Agent:")
	grantPayload, _ := json.Marshal(map[string]interface{}{
		"token":      token,
		"session_id": sessionID,
	})
	grantMsg := &isl.ISLMessage{
		MsgType: isl.MsgActivate,
		Payload: grantPayload,
	}
	r3 := authSkill.Execute(authCtx, grantMsg)
	t.Logf("  Agent nhận: scope=%s ttl=%s", r3.Data["auth.scope"], r3.Data["auth.ttl"])
	t.Log()

	// Step 4: Agent thực hiện trong phiên
	t.Log("  Agent thực hiện trong phiên:")
	hasPatch2 := authSkill.HasPermission(ScopeFirmwarePatch)
	t.Logf("  HasPermission(firmware:patch) = %v ← có quyền rồi", hasPatch2)
	if !hasPatch2 { t.Error("✗ Đã được cấp nhưng không pass") }

	// Quyền chỉ cho scope được cấp — scope khác vẫn không có
	hasWrite := authSkill.HasPermission(ScopeFirmwareWrite)
	t.Logf("  HasPermission(firmware:write) = %v ← đúng, không cấp scope này", hasWrite)
	if hasWrite { t.Error("✗ Write không được cấp nhưng pass") }
	t.Log()

	// Step 5: Phiên kết thúc → thu hồi
	t.Log("  Phiên kết thúc → thu hồi tất cả quyền:")
	revokeMsg := &isl.ISLMessage{
		MsgType: isl.MsgDeactivate,
		Payload: encodePayload(map[string]string{"session_id": sessionID}),
	}
	r4 := authSkill.Execute(authCtx, revokeMsg)
	t.Logf("  Revoked: %d tokens | Active: %d", r4.Data["auth.revoked"], r4.Data["auth.active"])

	// Sau khi thu hồi — không còn quyền
	hasPatch3 := authSkill.HasPermission(ScopeFirmwarePatch)
	t.Logf("  HasPermission(firmware:patch) = %v ← quyền đã bị thu hồi", hasPatch3)
	if hasPatch3 { t.Error("✗ Đã thu hồi nhưng vẫn pass") }
	t.Log()

	// ── PART 3: Kết hợp Env + Auth ───────────────────────────
	t.Log("[ PART 3 ] Kết hợp Environment + Auth")
	t.Log()
	t.Log("  Ví dụ HomeOS trên USB drive cắm vào TV:")
	t.Log("    env.class = embedded → CanRunLeoAI = false")
	t.Log("    Agent tự biết: 'không đủ RAM → không load LeoAI'")
	t.Log("    Agent tự biết: 'đây là edge → tôi là actuator'")
	t.Log()
	t.Log("  Ví dụ HomeOS trên server trung tâm dữ liệu:")
	t.Log("    env.class = datacenter → CanRunLeoAI = true")
	t.Log("    Agent tự biết: 'đây là server → tôi là LeoAI/AAM'")
	t.Log("    Khi user xác nhận → quyền cấp 1h")
	t.Log("    Phiên xong → quyền thu hồi, không lưu")
	t.Log()
	t.Log("  Bảo mật cốt lõi:")
	t.Log("  ✓ Không có quyền mặc định — phải xin")
	t.Log("  ✓ Xin quyền → User thấy risk level + lý do")
	t.Log("  ✓ Token gắn SessionID — không reuse")
	t.Log("  ✓ Phiên xong → tự hủy, không lưu vào Silk Tree")
	t.Log("  ✓ Scope cụ thể — firmware:patch ≠ firmware:write")

	t.Log()
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("  PASS")
}
