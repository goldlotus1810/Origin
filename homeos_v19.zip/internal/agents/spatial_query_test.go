package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestSpatialQuerySkill(t *testing.T) {
	// Setup đầy đủ QT7 pipeline
	ws      := gene.NewWorldScene()
	nodes   := ws.SpatialNodes()
	router  := gene.NewISLRouter(nodes, 8.0)
	addrMap := NewAddrAgentMap()
	bus     := NewMessageBus()

	vc := NewVisionChief("vc_q", 512)
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun),   vc.ID)

	dn := memory.NewShortTerm(256)
	lt := memory.NewLongTerm(silk.NewSilkGraph(), nil)

	learnSkill := NewSpatialLearnSkill(dn, lt)
	querySkill := NewSpatialQuerySkill(dn, lt)

	leoInbox := make(chan *isl.ISLMessage, 256)
	bus.Register("leoai", leoInbox, 2, RoleChief)

	stop := make(chan struct{})
	go vc.Run(stop)
	go func() {
		for {
			select {
			case <-stop: return
			case msg := <-leoInbox:
				learnSkill.Execute(nil, msg)
			}
		}
	}()
	defer close(stop)

	disp    := NewSpatialDispatcher(router, addrMap, bus)
	pl      := NewPerceptLayer(ws, disp)
	pl.AddSensor(SensorPoint{Pos: gene.Vec3{X: 0, Y: 7, Z: 0}, Radius: 5, NSamples: 8})
	flusher := NewDNFlusher(vc, bus, "leoai")
	flusher.FlushThreshold = 5

	t.Log("=== SpatialQuerySkill: LeoAI biết gì về ISLAddr? ===")

	// Phase 1: chưa học gì → miss
	earthAddr := isl.Address{
		Layer: byte(gene.ISL_Earth >> 56),
		Group: byte(gene.ISL_Earth >> 48),
		Type:  byte(gene.ISL_Earth >> 40),
		ID:    byte(gene.ISL_Earth >> 32),
	}
	res0 := querySkill.Query(earthAddr)
	t.Logf("Query trước khi học: source=QR:%v DN:%v", res0.FoundInQR, res0.FoundInDN)
	if res0.FoundInQR || res0.FoundInDN {
		t.Error("chưa học gì → phải miss")
	}

	// Phase 2: tích lũy ĐN
	for i := 0; i < 8; i++ { pl.Tick(0.1) }
	time.Sleep(20 * time.Millisecond)
	flusher.CheckAndFlush()
	time.Sleep(15 * time.Millisecond)

	// Query ĐN
	res1 := querySkill.Query(earthAddr)
	t.Logf("Query sau khi vào ĐN: QR=%v DN=%v conf=%.2f label=%q",
		res1.FoundInQR, res1.FoundInDN, res1.Confidence, res1.Label)
	if res1.FoundInDN {
		t.Logf("  ✓ ĐN: label=%s conf=%.2f fire=%d", res1.Label, res1.Confidence, res1.FireCount)
	}

	// Phase 3: reinforce đủ để vào QR
	for i := 0; i < 12; i++ {
		for j := 0; j < 4; j++ { pl.Tick(0.1) }
		time.Sleep(10 * time.Millisecond)
		flusher.CheckAndFlush()
		time.Sleep(10 * time.Millisecond)
	}

	// Query QR
	res2 := querySkill.Query(earthAddr)
	t.Logf("Query sau khi vào QR: QR=%v DN=%v weight=%d",
		res2.FoundInQR, res2.FoundInDN, res2.Weight)
	if res2.FoundInQR {
		t.Logf("  ✓ QR: label=%s dna=%s weight=%d", res2.Label, res2.DNA, res2.Weight)
	}

	// Stats
	hits, misses := querySkill.Stats()
	recv, comm   := learnSkill.Stats()
	t.Logf("\n── Stats ──")
	t.Logf("  QuerySkill: hits=%d misses=%d", hits, misses)
	t.Logf("  LearnSkill: recv=%d committed=%d", recv, comm)
	t.Logf("  LongTerm(QR): %d entries", lt.Count())
	t.Logf("  ShortTerm(ĐN): %d active", dn.CountActive())

	// ISLAddr bịa đặt → phải miss
	unknown := isl.Address{Layer: 0x99, Group: 0x99, Type: 0x99, ID: 0x99}
	res3 := querySkill.Query(unknown)
	if res3.FoundInQR || res3.FoundInDN {
		t.Error("unknown addr phải miss")
	}
	t.Logf("  Query unknown addr: miss ✓")

	t.Log("\n✓ LeoAI spatial memory:")
	t.Log("  miss → ĐN(đang học) → QR(đã biết)")
}
