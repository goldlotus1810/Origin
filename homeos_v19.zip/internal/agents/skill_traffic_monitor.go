// internal/agents/skill_traffic_monitor.go
//
// TrafficMonitorSkill — Worker giám sát traffic thiết bị
//
// Nguyên tắc (từ TRUTH.md — bất biến):
//   Worker = HomeOS tại thiết bị — KHÔNG phải adapter
//   Mọi traffic ra ngoài LAN phải được HomeOS cho phép
//   Firmware không có quyền tự kết nối cloud
//
// Cách hoạt động:
//   1. Maintain AllowList: IP/domain được phép liên lạc
//      → mặc định: chỉ trong subnet LAN
//      → AAM có thể cấp phép thêm qua MsgApproved
//   2. Mỗi MsgTick → kiểm tra connection table của thiết bị
//      (đọc từ DeviceConfig.IP qua /proc hoặc netstat API)
//   3. Phát hiện kết nối trái phép:
//      → gửi MsgEmergency lên Chief
//      → set IsolationMode = true (chặn mọi outbound)
//   4. Ghi audit log mọi kết nối

package agents

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// TrafficEvent — một sự kiện kết nối được phát hiện
type TrafficEvent struct {
	At          time.Time
	DeviceIP    string
	RemoteIP    string
	RemotePort  int
	Protocol    string // "tcp", "udp"
	Direction   string // "out", "in"
	Allowed     bool
	Reason      string // tại sao allowed/blocked
}

// TrafficRule — quy tắc cho phép/chặn
type TrafficRule struct {
	// Ít nhất 1 field phải match
	RemoteIP     string // exact IP hoặc CIDR, "" = any
	RemotePort   int    // 0 = any
	Protocol     string // "tcp"/"udp"/"any"
	Direction    string // "out"/"in"/"any"
	Allow        bool
	Reason       string
}

func (r TrafficRule) matches(ev TrafficEvent) bool {
	if r.RemoteIP != "" {
		// CIDR check
		if strings.Contains(r.RemoteIP, "/") {
			_, cidr, err := net.ParseCIDR(r.RemoteIP)
			if err == nil && !cidr.Contains(net.ParseIP(ev.RemoteIP)) {
				return false
			}
		} else if r.RemoteIP != ev.RemoteIP {
			return false
		}
	}
	if r.RemotePort != 0 && r.RemotePort != ev.RemotePort { return false }
	if r.Protocol != "" && r.Protocol != "any" && r.Protocol != ev.Protocol { return false }
	if r.Direction != "" && r.Direction != "any" && r.Direction != ev.Direction { return false }
	return true
}

// TrafficMonitorSkill — 1 trách nhiệm: giám sát traffic thiết bị
type TrafficMonitorSkill struct {
	deviceID  string
	deviceIP  string
	lanSubnet string // CIDR của LAN, e.g. "192.168.1.0/24"

	mu           sync.RWMutex
	rules        []TrafficRule
	events       []TrafficEvent // ring buffer cuối 100 events
	isolated     bool           // isolation mode
	violationCount int

	// Callbacks
	onViolation func(ev TrafficEvent) // gọi khi phát hiện vi phạm
}

func NewTrafficMonitorSkill(deviceID, deviceIP string) *TrafficMonitorSkill {
	s := &TrafficMonitorSkill{
		deviceID: deviceID,
		deviceIP: deviceIP,
	}
	s.buildDefaultRules(deviceIP)
	return s
}

// WithLAN set LAN subnet và rebuild rules
func (s *TrafficMonitorSkill) WithLAN(cidr string) *TrafficMonitorSkill {
	s.lanSubnet = cidr
	// Rebuild rules với subnet mới
	subnet := cidr
	s.rules = []TrafficRule{
		{RemoteIP: "127.0.0.1", Protocol: "any", Direction: "any",
			Allow: true, Reason: "loopback — HomeOS internal"},
		{RemoteIP: subnet, Protocol: "any", Direction: "any",
			Allow: true, Reason: "LAN — HomeOS peers"},
		{RemotePort: 53, Protocol: "udp", Direction: "out",
			Allow: true, Reason: "DNS lookup"},
		{RemotePort: 123, Protocol: "udp", Direction: "out",
			Allow: true, Reason: "NTP time sync"},
		{Protocol: "any", Direction: "any",
			Allow: false, Reason: "default deny — not authorized by HomeOS"},
	}
	return s
}

// WithViolationCallback set callback khi phát hiện vi phạm
func (s *TrafficMonitorSkill) WithViolationCallback(fn func(TrafficEvent)) *TrafficMonitorSkill {
	s.onViolation = fn
	return s
}

func (s *TrafficMonitorSkill) Name() string { return "traffic_monitor:" + s.deviceID }

func (s *TrafficMonitorSkill) CanHandle(msg *isl.ISLMessage) bool {
	switch msg.MsgType {
	case isl.MsgTick:      return true  // kiểm tra định kỳ
	case isl.MsgApproved:  return true  // AAM cấp phép thêm rule
	case isl.MsgQuery:     return true  // query trạng thái traffic
	}
	return false
}

func (s *TrafficMonitorSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	switch msg.MsgType {
	case isl.MsgTick:
		return s.checkTraffic()
	case isl.MsgApproved:
		return s.handleNewRule(msg)
	case isl.MsgQuery:
		return s.handleQuery()
	}
	return SkillResult{}
}

// checkTraffic kiểm tra connection table hiện tại của thiết bị
// Trong production: đọc từ /proc/net/tcp hoặc netstat API của thiết bị
// Hiện tại: kiểm tra các kết nối đang active từ DeviceIP
func (s *TrafficMonitorSkill) checkTraffic() SkillResult {
	if s.deviceIP == "" {
		return SkillResult{}
	}

	// Lấy connections của thiết bị từ ARP/netstat
	conns := s.scanDeviceConnections()
	violations := []TrafficEvent{}

	for _, conn := range conns {
		allowed, reason := s.evaluate(conn)
		conn.Allowed = allowed
		conn.Reason = reason

		s.addEvent(conn)

		if !allowed {
			violations = append(violations, conn)
			s.mu.Lock()
			s.violationCount++
			s.mu.Unlock()

			log.Printf("🚨 TrafficMonitor [%s]: BLOCKED %s→%s:%d (%s)",
				s.deviceID, conn.DeviceIP, conn.RemoteIP, conn.RemotePort, reason)

			if s.onViolation != nil {
				go s.onViolation(conn)
			}
		}
	}

	// Nếu có violation nghiêm trọng (cloud upload) → isolate
	for _, v := range violations {
		if s.isCritical(v) {
			s.mu.Lock()
			s.isolated = true
			s.mu.Unlock()
			log.Printf("🔒 TrafficMonitor [%s]: ISOLATED — critical violation", s.deviceID)
			return s.reportIsolation(v)
		}
	}

	data := map[string]interface{}{
		"device":          s.deviceID,
		"connections":     len(conns),
		"violations":      len(violations),
		"isolated":        s.isolated,
		"violation_total": s.violationCount,
	}

	if len(violations) > 0 {
		return SkillResult{
			Data: data,
			Message: &isl.ISLMessage{
				MsgType: isl.MsgPropose,
				Payload: encodePayload(map[string]interface{}{
					"type":       "traffic_violation",
					"device":     s.deviceID,
					"violations": violations,
				}),
			},
		}
	}

	return SkillResult{Data: data}
}

// scanDeviceConnections đọc connections của thiết bị
// Dùng /proc/net/tcp để lấy connections đang active trên host này
// Trong edge deployment: gọi API của thiết bị hoặc dùng eBPF
func (s *TrafficMonitorSkill) scanDeviceConnections() []TrafficEvent {
	// Đọc connections từ hệ thống local (khi Worker chạy trên same host)
	conns := readProcNetTCP()
	var result []TrafficEvent

	for _, c := range conns {
		// Chỉ quan tâm connections từ/đến deviceIP
		if c.LocalIP == s.deviceIP || c.RemoteIP == s.deviceIP {
			result = append(result, TrafficEvent{
				At:         time.Now(),
				DeviceIP:   s.deviceIP,
				RemoteIP:   c.RemoteIP,
				RemotePort: c.RemotePort,
				Protocol:   "tcp",
				Direction:  "out",
			})
		}
	}
	return result
}

// evaluate kiểm tra 1 traffic event theo rules
// Rules được evaluate theo thứ tự — first match wins
func (s *TrafficMonitorSkill) evaluate(ev TrafficEvent) (allowed bool, reason string) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	for _, rule := range s.rules {
		if rule.matches(ev) {
			return rule.Allow, rule.Reason
		}
	}
	// Default: deny nếu không match rule nào
	return false, "no matching rule — default deny"
}

// isCritical: vi phạm nghiêm trọng cần isolate ngay
func (s *TrafficMonitorSkill) isCritical(ev TrafficEvent) bool {
	// Kết nối ra internet (không phải LAN)
	if !s.isLAN(ev.RemoteIP) {
		return true
	}
	// Port 443/80 ra ngoài subnet = nghi ngờ cloud upload
	if ev.Direction == "out" && !s.isLAN(ev.RemoteIP) &&
		(ev.RemotePort == 443 || ev.RemotePort == 80) {
		return true
	}
	return false
}

func (s *TrafficMonitorSkill) isLAN(ip string) bool {
	if s.lanSubnet == "" { return isPrivateIP(ip) }
	_, cidr, err := net.ParseCIDR(s.lanSubnet)
	if err != nil { return isPrivateIP(ip) }
	return cidr.Contains(net.ParseIP(ip))
}

// handleNewRule: AAM cấp phép thêm rule
// Ví dụ: AAM cho phép firmware Hue update từ Philips server
func (s *TrafficMonitorSkill) handleNewRule(msg *isl.ISLMessage) SkillResult {
	var rule TrafficRule
	if err := decodePayload(msg.Payload, &rule); err != nil {
		return SkillResult{}
	}
	s.mu.Lock()
	// Insert vào đầu (priority cao hơn)
	s.rules = append([]TrafficRule{rule}, s.rules...)
	// Nếu AAM approve → có thể bỏ isolation
	if rule.Allow && s.isolated {
		s.isolated = false
		log.Printf("🔓 TrafficMonitor [%s]: isolation lifted by AAM", s.deviceID)
	}
	s.mu.Unlock()

	log.Printf("✅ TrafficMonitor [%s]: new rule added — %s", s.deviceID, rule.Reason)
	return SkillResult{
		Data: map[string]interface{}{"rule_added": rule.Reason},
	}
}

func (s *TrafficMonitorSkill) handleQuery() SkillResult {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return SkillResult{
		Data: map[string]interface{}{
			"device":     s.deviceID,
			"isolated":   s.isolated,
			"rules":      len(s.rules),
			"events":     len(s.events),
			"violations": s.violationCount,
		},
	}
}

func (s *TrafficMonitorSkill) reportIsolation(trigger TrafficEvent) SkillResult {
	payload, _ := json.Marshal(map[string]interface{}{
		"type":    "device_isolated",
		"device":  s.deviceID,
		"trigger": trigger,
		"reason":  "critical traffic violation — possible data exfiltration",
	})
	return SkillResult{
		Data: map[string]interface{}{
			"isolated": true,
			"device":   s.deviceID,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgEmergency,
			Payload: payload,
		},
	}
}

// buildDefaultRules tạo ruleset mặc định cho thiết bị
// Default policy: allow LAN only, deny everything else
func (s *TrafficMonitorSkill) buildDefaultRules(deviceIP string) {
	subnet := detectLANSubnet(deviceIP)
	s.lanSubnet = subnet

	s.rules = []TrafficRule{
		// Allow ISL bus (HomeOS internal — loopback)
		{RemoteIP: "127.0.0.1", Protocol: "any", Direction: "any",
			Allow: true, Reason: "loopback — HomeOS internal"},

		// Allow LAN subnet (Chief, AAM trên cùng mạng)
		{RemoteIP: subnet, Protocol: "any", Direction: "any",
			Allow: true, Reason: "LAN — HomeOS peers"},

		// Allow DNS (port 53) — cần để resolve hostnames
		{RemotePort: 53, Protocol: "udp", Direction: "out",
			Allow: true, Reason: "DNS lookup"},

		// Allow NTP (port 123) — đồng bộ thời gian
		{RemotePort: 123, Protocol: "udp", Direction: "out",
			Allow: true, Reason: "NTP time sync"},

		// DENY tất cả còn lại
		{Protocol: "any", Direction: "any",
			Allow: false, Reason: "default deny — not authorized by HomeOS"},
	}
}

func (s *TrafficMonitorSkill) addEvent(ev TrafficEvent) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.events) >= 100 {
		s.events = s.events[1:] // drop oldest
	}
	s.events = append(s.events, ev)
}

// IsIsolated trả về trạng thái isolation hiện tại
func (s *TrafficMonitorSkill) IsIsolated() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.isolated
}

// ─── /proc/net/tcp reader ───────────────────────────────────────

type tcpConn struct {
	LocalIP    string
	LocalPort  int
	RemoteIP   string
	RemotePort int
	State      string
}

// readProcNetTCP đọc connections từ /proc/net/tcp (Linux)
func readProcNetTCP() []tcpConn {
	// Đây là implementation cho khi Worker chạy trên Linux host
	// Trong edge deployment (Worker chạy trên thiết bị): thay bằng
	// device-specific API hoặc eBPF probe
	return parseProcNetFile("/proc/net/tcp")
}

func parseProcNetFile(path string) []tcpConn {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var result []tcpConn
	lines := strings.Split(string(data), "\n")
	for _, line := range lines[1:] {
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		localIP, localPort, err1 := parseHexAddr(fields[1])
		remoteIP, remotePort, err2 := parseHexAddr(fields[2])
		state := fields[3]
		if err1 != nil || err2 != nil {
			continue
		}
		// Chỉ lấy ESTABLISHED (01) và SYN_SENT (02)
		if state != "01" && state != "02" {
			continue
		}
		result = append(result, tcpConn{
			LocalIP:    localIP,
			LocalPort:  localPort,
			RemoteIP:   remoteIP,
			RemotePort: remotePort,
			State:      state,
		})
	}
	return result
}

// parseHexAddr: "0101007F:0050" → "127.0.1.1", 80
// /proc/net/tcp: IP little-endian, port big-endian
func parseHexAddr(s string) (ip string, port int, err error) {
	parts := strings.SplitN(s, ":", 2)
	if len(parts) != 2 {
		return "", 0, fmt.Errorf("bad addr: %s", s)
	}
	if len(parts[0]) != 8 {
		return "", 0, fmt.Errorf("bad ip hex: %s", parts[0])
	}
	var b [4]byte
	for i := 0; i < 4; i++ {
		var v uint64
		v, err = strconv.ParseUint(parts[0][i*2:i*2+2], 16, 8)
		if err != nil {
			return "", 0, err
		}
		b[3-i] = byte(v)
	}
	ip = fmt.Sprintf("%d.%d.%d.%d", b[0], b[1], b[2], b[3])
	portVal, err := strconv.ParseUint(parts[1], 16, 16)
	if err != nil {
		return "", 0, err
	}
	port = int(portVal)
	return ip, port, nil
}

// ─── Helpers ───────────────────────────────────────────────────

// detectLANSubnet tìm subnet của interface hiện tại
func detectLANSubnet(deviceIP string) string {
	if deviceIP == "" { return "192.168.0.0/16" }

	ifaces, err := net.Interfaces()
	if err != nil { return "192.168.0.0/16" }

	for _, iface := range ifaces {
		if iface.Flags&net.FlagLoopback != 0 { continue }
		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok && ipnet.IP.To4() != nil {
				// Check nếu deviceIP nằm trong subnet này
				if ipnet.Contains(net.ParseIP(deviceIP)) {
					return ipnet.String()
				}
				// Trả về subnet đầu tiên không phải loopback
				return ipnet.String()
			}
		}
	}
	return "192.168.0.0/16"
}

// isPrivateIP kiểm tra IP có phải địa chỉ private không
func isPrivateIP(ipStr string) bool {
	ip := net.ParseIP(ipStr)
	if ip == nil { return false }
	for _, cidr := range []string{
		"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8",
	} {
		_, network, _ := net.ParseCIDR(cidr)
		if network.Contains(ip) { return true }
	}
	return false
}

// TrafficReport snapshot cho audit
type TrafficReport struct {
	DeviceID        string         `json:"device_id"`
	DeviceIP        string         `json:"device_ip"`
	Isolated        bool           `json:"isolated"`
	ViolationCount  int            `json:"violation_count"`
	RecentEvents    []TrafficEvent `json:"recent_events"`
	Rules           []TrafficRule  `json:"rules"`
	GeneratedAt     time.Time      `json:"generated_at"`
}

func (s *TrafficMonitorSkill) Report() TrafficReport {
	s.mu.RLock()
	defer s.mu.RUnlock()
	events := make([]TrafficEvent, len(s.events))
	copy(events, s.events)
	rules := make([]TrafficRule, len(s.rules))
	copy(rules, s.rules)
	return TrafficReport{
		DeviceID:       s.deviceID,
		DeviceIP:       s.deviceIP,
		Isolated:       s.isolated,
		ViolationCount: s.violationCount,
		RecentEvents:   events,
		Rules:          rules,
		GeneratedAt:    time.Now(),
	}
}

// TrafficSummary tóm tắt ngắn gọn cho UI
func (s *TrafficMonitorSkill) Summary() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	status := "✅ normal"
	if s.isolated { status = "🔒 ISOLATED" }
	return fmt.Sprintf("[%s] %s · %d violations · %d events",
		s.deviceID, status, s.violationCount, len(s.events))
}
