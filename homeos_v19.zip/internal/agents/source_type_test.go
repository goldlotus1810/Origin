package agents

import (
	"testing"
)

func TestEpistemicFirewall(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  EPISTEMIC FIREWALL                                          ║")
	t.Log("║  FACT vs FICTION + DoubleConfirm                             ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── Test 1: CanPromoteQR ─────────────────────────────────────
	t.Log("[ FACT vs FICTION → QR promotion ]")
	cases := []struct{ s Source; can bool }{
		{SourceRealNow,   true},
		{SourceRealPast,  true},
		{SourceRealOther, true},
		{SourceFiction,   false}, // GWTW, Harry Potter...
		{SourceMusic,     false}, // nhạc
		{SourceMemory,    false}, // ký ức mix
	}
	for _, c := range cases {
		got := CanPromoteQR(c.s)
		mark := "✓"
		if got != c.can { mark = "✗"; t.Errorf("CanPromoteQR(%s)=%v want %v", c.s, got, c.can) }
		t.Logf("  %s %-15s CanPromoteQR=%v  weight=%.2f", mark, c.s, got, QRWeight(c.s))
	}

	t.Log()
	t.Log("[ BookMemory với SourceType ]")
	// FACT book
	factBook := NewBookMemoryTyped("Lịch sử Việt Nam", SourceRealPast)
	factBook.ReadParagraph("Chiến tranh Việt Nam kết thúc năm 1975 sau nhiều năm đau khổ và mất mát.")
	t.Logf("  FACT book '%s': CanPromoteQR=%v", factBook.Source, CanPromoteQR(factBook.SourceType))

	// FICTION book
	fictionBook := NewBookMemoryTyped("cuốn theo chiều gió", SourceFiction)
	fictionBook.ReadParagraph("Atlanta rực lửa, chiến tranh tàn phá mọi thứ.")
	t.Logf("  FICTION book '%s': CanPromoteQR=%v", fictionBook.Source, CanPromoteQR(fictionBook.SourceType))

	// ── Test 2: DoubleConfirm ────────────────────────────────────
	t.Log()
	t.Log("[ DOUBLE CONFIRM — xác nhận 2 lần ]")
	gate := NewConfirmGate()

	// Lệnh nguy hiểm
	level, reason := ClassifyIntent("xóa toàn bộ dữ liệu")
	t.Logf("  'xóa toàn bộ dữ liệu' → level=%d reason=%s", level, reason)

	msg := gate.Request("xóa toàn bộ dữ liệu", "Mất hết Silk Tree không khôi phục được", ConfirmDouble)
	t.Logf("  Request: %s", msg)

	// "ừ" không đủ
	ok, reply := gate.Confirm("ừ")
	t.Logf("  Confirm('ừ') → ok=%v reply=%q", ok, reply)
	if ok { t.Error("'ừ' không được phép xác nhận!") } else { t.Log("  ✓ 'ừ' bị từ chối") }

	// "ok" không đủ
	ok, reply = gate.Confirm("ok")
	t.Logf("  Confirm('ok') → ok=%v reply=%q", ok, reply)
	if ok { t.Error("'ok' không được phép xác nhận!") } else { t.Log("  ✓ 'ok' bị từ chối") }

	// Lần 1 đúng cách
	ok, reply = gate.Confirm("xác nhận xóa toàn bộ dữ liệu")
	t.Logf("  Confirm lần 1: ok=%v", ok)
	t.Logf("  → %s", reply)
	if ok { t.Error("Lần 1 chưa được thực thi!") } else { t.Log("  ✓ Lần 1 đúng — chờ lần 2") }

	// Lần 2
	ok, reply = gate.Confirm("xác nhận xóa toàn bộ dữ liệu")
	t.Logf("  Confirm lần 2: ok=%v", ok)
	t.Logf("  → %s", reply)
	if !ok { t.Error("Lần 2 phải được thực thi!") } else { t.Log("  ✓ Lần 2 → thực thi") }

	// Blocked hoàn toàn
	t.Log()
	blockedMsg := gate.Request("xóa tất cả", "không thể hoàn tác", ConfirmBlocked)
	t.Logf("  BLOCKED: %s", blockedMsg)

	t.Log()
	t.Log("[ KẾT LUẬN ]")
	t.Log("  FICTION → không bao giờ lên QR dù conf=0.99")
	t.Log("  'ừ'/'ok' → không đủ xác nhận lệnh nguy hiểm")
	t.Log("  Double confirm → phải gõ 'xác nhận [action]' 2 lần")
	t.Log("  Blocked → không ai confirm được dù 100 lần")
}
