// internal/agents/skill_actuator_hvac.go
//
// ActuatorHvacSkill — điều hòa nhiệt độ (Edge)
//
// RAM: ~64KB
// Nhận: MsgActuatorCmd (từ HomeChief)
// Thực thi: set nhiệt độ, bật/tắt, chế độ cool/heat/fan
// Offline: chạy theo TempProfile học từ LeoAI
//
// TempProfile: LeoAI gửi PacketTempProfile xuống
//   [{"hour":7,"temp_c":24.0},{"hour":22,"temp_c":22.0}]

package agents

import (
	"encoding/json"
	"fmt"
	"math"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type HvacMode string

const (
	HvacOff  HvacMode = "off"
	HvacCool HvacMode = "cool"
	HvacHeat HvacMode = "heat"
	HvacFan  HvacMode = "fan"
	HvacAuto HvacMode = "auto"
)

type TempEntry struct {
	Hour   int     `json:"hour"`
	TempC  float64 `json:"temp_c"`
	Action string  `json:"action,omitempty"`
}

type HvacState struct {
	Mode      HvacMode
	SetPoint  float64   // nhiệt độ đặt (°C)
	CurrentC  float64   // nhiệt độ hiện tại (giả lập)
	FanSpeed  int       // 0-100%
	On        bool
	UpdatedAt time.Time
	Reason    string
}

type ActuatorHvacSkill struct {
	deviceID  string
	location  gene.SpaceType

	state   HvacState
	profile []TempEntry // học từ LeoAI
}

func NewActuatorHvacSkill(deviceID string, location gene.SpaceType) *ActuatorHvacSkill {
	return &ActuatorHvacSkill{
		deviceID: deviceID,
		location: location,
		state: HvacState{
			Mode:     HvacOff,
			SetPoint: 25.0,
			CurrentC: 28.0, // giả lập nhiệt độ phòng ban đầu
			FanSpeed: 0,
			On:       false,
			Reason:   "init",
		},
	}
}

func (s *ActuatorHvacSkill) Name() string { return "actuator_hvac:" + s.deviceID }

func (s *ActuatorHvacSkill) CanHandle(msg *isl.ISLMessage) bool {
	switch msg.MsgType {
	case isl.MsgActuatorCmd:
		return true
	case isl.MsgSync: // LearnPacket từ LeoAI
		return true
	case isl.MsgTick: // cập nhật nhiệt độ giả lập
		return s.state.On
	}
	return false
}

func (s *ActuatorHvacSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	switch msg.MsgType {
	case isl.MsgActuatorCmd:
		return s.handleCmd(ctx, msg)
	case isl.MsgSync:
		return s.handleLearnPacket(ctx, msg)
	case isl.MsgTick:
		return s.handleTick(ctx)
	}
	return SkillResult{}
}

// handleCmd — nhận lệnh từ HomeChief
func (s *ActuatorHvacSkill) handleCmd(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	body := string(msg.Payload)
	prev := s.state

	// Parse: "hvac:cool:24" / "hvac:off" / "hvac:heat:20" / "hvac:fan:50"
	parts := splitCmd(body, ":")
	if len(parts) == 0 {
		return SkillResult{}
	}

	var temp float64
	var fan int

	if len(parts) >= 3 {
		fmt.Sscanf(parts[2], "%f", &temp)
	}
	if len(parts) >= 3 {
		fmt.Sscanf(parts[2], "%d", &fan)
	}

	switch HvacMode(parts[1]) {
	case HvacOff:
		s.state.On = false
		s.state.Mode = HvacOff
		s.state.FanSpeed = 0
		s.state.Reason = "cmd:off"
	case HvacCool, HvacHeat, HvacAuto:
		s.state.Mode = HvacMode(parts[1])
		s.state.On = true
		if temp > 0 { s.state.SetPoint = temp }
		s.state.FanSpeed = 70
		s.state.Reason = fmt.Sprintf("cmd:%s:%.1f", parts[1], s.state.SetPoint)
	case HvacFan:
		s.state.Mode = HvacFan
		s.state.On = fan > 0
		s.state.FanSpeed = fan
		s.state.Reason = fmt.Sprintf("cmd:fan:%d%%", fan)
	default:
		// "set_temp:24.5"
		fmt.Sscanf(body, "set_temp:%f", &temp)
		if temp > 0 {
			s.state.SetPoint = temp
			s.state.On = true
			s.state.Mode = HvacAuto
			s.state.Reason = "cmd:set_temp"
		}
	}

	s.state.UpdatedAt = time.Now()
	s.storeState(ctx)

	fmt.Printf("[HVAC:%s] %s→%s set=%.1f°C fan=%d%% (was: mode=%s)\n",
		s.deviceID, prev.Mode, s.state.Mode, s.state.SetPoint, s.state.FanSpeed, prev.Mode)

	return SkillResult{Data: s.stateMap()}
}

// handleLearnPacket — nhận TempProfile từ LeoAI
func (s *ActuatorHvacSkill) handleLearnPacket(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var pkts []LearnPacket
	if err := json.Unmarshal(msg.Payload, &pkts); err != nil {
		return SkillResult{}
	}
	for _, pkt := range pkts {
		if pkt.Type != PacketTempProfile { continue }
		var data map[string]interface{}
		if err := json.Unmarshal(pkt.Payload, &data); err != nil { continue }

		hour, _ := data["hour"].(float64)
		temp, _  := data["temp_c"].(float64)
		action, _ := data["action"].(string)
		if temp > 0 {
			s.profile = append(s.profile, TempEntry{
				Hour:  int(hour),
				TempC: temp,
				Action: action,
			})
		}
	}

	// Áp dụng profile giờ hiện tại ngay
	if entry := s.profileForNow(); entry != nil {
		s.state.SetPoint = entry.TempC
		s.state.On = true
		s.state.Mode = s.autoMode(entry.TempC)
		s.state.Reason = fmt.Sprintf("learn:hour%d", entry.Hour)
		fmt.Printf("[HVAC:%s] LearnPacket: hour=%d → %.1f°C (%s)\n",
			s.deviceID, entry.Hour, entry.TempC, s.state.Mode)
	}

	s.storeState(ctx)
	return SkillResult{Data: map[string]interface{}{
		"hvac.profile_len": len(s.profile),
		"hvac.setpoint":    s.state.SetPoint,
	}}
}

// handleTick — giả lập nhiệt độ tiến về setpoint
func (s *ActuatorHvacSkill) handleTick(ctx *ExecContext) SkillResult {
	if !s.state.On { return SkillResult{} }

	diff := s.state.SetPoint - s.state.CurrentC
	// Mỗi tick tiến ~0.5°C về setpoint
	step := math.Min(math.Abs(diff), 0.5)
	if diff > 0 {
		s.state.CurrentC += step
	} else if diff < 0 {
		s.state.CurrentC -= step
	}

	s.storeState(ctx)
	return SkillResult{Data: s.stateMap()}
}

func (s *ActuatorHvacSkill) profileForNow() *TempEntry {
	if len(s.profile) == 0 { return nil }
	h := time.Now().Hour()
	var best *TempEntry
	bestDiff := 25
	for i := range s.profile {
		d := h - s.profile[i].Hour
		if d < 0 { d = -d }
		if d < bestDiff { bestDiff = d; best = &s.profile[i] }
	}
	return best
}

func (s *ActuatorHvacSkill) autoMode(setPoint float64) HvacMode {
	if setPoint < s.state.CurrentC { return HvacCool }
	if setPoint > s.state.CurrentC { return HvacHeat }
	return HvacFan
}

func (s *ActuatorHvacSkill) storeState(ctx *ExecContext) {
	ctx.State["hvac.mode"]      = string(s.state.Mode)
	ctx.State["hvac.setpoint"]  = s.state.SetPoint
	ctx.State["hvac.current_c"] = s.state.CurrentC
	ctx.State["hvac.fan"]       = s.state.FanSpeed
	ctx.State["hvac.on"]        = s.state.On
	ctx.State["hvac.reason"]    = s.state.Reason
}

func (s *ActuatorHvacSkill) stateMap() map[string]interface{} {
	return map[string]interface{}{
		"hvac.mode":      string(s.state.Mode),
		"hvac.setpoint":  s.state.SetPoint,
		"hvac.current_c": s.state.CurrentC,
		"hvac.fan":       s.state.FanSpeed,
		"hvac.on":        s.state.On,
	}
}

// Status — human-readable
func (s *ActuatorHvacSkill) Status() string {
	if !s.state.On {
		return fmt.Sprintf("[HVAC:%s] OFF", s.deviceID)
	}
	return fmt.Sprintf("[HVAC:%s] %s %.1f°C (hiện %.1f°C) fan=%d%%",
		s.deviceID, s.state.Mode, s.state.SetPoint, s.state.CurrentC, s.state.FanSpeed)
}

// splitCmd tách chuỗi theo sep, bỏ phần tử rỗng
func splitCmd(s, sep string) []string {
	var parts []string
	start := 0
	for i := 0; i <= len(s); i++ {
		if i == len(s) || s[i:i+len(sep)] == sep {
			if p := s[start:i]; p != "" {
				parts = append(parts, p)
			}
			start = i + len(sep)
		}
	}
	return parts
}
