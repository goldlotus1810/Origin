// internal/agents/percept_layer_hot.go
// PerceptLayerHot — PerceptLayer thread-safe dùng HotReloadRouter
//
// Khác với PerceptLayer cũ:
//   - Dùng SpatialDispatcherHot thay SpatialDispatcher
//   - HotReloadRouter.Reload() mỗi tick → atomic, không race
//   - OnCreatureAdd(c): WorldScene.AddCreature + Reload ngay lập tức
//   - LabelIndex tự Invalidate khi có node mới
//   - Stats() trả về thêm router version
package agents

import (
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// PerceptLayerHot — phiên bản thread-safe của PerceptLayer
type PerceptLayerHot struct {
	World      *gene.WorldScene
	Dispatcher *SpatialDispatcherHot
	Router     *HotReloadRouter
	Labels     *AddrLabelIndex
	Sensors    []SensorPoint
	MinTickMs  int64

	tickCount   uint64
	lastVersion uint64 // router version lần tick trước
}

// NewPerceptLayerHot tạo PerceptLayerHot
// graph có thể nil nếu chưa load olang
func NewPerceptLayerHot(
	world *gene.WorldScene,
	addrMap *AddrAgentMap,
	bus *MessageBus,
	graph *silk.SilkGraph,
) *PerceptLayerHot {
	nodes := world.SpatialNodes()
	rr    := NewHotReloadRouter(nodes, 8.0)
	disp  := NewSpatialDispatcherHot(rr, addrMap, bus)
	lbls  := NewAddrLabelIndex(rr, graph)

	// Invalidate label cache khi router có node mới
	rr.OnUpdate = func(evt RouterUpdateEvent) {
		lbls.Invalidate()
	}

	return &PerceptLayerHot{
		World:      world,
		Dispatcher: disp,
		Router:     rr,
		Labels:     lbls,
		MinTickMs:  50,
	}
}

// AddSensor thêm sensor point
func (pl *PerceptLayerHot) AddSensor(s SensorPoint) {
	if s.NSamples == 0 { s.NSamples = 8 }
	if s.Radius == 0   { s.Radius = 2.0 }
	pl.Sensors = append(pl.Sensors, s)
}

// AddCreature thêm creature vào WorldScene + reload router ngay
// Thread-safe — có thể gọi từ bất kỳ goroutine nào
func (pl *PerceptLayerHot) AddCreature(c *gene.CreatureGene) {
	pl.World.AddCreature(c)
	pl.Router.Reload(pl.World.SpatialNodes())
}

// RemoveCreature xóa creature khỏi WorldScene + reload router
func (pl *PerceptLayerHot) RemoveCreature(addr uint64) bool {
	ok := pl.World.RemoveCreature(addr)
	if ok { pl.Router.Reload(pl.World.SpatialNodes()) }
	return ok
}

// HotTickResult kết quả 1 tick với thông tin router
type HotTickResult struct {
	TickN         uint64
	Dt            float64
	Dispatched    map[string]int
	TotalMsgs     int
	RouterVersion uint64
	NodesAdded    int // nodes mới kể từ tick trước
}

// Tick thực hiện 1 chu kỳ nhận thức
// Thread-safe — Reload dùng RWMutex
func (pl *PerceptLayerHot) Tick(dt float64) HotTickResult {
	pl.tickCount++

	// Cập nhật vật lý
	pl.World.Tick(dt)

	// Hot-reload router với nodes mới nhất (atomic)
	newNodes := pl.World.SpatialNodes()
	added    := pl.Router.Reload(newNodes)
	version  := pl.Router.Version()

	res := HotTickResult{
		TickN:         pl.tickCount,
		Dt:            dt,
		Dispatched:    make(map[string]int),
		RouterVersion: version,
		NodesAdded:    added,
	}

	// Mỗi sensor → probe ring → dispatch
	for _, sensor := range pl.Sensors {
		probes := gene.ProbeRing(sensor.Pos, sensor.Radius, sensor.NSamples)
		counts := pl.Dispatcher.DispatchBatch(probes, isl.MsgQuery)
		for agentID, n := range counts {
			res.Dispatched[agentID] += n
			res.TotalMsgs += n
		}
	}

	pl.lastVersion = version
	return res
}

// Run vòng lặp liên tục với ticker
func (pl *PerceptLayerHot) Run(stop <-chan struct{}, tickDt float64) {
	interval := time.Duration(pl.MinTickMs) * time.Millisecond
	ticker   := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-stop:
			return
		case <-ticker.C:
			pl.Tick(tickDt)
		}
	}
}

// LabeledDominant trả về label của node dominant + count
// Dùng cho LeoAI: "Tôi đang quan sát earth × 128 lần"
func (pl *PerceptLayerHot) LabeledDominant(sensors []SensorPoint) (label string, count int) {
	var allProbes []gene.Vec3
	for _, s := range sensors {
		allProbes = append(allProbes, gene.ProbeRing(s.Pos, s.Radius, s.NSamples)...)
	}
	if len(allProbes) == 0 { return "none", 0 }
	addr, cnt := pl.Dispatcher.Dominant(allProbes)
	if cnt == 0 { return "none", 0 }
	lbl := pl.Labels.LabelU64(addr)
	return lbl, cnt
}

// Stats trả về thống kê
func (pl *PerceptLayerHot) Stats() (ticks uint64, nodes int, version uint64) {
	return pl.tickCount, pl.Router.Len(), pl.Router.Version()
}
