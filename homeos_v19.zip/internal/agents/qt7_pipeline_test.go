package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// TestQT7Pipeline — pipeline đầy đủ từ SDF đến LongTerm memory
//
// vSDF.Eval(probe)
//   → ISLAddr → Bus → VisionChief.mem (ĐN)
//   → DNFlusher → MsgKnowledge → LeoAI
//   → SpatialLearnSkill → ShortTerm.Observe
//   → (confirm/reinforce) → LongTerm.Commit (QR)
func TestQT7Pipeline(t *testing.T) {
	// ── Setup world + router ──────────────────────────────────────────
	ws      := gene.NewWorldScene()
	ws.Clock.HourOfDay = 12.0
	nodes   := ws.SpatialNodes()
	router  := gene.NewISLRouter(nodes, 8.0)
	addrMap := NewAddrAgentMap()
	bus     := NewMessageBus()

	// ── VisionChief ───────────────────────────────────────────────────
	vc := NewVisionChief("vc_qt7", 512)
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun),   vc.ID)

	// ── LeoAI mock: SpatialLearnSkill + shortterm/longterm ───────────
	dn := memory.NewShortTerm(256)
	lt := memory.NewLongTerm(silk.NewSilkGraph(), nil)

	leoSkill := NewSpatialLearnSkill(dn, lt)

	// LeoAI inbox — chạy goroutine xử lý message
	leoInbox := make(chan *isl.ISLMessage, 128)
	bus.Register("leoai", leoInbox, 2, RoleChief)

	stop := make(chan struct{})
	// LeoAI goroutine
	go func() {
		for {
			select {
			case <-stop:
				return
			case msg := <-leoInbox:
				leoSkill.Execute(nil, msg)
			}
		}
	}()

	// ── PerceptLayer ──────────────────────────────────────────────────
	disp := NewSpatialDispatcher(router, addrMap, bus)
	pl   := NewPerceptLayer(ws, disp)
	pl.AddSensor(SensorPoint{
		ID:       "sensor_earth",
		Pos:      gene.Vec3{X: 0, Y: 7, Z: 0}, // bên trong Earth r=12
		Radius:   5.0,
		NSamples: 8,
	})

	// ── DNFlusher ─────────────────────────────────────────────────────
	flusher := NewDNFlusher(vc, bus, "leoai")
	flusher.FlushThreshold = 8 // flush khi đủ 8 observations

	// ── Start goroutines ──────────────────────────────────────────────
	go vc.Run(stop)
	defer close(stop)

	t.Log("=== QT7 Pipeline: vSDF → ĐN → KnowledgeProposal → LongTerm ===")

	// ── Phase 1: Tích lũy ĐN ─────────────────────────────────────────
	t.Log("\nPhase 1: PerceptLayer tích lũy observations vào VisionChief.mem")
	for i := 0; i < 6; i++ {
		r := pl.Tick(0.1)
		t.Logf("  Tick %d: %d msgs", r.TickN, r.TotalMsgs)
	}
	time.Sleep(20 * time.Millisecond)

	dom, cnt := vc.Dominant()
	t.Logf("  VisionChief dominant: %016x × %d", dom, cnt)
	insideCnt := vc.InsideCount(dom)
	t.Logf("  InsideCount: %d/%d (ratio=%.2f)",
		insideCnt, cnt, float64(insideCnt)/float64(cnt))

	// ── Phase 2: DNFlusher → MsgKnowledge ────────────────────────────
	t.Log("\nPhase 2: DNFlusher.CheckAndFlush → MsgKnowledge → LeoAI")
	proposal := flusher.CheckAndFlush()
	if proposal == nil {
		// thêm ticks nếu chưa đủ
		for i := 0; i < 4; i++ { pl.Tick(0.1) }
		time.Sleep(20 * time.Millisecond)
		proposal = flusher.CheckAndFlush()
	}
	if proposal == nil {
		t.Fatal("DNFlusher không tạo được proposal")
	}
	t.Logf("  Proposal: %s", proposal.Summary)
	t.Logf("  Evidence=%d InsideRatio=%.2f", proposal.Evidence, proposal.InsideRatio)

	// Đợi LeoAI xử lý
	time.Sleep(20 * time.Millisecond)

	// ── Phase 3: Kiểm tra ShortTerm (ĐN) ────────────────────────────
	t.Log("\nPhase 3: Kiểm tra ShortTerm (ĐN) đã lưu")
	dnCount := dn.CountActive()
	t.Logf("  ShortTerm active: %d obs", dnCount)
	if dnCount == 0 {
		t.Error("ShortTerm phải có ít nhất 1 observation")
	}

	dnAll := dn.All()
	for _, obs := range dnAll {
		t.Logf("  DN obs: addr=%02x%02x%02x%02x conf=%.2f label=%s",
			obs.ISL.Layer, obs.ISL.Group, obs.ISL.Type, obs.ISL.ID,
			obs.Confidence, obs.Label)
	}

	// ── Phase 4: Confirm → LongTerm.Commit ───────────────────────────
	t.Log("\nPhase 4: Confirm DN → promote to LongTerm (QR)")
	// Confirm tất cả observations trong DN
	for _, obs := range dnAll {
		dn.Confirm(obs.NodeHash)
	}

	// Flush lần 2 với evidence cao hơn để trigger commit
	for i := 0; i < 10; i++ { pl.Tick(0.1) }
	time.Sleep(20 * time.Millisecond)
	flusher.CheckAndFlush()
	time.Sleep(20 * time.Millisecond)

	ltCount := lt.Count()
	t.Logf("  LongTerm (QR) count: %d", ltCount)
	if ltCount > 0 {
		t.Log("  ✓ QR đã có entries — spatial knowledge promoted")
	} else {
		t.Log("  ĐN confirmed nhưng cần thêm reinforce để commit QR")
		// Force commit bằng cách gửi nhiều MsgKnowledge
		// Cần flush thêm để FireCount >= CommitThreshold (3)
		for i := 0; i < 8; i++ {
			for j := 0; j < 4; j++ { pl.Tick(0.1) }
			time.Sleep(15 * time.Millisecond)
			flusher.CheckAndFlush()
			time.Sleep(10 * time.Millisecond)
		}
		ltCount = lt.Count()
		t.Logf("  LongTerm sau multi-flush: %d", ltCount)
	}

	// ── Stats ─────────────────────────────────────────────────────────
	recv, comm := leoSkill.Stats()
	flushes, props := flusher.Stats()
	ticks, sensors := pl.Stats()
	t.Logf("\n── Stats ──────────────────────────────")
	t.Logf("  PerceptLayer: %d ticks, %d sensors", ticks, sensors)
	t.Logf("  VisionChief: %s", vc.Summary())
	t.Logf("  DNFlusher: %d flushes, %d proposals", flushes, len(props))
	t.Logf("  SpatialLearnSkill: recv=%d committed=%d", recv, comm)
	t.Logf("  ShortTerm(ĐN): %d active", dn.CountActive())
	t.Logf("  LongTerm(QR): %d entries", lt.Count())

	t.Log("\n✓ QT7 pipeline:")
	t.Log("  SDF → ISLAddr → VisionChief(ĐN) → DNFlusher → MsgKnowledge")
	t.Log("  → SpatialLearnSkill → ShortTerm → [confirm] → LongTerm(QR)")
}
