// internal/agents/skill_env_probe.go
//
// EnvironmentProbeSkill — Agent tự đọc môi trường đang chạy
//
// Agent không giả định mình đang ở đâu.
// Nó ĐỌC rồi mới biết:
//   USB drive cắm vào TV       → embedded/low_power
//   Raspberry Pi trong nhà     → edge/home
//   PC người dùng              → personal/desktop
//   Server trung tâm dữ liệu  → datacenter/server
//
// Kết quả lưu vào State → các Skill khác dùng để tự giới hạn
// Ví dụ: ActuatorSkill chỉ chạy nếu env là "edge" hoặc "embedded"
//        LeoAI chỉ chạy full nếu env là "server" hoặc "desktop"

package agents

import (
	"fmt"
	"os"
	"runtime"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ── Environment Types ─────────────────────────────────────────

type EnvClass string

const (
	EnvEmbedded   EnvClass = "embedded"   // MCU, STM32, USB stick < 256MB RAM
	EnvEdge       EnvClass = "edge"        // RPi, NUC, smart hub 256MB–4GB
	EnvPersonal   EnvClass = "personal"    // laptop, phone, desktop
	EnvDatacenter EnvClass = "datacenter"  // server, cloud VM
	EnvUnknown    EnvClass = "unknown"
)

type EnvironmentInfo struct {
	Class       EnvClass
	OS          string   // "linux", "windows", "darwin", "freertos"
	Arch        string   // "amd64", "arm64", "arm", "386"
	CPUCores    int
	RAMTotalMB  int64
	StorageMB   int64
	IsContainer bool     // docker / k8s
	IsVM        bool     // hypervisor
	PowerSource string   // "battery", "ac", "poe", "unknown"
	Hostname    string
	ProbeTime   time.Time

	// Khả năng của môi trường
	CanRunLeoAI      bool // đủ RAM/CPU cho bộ não học
	CanRunPerception bool // đủ cho vision pipeline
	CanActuate       bool // có GPIO / actuator interface
	CanStore         bool // đủ storage cho Silk Tree
}

func (e EnvClass) String() string { return string(e) }

func (info *EnvironmentInfo) Summary() string {
	return fmt.Sprintf("%s/%s [%d cores, %dMB RAM] host=%s",
		info.Class, info.Arch, info.CPUCores, info.RAMTotalMB, info.Hostname)
}

// ── EnvironmentProbeSkill ────────────────────────────────────

type EnvironmentProbeSkill struct{}

func NewEnvironmentProbeSkill() *EnvironmentProbeSkill {
	return &EnvironmentProbeSkill{}
}

func (s *EnvironmentProbeSkill) Name() string { return "env_probe" }

func (s *EnvironmentProbeSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg.MsgType == isl.MsgSync {
		return true
	}
	return MatchIntent(msg, IntentProbeEnv)
}

func (s *EnvironmentProbeSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	info := s.probe()
	ctx.State["env.info"]  = info
	ctx.State["env.class"] = string(info.Class)

	return SkillResult{
		Data: map[string]interface{}{
			"env.summary":        info.Summary(),
			"env.class":          string(info.Class),
			"env.can_leoai":      info.CanRunLeoAI,
			"env.can_perception": info.CanRunPerception,
			"env.can_actuate":    info.CanActuate,
			"env.can_store":      info.CanStore,
		},
	}
}

func (s *EnvironmentProbeSkill) probe() EnvironmentInfo {
	info := EnvironmentInfo{
		OS:        runtime.GOOS,
		Arch:      runtime.GOARCH,
		CPUCores:  runtime.NumCPU(),
		ProbeTime: time.Now(),
	}

	// Hostname
	info.Hostname, _ = os.Hostname()

	// RAM
	info.RAMTotalMB = probeRAMMB()

	// Storage
	info.StorageMB = probeStorageMB()

	// Container / VM detection
	info.IsContainer = isContainer()
	info.IsVM        = isVM()

	// Power source
	info.PowerSource = probePowerSource()

	// Phân loại môi trường
	info.Class = classifyEnv(info)

	// Khả năng dựa trên môi trường
	info.CanRunLeoAI      = info.RAMTotalMB >= 512
	info.CanRunPerception = info.CPUCores >= 2 && info.RAMTotalMB >= 256
	info.CanActuate       = info.Class == EnvEmbedded || info.Class == EnvEdge
	info.CanStore         = info.StorageMB >= 64

	return info
}

func classifyEnv(info EnvironmentInfo) EnvClass {
	switch {
	case info.IsContainer || (info.CPUCores >= 8 && info.RAMTotalMB >= 8192):
		return EnvDatacenter
	case info.RAMTotalMB >= 4096 || (info.CPUCores >= 4 && !isLowPowerArch(info.Arch)):
		return EnvPersonal
	case info.RAMTotalMB >= 256:
		return EnvEdge
	default:
		return EnvEmbedded
	}
}

func isLowPowerArch(arch string) bool {
	return arch == "arm" || arch == "arm64" || arch == "386"
}

// ── Platform probes (cross-platform) ─────────────────────────

func probeRAMMB() int64 {
	// Linux: đọc /proc/meminfo
	if data, err := os.ReadFile("/proc/meminfo"); err == nil {
		var kb int64
		fmt.Sscanf(string(data), "MemTotal: %d kB", &kb)
		if kb > 0 { return kb / 1024 }
	}
	// macOS / Windows: dùng runtime stats làm xấp xỉ
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	// Sys = memory obtained from OS — không phải total RAM
	// Trả về xấp xỉ để classify
	sysMB := int64(ms.Sys) / (1024 * 1024)
	if sysMB < 64 { return 512 } // default khi không đọc được
	return sysMB
}

func probeStorageMB() int64 {
	// Kiểm tra free space tại thư mục hiện tại
	// Đơn giản: kiểm tra xem có thể tạo file không
	tmp := os.TempDir()
	info, err := os.Stat(tmp)
	if err != nil || !info.IsDir() { return 0 }
	return 1024 // default 1GB nếu không đọc được
}

func isContainer() bool {
	// Docker: /.dockerenv tồn tại
	if _, err := os.Stat("/.dockerenv"); err == nil { return true }
	// Kubernetes: /var/run/secrets/kubernetes.io
	if _, err := os.Stat("/var/run/secrets/kubernetes.io"); err == nil { return true }
	return false
}

func isVM() bool {
	// Linux: kiểm tra /sys/hypervisor
	if _, err := os.Stat("/sys/hypervisor/type"); err == nil { return true }
	return false
}

func probePowerSource() string {
	// Linux: /sys/class/power_supply/
	entries, err := os.ReadDir("/sys/class/power_supply/")
	if err != nil { return "unknown" }
	for _, e := range entries {
		if e.Name() == "AC" || e.Name() == "AC0" { return "ac" }
		if e.Name()[:3] == "BAT" { return "battery" }
	}
	return "unknown"
}
