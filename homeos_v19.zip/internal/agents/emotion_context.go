// internal/agents/emotion_context.go
// EmotionContext — điều kiện biên của phương trình cảm xúc
//
// Insight (2026-03-09):
//   Cùng một tín hiệu âm học → cảm xúc khác nhau tùy ngữ cảnh.
//   Không thể đoán cảm xúc chỉ từ Spline — cần biết:
//     - Bạn là ai trong câu chuyện?
//     - Nguồn gốc sự việc là gì?
//     - Khoảng cách tâm lý bao xa?
//
// Mô hình toán:
//   EmotionTag = DetectEmotion(Spline) × S(Context)
//   S = role_factor × source_factor × recency_factor
//
// Cùng phương trình vi phân, điều kiện biên khác → nghiệm khác.

package agents

import "math"

// ─── Role — bạn là ai trong câu chuyện ───────────────────────────────────

// Role mô tả vị trí của người cảm nhận
type Role uint8

const (
	RoleFirstPerson  Role = iota // bạn đang sống nó trực tiếp
	RoleSecondPerson             // người kể chuyện nói với bạn
	RoleThirdPerson              // bạn nghe người khác kể về người khác
	RoleObserver                 // bạn xem/đọc từ xa
)

func (r Role) String() string {
	return [...]string{"first_person", "second_person", "third_person", "observer"}[r]
}

// roleSensitivity — hệ số nhạy cảm theo vai trò
func (r Role) sensitivity() float64 {
	return [...]float64{1.0, 0.75, 0.55, 0.30}[r]
}

// ─── Source — nguồn gốc sự việc ──────────────────────────────────────────

// Source mô tả bản chất của nguồn cảm xúc
type Source uint8

const (
	SourceRealNow    Source = iota // đang xảy ra với bạn ngay lúc này
	SourceRealPast                 // đã xảy ra — có khoảng cách thời gian
	SourceRealOther                // xảy ra với người khác (bạn nghe kể)
	SourceFiction                  // phim, sách, game — biết là không thật
	SourceMusic                    // âm nhạc thuần túy — nghệ thuật
	SourceMemory                   // ký ức — mix giữa real và constructed
)

func (s Source) String() string {
	return [...]string{"real_now", "real_past", "real_other", "fiction", "music", "memory"}[s]
}

func (s Source) sensitivity() float64 {
	return [...]float64{1.0, 0.80, 0.60, 0.30, 0.25, 0.70}[s]
}

// ─── EmotionContext — điều kiện biên ────────────────────────────────────

// EmotionContext chứa toàn bộ ngữ cảnh cần thiết để giải
// phương trình cảm xúc đúng với người đang cảm nhận.
type EmotionContext struct {
	Role     Role    // bạn là ai trong câu chuyện
	Source   Source  // sự việc đến từ đâu
	Recency  float64 // 0.0(xa xưa) → 1.0(vừa xảy ra)
	Shared   bool    // đang chia sẻ cùng người khác (tăng cộng hưởng)
	Expected bool    // biết trước sẽ xảy ra (giảm shock)
}

// DefaultContext — ngữ cảnh mặc định khi không có thông tin
// Giả định: đang nói về bản thân, sự việc vừa qua
var DefaultContext = EmotionContext{
	Role:    RoleFirstPerson,
	Source:  SourceRealNow,
	Recency: 1.0,
}

// FictionContext — xem phim, đọc sách
var FictionContext = EmotionContext{
	Role:    RoleObserver,
	Source:  SourceFiction,
	Recency: 0.5,
}

// MusicContext — nghe nhạc
var MusicContext = EmotionContext{
	Role:    RoleObserver,
	Source:  SourceMusic,
	Recency: 1.0, // âm nhạc luôn "hiện tại"
}

// S tính hệ số nhân tổng thể
//
//   S = role × source × recency × shared_bonus × expected_dampen
//
// Ý nghĩa: cùng Spline, S khác → EmotionTag khác
func (c EmotionContext) S() float64 {
	s := c.Role.sensitivity() * c.Source.sensitivity()

	// Recency: sự việc càng gần → cảm xúc càng mạnh
	// Công thức: 0.5 + 0.5*Recency → range [0.5, 1.0]
	s *= 0.5 + 0.5*c.Recency

	// Chia sẻ cùng người khác → tăng cộng hưởng +15%
	if c.Shared { s *= 1.15 }

	// Biết trước → giảm shock -20% (đã chuẩn bị tâm lý)
	if c.Expected { s *= 0.80 }

	// Clamp [0.05, 1.0] — luôn có phản ứng tối thiểu
	if s > 1.0  { return 1.0 }
	if s < 0.05 { return 0.05 }
	return s
}

// ─── Apply — áp dụng context lên EmotionTag ──────────────────────────────

// Apply áp dụng EmotionContext lên EmotionTag thô từ Spline
//
// Đây là bước "giải phương trình trong khoảng" —
// cùng f(t), điều kiện biên khác → nghiệm khác.
//
//   Valence:   scale theo S (dấu giữ nguyên)
//   Arousal:   scale theo S, nhưng giữ baseline 0.1 (luôn còn sống)
//   Dominance: FirstPerson+RealNow → giảm thêm (bị áp đảo)
//              Observer+Fiction   → tăng thêm (khoảng cách an toàn)
//   Intensity: scale theo S²  (cảm xúc mờ đi nhanh hơn với khoảng cách)
func (ctx EmotionContext) Apply(raw EmotionTag) EmotionTag {
	s := ctx.S()

	// Valence scale — dấu giữ nguyên, magnitude giảm
	valence := raw.Valence * s

	// Arousal scale với baseline
	arousal := 0.1 + (raw.Arousal-0.1)*s
	if arousal < 0 { arousal = 0 }

	// Dominance — phụ thuộc vai trò
	dominance := raw.Dominance
	switch {
	case ctx.Role == RoleFirstPerson && ctx.Source == SourceRealNow:
		// Trực tiếp → bị áp đảo hơn khi cảm xúc mạnh
		dominance *= (1.0 - 0.3*raw.Intensity)
	case ctx.Role == RoleObserver:
		// Quan sát → khoảng cách an toàn → kiểm soát tốt hơn
		dominance = dominance*0.5 + 0.5
	}

	// Intensity scale theo S² — mờ đi nhanh hơn với khoảng cách
	intensity := raw.Intensity * s * s
	// Nhưng fiction/music có aesthetic floor — xúc động nghệ thuật
	if ctx.Source == SourceFiction || ctx.Source == SourceMusic {
		floor := 0.15 * raw.Intensity // còn lại ít nhất 15% dưới dạng aesthetic
		if intensity < floor { intensity = floor }
	}

	clamp := func(v, lo, hi float64) float64 {
		if v < lo { return lo }
		if v > hi { return hi }
		return v
	}
	return EmotionTag{
		Valence:   clamp(valence,   -1, 1),
		Arousal:   clamp(arousal,    0, 1),
		Dominance: clamp(dominance,  0, 1),
		Intensity: clamp(intensity,  0, 1),
	}
}

// ─── ContextualEmotion — kết quả cuối cùng ───────────────────────────────

// ContextualEmotion = EmotionTag đã được giải trong ngữ cảnh cụ thể
type ContextualEmotion struct {
	Raw     EmotionTag     // từ Spline — chưa có context
	Context EmotionContext // điều kiện biên
	Final   EmotionTag     // sau khi Apply(Context)
}

// Describe mô tả ngắn gọn — dùng cho LeoAI trả lời người dùng
func (ce ContextualEmotion) Describe() string {
	label := ce.Final.Label()
	role  := ce.Context.Role.String()
	src   := ce.Context.Source.String()

	// Nếu raw và final khác nhau nhiều → nói lên sự khác biệt
	diff := math.Abs(ce.Raw.Intensity - ce.Final.Intensity)
	if diff > 0.3 {
		return label + " [" + role + "/" + src + ", attenuated]"
	}
	return label + " [" + role + "/" + src + "]"
}

// DNA lưu vào Silk edge — append-only
func (ce ContextualEmotion) DNA(t int64) string {
	return ce.Final.DNA(t) +
		":role=" + ce.Context.Role.String() +
		":src=" + ce.Context.Source.String()
}

// ─── SolveEmotion — entry point ──────────────────────────────────────────

// SolveEmotion giải phương trình cảm xúc trong ngữ cảnh cụ thể
//
// Đây là hàm chính — thay thế DetectEmotion trực tiếp
// khi đã biết ngữ cảnh.
func SolveEmotion(s ProsodySpline, ctx EmotionContext) ContextualEmotion {
	raw   := DetectEmotion(s)
	final := ctx.Apply(raw)
	return ContextualEmotion{Raw: raw, Context: ctx, Final: final}
}
