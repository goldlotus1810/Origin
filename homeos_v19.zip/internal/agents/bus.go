// internal/agents/bus.go
//
// MESSAGE BUS — trung tâm phân phối ISL
//
// Kiến trúc (bất biến từ MASTER.md):
//
//   User input (text/audio/image)
//       ↓ PerceptLayer → MsgUserInput
//       ↓ Bus.Broadcast()
//       │
//       ├── AAM.inbox      → dịch intent → MsgActuatorCmd → Chief → Worker
//       ├── LeoAI.inbox    → kiểm tra mới → học → MsgKnowledge → AAM → Chief → Agent
//       ├── HomeChief.inbox → (nghe thụ động — biết context)
//       └── ... mọi agent đều nhận
//
// Luồng kiến thức (QT7):
//   LeoAI học được → MsgKnowledge → Bus → AAM
//   AAM xác nhận   → MsgKnowledge → Chief → Worker liên quan
//
// Quy tắc phân cấp (bất biến):
//   ✅ Bus → tất cả agents (MsgUserInput)
//   ✅ AAM → Chief (MsgActuatorCmd, MsgKnowledge)
//   ✅ Chief → Worker (MsgActuatorCmd)
//   ❌ Worker → Worker trực tiếp
//   ❌ AAM → Worker trực tiếp

package agents

import (
	"log"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─── MessageBus ────────────────────────────────────────────────

// MessageBus là trung tâm phân phối ISLMessage
// Mọi agent đăng ký vào Bus — khi có message, Bus gửi đến TẤT CẢ
type MessageBus struct {
	mu       sync.RWMutex
	agents   map[string]*busEntry // id → entry
	learnCh  chan *isl.ISLMessage // kênh riêng cho LeoAI knowledge output
	aamCh    chan *isl.ISLMessage // kênh riêng cho AAM nhận knowledge từ LeoAI
}

type busEntry struct {
	id   string
	ch   chan *isl.ISLMessage
	tier int // 0=AAM, 1=Chief/LeoAI, 2=Worker
	role BusRole
}

// BusRole phân loại vai trò của agent trong bus
type BusRole uint8

const (
	RoleAAM     BusRole = 0 // điều phối trung tâm
	RoleLeoAI   BusRole = 1 // học + tri thức
	RoleChief   BusRole = 2 // route trong domain
	RoleWorker  BusRole = 3 // thực thi
)

// NewMessageBus tạo bus mới
func NewMessageBus() *MessageBus {
	return &MessageBus{
		agents:  make(map[string]*busEntry),
		learnCh: make(chan *isl.ISLMessage, 32),
		aamCh:   make(chan *isl.ISLMessage, 32),
	}
}

// Register đăng ký 1 agent vào bus
func (b *MessageBus) Register(id string, ch chan *isl.ISLMessage, tier int, role BusRole) {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.agents[id] = &busEntry{id: id, ch: ch, tier: tier, role: role}
	log.Printf("Bus: registered [%s] tier=%d role=%d", id, tier, role)
}

// Unregister gỡ agent khỏi bus
func (b *MessageBus) Unregister(id string) {
	b.mu.Lock()
	defer b.mu.Unlock()
	delete(b.agents, id)
}

// ─── Broadcast — gửi đến TẤT CẢ agents ───────────────────────

// Broadcast gửi 1 ISLMessage đến inbox của mọi agent đã đăng ký
// Non-blocking: nếu inbox đầy thì bỏ qua (agent tự chịu trách nhiệm)
// Chạy song song: mỗi agent nhận trong goroutine riêng
func (b *MessageBus) Broadcast(msg *isl.ISLMessage) {
	b.mu.RLock()
	entries := make([]*busEntry, 0, len(b.agents))
	for _, e := range b.agents {
		entries = append(entries, e)
	}
	b.mu.RUnlock()

	for _, e := range entries {
		select {
		case e.ch <- msg:
			// gửi được
		default:
			// inbox đầy — agent đang bận, bỏ qua
			// (Silent by default: agent tự kiểm soát buffer)
		}
	}
}

// ─── Send — gửi đến 1 agent cụ thể ───────────────────────────

// Send gửi message đến 1 agent theo id
func (b *MessageBus) Send(targetID string, msg *isl.ISLMessage) bool {
	b.mu.RLock()
	entry, ok := b.agents[targetID]
	b.mu.RUnlock()
	if !ok { return false }

	select {
	case entry.ch <- msg:
		return true
	case <-time.After(10 * time.Millisecond):
		log.Printf("Bus: timeout sending to [%s]", targetID)
		return false
	}
}

// ─── SendToRole — gửi đến tất cả agents có role cụ thể ────────

// SendToRole gửi đến tất cả AAM, hoặc tất cả Chief, v.v.
func (b *MessageBus) SendToRole(role BusRole, msg *isl.ISLMessage) {
	b.mu.RLock()
	entries := make([]*busEntry, 0)
	for _, e := range b.agents {
		if e.role == role {
			entries = append(entries, e)
		}
	}
	b.mu.RUnlock()

	for _, e := range entries {
		select {
		case e.ch <- msg:
		default:
		}
	}
}

// ─── Knowledge Pipeline ────────────────────────────────────────

// LearnOutput — LeoAI gửi knowledge mới vào đây sau khi học
// Bus tự động forward đến AAM
func (b *MessageBus) LearnOutput() chan<- *isl.ISLMessage {
	return b.learnCh
}

// RunKnowledgePipeline chạy goroutine chuyển knowledge từ LeoAI → AAM
// Luồng: LeoAI.learn() → learnCh → AAM.inbox
func (b *MessageBus) RunKnowledgePipeline() {
	go func() {
		for msg := range b.learnCh {
			if msg.MsgType != isl.MsgKnowledge { continue }

			// Forward đến AAM
			b.SendToRole(RoleAAM, msg)
			log.Printf("Bus: knowledge [%s] → AAM",
					msg.PrimaryAddr.String())
		}
	}()
}

// ─── UserInput Pipeline ────────────────────────────────────────

// DispatchUserInput — điểm vào chính khi user nói/gõ/gửi ảnh
//
// Đây là điểm duy nhất nhận input từ bên ngoài vào hệ thống.
// Sau khi qua Perception Layer, msg trở thành ISL thuần —
// không có string bên trong, chỉ có địa chỉ và confidence.
//
// Tất cả agents nhận cùng message (song song, non-blocking).
// Mỗi agent tự quyết định có xử lý không qua CanHandle().
func (b *MessageBus) DispatchUserInput(msg *isl.ISLMessage) {
	msg.MsgType = isl.MsgUserInput
	b.Broadcast(msg)
	log.Printf("Bus: user input → %d agents · primary=%s",
		b.Count(), msg.PrimaryAddr.String())
}

// Count trả về số agent đang đăng ký
func (b *MessageBus) Count() int {
	b.mu.RLock()
	defer b.mu.RUnlock()
	return len(b.agents)
}

// Snapshot debug — danh sách agents đang online
func (b *MessageBus) Snapshot() []string {
	b.mu.RLock()
	defer b.mu.RUnlock()
	ids := make([]string, 0, len(b.agents))
	for id := range b.agents {
		ids = append(ids, id)
	}
	return ids
}
