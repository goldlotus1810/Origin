package agents

import (
	"fmt"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestContextAwareSkill(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  CONTEXT AWARE SKILL — AAM biết bạn đang ở đâu              ║")
	t.Log("║  Trước: 'tắt đèn' → hỏi 'phòng nào?'                       ║")
	t.Log("║  Sau:   'tắt đèn' → tắt đúng phòng, không hỏi              ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	skill := NewContextAwareSkill("human_adult_female")

	// ── 1. Seed context: đang nấu ăn ─────────────────────────
	t.Log("[ BƯỚC 1 — Perception pipeline gửi scene ]")
	cookScene := &gene.SceneUnderstanding{
		Action: gene.ActionCooking, ActionConf: 1.00,
		Space:  gene.SpaceKitchen, SpaceConf: 0.80,
		ISLAddr: gene.SpaceKitchen.ISLAddr(),
	}
	skill.ctx.Update(cookScene, "human_adult_female", time.Now())
	t.Logf("  → Context: đang nấu ăn tại %s (HAa1)", gene.SpaceKitchen)
	t.Log()

	// ── 2. Test ambient commands ──────────────────────────────
	t.Log("[ BƯỚC 2 — User nói lệnh ngắn, không cần nói phòng nào ]")
	t.Log()

	type testCase struct {
		cmd      string
		wantAddr string
		wantKW   string
	}

	cases := []testCase{
		{"tắt đèn",   "HAa1", "light"},
		{"lạnh hơn",  "HAa1", "temp"},
		{"im lặng",   "HAa1", "sound"},
		{"sáng hơn",  "HAa1", "light"},
	}

	for _, tc := range cases {
		msg := &isl.ISLMessage{Payload: []byte(tc.cmd)}
		if !skill.CanHandle(msg) {
			t.Errorf("CanHandle(%q) = false", tc.cmd)
			continue
		}
		result := skill.Execute(&ExecContext{
			State: make(map[string]interface{}),
		}, msg)

		addr, _ := result.Data["isl_addr"].(string)
		cmdResult, _ := result.Data["cmd_result"].(string)
		reply := ContextualReply(result, tc.cmd)

		ok := addr == tc.wantAddr
		mark := "✓"
		if !ok { mark = "✗" }

		t.Logf("%s  %-12q → ISL=%-5s  %s", mark, tc.cmd, addr, cmdResult)
		t.Logf("   AAM nói: %q", reply)
		if result.Message != nil {
			t.Logf("   actuator: %s", string(result.Message.Payload))
		}
		t.Log()
	}

	// ── 3. Context thay đổi → lệnh tự resolve ────────────────
	t.Log("[ BƯỚC 3 — Người di chuyển từ bếp sang phòng ngủ ]")
	sleepScene := &gene.SceneUnderstanding{
		Action: gene.ActionSleeping, ActionConf: 0.85,
		Space:  gene.SpaceBedroom, SpaceConf: 0.87,
		ISLAddr: gene.SpaceBedroom.ISLAddr(),
	}
	skill.ctx.Update(sleepScene, "human_adult_female", time.Now().Add(2*time.Hour))
	t.Logf("  → Context thay đổi: ngủ tại %s (HAc1)", gene.SpaceBedroom)
	t.Log()

	// Cùng lệnh "tắt đèn" → nhưng giờ resolve sang bedroom
	msg := &isl.ISLMessage{Payload: []byte("tắt đèn")}
	result := skill.Execute(&ExecContext{State: make(map[string]interface{})}, msg)
	addr, _ := result.Data["isl_addr"].(string)
	reply := ContextualReply(result, "tắt đèn")
	t.Logf("  'tắt đèn' → ISL=%s  AAM: %q", addr, reply)
	t.Log()

	// ── 4. Scene parse ────────────────────────────────────────
	t.Log("[ BƯỚC 4 — Parse scene từ perception pipeline ]")
	scenePayloads := []string{
		"[scene] action=cooking space=kitchen conf=80",
		"[scene] action=dancing space=living_room conf=95",
		"[scene] action=sleeping space=bedroom conf=85",
	}
	for _, p := range scenePayloads {
		s := parseScenePayload(p)
		if s != nil {
			t.Logf("  %-46s → %s@%s (%.0f%%)",
				p, s.Action, s.Space, s.ActionConf*100)
		}
	}
	t.Log()

	// ── 5. Full pipeline visual ───────────────────────────────
	t.Log("[ PIPELINE HOÀN CHỈNH ]")
	fmt.Println(`
  Camera+Mic
      ↓ 0.12ms  FovealVision (Fibonacci 144)
      ↓ 0.08ms  Outline + SDFSkeleton
      ↓ 1.5μs   MotionTracker → MotionClip
      ↓          ActionRecognizer
      ↓ [scene] action=X space=Y conf=Z
  ContextAwareSkill (trong AAM)
      ↓ activeSpace() → HAa1/HAb1/HAc1...
      ↓ AmbientCommand("tắt đèn")
      ↓ ACTUATOR HAa1 light=0 sound=0 temp=22 fan=70
  Chief (kitchen) → Worker (light_01, hvac_01)
  `)
	t.Log("--- PASS")
}
