// internal/agents/dream_integration_test.go
//
// Integration test: DreamSkill end-to-end
// Luồng: Observe vào ShortTerm (ĐN) → MsgDream → runDreamCycle → promote QR
package agents

import (
	"crypto/ed25519"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// newTestLedger — tạo ledger in-memory cho test
func newTestLedger() *silk.Ledger {
	_, priv, _ := ed25519.GenerateKey(nil)
	return silk.NewLedger("", priv) // "" = in-memory, không tạo file
}

func TestDreamSkill_Integration(t *testing.T) {
	t.Log("── DreamSkill end-to-end: ĐN → Dream → QR ───────────────")

	// Setup: ShortTerm (ĐN) + LongTerm (QR) + SilkGraph
	dn := memory.NewShortTerm(256)
	graph := silk.NewSilkGraph()
	ledger := newTestLedger()
	qr := memory.NewLongTerm(graph, ledger)

	dream := NewDreamSkill(dn, qr, graph)
	// Tắt delay để test không cần chờ 30s
	dream.SetMinIdle(0)

	// ── Bước 1: Seed ĐN với các observations ──────────────────
	t.Log("  Bước 1: Seed ĐN")
	type obs struct {
		name   string
		conf   float64
		confirm int
		reject  int
	}
	seeds := []obs{
		// Sẽ được promote: conf cao, nhiều confirm
		{"quang_hop", 0.75, 5, 0},   // Fibonacci pattern → +0.1 → 0.85 ≥ 0.8 ✓
		{"dieu_hoa",  0.70, 4, 0},   // Fibonacci + consistency → 0.90 ✓
		{"den_LED",   0.78, 3, 0},   // Fibonacci + consistency → 0.88 ✓
		// Sẽ bị xóa: conf thấp + nhiều reject
		{"noise_1",   0.15, 1, 6},   // conf < 0.2, total > 5 → delete ✓
		{"noise_2",   0.10, 0, 8},   // conf < 0.2, total > 5 → delete ✓
		// Giữ lại (chưa đủ điều kiện)
		{"maybe",     0.50, 1, 0},   // conf trung bình, ít data
		{"uncertain", 0.45, 2, 1},
	}

	islAddrs := map[string]isl.Address{}
	for _, s := range seeds {
		addr := isl.Address{Layer: 3, Group: uint8(hash8(s.name)), Type: 1, ID: 1}
		islAddrs[s.name] = addr
		o := memory.Observation{
			ISL:       addr,
			NodeHash:  isl.NodeHash(hash64(s.name)),
			Data:      []byte(s.name),
			Confidence: s.conf,
			Confirmed: s.confirm,
			Rejected:  s.reject,
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
		}
		dn.ForceInsert(o) // Dùng ForceInsert để bypass Observe logic
		t.Logf("    seeded %-12s conf=%.2f confirm=%d reject=%d",
			s.name, s.conf, s.confirm, s.reject)
	}
	t.Logf("  ĐN count: %d", dn.Count())

	// ── Bước 2: Trigger MsgDream ──────────────────────────────
	t.Log("  Bước 2: Trigger MsgDream")
	ctx := &ExecContext{
		State: map[string]interface{}{
			"last_active": time.Now().Add(-10 * time.Minute).Unix(),
		},
	}
	msg := &isl.ISLMessage{Version: 1, MsgType: isl.MsgDream}
	result := dream.Execute(ctx, msg)

	// ── Bước 3: Kiểm tra kết quả ──────────────────────────────
	t.Log("  Bước 3: Kiểm tra kết quả")
	promoted := result.Data["dream.proposed"].(int)
	deleted  := result.Data["dream.deleted"].(int)
	checked  := result.Data["dream.checked"].(int)

	t.Logf("  Checked: %d, Promoted: %d, Deleted: %d", checked, promoted, deleted)

	if checked != len(seeds) {
		t.Errorf("expected checked=%d, got %d", len(seeds), checked)
	}
	if promoted < 1 {
		t.Logf("  ⚠ proposed=%d — conf chưa đủ 0.8 sau 1 cycle", promoted)
	} else {
		t.Logf("  ✓ proposed=%d proposals chờ AAM", promoted)
	}

	//  Bước 4: QR phải rỗng — dream không tự commit 
	t.Log("  Bước 4: QR phải rỗng")
	qrCount := qr.Count()
	if qrCount > 0 {
		t.Errorf("DreamSkill tự commit QR! Vi phạm QT7. got=%d", qrCount)
	} else {
		t.Logf("  ✓ QR=0 — proposals chờ AAM approve")
	}

	//  Bước 5: Proposals có evidence 
	t.Log("  Bước 5: Proposals có lý do")
	for _, p := range dream.PendingProposals() {
		if len(p.Evidence) == 0 {
			t.Errorf("Proposal '%s' không có evidence!", p.Label)
		} else {
			t.Logf("  ✓ '%s': %d evidence, conf=%.2f", p.Label, len(p.Evidence), p.Confidence)
		}
	}


	// ── Bước 6: Idempotent — chạy lại không promote lại ─────
	t.Log("  Bước 6: Idempotent check")
	dream.ResetLastRun() // reset throttle timer
	result2 := dream.Execute(ctx, msg)
	var promoted2 int
	if result2.Data != nil {
		promoted2 = result2.Data["dream.proposed"].(int)
	}
	t.Logf("  Second run promoted: %d (should be 0 — already archived)", promoted2)

	t.Log("  ✅ DreamSkill integration test PASS")
}

// TestDreamSkill_QT2_NoInfiniteLoop — Rule 2: không vòng lặp vô hạn
func TestDreamSkill_QT2_NoInfiniteLoop(t *testing.T) {
	t.Log("── QT2: Dream không vòng lặp vô hạn ─────────────────────")

	dn := memory.NewShortTerm(256)
	qr := memory.NewLongTerm(silk.NewSilkGraph(), newTestLedger())
	dream := NewDreamSkill(dn, qr, nil)
	dream.SetMinIdle(0)

	ctx := &ExecContext{State: map[string]interface{}{}}

	// 1000 MsgDream liên tiếp — không được block
	start := time.Now()
	for i := 0; i < 1000; i++ {
		dream.Execute(ctx, &isl.ISLMessage{Version: 1, MsgType: isl.MsgDream})
	}
	elapsed := time.Since(start)

	t.Logf("  1000 MsgDream: %v (should be fast due to 30s throttle)", elapsed)
	if elapsed > 2*time.Second {
		t.Errorf("Dream loop too slow: %v", elapsed)
	}
	t.Log("  ✅ QT2 PASS — throttle hoạt động đúng")
}

// ── helpers ──────────────────────────────────────────────────────

func hash8(s string) uint8 {
	h := uint8(0)
	for _, c := range s { h ^= uint8(c) }
	return h
}

func hash64(s string) uint64 {
	h := uint64(14695981039346656037)
	for _, c := range s { h ^= uint64(c); h *= 1099511628211 }
	return h
}
