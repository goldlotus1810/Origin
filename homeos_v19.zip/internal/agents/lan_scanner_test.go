package agents

import (
	"strings"
	"testing"
	"time"
	"github.com/goldlotus1810/HomeOS/internal/gene"
)

func TestMockLANScanner(t *testing.T) {
	devices := DefaultMockDevices()
	scanner := NewMockLANScanner(devices...)
	result := scanner.Scan()
	if len(result) != 3 {
		t.Errorf("Expected 3 devices, got %d", len(result))
	}
	if result[0].Vendor != "Philips" {
		t.Errorf("Expected Philips, got %s", result[0].Vendor)
	}
}

func TestClassifyDevice_MAC(t *testing.T) {
	cases := []struct {
		mac        string
		wantVendor string
		wantType   string
	}{
		{"00:17:88:aa:bb:cc", "Philips", "smart_light"},
		{"b8:27:eb:11:22:33", "RaspberryPi", "controller"},
		{"f4:f5:d8:44:55:66", "Google", "smart_speaker"},
		{"d4:81:d7:99:88:77", "Hikvision", "camera"},
	}
	for _, tc := range cases {
		v, dt := classifyDevice(tc.mac, "")
		if v != tc.wantVendor || dt != tc.wantType {
			t.Errorf("MAC %s: got vendor=%s type=%s, want vendor=%s type=%s",
				tc.mac, v, dt, tc.wantVendor, tc.wantType)
		}
	}
}

func TestClassifyDevice_mDNS(t *testing.T) {
	v, dt := classifyDevice("", "_hap._tcp.local")
	if dt != "smart_light" {
		t.Errorf("HomeKit: expected smart_light, got %s", dt)
	}
	v, dt = classifyDevice("", "_googlecast._tcp.local")
	if v != "Google" || dt != "smart_speaker" {
		t.Errorf("Chromecast: got vendor=%s type=%s", v, dt)
	}
}

func TestScanSummary(t *testing.T) {
	summary := ScanSummary([]DiscoveredDevice{})
	if !strings.Contains(summary, "Không tìm thấy") {
		t.Error("Empty devices: wrong message")
	}
	summary = ScanSummary(DefaultMockDevices())
	if !strings.Contains(summary, "3") {
		t.Errorf("Expected 3 in summary: %s", summary)
	}
}

func TestBuildMDNSQuery(t *testing.T) {
	pkt := buildMDNSQuery("_hap._tcp.local.")
	if len(pkt) < 12 {
		t.Error("Query too short")
	}
	// Header: ID=0, QR=0, QDCOUNT=1
	if pkt[4] != 0 || pkt[5] != 1 {
		t.Errorf("QDCOUNT wrong: %d", pkt[5])
	}
}

func TestIncrementIP(t *testing.T) {
	base := []byte{192, 168, 1, 0}
	ip := incrementIP(base, 5)
	if ip.String() != "192.168.1.5" {
		t.Errorf("Expected 192.168.1.5, got %s", ip.String())
	}
	ip = incrementIP(base, 254)
	if ip.String() != "192.168.1.254" {
		t.Errorf("Expected 192.168.1.254, got %s", ip.String())
	}
}

func TestRealLANScanner_Timeout(t *testing.T) {
	// Trên sandbox không có LAN thật → scan nhanh, trả về 0 devices
	// Chỉ test không panic, không block quá 3s
	s := &RealLANScanner{
		Timeout:  10 * time.Millisecond,
		MaxHosts: 5, // chỉ scan 5 hosts cho test nhanh
		MDNSWait: 100 * time.Millisecond,
	}
	start := time.Now()
	devices := s.Scan()
	elapsed := time.Since(start)

	if elapsed > 3*time.Second {
		t.Errorf("Scan took too long: %v", elapsed)
	}
	// Trong sandbox /31 network → 0 devices là bình thường
	t.Logf("✅ Scan: %d devices in %v", len(devices), elapsed)
	_ = devices
}

func TestDiscoveredDevice_Fields(t *testing.T) {
	dev := DiscoveredDevice{
		IP: "192.168.1.100", MAC: "00:17:88:aa:bb:cc",
		DeviceType: "smart_light", Vendor: "Philips",
		Location: gene.SpaceLivingRoom,
		DiscoveredAt: time.Now(),
		NeedsAuth: false,
	}
	if dev.DeviceType != "smart_light" { t.Error("DeviceType wrong") }
	if dev.Location != gene.SpaceLivingRoom { t.Error("Location wrong") }
}
