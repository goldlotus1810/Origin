//go:build linux

package agents

import "syscall"

type StatVFS struct {
	Bsize  uint64
	Blocks uint64
	Bfree  uint64
	Bavail uint64
}

func statVFS(path string, s *StatVFS) error {
	var st syscall.Statfs_t
	if err := syscall.Statfs(path, &st); err != nil {
		return err
	}
	s.Bsize  = uint64(st.Bsize)
	s.Blocks = st.Blocks
	s.Bfree  = st.Bfree
	s.Bavail = st.Bavail
	return nil
}
