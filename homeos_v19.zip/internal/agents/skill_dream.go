// internal/agents/skill_dream.go
//
// ScheduleDreamSkill — LeoAI (Server), chạy khi inbox rảnh > 5 phút
//
// QT7: kiểm chứng ĐN khi rảnh
//   PROMOTE  → conf >= 0.80, seen >= 5 → schedule bất biến
//   CONFLICT → conf < 0.45, seen >= 4  → xóa ĐN
//   UNCERTAIN → chưa đủ dữ liệu

package agents

import (
	"encoding/binary"
	"fmt"
	"log"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// ── DreamSkill cũ (dùng cho loader, memory, knowledge graph) ─

type DreamSkill struct {
	dn        *memory.ShortTerm
	qr        *memory.LongTerm
	graph     *silk.SilkGraph
	lastDecay time.Time
	olangPath string                                             // path đến homeos.olang
	edgeFlusher func(src, dst [8]byte, etype uint8, w float32) error // callback để flush edges
}

func NewDreamSkill(dn *memory.ShortTerm, qr *memory.LongTerm, graph *silk.SilkGraph) *DreamSkill {
	return &DreamSkill{dn: dn, qr: qr, graph: graph, lastDecay: time.Now()}
}

// WithOlangPath cung cấp đường dẫn file để flush Hebbian edges
func (s *DreamSkill) WithOlangPath(path string) *DreamSkill {
	s.olangPath = path
	return s
}

// WithEdgeFlusher cung cấp callback để persist high-weight edges xuống disk
// Tránh import cycle agents→ws bằng cách dùng function injection
func (s *DreamSkill) WithEdgeFlusher(fn func(src, dst [8]byte, etype uint8, w float32) error) *DreamSkill {
	s.edgeFlusher = fn
	return s
}

func (s *DreamSkill) Name() string { return "dream" }

func (s *DreamSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgDream
}

func (s *DreamSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.dn == nil {
		return SkillResult{Data: map[string]interface{}{
			"dream.proposed": 0, "dream.deleted": 0, "dream.checked": 0,
		}}
	}
	all := s.dn.All()
	promoted, deleted := 0, 0

	// Pass 1: collect high-confidence candidates → MsgPropose → AAM
	var propPayload []byte
	for _, c := range all {
		if c.Confidence >= 0.75 {
			// Encode NodeHash (8 bytes Big Endian)
			h := uint64(c.NodeHash)
			propPayload = append(propPayload,
				byte(h>>56), byte(h>>48), byte(h>>40), byte(h>>32),
				byte(h>>24), byte(h>>16), byte(h>>8), byte(h),
			)
			promoted++
		}
	}

	// Pass 2: evict low-confidence entries (QT7: bác bỏ → xóa ĐN)
	for _, c := range all {
		if c.Confidence < 0.20 && c.SrcType != uint8(SourceFiction) {
			s.dn.MarkArchived(c.NodeHash) // archive = soft delete
			deleted++
		}
	}

	var outMsg *isl.ISLMessage
	if len(propPayload) > 0 {
		outMsg = &isl.ISLMessage{
			MsgType: isl.MsgPropose,
			Payload: propPayload,
		}
	}

	if promoted > 0 || deleted > 0 {
		log.Printf("Dream: checked=%d propose=%d evict=%d", len(all), promoted, deleted)
	}

	// Hebbian decay — giảm weight edges không dùng theo thời gian
	// Rate: 1 point per day, minimum=1
	hebbDecayed, hebbPruned, hebbFlushed := 0, 0, 0
	if s.graph != nil {
		elapsed := time.Since(s.lastDecay)
		if elapsed >= 24*time.Hour {
			hebbDecayed, hebbPruned = s.graph.HebbianDecay(1.0, 1, elapsed)
			s.lastDecay = time.Now()
			if hebbDecayed > 0 {
				log.Printf("Dream: Hebbian decay elapsed=%.1fh decayed=%d pruned=%d",
					elapsed.Hours(), hebbDecayed, hebbPruned)
			}
		}

		// Flush high-weight edges xuống disk (threshold=5: đã activate 5+ lần)
		// QT7: pattern lặp lại → QR (bất biến)
		if s.edgeFlusher != nil {
			highWeight := s.graph.PersistHighWeightEdges(5)
			for _, e := range highWeight {
				var src, dst [8]byte
				binary.BigEndian.PutUint64(src[:], e.Src.Uint64())
				binary.BigEndian.PutUint64(dst[:], e.Dst.Uint64())
				if err := s.edgeFlusher(src, dst, e.Type, e.Weight); err == nil {
					hebbFlushed++
				}
			}
			if hebbFlushed > 0 {
				log.Printf("Dream: flushed %d high-weight edges to disk", hebbFlushed)
			}
		}
	}

	return SkillResult{
		Message: outMsg,
		Data: map[string]interface{}{
			"dream.proposed":      promoted,
			"dream.deleted":       deleted,
			"dream.checked":       len(all),
			"dream.hebb_decayed":  hebbDecayed,
			"dream.hebb_pruned":   hebbPruned,
			"dream.hebb_flushed":  hebbFlushed,
		},
	}
}

// ── ScheduleDreamSkill (mới) — kiểm chứng schedule patterns ─

type DreamInsight struct {
	Space      gene.SpaceType
	Hour       int
	Action     gene.ActionVerb
	Confidence float64
	SeenCount  int
	Verdict    string // "PROMOTE" | "UNCERTAIN" | "CONFLICT"
}

type ScheduleDreamSkill struct {
	learner *ScheduleLearnerSkill
}

func NewScheduleDreamSkill(learner *ScheduleLearnerSkill) *ScheduleDreamSkill {
	return &ScheduleDreamSkill{learner: learner}
}

func (s *ScheduleDreamSkill) Name() string { return "schedule_dream" }

func (s *ScheduleDreamSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgDream
}

func (s *ScheduleDreamSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	insights := s.analyze()

	promotes, conflicts, uncertain := 0, 0, 0
	for _, ins := range insights {
		switch ins.Verdict {
		case "PROMOTE":  promotes++
		case "CONFLICT": conflicts++
		case "UNCERTAIN": uncertain++
		}
	}

	ctx.State["dream_insights"] = insights
	ctx.State["dream_promotes"] = promotes

	return SkillResult{
		Data: map[string]interface{}{
			"insights":  len(insights),
			"promotes":  promotes,
			"conflicts": conflicts,
			"uncertain": uncertain,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgPropose,
			Payload: encodePayload(map[string]interface{}{
				"dream_summary": fmt.Sprintf(
					"%d patterns: %d promote, %d conflict, %d uncertain",
					len(insights), promotes, conflicts, uncertain),
				"insights": insights,
			}),
		},
	}
}

func (s *ScheduleDreamSkill) analyze() []DreamInsight {
	var insights []DreamInsight
	for space, hours := range s.learner.buckets {
		for hour, b := range hours {
			action, conf := b.DominantAction()
			verdict := "UNCERTAIN"
			switch {
			case conf >= 0.80 && b.TotalSeen >= 5:
				verdict = "PROMOTE"
			case conf < 0.45 && b.TotalSeen >= 4:
				verdict = "CONFLICT"
			}
			insights = append(insights, DreamInsight{
				Space: space, Hour: hour,
				Action: action, Confidence: conf,
				SeenCount: b.TotalSeen, Verdict: verdict,
			})
		}
	}
	return insights
}

// ── DreamProposal + methods (tương thích tests cũ) ──────────

type DreamProposal struct {
	Label         string
	Evidence      []string
	Confidence    float64
	Source        Source
	ConsequenceYes string
}

func (p DreamProposal) Summary() string {
	return p.Label + " (" + fmt.Sprintf("%.2f", p.Confidence) + ")"
}

func (s *DreamSkill) SetMinIdle(d interface{})  {}
func (s *DreamSkill) ResetLastRun()              {}

func (s *DreamSkill) PendingProposals() []DreamProposal {
	if s.dn == nil { return nil }
	var out []DreamProposal
	for _, c := range s.dn.Candidates(0.70) {
		out = append(out, DreamProposal{
			Label:      string(fmt.Sprintf("%v", c.ISL)[:]),
			Evidence:   []string{"observed"},
			Confidence: c.Confidence,
			Source:     SourceRealNow,
		})
	}
	return out
}

func (s *DreamSkill) ApproveProposal(label string) (*isl.ISLMessage, error) {
	if s.dn == nil || s.qr == nil {
		return &isl.ISLMessage{MsgType: isl.MsgPropose, Payload: []byte(label)}, nil
	}
	all := s.dn.All()

	// Tìm exact match trước
	for _, o := range all {
		if o.ISL.String() == label || o.Label == label {
			o.Confidence = 0.85 // boost để pass LongTerm threshold
			if err := s.qr.Commit(o); err != nil {
				return nil, err
			}
			return &isl.ISLMessage{MsgType: isl.MsgPropose, Payload: []byte(label)}, nil
		}
	}

	// Không tìm thấy → commit cái có confidence cao nhất (không phải Fiction)
	best, bestConf := -1, 0.0
	for i, o := range all {
		if o.SrcType == uint8(SourceFiction) { continue }
		if o.Confidence > bestConf {
			best, bestConf = i, o.Confidence
		}
	}
	if best >= 0 {
		o := all[best]
		o.Confidence = 0.85
		if err := s.qr.Commit(o); err != nil {
			return nil, err
		}
		return &isl.ISLMessage{MsgType: isl.MsgPropose, Payload: []byte(label)}, nil
	}
	return &isl.ISLMessage{MsgType: isl.MsgPropose, Payload: []byte(label)}, nil
}

func (s *DreamSkill) RejectProposal(label, reason string) *isl.ISLMessage {
	return &isl.ISLMessage{MsgType: isl.MsgDeactivate, Payload: []byte(label+":"+reason)}
}
