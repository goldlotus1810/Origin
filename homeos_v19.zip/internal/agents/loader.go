// internal/agents/loader.go
//
// AgentLoader — spawn agents từ homeos.olang graph
//
// QT4: Agent == tập hợp Skill của nó (không hơn không kém)
//
// Cách đọc:
//   1. AGENT_* nodes (L7 QR) — DNA = "tier=N|role=X"
//   2. HAS_SKILL edges (type=0x01) — AGENT → SKILL
//   3. SKILL_* nodes (L7 QR) — DNA có "handler=X"
//   4. handler name → Go Skill runtime
//
// Thay đổi so với thiết kế cũ:
//   CŨ: DNA text "skills=SKILL_A,SKILL_B" — Agent biết tên skill
//   MỚI: Edge AGENT──0x01──►SKILL — Index là đồ thị, không phải string

package agents

import (
	"log"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

const EdgeHasSkill uint8 = 0x01

// AgentLoader đọc olang graph → spawn agents
type AgentLoader struct {
	graph    *silk.SilkGraph
	codec    *isl.ISLCodec
	bus      chan *isl.ISLMessage
	registry *AgentRegistry
	dn       *memory.ShortTerm
	qr       *memory.LongTerm
}

func NewAgentLoader(g *silk.SilkGraph, c *isl.ISLCodec,
	b chan *isl.ISLMessage, r *AgentRegistry) *AgentLoader {
	return &AgentLoader{graph: g, codec: c, bus: b, registry: r}
}

// WithMemory gắn ShortTerm + LongTerm để ClusterSkill/DreamSkill dùng
func (l *AgentLoader) WithMemory(dn *memory.ShortTerm, qr *memory.LongTerm) *AgentLoader {
	l.dn = dn
	l.qr = qr
	return l
}

// AgentDef — 1 agent đã resolve từ olang graph
type AgentDef struct {
	Name   string
	ID     string
	Skills []SkillDef        // từ HAS_SKILL edges
	Params map[string]string // từ AGENT node DNA
}

// SkillDef — 1 skill node đã resolve
type SkillDef struct {
	NodeName string
	Handler  string // từ DNA "handler=X" — bất biến
	Params   map[string]string
}

// SpawnFromOlang — đọc AGENT_* + HAS_SKILL edges → spawn agents
func (l *AgentLoader) SpawnFromOlang(ctx interface{ Done() <-chan struct{} }) map[string]*Agent {
	defs := l.resolveAgents()
	result := map[string]*Agent{}
	if len(defs) == 0 {
		log.Println("○ AgentLoader: không tìm thấy AGENT nodes trong olang")
		return result
	}
	for _, def := range defs {
		if l.registry.Has(def.ID) {
			log.Printf("○ AgentLoader: skip %-14s (đã tồn tại)", def.ID)
			continue
		}
		a := l.buildAgent(def)
		if a == nil { continue }
		a.RegisterTo(l.registry)
		a.RunAsyncCtx(ctx)

		handlers := make([]string, len(def.Skills))
		for i, s := range def.Skills { handlers[i] = s.Handler }
		log.Printf("○ AgentLoader: spawned %-14s handlers=%v", def.ID, handlers)
		result[def.ID] = a
	}
	return result
}

// resolveAgents — traverse graph: AGENT nodes + HAS_SKILL edges → AgentDef list
func (l *AgentLoader) resolveAgents() []AgentDef {
	nodes := l.graph.AllNodeValues() // []silk.OlangNode (value, safe)
	edges := l.graph.AllOlangEdges() // []silk.OlangEdge{Src,Dst,Type}

	// ISL bytes → node (dùng để resolve edge dst)
	type mini struct{ name, dna string }
	byISL := map[[8]byte]mini{}
	for _, n := range nodes {
		byISL[toKey(n.Addr)] = mini{n.Name, n.DNA}
	}

	var defs []AgentDef
	seen := map[string]bool{}

	for _, n := range nodes {
		if !strings.HasPrefix(n.Name, "AGENT_") { continue }
		if strings.HasSuffix(n.Name, "_DEF") { continue } // nodes cũ

		agID := agentID(n.Name)
		if seen[agID] { continue }
		seen[agID] = true

		def := AgentDef{
			Name:   n.Name,
			ID:     agID,
			Params: parseDNA(n.DNA),
		}

		// Traverse HAS_SKILL edges từ agent này
		agentKey := toKey(n.Addr)
		for _, e := range edges {
			if e.Type != EdgeHasSkill { continue }
			if toKey(e.Src) != agentKey { continue }

			skill, ok := byISL[toKey(e.Dst)]
			if !ok || !strings.HasPrefix(skill.name, "SKILL_") { continue }

			params := parseDNA(skill.dna)
			handler := params["handler"]
			if handler == "" {
				handler = strings.ToLower(strings.TrimPrefix(skill.name, "SKILL_"))
			}
			def.Skills = append(def.Skills, SkillDef{
				NodeName: skill.name,
				Handler:  handler,
				Params:   params,
			})
		}

		defs = append(defs, def)
	}
	return defs
}

// buildAgent — tạo Agent từ AgentDef
func (l *AgentLoader) buildAgent(def AgentDef) *Agent {
	inbox := make(chan *isl.ISLMessage, 32)
	a := New(def.ID, l.codec, inbox, l.bus)
	// Set tier từ DNA params
	switch def.Params["tier"] {
	case "0": a.tier = 0
	case "1": a.tier = 1
	case "2": a.tier = 2
	}
	for _, sk := range def.Skills {
		if s := l.mapHandler(sk, def.Params); s != nil {
			a.AddSkill(s)
		}
	}
	if len(a.skills) == 0 {
		log.Printf("○ AgentLoader: %s — no skills mapped, skip", def.ID)
		return nil
	}
	return a
}

// mapHandler — handler string → Go Skill runtime
// handler là bất biến, không đổi khi rename node
func (l *AgentLoader) mapHandler(sk SkillDef, agentParams map[string]string) Skill {
	loc := agentParams["location"]
	if loc == "" { loc = sk.Params["location"] }

	switch sk.Handler {
	// AAM
	case "brain.listen", "brain.respond":
		return &NoopSkill{name: sk.Handler}
	case "bus.broadcast":
		return &BroadcastSkill{}
	case "security.gate", "agent.heartbeat":
		return &HeartbeatSkill{}

	// LeoAI — learning skills thật
	case "learn.cluster":
		return NewClusterSkill(l.dn, l.qr, l.graph)
	case "learn.dream":
		return NewDreamSkill(l.dn, l.qr, l.graph)
	case "learn.dn_fire":
		return NewDNFireSkill(l.dn, l.qr)
	case "learn.teach":
		return NewTeachSkill(l.dn, l.qr)
	case "learn.index":
		return &IndexSkill{}

	// Chief
	case "chief.route":
		return NewHomeChief(l.registry)
	case "chief.aggregate":
		return &NoopSkill{name: sk.Handler}

	// Actuators
	case "actuator.light":
		if loc == "" { loc = "all" }
		return NewActuatorLight(loc)
	case "actuator.hvac":
		if loc == "" { loc = "all" }
		return NewActuatorHvacSkill(loc, gene.SpaceType(loc))
	case "actuator.lock":
		if loc == "" { loc = "all" }
		return NewActuatorLock(loc)

	default:
		log.Printf("⚠ AgentLoader: handler %q chưa có runtime (node=%s)", sk.Handler, sk.NodeName)
		return &NoopSkill{name: sk.Handler}
	}
}

// ── Helpers ───────────────────────────────────────────────────

// toKey — dùng 4 bytes đầu (Layer/Group/Type/ID) làm key
// Attributes (bytes 4-7) là random ISL routing, không dùng để identify node
func toKey(addr isl.Address) [8]byte {
	return [8]byte{addr.Layer, addr.Group, addr.Type, addr.ID}
}

func parseDNA(dna string) map[string]string {
	m := map[string]string{}
	for _, part := range strings.Split(dna, "|") {
		kv := strings.SplitN(part, "=", 2)
		if len(kv) == 2 {
			m[strings.TrimSpace(kv[0])] = strings.TrimSpace(kv[1])
		}
	}
	return m
}

func agentID(name string) string {
	s := strings.TrimPrefix(name, "AGENT_")
	s = strings.TrimSuffix(s, "_DEF")
	return strings.ToLower(s)
}

func (r *AgentRegistry) Has(id string) bool {
	r.mu.RLock(); defer r.mu.RUnlock()
	_, ok := r.agents[id]
	return ok
}

// ── NoopSkill ─────────────────────────────────────────────────

type NoopSkill struct{ name string }
func (s *NoopSkill) Name() string                                           { return s.name }
func (s *NoopSkill) CanHandle(_ *isl.ISLMessage) bool                      { return false }
func (s *NoopSkill) Execute(_ *ExecContext, _ *isl.ISLMessage) SkillResult { return SkillResult{} }

// Stub actuators — HVAC moved to skill_actuator_hvac.go

type ActuatorLockSkill struct{ Location string }
func NewActuatorLock(loc string) *ActuatorLockSkill { return &ActuatorLockSkill{loc} }
func (s *ActuatorLockSkill) Name() string { return "actuator.lock." + s.Location }
func (s *ActuatorLockSkill) CanHandle(msg *isl.ISLMessage) bool {
	return (msg.MsgType == isl.MsgActivate || msg.MsgType == isl.MsgDeactivate) &&
		msg.PrimaryAddr.Group == 'A'
}
func (s *ActuatorLockSkill) Execute(_ *ExecContext, msg *isl.ISLMessage) SkillResult {
	state := "LOCK"; if msg.MsgType == isl.MsgDeactivate { state = "UNLOCK" }
	log.Printf("🔒 Lock[%s]: %s", s.Location, state)
	return SkillResult{}
}
