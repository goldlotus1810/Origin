package agents

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestKnowledgeVersionControl(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  KNOWLEDGE VERSION CONTROL                                  ║")
	t.Log("║  LeoAI → AAM → Chief → Worker (chỉ forward nếu mới hơn)   ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── 3 tier stores ─────────────────────────────────────────
	aamStore   := NewKnowledgeStore("aam")
	chiefStore := NewKnowledgeStore("home_chief")
	// Worker chỉ nhận qua ActuatorLightSkill + schedule

	aamRouter   := NewKnowledgeRouterSkill("aam",        TierServer)
	chiefRouter := NewKnowledgeRouterSkill("home_chief", TierHub)
	light       := NewActuatorLightSkill("light_living",  gene.SpaceLivingRoom)

	aamCtx   := &ExecContext{State: make(map[string]interface{})}
	chiefCtx := &ExecContext{State: make(map[string]interface{})}
	lightCtx := &ExecContext{State: make(map[string]interface{})}

	_ = aamStore
	_ = chiefStore

	// ── Helper: tạo KnowledgePacket từ LeoAI ─────────────────
	makeKnowledge := func(skill string, ver Version, sched []ScheduleEntry, changelog string) *isl.ISLMessage {
		raw, _ := json.Marshal(sched)
		pkt := KnowledgePacket{
			SkillName:  skill,
			Version:    ver,
			TargetRole: RoleActuator,
			TargetISL:  "HAb1",
			Payload:    raw,
			PacketType: PacketSchedule,
			CreatedAt:  time.Now(),
			CreatedBy:  "leoai",
			Changelog:  changelog,
		}
		return &isl.ISLMessage{
			MsgType: isl.MsgKnowledge,
			Payload: encodePayload(pkt),
		}
	}

	// ── Scenario 1: Onboard mới — chưa có version nào ────────
	t.Log("[ SCENARIO 1 ] Onboard mới — LeoAI gửi v1.0.0")
	t.Log()

	sched_v1 := []ScheduleEntry{
		{Hour: 7, Level: 0.80}, {Hour: 23, Level: 0.0},
	}
	msg_v1 := makeKnowledge("actuator_light", Version{1,0,0}, sched_v1,
		"initial schedule: morning on, night off")

	// AAM nhận từ LeoAI
	r_aam1 := aamRouter.Execute(aamCtx, msg_v1)
	t.Logf("  LeoAI → AAM:   %s", r_aam1.Data["knowledge_log"])
	t.Logf("  Decision:      %s", r_aam1.Data["knowledge_decision"])

	// AAM forward xuống Chief
	r_chief1 := chiefRouter.Execute(chiefCtx, r_aam1.Message)
	t.Logf("  AAM → Chief:   %s", r_chief1.Data["knowledge_log"])

	// Chief forward xuống Worker (LightAgent)
	if r_chief1.Message != nil {
		var kpkt KnowledgePacket
		decodePayload(r_chief1.Message.Payload, &kpkt)
		syncMsg := &isl.ISLMessage{
			MsgType: isl.MsgSync,
			Payload: encodePayload(kpkt.ToLearnPacket()),
		}
		if light.CanHandle(syncMsg) {
			r_light1 := light.Execute(lightCtx, syncMsg)
			t.Logf("  Chief → Light: %d entries loaded", r_light1.Data["schedule_entries"])
			t.Logf("  h07=%.0f%% h23=%.0f%%",
				light.scheduleLevel(7)*100, light.scheduleLevel(23)*100)
		}
	}
	t.Log()

	// ── Scenario 2: LeoAI học thêm → v1.1.0 ─────────────────
	t.Log("[ SCENARIO 2 ] LeoAI học thêm → v1.1.0 (thêm 18h)")

	sched_v11 := []ScheduleEntry{
		{Hour: 7, Level: 0.80}, {Hour: 18, Level: 0.90}, {Hour: 23, Level: 0.0},
	}
	msg_v11 := makeKnowledge("actuator_light", Version{1,1,0}, sched_v11,
		"learned: cooking at 18h needs bright light")

	r_aam2 := aamRouter.Execute(aamCtx, msg_v11)
	t.Logf("  LeoAI → AAM:   %s", r_aam2.Data["knowledge_log"])

	r_chief2 := chiefRouter.Execute(chiefCtx, r_aam2.Message)
	t.Logf("  AAM → Chief:   %s", r_chief2.Data["knowledge_log"])

	if r_chief2.Message != nil {
		var kpkt KnowledgePacket
		decodePayload(r_chief2.Message.Payload, &kpkt)
		syncMsg := &isl.ISLMessage{
			MsgType: isl.MsgSync,
			Payload: encodePayload(kpkt.ToLearnPacket()),
		}
		r_light2 := light.Execute(lightCtx, syncMsg)
		t.Logf("  Chief → Light: %d entries loaded", r_light2.Data["schedule_entries"])
		t.Logf("  h07=%.0f%% h18=%.0f%% h23=%.0f%%",
			light.scheduleLevel(7)*100,
			light.scheduleLevel(18)*100,
			light.scheduleLevel(23)*100)
	}
	t.Log()

	// ── Scenario 3: Gửi lại v1.0.0 (cũ hơn) → bỏ qua ───────
	t.Log("[ SCENARIO 3 ] Gửi lại v1.0.0 → REJECT (cũ hơn v1.1.0)")

	r_aam3 := aamRouter.Execute(aamCtx, msg_v1)
	t.Logf("  AAM decision:  %s ← đúng", r_aam3.Data["knowledge_decision"])
	if r_aam3.Message != nil {
		t.Error("✗ AAM không nên forward v1.0.0")
	} else {
		t.Log("  ✓ không forward xuống Chief")
	}
	t.Log()

	// ── Scenario 4: Gửi lại v1.1.0 (đã có) → skip ───────────
	t.Log("[ SCENARIO 4 ] Gửi lại v1.1.0 → SKIP (đã có rồi)")

	r_aam4 := aamRouter.Execute(aamCtx, msg_v11)
	t.Logf("  AAM decision:  %s ← đúng", r_aam4.Data["knowledge_decision"])
	if r_aam4.Message != nil {
		t.Error("✗ AAM không nên forward khi đã có version này")
	} else {
		t.Log("  ✓ không tốn bandwidth")
	}
	t.Log()

	// ── Scenario 5: v2.0.0 major update ─────────────────────
	t.Log("[ SCENARIO 5 ] v2.0.0 — major update (thêm dim curve)")

	sched_v2 := []ScheduleEntry{
		{Hour: 6, Level: 0.30}, {Hour: 7, Level: 0.80},
		{Hour: 12, Level: 0.60}, {Hour: 18, Level: 0.90},
		{Hour: 21, Level: 0.40}, {Hour: 23, Level: 0.0},
	}
	msg_v2 := makeKnowledge("actuator_light", Version{2,0,0}, sched_v2,
		"major: full day dim curve learned from 30 days")

	r_aam5 := aamRouter.Execute(aamCtx, msg_v2)
	r_chief5 := chiefRouter.Execute(chiefCtx, r_aam5.Message)
	t.Logf("  LeoAI → AAM → Chief: %s", r_chief5.Data["knowledge_log"])

	if r_chief5.Message != nil {
		var kpkt KnowledgePacket
		decodePayload(r_chief5.Message.Payload, &kpkt)
		syncMsg := &isl.ISLMessage{
			MsgType: isl.MsgSync,
			Payload: encodePayload(kpkt.ToLearnPacket()),
		}
		r_light5 := light.Execute(lightCtx, syncMsg)
		t.Logf("  Light: %d entries", r_light5.Data["schedule_entries"])
		t.Logf("  h06=%.0f%% h12=%.0f%% h21=%.0f%%",
			light.scheduleLevel(6)*100,
			light.scheduleLevel(12)*100,
			light.scheduleLevel(21)*100)
	}
	t.Log()

	t.Log("[ VERSION HISTORY ]")
	t.Logf("  actuator_light: v1.0.0 → v1.1.0 → v2.0.0")
	t.Log("  QT8: lịch sử bất biến — không xóa version cũ")
	t.Log()
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("  KNOWLEDGE VERSION CONTROL PASS")
	t.Log("  LeoAI → AAM → Chief → Worker")
	t.Log("  Forward chỉ khi ver mới hơn — không tốn bandwidth")

	// Verify final state
	if light.scheduleLevel(6) != 0.30 {
		t.Errorf("✗ v2.0.0 không được áp dụng: h06=%.0f%%", light.scheduleLevel(6)*100)
	}
}
