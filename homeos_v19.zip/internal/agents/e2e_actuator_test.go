// internal/agents/e2e_actuator_test.go
//
// End-to-end test: "tắt đèn phòng khách"
// Pipeline: aamInbox → AAMRouterSkill → home_chief → light_living → ActuatorLight
//
// Kiểm tra QT5: lệnh đi đúng tầng, không bypass.

package agents

import (
	"context"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestE2EActuatorPipeline(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	codec    := isl.NewPlainCodec()
	bus      := make(chan *isl.ISLMessage, 32)
	registry := NewAgentRegistry()

	// === Tier 2: Light worker ===
	lightExecuted := make(chan string, 1)
	lightSkill := &testLightSkill{executed: lightExecuted}

	light := New("light_living", codec, make(chan *isl.ISLMessage, 8), bus).
		AddSkill(lightSkill).
		RegisterTo(registry)
	light.RunAsyncCtx(ctx)

	// === Tier 1: HomeChief ===
	chief := New("home_chief", codec, make(chan *isl.ISLMessage, 8), bus).
		AddSkill(NewHomeChief(registry)).
		RegisterTo(registry)
	chief.RunAsyncCtx(ctx)

	// === Tier 0: AAM ===
	aamInbox := make(chan *isl.ISLMessage, 8)
	aam := New("aam", codec, aamInbox, bus).
		AddSkill(&BroadcastSkill{}).
		AddSkill(NewAAMRouterSkill(registry)).
		RegisterTo(registry)
	aam.RunAsyncCtx(ctx)

	// Gửi MsgActuatorCmd vào aamInbox (simulate từ HTTP/brain)
	msg := &isl.ISLMessage{
		Version:     1,
		MsgType:     isl.MsgActuatorCmd,
		PrimaryAddr: isl.AddrHomeChief,
		Payload:     []byte("off:light:living_room"),
	}
	aamInbox <- msg

	// Chờ LightAgent thực thi
	select {
	case action := <-lightExecuted:
		t.Logf("✅ E2E: light_living received action=%q", action)
		if action != "off" {
			t.Errorf("expected action=off, got %q", action)
		}
	case <-ctx.Done():
		t.Error("❌ timeout: light_living không nhận được lệnh qua AAM→Chief→Worker pipeline")
	}
}

func TestE2EActuatorBroadcast(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	codec    := isl.NewPlainCodec()
	bus      := make(chan *isl.ISLMessage, 32)
	registry := NewAgentRegistry()

	// 2 light workers
	ch1 := make(chan string, 1)
	ch2 := make(chan string, 1)

	New("light_living", codec, make(chan *isl.ISLMessage, 8), bus).
		AddSkill(&testLightSkill{executed: ch1}).
		RegisterTo(registry).RunAsyncCtx(ctx)
	New("light_bed", codec, make(chan *isl.ISLMessage, 8), bus).
		AddSkill(&testLightSkill{executed: ch2}).
		RegisterTo(registry).RunAsyncCtx(ctx)

	// HomeChief + AAM
	New("home_chief", codec, make(chan *isl.ISLMessage, 8), bus).
		AddSkill(NewHomeChief(registry)).
		RegisterTo(registry).RunAsyncCtx(ctx)

	aamInbox := make(chan *isl.ISLMessage, 8)
	New("aam", codec, aamInbox, bus).
		AddSkill(NewAAMRouterSkill(registry)).
		RegisterTo(registry).RunAsyncCtx(ctx)

	// Broadcast: tắt tất cả đèn
	aamInbox <- &isl.ISLMessage{
		Version:     1,
		MsgType:     isl.MsgActuatorCmd,
		PrimaryAddr: isl.AddrHomeChief,
		Payload:     []byte("off:light:all"),
	}

	received := 0
	deadline := time.After(2 * time.Second)
	for received < 2 {
		select {
		case a := <-ch1:
			t.Logf("✅ light_living: %q", a)
			received++
		case a := <-ch2:
			t.Logf("✅ light_bed: %q", a)
			received++
		case <-deadline:
			t.Errorf("❌ timeout: chỉ nhận %d/2 workers", received)
			return
		}
	}
	t.Logf("✅ broadcast all: %d workers executed", received)
}

// testLightSkill — stub ActuatorLight cho test
type testLightSkill struct {
	executed chan string
}

func (s *testLightSkill) Name() string { return "actuator.light.test" }

func (s *testLightSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgActivate || msg.MsgType == isl.MsgDeactivate
}

func (s *testLightSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	action := "on"
	if msg.MsgType == isl.MsgDeactivate {
		action = "off"
	}
	select {
	case s.executed <- action:
	default:
	}
	return SkillResult{}
}
