// ErrorCollectorSkill + AppLauncherSkill
// Anchor: SYS_PROCESS (⚙ U+2699)
package agents

import (
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ── ErrorCollectorSkill ───────────────────────────────────────

type ErrorEntry struct {
	At      time.Time
	Level   string // "error" | "warn" | "critical"
	Source  string // skill/agent/system
	Message string
	Count   int // số lần lặp
}

type ErrorCollectorSkill struct {
	errors  []ErrorEntry
	maxLen  int
	dedup   map[string]*ErrorEntry // message → entry (dedup)
}

func NewErrorCollectorSkill() *ErrorCollectorSkill {
	return &ErrorCollectorSkill{
		maxLen: 512,
		dedup:  make(map[string]*ErrorEntry),
	}
}

func (s *ErrorCollectorSkill) Name() string { return "error_collector" }

func (s *ErrorCollectorSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgKnowledge
}

func (s *ErrorCollectorSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	body := strings.TrimSpace(string(msg.Payload))
	if body == "" {
		return SkillResult{}
	}

	level := "info"
	if strings.Contains(body, "critical") || strings.Contains(body, "CRITICAL") {
		level = "critical"
	} else if strings.Contains(body, "⚠") || strings.Contains(body, "error") || strings.Contains(body, "Error") {
		level = "error"
	} else if strings.Contains(body, "warn") || strings.Contains(body, "Warn") {
		level = "warn"
	}

	// Dedup
	key := body[:min(80, len(body))]
	if existing, ok := s.dedup[key]; ok {
		existing.Count++
		existing.At = time.Now()
	} else {
		entry := &ErrorEntry{
			At:      time.Now(),
			Level:   level,
			Source:  "homeos",
			Message: body,
			Count:   1,
		}
		s.errors = append(s.errors, *entry)
		s.dedup[key] = &s.errors[len(s.errors)-1]
		if len(s.errors) > s.maxLen {
			s.errors = s.errors[1:]
		}
	}

	ctx.State["errors.total"]    = len(s.errors)
	ctx.State["errors.last"]     = body[:min(120, len(body))]
	ctx.State["errors.last_lvl"] = level

	return SkillResult{Data: map[string]interface{}{
		"errors.total": len(s.errors),
		"errors.level": level,
	}}
}

func (s *ErrorCollectorSkill) GetByLevel(level string) []ErrorEntry {
	var out []ErrorEntry
	for _, e := range s.errors {
		if e.Level == level {
			out = append(out, e)
		}
	}
	return out
}
