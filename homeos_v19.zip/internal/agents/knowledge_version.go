// internal/agents/knowledge_version.go
//
// KnowledgePacket — versioned knowledge từ LeoAI
//
// Luồng:
//   LeoAI tạo KnowledgePacket{skill, ver, payload}
//   AAM yêu cầu → LeoAI gửi về AAM
//   AAM so sánh version → mới hơn → gửi Chief
//   Chief so sánh version → mới hơn → gửi Worker
//   Worker cập nhật
//
// Version: semantic {major.minor.patch}
//   major: thay đổi cấu trúc skill (không tương thích cũ)
//   minor: thêm rule/pattern mới (tương thích ngược)
//   patch: fix nhỏ, tune threshold
//
// QT8: Lịch sử bất biến — không xóa version cũ, chỉ append

package agents

import (
	"fmt"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ── Version ───────────────────────────────────────────────────

type Version struct {
	Major, Minor, Patch int
}

func (v Version) String() string {
	return fmt.Sprintf("v%d.%d.%d", v.Major, v.Minor, v.Patch)
}

// NewerThan: v mới hơn other không?
func (v Version) NewerThan(other Version) bool {
	if v.Major != other.Major { return v.Major > other.Major }
	if v.Minor != other.Minor { return v.Minor > other.Minor }
	return v.Patch > other.Patch
}

func (v Version) Equal(other Version) bool {
	return v.Major == other.Major && v.Minor == other.Minor && v.Patch == other.Patch
}

// ── KnowledgePacket ───────────────────────────────────────────

type KnowledgePacket struct {
	SkillName   string          `json:"skill"`       // "actuator_light"
	Version     Version         `json:"version"`
	TargetRole  DeviceRole      `json:"role"`
	TargetISL   string          `json:"isl,omitempty"` // "" = tất cả cùng role
	Payload     []byte          `json:"payload"`     // schedule/motion/audio/...
	PacketType  LearnPacketType `json:"type"`
	CreatedAt   time.Time       `json:"created_at"`
	CreatedBy   string          `json:"created_by"`  // "leocai"
	Changelog   string          `json:"changelog"`
}

func (kp *KnowledgePacket) ToLearnPacket() LearnPacket {
	return LearnPacket{
		Type:       kp.PacketType,
		TargetRole: kp.TargetRole,
		TargetISL:  kp.TargetISL,
		Payload:    kp.Payload,
	}
}

// ── KnowledgeStore — lưu version hiện tại tại mỗi tier ───────
// AAM có store của mình
// Chief có store của mình
// Worker có store của mình
// Mỗi tier tự so sánh trước khi forward

type KnowledgeStore struct {
	ownerID  string
	versions map[string]Version // skillName → current version
}

func NewKnowledgeStore(ownerID string) *KnowledgeStore {
	return &KnowledgeStore{
		ownerID:  ownerID,
		versions: make(map[string]Version),
	}
}

type UpdateDecision int

const (
	UpdateApply   UpdateDecision = iota // mới hơn → cập nhật + forward
	UpdateSkip                          // đã có version này rồi
	UpdateReject                        // cũ hơn → bỏ qua
)

func (d UpdateDecision) String() string {
	return [...]string{"apply", "skip", "reject"}[d]
}

// Decide: có nên cập nhật không?
func (ks *KnowledgeStore) Decide(pkt *KnowledgePacket) UpdateDecision {
	current, exists := ks.versions[pkt.SkillName]
	if !exists {
		return UpdateApply // chưa có → luôn lấy
	}
	if pkt.Version.NewerThan(current) {
		return UpdateApply
	}
	if pkt.Version.Equal(current) {
		return UpdateSkip
	}
	return UpdateReject // gói đến cũ hơn hiện tại → bỏ
}

// Apply: lưu version mới
func (ks *KnowledgeStore) Apply(pkt *KnowledgePacket) {
	ks.versions[pkt.SkillName] = pkt.Version
}

func (ks *KnowledgeStore) CurrentVersion(skillName string) (Version, bool) {
	v, ok := ks.versions[skillName]
	return v, ok
}

// ── KnowledgeRouterSkill — sống tại AAM và Chief ─────────────
// Nhận KnowledgePacket từ LeoAI (nếu là AAM)
// hoặc từ AAM (nếu là Chief)
// So sánh version → forward xuống nếu mới hơn

type KnowledgeRouterSkill struct {
	ownerID string
	store   *KnowledgeStore
	tier    Tier
}

func NewKnowledgeRouterSkill(ownerID string, tier Tier) *KnowledgeRouterSkill {
	return &KnowledgeRouterSkill{
		ownerID: ownerID,
		store:   NewKnowledgeStore(ownerID),
		tier:    tier,
	}
}

func (s *KnowledgeRouterSkill) Name() string {
	return fmt.Sprintf("knowledge_router:%s", s.ownerID)
}

func (s *KnowledgeRouterSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg.MsgType != isl.MsgKnowledge { return false }
	var pkt KnowledgePacket
	return decodePayload(msg.Payload, &pkt) == nil && pkt.SkillName != ""
}

func (s *KnowledgeRouterSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var pkt KnowledgePacket
	if err := decodePayload(msg.Payload, &pkt); err != nil {
		return SkillResult{}
	}

	decision := s.store.Decide(&pkt)
	currentVer, _ := s.store.CurrentVersion(pkt.SkillName)

	logEntry := fmt.Sprintf("%s: %s %s→%s [%s]",
		s.ownerID, pkt.SkillName,
		currentVer, pkt.Version, decision)

	if decision != UpdateApply {
		return SkillResult{
			Data: map[string]interface{}{
				"knowledge_decision": decision.String(),
				"knowledge_log":      logEntry,
			},
		}
	}

	// Cập nhật store
	s.store.Apply(&pkt)

	// Forward xuống tier dưới
	return SkillResult{
		Data: map[string]interface{}{
			"knowledge_decision": decision.String(),
			"knowledge_updated":  pkt.SkillName,
			"knowledge_version":  pkt.Version.String(),
			"knowledge_log":      logEntry,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgKnowledge, // tiếp tục forward xuống
			Payload: encodePayload(pkt),
		},
	}
}

