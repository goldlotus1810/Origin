package agents

import (
	"os"
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestTrafficMonitor_DefaultRules(t *testing.T) {
	s := NewTrafficMonitorSkill("light_living", "192.168.1.100")
	if len(s.rules) == 0 {
		t.Fatal("should have default rules")
	}
	// Rule cuối phải là default deny
	last := s.rules[len(s.rules)-1]
	if last.Allow {
		t.Error("last rule should be default deny")
	}
	t.Logf("Default rules: %d rules, last=%q", len(s.rules), last.Reason)
}

func TestTrafficMonitor_EvaluateLAN(t *testing.T) {
	s := NewTrafficMonitorSkill("light_living", "192.168.1.100").
		WithLAN("192.168.1.0/24")

	// LAN traffic → allowed
	ev := TrafficEvent{
		DeviceIP: "192.168.1.100", RemoteIP: "192.168.1.1",
		RemotePort: 8080, Protocol: "tcp", Direction: "out",
	}
	allowed, reason := s.evaluate(ev)
	if !allowed {
		t.Errorf("LAN traffic should be allowed, reason: %s", reason)
	}
	t.Logf("LAN: allowed=%v reason=%q", allowed, reason)
}

func TestTrafficMonitor_EvaluateCloud(t *testing.T) {
	s := NewTrafficMonitorSkill("light_living", "192.168.1.100").
		WithLAN("192.168.1.0/24")

	// Cloud traffic (8.8.8.8) → denied
	ev := TrafficEvent{
		DeviceIP: "192.168.1.100", RemoteIP: "8.8.8.8",
		RemotePort: 443, Protocol: "tcp", Direction: "out",
	}
	allowed, reason := s.evaluate(ev)
	if allowed {
		t.Errorf("Cloud traffic should be blocked, reason: %s", reason)
	}
	t.Logf("Cloud: allowed=%v reason=%q", allowed, reason)
}

func TestTrafficMonitor_EvaluateDNS(t *testing.T) {
	s := NewTrafficMonitorSkill("light_living", "192.168.1.100")

	// DNS (port 53 UDP) → allowed
	ev := TrafficEvent{
		DeviceIP: "192.168.1.100", RemoteIP: "8.8.8.8",
		RemotePort: 53, Protocol: "udp", Direction: "out",
	}
	allowed, reason := s.evaluate(ev)
	if !allowed {
		t.Errorf("DNS should be allowed, reason: %s", reason)
	}
	t.Logf("DNS: allowed=%v reason=%q", allowed, reason)
}

func TestTrafficMonitor_NewRule(t *testing.T) {
	s := NewTrafficMonitorSkill("light_living", "192.168.1.100")

	// AAM cấp phép thêm: cho phép kết nối Philips server để update
	rule := TrafficRule{
		RemoteIP: "185.60.112.0/24", RemotePort: 443,
		Protocol: "tcp", Direction: "out",
		Allow: true, Reason: "Philips Hue OTA update — approved by AAM",
	}
	payload := encodePayload(rule)
	result := s.Execute(&ExecContext{State: make(map[string]interface{})},
		&isl.ISLMessage{MsgType: isl.MsgApproved, Payload: payload})

	if result.Data["rule_added"] == nil {
		t.Error("rule should be added")
	}
	t.Logf("New rule: %v", result.Data["rule_added"])

	// Check rule mới có effect
	ev := TrafficEvent{
		RemoteIP: "185.60.112.100", RemotePort: 443,
		Protocol: "tcp", Direction: "out",
	}
	allowed, reason := s.evaluate(ev)
	if !allowed {
		t.Errorf("Philips OTA should be allowed after rule, reason: %s", reason)
	}
	t.Logf("Philips OTA: allowed=%v", allowed)
}

func TestTrafficMonitor_ViolationCallback(t *testing.T) {
	violations := []TrafficEvent{}
	s := NewTrafficMonitorSkill("test_device", "192.168.1.200").
		WithLAN("192.168.1.0/24").
		WithViolationCallback(func(ev TrafficEvent) {
			violations = append(violations, ev)
		})

	if s.IsIsolated() {
		t.Error("should not be isolated initially")
	}
	t.Logf("Summary: %s", s.Summary())
}

func TestTrafficMonitor_IsPrivateIP(t *testing.T) {
	cases := []struct {
		ip      string
		private bool
	}{
		{"192.168.1.100", true},
		{"10.0.0.1", true},
		{"172.16.50.1", true},
		{"8.8.8.8", false},
		{"1.1.1.1", false},
		{"185.60.112.100", false},
	}
	for _, tc := range cases {
		got := isPrivateIP(tc.ip)
		if got != tc.private {
			t.Errorf("isPrivateIP(%s): got %v, want %v", tc.ip, got, tc.private)
		}
	}
}

func TestTrafficMonitor_Report(t *testing.T) {
	s := NewTrafficMonitorSkill("light_living", "192.168.1.100")
	r := s.Report()
	if r.DeviceID != "light_living" {
		t.Errorf("DeviceID wrong: %s", r.DeviceID)
	}
	if r.Isolated {
		t.Error("should not be isolated initially")
	}
	t.Logf("Report: device=%s isolated=%v violations=%d",
		r.DeviceID, r.Isolated, r.ViolationCount)
}

// ─── FirmwareWatch Tests ────────────────────────────────────────

func TestFirmwareWatch_Init(t *testing.T) {
	s := NewFirmwareWatchSkill("light_living", "192.168.1.100")
	if s.IsQuarantined() {
		t.Error("should not be quarantined initially")
	}
	r := s.Execute(&ExecContext{State: make(map[string]interface{})},
		&isl.ISLMessage{MsgType: isl.MsgQuery})
	if r.Data["phase"] != "learning" {
		t.Errorf("initial phase should be learning, got %v", r.Data["phase"])
	}
	t.Logf("Summary: %s", s.Summary())
}

func TestFirmwareWatch_Heartbeat(t *testing.T) {
	s := NewFirmwareWatchSkill("light_living", "192.168.1.100")
	r := s.Execute(&ExecContext{State: make(map[string]interface{})},
		&isl.ISLMessage{MsgType: isl.MsgHeartbeat})
	if r.Data["heartbeat"] != "ok" {
		t.Errorf("heartbeat result wrong: %v", r.Data)
	}
	// lastHeartbeat phải được cập nhật
	s.mu.RLock()
	hb := s.lastHeartbeat
	s.mu.RUnlock()
	if time.Since(hb) > time.Second {
		t.Error("lastHeartbeat should be recent")
	}
}

func TestFirmwareWatch_LearningPhase(t *testing.T) {
	s := NewFirmwareWatchSkill("test", "192.168.1.100")
	s.learningTicks = 3
	ctx := &ExecContext{State: make(map[string]interface{})}
	tickMsg := &isl.ISLMessage{MsgType: isl.MsgTick}

	// 3 ticks → học baseline
	for i := 0; i < 3; i++ {
		r := s.Execute(ctx, tickMsg)
		if r.Data["phase"] != "learning" {
			t.Errorf("tick %d should be learning, got %v", i, r.Data["phase"])
		}
	}
	// Tick 4 → monitoring
	r := s.Execute(ctx, tickMsg)
	t.Logf("After learning: phase=%v status=%v", r.Data["phase"], r.Data["status"])
}

func TestFirmwareWatch_AnomalyDetect_TrafficSpike(t *testing.T) {
	s := NewFirmwareWatchSkill("test", "192.168.1.100")
	s.baseline = &FirmwareBehavior{
		BytesSent: 1000, BytesRecv: 500,
		UniqueRemoteIPs: 2, ResponseTimeMs: 50,
	}
	s.tickCount = s.learningTicks + 1 // skip learning

	// Snapshot với traffic spike 10x
	snap := FirmwareBehavior{
		At: time.Now(), BytesSent: 10000,
		UniqueRemoteIPs: 2, HeartbeatOK: true,
	}
	anomalies := s.detect(snap)
	found := false
	for _, a := range anomalies {
		if a.Type == AnomalyTrafficSpike {
			found = true
			t.Logf("Traffic spike detected: severity=%d detail=%q", a.Severity, a.Detail)
		}
	}
	if !found {
		t.Error("should detect traffic spike")
	}
}

func TestFirmwareWatch_AnomalyDetect_FirmwareChanged(t *testing.T) {
	s := NewFirmwareWatchSkill("test", "192.168.1.100")
	s.baseline = &FirmwareBehavior{
		FirmwareHash: "abc123def456",
		BytesSent: 100,
	}
	s.tickCount = s.learningTicks + 1

	snap := FirmwareBehavior{
		At: time.Now(), FirmwareHash: "xxx999yyy888", // hash khác
		BytesSent: 100,
	}
	anomalies := s.detect(snap)
	found := false
	for _, a := range anomalies {
		if a.Type == AnomalyFirmwareChanged {
			found = true
			if a.Severity != 3 {
				t.Errorf("FirmwareChanged should be severity 3, got %d", a.Severity)
			}
			t.Logf("Firmware changed: severity=%d detail=%q", a.Severity, a.Detail)
		}
	}
	if !found {
		t.Error("should detect firmware change")
	}
}

func TestFirmwareWatch_Quarantine_LiftedByAAM(t *testing.T) {
	s := NewFirmwareWatchSkill("test", "")
	s.mu.Lock()
	s.quarantined = true
	s.mu.Unlock()

	r := s.Execute(&ExecContext{State: make(map[string]interface{})},
		&isl.ISLMessage{MsgType: isl.MsgApproved})

	if s.IsQuarantined() {
		t.Error("quarantine should be lifted after AAM approval")
	}
	if r.Data["quarantine_lifted"] != true {
		t.Errorf("result should indicate lifted: %v", r.Data)
	}
}

// ─── Real /proc/net/tcp Tests ────────────────────────────────────

func TestParseHexAddr(t *testing.T) {
	cases := []struct {
		input    string
		wantIP   string
		wantPort int
		wantErr  bool
	}{
		{"00000000:0050", "0.0.0.0", 80, false},
		{"0101007F:1F90", "127.0.1.1", 8080, false},
		{"0F02000A:01BB", "10.0.2.15", 443, false},
		{"bad", "", 0, true},
		{"ZZZZZZZZ:0050", "", 0, true},
	}
	for _, tc := range cases {
		ip, port, err := parseHexAddr(tc.input)
		if tc.wantErr {
			if err == nil {
				t.Errorf("parseHexAddr(%q): expected error", tc.input)
			}
			continue
		}
		if err != nil {
			t.Errorf("parseHexAddr(%q): unexpected error: %v", tc.input, err)
			continue
		}
		if ip != tc.wantIP || port != tc.wantPort {
			t.Errorf("parseHexAddr(%q): got (%s, %d), want (%s, %d)",
				tc.input, ip, port, tc.wantIP, tc.wantPort)
		}
	}
}

func TestParseProcNetFile_Real(t *testing.T) {
	// Test với /proc/net/tcp thật (chỉ pass trên Linux)
	conns := readProcNetTCP()
	t.Logf("/proc/net/tcp: %d ESTABLISHED connections", len(conns))
	for _, c := range conns {
		t.Logf("  %s:%d → %s:%d  state=%s",
			c.LocalIP, c.LocalPort, c.RemoteIP, c.RemotePort, c.State)
	}
	// Không assert số lượng — có thể 0 trong sandbox
}

func TestParseProcNetFile_MockData(t *testing.T) {
	mockData := "  sl  local_address rem_address   st tx_queue rx_queue tr tm->when retrnsmt   uid  timeout inode\n" +
		"   0: 0101007F:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000     0        0 1234 1 0\n" +
		"   1: 0F02000A:0050 0101007F:C3A8 01 00000000:00000000 00:00000000 00000000  1000        0 5678 1 0\n"

	f, err := os.CreateTemp("", "proc_net_tcp_*")
	if err != nil {
		t.Fatal(err)
	}
	defer os.Remove(f.Name())
	f.WriteString(mockData)
	f.Close()

	conns := parseProcNetFile(f.Name())
	if len(conns) != 1 {
		t.Errorf("expected 1 ESTABLISHED conn, got %d", len(conns))
		return
	}
	c := conns[0]
	// 0F02000A → 10.0.2.15, 0x0050 → 80
	// 0101007F → 127.0.1.1, 0xC3A8 → 50088
	if c.LocalIP != "10.0.2.15" || c.LocalPort != 80 {
		t.Errorf("wrong local: got %s:%d", c.LocalIP, c.LocalPort)
	}
	if c.RemoteIP != "127.0.1.1" || c.RemotePort != 50088 {
		t.Errorf("wrong remote: got %s:%d want 127.0.1.1:50088", c.RemoteIP, c.RemotePort)
	}
	t.Logf("Parsed: %s:%d → %s:%d state=%s",
		c.LocalIP, c.LocalPort, c.RemoteIP, c.RemotePort, c.State)
}

func TestReadNetDevBytes_Real(t *testing.T) {
	sent, recv := readNetDevBytes()
	t.Logf("/proc/net/dev: sent=%d bytes, recv=%d bytes", sent, recv)
	// Trên Linux thật sẽ > 0; trong sandbox có thể = 0
	if sent < 0 || recv < 0 {
		t.Error("bytes should be non-negative")
	}
}
