// internal/agents/skill_ephemeral_auth.go
//
// EphemeralAuthSkill — quyền tạm thời trong 1 phiên làm việc
//
// NGUYÊN TẮC BẤT BIẾN:
//   Agent KHÔNG có quyền mặc định để:
//     - Ghi/sửa firmware
//     - Thực thi lệnh hệ thống
//     - Cập nhật Skill
//     - Xóa/sửa dữ liệu
//
//   Mọi hành động nguy hiểm cần:
//     1. Agent gửi AuthRequest lên AAM
//     2. AAM hỏi User: "Agent X muốn làm Y — cho phép không?"
//     3. User xác nhận → AAM cấp EphemeralToken{scope, ttl, session}
//     4. Agent thực hiện TRONG phiên
//     5. Phiên kết thúc → Token tự hủy → quyền thu hồi
//
//   Token KHÔNG lưu vào Silk Tree (không bất biến)
//   Token KHÔNG forward sang Agent khác
//   Token gắn với SessionID — không reuse

package agents

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ── Permission Scopes ─────────────────────────────────────────

type PermScope string

const (
	ScopeRead           PermScope = "read"            // luôn có — không cần xin
	ScopeActuate        PermScope = "actuate"          // bật/tắt thiết bị
	ScopeFirmwareRead   PermScope = "firmware:read"    // đọc firmware
	ScopeFirmwareWrite  PermScope = "firmware:write"   // ghi firmware (nguy hiểm)
	ScopeFirmwarePatch  PermScope = "firmware:patch"   // vá lỗi firmware
	ScopeSkillUpdate    PermScope = "skill:update"     // cập nhật Skill
	ScopeSystemExec     PermScope = "system:exec"      // chạy lệnh hệ thống
	ScopeNetworkWrite   PermScope = "network:write"    // thay đổi cấu hình mạng
)

func (s PermScope) RiskLevel() string {
	switch s {
	case ScopeRead, ScopeActuate:
		return "low"
	case ScopeFirmwareRead, ScopeFirmwarePatch:
		return "medium"
	case ScopeFirmwareWrite, ScopeSkillUpdate, ScopeNetworkWrite:
		return "high"
	case ScopeSystemExec:
		return "critical"
	default:
		return "unknown"
	}
}

// ── EphemeralToken ────────────────────────────────────────────

type EphemeralToken struct {
	TokenID   string
	SessionID string
	AgentID   string
	Scope     PermScope
	GrantedBy string    // "user:alice", "aam"
	GrantedAt time.Time
	ExpiresAt time.Time
	Used      int       // số lần đã dùng
	MaxUse    int       // 0 = unlimited trong TTL
	Revoked   bool
}

func (t *EphemeralToken) Valid() bool {
	return !t.Revoked &&
		time.Now().Before(t.ExpiresAt) &&
		(t.MaxUse == 0 || t.Used < t.MaxUse)
}

func (t *EphemeralToken) String() string {
	remaining := time.Until(t.ExpiresAt).Round(time.Second)
	return fmt.Sprintf("Token[%s] scope=%s ttl=%v uses=%d/%d",
		t.TokenID[:8], t.Scope, remaining, t.Used, t.MaxUse)
}

func newTokenID() string {
	b := make([]byte, 8)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// ── EphemeralAuthSkill — sống tại Agent (Worker) ─────────────

type EphemeralAuthSkill struct {
	agentID  string
	tokens   map[string]*EphemeralToken // tokenID → token
	sessions map[string][]string        // sessionID → []tokenID
}

func NewEphemeralAuthSkill(agentID string) *EphemeralAuthSkill {
	return &EphemeralAuthSkill{
		agentID:  agentID,
		tokens:   make(map[string]*EphemeralToken),
		sessions: make(map[string][]string),
	}
}

func (s *EphemeralAuthSkill) Name() string { return "ephemeral_auth" }

func (s *EphemeralAuthSkill) CanHandle(msg *isl.ISLMessage) bool {
	if MatchIntent(msg, IntentReceiveToken) {
		return true
	}
	return msg.MsgType == isl.MsgQuery // validate token query
}

func (s *EphemeralAuthSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	switch msg.MsgType {
	case isl.MsgActivate:
		return s.receiveToken(ctx, msg)
	case isl.MsgDeactivate:
		return s.revokeSession(ctx, msg)
	}
	return SkillResult{}
}

// receiveToken: AAM cấp token → Agent nhận và lưu
func (s *EphemeralAuthSkill) receiveToken(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var grant struct {
		Token     EphemeralToken `json:"token"`
		SessionID string         `json:"session_id"`
	}
	if err := decodePayload(msg.Payload, &grant); err != nil {
		return SkillResult{}
	}

	s.tokens[grant.Token.TokenID] = &grant.Token
	s.sessions[grant.SessionID] = append(
		s.sessions[grant.SessionID], grant.Token.TokenID)

	ctx.State["auth.session"] = grant.SessionID
	ctx.State["auth.tokens"]  = s.activeTokens()

	return SkillResult{
		Data: map[string]interface{}{
			"auth.granted": true,
			"auth.scope":   string(grant.Token.Scope),
			"auth.ttl":     time.Until(grant.Token.ExpiresAt).String(),
			"auth.token":   grant.Token.String(),
		},
	}
}

// revokeSession: phiên kết thúc → thu hồi tất cả token của phiên
func (s *EphemeralAuthSkill) revokeSession(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var req struct{ SessionID string `json:"session_id"` }
	decodePayload(msg.Payload, &req)

	revoked := 0
	for _, tid := range s.sessions[req.SessionID] {
		if t, ok := s.tokens[tid]; ok {
			t.Revoked = true
			revoked++
		}
	}
	delete(s.sessions, req.SessionID)

	ctx.State["auth.tokens"] = s.activeTokens()

	return SkillResult{
		Data: map[string]interface{}{
			"auth.revoked":  revoked,
			"auth.session":  req.SessionID,
			"auth.active":   len(s.activeTokens()),
		},
	}
}

// HasPermission: Skill khác gọi để kiểm tra quyền trước khi hành động
func (s *EphemeralAuthSkill) HasPermission(scope PermScope) bool {
	for _, t := range s.tokens {
		if t.Valid() && t.Scope == scope {
			t.Used++
			return true
		}
	}
	return false
}

func (s *EphemeralAuthSkill) activeTokens() []string {
	var out []string
	for _, t := range s.tokens {
		if t.Valid() { out = append(out, t.String()) }
	}
	return out
}

// ── AAMGrantSkill — sống tại AAM ─────────────────────────────
// Nhận AuthRequest từ Agent → hỏi User → cấp EphemeralToken

type AuthRequest struct {
	AgentID   string    `json:"agent_id"`
	SessionID string    `json:"session_id"`
	Scope     PermScope `json:"scope"`
	Reason    string    `json:"reason"`    // tại sao cần quyền này
	Duration  string    `json:"duration"`  // "5m", "1h", "session"
}

type AAMGrantSkill struct {
	pending  map[string]*AuthRequest  // sessionID → request
	granted  []*EphemeralToken        // lịch sử (QT8)
}

func NewAAMGrantSkill() *AAMGrantSkill {
	return &AAMGrantSkill{
		pending: make(map[string]*AuthRequest),
	}
}

func (s *AAMGrantSkill) Name() string { return "aam_grant" }

func (s *AAMGrantSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgQuery // Agent gửi AuthRequest lên AAM
}

func (s *AAMGrantSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var req AuthRequest
	if err := decodePayload(msg.Payload, &req); err != nil {
		return SkillResult{}
	}

	s.pending[req.SessionID] = &req

	// Tạo prompt cho User
	risk := req.Scope.RiskLevel()
	prompt := fmt.Sprintf(
		"[%s RISK] Agent '%s' xin quyền '%s'\n"+
			"Lý do: %s\n"+
			"Thời hạn: %s\n"+
			"Xác nhận? (gõ 'xác nhận %s' để đồng ý)",
		risk, req.AgentID, req.Scope, req.Reason, req.Duration, req.AgentID,
	)

	return SkillResult{
		Data: map[string]interface{}{
			"auth.pending": req.SessionID,
			"auth.scope":   string(req.Scope),
			"auth.risk":    risk,
		},
		// Hỏi User
		Message: &isl.ISLMessage{
			MsgType: isl.MsgQuery,
			Payload: []byte(prompt),
		},
	}
}

// GrantToken: User xác nhận → AAM tạo token → gửi xuống Agent
func (s *AAMGrantSkill) GrantToken(sessionID string, ttl time.Duration) *EphemeralToken {
	req, ok := s.pending[sessionID]
	if !ok { return nil }

	token := &EphemeralToken{
		TokenID:   newTokenID(),
		SessionID: sessionID,
		AgentID:   req.AgentID,
		Scope:     req.Scope,
		GrantedBy: "user",
		GrantedAt: time.Now(),
		ExpiresAt: time.Now().Add(ttl),
		MaxUse:    0, // unlimited trong TTL
	}

	s.granted = append(s.granted, token)
	delete(s.pending, sessionID)
	return token
}

// RevokeAll: kết thúc phiên → thu hồi tất cả
func (s *AAMGrantSkill) RevokeAll(sessionID string) int {
	revoked := 0
	for _, t := range s.granted {
		if t.SessionID == sessionID && !t.Revoked {
			t.Revoked = true
			revoked++
		}
	}
	return revoked
}
