// internal/agents/book_reader.go
// BookReader — đọc sách → tự học EmotionTag của từng từ/cụm từ
//
// Insight (2026-03-09):
//   "thay vì phân loại, đưa nó một cuốn sách, bảo nó ghi nhớ"
//   "coi nó có lưu các giá trị cảm xúc và dùng nó nói chuyện không"
//
// Pipeline:
//   Text → câu → SentenceAffect → từng từ học EmotionTag từ context
//   Context propagation: từ ngữ trung tính học cảm xúc từ câu xung quanh
//   Silk edge: word_A ──sem:w──► word_B (nếu cùng xuất hiện nhiều lần)
//   Inflection → flush vào Silk
//
// Đây là QT7: ĐN (đang học) → lặp lại đủ nhiều → QR (đã chứng minh)

package agents

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

// LearnedWord — từ học được từ sách (ĐN — ngắn hạn)
type LearnedWord struct {
	Word       string
	Tag        EmotionTag
	Count      int     // xuất hiện bao nhiêu lần
	Confidence float64 // 0..1 — càng nhiều context càng chắc
	Source     string  // tên sách / nguồn
	Examples   []string // câu ví dụ (tối đa 3)
}

// SemanticPair — hai từ thường xuất hiện cùng nhau
type SemanticPair struct {
	WordA, WordB string
	CoOccur      int     // số lần đồng xuất hiện
	Weight       float64 // 0..1
	TagA, TagB   EmotionTag
}

// DNA → Silk edge "sem:"
func (p SemanticPair) DNA() string {
	return fmt.Sprintf("sem:%s→%s:w=%.2f:co=%d", p.WordA, p.WordB, p.Weight, p.CoOccur)
}

// BookMemory — bộ nhớ ngắn hạn (ĐN) của một lần đọc sách
type BookMemory struct {
	Source      string
	SourceType  Source  // FACT / FICTION / USER
	Words       map[string]*LearnedWord // từ → tag học được
	Pairs       map[string]*SemanticPair // "A|B" → pair
	Curve       *ConversationCurve
	History     *EmotionHistory
	Paragraphs  int
	Inflections []ConversationPoint // → Silk
}

func NewBookMemory(source string) *BookMemory {
	m := &BookMemory{
		Source:  source,
		Words:   make(map[string]*LearnedWord),
		Pairs:   make(map[string]*SemanticPair),
		History: &EmotionHistory{},
	}
	m.Curve = NewConversationCurve(func(pt ConversationPoint) {
		m.Inflections = append(m.Inflections, pt) // → Silk
	})
	return m
}

// ReadParagraph xử lý một đoạn văn
func (m *BookMemory) ReadParagraph(para string) {
	if strings.TrimSpace(para) == "" {
		return
	}
	m.Paragraphs++

	// 1. Phân tích cảm xúc cả câu
	sentTag := SentenceAffect(para)
	// Fallback: nếu SentenceAffect không nhận → BootstrapAffect
	if sentTag.Valence == 0 && sentTag.Intensity < 0.15 {
		sentTag = BootstrapAffect(para)
	}
	ctx := InferContext(para)
	scaled := ctx.Apply(sentTag)

	m.Curve.Add(scaled, truncateStr(para, 60))
	m.History.Add(scaled, ctx, para)

	// 2. Học từng từ từ context câu
	words := extractContentWords(para)
	for _, w := range words {
		m.learnWord(w, sentTag, para)
	}

	// 3. Học semantic pairs (từ nào hay đi cùng nhau)
	for i := 0; i < len(words); i++ {
		for j := i + 1; j < len(words) && j < i+5; j++ {
			m.learnPair(words[i], words[j], sentTag)
		}
	}
}

// learnWord học EmotionTag của một từ từ context
func (m *BookMemory) learnWord(word string, ctxTag EmotionTag, example string) {
	if len(word) < 2 {
		return
	}
	if lw, exists := m.Words[word]; exists {
		// Cập nhật running average
		n := float64(lw.Count)
		lw.Tag.Valence   = (lw.Tag.Valence*n   + ctxTag.Valence)   / (n + 1)
		lw.Tag.Arousal   = (lw.Tag.Arousal*n   + ctxTag.Arousal)   / (n + 1)
		lw.Tag.Dominance = (lw.Tag.Dominance*n + ctxTag.Dominance) / (n + 1)
		lw.Tag.Intensity = (lw.Tag.Intensity*n + ctxTag.Intensity) / (n + 1)
		lw.Count++
		lw.Confidence = math.Min(1.0, float64(lw.Count)/10.0) // 10 lần = confident
		if len(lw.Examples) < 3 {
			lw.Examples = append(lw.Examples, truncateStr(example, 50))
		}
	} else {
		// Từ mới — ĐN (chưa chắc)
		tag := ctxTag
		// Nếu đã có trong coreLexicon → blend
		if known, ok := LookupAffect(word); ok {
			tag.Valence   = (known.Valence   + ctxTag.Valence)   / 2
			tag.Arousal   = (known.Arousal   + ctxTag.Arousal)   / 2
			tag.Dominance = (known.Dominance + ctxTag.Dominance) / 2
			tag.Intensity = (known.Intensity + ctxTag.Intensity) / 2
		}
		m.Words[word] = &LearnedWord{
			Word: word, Tag: tag, Count: 1,
			Confidence: 0.10, Source: m.Source,
			Examples: []string{truncateStr(example, 50)},
		}
	}
}

// learnPair học semantic pair
func (m *BookMemory) learnPair(a, b string, tag EmotionTag) {
	key := a + "|" + b
	if a > b {
		key = b + "|" + a
		a, b = b, a
	}
	if p, exists := m.Pairs[key]; exists {
		p.CoOccur++
		n := float64(p.CoOccur)
		p.TagA.Valence = (p.TagA.Valence*(n-1) + tag.Valence) / n
		p.Weight = math.Min(1.0, float64(p.CoOccur)/5.0)
	} else {
		m.Pairs[key] = &SemanticPair{
			WordA: a, WordB: b, CoOccur: 1,
			Weight: 0.20, TagA: tag, TagB: tag,
		}
	}
}

// ─── Query ────────────────────────────────────────────────────────────────

// LookupLearned tra từ đã học
func (m *BookMemory) LookupLearned(word string) (*LearnedWord, bool) {
	lw, ok := m.Words[strings.ToLower(word)]
	return lw, ok
}

// TopEmotionalWords trả N từ có Intensity cao nhất
func (m *BookMemory) TopEmotionalWords(n int) []*LearnedWord {
	var all []*LearnedWord
	for _, lw := range m.Words {
		if lw.Count >= 2 { // chỉ lấy từ xuất hiện ≥2 lần
			all = append(all, lw)
		}
	}
	sort.Slice(all, func(i, j int) bool {
		return all[i].Tag.Intensity > all[j].Tag.Intensity
	})
	if n > len(all) {
		n = len(all)
	}
	return all[:n]
}

// StrongestPairs trả N cặp từ thường đi cùng nhau nhất
func (m *BookMemory) StrongestPairs(n int) []*SemanticPair {
	var all []*SemanticPair
	for _, p := range m.Pairs {
		if p.CoOccur >= 2 {
			all = append(all, p)
		}
	}
	sort.Slice(all, func(i, j int) bool {
		return all[i].CoOccur > all[j].CoOccur
	})
	if n > len(all) {
		n = len(all)
	}
	return all[:n]
}

// EmotionalProfile tóm tắt cảm xúc cuốn sách
func (m *BookMemory) EmotionalProfile() string {
	avg := m.History.AverageVAD()
	trend := m.History.RecentTrend()
	dom := m.History.DominantEmotion()
	top := m.TopEmotionalWords(5)

	var b strings.Builder
	b.WriteString(fmt.Sprintf("📖 %s\n", m.Source))
	b.WriteString(fmt.Sprintf("   Đoạn đọc: %d  |  Inflections→Silk: %d\n",
		m.Paragraphs, len(m.Inflections)))
	b.WriteString(fmt.Sprintf("   Từ học được: %d  |  Cặp ngữ nghĩa: %d\n",
		len(m.Words), len(m.Pairs)))
	b.WriteString(fmt.Sprintf("   Avg VAD: V=%+.2f A=%.2f I=%.2f  [%s]\n",
		avg.Valence, avg.Arousal, avg.Intensity, dom))
	b.WriteString(fmt.Sprintf("   Xu hướng: %s\n", trend))
	b.WriteString(fmt.Sprintf("   RAM: %s\n\n", m.Curve.MemoryStats()))
	b.WriteString("   Từ cảm xúc mạnh nhất:\n")
	for _, lw := range top {
		b.WriteString(fmt.Sprintf("     %-12s V=%+.2f I=%.2f [%s] (×%d, conf=%.0f%%)\n",
			lw.Word, lw.Tag.Valence, lw.Tag.Intensity, lw.Tag.Label(),
			lw.Count, lw.Confidence*100))
	}
	return b.String()
}

// ─── Conversation: nói chuyện dựa trên bộ nhớ sách ─────────────────────

// RespondAboutBook trả lời câu hỏi về cảm xúc sách
func (m *BookMemory) RespondAboutBook(question string, userCurve *ConversationCurve) string {
	lo := strings.ToLower(question)
	tone := userCurve.NextTone()

	// Câu hỏi về nhân vật / cảm xúc cụ thể
	for word := range m.Words {
		if strings.Contains(lo, word) {
			lw := m.Words[word]
			affSent := AffectSentence(userCurve, "vi")
			prefix := ""
			if affSent != "" {
				prefix = affSent + " "
			}
			return fmt.Sprintf("%sVề \"%s\" trong cuốn sách: V=%+.2f [%s] — "+
				"từ này xuất hiện %d lần trong ngữ cảnh %s.\n"+
				"Ví dụ: \"%s\"",
				prefix, word, lw.Tag.Valence, lw.Tag.Label(),
				lw.Count, toneDescription(lw.Tag),
				lw.Examples[0])
		}
	}

	// Câu hỏi chung
	avg := m.History.AverageVAD()
	top := m.TopEmotionalWords(3)

	switch tone.Style {
	case "supportive", "gentle":
		return fmt.Sprintf(
			"Cuốn sách này mang cảm giác %s (V=%+.2f). "+
				"Những từ để lại ấn tượng nhất: %s, %s, %s. "+
				"Bạn đang cảm thấy thế nào khi đọc nó?",
			avg.Label(), avg.Valence,
			top[0].Word, top[1].Word, top[2].Word)
	case "reinforcing", "celebratory":
		pairs := m.StrongestPairs(2)
		pairStr := ""
		if len(pairs) > 0 {
			pairStr = fmt.Sprintf(" Đặc biệt cặp \"%s\" và \"%s\" hay xuất hiện cùng nhau.",
				pairs[0].WordA, pairs[0].WordB)
		}
		return fmt.Sprintf(
			"Cuốn sách có hành trình cảm xúc thú vị! "+
				"Từ %s đến %s — %d bước ngoặt lớn.%s",
			m.Inflections[0].Tag.Label(),
			m.Inflections[len(m.Inflections)-1].Tag.Label(),
			len(m.Inflections), pairStr)
	default:
		return fmt.Sprintf(
			"Cuốn sách học được %d từ với cảm xúc. "+
				"Dominant mood: %s. "+
				"Từ ấn tượng nhất: \"%s\" (V=%+.2f).",
			len(m.Words), avg.Label(),
			top[0].Word, top[0].Tag.Valence)
	}
}

// ─── Helpers ──────────────────────────────────────────────────────────────

func extractContentWords(text string) []string {
	stopWords := map[string]bool{
		"tôi": true, "của": true, "và": true, "là": true, "có": true,
		"một": true, "những": true, "các": true, "trong": true, "với": true,
		"được": true, "đã": true, "sẽ": true, "đến": true, "từ": true,
		"cho": true, "về": true, "khi": true, "như": true, "họ": true,
		"này": true, "đó": true, "ra": true, "vào": true, "cũng": true,
		"mà": true, "nó": true, "anh": true, "cô": true, "người": true,
	}
	lo := strings.ToLower(text)
	words := strings.FieldsFunc(lo, func(r rune) bool {
		return !('a' <= r && r <= 'z') && !(r >= 0x00C0) // giữ unicode
	})
	var result []string
	seen := map[string]bool{}
	for _, w := range words {
		w = strings.Trim(w, ".,!?;:\"'()—-")
		if len([]rune(w)) >= 3 && !stopWords[w] && !seen[w] {
			result = append(result, w)
			seen[w] = true
		}
	}
	return result
}

func toneDescription(tag EmotionTag) string {
	switch {
	case tag.Valence < -0.5: return "nặng nề, đau buồn"
	case tag.Valence < -0.2: return "u ám, lo lắng"
	case tag.Valence < 0.1:  return "trung tính, bình thản"
	case tag.Valence < 0.4:  return "nhẹ nhàng, thoải mái"
	default:                 return "vui vẻ, tích cực"
	}
}

// ─── Bootstrap Affect — pattern matching không cần lexicon ───────────────
// Dùng khi coreLexicon không có từ
// Học từ signal trong câu thay vì lookup

var bootstrapPatterns = []struct {
	patterns []string
	v, a, d  float64
}{
	// Cái chết / mất mát
	{[]string{"chết", "qua đời", "mất mạng", "tử vong", "hi sinh",
		"thi thể", "tang", "khóc thương"}, -0.80, 0.60, 0.20},
	// Chiến tranh / bạo lực
	{[]string{"chiến tranh", "bom đạn", "súng", "lửa", "cháy",
		"hỗn loạn", "khói", "tàn phá", "máu"}, -0.75, 0.80, 0.30},
	// Đau khổ / buồn
	{[]string{"đau buồn", "khóc", "nước mắt", "vỡ tan", "tan vỡ",
		"tuyệt vọng", "đau đớn", "thổn thức", "than thở"}, -0.70, 0.50, 0.25},
	// Sợ hãi / lo lắng
	{[]string{"sợ hãi", "hoảng loạn", "run rẩy", "kinh hoàng",
		"lo lắng", "bất an", "hồi hộp", "nguy hiểm"}, -0.60, 0.75, 0.25},
	// Đói / nghèo khổ
	{[]string{"đói", "nghèo", "khổ cực", "cơ cực", "thiếu thốn",
		"hoang tàn", "tàn lụi"}, -0.55, 0.45, 0.25},
	// Cô đơn / bị bỏ rơi
	{[]string{"cô đơn", "một mình", "bị bỏ rơi", "rời đi",
		"quay đi", "không còn"}, -0.50, 0.30, 0.25},
	// Tức giận
	{[]string{"tức giận", "phẫn nộ", "căm ghét", "thù hận",
		"nổi giận", "tức tối"}, -0.40, 0.85, 0.70},
	// Yêu thương / ấm áp
	{[]string{"yêu", "thương", "trìu mến", "ấm áp", "dịu dàng",
		"hạnh phúc", "vui mừng", "sung sướng"}, +0.70, 0.55, 0.65},
	// Hy vọng / quyết tâm
	{[]string{"hy vọng", "quyết tâm", "kiên cường", "ngày mai",
		"trở về", "vươn lên", "cố gắng", "không bỏ cuộc"}, +0.50, 0.55, 0.70},
	// Bình yên / nhẹ nhàng
	{[]string{"bình yên", "yên tĩnh", "nhẹ nhàng", "an toàn",
		"thoải mái", "thư thái"}, +0.50, 0.20, 0.60},
}

// BootstrapAffect phân tích câu không cần lexicon
// Dùng pattern matching thay vì word lookup
func BootstrapAffect(text string) EmotionTag {
	lo := strings.ToLower(text)
	var v, a, d float64
	count := 0

	for _, bp := range bootstrapPatterns {
		for _, pat := range bp.patterns {
			if strings.Contains(lo, pat) {
				v += bp.v
				a += bp.a
				d += bp.d
				count++
				break // chỉ tính 1 lần mỗi pattern group
			}
		}
	}

	if count == 0 {
		return EmotionTag{0, 0.40, 0.50, 0.10}
	}

	norm := func(x float64) float64 {
		return math.Max(-0.95, math.Min(0.95, x/float64(count)))
	}
	intensity := math.Abs(v/float64(count))*0.7 + math.Abs(a/float64(count)-0.5)*0.3
	return EmotionTag{
		Valence:   norm(v),
		Arousal:   math.Max(0.10, math.Min(0.95, a/float64(count))),
		Dominance: math.Max(0.10, math.Min(0.95, d/float64(count))),
		Intensity: math.Min(0.95, intensity),
	}
}

// ─── Bootstrap Affect ────────────────────────────────────────────────────

// ─── FlushToLongTerm — ghi thật vào Silk ─────────────────────────────────
// Đây là bước "ĐN → QR" theo QT7:
//   LearnedWord.Confidence >= threshold → Commit vào LongTerm (Silk + Ledger)
//   SemanticPair.CoOccur >= 2          → AddEdge vào SilkGraph

