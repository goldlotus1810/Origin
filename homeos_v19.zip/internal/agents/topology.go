// internal/agents/topology.go
//
// Topology vật lý của HomeOS
//
// EDGE   — sống tại thiết bị  (camera, đèn, điều hòa)
// HUB    — sống tại hub/router trung tâm
// SERVER — sống tại máy chủ (AAM, LeoAI)
//
// Hệ quả:
//   Edge tự xử lý, chỉ gửi ISL payload nhỏ lên Hub
//   Hub aggregate, route lên Server
//   Server quyết định, gửi lệnh xuống Hub → Edge
//
// Bandwidth:
//   1 camera 1080p@30fps raw = 186MB/s
//   sau extract tại Edge     = 124B/s
//   ratio: 1,500,000:1

package agents

// Tier — vị trí vật lý của Agent
type Tier int

const (
	TierEdge   Tier = 2 // sống tại thiết bị
	TierHub    Tier = 1 // sống tại hub trung tâm
	TierServer Tier = 0 // sống tại máy chủ
)

func (t Tier) String() string {
	switch t {
	case TierEdge:   return "edge"
	case TierHub:    return "hub"
	case TierServer: return "server"
	}
	return "unknown"
}

// DeviceRole — vai trò của thiết bị edge
type DeviceRole string

const (
	RoleSensor  DeviceRole = "sensor"   // camera, mic — chỉ đọc
	RoleActuator DeviceRole = "actuator" // đèn, điều hòa, khóa — chỉ làm
	RoleHybrid  DeviceRole = "hybrid"   // cả hai (điều hòa có sensor nhiệt)
)

// OfflinePolicy — làm gì khi mất kết nối Hub/Server
type OfflinePolicy int

const (
	// OfflineHold: giữ trạng thái cuối, không tự quyết
	OfflineHold OfflinePolicy = iota
	// OfflineSchedule: chạy theo lịch đã học (từ MotionLibrary)
	OfflineSchedule
	// OfflineSafe: về trạng thái an toàn (đèn tắt, cửa khóa)
	OfflineSafe
)

// EdgeCapabilities — những gì Edge có thể tự làm mà không cần Server
type EdgeCapabilities struct {
	// Có MotionLibrary local không?
	HasMotionLibrary bool
	// Có AudioLibrary local không?
	HasAudioLibrary bool
	// Có thể chạy inference khi offline không?
	CanRunOffline bool
	// Policy khi mất kết nối
	OfflinePolicy OfflinePolicy
	// Bandwidth tối đa gửi lên Hub (bytes/giây)
	MaxUpstreamBPS int
}

// StandardEdgeCapabilities cho thiết bị phổ thông
var StandardEdgeCapabilities = EdgeCapabilities{
	HasMotionLibrary: true,
	HasAudioLibrary:  true,
	CanRunOffline:    true,
	OfflinePolicy:    OfflineSchedule,
	MaxUpstreamBPS:   1024, // 1KB/s là đủ cho ISL payload
}

// ISL message flow theo topology:
//
//   EDGE → HUB:
//     MsgLearn (PerceptPayload 124B)     — chỉ khi mẫu MỚI
//     MsgHeartbeat                       — 1 lần/phút
//
//   HUB → SERVER:
//     MsgKnowledge (ContextUpdate)       — chỉ khi thay đổi
//
//   SERVER → HUB:
//     MsgActuatorCmd                     — khi cần hành động
//
//   HUB → EDGE:
//     MsgActuatorCmd (target device)     — direct to device
//
// Không bao giờ:
//   EDGE → SERVER  (phải qua HUB)
//   SERVER → EDGE  (phải qua HUB)
//   raw media lên HUB hoặc SERVER
