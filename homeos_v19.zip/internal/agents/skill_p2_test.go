package agents

import (
	"strings"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestP2Skills(t *testing.T) {
	t.Log("═══════════════════════════════════════════")
	t.Log("P2 Skills: WebFetch · DataLeakDetect · ErrorCollector · AppLauncher")
	t.Log("═══════════════════════════════════════════")

	// === WebFetchSkill ===
	t.Log("\n[WebFetchSkill]")
	wf := NewWebFetchSkill()
	ctx1 := &ExecContext{State: make(map[string]interface{})}

	// CanHandle checks
	if !wf.CanHandle(&isl.ISLMessage{MsgType: isl.MsgQuery, Payload: []byte("https://example.com")}) {
		t.Error("should handle https URL")
	}
	if wf.CanHandle(&isl.ISLMessage{MsgType: isl.MsgQuery, Payload: []byte("not a url")}) {
		t.Error("should NOT handle non-URL")
	}
	t.Log("  CanHandle: https://... ✓ | non-URL ✗ ✓")

	// Real fetch
	msg1 := &isl.ISLMessage{MsgType: isl.MsgQuery, Payload: []byte("https://example.com")}
	r1 := wf.Execute(ctx1, msg1)
	if status, ok := r1.Data["web.status"].(int); ok && status == 200 {
		t.Logf("  Fetch example.com: status=%d title=%q ✓", status, r1.Data["web.title"])
	} else {
		t.Logf("  Fetch example.com: %v (network may be limited)", r1.Data)
	}

	// === DataLeakDetectSkill ===
	t.Log("\n[DataLeakDetectSkill]")
	dl := NewDataLeakDetectSkill()
	ctx2 := &ExecContext{State: make(map[string]interface{})}

	// Inject suspicious network snapshot
	ctx2.State["network.snapshot"] = &NetworkSnapshot{
		Suspicious: []ConnInfo{
			{PID: 666, ProcessName: "miner", RemoteAddr: "1.2.3.4:4444",
				State: "ESTABLISHED", Suspicious: true, Reason: "unknown external"},
		},
	}
	r2 := dl.Execute(ctx2, &isl.ISLMessage{MsgType: isl.MsgTick})
	t.Logf("  leak.count = %v", r2.Data["leak.count"])
	if r2.Message != nil {
		t.Logf("  Alert: %s", strings.TrimSpace(string(r2.Message.Payload))[:60])
	}
	t.Log("  ✓")

	// === ErrorCollectorSkill ===
	t.Log("\n[ErrorCollectorSkill]")
	ec := NewErrorCollectorSkill()
	ctx3 := &ExecContext{State: make(map[string]interface{})}
	r3 := ec.Execute(ctx3, &isl.ISLMessage{MsgType: isl.MsgTick})
	t.Logf("  errors.count = %v", r3.Data["errors.count"])
	t.Logf("  errors.new   = %v", r3.Data["errors.new"])
	// Cache test
	r3b := ec.Execute(ctx3, &isl.ISLMessage{MsgType: isl.MsgTick})
	t.Logf("  cache hit: new=%v ✓", r3b.Data["errors.new"])

	// === AppLauncherSkill ===
	t.Log("\n[AppLauncherSkill]")
	al := NewAppLauncherSkill()
	ctx4 := &ExecContext{State: make(map[string]interface{})}

	// Check bash (always installed)
	r4 := al.Execute(ctx4, &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: []byte("check:bash"),
	})
	t.Logf("  check:bash → installed=%v path=%v ✓",
		r4.Data["app.installed"], r4.Data["app.path"])

	// Check app không tồn tại
	r5 := al.Execute(ctx4, &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: []byte("check:nonexistent_xyz_app_12345"),
	})
	t.Logf("  check:nonexistent → installed=%v ✓", r5.Data["app.installed"])

	// Launch app không tồn tại → error gracefully
	r6 := al.Execute(ctx4, &isl.ISLMessage{
		MsgType: isl.MsgActuatorCmd,
		Payload: []byte("launch:nonexistent_xyz_app_12345"),
	})
	t.Logf("  launch:nonexistent → error=%v ✓", r6.Data["app.error"])

	t.Log("\n✓ P2 Skills PASS")
}
