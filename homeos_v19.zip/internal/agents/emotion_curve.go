// internal/agents/emotion_curve.go
// ConversationCurve — đường cong cảm xúc, thiết kế tiết kiệm tài nguyên
//
// Nguyên tắc (QT2: ∞-1, hữu hạn):
//   RAM:  Sliding window W điểm gần nhất — O(W) không phải O(n)
//   Silk: CHỈ lưu inflection points (f'' đổi dấu) — giảm ~10x
//   CPU:  D1/D2 tính lazy từ window — không cache
//
// Ước tính (80K-word book, W=32):
//   Naive (per câu):     469 KB RAM, 31.7 MB/năm Silk
//   Window+Inflect:        2.8 KB RAM,  0.32 MB/năm ← 100x nhỏ hơn
package agents

import (
	"fmt"
	"math"
)

const DefaultWindowSize = 32 // giữ 32 điểm gần nhất trong RAM

// ConversationPoint — một điểm trong đường cong
type ConversationPoint struct {
	Turn int
	Tag  EmotionTag
	Text string
}

// ConversationCurve — sliding window + inflection flush
//
//   Window:      chỉ W điểm gần nhất (RAM)
//   Inflections: các bước ngoặt đã detect (→ Silk append-only)
//   FlushFn:     callback khi có inflection mới
type ConversationCurve struct {
	Window      []ConversationPoint
	WindowSize  int
	Inflections []ConversationPoint
	TotalTurns  int
	FlushFn     func(ConversationPoint) // nil = không flush
}

// NewConversationCurve tạo curve mới
func NewConversationCurve(flushFn func(ConversationPoint)) *ConversationCurve {
	return &ConversationCurve{WindowSize: DefaultWindowSize, FlushFn: flushFn}
}

// Add thêm điểm mới, slide window, detect inflection
func (c *ConversationCurve) Add(tag EmotionTag, text string) {
	pt := ConversationPoint{Turn: c.TotalTurns, Tag: tag, Text: truncateStr(text, 50)}
	c.TotalTurns++

	// Detect inflection TRƯỚC khi push vào window
	if c.isInflection(tag) {
		c.Inflections = append(c.Inflections, pt)
		if c.FlushFn != nil {
			c.FlushFn(pt) // → Silk (append-only)
		}
	}

	// Sliding window
	c.Window = append(c.Window, pt)
	if len(c.Window) > c.WindowSize {
		c.Window = c.Window[1:]
	}
}

// isInflection: f'' đổi dấu VÀ đủ lớn (tránh noise < 0.1)
func (c *ConversationCurve) isInflection(tag EmotionTag) bool {
	n := len(c.Window)
	if n < 3 {
		return false
	}
	v := c.Window
	prevD2 := v[n-1].Tag.Valence - 2*v[n-2].Tag.Valence + v[n-3].Tag.Valence
	newD2 := tag.Valence - 2*v[n-1].Tag.Valence + v[n-2].Tag.Valence
	return prevD2*newD2 < 0 && (math.Abs(prevD2)+math.Abs(newD2)) > 0.02
}

// ─── Derivatives (lazy, từ window) ───────────────────────────────────────

// D1 — xu hướng hiện tại (finite difference 3 điểm cuối)
func (c *ConversationCurve) D1() float64 {
	n := len(c.Window)
	if n < 2 {
		return 0
	}
	if n == 2 {
		return c.Window[1].Tag.Valence - c.Window[0].Tag.Valence
	}
	p := c.Window
	return (p[n-1].Tag.Valence - p[n-3].Tag.Valence) / 2.0
}

// D2 — curvature (đột ngột hay trơn)
func (c *ConversationCurve) D2() float64 {
	n := len(c.Window)
	if n < 3 {
		return 0
	}
	p := c.Window
	return p[n-1].Tag.Valence - 2*p[n-2].Tag.Valence + p[n-3].Tag.Valence
}

// EnergyIntegral — tích phân năng lượng cảm xúc trong window
func (c *ConversationCurve) EnergyIntegral() float64 {
	n := len(c.Window)
	if n < 2 {
		return 0
	}
	var sum float64
	for i := 1; i < n; i++ {
		v1 := math.Abs(c.Window[i-1].Tag.Valence)
		v2 := math.Abs(c.Window[i].Tag.Valence)
		sum += (v1 + v2) / 2.0
	}
	return sum
}

// ─── ResponseTone ─────────────────────────────────────────────────────────

// ResponseTone — cách điều chỉnh câu trả lời tiếp theo
type ResponseTone struct {
	Style   string  // supportive / pause / reinforcing / celebratory / gentle / engaged / neutral
	Warmth  float64 // 0.0(lạnh) → 1.0(ấm)
	Brevity float64 // 0.0(dài) → 1.0(ngắn)
	Reason  string
}

// NextTone phân tích window → tone phù hợp
func (c *ConversationCurve) NextTone() ResponseTone {
	if len(c.Window) == 0 {
		return ResponseTone{"neutral", 0.5, 0.5, "no data"}
	}
	d1 := c.D1()
	d2 := c.D2()
	cur := c.Window[len(c.Window)-1].Tag

	switch {
	case d2 < -0.25:
		return ResponseTone{"pause", 0.9, 0.8, "f''<0 dot ngot xau → dung lai hoi them"}
	case d2 > 0.25 && cur.Valence > -0.10:
		return ResponseTone{"celebratory", 0.8, 0.5, "f''>0 dot ngot tot → cung co"}
	case d1 < -0.15:
		return ResponseTone{"supportive", 0.85, 0.6, "f'<0 dang giam → nhe nhang"}
	case d1 > 0.025:
		return ResponseTone{"reinforcing", 0.7, 0.4, "f'>0 dang tang → cung co da di len"}
	case cur.Valence < -0.2:
		return ResponseTone{"gentle", 0.75, 0.55, "V<0 on dinh → diu dang"}
	case cur.Valence > 0.2:
		return ResponseTone{"engaged", 0.6, 0.3, "V>0 on dinh → tuong tac tich cuc"}
	default:
		return ResponseTone{"neutral", 0.55, 0.45, "V~0 f'~0"}
	}
}

// Summary — mô tả ngắn cho LeoAI / brain.go
func (c *ConversationCurve) Summary() string {
	if len(c.Window) == 0 {
		return "Chua co du lieu."
	}
	tone := c.NextTone()
	cur := c.Window[len(c.Window)-1].Tag
	return fmt.Sprintf(
		"Curve(turns=%d window=%d inflections=%d)\n"+
			"  Hien tai: V=%+.2f [%s]\n"+
			"  f'=%+.3f  f''=%+.3f  energy=%.2f\n"+
			"  → Tone: %s (warmth=%.1f) — %s",
		c.TotalTurns, len(c.Window), len(c.Inflections),
		cur.Valence, cur.Label(),
		c.D1(), c.D2(), c.EnergyIntegral(),
		tone.Style, tone.Warmth, tone.Reason,
	)
}

// ─── MemoryStats — thống kê tài nguyên ───────────────────────────────────

// MemoryStats trả về ước tính bộ nhớ đang dùng
func (c *ConversationCurve) MemoryStats() string {
	bytesPerPoint := 4*8 + 8 + 50 // EmotionTag + Turn + Text
	windowBytes := len(c.Window) * bytesPerPoint
	inflectBytes := len(c.Inflections) * 60 // compressed inflection edge
	return fmt.Sprintf(
		"RAM: window=%dB inflections=%dB total=%dB | Silk: %d edges",
		windowBytes, inflectBytes, windowBytes+inflectBytes,
		len(c.Inflections),
	)
}
