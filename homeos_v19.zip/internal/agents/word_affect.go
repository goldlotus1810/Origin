// internal/agents/word_affect.go
// WordAffect — mỗi từ/khái niệm trong Silk Tree có EmotionTag riêng
//
// Insight (2026-03-09):
//   "mỗi từ, vật, việc đều có nhóm câu giải thích ngữ nghĩa"
//   "giá trị cảm xúc được lưu lại bởi Silk của các từ đó"
//   "làm sao để nó lựa từ ngữ thích hợp để khiến ta vui, thoải mái"
//
// Cách hoạt động:
//   1. Khi học một node (ĐN→QR), ProsodySkill đọc DNA → WordAffectTag
//   2. WordAffectTag lưu vào Silk edge (loại "emo:")
//   3. Khi cần trả lời: TargetAffect(curve) → chọn từ có AffectScore gần nhất
//   4. Không nhảy cảm xúc đột ngột — dẫn dần theo slope

package agents

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

// WordAffect — EmotionTag của một từ/khái niệm
type WordAffect struct {
	Word      string
	Tag       EmotionTag
	Source    string // "lexicon" / "learned" / "context"
	UseCount  int    // được dùng bao nhiêu lần
}

// DNA — lưu vào Silk edge "emo:" prefix
func (w WordAffect) DNA() string {
	return fmt.Sprintf("emo:word=%s:v=%.2f:a=%.2f:d=%.2f:i=%.2f:src=%s:n=%d",
		w.Word, w.Tag.Valence, w.Tag.Arousal, w.Tag.Dominance, w.Tag.Intensity,
		w.Source, w.UseCount)
}

// ─── Affect Lexicon ───────────────────────────────────────────────────────
// Lexicon cơ bản — học thêm từ Silk theo thời gian

var coreLexicon = map[string]EmotionTag{
	// Tích cực — nhẹ
	"bình yên":   {+0.50, 0.20, 0.60, 0.25},
	"nhẹ nhàng":  {+0.45, 0.20, 0.55, 0.22},
	"an toàn":    {+0.55, 0.20, 0.65, 0.28},
	"ổn":         {+0.30, 0.30, 0.55, 0.15},
	"thoải mái":  {+0.50, 0.25, 0.60, 0.26},
	"dễ chịu":    {+0.45, 0.25, 0.55, 0.23},
	"ấm áp":      {+0.60, 0.30, 0.60, 0.32},
	"thân quen":  {+0.50, 0.20, 0.55, 0.25},

	// Tích cực — mạnh
	"vui":        {+0.70, 0.60, 0.70, 0.50},
	"hạnh phúc":  {+0.80, 0.60, 0.70, 0.58},
	"tuyệt vời":  {+0.85, 0.70, 0.75, 0.65},
	"xuất sắc":   {+0.80, 0.65, 0.75, 0.60},
	"rực rỡ":     {+0.75, 0.75, 0.70, 0.58},
	"thú vị":     {+0.65, 0.65, 0.65, 0.48},
	"phấn khích": {+0.70, 0.80, 0.65, 0.60},

	// Trung tính — informative
	"rõ ràng":    {+0.20, 0.35, 0.60, 0.12},
	"đơn giản":   {+0.25, 0.30, 0.55, 0.13},
	"thú":        {+0.35, 0.45, 0.55, 0.20},
	"hay":        {+0.50, 0.45, 0.60, 0.28},
	"đúng":       {+0.30, 0.35, 0.65, 0.18},
	"chính xác":  {+0.25, 0.35, 0.65, 0.15},

	// Tiêu cực — nhẹ
	"khó":        {-0.20, 0.45, 0.40, 0.18},
	"mệt":        {-0.30, 0.25, 0.35, 0.20},
	"chán":       {-0.40, 0.20, 0.30, 0.25},
	"lo lắng":    {-0.40, 0.55, 0.30, 0.35},

	// Tiêu cực — mạnh
	"buồn":       {-0.60, 0.30, 0.25, 0.45},
	"sợ hãi":     {-0.70, 0.75, 0.20, 0.58},
	"đau":        {-0.65, 0.55, 0.20, 0.50},
	"thất bại":   {-0.65, 0.45, 0.20, 0.48},
	"mất mát":    {-0.70, 0.40, 0.20, 0.50},
	"chết":       {-0.80, 0.60, 0.15, 0.60},
	"bóng tối":   {-0.55, 0.50, 0.25, 0.42},
	"chiến tranh":{-0.75, 0.80, 0.30, 0.65},
}

// LookupAffect tra cứu EmotionTag của một từ
func LookupAffect(word string) (EmotionTag, bool) {
	lo := strings.ToLower(strings.TrimSpace(word))
	if tag, ok := coreLexicon[lo]; ok {
		return tag, true
	}
	return EmotionTag{}, false
}

// ─── TargetAffect — tính cảm xúc mục tiêu cho câu trả lời ────────────────

// TargetAffect tính EmotionTag mục tiêu dựa trên curve hiện tại
//
// Nguyên tắc:
//   Không nhảy đột ngột — dẫn dần về trạng thái tốt hơn
//   Nếu user buồn (V=-0.6): target = V+0.3 = -0.3 (không phải +0.8)
//   Tốc độ dẫn dần phụ thuộc vào f'(t) và Intensity
func TargetAffect(curve *ConversationCurve) EmotionTag {
	if len(curve.Window) == 0 {
		return EmotionTag{Valence: 0.30, Arousal: 0.40, Dominance: 0.60, Intensity: 0.20}
	}

	cur  := curve.Window[len(curve.Window)-1].Tag
	d1   := curve.D1()
	tone := curve.NextTone()

	var target EmotionTag

	switch tone.Style {
	case "pause":
		// Đột ngột xấu — nhẹ nhàng, không thêm gánh nặng
		target = EmotionTag{
			Valence:   cur.Valence + 0.15, // chỉ cải thiện nhẹ
			Arousal:   0.30,               // xuống thấp, ổn định
			Dominance: 0.55,
			Intensity: 0.15,
		}

	case "supportive":
		// Đang giảm — dẫn lên chậm chậm
		step := 0.20
		if d1 < -0.30 { step = 0.15 } // giảm nhanh → bước nhỏ hơn
		target = EmotionTag{
			Valence:   cur.Valence + step,
			Arousal:   cur.Arousal * 0.85, // giảm nhẹ arousal
			Dominance: cur.Dominance + 0.10,
			Intensity: cur.Intensity * 0.80,
		}

	case "reinforcing":
		// Đang hồi phục — tiếp tục đà lên
		target = EmotionTag{
			Valence:   cur.Valence + 0.25,
			Arousal:   cur.Arousal + 0.10,
			Dominance: cur.Dominance + 0.10,
			Intensity: cur.Intensity * 1.10,
		}

	case "celebratory":
		// Bước ngoặt tích cực — chia vui
		target = EmotionTag{
			Valence:   math.Min(cur.Valence+0.35, 0.85),
			Arousal:   math.Min(cur.Arousal+0.20, 0.80),
			Dominance: 0.70,
			Intensity: math.Min(cur.Intensity*1.20, 0.70),
		}

	case "gentle":
		// V < 0, ổn định — dịu dàng, không ép
		target = EmotionTag{
			Valence:   cur.Valence + 0.10,
			Arousal:   0.25,
			Dominance: 0.50,
			Intensity: 0.12,
		}

	default: // engaged / neutral
		target = EmotionTag{
			Valence:   0.35,
			Arousal:   0.45,
			Dominance: 0.60,
			Intensity: 0.22,
		}
	}

	// Clamp
	target.Valence   = math.Max(-0.95, math.Min(0.95, target.Valence))
	target.Arousal   = math.Max(0.10,  math.Min(0.95, target.Arousal))
	target.Dominance = math.Max(0.10,  math.Min(0.95, target.Dominance))
	target.Intensity = math.Max(0.05,  math.Min(0.95, target.Intensity))
	return target
}

// ─── WordSelector — chọn từ phù hợp với target ──────────────────────────

// WordCandidate — từ với score phù hợp
type WordCandidate struct {
	Word  string
	Tag   EmotionTag
	Score float64 // khoảng cách VAD đến target (nhỏ hơn = tốt hơn)
}

// SelectWords chọn N từ có AffectScore gần target nhất
func SelectWords(target EmotionTag, n int) []WordCandidate {
	var candidates []WordCandidate
	for word, tag := range coreLexicon {
		// Khoảng cách Euclidean trong không gian VAD
		dv := tag.Valence   - target.Valence
		da := tag.Arousal   - target.Arousal
		dd := tag.Dominance - target.Dominance
		dist := math.Sqrt(dv*dv*2.0 + da*da*0.5 + dd*dd*0.5) // Valence quan trọng nhất
		candidates = append(candidates, WordCandidate{Word: word, Tag: tag, Score: dist})
	}
	sort.Slice(candidates, func(i, j int) bool {
		return candidates[i].Score < candidates[j].Score
	})
	if n > len(candidates) { n = len(candidates) }
	return candidates[:n]
}

// AffectSentence tạo câu mở đầu phù hợp với tone
// Dùng từ có AffectScore gần target để tạo cảm giác tự nhiên
func AffectSentence(curve *ConversationCurve, lang string) string {
	if len(curve.Window) == 0 { return "" }
	target := TargetAffect(curve)
	tone   := curve.NextTone()
	words  := SelectWords(target, 3)

	if lang == "vi" {
		switch tone.Style {
		case "pause":
			return fmt.Sprintf("Mình hiểu — %s là điều quan trọng lúc này.",
				words[0].Word)
		case "supportive":
			return fmt.Sprintf("Nghe có vẻ %s, nhưng mọi thứ rồi sẽ %s hơn.",
				words[1].Word, words[0].Word)
		case "reinforcing":
			return fmt.Sprintf("Tốt đấy! Mình thấy bạn đang %s lên rõ rệt.",
				words[0].Word)
		case "celebratory":
			return fmt.Sprintf("Thật %s! Đây là tin %s quá!",
				words[0].Word, words[1].Word)
		case "gentle":
			return fmt.Sprintf("Cứ từ từ thôi, %s sẽ đến.",
				words[0].Word)
		default:
			return ""
		}
	}
	return ""
}
