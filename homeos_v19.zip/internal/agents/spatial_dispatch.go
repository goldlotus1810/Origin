// internal/agents/spatial_dispatch.go
// SpatialDispatcher — ISLRouter → MessageBus
//
// Luồng:
//   Agent/Sensor có probe point p
//   → SpatialDispatcher.Dispatch(p)
//   → ISLRouter.Route(p) → RouteResult.TargetAddr
//   → TargetAddr → agent ID (qua addr2agent registry)
//   → Bus.Send(agentID, ISLMessage{MsgQuery, addr...})
//
// Ý nghĩa:
//   SDF value quyết định ai nhận message
//   Không hardcode agent ID — địa chỉ ISL tự định tuyến

package agents

import (
	"fmt"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// AddrAgentMap ánh xạ ISLAddr → agent ID trong Bus
// Đăng ký khi agent khởi động, xóa khi agent tắt
type AddrAgentMap struct {
	m map[uint64]string // ISLAddr → agentID
}

func NewAddrAgentMap() *AddrAgentMap {
	return &AddrAgentMap{m: make(map[uint64]string)}
}

// Register gắn ISLAddr với agentID
func (a *AddrAgentMap) Register(addr uint64, agentID string) {
	a.m[addr] = agentID
}

// Lookup tra agentID từ ISLAddr
func (a *AddrAgentMap) Lookup(addr uint64) (string, bool) {
	id, ok := a.m[addr]
	return id, ok
}

// SpatialDispatcher — route probe points đến đúng agent
type SpatialDispatcher struct {
	Router   *gene.ISLRouter
	AddrMap  *AddrAgentMap
	Bus      *MessageBus
	SenderID uint16 // ID của dispatcher (cho ISLMessage)
}

// NewSpatialDispatcher tạo dispatcher
func NewSpatialDispatcher(router *gene.ISLRouter, addrMap *AddrAgentMap, bus *MessageBus) *SpatialDispatcher {
	return &SpatialDispatcher{
		Router:  router,
		AddrMap: addrMap,
		Bus:     bus,
	}
}

// DispatchResult kết quả dispatch 1 probe
type DispatchResult struct {
	Probe     gene.Vec3
	Route     gene.RouteResult
	AgentID   string
	Sent      bool   // true nếu message đã gửi
	Reason    string // lý do không gửi (nếu Sent=false)
}

// Dispatch route 1 probe point p và gửi ISLMessage đến agent đích
func (d *SpatialDispatcher) Dispatch(p gene.Vec3, msgType isl.MsgType) DispatchResult {
	route := d.Router.Route(p)

	res := DispatchResult{Probe: p, Route: route}

	if !route.Confident {
		res.Reason = fmt.Sprintf("uncertain dist=%.2f", route.Dist)
		return res
	}

	agentID, ok := d.AddrMap.Lookup(route.TargetAddr)
	if !ok {
		res.Reason = fmt.Sprintf("no agent for addr %016x", route.TargetAddr)
		return res
	}
	res.AgentID = agentID

	// Tạo ISLMessage với địa chỉ ISL từ RouteResult
	msg := &isl.ISLMessage{
		Version:  1,
		MsgType:  msgType,
		SenderID: d.SenderID,
		Confidence: uint32(100),
		PrimaryAddr: isl.Address{
			Layer: byte(route.TargetAddr >> 56),
			Group: byte(route.TargetAddr >> 48),
			Type:  byte(route.TargetAddr >> 40),
			ID:    byte(route.TargetAddr >> 32),
		},
	}

	// Thêm thông tin spatial vào payload (dist × 1000 → int)
	if route.Inside {
		msg.Flags = 0x01 // flag: probe inside node
	}
	// Confidence giảm tỉ lệ với khoảng cách (max 100 khi dist=0)
	if !route.Inside && route.Dist > 0 {
		conf := 100.0 - route.Dist*10
		if conf < 10 { conf = 10 }
		msg.Confidence = uint32(conf)
	}

	sent := d.Bus.Send(agentID, msg)
	res.Sent = sent
	if !sent {
		res.Reason = "bus.Send failed (channel full?)"
	}
	return res
}

// DispatchBatch route nhiều probe points cùng lúc
// Trả về tổng hợp: map agentID → số message đã gửi
func (d *SpatialDispatcher) DispatchBatch(probes []gene.Vec3, msgType isl.MsgType) map[string]int {
	counts := make(map[string]int)
	for _, p := range probes {
		res := d.Dispatch(p, msgType)
		if res.Sent {
			counts[res.AgentID]++
		}
	}
	return counts
}

// DispatchDominant chỉ gửi 1 message đến agent chiếm ưu thế
// Dùng khi muốn xác định "agent nào sở hữu không gian này?"
func (d *SpatialDispatcher) DispatchDominant(probes []gene.Vec3, msgType isl.MsgType) DispatchResult {
	domAddr, _ := d.Router.Dominant(probes)
	// Tìm probe gần nhất với dominant node
	var bestProbe gene.Vec3
	var bestRoute gene.RouteResult
	for i, p := range probes {
		r := d.Router.Route(p)
		if r.TargetAddr == domAddr {
			if i == 0 || r.Dist < bestRoute.Dist {
				bestProbe = p
				bestRoute = r
			}
		}
	}
	_ = bestRoute
	return d.Dispatch(bestProbe, msgType)
}

// ── HotReload integration ─────────────────────────────────────────────────

// SpatialDispatcherHot — SpatialDispatcher dùng HotReloadRouter
// Thay thế SpatialDispatcher khi cần thread-safe hot-reload
type SpatialDispatcherHot struct {
	Router  *HotReloadRouter
	AddrMap *AddrAgentMap
	Bus     *MessageBus
	SenderID uint16
}

// NewSpatialDispatcherHot tạo dispatcher với HotReloadRouter
func NewSpatialDispatcherHot(rr *HotReloadRouter, addrMap *AddrAgentMap, bus *MessageBus) *SpatialDispatcherHot {
	return &SpatialDispatcherHot{Router: rr, AddrMap: addrMap, Bus: bus}
}

// DispatchBatch route nhiều probes → gửi ISLMessage đến đúng agent
func (d *SpatialDispatcherHot) DispatchBatch(probes []gene.Vec3, msgType isl.MsgType) map[string]int {
	results := d.Router.RouteAll(probes)
	counts  := make(map[string]int)
	for _, r := range results {
		if !r.Inside && !r.Confident { continue }
		agentID, ok := d.AddrMap.Lookup(r.TargetAddr)
		if !ok { continue }
		msg := &isl.ISLMessage{
			MsgType:     msgType,
			SenderID:    d.SenderID,
			PrimaryAddr: addrFromU64(r.TargetAddr),
			Confidence:  confidenceOf(r),
		}
		if d.Bus.Send(agentID, msg) {
			counts[agentID]++
		}
	}
	return counts
}

// Dominant trả về ISLAddr xuất hiện nhiều nhất
func (d *SpatialDispatcherHot) Dominant(probes []gene.Vec3) (uint64, int) {
	results := d.Router.RouteAll(probes)
	tally   := d.Router.Tally(results)
	var bestAddr uint64; bestCnt := 0
	for addr, cnt := range tally {
		if cnt > bestCnt { bestAddr = addr; bestCnt = cnt }
	}
	return bestAddr, bestCnt
}

func addrFromU64(u uint64) isl.Address {
	return isl.Address{
		Layer: byte(u >> 56), Group: byte(u >> 48),
		Type:  byte(u >> 40), ID:    byte(u >> 32),
	}
}
func confidenceOf(r gene.RouteResult) uint32 {
	if r.Inside   { return 100 }
	if r.Confident { return 60 }
	return 0
}
