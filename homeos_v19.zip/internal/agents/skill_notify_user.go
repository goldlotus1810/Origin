// NotifyUserSkill — đẩy thông báo tới người dùng
// Không chỉ log — gửi qua: WebSocket, stdout, ISL broadcast
package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type NotifyLevel string

const (
	NotifyInfo     NotifyLevel = "INFO"
	NotifyWarn     NotifyLevel = "WARN"
	NotifyCritical NotifyLevel = "CRITICAL"
)

type Notification struct {
	At      time.Time
	Level   NotifyLevel
	Title   string
	Body    string
	Source  string // skill nào phát
	Ack     bool   // người dùng đã đọc chưa
}

type NotifyUserSkill struct {
	queue    []Notification
	maxQueue int
	handlers []func(Notification) // external listeners (WebSocket, etc.)
}

func NewNotifyUserSkill() *NotifyUserSkill {
	return &NotifyUserSkill{maxQueue: 256}
}

func (s *NotifyUserSkill) Name() string { return "notify_user" }

func (s *NotifyUserSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgKnowledge || msg.MsgType == isl.MsgQuery
}

func (s *NotifyUserSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	body := strings.TrimSpace(string(msg.Payload))
	if body == "" {
		return SkillResult{}
	}

	// Xác định level từ content
	level := NotifyInfo
	if strings.Contains(body, "critical") || strings.Contains(body, "CRITICAL") {
		level = NotifyCritical
	} else if strings.Contains(body, "⚠") || strings.Contains(body, "suspicious") {
		level = NotifyWarn
	}

	notif := Notification{
		At:     time.Now(),
		Level:  level,
		Title:  s.extractTitle(body),
		Body:   body,
		Source: "homeos",
	}

	// Ghi vào queue
	s.queue = append(s.queue, notif)
	if len(s.queue) > s.maxQueue {
		s.queue = s.queue[1:] // drop oldest
	}

	// Cập nhật state để web UI đọc
	ctx.State["notify.last_level"] = string(level)
	ctx.State["notify.last_title"] = notif.Title
	ctx.State["notify.last_at"]    = notif.At.Format(time.RFC3339)
	ctx.State["notify.queue_len"]  = len(s.queue)
	ctx.State["notify.queue"]      = s.queue

	// Gọi external handlers (WebSocket clients)
	for _, h := range s.handlers {
		h(notif)
	}

	// Log ra stdout rõ ràng
	fmt.Printf("[HomeOS %s] %s %s\n", level, notif.At.Format("15:04:05"), notif.Title)
	if level != NotifyInfo {
		fmt.Printf("  %s\n", body)
	}

	return SkillResult{Data: map[string]interface{}{
		"notify.last_level": string(level),
		"notify.last_title": notif.Title,
	}}
}

// AddHandler — Web/UI layer đăng ký nhận notification
func (s *NotifyUserSkill) AddHandler(h func(Notification)) {
	s.handlers = append(s.handlers, h)
}

// GetUnread — web UI poll
func (s *NotifyUserSkill) GetUnread() []Notification {
	var out []Notification
	for _, n := range s.queue {
		if !n.Ack {
			out = append(out, n)
		}
	}
	return out
}

func (s *NotifyUserSkill) AckAll() {
	for i := range s.queue {
		s.queue[i].Ack = true
	}
}

func (s *NotifyUserSkill) extractTitle(body string) string {
	lines := strings.SplitN(body, "\n", 2)
	title := strings.TrimSpace(lines[0])
	if len(title) > 80 {
		return title[:77] + "..."
	}
	return title
}
