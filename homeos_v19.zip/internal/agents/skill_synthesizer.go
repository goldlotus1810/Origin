// internal/agents/skill_synthesizer.go
//
// SkillSynthesizer — tự tổng hợp Skill từ yêu cầu
//
// INSIGHT (session 127):
//   Skill = có thể là tập hợp từ những Skill nhỏ hơn
//   Nếu thiếu Skill cơ bản → viết thêm → add vào registry → compose
//
// Ví dụ:
//   Yêu cầu: "tổng hợp các file trong hệ thống"
//   Phân tích: cần [ListFilesSkill]
//   ListFilesSkill cần: [ReadStorageSkill]
//   ReadStorageSkill: CHƯA CÓ → viết mới (primitive)
//   → registry: ReadStorageSkill (primitive)
//   → registry: ListFilesSkill = [ReadStorageSkill + FilterSkill]
//   → registry: SystemManageSkill = [ListFilesSkill + ProcessWatchSkill + ...]
//
// LUẬT BẤT BIẾN:
//   Primitive Skill = chỉ làm 1 việc, không phụ thuộc Skill khác
//   Composed Skill  = []Primitive hoặc []Composed, không tự viết code mới
//   Skill mới cần AAM approve trước khi vào registry (EphemeralAuth)
//   Skill không tự chạy — chỉ chạy khi Agent gắn vào

package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─────────────────────────────────────────────────────────────
// SKILL GRAPH — đồ thị phụ thuộc
// ─────────────────────────────────────────────────────────────

// SkillNode mô tả một Skill trong dependency graph
type SkillNode struct {
	Name        string
	Kind        string    // "primitive" | "composed"
	Deps        []string  // tên các Skill phụ thuộc
	Description string
	Status      string    // "available" | "missing" | "pending_approval" | "approved"
	CreatedAt   time.Time
	ApprovedBy  string    // "user", "aam", ""
}

func (n *SkillNode) IsPrimitive() bool { return n.Kind == "primitive" }
func (n *SkillNode) IsAvailable() bool { return n.Status == "available" }

// SkillGraph — đồ thị toàn bộ Skills
// Node = Skill, Edge = "A cần B"
type SkillGraph struct {
	nodes map[string]*SkillNode
}

func NewSkillGraph() *SkillGraph {
	g := &SkillGraph{nodes: make(map[string]*SkillNode)}
	// Seed: những Skill đã có
	g.register("ActuatorLightSkill",    "primitive", []string{}, "bật/tắt/dim đèn")
	g.register("PerceptionSkill",       "primitive", []string{}, "camera frame → ISL")
	g.register("FirmwareReaderSkill",   "primitive", []string{}, "đọc firmware endpoint")
	g.register("SecurityAuditSkill",    "primitive", []string{}, "CVE check")
	g.register("FirmwarePatchSkill",    "primitive", []string{"SecurityAuditSkill"}, "vá firmware")
	g.register("EnvironmentProbeSkill", "primitive", []string{}, "đọc RAM/CPU/OS")
	g.register("EphemeralAuthSkill",    "primitive", []string{}, "quyền tạm thời")
	g.register("LoggerSkill",           "primitive", []string{}, "3-tier log")
	g.register("NotifyUserSkill",       "primitive", []string{}, "báo user")
	return g
}

func (g *SkillGraph) register(name, kind string, deps []string, desc string) {
	g.nodes[name] = &SkillNode{
		Name: name, Kind: kind, Deps: deps,
		Description: desc, Status: "available",
		CreatedAt: time.Now(),
	}
}

func (g *SkillGraph) Has(name string) bool {
	n, ok := g.nodes[name]
	return ok && n.IsAvailable()
}

func (g *SkillGraph) Add(node *SkillNode) {
	g.nodes[node.Name] = node
}

// MissingDeps: tìm tất cả deps chưa có (đệ quy)
func (g *SkillGraph) MissingDeps(skillName string) []string {
	visited := make(map[string]bool)
	var missing []string
	g.walkMissing(skillName, visited, &missing)
	return missing
}

func (g *SkillGraph) walkMissing(name string, visited map[string]bool, missing *[]string) {
	if visited[name] { return }
	visited[name] = true
	node, ok := g.nodes[name]
	if !ok {
		*missing = append(*missing, name)
		return
	}
	for _, dep := range node.Deps {
		g.walkMissing(dep, visited, missing)
	}
}

// ─────────────────────────────────────────────────────────────
// INTENT ANALYZER — phân tích yêu cầu → Skills cần thiết
// ─────────────────────────────────────────────────────────────

type IntentAnalysis struct {
	Intent      string     // yêu cầu gốc
	GoalSkill   string     // Skill mục tiêu
	NeedChain   []string   // chuỗi Skills cần (theo thứ tự)
	Missing     []string   // chưa có trong registry
	CanCompose  bool       // có thể compose từ những gì có
}

// analyzeIntent: intent string → chuỗi Skills cần thiết
// Đây là nơi Agent "suy nghĩ" về yêu cầu
func analyzeIntent(intent string, graph *SkillGraph) *IntentAnalysis {
	analysis := &IntentAnalysis{Intent: intent}
	lower := strings.ToLower(intent)

	// Bảng ánh xạ intent → skill chain
	// Primitive được liệt kê trước (leaf → root)
	patterns := []struct {
		keywords  []string
		goalSkill string
		chain     []string  // thứ tự: từ primitive đến composed
	}{
		{
			keywords:  []string{"file", "tổng hợp", "danh sách", "liệt kê", "thư mục"},
			goalSkill: "ListFilesSkill",
			chain:     []string{"ReadStorageSkill", "ListFilesSkill"},
		},
		{
			keywords:  []string{"process", "tiến trình", "đang chạy", "chạy ngầm"},
			goalSkill: "ProcessWatchSkill",
			chain:     []string{"OSProfileSkill", "ProcessWatchSkill"},
		},
		{
			keywords:  []string{"network", "mạng", "kết nối", "gửi data", "data leak"},
			goalSkill: "NetworkMonitorSkill",
			chain:     []string{"NetworkMonitorSkill", "DataLeakDetectSkill"},
		},
		{
			keywords:  []string{"bảo mật", "security", "lỗ hổng", "virus", "malware"},
			goalSkill: "SecurityScanSkill",
			chain:     []string{"ProcessWatchSkill", "NetworkMonitorSkill", "SecurityAuditSkill", "SecurityScanSkill"},
		},
		{
			keywords:  []string{"web", "trang web", "đọc bài", "url", "http"},
			goalSkill: "WebQASkill",
			chain:     []string{"WebFetchSkill", "ContentParseSkill", "WebQASkill"},
		},
		{
			keywords:  []string{"quản lý hệ thống", "system", "hệ thống"},
			goalSkill: "SystemManageSkill",
			chain:     []string{"ReadStorageSkill", "ListFilesSkill", "OSProfileSkill", "ProcessWatchSkill", "SystemManageSkill"},
		},
		{
			keywords:  []string{"thông báo lỗi", "lỗi", "crash", "error", "log"},
			goalSkill: "DiagnosticSkill",
			chain:     []string{"ErrorCollectorSkill", "DiagnosticSkill", "NotifyUserSkill"},
		},
		{
			keywords:  []string{"mở ứng dụng", "launch", "mở app"},
			goalSkill: "AppLauncherSkill",
			chain:     []string{"AppInstalledSkill", "AppLauncherSkill"},
		},
	}

	for _, p := range patterns {
		for _, kw := range p.keywords {
			if strings.Contains(lower, kw) {
				analysis.GoalSkill = p.goalSkill
				analysis.NeedChain = p.chain
				break
			}
		}
		if analysis.GoalSkill != "" { break }
	}

	if analysis.GoalSkill == "" {
		analysis.GoalSkill = "UnknownSkill"
		analysis.NeedChain = []string{}
	}

	// Tìm những gì còn thiếu
	for _, skillName := range analysis.NeedChain {
		if !graph.Has(skillName) {
			analysis.Missing = append(analysis.Missing, skillName)
		}
	}

	analysis.CanCompose = len(analysis.Missing) == 0
	return analysis
}

// ─────────────────────────────────────────────────────────────
// PRIMITIVE TEMPLATE — tạo Skill cơ bản khi còn thiếu
// ─────────────────────────────────────────────────────────────

// PrimitiveTemplate mô tả cách viết một Skill primitive
type PrimitiveTemplate struct {
	Name        string
	Description string
	Deps        []string   // deps của chính nó
	PermScope   PermScope  // quyền cần thiết để chạy
	InputMsg    isl.MsgType
	OutputData  []string   // keys nó sẽ ghi vào ExecContext.State
}

// primitiveLibrary: bộ sưu tập template cho Skills chưa có
// LeoAI dùng đây để "viết" Skill mới khi cần
var primitiveLibrary = map[string]*PrimitiveTemplate{
	"ReadStorageSkill": {
		Name:        "ReadStorageSkill",
		Description: "Đọc danh sách ổ đĩa, mount points, dung lượng",
		Deps:        []string{},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgActivate,
		OutputData:  []string{"storage.disks", "storage.mounts", "storage.total_gb", "storage.free_gb"},
	},
	"ListFilesSkill": {
		Name:        "ListFilesSkill",
		Description: "Liệt kê files theo path, filter by type/size/date",
		Deps:        []string{"ReadStorageSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgActivate,
		OutputData:  []string{"files.list", "files.count", "files.total_size"},
	},
	"OSProfileSkill": {
		Name:        "OSProfileSkill",
		Description: "Kernel version, OS type, distro, init system",
		Deps:        []string{},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgActivate,
		OutputData:  []string{"os.kernel", "os.type", "os.distro", "os.arch"},
	},
	"ProcessWatchSkill": {
		Name:        "ProcessWatchSkill",
		Description: "Liệt kê process, phát hiện process lạ/bất hợp pháp",
		Deps:        []string{"OSProfileSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgTick,
		OutputData:  []string{"processes.list", "processes.suspicious", "processes.hidden"},
	},
	"NetworkMonitorSkill": {
		Name:        "NetworkMonitorSkill",
		Description: "Connections đang mở, traffic theo process, gửi data đi đâu",
		Deps:        []string{},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgTick,
		OutputData:  []string{"network.connections", "network.outbound", "network.suspicious"},
	},
	"DataLeakDetectSkill": {
		Name:        "DataLeakDetectSkill",
		Description: "Phát hiện process gửi data bất thường ra ngoài LAN",
		Deps:        []string{"NetworkMonitorSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgTick,
		OutputData:  []string{"security.leaks", "security.blocked_ips"},
	},
	"WebFetchSkill": {
		Name:        "WebFetchSkill",
		Description: "Đọc trang web theo URL, stream HTML, không tải file",
		Deps:        []string{},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgQuery,
		OutputData:  []string{"web.html", "web.status", "web.url"},
	},
	"ContentParseSkill": {
		Name:        "ContentParseSkill",
		Description: "HTML → plain text, loại quảng cáo, giữ nội dung chính",
		Deps:        []string{"WebFetchSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgQuery,
		OutputData:  []string{"content.text", "content.title", "content.summary"},
	},
	"WebQASkill": {
		Name:        "WebQASkill",
		Description: "User hỏi → fetch → parse → trả lời từ nội dung trang",
		Deps:        []string{"WebFetchSkill", "ContentParseSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgQuery,
		OutputData:  []string{"qa.answer", "qa.source_url"},
	},
	"SecurityScanSkill": {
		Name:        "SecurityScanSkill",
		Description: "Full scan: process + network + firmware + CVE",
		Deps:        []string{"ProcessWatchSkill", "NetworkMonitorSkill", "SecurityAuditSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgSync,
		OutputData:  []string{"scan.result", "scan.critical_count", "scan.report"},
	},
	"SystemManageSkill": {
		Name:        "SystemManageSkill",
		Description: "Quản lý hệ thống: files + process + OS info",
		Deps:        []string{"ListFilesSkill", "ProcessWatchSkill", "OSProfileSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgQuery,
		OutputData:  []string{"system.summary", "system.health"},
	},
	"ErrorCollectorSkill": {
		Name:        "ErrorCollectorSkill",
		Description: "Đọc journald/dmesg/EventLog/syslog, crash report",
		Deps:        []string{"OSProfileSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgTick,
		OutputData:  []string{"errors.recent", "errors.critical", "errors.crashes"},
	},
	"DiagnosticSkill": {
		Name:        "DiagnosticSkill",
		Description: "Từ error → tìm nguyên nhân → đề xuất fix → thông báo",
		Deps:        []string{"ErrorCollectorSkill", "NotifyUserSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgQuery,
		OutputData:  []string{"diagnostic.cause", "diagnostic.fix", "diagnostic.notified"},
	},
	"AppInstalledSkill": {
		Name:        "AppInstalledSkill",
		Description: "Liệt kê apps đã cài, version, source, quyền đã cấp",
		Deps:        []string{"OSProfileSkill"},
		PermScope:   ScopeRead,
		InputMsg:    isl.MsgActivate,
		OutputData:  []string{"apps.list", "apps.suspicious", "apps.permissions"},
	},
	"AppLauncherSkill": {
		Name:        "AppLauncherSkill",
		Description: "Mở đúng ứng dụng phù hợp với nhiệm vụ",
		Deps:        []string{"AppInstalledSkill"},
		PermScope:   ScopeActuate,
		InputMsg:    isl.MsgActivate,
		OutputData:  []string{"launcher.app_opened", "launcher.pid"},
	},
}

// ─────────────────────────────────────────────────────────────
// SKILL SYNTHESIZER — tổng hợp: phân tích → tạo thiếu → compose
// ─────────────────────────────────────────────────────────────

type SynthesisStep struct {
	Action    string // "use_existing" | "create_primitive" | "compose" | "need_approval"
	SkillName string
	From      []string // composed từ những gì
	Reason    string
}

type SynthesisResult struct {
	Intent    string
	GoalSkill string
	Steps     []SynthesisStep
	Final     *SkillNode    // Skill tổng hợp cuối cùng
	NeedApproval []string   // cần user approve trước khi tạo
}

// SkillSynthesizerSkill — LeoAI dùng khi nhận yêu cầu chưa có Skill
type SkillSynthesizerSkill struct {
	graph    *SkillGraph
	registry *SkillRegistry
	pending  []*SynthesisResult // chờ AAM approve
}

func NewSkillSynthesizerSkill(graph *SkillGraph, registry *SkillRegistry) *SkillSynthesizerSkill {
	return &SkillSynthesizerSkill{graph: graph, registry: registry}
}

func (s *SkillSynthesizerSkill) Name() string { return "skill_synthesizer" }

func (s *SkillSynthesizerSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgQuery // yêu cầu từ user
}

func (s *SkillSynthesizerSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	intent := string(msg.Payload)
	result := s.synthesize(intent)
	s.pending = append(s.pending, result)

	ctx.State["synthesis.goal"]         = result.GoalSkill
	ctx.State["synthesis.steps"]        = len(result.Steps)
	ctx.State["synthesis.need_approval"] = result.NeedApproval

	// Nếu cần tạo Skill mới → hỏi user
	if len(result.NeedApproval) > 0 {
		return SkillResult{
			Data: map[string]interface{}{
				"synthesis.status":  "need_approval",
				"synthesis.missing": result.NeedApproval,
			},
			Message: &isl.ISLMessage{
				MsgType: isl.MsgQuery,
				Payload: []byte(s.buildApprovalPrompt(result)),
			},
		}
	}

	// Có đủ → compose ngay
	s.applyResult(result)
	return SkillResult{
		Data: map[string]interface{}{
			"synthesis.status": "composed",
			"synthesis.skill":  result.GoalSkill,
			"synthesis.steps":  len(result.Steps),
		},
	}
}

// synthesize: phân tích intent → lập kế hoạch tổng hợp
func (s *SkillSynthesizerSkill) synthesize(intent string) *SynthesisResult {
	analysis := analyzeIntent(intent, s.graph)
	result := &SynthesisResult{
		Intent:    intent,
		GoalSkill: analysis.GoalSkill,
	}

	// Duyệt chuỗi từ primitive đến composed
	for _, skillName := range analysis.NeedChain {
		if s.graph.Has(skillName) {
			// Đã có → dùng luôn
			result.Steps = append(result.Steps, SynthesisStep{
				Action:    "use_existing",
				SkillName: skillName,
				Reason:    "đã có trong registry",
			})
			continue
		}

		// Chưa có → kiểm tra trong library
		tmpl, inLibrary := primitiveLibrary[skillName]
		if inLibrary {
			if tmpl.IsPrimitive() {
				result.Steps = append(result.Steps, SynthesisStep{
					Action:    "create_primitive",
					SkillName: skillName,
					Reason:    tmpl.Description,
				})
				result.NeedApproval = append(result.NeedApproval, skillName)
			} else {
				result.Steps = append(result.Steps, SynthesisStep{
					Action:    "compose",
					SkillName: skillName,
					From:      tmpl.Deps,
					Reason:    tmpl.Description,
				})
				result.NeedApproval = append(result.NeedApproval, skillName)
			}
		} else {
			// Không có template → cần LeoAI tự suy luận (future)
			result.Steps = append(result.Steps, SynthesisStep{
				Action:    "need_approval",
				SkillName: skillName,
				Reason:    "không có template, cần thiết kế thủ công",
			})
			result.NeedApproval = append(result.NeedApproval, skillName)
		}
	}

	// Goal Skill cuối: composed từ tất cả skills trước
	if len(analysis.NeedChain) > 1 {
		goalNode := &SkillNode{
			Name:        analysis.GoalSkill,
			Kind:        "composed",
			Deps:        analysis.NeedChain[:len(analysis.NeedChain)-1],
			Description: fmt.Sprintf("Tổng hợp: %s", strings.Join(analysis.NeedChain, " → ")),
			Status:      "pending_approval",
			CreatedAt:   time.Now(),
		}
		result.Final = goalNode
	}

	return result
}

func (tmpl *PrimitiveTemplate) IsPrimitive() bool {
	return len(tmpl.Deps) == 0
}

// Approve: user xác nhận → tạo Skills
func (s *SkillSynthesizerSkill) Approve(goalSkill string, grantedBy string) []string {
	var created []string
	for _, r := range s.pending {
		if r.GoalSkill != goalSkill { continue }
		s.applyResult(r)
		for _, step := range r.Steps {
			if step.Action == "create_primitive" || step.Action == "compose" {
				created = append(created, step.SkillName)
			}
		}
		// Mark approved
		if r.Final != nil {
			r.Final.Status    = "approved"
			r.Final.ApprovedBy = grantedBy
		}
	}
	return created
}

func (s *SkillSynthesizerSkill) applyResult(result *SynthesisResult) {
	for _, step := range result.Steps {
		if s.graph.Has(step.SkillName) { continue }
		tmpl, ok := primitiveLibrary[step.SkillName]
		if !ok { continue }

		node := &SkillNode{
			Name:        tmpl.Name,
			Kind:        func() string { if tmpl.IsPrimitive() { return "primitive" }; return "composed" }(),
			Deps:        tmpl.Deps,
			Description: tmpl.Description,
			Status:      "available",
			CreatedAt:   time.Now(),
			ApprovedBy:  "synthesizer",
		}
		s.graph.Add(node)

		// Đăng ký vào SkillRegistry
		mock := &mockPrimitiveSkill{name: tmpl.Name, outputKeys: tmpl.OutputData}
		s.registry.Register(mock)
	}

	// Compose goal Skill
	if result.Final != nil && len(result.Final.Deps) > 0 {
		result.Final.Status = "available"
		s.graph.Add(result.Final)
	}
}

func (s *SkillSynthesizerSkill) buildApprovalPrompt(r *SynthesisResult) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("Yêu cầu: \"%s\"\n", r.Intent))
	sb.WriteString(fmt.Sprintf("Mục tiêu: %s\n\n", r.GoalSkill))
	sb.WriteString("Kế hoạch tổng hợp:\n")
	for i, step := range r.Steps {
		icon := map[string]string{
			"use_existing":    "✓",
			"create_primitive": "🔧",
			"compose":         "⊕",
			"need_approval":   "?",
		}[step.Action]
		sb.WriteString(fmt.Sprintf("  %d. %s [%s] %s\n", i+1, icon, step.SkillName, step.Reason))
	}
	sb.WriteString(fmt.Sprintf("\nCần tạo mới: %s\n", strings.Join(r.NeedApproval, ", ")))
	sb.WriteString(fmt.Sprintf("Xác nhận? (gõ 'approve %s')", r.GoalSkill))
	return sb.String()
}

// ─────────────────────────────────────────────────────────────
// Mock primitive — để registry có thể hold Skills chưa implement
// Khi Skill thật được viết → replace mock
// ─────────────────────────────────────────────────────────────

type mockPrimitiveSkill struct {
	name       string
	outputKeys []string
}

func (m *mockPrimitiveSkill) Name() string { return m.name }
func (m *mockPrimitiveSkill) CanHandle(msg *isl.ISLMessage) bool { return false } // chưa implement
func (m *mockPrimitiveSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Placeholder — sẽ được replace khi implement thật
	data := map[string]interface{}{"_mock": true}
	for _, k := range m.outputKeys {
		data[k] = nil
	}
	return SkillResult{Data: data}
}
