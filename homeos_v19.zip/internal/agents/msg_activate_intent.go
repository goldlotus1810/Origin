// msg_activate_intent.go
//
// FIX: MsgActivate conflict — 4 Skills cùng handle MsgActivate
//
// VẤN ĐỀ:
//   Agent duyệt []Skill theo thứ tự → CanHandle() đúng với cả 4 →
//   chỉ Skill đầu tiên chạy, 3 cái kia bị bỏ qua.
//
// GIẢI PHÁP:
//   Payload bắt đầu bằng "intent:<name>\n" → mỗi Skill chỉ nhận intent của mình.
//   Không thêm field mới vào ISLMessage — backward compatible.
//
// INTENT MAP:
//   "probe_env"      → EnvironmentProbeSkill
//   "read_firmware"  → FirmwareReaderSkill
//   "map_caps"       → CapabilityMapSkill
//   "receive_token"  → EphemeralAuthSkill
//   ""  (no intent)  → tất cả match (backward compat)
//
// DÙNG:
//   Gửi:    isl.ActivateMsg("probe_env", payload)
//   Nhận:   isl.IntentOf(msg) == "probe_env"

package agents

import (
	"strings"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// Intent constants — bất biến
const (
	IntentProbeEnv     = "probe_env"
	IntentReadFirmware = "read_firmware"
	IntentMapCaps      = "map_caps"
	IntentReceiveToken = "receive_token"
	IntentOSProfile    = "os_profile"
	IntentSecurityAudit = "security_audit"
)

// IntentOf — đọc intent từ Payload prefix
// Format: "intent:probe_env\n<rest of payload>"
func IntentOf(msg *isl.ISLMessage) string {
	if len(msg.Payload) == 0 {
		return ""
	}
	s := string(msg.Payload)
	if !strings.HasPrefix(s, "intent:") {
		return ""
	}
	s = strings.TrimPrefix(s, "intent:")
	idx := strings.IndexByte(s, '\n')
	if idx < 0 {
		return strings.TrimSpace(s)
	}
	return s[:idx]
}

// PayloadBody — phần body sau intent prefix
func PayloadBody(msg *isl.ISLMessage) []byte {
	s := string(msg.Payload)
	if !strings.HasPrefix(s, "intent:") {
		return msg.Payload
	}
	idx := strings.IndexByte(s, '\n')
	if idx < 0 || idx+1 >= len(s) {
		return nil
	}
	return msg.Payload[idx+1:]
}

// ActivateMsg — tạo MsgActivate với intent
func ActivateMsg(intent string, body []byte) *isl.ISLMessage {
	prefix := []byte("intent:" + intent + "\n")
	payload := append(prefix, body...)
	return &isl.ISLMessage{
		MsgType: isl.MsgActivate,
		Payload: payload,
	}
}

// MatchIntent — helper cho CanHandle:
//   return MatchIntent(msg, IntentProbeEnv)
//   → true nếu intent match HOẶC không có intent (backward compat)
func MatchIntent(msg *isl.ISLMessage, want string) bool {
	if msg.MsgType != isl.MsgActivate {
		return false
	}
	got := IntentOf(msg)
	return got == "" || got == want
}
