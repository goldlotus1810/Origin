// internal/agents/skill_aam_router.go
//
// AAMRouterSkill — AAM forward actuator commands xuống home_chief (QT5)
//
// Pipeline đúng:
//   HTTP → aamInbox → AAMRouterSkill → registry.Send("home_chief") → HomeChiefSkill
//
// Không xử lý trực tiếp — chỉ route. Logic nằm ở HomeChiefSkill.

package agents

import (
	"log"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// AAMRouterSkill forward MsgActuatorCmd từ AAM inbox xuống home_chief
type AAMRouterSkill struct {
	registry *AgentRegistry
}

func NewAAMRouterSkill(registry *AgentRegistry) *AAMRouterSkill {
	return &AAMRouterSkill{registry: registry}
}

func (s *AAMRouterSkill) Name() string { return "aam.router" }

func (s *AAMRouterSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgActuatorCmd
}

func (s *AAMRouterSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.registry == nil {
		log.Println("AAMRouter: registry nil")
		return SkillResult{}
	}

	// Forward nguyên xi xuống home_chief
	if s.registry.Send("home_chief", msg) {
		log.Printf("AAMRouter: forwarded %q → home_chief", msg.Payload)
		return SkillResult{}
	}

	// Fallback: broadcast tới tất cả chiefs
	n := s.registry.Broadcast("home_chief", msg)
	log.Printf("AAMRouter: broadcast fallback → %d chiefs", n)
	return SkillResult{}
}
