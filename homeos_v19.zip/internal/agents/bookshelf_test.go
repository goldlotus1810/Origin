package agents

import (
	"math"
	"testing"
)

func TestBookShelf_ConversationWithEmotion(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  BookShelf — AI biết nịnh: nói chuyện theo cảm xúc user     ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── Đọc sách ─────────────────────────────────────────────────
	shelf := NewBookShelf()
	t.Log("[ ĐỌC SÁCH ]")
	mem := shelf.Read("cuốn theo chiều gió", GWTWCorpus())
	t.Logf("  → %d từ, %d pairs, %d inflections→Silk",
		len(mem.Words), len(mem.Pairs), len(mem.Inflections))
	t.Logf("  → Avg: V=%+.2f [%s]  trend: %s\n",
		mem.History.AverageVAD().Valence,
		mem.History.AverageVAD().Label(),
		mem.History.RecentTrend())

	// ── 5 kịch bản nói chuyện ────────────────────────────────────
	t.Log("[ NÓI CHUYỆN ]")
	t.Log("═══════════════════════════════════════════════════════════════\n")

	scenarios := []struct {
		userMsgs []struct{ text string; v, a float64 }
		desc     string
	}{
		{
			desc: "User đang vui, hỏi về sách",
			userMsgs: []struct{ text string; v, a float64 }{
				{"bạn đã đọc cuốn theo chiều gió chưa?", +0.30, 0.50},
				{"tôi thấy cuốn sách này hay quá!", +0.60, 0.65},
			},
		},
		{
			desc: "User buồn khi đọc về bi kịch",
			userMsgs: []struct{ text string; v, a float64 }{
				{"tôi vừa đọc đến phần Bonnie chết rồi", +0.10, 0.40},
				{"tôi buồn lắm, Rhett thật đáng thương", -0.60, 0.45},
				{"nhân vật này khổ quá...", -0.70, 0.40},
			},
		},
		{
			desc: "User hứng khởi về Scarlett",
			userMsgs: []struct{ text string; v, a float64 }{
				{"tôi thích Scarlett vì cô ấy không bao giờ bỏ cuộc", +0.50, 0.60},
				{"cô ấy thật phi thường!", +0.75, 0.70},
			},
		},
		{
			desc: "User đột ngột chia sẻ chuyện cá nhân",
			userMsgs: []struct{ text string; v, a float64 }{
				{"đọc cảnh Tara cháy tôi lại nghĩ đến nhà mình", +0.10, 0.45},
				{"tôi cũng từng mất tất cả một lần", -0.70, 0.60},
				{"nhưng tôi đứng dậy được, như Scarlett vậy", +0.30, 0.55},
			},
		},
		{
			desc: "User hỏi về Rhett Butler",
			userMsgs: []struct{ text string; v, a float64 }{
				{"bạn nghĩ Rhett có thực sự yêu Scarlett không?", +0.20, 0.50},
			},
		},
	}

	for si, sc := range scenarios {
		t.Logf("── Kịch bản %d: %s ──", si+1, sc.desc)
		userCurve := NewConversationCurve(nil)

		for mi, msg := range sc.userMsgs {
			// Cập nhật curve user
			tag := EmotionTag{
				Valence: msg.v, Arousal: msg.a,
				Dominance: 0.5, Intensity: math.Abs(msg.v)*0.7 + msg.a*0.2,
			}
			userCurve.Add(tag, msg.text)
			tone := userCurve.NextTone()

			// Lấy response
			response := shelf.RespondWithEmotion(msg.text, userCurve)

			t.Logf("  [%d] User (V=%+.2f tone=%-12s): %q",
				mi+1, msg.v, tone.Style, msg.text)
			t.Logf("       AI: %q", response)
			t.Log()
		}
		t.Log()
	}

	// ── Verify ───────────────────────────────────────────────────
	t.Log("[ VERIFY ]")

	// Tìm đúng sách theo alias nhân vật
	foundMem, title := shelf.Find("Scarlett thật phi thường")
	if foundMem == nil {
		t.Error("Không tìm được sách qua alias 'scarlett'")
	} else {
		t.Logf("✓ Find('Scarlett') → '%s'", title)
	}

	foundMem2, _ := shelf.Find("rhett butler thật đáng thương")
	if foundMem2 == nil {
		t.Error("Không tìm được sách qua alias 'rhett'")
	} else {
		t.Log("✓ Find('rhett') → found")
	}

	// Response với user buồn phải có prefix đồng cảm
	userCurve := NewConversationCurve(nil)
	sadTag := EmotionTag{-0.65, 0.45, 0.3, 0.50}
	userCurve.Add(sadTag, "tôi buồn lắm")
	userCurve.Add(sadTag, "thật đau lòng")
	resp := shelf.RespondWithEmotion("Rhett thật đáng thương", userCurve)
	if !containsAny(resp, []string{"Mình hiểu", "thực sự", "nặng", "Cứ"}) {
		t.Logf("⚠ Response với user buồn: %q", resp)
		t.Log("  (Kỳ vọng có prefix đồng cảm)")
	} else {
		t.Logf("✓ User buồn → response có prefix đồng cảm")
	}

	// Response với user vui phải khác
	happyCurve := NewConversationCurve(nil)
	happyTag := EmotionTag{+0.70, 0.65, 0.65, 0.55}
	happyCurve.Add(happyTag, "tôi thích quá!")
	happyCurve.Add(happyTag, "thật tuyệt vời!")
	resp2 := shelf.RespondWithEmotion("Scarlett thật phi thường", happyCurve)
	t.Logf("✓ User vui → %q", resp2[:min3(len(resp2), 80)]+"...")
}

func containsAny(s string, subs []string) bool {
	for _, sub := range subs {
		if contains2(s, sub) { return true }
	}
	return false
}

func contains2(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub ||
		len(s) > 0 && containsStr(s, sub))
}

func containsStr(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub { return true }
	}
	return false
}
