// internal/agents/addr_label.go
// AddrLabelIndex — tra cứu human-readable label cho ISLAddr
// Kết hợp:
//   1. HotReloadRouter.AddrToLabel (từ SpatialNodes / SDF genes)
//   2. SilkGraph node lookup (từ homeos.olang — 4700 nodes)
//
// VisionChief.Summary() dùng cái này để nói:
//   "Tôi thấy earth × 128 lần" thay vì "5702010100000000 × 128"

package agents

import (
	"fmt"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// AddrLabelIndex — cache label cho ISLAddr
type AddrLabelIndex struct {
	mu     sync.RWMutex
	cache  map[uint64]string
	router *HotReloadRouter // SDF spatial nodes
	graph  *silk.SilkGraph  // Silk Web Tree nodes
}

// NewAddrLabelIndex tạo index
func NewAddrLabelIndex(router *HotReloadRouter, graph *silk.SilkGraph) *AddrLabelIndex {
	return &AddrLabelIndex{
		cache:  make(map[uint64]string),
		router: router,
		graph:  graph,
	}
}

// Label tra cứu label cho ISLAddr
// Thứ tự ưu tiên: cache → router (SDF) → silk graph → hex fallback
func (a *AddrLabelIndex) Label(addr isl.Address) string {
	k := addr.Uint64()

	// 1. Cache hit
	a.mu.RLock()
	if v, ok := a.cache[k]; ok {
		a.mu.RUnlock()
		return v
	}
	a.mu.RUnlock()

	// 2. HotReloadRouter (SDF spatial nodes: earth, sun, creature...)
	label := ""
	if a.router != nil {
		label = a.router.AddrToLabel(addr)
	}

	// 3. SilkGraph (olang nodes: GEOLOGY_PLATE, QUANTUM2_COMPUTE...)
	if label == "" && a.graph != nil {
		if node, ok := a.graph.Get(addr); ok {
			label = node.Name
		}
	}

	// 4. Fallback: hex string
	if label == "" {
		label = fmt.Sprintf("%02x%02x%02x%02x",
			addr.Layer, addr.Group, addr.Type, addr.ID)
	}

	// Lưu cache
	a.mu.Lock()
	a.cache[k] = label
	a.mu.Unlock()

	return label
}

// LabelU64 tiện ích cho uint64 addr
func (a *AddrLabelIndex) LabelU64(addr uint64) string {
	return a.Label(isl.Address{
		Layer: byte(addr >> 56),
		Group: byte(addr >> 48),
		Type:  byte(addr >> 40),
		ID:    byte(addr >> 32),
	})
}

// Invalidate xóa cache (gọi khi HotReloadRouter reload)
func (a *AddrLabelIndex) Invalidate() {
	a.mu.Lock()
	a.cache = make(map[uint64]string)
	a.mu.Unlock()
}

// Size trả về số entries trong cache
func (a *AddrLabelIndex) Size() int {
	a.mu.RLock()
	defer a.mu.RUnlock()
	return len(a.cache)
}
