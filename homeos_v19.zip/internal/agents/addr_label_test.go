package agents

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestAddrLabelIndex(t *testing.T) {
	ws     := gene.NewWorldScene()
	nodes  := ws.SpatialNodes()
	rr     := NewHotReloadRouter(nodes, 8.0)
	graph  := silk.NewSilkGraph()
	labels := NewAddrLabelIndex(rr, graph)

	t.Log("=== AddrLabelIndex ===")

	// Earth addr từ ISL_Earth const
	earthAddr := isl.Address{
		Layer: byte(gene.ISL_Earth >> 56),
		Group: byte(gene.ISL_Earth >> 48),
		Type:  byte(gene.ISL_Earth >> 40),
		ID:    byte(gene.ISL_Earth >> 32),
	}
	lbl := labels.Label(earthAddr)
	t.Logf("ISL_Earth label: %q", lbl)
	if lbl == "" { t.Error("earth phải có label") }

	// Sun addr
	sunAddr := isl.Address{
		Layer: byte(gene.ISL_Sun >> 56),
		Group: byte(gene.ISL_Sun >> 48),
		Type:  byte(gene.ISL_Sun >> 40),
		ID:    byte(gene.ISL_Sun >> 32),
	}
	lblSun := labels.Label(sunAddr)
	t.Logf("ISL_Sun label: %q", lblSun)

	// Unknown addr → hex fallback
	unknown := isl.Address{Layer: 0x99, Group: 0xAB, Type: 0xCD, ID: 0x01}
	lblUnk := labels.Label(unknown)
	t.Logf("Unknown label: %q (hex fallback)", lblUnk)
	if lblUnk == "" { t.Error("phải có hex fallback") }

	// Cache hit
	sz1 := labels.Size()
	labels.Label(earthAddr) // second call
	sz2 := labels.Size()
	if sz1 != sz2 { t.Error("cache size phải không đổi sau hit") }
	t.Logf("Cache size: %d ✓", sz2)

	// Invalidate
	labels.Invalidate()
	if labels.Size() != 0 { t.Error("sau Invalidate cache phải rỗng") }
	t.Log("Invalidate ✓")

	// LabelU64
	lbl2 := labels.LabelU64(uint64(gene.ISL_Earth))
	t.Logf("LabelU64(ISL_Earth): %q ✓", lbl2)

	// VisionChief.LabeledSummary
	vc := NewVisionChief("vc_label", 512)
	bus := NewMessageBus()
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)
	addrMap := NewAddrAgentMap()
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun), vc.ID)

	router := gene.NewISLRouter(nodes, 8.0)
	disp := NewSpatialDispatcher(router, addrMap, bus)
	_ = disp

	// Inject observations trực tiếp
	for i := 0; i < 10; i++ {
		vc.Inbox <- &isl.ISLMessage{
			MsgType:     isl.MsgQuery,
			PrimaryAddr: earthAddr,
			Confidence:  90,
			Flags:       0x01,
		}
	}
	for i := 0; i < 3; i++ {
		vc.Inbox <- &isl.ISLMessage{
			MsgType:     isl.MsgQuery,
			PrimaryAddr: sunAddr,
			Confidence:  60,
			Flags:       0x00,
		}
	}

	stop := make(chan struct{})
	go vc.Run(stop)
	// Đợi process
	for retry := 0; retry < 50; retry++ {
		if len(vc.mem) >= 13 { break }
		// busy wait nhẹ
	}
	close(stop)

	summary := vc.LabeledSummary(labels)
	t.Logf("LabeledSummary: %s", summary)
	if summary == "" { t.Error("summary phải có nội dung") }

	t.Log("\n✓ AddrLabelIndex: router→label, graph→name, hex fallback, cache")
}
