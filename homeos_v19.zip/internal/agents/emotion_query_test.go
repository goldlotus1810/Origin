package agents

import "testing"

func TestEmotionHistory(t *testing.T) {
	t.Log("=== EmotionHistory — lịch sử cảm xúc theo thời gian ===\n")

	h := &EmotionHistory{}
	sp := ProsodySpline{Frames: makeSadFrames(), Duration: 0.2}

	// Ghi nhiều sự kiện với ngữ cảnh khác nhau
	events := []struct{ text string }{
		{"tôi vừa mất việc hôm nay"},
		{"hồi nhỏ tôi đã từng sợ"},
		{"bạn tôi kể chuyện buồn"},
		{"trong phim đó rất xúc động"},
		{"bài nhạc này hay quá"},
		{"tôi vừa gặp người bạn cũ"},
		{"chúng mình cùng nhau vui"},
		{"tôi nhớ lại ngày đó"},
	}

	for _, ev := range events {
		ctx := InferContext(ev.text)
		ce  := SolveEmotion(sp, ctx)
		h.Add(ce.Final, ctx, ev.text)
	}

	t.Logf("Đã ghi %d sự kiện\n", len(h.Edges))
	t.Log(h.Profile())

	// Verify
	if h.DominantEmotion() == "unknown" {
		t.Error("DominantEmotion không được là unknown")
	}
	avg := h.AverageVAD()
	if avg.Arousal <= 0 {
		t.Error("AverageVAD.Arousal phải > 0")
	}
	t.Logf("\nTop 3: %v", h.TopLabels(3))
	t.Logf("Trend: %s", h.RecentTrend())
	t.Log("\n✓ EmotionHistory: append-only, query profile, by source")
}
