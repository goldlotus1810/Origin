package agents

import (
	"testing"
)

func TestMsgActivateIntent(t *testing.T) {
	t.Log("═══════════════════════════════════════════")
	t.Log("MsgActivate Intent Fix — 4 Skills không conflict")
	t.Log("═══════════════════════════════════════════")

	tests := []struct {
		intent  string
		wantEnv bool
		wantFW  bool
		wantMap bool
		wantAuth bool
	}{
		{IntentProbeEnv,     true,  false, false, false},
		{IntentReadFirmware, false, true,  false, false},
		{IntentMapCaps,      false, false, true,  false},
		{IntentReceiveToken, false, false, false, true},
		{"",                 true,  true,  true,  true}, // backward compat
	}

	env  := NewEnvironmentProbeSkill()
	fw   := NewFirmwareReaderSkill()
	caps := NewCapabilityMapSkill()
	auth := NewEphemeralAuthSkill("test_agent")

	for _, tc := range tests {
		msg := ActivateMsg(tc.intent, nil)
		gotEnv  := env.CanHandle(msg)
		gotFW   := fw.CanHandle(msg)
		gotMap  := caps.CanHandle(msg)
		gotAuth := auth.CanHandle(msg)

		ok := gotEnv==tc.wantEnv && gotFW==tc.wantFW &&
			  gotMap==tc.wantMap && gotAuth==tc.wantAuth

		label := tc.intent
		if label == "" { label = "(no intent)" }
		if ok {
			t.Logf("  ✓ intent=%-18s env=%v fw=%v map=%v auth=%v",
				label, gotEnv, gotFW, gotMap, gotAuth)
		} else {
			t.Errorf("  ✗ intent=%-18s got env=%v fw=%v map=%v auth=%v | want %v %v %v %v",
				label, gotEnv, gotFW, gotMap, gotAuth,
				tc.wantEnv, tc.wantFW, tc.wantMap, tc.wantAuth)
		}
	}

	// Test PayloadBody
	msg := ActivateMsg(IntentReadFirmware, []byte("192.168.1.1"))
	body := PayloadBody(msg)
	if string(body) != "192.168.1.1" {
		t.Errorf("PayloadBody got %q, want %q", body, "192.168.1.1")
	}
	t.Logf("\n  PayloadBody: %q ✓", body)
	t.Log("\n✓ MsgActivate intent fix PASS — no conflict")
}
