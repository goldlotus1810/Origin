package agents

import (
	"math"
	"testing"
)

func TestConversationCurve(t *testing.T) {
	t.Log("=== ConversationCurve (sliding window + inflection-only Silk) ===\n")

	flushed := []ConversationPoint{}
	c := NewConversationCurve(func(pt ConversationPoint) {
		flushed = append(flushed, pt)
	})

	scenario := []struct{ text string; v, a float64 }{
		{"xin chao, hom nay the nao?",   +0.30, 0.50},
		{"u cung on",                     +0.20, 0.40},
		{"hom qua toi bi mat viec roi",   -0.60, 0.70},
		{"toi khong biet phai lam gi",    -0.70, 0.55},
		{"nhung ma... thoi cung qua",     -0.30, 0.40},
		{"co cong ty khac hoi roi",       +0.10, 0.50},
		{"ho tra luong cao hon nua",      +0.50, 0.65},
		{"cam on ban da lang nghe",       +0.60, 0.55},
	}

	t.Log("Luot  Valence  f'      f''     Tone            Silk?")
	t.Log("─────────────────────────────────────────────────────")
	for _, s := range scenario {
		prevInflect := len(flushed)
		tag := EmotionTag{
			Valence: s.v, Arousal: s.a, Dominance: 0.5,
			Intensity: math.Abs(s.v)*0.8 + s.a*0.2,
		}
		c.Add(tag, s.text)
		tone := c.NextTone()
		silk := ""
		if len(flushed) > prevInflect {
			silk = "← INFLECT→Silk"
		}
		t.Logf("[%d]  V=%+.2f  f'=%+.3f  f''=%+.3f  %-14s  %s",
			c.TotalTurns-1, s.v, c.D1(), c.D2(), tone.Style, silk)
	}

	t.Logf("\nInflection points flush ke Silk: %d/%d luot", len(flushed), c.TotalTurns)
	t.Logf("%s", c.MemoryStats())
	t.Log("\n" + c.Summary())

	// Verify: inflection xảy ra khi mất việc
	if len(flushed) == 0 {
		t.Error("Phai co it nhat 1 inflection point")
	}

	// Verify: window không vượt quá WindowSize
	if len(c.Window) > c.WindowSize {
		t.Errorf("Window %d > WindowSize %d", len(c.Window), c.WindowSize)
	}

	// Demo: sách dài (533 đoạn) — chỉ một số inflection vào Silk
	t.Log("\n─── Demo: sach 533 doan (chi inflection → Silk) ───")
	book := NewConversationCurve(nil)
	book.WindowSize = 32
	// Mô phỏng đường cong sin (sách có nhiều thăng trầm)
	inflectCount := 0
	oldInflect := 0
	for i := 0; i < 533; i++ {
		v := math.Sin(float64(i)*0.50) * 0.6
		a := 0.4 + math.Abs(math.Cos(float64(i)*0.35))*0.3
		tag := EmotionTag{Valence: v, Arousal: a, Dominance: 0.5, Intensity: math.Abs(v)}
		book.Add(tag, "para")
		if len(book.Inflections) > oldInflect {
			inflectCount++
			oldInflect = len(book.Inflections)
		}
	}
	t.Logf("  Tong doan: 533  |  Window hien tai: %d  |  Inflections→Silk: %d",
		len(book.Window), len(book.Inflections))
	t.Logf("  Giam: %.0fx (chi luu %.1f%% vao Silk)",
		533.0/float64(max1(len(book.Inflections), 1)),
		float64(len(book.Inflections))/533.0*100)
	t.Logf("  %s", book.MemoryStats())
	t.Log("\n✓ Sliding window: O(W) RAM, khong phai O(n)")
	t.Log("✓ Chi flush inflection points vao Silk: giam ~10x")
}

func max1(a, b int) int {
	if a > b { return a }
	return b
}
