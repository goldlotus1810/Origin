package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestSpatialDispatcher(t *testing.T) {
	// Setup world
	ws := gene.NewWorldScene()
	ws.Clock.HourOfDay = 12.0
	nodes := ws.SpatialNodes()

	router := gene.NewISLRouter(nodes, 5.0)
	addrMap := NewAddrAgentMap()
	bus := NewMessageBus()

	// Tạo 2 agent channels và đăng ký
	earthCh := make(chan *isl.ISLMessage, 64)
	sunCh   := make(chan *isl.ISLMessage, 64)

	bus.Register("earth_agent", earthCh, 1, RoleChief)
	bus.Register("sun_agent",   sunCh,   1, RoleChief)

	// Map ISLAddr → agentID
	addrMap.Register(uint64(gene.ISL_Earth), "earth_agent")
	addrMap.Register(uint64(gene.ISL_Sun),   "sun_agent")

	disp := NewSpatialDispatcher(router, addrMap, bus)
	disp.SenderID = 0x0099

	t.Log("=== SpatialDispatcher: vSDF → ISLAddr → Bus.Send ===")

	// 1. Probe bên trong Earth → earth_agent nhận
	p1 := gene.Vec3{X: 0, Y: 5, Z: 0}
	r1 := disp.Dispatch(p1, isl.MsgQuery)
	t.Logf("p(0,5,0) inside Earth → agent=%q sent=%v", r1.AgentID, r1.Sent)
	if r1.AgentID != "earth_agent" {
		t.Errorf("expect earth_agent, got %q reason=%q", r1.AgentID, r1.Reason)
	}
	if !r1.Sent { t.Error("phải Sent=true") }

	// Kiểm tra earth_agent nhận đúng message
	select {
	case msg := <-earthCh:
		t.Logf("  earth_agent nhận: type=%02x flags=%02x conf=%d",
			msg.MsgType, msg.Flags, msg.Confidence)
		if msg.MsgType != isl.MsgQuery { t.Error("MsgType sai") }
		if msg.Flags != 0x01 { t.Errorf("flags sai: %02x (expect 0x01=inside)", msg.Flags) }
		if msg.Confidence != 100 { t.Errorf("confidence %d != 100", msg.Confidence) }
	case <-time.After(10 * time.Millisecond):
		t.Error("earth_agent không nhận message")
	}

	// 2. Probe gần bề mặt Earth (ngoài) → confident → earth_agent
	p2 := gene.Vec3{X: 0, Y: 14.0, Z: 0} // dist=2.0 < threshold=5
	r2 := disp.Dispatch(p2, isl.MsgQuery)
	t.Logf("p(0,14,0) outside Earth dist=2.0 → agent=%q sent=%v conf=%.2f",
		r2.AgentID, r2.Sent, r2.Route.Dist)
	if r2.Sent {
		select {
		case msg := <-earthCh:
			if msg.Flags == 0x01 { t.Error("flags outside không được là 0x01") }
			t.Logf("  earth_agent nhận outside: flags=%02x conf=%d ✓", msg.Flags, msg.Confidence)
		case <-time.After(10 * time.Millisecond):
			t.Error("earth_agent không nhận message outside")
		}
	}

	// 3. Probe quá xa → uncertain → không gửi
	p3 := gene.Vec3{X: 50, Y: 50, Z: 50}
	r3 := disp.Dispatch(p3, isl.MsgQuery)
	t.Logf("p(50,50,50) far → sent=%v reason=%q", r3.Sent, r3.Reason)
	if r3.Sent { t.Error("xa quá phải không gửi") }

	// 4. DispatchBatch — ProbeGrid 3×3×3 quanh tâm Earth
	grid := gene.ProbeGrid(gene.Vec3{}, 3.0, 3)
	counts := disp.DispatchBatch(grid, isl.MsgQuery)
	t.Logf("DispatchBatch grid 3×3×3 (%d probes): %v", len(grid), counts)
	if counts["earth_agent"] == 0 {
		t.Error("earth_agent phải nhận ít nhất 1 message từ batch")
	}
	// Drain channel
	for len(earthCh) > 0 { <-earthCh }

	// 5. DispatchDominant — ai chiếm không gian?
	ring := gene.ProbeRing(gene.Vec3{}, 8.0, 12)
	rd := disp.DispatchDominant(ring, isl.MsgQuery)
	t.Logf("DispatchDominant ring r=8 → agent=%q sent=%v", rd.AgentID, rd.Sent)
	if rd.AgentID != "earth_agent" {
		t.Errorf("ring r=8 trong Earth → expect earth_agent, got %q", rd.AgentID)
	}

	t.Log("\n✓ Pipeline: vSDF.Eval(p) → ISLAddr → Bus.Send(agentID, msg)")
}
