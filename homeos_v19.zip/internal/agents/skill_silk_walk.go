// skill_silk_walk.go
//
// SilkWalkSkill — LeoAI tự suy luận qua Silk Tree
//
// QT7: "Silk Walk → Response"
// Nhận MsgQuery → Walk Silk Tree → sinh câu trả lời tự nhiên
//
// Pipeline:
//   MsgQuery("AI là gì?")
//       ↓ SilkWalkSkill
//       BFS Silk Tree (depth=3, max=8 hops)
//       ↓
//       buildResponse() → câu trả lời có cấu trúc
//       ↓
//   MsgKnowledge (kết quả)
//
// Khác với brain.go: Skill này dùng được trong bất kỳ Agent nào,
// không phụ thuộc HTTP server.

package agents

import (
	"fmt"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// WalkResult — kết quả 1 lần Silk Walk
type WalkResult struct {
	Root     string   // node gốc tìm được
	RootDesc string   // mô tả node gốc
	Hops     []string // các node liên quan (name)
	Answer   string   // câu trả lời tổng hợp
	Depth    int      // độ sâu walk thực tế
	Found    bool
}

type SilkWalkSkill struct {
	graph   *silk.SilkGraph
	maxHops int
	depth   int
}

func NewSilkWalkSkill(graph *silk.SilkGraph) *SilkWalkSkill {
	return &SilkWalkSkill{graph: graph, maxHops: 8, depth: 3}
}

func (s *SilkWalkSkill) Name() string { return "silk_walk" }

func (s *SilkWalkSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgQuery && len(msg.Payload) > 0
}

func (s *SilkWalkSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	query := strings.TrimSpace(string(msg.Payload))
	if query == "" {
		return SkillResult{}
	}

	result := s.walk(query)

	ctx.State["silk_walk.query"]  = query
	ctx.State["silk_walk.found"]  = result.Found
	ctx.State["silk_walk.root"]   = result.Root
	ctx.State["silk_walk.hops"]   = len(result.Hops)
	ctx.State["silk_walk.answer"] = result.Answer

	if !result.Found {
		return SkillResult{Data: map[string]interface{}{
			"silk_walk.found": false,
			"silk_walk.query": query,
		}}
	}

	return SkillResult{
		Data: map[string]interface{}{
			"silk_walk.found":  true,
			"silk_walk.root":   result.Root,
			"silk_walk.hops":   len(result.Hops),
			"silk_walk.answer": result.Answer,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgKnowledge,
			Payload: []byte(result.Answer),
		},
	}
}

// walk — tìm node + BFS qua silk edges
func (s *SilkWalkSkill) walk(query string) WalkResult {
	// 1. Tìm node gốc: thử chính xác trước, rồi fuzzy
	node := s.graph.SearchNode(query)
	if node == nil {
		// Thử từng từ trong query
		for _, w := range strings.Fields(query) {
			if len([]rune(w)) >= 3 {
				node = s.graph.SearchNode(w)
				if node != nil { break }
			}
		}
	}
	if node == nil {
		return WalkResult{Found: false}
	}

	// 2. BFS qua silk edges (dùng Walk + expand thủ công)
	visited := map[uint64]bool{node.Addr.Uint64(): true}
	var hopNodes []*silk.OlangNode
	queue := []*silk.OlangNode{node}
	for depth := 0; depth < s.depth && len(hopNodes) < s.maxHops; depth++ {
		var next []*silk.OlangNode
		for _, cur := range queue {
			children := s.graph.WalkWeightedMulti(cur.Addr, silk.OpMember, silk.OpSimilar) // Hebbian: weight cao → ưu tiên, cả OpSimilar edges
			for _, child := range children {
				if !visited[child.Addr.Uint64()] {
					visited[child.Addr.Uint64()] = true
					hopNodes = append(hopNodes, child)
					next = append(next, child)
				}
			}
		}
		queue = next
	}

	// 3. Build hop labels
	hopLabels := make([]string, 0, len(hopNodes))
	for _, h := range hopNodes {
		if h.Name != "" && h.Name != node.Name {
			hopLabels = append(hopLabels, h.Name)
		}
		if len(hopLabels) >= 6 { break }
	}

	desc := extractDesc(node.DNA)
	answer := s.buildResponse(node.Name, desc, hopLabels, query)

	return WalkResult{
		Root:     node.Name,
		RootDesc: desc,
		Hops:     hopLabels,
		Answer:   answer,
		Depth:    s.depth,
		Found:    true,
	}
}

// extractDesc lấy trường desc từ DNA string "label=...|en=...|desc=..."
func extractDesc(dna string) string {
	for _, part := range strings.Split(dna, "|") {
		if strings.HasPrefix(part, "desc=") {
			return strings.TrimPrefix(part, "desc=")
		}
		if strings.HasPrefix(part, "label=") {
			// fallback: dùng label nếu không có desc
		}
	}
	return dna
}

// buildResponse — tổng hợp câu trả lời từ walk result
func (s *SilkWalkSkill) buildResponse(root, desc string, hops []string, query string) string {
	var sb strings.Builder

	// Phần 1: định nghĩa node gốc
	if desc != "" {
		sb.WriteString(fmt.Sprintf("**%s** — %s", capitalize(root), desc))
	} else {
		sb.WriteString(fmt.Sprintf("**%s**", capitalize(root)))
	}

	// Phần 2: các khái niệm liên quan
	if len(hops) > 0 {
		sb.WriteString("\n\nCác khái niệm liên quan: ")
		limit := len(hops)
		if limit > 5 { limit = 5 }
		sb.WriteString(strings.Join(hops[:limit], ", "))
		sb.WriteString(".")
	}

	// Phần 3: gợi ý tìm hiểu thêm
	if len(hops) > 2 {
		sb.WriteString(fmt.Sprintf("\n\n→ Tìm hiểu thêm: `%s`", hops[0]))
	}

	return sb.String()
}

func capitalize(s string) string {
	if s == "" { return "" }
	r := []rune(s)
	if r[0] >= 'a' && r[0] <= 'z' {
		r[0] -= 32
	}
	return string(r)
}
