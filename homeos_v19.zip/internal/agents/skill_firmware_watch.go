// internal/agents/skill_firmware_watch.go
//
// FirmwareWatchSkill — Worker theo dõi hành vi firmware
//
// Nguyên tắc (TRUTH.md):
//   Firmware không quan trọng là loại gì
//   Nếu firmware hành xử trái phép → cô lập → báo AAM
//   HomeOS có thể thay thế firmware bằng Skill của mình
//
// Cách hoạt động:
//   1. Theo dõi pattern hành vi firmware theo thời gian
//   2. Phát hiện anomaly:
//      - Bỗng nhiên tăng network traffic
//      - Gửi data đến IP lạ
//      - Thay đổi firmware (OTA update trái phép)
//      - Heartbeat bất thường (có thể bị kiểm soát từ xa)
//   3. Khi phát hiện → Quarantine → báo AAM
//   4. AAM quyết định: cho phép / cô lập hoàn toàn / thay thế firmware
//
// FirmwareReplacement (dài hạn):
//   Khi HomeOS đủ hiểu firmware:
//   → extract behavior → viết FirmwareSkill thay thế
//   → ship light.olang với FirmwareSkill thay firmware gốc

package agents

import (
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// FirmwareBehavior — snapshot hành vi firmware tại 1 thời điểm
type FirmwareBehavior struct {
	At             time.Time
	BytesSent      int64   // bytes gửi ra ngoài
	BytesRecv      int64   // bytes nhận vào
	UniqueRemoteIPs int    // số IP khác nhau đã kết nối
	ResponseTimeMs int     // thời gian phản hồi lệnh (ms)
	HeartbeatOK    bool    // có heartbeat đúng lịch không
	FirmwareHash   string  // hash firmware hiện tại (nếu đọc được)
}

// AnomalyType — loại bất thường
type AnomalyType string

const (
	AnomalyTrafficSpike    AnomalyType = "traffic_spike"      // traffic tăng đột biến
	AnomalyUnknownRemote   AnomalyType = "unknown_remote"     // kết nối IP lạ
	AnomalyFirmwareChanged AnomalyType = "firmware_changed"   // firmware bị thay
	AnomalyHeartbeatLost   AnomalyType = "heartbeat_lost"     // mất heartbeat
	AnomalyOTAUnauthorized AnomalyType = "ota_unauthorized"   // OTA update trái phép
	AnomalyHighLatency     AnomalyType = "high_latency"       // phản hồi chậm bất thường
	AnomalyReplayAttack    AnomalyType = "replay_attack"      // nhận lệnh cũ (replay)
)

// FirmwareAnomaly — 1 sự kiện bất thường phát hiện được
type FirmwareAnomaly struct {
	At        time.Time
	DeviceID  string
	Type      AnomalyType
	Severity  int    // 1=low 2=medium 3=critical
	Detail    string
	Evidence  FirmwareBehavior
}

// FirmwareWatchSkill — 1 trách nhiệm: theo dõi hành vi firmware
type FirmwareWatchSkill struct {
	deviceID  string
	deviceIP  string

	mu           sync.RWMutex
	baseline     *FirmwareBehavior   // hành vi bình thường đã học
	history      []FirmwareBehavior  // lịch sử 60 snapshots (~1 giờ)
	anomalies    []FirmwareAnomaly   // anomalies phát hiện được
	quarantined  bool                // đang bị cách ly
	lastHeartbeat time.Time

	// Learning period: bao nhiêu ticks để xây baseline
	learningTicks int
	tickCount     int

	// Thresholds
	trafficSpikeRatio float64 // x lần baseline → spike (default 5x)
	latencyThresholdMs int    // ms vượt ngưỡng → anomaly (default 2000)
	heartbeatTimeoutMs int    // ms không heartbeat → lost (default 30000)
}

func NewFirmwareWatchSkill(deviceID, deviceIP string) *FirmwareWatchSkill {
	return &FirmwareWatchSkill{
		deviceID:           deviceID,
		deviceIP:           deviceIP,
		history:            make([]FirmwareBehavior, 0, 60),
		learningTicks:      10, // 10 ticks đầu = học baseline
		trafficSpikeRatio:  5.0,
		latencyThresholdMs: 2000,
		heartbeatTimeoutMs: 30000,
		lastHeartbeat:      time.Now(),
	}
}

func (s *FirmwareWatchSkill) Name() string { return "firmware_watch:" + s.deviceID }

func (s *FirmwareWatchSkill) CanHandle(msg *isl.ISLMessage) bool {
	switch msg.MsgType {
	case isl.MsgTick:      return true  // check định kỳ
	case isl.MsgHeartbeat: return true  // nhận heartbeat từ firmware
	case isl.MsgQuery:     return true  // query status
	case isl.MsgApproved:  return true  // AAM cho phép hành vi này
	}
	return false
}

func (s *FirmwareWatchSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	switch msg.MsgType {
	case isl.MsgTick:
		return s.watchTick()
	case isl.MsgHeartbeat:
		return s.handleHeartbeat(msg)
	case isl.MsgQuery:
		return s.handleQuery()
	case isl.MsgApproved:
		return s.handleApproval(msg)
	}
	return SkillResult{}
}

// watchTick — chạy mỗi tick: lấy snapshot → so sánh baseline → phát hiện anomaly
func (s *FirmwareWatchSkill) watchTick() SkillResult {
	snap := s.collectSnapshot()

	s.mu.Lock()
	s.history = append(s.history, snap)
	if len(s.history) > 60 { s.history = s.history[1:] }
	s.tickCount++

	// Phase 1: learning — xây baseline
	if s.tickCount <= s.learningTicks {
		if s.tickCount == s.learningTicks {
			s.baseline = s.computeBaseline()
			log.Printf("✅ FirmwareWatch [%s]: baseline learned (traffic=%.0f B/tick)",
				s.deviceID, float64(s.baseline.BytesSent))
		}
		s.mu.Unlock()
		return SkillResult{Data: map[string]interface{}{
			"phase": "learning",
			"tick":  s.tickCount,
		}}
	}
	s.mu.Unlock()

	// Phase 2: monitoring — detect anomalies
	anomalies := s.detect(snap)
	if len(anomalies) == 0 {
		return SkillResult{Data: map[string]interface{}{
			"device": s.deviceID, "status": "normal",
		}}
	}

	// Xử lý từng anomaly
	var critical *FirmwareAnomaly
	for i := range anomalies {
		a := &anomalies[i]
		s.mu.Lock()
		s.anomalies = append(s.anomalies, *a)
		s.mu.Unlock()

		log.Printf("⚠️  FirmwareWatch [%s]: %s (severity=%d) — %s",
			s.deviceID, a.Type, a.Severity, a.Detail)

		if a.Severity == 3 && critical == nil {
			critical = a
		}
	}

	// Critical anomaly → quarantine ngay
	if critical != nil {
		s.mu.Lock()
		s.quarantined = true
		s.mu.Unlock()
		return s.reportQuarantine(*critical)
	}

	// Non-critical → báo lên Chief
	return SkillResult{
		Data: map[string]interface{}{
			"device":    s.deviceID,
			"anomalies": len(anomalies),
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgPropose,
			Payload: encodePayload(map[string]interface{}{
				"type":      "firmware_anomaly",
				"device":    s.deviceID,
				"anomalies": anomalies,
			}),
		},
	}
}

// detect so sánh snapshot với baseline → trả về anomalies
func (s *FirmwareWatchSkill) detect(snap FirmwareBehavior) []FirmwareAnomaly {
	s.mu.RLock()
	baseline := s.baseline
	lastHeartbeat := s.lastHeartbeat
	s.mu.RUnlock()

	if baseline == nil { return nil }

	var result []FirmwareAnomaly

	// 1. Traffic spike — gửi nhiều hơn 5x baseline
	if baseline.BytesSent > 0 {
		ratio := float64(snap.BytesSent) / float64(baseline.BytesSent)
		if ratio > s.trafficSpikeRatio {
			result = append(result, FirmwareAnomaly{
				At: snap.At, DeviceID: s.deviceID,
				Type:     AnomalyTrafficSpike,
				Severity: 2,
				Detail:   fmt.Sprintf("traffic %.1fx baseline (%.0f vs %.0f bytes)", ratio, float64(snap.BytesSent), float64(baseline.BytesSent)),
				Evidence: snap,
			})
		}
	}

	// 2. Kết nối nhiều IP lạ hơn baseline
	if snap.UniqueRemoteIPs > baseline.UniqueRemoteIPs+3 {
		severity := 2
		if snap.UniqueRemoteIPs > baseline.UniqueRemoteIPs+10 { severity = 3 }
		result = append(result, FirmwareAnomaly{
			At: snap.At, DeviceID: s.deviceID,
			Type:     AnomalyUnknownRemote,
			Severity: severity,
			Detail:   fmt.Sprintf("%d unique IPs vs baseline %d", snap.UniqueRemoteIPs, baseline.UniqueRemoteIPs),
			Evidence: snap,
		})
	}

	// 3. Firmware hash thay đổi → OTA unauthorized
	if baseline.FirmwareHash != "" && snap.FirmwareHash != "" &&
		snap.FirmwareHash != baseline.FirmwareHash {
		result = append(result, FirmwareAnomaly{
			At: snap.At, DeviceID: s.deviceID,
			Type:     AnomalyFirmwareChanged,
			Severity: 3, // CRITICAL — firmware bị thay
			Detail:   fmt.Sprintf("hash changed: %s → %s", baseline.FirmwareHash[:8], snap.FirmwareHash[:8]),
			Evidence: snap,
		})
	}

	// 4. Heartbeat timeout
	if time.Since(lastHeartbeat) > time.Duration(s.heartbeatTimeoutMs)*time.Millisecond {
		result = append(result, FirmwareAnomaly{
			At: snap.At, DeviceID: s.deviceID,
			Type:     AnomalyHeartbeatLost,
			Severity: 2,
			Detail:   fmt.Sprintf("no heartbeat for %v", time.Since(lastHeartbeat).Round(time.Second)),
			Evidence: snap,
		})
	}

	// 5. Response time bất thường → có thể bị overload hoặc bị kiểm soát
	if snap.ResponseTimeMs > s.latencyThresholdMs {
		result = append(result, FirmwareAnomaly{
			At: snap.At, DeviceID: s.deviceID,
			Type:     AnomalyHighLatency,
			Severity: 1,
			Detail:   fmt.Sprintf("response %dms > threshold %dms", snap.ResponseTimeMs, s.latencyThresholdMs),
			Evidence: snap,
		})
	}

	return result
}

// collectSnapshot đo hành vi firmware tại thời điểm hiện tại
// Dùng /proc/net/dev để đo bytes sent/recv và đếm unique remote IPs
func (s *FirmwareWatchSkill) collectSnapshot() FirmwareBehavior {
	snap := FirmwareBehavior{
		At:          time.Now(),
		HeartbeatOK: time.Since(s.lastHeartbeat) < 30*time.Second,
	}

	// Đo traffic từ /proc/net/dev (host-level)
	bytesSent, bytesRecv := readNetDevBytes()
	snap.BytesSent = bytesSent
	snap.BytesRecv = bytesRecv

	// Đếm unique remote IPs từ /proc/net/tcp
	conns := readProcNetTCP()
	remoteIPs := map[string]bool{}
	for _, c := range conns {
		if c.RemoteIP != "0.0.0.0" && c.RemoteIP != "" {
			remoteIPs[c.RemoteIP] = true
		}
	}
	snap.UniqueRemoteIPs = len(remoteIPs)

	// Đo response time bằng TCP connect
	if s.deviceIP != "" {
		snap.ResponseTimeMs = int(s.pingDevice(s.deviceIP).Milliseconds())
	}

	return snap
}

// pingDevice đo latency bằng TCP connect với timeout ngắn
func (s *FirmwareWatchSkill) pingDevice(ip string) time.Duration {
	start := time.Now()
	conn, err := net.DialTimeout("tcp", net.JoinHostPort(ip, "80"), 500*time.Millisecond)
	if err != nil {
		// Port 80 không mở thử port 443
		conn, err = net.DialTimeout("tcp", net.JoinHostPort(ip, "443"), 500*time.Millisecond)
	}
	if err == nil {
		conn.Close()
	}
	return time.Since(start)
}

// readNetDevBytes đọc tổng bytes sent/recv từ /proc/net/dev
// Format: "  eth0: bytes packets errs drop ...  bytes packets ..."
//          col 1 = recv bytes, col 9 = sent bytes
func readNetDevBytes() (sent, recv int64) {
	data, err := os.ReadFile("/proc/net/dev")
	if err != nil {
		return 0, 0
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if !strings.Contains(line, ":") {
			continue
		}
		// Skip loopback
		if strings.HasPrefix(line, "lo:") {
			continue
		}
		// Tách iface và data
		parts := strings.SplitN(line, ":", 2)
		if len(parts) < 2 {
			continue
		}
		fields := strings.Fields(parts[1])
		// recv bytes = field[0], sent bytes = field[8]
		if len(fields) < 9 {
			continue
		}
		r, e1 := strconv.ParseInt(fields[0], 10, 64)
		s2, e2 := strconv.ParseInt(fields[8], 10, 64)
		if e1 == nil && e2 == nil {
			recv += r
			sent += s2
		}
	}
	return sent, recv
}

// computeBaseline tính giá trị baseline từ history
func (s *FirmwareWatchSkill) computeBaseline() *FirmwareBehavior {
	if len(s.history) == 0 { return &FirmwareBehavior{} }

	var totalSent, totalRecv int64
	var totalLatency, totalIPs int

	for _, h := range s.history {
		totalSent += h.BytesSent
		totalRecv += h.BytesRecv
		totalLatency += h.ResponseTimeMs
		totalIPs += h.UniqueRemoteIPs
	}
	n := int64(len(s.history))
	return &FirmwareBehavior{
		BytesSent:       totalSent / n,
		BytesRecv:       totalRecv / n,
		ResponseTimeMs:  int(int64(totalLatency) / n),
		UniqueRemoteIPs: int(int64(totalIPs) / n),
		HeartbeatOK:     true,
	}
}

func (s *FirmwareWatchSkill) handleHeartbeat(msg *isl.ISLMessage) SkillResult {
	s.mu.Lock()
	s.lastHeartbeat = time.Now()
	s.mu.Unlock()
	return SkillResult{Data: map[string]interface{}{
		"heartbeat": "ok",
		"device":    s.deviceID,
	}}
}

func (s *FirmwareWatchSkill) handleQuery() SkillResult {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return SkillResult{
		Data: map[string]interface{}{
			"device":      s.deviceID,
			"quarantined": s.quarantined,
			"anomalies":   len(s.anomalies),
			"tick":        s.tickCount,
			"phase":       s.phase(),
		},
	}
}

func (s *FirmwareWatchSkill) handleApproval(msg *isl.ISLMessage) SkillResult {
	// AAM đã xem xét và approve → có thể lift quarantine
	s.mu.Lock()
	if s.quarantined {
		s.quarantined = false
		log.Printf("🔓 FirmwareWatch [%s]: quarantine lifted by AAM", s.deviceID)
	}
	s.mu.Unlock()
	return SkillResult{Data: map[string]interface{}{
		"quarantine_lifted": true,
		"device":            s.deviceID,
	}}
}

func (s *FirmwareWatchSkill) reportQuarantine(trigger FirmwareAnomaly) SkillResult {
	log.Printf("🔒 FirmwareWatch [%s]: QUARANTINED — %s", s.deviceID, trigger.Detail)
	return SkillResult{
		Data: map[string]interface{}{
			"quarantined": true,
			"device":      s.deviceID,
			"reason":      trigger.Detail,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgEmergency,
			Payload: encodePayload(map[string]interface{}{
				"type":    "firmware_quarantine",
				"device":  s.deviceID,
				"anomaly": trigger,
				"action":  "isolate_immediately",
			}),
		},
	}
}

func (s *FirmwareWatchSkill) phase() string {
	if s.tickCount < s.learningTicks { return "learning" }
	return "monitoring"
}

// IsQuarantined trả về trạng thái quarantine
func (s *FirmwareWatchSkill) IsQuarantined() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.quarantined
}

// Summary tóm tắt cho UI/log
func (s *FirmwareWatchSkill) Summary() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	status := "✅ normal"
	if s.quarantined { status = "🔒 QUARANTINED" }
	return fmt.Sprintf("[%s] %s · %d anomalies · phase=%s",
		s.deviceID, status, len(s.anomalies), s.phase())
}
