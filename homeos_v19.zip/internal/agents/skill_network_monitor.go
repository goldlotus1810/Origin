// NetworkMonitorSkill — ai đang gửi data ra ngoài
package agents

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type ConnInfo struct {
	PID        int
	ProcessName string
	LocalAddr  string
	RemoteAddr string
	State      string
	Suspicious bool
	Reason     string
}

type NetworkSnapshot struct {
	At          time.Time
	Conns       []ConnInfo
	Suspicious  []ConnInfo
	ExternalOut int // số kết nối ra internet
}

type NetworkMonitorSkill struct {
	// IP nội bộ được phép
	trustedRanges []string
}

func NewNetworkMonitorSkill() *NetworkMonitorSkill {
	return &NetworkMonitorSkill{
		trustedRanges: []string{
			"127.", "192.168.", "10.", "172.16.",
			"172.17.", "172.18.", "172.19.",
			"::1", "fe80::",
		},
	}
}

func (s *NetworkMonitorSkill) Name() string { return "network_monitor" }

func (s *NetworkMonitorSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgSync
}

func (s *NetworkMonitorSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	snap := s.scanConnections()

	ctx.State["network.total"]      = len(snap.Conns)
	ctx.State["network.external"]   = snap.ExternalOut
	ctx.State["network.suspicious"] = len(snap.Suspicious)
	ctx.State["network.snapshot"]   = snap

	var notifyMsg *isl.ISLMessage
	if len(snap.Suspicious) > 0 {
		alert := s.buildAlert(snap)
		notifyMsg = &isl.ISLMessage{
			MsgType: isl.MsgKnowledge,
			Payload: []byte(alert),
		}
	}

	return SkillResult{
		Data: map[string]interface{}{
			"network.total":      len(snap.Conns),
			"network.external":   snap.ExternalOut,
			"network.suspicious": len(snap.Suspicious),
		},
		Message: notifyMsg,
	}
}

func (s *NetworkMonitorSkill) scanConnections() *NetworkSnapshot {
	snap := &NetworkSnapshot{At: time.Now()}

	// Đọc /proc/net/tcp và tcp6
	for _, netFile := range []string{"/proc/net/tcp", "/proc/net/tcp6"} {
		data, err := os.ReadFile(netFile)
		if err != nil {
			continue
		}
		for i, line := range strings.Split(string(data), "\n") {
			if i == 0 || strings.TrimSpace(line) == "" {
				continue
			}
			conn := s.parseTCPLine(line)
			if conn == nil {
				continue
			}
			snap.Conns = append(snap.Conns, *conn)
			if !s.isTrusted(conn.RemoteAddr) && conn.State == "ESTABLISHED" {
				snap.ExternalOut++
			}
			if conn.Suspicious {
				snap.Suspicious = append(snap.Suspicious, *conn)
			}
		}
	}
	return snap
}

func (s *NetworkMonitorSkill) parseTCPLine(line string) *ConnInfo {
	fields := strings.Fields(line)
	if len(fields) < 4 {
		return nil
	}
	local  := s.hexToAddr(fields[1])
	remote := s.hexToAddr(fields[2])
	state  := s.tcpState(fields[3])

	conn := &ConnInfo{
		LocalAddr:  local,
		RemoteAddr: remote,
		State:      state,
	}

	// Check suspicious
	if state == "ESTABLISHED" && !s.isTrusted(remote) {
		conn.Suspicious = true
		conn.Reason = fmt.Sprintf("external connection to %s", remote)
	}
	return conn
}

func (s *NetworkMonitorSkill) hexToAddr(hex string) string {
	parts := strings.Split(hex, ":")
	if len(parts) != 2 {
		return hex
	}
	// IPv4
	ipHex := parts[0]
	portHex := parts[1]
	if len(ipHex) == 8 {
		b0, _ := strconv.ParseUint(ipHex[6:8], 16, 8)
		b1, _ := strconv.ParseUint(ipHex[4:6], 16, 8)
		b2, _ := strconv.ParseUint(ipHex[2:4], 16, 8)
		b3, _ := strconv.ParseUint(ipHex[0:2], 16, 8)
		port, _ := strconv.ParseUint(portHex, 16, 16)
		return fmt.Sprintf("%d.%d.%d.%d:%d", b0, b1, b2, b3, port)
	}
	return hex
}

func (s *NetworkMonitorSkill) tcpState(hex string) string {
	states := map[string]string{
		"01": "ESTABLISHED", "02": "SYN_SENT", "03": "SYN_RECV",
		"04": "FIN_WAIT1", "05": "FIN_WAIT2", "06": "TIME_WAIT",
		"07": "CLOSE", "08": "CLOSE_WAIT", "09": "LAST_ACK",
		"0A": "LISTEN", "0B": "CLOSING",
	}
	if s, ok := states[strings.ToUpper(hex)]; ok {
		return s
	}
	return hex
}

func (s *NetworkMonitorSkill) isTrusted(addr string) bool {
	for _, prefix := range s.trustedRanges {
		if strings.HasPrefix(addr, prefix) {
			return true
		}
	}
	return false
}

func (s *NetworkMonitorSkill) buildAlert(snap *NetworkSnapshot) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("⚠ NetworkMonitor: %d external, %d suspicious\n",
		snap.ExternalOut, len(snap.Suspicious)))
	for _, c := range snap.Suspicious {
		sb.WriteString(fmt.Sprintf("  [%s] %s → %s — %s\n",
			c.State, c.LocalAddr, c.RemoteAddr, c.Reason))
	}
	return sb.String()
}
