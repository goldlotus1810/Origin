// AppLauncherSkill — kiểm tra app đã cài + launch
// Anchor: HW_ARCH (🔧 U+1F527)
// Flow: AppInstalledSkill → AppLauncherSkill (check trước, launch sau)
package agents

import (
	"fmt"
	"os/exec"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type AppInfo struct {
	Name       string
	Installed  bool
	Path       string // full path if installed
	PkgManager string // pacman/apt/brew
}

type LaunchResult struct {
	App     string
	At      time.Time
	Success bool
	PID     int
	Error   string
}

type AppLauncherSkill struct {
	cache    map[string]*AppInfo
	cacheTTL time.Duration
	cachedAt map[string]time.Time
	launches []LaunchResult
}

func NewAppLauncherSkill() *AppLauncherSkill {
	return &AppLauncherSkill{
		cache:    make(map[string]*AppInfo),
		cacheTTL: 5 * time.Minute,
		cachedAt: make(map[string]time.Time),
	}
}

func (s *AppLauncherSkill) Name() string { return "app_launcher" }

func (s *AppLauncherSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg.MsgType != isl.MsgQuery && msg.MsgType != isl.MsgActuatorCmd {
		return false
	}
	body := strings.ToLower(strings.TrimSpace(string(msg.Payload)))
	return strings.HasPrefix(body, "launch:") ||
		strings.HasPrefix(body, "check:") ||
		strings.HasPrefix(body, "install?:")
}

func (s *AppLauncherSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	body := strings.TrimSpace(string(msg.Payload))

	var cmd, appName string
	if idx := strings.IndexByte(body, ':'); idx >= 0 {
		cmd     = strings.ToLower(body[:idx])
		appName = strings.TrimSpace(body[idx+1:])
	}
	if appName == "" {
		return SkillResult{}
	}

	switch cmd {
	case "check", "install?":
		info := s.checkInstalled(appName)
		ctx.State["app."+appName+".installed"] = info.Installed
		ctx.State["app."+appName+".path"]      = info.Path
		return SkillResult{Data: map[string]interface{}{
			"app.name":      appName,
			"app.installed": info.Installed,
			"app.path":      info.Path,
		}}

	case "launch":
		// Check trước
		info := s.checkInstalled(appName)
		if !info.Installed {
			errMsg := fmt.Sprintf("App '%s' not installed", appName)
			return SkillResult{
				Data: map[string]interface{}{"app.error": errMsg},
				Message: &isl.ISLMessage{
					MsgType: isl.MsgKnowledge,
					Payload: []byte("⚠ " + errMsg),
				},
			}
		}
		result := s.launch(info)
		s.launches = append(s.launches, result)

		data := map[string]interface{}{
			"app.name":    appName,
			"app.launched": result.Success,
			"app.pid":     result.PID,
		}
		if !result.Success {
			data["app.error"] = result.Error
		}
		return SkillResult{Data: data}
	}

	return SkillResult{}
}

func (s *AppLauncherSkill) checkInstalled(name string) *AppInfo {
	// Cache
	if info, ok := s.cache[name]; ok {
		if time.Since(s.cachedAt[name]) < s.cacheTTL {
			return info
		}
	}

	info := &AppInfo{Name: name}

	// 1. which/whereis
	path, err := exec.LookPath(name)
	if err == nil && path != "" {
		info.Installed = true
		info.Path = path
		s.cache[name] = info
		s.cachedAt[name] = time.Now()
		return info
	}

	// 2. pacman -Qi (Arch)
	if out, err := exec.Command("pacman", "-Qi", name).Output(); err == nil {
		if strings.Contains(string(out), "Name") {
			info.Installed = true
			info.PkgManager = "pacman"
		}
	}

	// 3. dpkg -l (Debian/Ubuntu)
	if !info.Installed {
		if out, err := exec.Command("dpkg", "-l", name).Output(); err == nil {
			if strings.Contains(string(out), "ii") {
				info.Installed = true
				info.PkgManager = "apt"
			}
		}
	}

	s.cache[name] = info
	s.cachedAt[name] = time.Now()
	return info
}

func (s *AppLauncherSkill) launch(info *AppInfo) LaunchResult {
	result := LaunchResult{App: info.Name, At: time.Now()}

	appPath := info.Path
	if appPath == "" { appPath = info.Name }

	cmd := exec.Command(appPath)
	cmd.Env = append(cmd.Environ(),
		"DISPLAY=:0",
		"WAYLAND_DISPLAY=wayland-0",
	)

	if err := cmd.Start(); err != nil {
		result.Error = err.Error()
		return result
	}

	result.Success = true
	if cmd.Process != nil {
		result.PID = cmd.Process.Pid
	}
	return result
}
