// internal/agents/vision_chief.go
// VisionChief — agent nhận spatial messages → ghi vào shortterm memory
//
// VisionChief = Chief agent cho spatial perception:
//   nhận ISLMessage từ SpatialDispatcher (qua Bus)
//   → decode ISLAddr từ message
//   → lưu vào shortterm memory (ĐN)
//   → ISL edge: probe_addr → target_addr (weighted bằng confidence)
//
// Không march rays. Nhận kết quả từ vSDF đã evaluate.

package agents

import (
	"fmt"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// SpatialObservation — 1 lần quan sát không gian
type SpatialObservation struct {
	At         time.Time
	TargetAddr uint64  // ISLAddr của node quan sát được
	Dist       float64 // (không dùng trực tiếp — từ confidence)
	Inside     bool    // flags=0x01
	Confidence uint32  // 0-100
	TickN      uint64
}

// VisionChief agent
type VisionChief struct {
	ID      string
	Inbox   chan *isl.ISLMessage

	mu     sync.RWMutex
	mem    []SpatialObservation // shortterm memory (ĐN)
	maxMem int
	tickN  uint64
}

// NewVisionChief tạo VisionChief
func NewVisionChief(id string, bufSize int) *VisionChief {
	return &VisionChief{
		ID:     id,
		Inbox:  make(chan *isl.ISLMessage, bufSize),
		maxMem: 512,
	}
}

// Run vòng lặp xử lý message
// Gọi trong goroutine riêng
func (vc *VisionChief) Run(stop <-chan struct{}) {
	for {
		select {
		case <-stop:
			return
		case msg := <-vc.Inbox:
			vc.process(msg)
		}
	}
}

// process xử lý 1 ISLMessage từ SpatialDispatcher
func (vc *VisionChief) process(msg *isl.ISLMessage) {
	vc.tickN++

	// Decode ISLAddr từ PrimaryAddr
	addr := uint64(msg.PrimaryAddr.Layer)<<56 |
		uint64(msg.PrimaryAddr.Group)<<48 |
		uint64(msg.PrimaryAddr.Type)<<40 |
		uint64(msg.PrimaryAddr.ID)<<32

	obs := SpatialObservation{
		At:         time.Now(),
		TargetAddr: addr,
		Inside:     msg.Flags&0x01 != 0,
		Confidence: msg.Confidence,
		TickN:      vc.tickN,
	}

	vc.mu.Lock()
	vc.mem = append(vc.mem, obs)
	// Giữ maxMem observations gần nhất (sliding window)
	if len(vc.mem) > vc.maxMem {
		vc.mem = vc.mem[len(vc.mem)-vc.maxMem:]
	}
	vc.mu.Unlock()
}

// Recent trả về N observations gần nhất
func (vc *VisionChief) Recent(n int) []SpatialObservation {
	vc.mu.RLock()
	defer vc.mu.RUnlock()
	if n > len(vc.mem) { n = len(vc.mem) }
	out := make([]SpatialObservation, n)
	copy(out, vc.mem[len(vc.mem)-n:])
	return out
}

// Tally đếm tần suất mỗi ISLAddr trong memory
func (vc *VisionChief) Tally() map[uint64]int {
	vc.mu.RLock()
	defer vc.mu.RUnlock()
	m := make(map[uint64]int)
	for _, obs := range vc.mem {
		m[obs.TargetAddr]++
	}
	return m
}

// Dominant ISLAddr được quan sát nhiều nhất
func (vc *VisionChief) Dominant() (uint64, int) {
	tally := vc.Tally()
	var bestAddr uint64; bestCount := 0
	for addr, cnt := range tally {
		if cnt > bestCount { bestCount = cnt; bestAddr = addr }
	}
	return bestAddr, bestCount
}

// InsideCount đếm observations với Inside=true cho 1 addr
func (vc *VisionChief) InsideCount(addr uint64) int {
	vc.mu.RLock()
	defer vc.mu.RUnlock()
	n := 0
	for _, obs := range vc.mem {
		if obs.TargetAddr == addr && obs.Inside { n++ }
	}
	return n
}

// Summary debug string
func (vc *VisionChief) Summary() string {
	dom, cnt := vc.Dominant()
	vc.mu.RLock()
	total := len(vc.mem)
	vc.mu.RUnlock()
	return fmt.Sprintf("VisionChief[%s] mem=%d dominant=%016x×%d",
		vc.ID, total, dom, cnt)
}

// LabeledSummary trả về summary có human-readable labels
// Ví dụ: "earth × 128 (100%) | sun × 12 (9%)"
func (vc *VisionChief) LabeledSummary(labels *AddrLabelIndex) string {
	tally := vc.Tally()
	if len(tally) == 0 { return "VisionChief[" + vc.ID + "] — no observations" }

	// Sort by count desc
	type entry struct{ addr uint64; cnt int }
	entries := make([]entry, 0, len(tally))
	total := 0
	for addr, cnt := range tally {
		entries = append(entries, entry{addr, cnt})
		total += cnt
	}
	// Simple sort (max 10 entries thường)
	for i := 0; i < len(entries)-1; i++ {
		for j := i+1; j < len(entries); j++ {
			if entries[j].cnt > entries[i].cnt {
				entries[i], entries[j] = entries[j], entries[i]
			}
		}
	}

	parts := make([]string, 0, len(entries))
	for _, e := range entries {
		lbl := fmt.Sprintf("%016x", e.addr)
		if labels != nil { lbl = labels.LabelU64(e.addr) }
		pct := 0.0
		if total > 0 { pct = float64(e.cnt) / float64(total) * 100 }
		parts = append(parts, fmt.Sprintf("%s × %d (%.0f%%)", lbl, e.cnt, pct))
	}

	result := "VisionChief[" + vc.ID + "]: "
	for i, p := range parts {
		if i > 0 { result += " | " }
		result += p
	}
	return result
}
