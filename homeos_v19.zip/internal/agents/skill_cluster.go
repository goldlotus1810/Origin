// internal/agents/skill_cluster.go
//
// CLUSTER SKILL — QT7: ĐN → QR (học chủ động)
// =============================================
// MASTER.md §5.5 "Thăng cấp Lá → Nhánh → Cành":
//
//   1. Cluster detection:
//      Tìm nhóm ĐN có ISL cùng [layer][group]:
//        n >= 3  → propose Twig (Nhánh nhỏ)
//        n >= 10 → propose Twig (Nhánh)
//        n >= 60 → propose Branch (Cành)
//
//   2. Tạo node cha:
//      parent_addr = ISLAddress{layer, group, 0, 0, 0}
//      parent_edges = ∀ child → SilkEdge{child.Addr, ∈}
//
//   3. Propose lên AAM
//
// ClusterSkill là Skill của LeoAI.
// Chạy theo MsgTick (NxT cycle).
// Không giữ state — state nằm trong Agent (QT5 bất biến ④).

package agents

import (
	"fmt"
	"log"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/olang"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// Ngưỡng thăng cấp
const (
	ClusterTwig   = 3  // n >= 3 → propose parent node
	ClusterBranch = 10 // n >= 10 → propose branch
	ClusterTrunk  = 60 // n >= 60 → propose trunk
)

// ClusterSkill gom nhóm ĐN theo [layer][group] → propose parent
// NodePersister lưu cluster nodes vào file .olang sau khi AAM approve
type NodePersister interface {
	AppendNode(n *olang.OlangNode) error
	SaveToPath(path string) error
}

type ClusterSkill struct {
	dn         *memory.ShortTerm
	qr         *memory.LongTerm
	graph      *silk.SilkGraph
	persister  NodePersister // nil = in-memory only
	olangPath   string        // path để SaveToPath
}

func NewClusterSkill(dn *memory.ShortTerm, qr *memory.LongTerm, g *silk.SilkGraph) *ClusterSkill {
	return &ClusterSkill{dn: dn, qr: qr, graph: g}
}

// WithPersister wire NodePersister để persist cluster nodes vào .olang
func (s *ClusterSkill) WithPersister(p NodePersister, path string) *ClusterSkill {
	s.persister = p
	s.olangPath = path
	return s
}

func (s *ClusterSkill) Name() string { return "learn.cluster" }

func (s *ClusterSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg == nil {
		return false
	}
	return msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgLearn
}

func (s *ClusterSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.dn == nil {
		return SkillResult{}
	}

	proposals := s.detectClusters()
	if len(proposals) == 0 {
		return SkillResult{}
	}

	// Gửi MsgPropose cho từng cluster lên outbox → AAM approve → CommitCluster
	var outMsgs []*isl.ISLMessage
	proposed := make([]string, 0, len(proposals))
	for _, p := range proposals {
		proposed = append(proposed, p.Name)
		// Encode proposal: "name|level|childCount"
		payload := fmt.Appendf(nil, "cluster|%s|%s|%d", p.Name, p.Level, p.ChildCount)
		outMsgs = append(outMsgs, &isl.ISLMessage{
			MsgType:     isl.MsgPropose,
			PrimaryAddr: p.ParentAddr,
			Payload:     payload,
		})
		log.Printf("Cluster[%s]: %d nodes → MsgPropose parent [%02X][%02X]",
			p.Name, p.ChildCount,
			p.ParentAddr.Layer, p.ParentAddr.Group)
	}

	return SkillResult{
		Messages: outMsgs,
		Data: map[string]interface{}{
			"cluster.proposals": proposals,
			"cluster.count":     len(proposals),
			"cluster.last_run":  time.Now().Unix(),
		},
	}
}

// ClusterProposal là đề xuất tạo parent node
type ClusterProposal struct {
	ParentAddr isl.Address
	Name       string
	ChildCount int
	Level      string // "twig" | "branch" | "trunk"
	Children   []isl.Address
}

// detectClusters tìm tất cả nhóm ĐN đủ ngưỡng
func (s *ClusterSkill) detectClusters() []ClusterProposal {
	if s.dn == nil {
		return nil
	}

	// Lấy tất cả entries trong ShortTerm
	entries := s.dn.All()
	if len(entries) == 0 {
		return nil
	}

	// Nhóm theo [layer][group] — 2 bytes đầu của ISL
	type groupKey struct{ layer, group byte }
	groups := map[groupKey][]memory.Observation{}

	for _, e := range entries {
		key := groupKey{e.ISL.Layer, e.ISL.Group}
		groups[key] = append(groups[key], e)
	}

	var proposals []ClusterProposal
	for key, children := range groups {
		n := len(children)
		if n < ClusterTwig {
			continue
		}

		// Kiểm tra parent chưa tồn tại trong QR
		parentAddr := isl.Address{Layer: key.layer, Group: key.group}
		if _, exists := s.graph.Get(parentAddr); exists {
			continue // đã có parent rồi
		}

		level := "twig"
		if n >= ClusterTrunk {
			level = "trunk"
		} else if n >= ClusterBranch {
			level = "branch"
		}

		childAddrs := make([]isl.Address, len(children))
		for i, c := range children {
			childAddrs[i] = c.ISL
		}

		proposals = append(proposals, ClusterProposal{
			ParentAddr: parentAddr,
			Name:       fmt.Sprintf("cluster[%02X][%02X]", key.layer, key.group),
			ChildCount: n,
			Level:      level,
			Children:   childAddrs,
		})
	}

	return proposals
}

// CommitCluster ghi parent node + edges vào SilkGraph
// Gọi sau khi AAM approve
func (s *ClusterSkill) CommitCluster(p ClusterProposal) {
	if s.graph == nil {
		return
	}

	// Tạo parent node
	parentNode := &silk.OlangNode{
		Addr:   p.ParentAddr,
		Name:   p.Name,
		Cat:    "cluster",
		Status: silk.StatusQR,
		Weight: p.ChildCount,
	}
	s.graph.AddNode(parentNode)

	// Persist parent node vào .olang nếu persister được wire
	if s.persister != nil {
		olangNode := &olang.OlangNode{
			OlangNodeHeader: olang.OlangNodeHeader{
				ISLAddr: p.ParentAddr.Uint64(),
				Flags:   (uint8(p.ParentAddr.Layer)<<4) | 0b01, // layer | QR
			},
			DNA: []byte("cluster=" + p.Name),
		}
		if err := s.persister.AppendNode(olangNode); err != nil {
			log.Printf("ClusterSkill: persist parent node failed: %v", err)
		} else if s.olangPath != "" {
			go func() {
				if err := s.persister.SaveToPath(s.olangPath); err != nil {
					log.Printf("ClusterSkill: SaveToPath failed: %v", err)
				}
			}()
		}
	}

	// Thêm ∈ edges: child → parent
	for _, childAddr := range p.Children {
		s.graph.AddEdge(childAddr, p.ParentAddr, silk.OpMember)
	}

	// Archive children trong ShortTerm (không xóa — QT append-only)
	// childAddr là ISL address — tìm observations ở vùng đó để archive
	for _, childAddr := range p.Children {
		neighbors := s.dn.GetByISL(childAddr)
		for _, obs := range neighbors {
			s.dn.MarkArchived(obs.NodeHash)
		}
	}

	log.Printf("Cluster committed: %s (%d children, %d edges)",
		p.Name, len(p.Children), len(p.Children))
}
