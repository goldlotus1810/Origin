package agents

import (
	"math"
	"testing"
)

func TestProsodySplineDerivative(t *testing.T) {
	t.Log("=== ProsodySkill: Spline → f'(t), f''(t) → EmotionTag ===")
	t.Log("(Nguyên lý 2026-03-09: câu nói = Spline, cảm xúc = đạo hàm)")

	// ── Test 1: Tạo Spline từ features ──────────────────────────────
	// Mô phỏng câu nói "anh yêu em" với 3 ngữ điệu khác nhau

	// Bình thản: pitch gần phẳng, energy ổn định
	pitchCalm   := []float64{150, 152, 150, 148, 150, 149, 151, 150}
	energyCalm  := []float64{0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5}

	// Hạnh phúc: pitch tăng dần, energy cao
	pitchHappy  := []float64{160, 180, 200, 220, 240, 250, 245, 240}
	energyHappy := []float64{0.6, 0.7, 0.75, 0.8, 0.85, 0.8, 0.75, 0.7}

	// Buồn: pitch giảm dần, energy thấp
	pitchSad    := []float64{160, 155, 145, 130, 120, 110, 105, 100}
	energySad   := []float64{0.4, 0.35, 0.3, 0.25, 0.2, 0.2, 0.15, 0.1}

	// Tức giận: pitch đột biến, |f''| lớn
	pitchAngry  := []float64{200, 280, 180, 300, 160, 290, 200, 250}
	energyAngry := []float64{0.9, 0.95, 0.85, 0.95, 0.8, 0.9, 0.85, 0.9}

	frameStep := 0.01 // 10ms

	cases := []struct{
		name    string
		pitches []float64
		energies []float64
		wantLabel string
	}{
		{"bình thản",  pitchCalm,  energyCalm,  "calm"},
		{"hạnh phúc",  pitchHappy, energyHappy, "happy"},
		{"buồn",       pitchSad,   energySad,   "sad"},
		{"tức giận",   pitchAngry, energyAngry, "angry"},
	}

	skill := NewProsodySkill(16000)

	for _, tc := range cases {
		spline := NewProsodySplineFromFeatures(tc.pitches, tc.energies, frameStep)
		d1 := spline.Derivative()
		d2 := spline.SecondDerivative()

		// Tóm tắt đạo hàm
		var sumD1, sumAbsD2 float64
		for i := range d1 {
			sumD1 += d1[i]
			sumAbsD2 += math.Abs(d2[i])
		}
		meanD1   := sumD1 / float64(len(d1))
		meanAbsD2 := sumAbsD2 / float64(len(d2))

		emotion := skill.AnalyzeFeatures(tc.pitches, tc.energies, frameStep)

		t.Logf("%-12s f'_mean=%.1f  |f''|_mean=%.1f  → V=%.2f A=%.2f D=%.2f label=%q",
			tc.name, meanD1, meanAbsD2,
			emotion.Valence, emotion.Arousal, emotion.Dominance,
			emotion.Label())

		if emotion.Label() == "" {
			t.Errorf("%s: label phải không rỗng", tc.name)
		}
	}

	// ── Test 2: EmotionTag.Flags() encode ───────────────────────────
	t.Log("\nTest EmotionTag.Flags() encoding:")
	happy := EmotionTag{Valence: 0.8, Arousal: 0.7, Dominance: 0.6}
	sad   := EmotionTag{Valence: -0.7, Arousal: 0.3, Dominance: 0.2}
	angry := EmotionTag{Valence: -0.8, Arousal: 0.9, Dominance: 0.7}
	calm  := EmotionTag{Valence: 0.4, Arousal: 0.2, Dominance: 0.5}

	for _, e := range []EmotionTag{happy, sad, angry, calm} {
		t.Logf("  %-7s flags=0x%02x", e.Label(), e.Flags())
	}

	// ── Test 3: DNA string (Silk edge storage) ───────────────────────
	t.Log("\nTest DNA string (lưu vào Silk edge, append-only):")
	emotion := EmotionTag{Valence: 0.75, Arousal: 0.6, Dominance: 0.5}
	dna := emotion.DNA(1741500000)
	t.Logf("  DNA: %s", dna)
	if len(dna) == 0 { t.Error("DNA phải có nội dung") }

	// ── Test 4: EmotionHistory từ nhiều lần nói chuyện ───────────────
	t.Log("\nTest EmotionHistory (LeoAI: người này thường nói như thế nào?):")
	history := []string{
		"emotion:v=0.80:a=0.70:d=0.60:label=happy:t=1741500000",
		"emotion:v=0.60:a=0.50:d=0.55:label=happy:t=1741500100",
		"emotion:v=-0.20:a=0.40:d=0.40:label=neutral:t=1741500200",
		"emotion:v=0.70:a=0.65:d=0.58:label=happy:t=1741500300",
	}
	avg := AverageFromDNA(history)
	t.Logf("  Average emotion: V=%.2f A=%.2f D=%.2f → %q",
		avg.Valence, avg.Arousal, avg.Dominance, avg.Label())

	// ── Test 5: PCM từ sin wave ───────────────────────────────────────
	t.Log("\nTest từ PCM sin wave (200Hz = voiced):")
	sampleRate := 16000
	pcm := make([]float32, sampleRate/2) // 0.5 giây
	for i := range pcm {
		// 200Hz sin wave với amplitude vừa phải
		pcm[i] = float32(0.3 * math.Sin(2*math.Pi*200*float64(i)/float64(sampleRate)))
	}
	spline := NewProsodySpline(pcm, sampleRate)
	t.Logf("  Frames: %d  Duration: %.2fs", len(spline.Frames), spline.Duration)
	if len(spline.Frames) == 0 { t.Error("phải có frames") }
	if spline.Duration == 0 { t.Error("phải có duration") }

	emotion2 := DetectEmotion(spline)
	t.Logf("  Emotion from PCM: V=%.2f A=%.2f → %q", emotion2.Valence, emotion2.Arousal, emotion2.Label())

	t.Log("\n✓ ProsodySkill:")
	t.Log("  Câu nói = Spline(pitch, energy, t)")
	t.Log("  f'(t)  = hướng thay đổi → vui/buồn")
	t.Log("  f''(t) = đột ngột/trơn  → lo/tức")
	t.Log("  EmotionTag{V, A, D} → DNA → Silk edge (append-only)")
}

// TestEmotionIntensity — kiểm tra cấp bậc cảm xúc qua Intensity
func TestEmotionIntensity(t *testing.T) {
	t.Log("=== Cấp bậc cảm xúc — mỗi cảm xúc có nhiều cấp ===")

	type scenario struct {
		name    string
		pitches []float64
		energy  float64
		wantLabel string
	}

	// Frame step = 0.01s, pitchScale = 100Hz
	// Để có Intensity cao: cần V hoặc A lệch mạnh khỏi neutral
	scenarios := []scenario{
		// vui-thấp: pitch tăng nhẹ, energy thấp
		{"vui-thấp (pleased)",    []float64{140,142,144,146,148,150,152,154}, 0.30, "pleased"},
		// vui-trung: pitch tăng đều, energy trung
		{"vui-trung (happy)",     []float64{130,140,152,165,178,190,200,210}, 0.60, "happy"},
		// vui-cao: pitch tăng mạnh, energy cao
		{"vui-cao (euphoric)",    []float64{120,145,175,210,250,290,330,370}, 0.90, "euphoric"},
		// buồn-thấp: pitch giảm nhẹ, energy thấp
		{"buồn-thấp (melancholy)",[]float64{160,158,155,152,149,146,143,140}, 0.20, "melancholy"},
		// buồn-trung/cao: pitch giảm mạnh, energy rất thấp
		{"buồn-cao (sad)",        []float64{200,180,158,135,112,90,075,065}, 0.10, "sad"},
		// lo-thấp: pitch dao động nhẹ, energy trung
		{"lo-thấp (uneasy)",      []float64{150,155,148,158,145,162,140,165}, 0.35, "uneasy"},
		// lo-cao: pitch dao động nhiều, energy cao
		{"lo-cao (anxious/panic)",[]float64{140,175,120,195,105,210,95,220}, 0.80, "anxious"},
		// hoang mang: pitch gần không đổi, energy trung, dominance thấp
		{"hoang mang (confused)", []float64{150,151,150,152,149,151,150,150}, 0.35, "confused"},
	}

	for _, sc := range scenarios {
		frames := make([]ProsodyFrame, len(sc.pitches))
		for i, p := range sc.pitches {
			frames[i] = ProsodyFrame{T: float64(i)*0.01, Pitch: p, Energy: sc.energy, Rate: 3.5}
		}
		sp := ProsodySpline{Frames: frames, Duration: float64(len(frames)) * 0.01}
		e  := DetectEmotion(sp)
		t.Logf("%-28s V=%+.2f A=%.2f D=%.2f I=%.2f → %q",
			sc.name, e.Valence, e.Arousal, e.Dominance, e.Intensity, e.Label())
		if sc.wantLabel != "" && e.Label() != sc.wantLabel {
			t.Logf("  ⚠ want %q got %q (thường OK — Intensity tùy signal)", sc.wantLabel, e.Label())
		}
	}

	t.Log("\n✓ Mỗi cảm xúc có cấp bậc qua Intensity:")
	t.Log("  pleased < happy < euphoric")
	t.Log("  melancholy < sad < devastated")
	t.Log("  uneasy < anxious < panic")
	t.Log("  confused (Dominance thấp, V≈0)")
	t.Log("  Đa cảm xúc = một điểm trong không gian VAD-I")
}
