// internal/agents/bookshelf.go
// BookShelf — kho sách đã đọc + nói chuyện có cảm xúc
//
// "tấm màn đen" — ranh giới giữa AI trả lời cứng và AI biết nịnh
//
// Pipeline:
//   Brain.bookShelf.Read(book) → BookMemory
//   user hỏi → findBook() → RespondWithEmotion(userCurve)
//   → AffectSentence dẫn tone → trả lời từ memory → hỏi lại
//
// Nguyên tắc "nịnh đúng lúc":
//   user buồn   → đồng cảm trước, thông tin sau
//   user vui    → chia vui, củng cố, mở rộng
//   user tò mò  → khơi gợi thêm, hỏi ngược lại
//   KHÔNG nịnh khi user không cần — giả tạo = tệ hơn im lặng

package agents

import (
	"fmt"
	"strings"
)

// BookShelf — kho sách đã đọc
type BookShelf struct {
	Books   map[string]*BookMemory // title_lower → memory
	Aliases map[string]string      // "scarlett" → "cuốn theo chiều gió"
}

func NewBookShelf() *BookShelf {
	return &BookShelf{
		Books:   make(map[string]*BookMemory),
		Aliases: make(map[string]string),
	}
}

// Read đọc toàn bộ văn bản và lưu vào shelf
func (s *BookShelf) Read(title string, paragraphs []string) *BookMemory {
	mem := NewBookMemory(title)
	for _, p := range paragraphs {
		mem.ReadParagraph(p)
	}
	key := strings.ToLower(title)
	s.Books[key] = mem

	// Tự động tạo alias từ các từ quan trọng
	for word := range mem.Words {
		if len([]rune(word)) >= 4 {
			s.Aliases[word] = key
		}
	}
	// Thêm alias từ top emotional words
	for _, lw := range mem.TopEmotionalWords(20) {
		s.Aliases[lw.Word] = key
	}
	return mem
}

// Find tìm BookMemory phù hợp với câu hỏi
func (s *BookShelf) Find(query string) (*BookMemory, string) {
	lo := strings.ToLower(query)

	// Tìm trực tiếp theo title
	for title, mem := range s.Books {
		if strings.Contains(lo, title) {
			return mem, title
		}
	}

	// Tìm theo alias (tên nhân vật, từ đặc trưng)
	bestTitle := ""
	bestCount := 0
	for alias, title := range s.Aliases {
		if strings.Contains(lo, alias) {
			// Đếm số alias match để lấy sách liên quan nhất
			count := 0
			for a, t := range s.Aliases {
				if t == title && strings.Contains(lo, a) {
					count++
				}
			}
			if count > bestCount {
				bestCount = count
				bestTitle = title
			}
		}
	}
	if bestTitle != "" {
		return s.Books[bestTitle], bestTitle
	}
	return nil, ""
}

// ─── Emotional Response ───────────────────────────────────────────────────

// RespondWithEmotion tạo câu trả lời thật sự có cảm xúc
// Dựa trên: BookMemory + userCurve + tone hiện tại
func (s *BookShelf) RespondWithEmotion(query string, userCurve *ConversationCurve) string {
	mem, bookTitle := s.Find(query)
	tone := userCurve.NextTone()
	target := TargetAffect(userCurve)
	words := SelectWords(target, 4)

	// Không tìm thấy sách
	if mem == nil {
		return s.respondNoBook(query, tone, words)
	}

	lo := strings.ToLower(query)

	// ── Nhận ra nhân vật / từ khóa trong sách ────────────────────
	var matchedWord *LearnedWord
	var matchedKey string
	for word, lw := range mem.Words {
		if strings.Contains(lo, word) && lw.Count >= 1 {
			if matchedWord == nil || lw.Tag.Intensity > matchedWord.Tag.Intensity {
				matchedWord = lw
				matchedKey = word
			}
		}
	}

	// ── Xây dựng response theo tone ──────────────────────────────
	var b strings.Builder

	// Prefix cảm xúc (nịnh đúng lúc)
	prefix := emotionalPrefix(tone, userCurve, words)
	if prefix != "" {
		b.WriteString(prefix)
		b.WriteString(" ")
	}

	if matchedWord != nil {
		// Có từ khóa cụ thể
		b.WriteString(respondAboutWord(matchedKey, matchedWord, mem, bookTitle, tone))
	} else {
		// Hỏi chung về sách
		b.WriteString(respondAboutBook(mem, bookTitle, tone))
	}

	// Hỏi ngược lại (tạo kết nối)
	question := generateQuestion(tone, matchedWord, mem)
	if question != "" {
		b.WriteString("\n\n")
		b.WriteString(question)
	}

	return b.String()
}

// ─── Response builders ────────────────────────────────────────────────────

func emotionalPrefix(tone ResponseTone, curve *ConversationCurve, words []WordCandidate) string {
	if len(curve.Window) == 0 || len(words) == 0 {
		return ""
	}
	cur := curve.Window[len(curve.Window)-1].Tag

	switch tone.Style {
	case "supportive":
		// User đang buồn → đồng cảm thật sự, không giả tạo
		return fmt.Sprintf("Mình hiểu cảm giác đó —")
	case "pause":
		// Đột ngột nặng → dừng lại
		return fmt.Sprintf("Ừ, cái đó thực sự nặng.")
	case "reinforcing":
		// Đang hồi phục → nhẹ nhàng củng cố
		return fmt.Sprintf("Bạn đang cảm nhận được điều thú vị đó rồi đấy.")
	case "celebratory":
		// Đang vui → chia vui tự nhiên
		if cur.Valence > 0.3 {
			return fmt.Sprintf("Đúng rồi, đúng rồi!")
		}
	case "gentle":
		return fmt.Sprintf("Cứ từ từ,")
	}
	return ""
}

func respondAboutWord(key string, lw *LearnedWord, mem *BookMemory, title string, tone ResponseTone) string {
	// Tìm semantic pairs liên quan
	relatedPairs := []string{}
	for _, p := range mem.StrongestPairs(20) {
		if p.WordA == key || p.WordB == key {
			other := p.WordB
			if p.WordA != key {
				other = p.WordA
			}
			relatedPairs = append(relatedPairs, other)
		}
	}

	// Mô tả cảm xúc của từ
	emoDesc := describeEmotion(lw.Tag)

	var b strings.Builder
	switch tone.Style {
	case "supportive", "pause", "gentle":
		// User đang nặng nề → đồng cảm với nhân vật
		b.WriteString(fmt.Sprintf(
			"\"%s\" trong %s mang cảm giác %s (V=%+.2f). ",
			key, title, emoDesc, lw.Tag.Valence))
		if lw.Count > 1 {
			b.WriteString(fmt.Sprintf(
				"Từ này xuất hiện %d lần, thường trong những khoảnh khắc nặng nề nhất. ",
				lw.Count))
		}
		if len(lw.Examples) > 0 {
			b.WriteString(fmt.Sprintf("Ví dụ: \"%s\"", lw.Examples[0]))
		}

	case "reinforcing", "celebratory", "engaged":
		// User đang tích cực → phân tích thú vị hơn
		b.WriteString(fmt.Sprintf(
			"\"%s\" là một trong những từ/nhân vật thú vị nhất của %s — ", key, title))
		if len(relatedPairs) > 0 {
			b.WriteString(fmt.Sprintf(
				"thường xuất hiện cùng với: %s. ",
				strings.Join(relatedPairs[:min3(len(relatedPairs), 3)], ", ")))
		}
		b.WriteString(fmt.Sprintf(
			"Cảm xúc tích lũy: %s.", emoDesc))

	default:
		b.WriteString(fmt.Sprintf(
			"Trong %s, \"%s\" mang cảm giác %s.",
			title, key, emoDesc))
		if len(lw.Examples) > 0 {
			b.WriteString(fmt.Sprintf(" \"%s\"", lw.Examples[0]))
		}
	}
	return b.String()
}

func respondAboutBook(mem *BookMemory, title string, tone ResponseTone) string {
	avg := mem.History.AverageVAD()
	top := mem.TopEmotionalWords(3)
	pairs := mem.StrongestPairs(2)

	var b strings.Builder
	switch tone.Style {
	case "supportive", "gentle":
		b.WriteString(fmt.Sprintf(
			"%s là một cuốn sách %s (avg V=%+.2f). ",
			title, describeEmotion(avg), avg.Valence))
		if len(top) >= 2 {
			b.WriteString(fmt.Sprintf(
				"Những từ để lại ấn tượng sâu nhất: \"%s\" và \"%s\".",
				top[0].Word, top[1].Word))
		}

	case "reinforcing", "celebratory":
		b.WriteString(fmt.Sprintf(
			"%s có hành trình cảm xúc %d bước ngoặt — ",
			title, len(mem.Inflections)))
		if len(mem.Inflections) >= 2 {
			b.WriteString(fmt.Sprintf(
				"từ %s đến %s. ",
				mem.Inflections[0].Tag.Label(),
				mem.Inflections[len(mem.Inflections)-1].Tag.Label()))
		}
		if len(pairs) > 0 {
			b.WriteString(fmt.Sprintf(
				"Cặp từ hay xuất hiện cùng nhau: \"%s\" và \"%s\".",
				pairs[0].WordA, pairs[0].WordB))
		}

	default:
		b.WriteString(fmt.Sprintf(
			"%s: %d từ học được, dominant mood: %s.",
			title, len(mem.Words), avg.Label()))
	}
	return b.String()
}

func generateQuestion(tone ResponseTone, lw *LearnedWord, mem *BookMemory) string {
	switch tone.Style {
	case "supportive", "pause":
		return "Bạn đang đọc đến phần nào rồi?"
	case "gentle":
		return "Bạn cảm thấy thế nào về nhân vật đó?"
	case "reinforcing":
		return "Có nhân vật nào trong sách khiến bạn thấy gần gũi không?"
	case "celebratory":
		if lw != nil && lw.Tag.Valence > 0.3 {
			return "Bạn thích nhất khoảnh khắc nào trong sách?"
		}
		return "Bạn đã đọc xong chưa hay vẫn đang đọc dở?"
	default:
		return ""
	}
}

// respondNoBook — khi không tìm thấy sách
func (s *BookShelf) respondNoBook(query string, tone ResponseTone, words []WordCandidate) string {
	switch tone.Style {
	case "supportive":
		return "Mình chưa đọc cuốn đó, nhưng mình đang lắng nghe. Bạn kể cho mình nghe đi?"
	case "celebratory":
		return "Mình chưa đọc nhưng nghe có vẻ thú vị! Tên sách là gì vậy?"
	default:
		return "Mình chưa đọc cuốn đó. Bạn có thể kể một chút không?"
	}
}

// ─── Helpers ──────────────────────────────────────────────────────────────

func describeEmotion(tag EmotionTag) string {
	switch {
	case tag.Valence < -0.70: return "rất nặng nề và đau buồn"
	case tag.Valence < -0.40: return "u ám, căng thẳng"
	case tag.Valence < -0.15: return "hơi buồn, trĩu nặng"
	case tag.Valence < +0.15: return "bình thản, trung tính"
	case tag.Valence < +0.40: return "nhẹ nhàng, thoải mái"
	case tag.Valence < +0.65: return "vui vẻ, tích cực"
	default:                  return "rất vui, phấn khích"
	}
}

func min3(a, b int) int {
	if a < b { return a }
	return b
}

// AllTitles trả tên tất cả sách đã đọc
func (s *BookShelf) AllTitles() []string {
	titles := make([]string, 0, len(s.Books))
	for title := range s.Books {
		titles = append(titles, title)
	}
	return titles
}

// ─── GWTW corpus mặc định (để test/demo) ─────────────────────────────────

func GWTWCorpus() []string {
	return []string{
		"Scarlett O'Hara không đẹp theo tiêu chuẩn thông thường, nhưng đàn ông hiếm khi nhận ra điều đó khi bị cuốn hút bởi sức sống và sự quyến rũ của cô.",
		"Cô yêu Ashley Wilkes từ khi còn nhỏ, một tình yêu mà cô tưởng chắc chắn sẽ được đáp lại.",
		"Nhưng Ashley đã đính hôn với Melanie Hamilton, và trái tim Scarlett vỡ tan.",
		"Rhett Butler — người đàn ông nguy hiểm với nụ cười bí ẩn — nhìn thấu cô ngay từ buổi đầu.",
		"Chiến tranh ập đến như cơn bão. Atlanta rực lửa. Tiếng súng ngày càng gần hơn.",
		"Rhett Butler bế Scarlett chạy qua những con phố ngập khói và lửa.",
		"Họ để lại tất cả phía sau — ngôi nhà, tài sản, cuộc sống cũ — trong cơn hỗn loạn.",
		"Melanie sinh con giữa tiếng bom đạn. Máu và sợ hãi tràn ngập Atlanta.",
		"Tara — ngôi nhà cha mẹ Scarlett — đứng vững sau trận chiến, nhưng hoang tàn và đói nghèo.",
		"Mẹ Scarlett đã chết. Cha cô không còn tỉnh táo vì đau buồn.",
		"Scarlett nhìn xuống mảnh đất đỏ, nắm chặt tay. Cơn đói cào cấu ruột gan.",
		"Tôi sẽ không bao giờ đói nữa, cô thề. Dù phải ăn trộm hay nói dối.",
		"Rhett yêu Scarlett say đắm dù biết cô chỉ dùng mình để có tiền và địa vị.",
		"Anh nhẫn nhịn năm này qua năm khác, chờ đợi cô nhận ra sự thật về tình yêu.",
		"Nhưng Scarlett mãi mê đuổi theo bóng Ashley — người đàn ông không bao giờ thuộc về cô.",
		"Rhett tặng Scarlett những bộ váy đẹp nhất Atlanta, nhưng trái tim cô không rung động.",
		"Bonnie Blue — đứa con gái nhỏ yêu dấu của họ — chết trong một tai nạn phi ngựa.",
		"Rhett khóc lặng lẽ bên thi thể con gái. Scarlett lần đầu thấy anh tan vỡ.",
		"Melanie qua đời vì sinh nở khó. Ashley mất đi chỗ dựa tinh thần duy nhất.",
		"Đau buồn chồng chất đau buồn. Atlanta cháy lần nữa trong ký ức Scarlett.",
		"Frankly my dear, I don't give a damn — Rhett nói và quay đi trong bóng đêm.",
		"Scarlett đứng một mình trong căn nhà trống. Lần đầu cô thấy thực sự cô đơn.",
		"Nhưng Tara vẫn còn đó. Đất đỏ vẫn còn đó. Và ngày mai sẽ là một ngày mới.",
		"Dù sao, ngày mai cũng là một ngày khác — Scarlett tự nhủ và ngẩng cao đầu.",
	}
}
