package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestDNFlusher(t *testing.T) {
	// Setup giống integration test
	ws := gene.NewWorldScene()
	ws.Clock.HourOfDay = 12.0

	nodes   := ws.SpatialNodes()
	router  := gene.NewISLRouter(nodes, 8.0)
	addrMap := NewAddrAgentMap()
	bus     := NewMessageBus()

	// VisionChief
	vc := NewVisionChief("vc_dn", 256)
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun),   vc.ID)

	// LeoAI mock channel
	leoInbox := make(chan *isl.ISLMessage, 64)
	bus.Register("leoai", leoInbox, 2, RoleChief)

	disp := NewSpatialDispatcher(router, addrMap, bus)
	pl   := NewPerceptLayer(ws, disp)
	pl.AddSensor(SensorPoint{
		Pos: gene.Vec3{X: 0, Y: 7, Z: 0}, // bên trong Earth
		Radius: 5.0, NSamples: 8,
	})

	// DNFlusher với threshold thấp để test
	flusher := NewDNFlusher(vc, bus, "leoai")
	flusher.FlushThreshold = 5 // chỉ cần 5 observations

	t.Log("=== DNFlusher: ĐN pattern → KnowledgeProposal ===")

	// Start VisionChief
	stop := make(chan struct{})
	go vc.Run(stop)
	defer close(stop)

	// Chạy đủ ticks để vượt threshold
	for i := 0; i < 4; i++ {
		pl.Tick(0.1)
	}
	time.Sleep(30 * time.Millisecond) // đợi VisionChief process

	// Kiểm tra trước flush
	dom, cnt := vc.Dominant()
	t.Logf("Before flush: dominant=%016x count=%d threshold=%d",
		dom, cnt, flusher.FlushThreshold)

	// CheckAndFlush lần 1 — chưa đủ threshold? check
	p1 := flusher.CheckAndFlush()
	if cnt >= flusher.FlushThreshold {
		if p1 == nil {
			t.Error("phải flush khi cnt >= threshold")
		} else {
			t.Logf("Flush 1: %s", p1.Summary)
			t.Logf("  Addr=%016x Evidence=%d InsideRatio=%.2f",
				p1.Addr, p1.Evidence, p1.InsideRatio)
			if p1.Addr != uint64(gene.ISL_Earth) {
				t.Errorf("expect ISL_Earth, got %016x", p1.Addr)
			}
			if p1.Evidence < flusher.FlushThreshold {
				t.Errorf("evidence %d < threshold %d", p1.Evidence, flusher.FlushThreshold)
			}
			// InsideRatio phải cao (sensor bên trong Earth)
			if p1.InsideRatio < 0.3 {
				t.Errorf("InsideRatio %.2f quá thấp cho sensor bên trong Earth", p1.InsideRatio)
			}
		}
	} else {
		t.Logf("cnt=%d < threshold=%d, chạy thêm ticks", cnt, flusher.FlushThreshold)
		for i := 0; i < 4; i++ { pl.Tick(0.1) }
		time.Sleep(30 * time.Millisecond)
		p1 = flusher.CheckAndFlush()
		if p1 == nil { t.Error("sau 8 ticks vẫn không flush được") }
	}

	// Kiểm tra LeoAI nhận được MsgKnowledge
	select {
	case msg := <-leoInbox:
		t.Logf("LeoAI nhận: type=%02x addr=%02x%02x%02x%02x conf=%d flags=%02x",
			msg.MsgType,
			msg.PrimaryAddr.Layer, msg.PrimaryAddr.Group,
			msg.PrimaryAddr.Type, msg.PrimaryAddr.ID,
			msg.Confidence, msg.Flags)
		if msg.MsgType != isl.MsgKnowledge {
			t.Errorf("MsgType phải MsgKnowledge (%02x), got %02x",
				isl.MsgKnowledge, msg.MsgType)
		}
		if msg.Confidence == 0 { t.Error("confidence phải > 0") }
	case <-time.After(50 * time.Millisecond):
		if p1 != nil { t.Error("LeoAI không nhận được message dù flush thành công") }
	}

	// Flush lần 2 ngay liền — phải bị throttle (cùng addr, count chưa tăng đủ)
	p2 := flusher.CheckAndFlush()
	if p2 != nil {
		t.Logf("Flush 2 (ngay sau): evidence=%d (có thể OK nếu count tăng)", p2.Evidence)
	} else {
		t.Log("Flush 2 throttled ✓ (tránh spam LeoAI)")
	}

	// Thêm nhiều observations → flush lại được
	for i := 0; i < 10; i++ { pl.Tick(0.1) }
	time.Sleep(30 * time.Millisecond)
	p3 := flusher.CheckAndFlush()
	if p3 != nil {
		t.Logf("Flush 3 sau thêm 10 ticks: evidence=%d ✓", p3.Evidence)
	}

	// Stats
	flushes, proposals := flusher.Stats()
	t.Logf("\nDNFlusher stats: %d flushes, %d proposals", flushes, len(proposals))

	t.Log("\n✓ ĐN pattern → KnowledgeProposal → LeoAI(MsgKnowledge)")
	t.Logf("  Pipeline: SDF → ISLAddr → VC.mem → DNFlusher → Bus → LeoAI")
}
