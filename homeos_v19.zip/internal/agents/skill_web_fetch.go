// WebFetchSkill — fetch URL, trả về content
// Anchor: SYS_NETWORK (📡 U+1F4E1)
package agents

import (
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type WebFetchResult struct {
	URL        string
	StatusCode int
	Body       string // truncated to maxBytes
	ContentType string
	FetchedAt  time.Time
	Error      string
}

type WebFetchSkill struct {
	client   *http.Client
	maxBytes int
}

func NewWebFetchSkill() *WebFetchSkill {
	return &WebFetchSkill{
		client:   &http.Client{Timeout: 10 * time.Second},
		maxBytes: 64 * 1024, // 64KB max
	}
}

func (s *WebFetchSkill) Name() string { return "web_fetch" }

func (s *WebFetchSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg.MsgType != isl.MsgQuery {
		return false
	}
	body := string(PayloadBody(msg))
	return strings.HasPrefix(body, "http://") || strings.HasPrefix(body, "https://")
}

func (s *WebFetchSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	url := strings.TrimSpace(string(PayloadBody(msg)))
	if url == "" {
		url = strings.TrimSpace(string(msg.Payload))
	}

	result := s.fetch(url)

	ctx.State["web.last_url"]    = result.URL
	ctx.State["web.last_status"] = result.StatusCode
	ctx.State["web.last_body"]   = result.Body
	ctx.State["web.last_error"]  = result.Error

	var replyMsg *isl.ISLMessage
	if result.Error == "" {
		replyMsg = &isl.ISLMessage{
			MsgType: isl.MsgResponse,
			Payload: []byte(result.Body),
		}
	}

	return SkillResult{
		Data: map[string]interface{}{
			"web.url":    result.URL,
			"web.status": result.StatusCode,
			"web.bytes":  len(result.Body),
			"web.error":  result.Error,
		},
		Message: replyMsg,
	}
}

func (s *WebFetchSkill) fetch(url string) WebFetchResult {
	r := WebFetchResult{URL: url, FetchedAt: time.Now()}

	resp, err := s.client.Get(url)
	if err != nil {
		r.Error = err.Error()
		return r
	}
	defer resp.Body.Close()

	r.StatusCode  = resp.StatusCode
	r.ContentType = resp.Header.Get("Content-Type")

	limited := io.LimitReader(resp.Body, int64(s.maxBytes))
	data, err := io.ReadAll(limited)
	if err != nil {
		r.Error = fmt.Sprintf("read error: %v", err)
		return r
	}
	r.Body = string(data)
	return r
}
