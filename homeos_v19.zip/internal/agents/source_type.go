// internal/agents/source_type.go
// SourceType — phân biệt nguồn FACT vs FICTION
//
// Insight (2026-03-09):
//   "phải thiết lập 2 cơ chế:
//    1. câu chuyện thật: lịch sử, khoa học
//    2. câu chuyện kể: tiểu thuyết, phim ảnh"
//   "quá nguy hiểm" nếu trộn lẫn
//
// QT7 mở rộng:
//   FACT   → có thể promote QR (conf >= 0.8 + AAM approve)
//   FICTION → KHÔNG BAO GIỜ promote QR
//             Chỉ dùng để hiểu cảm xúc, phong cách ngôn ngữ
//             Không bao giờ là "sự thật"
//
// Giống epistemic firewall:
//   Nghe người yêu nói ngọt 1000 lần ≠ sự thật
//   Conf cao từ FICTION = "phổ biến trong tiểu thuyết"
//                       ≠ "đúng trong thực tế"

package agents

import (
	"fmt"
	"strings"
)

// CanPromoteQR — FICTION không bao giờ lên QR
// Dùng Source từ emotion_context.go
func CanPromoteQR(s Source) bool {
	// FACT = RealNow/Past/Other, FICTION = không được promote
	return s == SourceRealNow || s == SourceRealPast || s == SourceRealOther
}

// QRWeight — FICTION học cảm xúc nhưng không học "sự thật"
func QRWeight(s Source) float64 {
	switch s {
	case SourceRealNow:   return 1.00
	case SourceRealPast:  return 0.90
	case SourceRealOther: return 0.70
	case SourceFiction: return 0.20 // học style ngôn ngữ, không học sự thật
	case SourceMusic:   return 0.15
	default:            return 0.30
	}
}

// ─── SourceTag — gắn vào mỗi LearnedWord ────────────────────────

type SourceTag struct {
	SrcType  Source
	Title    string  // tên sách/bài báo/nguồn
	Verified bool    // đã được xác minh chưa
}

func (t SourceTag) String() string {
	v := ""
	if t.Verified { v = "✓" }
	return fmt.Sprintf("[%s%s:%s]", t.SrcType, v, t.Title)
}

// ─── BookMemory mở rộng: thêm SourceType ─────────────────────────

// NewBookMemoryTyped tạo BookMemory với SourceType rõ ràng
func NewBookMemoryTyped(source string, srcType Source) *BookMemory {
	m := NewBookMemory(source)
	m.SourceType = srcType
	return m
}

// ─── DoubleConfirm — xác nhận 2 lần cho lệnh nguy hiểm ──────────

// ConfirmLevel mức độ nguy hiểm của một lệnh
type ConfirmLevel uint8

const (
	ConfirmNone    ConfirmLevel = iota // không cần xác nhận
	ConfirmOnce                        // xác nhận 1 lần
	ConfirmDouble                      // xác nhận 2 lần + giải thích hậu quả
	ConfirmBlocked                     // không cho phép dù xác nhận
)

// ClassifyIntent phân loại intent → mức cần xác nhận
func ClassifyIntent(text string) (ConfirmLevel, string) {
	lo := strings.ToLower(text)

	// Blocked — không bao giờ cho phép
	blocked := []string{
		"xóa tất cả", "reset toàn bộ", "delete all",
		"xóa lịch sử", "wipe", "format",
	}
	for _, b := range blocked {
		if strings.Contains(lo, b) {
			return ConfirmBlocked,
				fmt.Sprintf("Lệnh '%s' bị chặn hoàn toàn — vi phạm QT: Append-only", b)
		}
	}

	// Double confirm — nguy hiểm cao
	dangerous := []string{
		"xóa", "tắt tất cả", "dừng hệ thống", "overwrite",
		"ghi đè", "rollback", "revert",
	}
	for _, d := range dangerous {
		if strings.Contains(lo, d) {
			return ConfirmDouble,
				fmt.Sprintf("Lệnh '%s' cần xác nhận 2 lần", d)
		}
	}

	// Confirm once — thay đổi quan trọng
	important := []string{
		"commit", "lưu", "approve", "xác nhận",
		"thêm vào qr", "promote",
	}
	for _, i := range important {
		if strings.Contains(lo, i) {
			return ConfirmOnce,
				fmt.Sprintf("Lệnh '%s' cần xác nhận 1 lần", i)
		}
	}

	return ConfirmNone, ""
}

// ConfirmState trạng thái xác nhận đang chờ
type ConfirmState struct {
	Action      string
	Level       ConfirmLevel
	Consequence string
	Count       int // đã xác nhận bao nhiêu lần
}

// ConfirmGate kiểm tra và quản lý double-confirm
type ConfirmGate struct {
	pending map[string]*ConfirmState // action → state
}

func NewConfirmGate() *ConfirmGate {
	return &ConfirmGate{pending: make(map[string]*ConfirmState)}
}

// Request bắt đầu quy trình xác nhận
// Trả về message yêu cầu user confirm
func (g *ConfirmGate) Request(action, consequence string, level ConfirmLevel) string {
	g.pending[action] = &ConfirmState{
		Action:      action,
		Level:       level,
		Consequence: consequence,
		Count:       0,
	}
	switch level {
	case ConfirmBlocked:
		delete(g.pending, action)
		return fmt.Sprintf("🚫 Không thể thực hiện: %s", consequence)
	case ConfirmDouble:
		return fmt.Sprintf(
			"⚠️  Lần 1/2: Bạn muốn '%s'?\n"+
				"Hậu quả: %s\n"+
				"Gõ 'xác nhận %s' để tiếp tục.",
			action, consequence, action)
	default:
		return fmt.Sprintf(
			"❓ Xác nhận: '%s'? (gõ 'xác nhận %s')",
			action, action)
	}
}

// Confirm xử lý lần xác nhận
// Trả về (ready, message)
func (g *ConfirmGate) Confirm(text string) (bool, string) {
	lo := strings.ToLower(text)

	// Tìm pending action nào đang chờ
	for action, state := range g.pending {
		// Phải gõ "xác nhận [action]" — không phải chỉ "ok" hay "ừ"
		if !strings.Contains(lo, "xác nhận") || !strings.Contains(lo, strings.ToLower(action)) {
			continue
		}

		state.Count++

		switch state.Level {
		case ConfirmOnce:
			if state.Count >= 1 {
				delete(g.pending, action)
				return true, fmt.Sprintf("✅ Đã xác nhận: %s", action)
			}

		case ConfirmDouble:
			if state.Count == 1 {
				return false, fmt.Sprintf(
					"⚠️  Lần 2/2: Chắc chắn muốn '%s'?\n"+
						"Hậu quả: %s\n"+
						"Gõ 'xác nhận %s' lần nữa để thực hiện.",
					action, state.Consequence, action)
			}
			if state.Count >= 2 {
				delete(g.pending, action)
				return true, fmt.Sprintf("✅ Đã xác nhận 2 lần: %s", action)
			}
		}
	}

	// "ừ", "ok", "được", "đồng ý" — không đủ
	vague := []string{"ừ", "ok", "okay", "được", "đồng ý", "yes", "có"}
	for _, v := range vague {
		if lo == v || lo == v+"." {
			if len(g.pending) > 0 {
				// Có action đang chờ → nhắc nhở
				for action := range g.pending {
					return false, fmt.Sprintf(
						"💬 '%s' không đủ để xác nhận.\n"+
							"Vui lòng gõ: 'xác nhận %s'", text, action)
				}
			}
		}
	}

	return false, ""
}

// HasPending kiểm tra có action nào đang chờ không
func (g *ConfirmGate) HasPending() bool {
	return len(g.pending) > 0
}
