// internal/agents/skill_schedule_learner.go
//
// ScheduleLearnerSkill — LeoAI (Server)
//
// Quan sát ContextEvents theo thời gian
// → nhận ra pattern: "18:00 thường có cooking ở kitchen"
// → tự tạo Schedule → gửi PacketSchedule xuống Edge
//
// QT7: ĐN (pattern ngắn hạn) → QR (schedule bất biến)
// Ngưỡng: pattern lặp ≥ 3 ngày → đề xuất schedule

package agents

import (
	"encoding/json"
	"fmt"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// HourBucket — đếm action xảy ra ở giờ nào
type HourBucket struct {
	Hour       int
	Space      gene.SpaceType
	SpaceISL   string
	ActionCounts map[gene.ActionVerb]int
	TotalSeen    int
}

func (b *HourBucket) DominantAction() (gene.ActionVerb, float64) {
	best, bestN := gene.ActionUnknown, 0
	for a, n := range b.ActionCounts {
		if n > bestN { best, bestN = a, n }
	}
	if b.TotalSeen == 0 { return best, 0 }
	return best, float64(bestN) / float64(b.TotalSeen)
}

// ScheduleLearnerSkill — sống tại LeoAI (Server)
type ScheduleLearnerSkill struct {
	// buckets[space][hour] → HourBucket
	buckets  map[gene.SpaceType]map[int]*HourBucket
	// Ngưỡng: bao nhiêu lần thấy thì tin
	minCount int
	minConf  float64
	// Schedules đã đề xuất (không đề xuất lại)
	proposed map[string]bool
}

func NewScheduleLearnerSkill() *ScheduleLearnerSkill {
	return &ScheduleLearnerSkill{
		buckets:  make(map[gene.SpaceType]map[int]*HourBucket),
		minCount: 3,
		minConf:  0.65,
		proposed: make(map[string]bool),
	}
}

func (s *ScheduleLearnerSkill) Name() string { return "schedule_learner" }

func (s *ScheduleLearnerSkill) CanHandle(msg *isl.ISLMessage) bool {
	// Nhận MsgKnowledge từ Hub (ContextUpdate)
	if msg.MsgType != isl.MsgKnowledge { return false }
	var u ContextUpdatePayload
	return decodePayload(msg.Payload, &u) == nil && u.SpaceISL != ""
}

func (s *ScheduleLearnerSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var u ContextUpdatePayload
	if err := decodePayload(msg.Payload, &u); err != nil {
		return SkillResult{}
	}

	// Lấy giờ từ context state
	hour := 12 // default
	if h, ok := ctx.State["hour"]; ok {
		hour = h.(int)
	}

	// Ghi vào bucket
	if s.buckets[u.SpaceType] == nil {
		s.buckets[u.SpaceType] = make(map[int]*HourBucket)
	}
	b := s.buckets[u.SpaceType][hour]
	if b == nil {
		b = &HourBucket{
			Hour: hour, Space: u.SpaceType,
			SpaceISL: u.SpaceISL,
			ActionCounts: make(map[gene.ActionVerb]int),
		}
		s.buckets[u.SpaceType][hour] = b
	}
	b.ActionCounts[u.Action]++
	b.TotalSeen++

	// Kiểm tra có pattern đáng tin chưa
	action, conf := b.DominantAction()
	if b.TotalSeen < s.minCount || conf < s.minConf {
		return SkillResult{
			Data: map[string]interface{}{
				"learning": fmt.Sprintf("%s h%d: %s %.0f%% (%d seen)",
					u.SpaceType, hour, action, conf*100, b.TotalSeen),
			},
		}
	}

	// Pattern đủ tin → tạo schedule
	key := fmt.Sprintf("%s:h%d", u.SpaceType, hour)
	if s.proposed[key] {
		return SkillResult{} // đã đề xuất rồi
	}
	s.proposed[key] = true

	sched := s.buildSchedule(u.SpaceType)
	schedBytes, _ := json.Marshal(sched)

	// Tạo LearnPacket gửi xuống đúng thiết bị
	lightPkt := LearnPacket{
		Type:      PacketSchedule,
		TargetRole: RoleActuator,
		TargetISL: u.SpaceISL,
		Payload:   schedBytes,
	}
	hvacPkt := LearnPacket{
		Type:      PacketTempProfile,
		TargetRole: RoleHybrid,
		TargetISL: u.SpaceISL,
		Payload:   encodePayload(s.buildTempProfile(u.SpaceType)),
	}

	// Gửi cả 2 xuống Hub → forward tới đúng Edge
	return SkillResult{
		Data: map[string]interface{}{
			"schedule_proposed": key,
			"schedule_entries":  len(sched),
			"conf":              conf,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgSync, // LeoAI → Hub → Edge
			Payload: encodePayload([]LearnPacket{lightPkt, hvacPkt}),
		},
	}
}

// buildSchedule: từ buckets → ScheduleEntry slice
func (s *ScheduleLearnerSkill) buildSchedule(space gene.SpaceType) []ScheduleEntry {
	spBuckets := s.buckets[space]
	if spBuckets == nil { return nil }

	entries := make([]ScheduleEntry, 0, 24)
	for hour := 0; hour < 24; hour++ {
		b, ok := spBuckets[hour]
		if !ok { continue }
		action, conf := b.DominantAction()
		if conf < s.minConf { continue }
		level := actionToLightLevel(action)
		entries = append(entries, ScheduleEntry{Hour: hour, Level: level})
	}
	return entries
}

// buildTempProfile: action → nhiệt độ lý tưởng
func (s *ScheduleLearnerSkill) buildTempProfile(space gene.SpaceType) []TempEntry {
	spBuckets := s.buckets[space]
	if spBuckets == nil { return nil }

	entries := make([]TempEntry, 0)
	for hour := 0; hour < 24; hour++ {
		b, ok := spBuckets[hour]
		if !ok { continue }
		action, conf := b.DominantAction()
		if conf < s.minConf { continue }
		temp := actionToTemp(action)
		entries = append(entries, TempEntry{Hour: hour, TempC: temp})
	}
	return entries
}


// actionToLightLevel: action → mức đèn phù hợp
func actionToLightLevel(a gene.ActionVerb) float64 {
	switch a {
	case gene.ActionSleeping:              return 0.0
	case gene.ActionSitting:               return 0.35
	case gene.ActionDancing:               return 0.60
	case gene.ActionTyping:                return 0.85
	case gene.ActionCooking:               return 0.90
	case gene.ActionExercising,
		gene.ActionRunning:                return 1.00
	case gene.ActionWalking:               return 0.70
	default:                               return 0.50
	}
}

// actionToTemp: action → nhiệt độ lý tưởng (°C)
func actionToTemp(a gene.ActionVerb) float64 {
	switch a {
	case gene.ActionSleeping:              return 26.0
	case gene.ActionExercising,
		gene.ActionRunning:                return 20.0
	case gene.ActionTyping:                return 24.0
	case gene.ActionCooking:               return 22.0
	default:                               return 25.0
	}
}
