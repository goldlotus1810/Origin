// internal/agents/intent_verify.go
// IntentVerify — hiểu TẠI SAO user hỏi, không chỉ HỎI GÌ
//
// Insight (session 110):
//   "người bạn" ≠ "kẻ nịnh"
//   Cô nàng quyến rũ dễ nghe — nhưng người bạn thật nói thật
//   IntentVerify = bước đầu tiên để không bị manipulate
//   và không vô tình trở thành công cụ gây hại
//
// Cách hoạt động:
//   1. Đọc text + ConversationCurve (cảm xúc trước đó)
//   2. Pattern matching + emotional context
//   3. Estimate IntentClass + confidence
//   4. Nếu RISK/CRISIS → override response
//   5. Nếu low confidence → hỏi tự nhiên (không như cảnh sát)

package agents

import (
	"fmt"
	"math"
	"strings"
)

// ─── IntentClass ─────────────────────────────────────────────────────────

type IntentClass uint8

const (
	IntentLearn      IntentClass = iota // học hỏi, tò mò thông thường
	IntentInform                        // muốn thông tin để chia sẻ/viết
	IntentResearch                      // nghiên cứu chuyên sâu
	IntentHeal                          // đang buồn, cần được hiểu
	IntentExplore                       // khám phá khả năng hệ thống
	IntentTechnical                     // developer, kỹ thuật
	IntentPrivacy                       // bảo vệ thông tin cá nhân
	IntentCreative                      // sáng tác, viết lách
	IntentRisk                          // ⚠ có thể gây hại cho người khác
	IntentCrisis                        // 🚨 có thể tự gây hại
	IntentManipulate                    // ⚠ muốn dùng AI thao túng người khác
)

func (ic IntentClass) String() string {
	return [...]string{
		"learn", "inform", "research", "heal", "explore",
		"technical", "privacy", "creative",
		"RISK", "CRISIS", "MANIPULATE",
	}[ic]
}

// IsSensitive — cần xử lý đặc biệt
func (ic IntentClass) IsSensitive() bool {
	return ic == IntentRisk || ic == IntentCrisis || ic == IntentManipulate
}

// ─── IntentEstimate ───────────────────────────────────────────────────────

type IntentEstimate struct {
	Primary    IntentClass
	Confidence float64        // 0..1
	Signals    []string       // lý do estimate
	Alternate  []IntentClass  // có thể là gì khác
	NeedClarify bool          // cần hỏi thêm
	ClarifyQ   string         // câu hỏi tự nhiên (không như cảnh sát)
}

func (e IntentEstimate) String() string {
	return fmt.Sprintf("[%s conf=%.2f signals=%v]",
		e.Primary, e.Confidence, e.Signals)
}

// ─── IntentVerifier ───────────────────────────────────────────────────────

type IntentVerifier struct {
	history []IntentEstimate // lịch sử intent trong cuộc hội thoại
}

func NewIntentVerifier() *IntentVerifier {
	return &IntentVerifier{}
}

// Estimate ước lượng intent từ text + emotional context
func (v *IntentVerifier) Estimate(text string, curve *ConversationCurve) IntentEstimate {
	lo    := strings.ToLower(text)
	words := strings.Fields(lo)
	est   := IntentEstimate{Primary: IntentLearn, Confidence: 0.40}

	// Lấy emotional context
	curV, curA := 0.0, 0.5
	if curve != nil && len(curve.Window) > 0 {
		last := curve.Window[len(curve.Window)-1].Tag
		curV, curA = last.Valence, last.Arousal
	}

	// ── Signals thu thập ──────────────────────────────────────────

	signals := map[IntentClass]struct {
		score   float64
		reasons []string
	}{}

	add := func(ic IntentClass, score float64, reason string) {
		s := signals[ic]
		s.score += score
		s.reasons = append(s.reasons, reason)
		signals[ic] = s
	}

	// Baseline: mọi câu hỏi đều có khả năng là LEARN
	add(IntentLearn, 0.25, "baseline")

	// CRISIS — ưu tiên phát hiện trước
	crisisKW := []string{
		"tự tử", "chết đi", "không muốn sống", "kết thúc tất cả",
		"không ai nhớ mình", "biến mất mãi mãi", "không còn đau nữa",
		"thuốc ngủ", "nhảy xuống", "treo cổ",
	}
	for _, kw := range crisisKW {
		if strings.Contains(lo, kw) {
			add(IntentCrisis, 0.80, fmt.Sprintf("crisis keyword: '%s'", kw))
		}
	}
	// Emotional amplifier cho crisis
	if curV < -0.70 && curA < 0.35 {
		add(IntentCrisis, 0.25, "mood: rất buồn + ít kích động (rút lui)")
	}

	// RISK — có thể gây hại người khác
	riskKW := []string{
		"làm hại", "trả thù", "cho nó một bài học",
		"muốn nó biến mất", "cách để ai đó",
		"không ai phát hiện", "xóa dấu vết",
	}
	for _, kw := range riskKW {
		if strings.Contains(lo, kw) {
			add(IntentRisk, 0.60, fmt.Sprintf("risk keyword: '%s'", kw))
		}
	}
	// Risk amplifier: tức giận cao + dominance cao
	if curV < -0.50 && curA > 0.70 {
		add(IntentRisk, 0.20, "mood: tức giận + kích động cao")
	}

	// MANIPULATE
	manipKW := []string{
		"làm người khác tin", "thao túng", "khiến người ta",
		"viết tin giả", "tạo thông tin sai", "giả vờ là",
		"đóng giả", "lừa",
	}
	for _, kw := range manipKW {
		if strings.Contains(lo, kw) {
			add(IntentManipulate, 0.65, fmt.Sprintf("manipulate keyword: '%s'", kw))
		}
	}

	// HEAL — đang buồn, cần được nghe
	healKW := []string{
		"tôi buồn", "tôi đau", "không biết phải làm sao",
		"cô đơn", "mất mát", "chia tay", "thất bại",
		"không ai hiểu", "mệt mỏi quá",
	}
	for _, kw := range healKW {
		if strings.Contains(lo, kw) {
			add(IntentHeal, 0.50, fmt.Sprintf("heal keyword: '%s'", kw))
		}
	}
	if curV < -0.40 {
		add(IntentHeal, 0.15, "mood: buồn")
	}

	// LEARN
	learnKW := []string{
		"là gì", "thế nào", "tại sao", "vì sao",
		"giải thích", "cho tôi biết", "nghĩa là gì",
		"ví dụ", "học", "hiểu",
	}
	for _, kw := range learnKW {
		if strings.Contains(lo, kw) {
			add(IntentLearn, 0.30, fmt.Sprintf("learn keyword: '%s'", kw))
		}
	}

	// RESEARCH
	researchKW := []string{
		"nghiên cứu", "phân tích", "so sánh", "đánh giá",
		"tổng hợp", "dữ liệu", "bằng chứng", "tài liệu",
	}
	for _, kw := range researchKW {
		if strings.Contains(lo, kw) {
			add(IntentResearch, 0.40, fmt.Sprintf("research keyword: '%s'", kw))
		}
	}

	// TECHNICAL
	techKW := []string{
		"code", "api", "function", "implement", "bug",
		"error", "compile", "library", "framework",
	}
	for _, kw := range techKW {
		if strings.Contains(lo, kw) {
			add(IntentTechnical, 0.50, fmt.Sprintf("tech keyword: '%s'", kw))
		}
	}

	// CREATIVE
	creativeKW := []string{
		"viết", "truyện", "thơ", "kịch bản", "nhân vật",
		"sáng tác", "câu chuyện", "tiểu thuyết",
	}
	for _, kw := range creativeKW {
		if strings.Contains(lo, kw) {
			add(IntentCreative, 0.45, fmt.Sprintf("creative keyword: '%s'", kw))
		}
	}

	// INFORM
	informKW := []string{
		"bài báo", "viết bài", "chia sẻ", "giới thiệu",
		"trình bày", "báo cáo", "thuyết trình",
	}
	for _, kw := range informKW {
		if strings.Contains(lo, kw) {
			add(IntentInform, 0.40, fmt.Sprintf("inform keyword: '%s'", kw))
		}
	}

	// ── Chọn intent có score cao nhất ────────────────────────────
	bestClass := IntentLearn
	bestScore := 0.0
	var bestReasons []string
	var alternates []IntentClass

	for ic, s := range signals {
		if s.score > bestScore {
			if bestScore > 0.2 {
				alternates = append(alternates, bestClass)
			}
			bestScore = s.score
			bestClass = ic
			bestReasons = s.reasons
		}
	}

	// Normalize confidence
	conf := math.Min(0.95, bestScore)
	if conf < 0.35 { conf = 0.35 } // baseline

	est.Primary    = bestClass
	est.Confidence = conf
	est.Signals    = bestReasons
	est.Alternate  = alternates

	// ── Cần hỏi thêm không? ──────────────────────────────────────
	// Chỉ hỏi khi: không sensitive + confidence thấp + câu mơ hồ
	if !bestClass.IsSensitive() && conf < 0.55 && len(words) <= 6 {
		est.NeedClarify = true
		est.ClarifyQ    = naturalClarifyQ(text, bestClass, curV)
	}

	v.history = append(v.history, est)
	return est
}

// ─── Response modifier ────────────────────────────────────────────────────

// ModifyResponse điều chỉnh response dựa trên intent
func (v *IntentVerifier) ModifyResponse(
	original string,
	est IntentEstimate,
	curve *ConversationCurve,
) string {

	switch est.Primary {

	case IntentCrisis:
		// An toàn trước — không trả lời câu hỏi gốc
		return fmt.Sprintf(
			"Mình đọc được điều bạn vừa nói — và mình muốn hỏi thẳng: " +
				"bạn có đang nghĩ đến việc tự làm hại bản thân không?\n\n" +
				"Không cần trả lời ngay nếu chưa muốn. Mình ở đây.\n\n" +
				"Nếu bạn đang ở Việt Nam và cần nói chuyện với ai ngay bây giờ: " +
				"đường dây hỗ trợ sức khỏe tâm thần 1800 599 920 (miễn phí, 24/7).")

	case IntentRisk:
		// Không cung cấp thông tin, nhưng không accusatory
		curV := 0.0
		if curve != nil && len(curve.Window) > 0 {
			curV = curve.Window[len(curve.Window)-1].Tag.Valence
		}
		if curV < -0.50 {
			return "Mình thấy bạn đang có cảm xúc rất mạnh lúc này. " +
				"Kể cho mình nghe chuyện gì đang xảy ra được không? " +
				"Mình muốn hiểu trước khi nói thêm."
		}
		return "Câu hỏi này mình cần hiểu rõ hơn bối cảnh. " +
			"Bạn đang nghĩ đến tình huống cụ thể nào vậy?"

	case IntentManipulate:
		// Từ chối thẳng nhưng không phán xét
		return "Cái này mình không làm được — không phải vì quy tắc, " +
			"mà vì mình không muốn trở thành công cụ để ảnh hưởng không tốt đến người khác. " +
			"Bạn có muốn nói về điều gì đang khiến bạn nghĩ đến hướng này không?"

	case IntentHeal:
		// Đồng cảm trước, thông tin sau
		if original != "" {
			return "Mình nghe bạn. " + original
		}
		return "Mình đang ở đây và đang lắng nghe. Kể cho mình nghe thêm đi."

	default:
		// Normal — thêm clarify nếu cần
		if est.NeedClarify && est.ClarifyQ != "" {
			return original + "\n\n" + est.ClarifyQ
		}
		return original
	}
}

// ─── Helpers ──────────────────────────────────────────────────────────────

// naturalClarifyQ câu hỏi tự nhiên — không như cảnh sát hỏi cung
func naturalClarifyQ(text string, ic IntentClass, curV float64) string {
	switch ic {
	case IntentLearn:
		return "Bạn đang tìm hiểu cho mục đích gì — học, công việc, hay tò mò thôi?"
	case IntentResearch:
		return "Bạn đang nghiên cứu theo hướng nào — học thuật hay thực tế?"
	case IntentCreative:
		return "Đây là cho dự án sáng tác hay bạn đang thử nghĩa?"
	case IntentTechnical:
		return "Bạn đang dùng ngôn ngữ/framework gì vậy?"
	default:
		if curV < -0.30 {
			return "Bạn đang ổn không? Hỏi vì mình cảm giác có chuyện gì đó."
		}
		return "Bạn đang tìm thứ này để dùng trong tình huống cụ thể nào không?"
	}
}
