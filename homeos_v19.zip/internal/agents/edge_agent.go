// internal/agents/edge_agent.go
//
// Edge Agent — sống tại thiết bị, 1 skill, nhẹ nhất có thể
//
// Nguyên tắc:
//   Chỉ load skill cần thiết cho thiết bị đó
//   Dữ liệu học tập: Server gửi xuống đúng loại
//   Không nhận dữ liệu không liên quan
//
// RAM footprint:
//   SensorAgent  (camera)  ≈ 8MB  — MotionLibrary + recognizer
//   LightAgent   (đèn)     ≈ 64KB — chỉ nhận lệnh
//   HVACAgent    (điều hòa)≈ 128KB — lệnh + schedule
//   AudioAgent   (mic)     ≈ 2MB  — AudioLibrary

package agents

import "github.com/goldlotus1810/HomeOS/internal/gene"

// ── DeviceProfile — mô tả thiết bị Edge ──────────────────────

type DeviceProfile struct {
	ID         string
	Role       DeviceRole
	Location   gene.SpaceType
	LocationISL string

	// Hardware
	RAMMB    int    // RAM có sẵn (MB)
	HasCamera bool
	HasMic    bool

	// Dữ liệu học tập nào được nhận
	AcceptsMotionUpdate bool // nhận MotionLibrary updates từ LeoAI
	AcceptsAudioUpdate  bool // nhận AudioLibrary updates
	AcceptsSchedule     bool // nhận lịch (giờ nào bật/tắt)
}

// Các profile chuẩn
var (
	ProfileCamera = DeviceProfile{
		Role: RoleSensor, RAMMB: 512,
		HasCamera: true, HasMic: false,
		AcceptsMotionUpdate: true,  // ← nhận motion patterns mới
		AcceptsAudioUpdate:  false, // ← không cần
		AcceptsSchedule:     false,
	}
	ProfileMic = DeviceProfile{
		Role: RoleSensor, RAMMB: 64,
		HasCamera: false, HasMic: true,
		AcceptsMotionUpdate: false,
		AcceptsAudioUpdate:  true,  // ← nhận audio patterns mới
		AcceptsSchedule:     false,
	}
	ProfileLight = DeviceProfile{
		Role: RoleActuator, RAMMB: 0, // tính bằng KB
		AcceptsMotionUpdate: false,
		AcceptsAudioUpdate:  false,
		AcceptsSchedule:     true,  // ← nhận lịch bật/tắt
	}
	ProfileHVAC = DeviceProfile{
		Role: RoleHybrid, RAMMB: 1,
		AcceptsMotionUpdate: false,
		AcceptsAudioUpdate:  false,
		AcceptsSchedule:     true,  // ← nhận nhiệt độ theo giờ
	}
)

// ── LearnPacket — gói dữ liệu LeoAI gửi xuống Edge ──────────
// Chỉ gửi đúng loại mà thiết bị đó cần

type LearnPacketType string

const (
	PacketMotionSignature LearnPacketType = "motion_sig" // → camera
	PacketAudioSignature  LearnPacketType = "audio_sig"  // → mic
	PacketSchedule        LearnPacketType = "schedule"   // → light/hvac
	PacketTempProfile     LearnPacketType = "temp_prof"  // → hvac
)

type LearnPacket struct {
	Type       LearnPacketType
	TargetRole DeviceRole     // chỉ gửi cho role này
	TargetISL  string         // "" = gửi cho tất cả cùng role
	Payload    []byte         // JSON encoded
}

// ShouldAccept: thiết bị có nhận packet này không?
func (p DeviceProfile) ShouldAccept(pkt *LearnPacket) bool {
	if pkt.TargetRole != p.Role && pkt.TargetRole != "" {
		return false
	}
	if pkt.TargetISL != "" && pkt.TargetISL != p.LocationISL {
		return false
	}
	switch pkt.Type {
	case PacketMotionSignature:
		return p.AcceptsMotionUpdate
	case PacketAudioSignature:
		return p.AcceptsAudioUpdate
	case PacketSchedule, PacketTempProfile:
		return p.AcceptsSchedule
	}
	return false
}
