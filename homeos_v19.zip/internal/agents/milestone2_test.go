package agents

import (
	"encoding/json"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestMilestone2(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  MILESTONE 2 — LeoAI học lịch sử → schedule tự động        ║")
	t.Log("║  QT7: ĐN (pattern lặp 3+ ngày) → QR (schedule bất biến)   ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	learner := NewScheduleLearnerSkill()
	dreamer := NewScheduleDreamSkill(learner)
	light   := NewActuatorLightSkill("light_kitchen", gene.SpaceKitchen)

	learnerCtx := &ExecContext{State: make(map[string]interface{})}
	dreamCtx   := &ExecContext{State: make(map[string]interface{})}
	lightCtx   := &ExecContext{State: make(map[string]interface{})}

	type obs struct {
		hour   int
		space  gene.SpaceType
		action gene.ActionVerb
	}

	// Pattern 1 tuần: nấu ăn 7h + 18h, làm việc 9h, ngủ 22h
	week := []obs{
		{7,  gene.SpaceKitchen,    gene.ActionCooking},
		{9,  gene.SpaceOffice,     gene.ActionTyping},
		{18, gene.SpaceKitchen,    gene.ActionCooking},
		{20, gene.SpaceLivingRoom, gene.ActionSitting},
		{22, gene.SpaceBedroom,    gene.ActionSleeping},
	}

	t.Log("[ 7 NGÀY QUAN SÁT ]")
	proposed := 0

	for day := 1; day <= 7; day++ {
		for _, o := range week {
			hour := o.hour
			// Ngày 3: nấu ăn sáng lùi 1h (noise)
			if day == 3 && o.hour == 7 { hour = 8 }

			msg := &isl.ISLMessage{
				MsgType: isl.MsgKnowledge,
				Payload: encodePayload(ContextUpdatePayload{
					SpaceISL:  o.space.ISLAddr(),
					SpaceType: o.space,
					Action:    o.action, ActionConf: 0.90,
					Species: "human_adult_female",
				}),
			}
			learnerCtx.State["hour"] = hour
			r := learner.Execute(learnerCtx, msg)

			if r.Message != nil {
				proposed++
				t.Logf("  ★ ngày %d h%02d %-10s → pattern đủ tin, đề xuất schedule",
					day, hour, o.action)
			}
		}
	}

	t.Logf("\n  Tổng: %d observations, %d schedules đề xuất", 7*len(week), proposed)

	// ── Dream ────────────────────────────────────────────────
	t.Log()
	t.Log("[ DREAMING ]")
	dr := dreamer.Execute(dreamCtx, &isl.ISLMessage{MsgType: isl.MsgDream})

	t.Logf("  patterns=%d  PROMOTE=%d  CONFLICT=%d  UNCERTAIN=%d",
		dr.Data["insights"], dr.Data["promotes"],
		dr.Data["conflicts"], dr.Data["uncertain"])

	if ins, ok := dreamCtx.State["dream_insights"]; ok {
		for _, i := range ins.([]DreamInsight) {
			if i.Verdict == "PROMOTE" {
				t.Logf("  ✓ PROMOTE %-12s h%02d %-12s %.0f%% (%dx)",
					i.Space, i.Hour, i.Action, i.Confidence*100, i.SeenCount)
			}
		}
	}

	// ── Gửi schedule xuống LightAgent ────────────────────────
	t.Log()
	t.Log("[ SCHEDULE → LightAgent kitchen ]")

	sched := learner.buildSchedule(gene.SpaceKitchen)
	t.Logf("  %d entries:", len(sched))
	for _, e := range sched {
		t.Logf("    h%02d → %.0f%%", e.Hour, e.Level*100)
	}

	if len(sched) > 0 {
		raw, _ := json.Marshal(sched)
		pkt := LearnPacket{
			Type: PacketSchedule, TargetRole: RoleActuator,
			TargetISL: "HAa1", Payload: raw,
		}
		syncMsg := &isl.ISLMessage{
			MsgType: isl.MsgSync,
			Payload: encodePayload(pkt),
		}
		r := light.Execute(lightCtx, syncMsg)
		t.Logf("  LightAgent: %d entries loaded", r.Data["schedule_entries"])
		t.Logf("  h07=%.0f%% h18=%.0f%% h22=%.0f%%",
			light.scheduleLevel(7)*100,
			light.scheduleLevel(18)*100,
			light.scheduleLevel(22)*100)
		t.Log("  ✓ offline mode sẵn sàng")
	}

	t.Log()
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("  MILESTONE 2 PASS")

	if dr.Data["promotes"].(int) == 0 {
		t.Error("✗ Không có PROMOTE nào")
	}
}
