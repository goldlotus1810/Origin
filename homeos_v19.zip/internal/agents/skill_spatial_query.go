// internal/agents/skill_spatial_query.go
// SpatialQuerySkill — LeoAI trả lời "tôi biết gì về ISLAddr X?"
//
// Nhận MsgQuery với PrimaryAddr → tra cứu:
//   1. LongTerm(QR): đã chứng minh → trả về OlangNode.DNA
//   2. ShortTerm(ĐN): đang học → trả về Observation.Label + confidence
//   3. Không có → trả về MsgResponse rỗng
//
// Đây là "bộ nhớ không gian" của LeoAI:
//   agent khác hỏi "vị trí này là gì?" → LeoAI tra QR/ĐN → trả lời

package agents

import (
	"fmt"
	"sync/atomic"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
)

// SpatialQueryResult kết quả tra cứu
type SpatialQueryResult struct {
	Addr       isl.Address
	FoundInQR  bool
	FoundInDN  bool
	DNA        string   // từ QR node
	Label      string   // từ DN observation
	Confidence float64  // 0.0-1.0
	Weight     int      // QR weight (số lần confirm)
	FireCount  int      // DN fire count
}

// SpatialQuerySkill tra cứu ISLAddr trong QR + ĐN
type SpatialQuerySkill struct {
	dn *memory.ShortTerm
	qr *memory.LongTerm

	hits   atomic.Int64
	misses atomic.Int64
}

func NewSpatialQuerySkill(dn *memory.ShortTerm, qr *memory.LongTerm) *SpatialQuerySkill {
	return &SpatialQuerySkill{dn: dn, qr: qr}
}

func (s *SpatialQuerySkill) Name() string { return "query.spatial" }

func (s *SpatialQuerySkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgQuery
}

func (s *SpatialQuerySkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	addr := msg.PrimaryAddr
	res  := SpatialQueryResult{Addr: addr}

	// 1. Tra QR trước — đã chứng minh
	if node, ok := s.qr.Query(addr); ok {
		res.FoundInQR  = true
		res.DNA        = node.DNA
		res.Label      = node.Name
		res.Weight     = node.Weight
		res.Confidence = 1.0
		s.hits.Add(1)
		return SkillResult{Data: map[string]interface{}{
			"source":     "QR",
			"addr":       fmtAddr(addr),
			"label":      res.Label,
			"dna":        res.DNA,
			"weight":     res.Weight,
			"confidence": 1.0,
		}}
	}

	// 2. Tra ĐN — đang học
	obs := s.dn.GetByISL(addr)
	if len(obs) > 0 {
		best := obs[0]
		for _, o := range obs[1:] {
			if o.Confidence > best.Confidence { best = o }
		}
		res.FoundInDN  = true
		res.Label      = best.Label
		res.Confidence = best.Confidence
		res.FireCount  = best.FireCount
		s.hits.Add(1)
		return SkillResult{Data: map[string]interface{}{
			"source":     "DN",
			"addr":       fmtAddr(addr),
			"label":      res.Label,
			"confidence": res.Confidence,
			"fire_count": res.FireCount,
			"note":       "ĐN — chưa chứng minh",
		}}
	}

	// 3. Không biết
	s.misses.Add(1)
	return SkillResult{Data: map[string]interface{}{
		"source": "none",
		"addr":   fmtAddr(addr),
		"note":   "không có trong QR hoặc ĐN",
	}}
}

// Query trực tiếp — dùng cho test hoặc non-message flow
func (s *SpatialQuerySkill) Query(addr isl.Address) SpatialQueryResult {
	msg := &isl.ISLMessage{
		MsgType:     isl.MsgQuery,
		PrimaryAddr: addr,
	}
	result := s.Execute(nil, msg)
	res := SpatialQueryResult{Addr: addr}
	data := result.Data
	res.FoundInQR = data["source"] == "QR"
	res.FoundInDN = data["source"] == "DN"
	if v, ok := data["label"].(string); ok { res.Label = v }
	if v, ok := data["dna"].(string);   ok { res.DNA   = v }
	if v, ok := data["confidence"].(float64); ok { res.Confidence = v }
	if v, ok := data["weight"].(int);    ok { res.Weight    = v }
	if v, ok := data["fire_count"].(int); ok { res.FireCount = v }
	return res
}

func (s *SpatialQuerySkill) Stats() (hits, misses int) {
	return int(s.hits.Load()), int(s.misses.Load())
}

func fmtAddr(a isl.Address) string {
	return fmt.Sprintf("%02x%02x%02x%02x", a.Layer, a.Group, a.Type, a.ID)
}
