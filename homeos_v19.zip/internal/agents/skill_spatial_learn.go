// internal/agents/skill_spatial_learn.go
// SpatialLearnSkill — LeoAI nhận MsgKnowledge từ DNFlusher
//                     → ShortTerm.Observe → LongTerm.Commit (QR)
//
// QT7 pipeline:
//   DNFlusher → MsgKnowledge(ISLAddr, confidence, flags)
//   → SpatialLearnSkill.Execute
//   → ShortTerm.Observe(Observation) → (promote) → LongTerm.Commit

package agents

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"sync/atomic"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
)

// SpatialLearnSkill — Skill cho LeoAI nhận spatial knowledge
type SpatialLearnSkill struct {
	dn *memory.ShortTerm
	qr *memory.LongTerm

	received  atomic.Int64
	committed atomic.Int64
}

func NewSpatialLearnSkill(dn *memory.ShortTerm, qr *memory.LongTerm) *SpatialLearnSkill {
	return &SpatialLearnSkill{dn: dn, qr: qr}
}

func (s *SpatialLearnSkill) Name() string { return "learn.spatial" }

func (s *SpatialLearnSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgKnowledge && msg.Confidence > 0
}

// CommitThreshold: số lần reinforce trước khi commit lên QR
const spatialCommitThreshold = 3

func (s *SpatialLearnSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	s.received.Add(1)
	addr := msg.PrimaryAddr

	inside := msg.Flags&0x01 != 0
	insideStr := "0"
	if inside { insideStr = "1" }
	dnaStr := fmt.Sprintf("spatial:inside=%s:conf=%d:layer=%02x:%02x%02x%02x",
		insideStr, msg.Confidence,
		addr.Layer, addr.Group, addr.Type, addr.ID)
	dnaBytes := []byte(dnaStr)

	h := sha256.Sum256(dnaBytes)
	nh := isl.NodeHash(binary.BigEndian.Uint64(h[:8]))

	obs := memory.Observation{
		NodeHash:   nh,
		ISL:        addr,
		Data:       dnaBytes,
		Label:      dnaStr,
		Confidence: float64(msg.Confidence) / 100.0,
	}

	addrStr := fmt.Sprintf("%02x%02x%02x%02x",
		addr.Layer, addr.Group, addr.Type, addr.ID)

	result := s.dn.Observe(obs, s.qr)

	switch result {
	case memory.ResultDiscarded:
		// Đã trong QR rồi
		s.committed.Add(1)
		return SkillResult{Data: map[string]interface{}{"action": "qr_exists", "addr": addrStr}}

	case memory.ResultReinforced:
		// FireCount tăng sau mỗi reinforce
		// Khi đủ threshold → commit thẳng lên QR
		allObs := s.dn.All()
		for _, o := range allObs {
			if o.NodeHash == nh && o.FireCount >= spatialCommitThreshold {
				// Confirm trước để Commit hợp lệ
				s.dn.Confirm(nh)
				// Lấy lại sau Confirm
				for _, o2 := range s.dn.All() {
					if o2.NodeHash == nh {
						if err := s.qr.Commit(o2); err == nil {
							s.committed.Add(1)
							s.dn.MarkArchived(nh)
						}
						break
					}
				}
				break
			}
		}
		return SkillResult{Data: map[string]interface{}{"action": "reinforced", "addr": addrStr}}

	default: // ResultCreated
		return SkillResult{Data: map[string]interface{}{"action": "created_DN", "addr": addrStr}}
	}
}

func (s *SpatialLearnSkill) Stats() (received, committed int) {
	return int(s.received.Load()), int(s.committed.Load())
}
