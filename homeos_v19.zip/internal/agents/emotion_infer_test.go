package agents

import "testing"

func TestInferContext(t *testing.T) {
	t.Log("=== InferContext — suy luận EmotionContext từ text ===\n")

	cases := []struct {
		text    string
		wantRole   Role
		wantSource Source
	}{
		{"tôi vừa mất việc hôm nay",             RoleFirstPerson,  SourceRealNow},
		{"hồi nhỏ tôi đã từng sợ bóng tối lắm", RoleFirstPerson,  SourceRealPast},
		{"tôi nhớ lại ngày đó rất rõ",           RoleFirstPerson,  SourceMemory},
		{"bạn tôi kể rằng cô ấy rất buồn",       RoleThirdPerson,  SourceRealOther},
		{"trong phim đó nhân vật chính rất đau",  RoleObserver,     SourceFiction},
		{"bài nhạc này làm mình buồn ghê",        RoleObserver,     SourceMusic},
		{"bạn đang trải qua chuyện khó khăn",     RoleSecondPerson, SourceRealOther},
		// shared
		{"chúng mình cùng nhau vượt qua",         RoleFirstPerson,  SourceRealNow},
	}

	frames := makeSadFrames()
	sp := ProsodySpline{Frames: frames, Duration: float64(len(frames)) * 0.01}

	t.Log("Text                                    Role          Source        S      Label")
	t.Log("────────────────────────────────────────────────────────────────────────────────")
	for _, c := range cases {
		ctx := InferContext(c.text)
		ce  := SolveEmotion(sp, ctx)
		ok  := "✓"
		if ctx.Role != c.wantRole || ctx.Source != c.wantSource { ok = "⚠" }
		t.Logf("%-40s %-13s %-13s %.2f   %-12s %s",
			truncate(c.text, 38),
			ctx.Role.String(), ctx.Source.String(),
			ctx.S(), ce.Final.Label(), ok)
	}

	t.Log("\n─── Cùng text buồn, ngữ cảnh khác → S khác ───")
	texts := []string{
		"tôi vừa trải qua chuyện đó",
		"hồi xưa tôi đã từng như vậy",
		"bạn tôi kể chuyện đó cho tôi nghe",
		"trong phim có cảnh rất xúc động",
		"bài nhạc này hay quá",
	}
	for _, tx := range texts {
		ctx := InferContext(tx)
		ce  := SolveEmotion(sp, ctx)
		t.Logf("  %-34s S=%.2f → I=%.2f [%s]",
			truncate(tx,32), ctx.S(), ce.Final.Intensity, ce.Final.Label())
	}
	t.Log("\n✓ Cùng Spline, text khác → Context khác → EmotionTag khác")
}

func makeSadFrames() []ProsodyFrame {
	frames := make([]ProsodyFrame, 20)
	for i := range frames {
		frames[i] = ProsodyFrame{T: float64(i)*0.01, Pitch: 200-float64(i)*6, Energy: 0.18, Rate: 2.5}
	}
	return frames
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n { return s }
	return string(r[:n-1]) + "…"
}
