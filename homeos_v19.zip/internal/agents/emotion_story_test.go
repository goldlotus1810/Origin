package agents

import (
	"fmt"
	"math"
	"strings"
	"testing"
)

// analyzeText — phân tích một đoạn văn → EmotionTag
// Đây là heuristic đơn giản (thực tế dùng ProsodySkill với audio)
// Ở đây ta dùng keyword matching để test pipeline
func analyzeText(text string) EmotionTag {
	lo := strings.ToLower(text)

	// Weight cao hơn để còn lại sau Fiction scale (S=0.07)
	// Raw cần đủ mạnh để: raw * S > threshold
	negWords := []string{
		"kinh dị", "sợ", "chết", "máu", "bóng tối", "tiếng bước",
		"run rẩy", "la hét", "biến mất", "cửa", "lạnh", "nhìn chằm",
		"tự mở", "rùng mình", "hét", "chạy", "ám ảnh", "bí ẩn",
		"horror", "fear", "dead", "blood", "scream", "dark", "cold",
		"tiếng động", "lạ", "không ai", "cô đơn", "đêm", "tối",
	}
	posWords := []string{
		"an toàn", "ánh sáng", "bình yên", "thoát", "may mắn",
		"safe", "light", "rescue", "relief", "dawn",
	}

	var valence float64
	for _, w := range negWords {
		if strings.Contains(lo, w) { valence -= 0.22 }
	}
	for _, w := range posWords {
		if strings.Contains(lo, w) { valence += 0.18 }
	}
	valence = math.Max(-0.98, math.Min(0.98, valence))

	// Arousal
	highArousal := []string{
		"la hét", "chạy", "tim đập", "run rẩy", "hoảng", "đột ngột",
		"bỗng", "hét", "loạn xạ", "screamed", "running", "suddenly",
	}
	arousal := 0.40
	for _, w := range highArousal {
		if strings.Contains(lo, w) { arousal += 0.15 }
	}
	arousal = math.Min(0.98, arousal)

	intensity := math.Sqrt(valence*valence+(arousal-0.5)*(arousal-0.5)) / math.Sqrt(1.5)

	return EmotionTag{
		Valence:   valence,
		Arousal:   arousal,
		Dominance: 0.5 - math.Abs(valence)*0.3,
		Intensity: intensity,
	}
}

func TestHorrorStoryAnalysis(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════╗")
	t.Log("║  TEST: Phân tích câu chuyện kinh dị                      ║")
	t.Log("╚══════════════════════════════════════════════════════════╝")
	t.Log()

	// Câu chuyện kinh dị — 10 đoạn
	story := []struct{ para, summary string }{
		{
			`Căn nhà cũ nằm cuối con đường vắng, không có ai ở từ mười năm nay.
			 Lan dọn vào một mình, vì giá thuê quá rẻ so với thành phố.
			 Buổi tối đầu tiên, mọi thứ có vẻ yên tĩnh.`,
			"Giới thiệu — căn nhà cũ, Lan dọn vào",
		},
		{
			`Đêm đầu tiên, Lan nghe thấy tiếng bước chân trên tầng hai.
			 Nhẹ, đều đặn, như ai đó đang đi đi lại lại.
			 Cô tự nhủ chắc là tiếng chuột.`,
			"Tiếng bước chân — cô tự trấn an",
		},
		{
			`Đêm thứ ba, cửa phòng ngủ tự mở ra lúc 3 giờ sáng.
			 Lan run rẩy, nằm im không dám thở mạnh.
			 Bóng tối ngoài hành lang đặc quánh, không nhìn thấy gì.`,
			"Cửa tự mở — run rẩy, sợ hãi cực độ",
		},
		{
			`Sáng hôm sau, Lan thấy dấu bàn tay trên tấm gương phòng tắm.
			 Không phải của cô. Ngón tay dài hơn, lạnh hơn.
			 Máu lạnh chạy dọc sống lưng.`,
			"Dấu tay lạ trên gương — máu lạnh",
		},
		{
			`Lan gọi cho người bạn, kể mọi chuyện.
			 Bạn cô cười: 'Chắc mày tự làm đó'.
			 Nhưng Lan biết — cô không bao giờ chạm vào gương đó.`,
			"Gọi bạn — không ai tin",
		},
		{
			`Đêm thứ năm, Lan thấy bóng người đứng góc phòng.
			 Nhìn chằm chằm về phía cô. Không di chuyển.
			 Lan la hét, bật hết đèn, chạy ra ngoài đường.`,
			"Thấy bóng người — la hét, chạy thoát",
		},
		{
			`Ngoài đường lạnh và tối. Lan run không ngừng.
			 Cô đứng dưới ánh đèn đường, không dám quay lại.
			 Tim đập loạn xạ.`,
			"Ngoài đường — run, hoảng loạn cực độ",
		},
		{
			`Người hàng xóm già bước ra, hỏi sao lại đứng đây.
			 Lan kể. Ông im lặng một lúc rồi nói:
			 'Mười năm trước, người ở đó cũng chết trong phòng đó.'`,
			"Hàng xóm tiết lộ — người đã chết ở đó",
		},
		{
			`Lan không quay lại căn nhà đó nữa.
			 Cô để lại tất cả đồ đạc.
			 Chỉ mang theo chiếc điện thoại và bộ quần áo trên người.`,
			"Bỏ trốn — không lấy gì cả",
		},
		{
			`Nhưng đêm đó, trong khách sạn mới thuê,
			 Lan nghe thấy tiếng bước chân quen thuộc —
			 đều đặn, nhẹ, từ phía cửa phòng.`,
			"Kết — nó đi theo cô",
		},
	}

	// Context: Observer + Fiction (đọc truyện)
	ctx := FictionContext

	flushed := []ConversationPoint{}
	curve := NewConversationCurve(func(pt ConversationPoint) {
		flushed = append(flushed, pt)
	})
	history := &EmotionHistory{}

	t.Log("Đoạn  VAD                    Tone          Inflect  Tóm tắt")
	t.Log("──────────────────────────────────────────────────────────────────")

	for i, s := range story {
		rawTag := analyzeText(s.para)
		// Dùng ctx.Apply() đúng cách — giữ aesthetic floor
		scaled := ctx.Apply(rawTag)

		prevInfl := len(flushed)
		curve.Add(scaled, s.summary)
		history.Add(scaled, ctx, s.summary)
		tone := curve.NextTone()

		inflMark := ""
		if len(flushed) > prevInfl { inflMark = "← INFLECT" }

		t.Logf("[%2d] V=%+.2f A=%.2f I=%.2f  %-12s  %-10s  %s",
			i+1,
			scaled.Valence, scaled.Arousal, scaled.Intensity,
			tone.Style, inflMark,
			s.summary)
	}

	// ── Tổng kết đường cong ──────────────────────────────────────────
	t.Log()
	t.Log("══════════════════════════════════════════════")
	t.Log(curve.Summary())
	t.Log()
	t.Log("══════════════════════════════════════════════")
	t.Log(history.Profile())
	t.Log()
	t.Logf("Inflection → Silk: %d điểm", len(flushed))
	for _, pt := range flushed {
		t.Logf("  lượt %d: V=%+.2f [%s] — %s",
			pt.Turn, pt.Tag.Valence, pt.Tag.Label(), pt.Text)
	}
	t.Log()
	t.Log(curve.MemoryStats())

	// ── Nhận xét tự động ─────────────────────────────────────────────
	t.Log()
	t.Log("══════════════════════════════════════════════")
	t.Log("NHẬN XÉT CỦA HỆ THỐNG:")
	t.Log(generateReview(curve, history, flushed, ctx))
}

// generateReview — tự tạo nhận xét dựa trên đường cong
func generateReview(
	curve *ConversationCurve,
	history *EmotionHistory,
	inflects []ConversationPoint,
	ctx EmotionContext,
) string {
	avg   := history.AverageVAD()
	trend := history.RecentTrend()
	dom   := history.DominantEmotion()
	tone  := curve.NextTone()
	d1    := curve.D1()

	var b strings.Builder

	// Nhận xét ngữ cảnh
	b.WriteString(fmt.Sprintf("Ngữ cảnh: %s + %s (S=%.2f — cảm nhận nghệ thuật)\n\n",
		ctx.Role.String(), ctx.Source.String(), ctx.S()))

	// Nhận xét cảm xúc chủ đạo
	switch dom {
	case "tired", "neutral":
		b.WriteString("Câu chuyện gây cảm giác lo âu nhẹ — đúng với khoảng cách\n")
		b.WriteString("của người đọc truyện (không trực tiếp trải nghiệm).\n\n")
	case "anxious", "panic":
		b.WriteString("Câu chuyện tạo được căng thẳng đáng kể dù qua Fiction filter.\n\n")
	case "melancholy", "sad":
		b.WriteString("Câu chuyện mang cảm giác u ám, nặng nề hơn là kinh dị thuần túy.\n\n")
	}

	// Nhận xét về inflection points
	if len(inflects) > 0 {
		b.WriteString(fmt.Sprintf("Bước ngoặt cảm xúc (%d điểm):\n", len(inflects)))
		for _, pt := range inflects {
			b.WriteString(fmt.Sprintf("  → Lượt %d: \"%s\"\n", pt.Turn+1, pt.Text))
		}
		b.WriteString("\n")
	}

	// Nhận xét kết thúc
	if d1 < -0.1 {
		b.WriteString("Kết thúc: căng thẳng tăng dần → open ending hiệu quả.\n")
	} else if d1 > 0.1 {
		b.WriteString("Kết thúc: cảm xúc đi lên → có thể là false relief.\n")
	}

	// Nhận xét xu hướng
	switch trend {
	case "declining":
		b.WriteString("Xu hướng: cảm xúc giảm dần → câu chuyện xây dựng tension tốt.\n")
	case "improving":
		b.WriteString("Xu hướng: cảm xúc cải thiện ở nửa sau → có giải thoát.\n")
	case "stable":
		b.WriteString("Xu hướng: ổn định → tension đều, không có cao trào rõ.\n")
	}

	b.WriteString(fmt.Sprintf("\nAvg VAD: V=%+.2f A=%.2f I=%.2f\n", avg.Valence, avg.Arousal, avg.Intensity))
	b.WriteString(fmt.Sprintf("Tone cuối: %s (warmth=%.1f)\n", tone.Style, tone.Warmth))

	return b.String()
}
