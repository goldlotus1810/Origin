// skill_dream_dispatch.go
//
// DreamDispatchSkill — nhận MsgPropose từ ScheduleDreamSkill,
// đóng gói thành LearnPacket và broadcast xuống Edge Agents.
//
// Pipeline hoàn chỉnh:
//   ScheduleLearnerSkill (học pattern)
//       ↓ MsgDream (idle > 5min)
//   ScheduleDreamSkill (kiểm chứng → PROMOTE)
//       ↓ MsgPropose
//   DreamDispatchSkill (đóng gói LearnPacket)
//       ↓ MsgSync (broadcast qua registry)
//   ActuatorLightSkill / ActuatorHvacSkill (áp dụng)
//
// QT7: ĐN → QR (vòng đời tri thức)
// DreamDispatch = cầu nối từ QR (LeoAI) xuống Edge (Worker)

package agents

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type DreamDispatchSkill struct {
	registry  *AgentRegistry
	dispatched int
	lastAt     time.Time
}

func NewDreamDispatchSkill(registry *AgentRegistry) *DreamDispatchSkill {
	return &DreamDispatchSkill{registry: registry}
}

func (s *DreamDispatchSkill) Name() string { return "dream_dispatch" }

func (s *DreamDispatchSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgPropose
}

func (s *DreamDispatchSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Đọc insights từ ctx.State (ScheduleDreamSkill đã để đó)
	insights, ok := ctx.State["dream_insights"].([]DreamInsight)
	if !ok || len(insights) == 0 {
		return SkillResult{Data: map[string]interface{}{"dispatch.count": 0}}
	}

	promotes := 0
	var packets []LearnPacket

	for _, ins := range insights {
		if ins.Verdict != "PROMOTE" {
			continue
		}
		promotes++

		// Tạo LearnPacket cho light và hvac
		lightPkt := s.makeLightPacket(ins)
		hvacPkt  := s.makeHvacPacket(ins)

		packets = append(packets, lightPkt, hvacPkt)
	}

	if len(packets) == 0 {
		return SkillResult{Data: map[string]interface{}{
			"dispatch.count":   0,
			"dispatch.insights": len(insights),
		}}
	}

	// Broadcast xuống tất cả Edge agents qua registry
	sent := s.broadcast(packets)
	s.dispatched += sent
	s.lastAt = time.Now()

	log.Printf("🧠 DreamDispatch: %d promotes → %d packets → %d agents",
		promotes, len(packets), sent)

	ctx.State["dispatch.last_at"]   = s.lastAt
	ctx.State["dispatch.total"]     = s.dispatched

	return SkillResult{Data: map[string]interface{}{
		"dispatch.count":    sent,
		"dispatch.promotes": promotes,
		"dispatch.packets":  len(packets),
	}}
}

func (s *DreamDispatchSkill) makeLightPacket(ins DreamInsight) LearnPacket {
	brightness := lightBrightnessForAction(ins.Action)
	return LearnPacket{
		Type:       PacketSchedule,
		TargetRole: RoleActuator,
		Payload: encodePayload(map[string]interface{}{
			"device":     string(ins.Space) + "_light",
			"hour":       ins.Hour,
			"space":      string(ins.Space),
			"action":     string(ins.Action),
			"brightness": brightness,
			"confidence": ins.Confidence,
			"source":     "dream",
		}),
	}
}

func (s *DreamDispatchSkill) makeHvacPacket(ins DreamInsight) LearnPacket {
	temp := hvacTempForAction(ins.Action)
	return LearnPacket{
		Type:       PacketTempProfile,
		TargetRole: RoleActuator,
		Payload: encodePayload(map[string]interface{}{
			"device":     string(ins.Space) + "_hvac",
			"hour":       ins.Hour,
			"space":      string(ins.Space),
			"action":     string(ins.Action),
			"temp_c":     temp,
			"confidence": ins.Confidence,
			"source":     "dream",
		}),
	}
}

// broadcast gửi packets xuống Edge agents qua registry.Broadcast
func (s *DreamDispatchSkill) broadcast(packets []LearnPacket) int {
	if s.registry == nil {
		return 0
	}
	payload, err := json.Marshal(packets)
	if err != nil {
		log.Printf("DreamDispatch: marshal error: %v", err)
		return 0
	}
	msg := &isl.ISLMessage{
		MsgType: isl.MsgSync,
		Payload: payload,
	}
	// Broadcast tới light_, hvac_, lock_, sensor_, fan_ agents
	sent := 0
	for _, prefix := range []string{"light_", "hvac_", "lock_", "fan_"} {
		sent += s.registry.Broadcast(prefix, msg)
	}
	return sent
}

// lightBrightnessForAction — ánh sáng phù hợp với hoạt động
func lightBrightnessForAction(action gene.ActionVerb) int {
	switch action {
	case gene.ActionSleeping:   return 0
	case gene.ActionExercising: return 100
	case gene.ActionTyping:     return 90
	case gene.ActionCooking:    return 85
	case gene.ActionWalking:    return 70
	case gene.ActionSitting:    return 35
	default:                    return 60
	}
}

// hvacTempForAction — nhiệt độ phù hợp với hoạt động
func hvacTempForAction(action gene.ActionVerb) float64 {
	switch action {
	case gene.ActionSleeping:   return 22.0
	case gene.ActionExercising: return 20.0
	case gene.ActionTyping:     return 24.0
	case gene.ActionCooking:    return 23.0
	case gene.ActionWalking:    return 25.0
	default:                    return 25.0
	}
}

// isEdgeAgent — phân loại Worker agents
func isEdgeAgent(name string) bool {
	prefixes := []string{"light_", "hvac_", "lock_", "sensor_", "fan_"}
	for _, p := range prefixes {
		if len(name) > len(p) && name[:len(p)] == p {
			return true
		}
	}
	return false
}

// Stats — thống kê dispatch
func (s *DreamDispatchSkill) Stats() string {
	if s.lastAt.IsZero() {
		return "DreamDispatch: chưa dispatch lần nào"
	}
	return fmt.Sprintf("DreamDispatch: %d packets gửi, lần cuối %s",
		s.dispatched, s.lastAt.Format("15:04:05"))
}
