package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestDreamDispatchSkill(t *testing.T) {
	t.Log("═══════════════════════════════════════════")
	t.Log("DreamDispatchSkill — LeoAI → Edge pipeline")
	t.Log("═══════════════════════════════════════════")

	registry := NewAgentRegistry()

	// Tạo fake Edge agents (light + hvac)
	lightInbox := make(chan *isl.ISLMessage, 16)
	hvacInbox  := make(chan *isl.ISLMessage, 16)

	registry.Register("light_living", lightInbox)
	registry.Register("hvac_living",  hvacInbox)

	dispatch := NewDreamDispatchSkill(registry)

	// Simulate MsgPropose với insights đã có trong State
	insights := []DreamInsight{
		{
			Space:      gene.SpaceLivingRoom,
			Hour:       20,
			Action:     gene.ActionSitting,
			Confidence: 0.88,
			SeenCount:  7,
			Verdict:    "PROMOTE",
		},
		{
			Space:      gene.SpaceBedroom,
			Hour:       22,
			Action:     gene.ActionSleeping,
			Confidence: 0.92,
			SeenCount:  9,
			Verdict:    "PROMOTE",
		},
		{
			Space:      gene.SpaceKitchen,
			Hour:       8,
			Action:     gene.ActionCooking,
			Confidence: 0.40, // UNCERTAIN — không dispatch
			SeenCount:  3,
			Verdict:    "UNCERTAIN",
		},
	}

	ctx := &ExecContext{State: make(map[string]interface{})}
	ctx.State["dream_insights"] = insights
	ctx.State["dream_promotes"] = 2

	msg := &isl.ISLMessage{MsgType: isl.MsgPropose}
	result := dispatch.Execute(ctx, msg)

	t.Logf("\n  Insights: %d total, 2 PROMOTE, 1 UNCERTAIN", len(insights))
	t.Logf("  dispatch.count:    %v", result.Data["dispatch.count"])
	t.Logf("  dispatch.promotes: %v", result.Data["dispatch.promotes"])
	t.Logf("  dispatch.packets:  %v", result.Data["dispatch.packets"])

	// Kiểm tra light_ và hvac_ đã nhận MsgSync
	time.Sleep(10 * time.Millisecond)

	lightGot := len(lightInbox) > 0
	hvacGot  := len(hvacInbox) > 0
	t.Logf("\n  light_living inbox: %d msgs (got=%v)", len(lightInbox), lightGot)
	t.Logf("  hvac_living inbox:  %d msgs (got=%v)", len(hvacInbox), hvacGot)

	// Xác nhận brightness mapping
	cases := []struct {
		action gene.ActionVerb
		wantBr int
		wantT  float64
	}{
		{gene.ActionSleeping,   0,   22.0},
		{gene.ActionExercising, 100, 20.0},
		{gene.ActionTyping,     90,  24.0},
		{gene.ActionCooking,    85,  23.0},
		{gene.ActionSitting,    35,  25.0},
	}
	t.Log("\n  Action → brightness/temp mapping:")
	for _, c := range cases {
		br := lightBrightnessForAction(c.action)
		tp := hvacTempForAction(c.action)
		ok := br == c.wantBr && tp == c.wantT
		sym := "✓"
		if !ok { sym = "✗"; t.Errorf("action=%s: br=%d (want %d), temp=%.1f (want %.1f)",
			c.action, br, c.wantBr, tp, c.wantT) }
		t.Logf("    %s %-14s → light=%d%%  temp=%.1f°C", sym, c.action, br, tp)
	}

	// Stats
	t.Logf("\n  %s", dispatch.Stats())
	t.Log("\n✓ DreamDispatchSkill PASS — LeoAI → Edge pipeline hoàn chỉnh")
}
