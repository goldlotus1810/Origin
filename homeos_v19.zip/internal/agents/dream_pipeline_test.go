// internal/agents/dream_pipeline_test.go
//
// Test DreamSkill → MsgPropose → ProposalHandlerSkill → QR.Commit
// Vòng QT7: ĐN → Dream kiểm chứng → AAM approve → QR

package agents

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestDreamProposalPipeline(t *testing.T) {
	dn := memory.NewShortTerm(64)
	graph := silk.NewSilkGraph()
	ledger := silk.NewLedger("", nil)
	qr := memory.NewLongTerm(graph, ledger)

	// 2 high-confidence (>= 0.75) → Dream propose
	// 1 low-confidence (< 0.20)   → Dream evict
	dn.ForceInsert(memory.Observation{
		ISL: isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 1},
		Label: "quang hợp", Confidence: 0.85, NodeHash: isl.NodeHash(0x0001),
	})
	dn.ForceInsert(memory.Observation{
		ISL: isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 2},
		Label: "diệp lục", Confidence: 0.90, NodeHash: isl.NodeHash(0x0002),
	})
	dn.ForceInsert(memory.Observation{
		ISL: isl.Address{Layer: 3, Group: 'B', Type: 'b', ID: 3},
		Label: "noise", Confidence: 0.10, NodeHash: isl.NodeHash(0x0003),
	})

	if dn.Count() != 3 {
		t.Fatalf("expected 3 entries, got %d", dn.Count())
	}

	// DreamSkill chạy
	dreamSkill := NewDreamSkill(dn, qr, graph)
	result := dreamSkill.Execute(&ExecContext{}, &isl.ISLMessage{MsgType: isl.MsgDream})

	// Phải gửi MsgPropose với 2 NodeHashes
	if result.Message == nil {
		t.Fatal("DreamSkill phải gửi MsgPropose khi có high-confidence entries")
	}
	if result.Message.MsgType != isl.MsgPropose {
		t.Errorf("expected MsgPropose, got %v", result.Message.MsgType)
	}
	proposedCount := len(result.Message.Payload) / 8
	if proposedCount != 2 {
		t.Errorf("expected 2 proposals, got %d", proposedCount)
	}
	t.Logf("✅ Dream: proposed=%d evicted=%v checked=%v",
		result.Data["dream.proposed"], result.Data["dream.deleted"], result.Data["dream.checked"])

	// ProposalHandlerSkill commit vào QR
	handler := NewProposalHandlerSkill(dn, qr)
	handlerResult := handler.Execute(&ExecContext{}, result.Message)

	if handlerResult.Message == nil || handlerResult.Message.MsgType != isl.MsgApproved {
		t.Error("ProposalHandler phải trả về MsgApproved")
	}
	t.Logf("✅ ProposalHandler: MsgApproved")

	// low-confidence entry phải bị archive
	entry, ok := dn.GetByHash(isl.NodeHash(0x0003))
	if ok && entry != nil && entry.State != memory.StateArchived {
		t.Error("low-confidence entry phải bị archive sau Dream")
	}
	t.Logf("✅ low-confidence archived")
}

func TestDreamSkipFiction(t *testing.T) {
	dn := memory.NewShortTerm(64)
	graph := silk.NewSilkGraph()
	ledger := silk.NewLedger("", nil)
	qr := memory.NewLongTerm(graph, ledger)

	// Fiction confidence thấp → không bị evict
	dn.ForceInsert(memory.Observation{
		ISL:      isl.Address{Layer: 3, Group: 'C', Type: 'c', ID: 1},
		Label:    "dragon_story",
		Confidence: 0.05,
		SrcType:  uint8(SourceFiction),
		NodeHash: isl.NodeHash(0xFFF1),
	})

	NewDreamSkill(dn, qr, graph).Execute(&ExecContext{}, &isl.ISLMessage{MsgType: isl.MsgDream})

	entry, ok := dn.GetByHash(isl.NodeHash(0xFFF1))
	if ok && entry != nil && entry.State == memory.StateArchived {
		t.Error("Fiction entries không được archive dù confidence thấp")
	}
	t.Logf("✅ Fiction protected from eviction")
}

func TestDreamEmptyDN(t *testing.T) {
	dn := memory.NewShortTerm(64)
	graph := silk.NewSilkGraph()
	ledger := silk.NewLedger("", nil)
	qr := memory.NewLongTerm(graph, ledger)

	result := NewDreamSkill(dn, qr, graph).Execute(&ExecContext{}, &isl.ISLMessage{MsgType: isl.MsgDream})
	if result.Message != nil {
		t.Error("empty ĐN không được gửi MsgPropose")
	}
	t.Logf("✅ empty ĐN: no proposal")
}
