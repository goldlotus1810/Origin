package agents

import (
	"testing"
	"time"
)

func TestThreeTierLogging(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  3 TẦNG LOG                                                 ║")
	t.Log("║  Ephemeral(RAM) · Audit(Ledger) · Knowledge(Silk Tree QR)  ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	logger := NewLoggerSkill("firmware_agent_01", nil) // nil = test mode (không ký)

	// ── TẦNG 1: Ephemeral — debug, heartbeat, raw data ────────
	t.Log("[ TẦNG 1 ] EphemeralLog — RAM buffer, mất khi tắt")

	for i := 0; i < 5; i++ {
		logger.Debug("đang quét endpoint " + string(rune('A'+i)))
	}
	logger.EphemeralLog().Write("firmware_agent_01", LogInfo,  "firmware đọc xong")
	logger.EphemeralLog().Write("firmware_agent_01", LogWarn,  "MQTT không có auth")
	logger.EphemeralLog().Write("firmware_agent_01", LogError, "timeout kết nối lần 1")

	recent := logger.EphemeralLog().Recent(5)
	t.Logf("  Buffer: %d entries (capacity 1000, vòng tròn)", logger.EphemeralLog().Count())
	for _, e := range recent {
		t.Logf("  [%s] %s", e.Level, e.Message)
	}
	t.Log("  → Mất khi tắt máy. Không vào Silk Tree.")
	t.Log()

	// ── TẦNG 2: Audit — truy vết bất biến ────────────────────
	t.Log("[ TẦNG 2 ] AuditLog — ISL Ledger, append-only, ED25519")
	t.Log()

	sessionID := "session_abc123"

	// Các sự kiện quan trọng cần truy vết
	logger.Audit(AuditAgentCreated,   "firmware_agent_01", "ok",     "", "")
	logger.Audit(AuditFirmwareRead,   "192.168.1.105",     "ok",     sessionID, string(ScopeFirmwareRead))
	logger.Audit(AuditPermGranted,    "firmware:patch",    "ok",     sessionID, string(ScopeFirmwarePatch))
	logger.Audit(AuditFirmwarePatch,  "CVE-2023-38913",   "ok",     sessionID, string(ScopeFirmwarePatch))
	logger.Audit(AuditPermRevoked,    "firmware:patch",    "ok",     sessionID, "")
	logger.Audit(AuditPermDenied,     "system:exec",       "denied", sessionID, string(ScopeSystemExec))
	logger.Audit(AuditSecurityBlock,  "unknown_cmd",       "blocked","",        "")

	t.Logf("  Audit entries: %d", logger.AuditLog().Count())
	t.Log()

	// Truy vết: ai đã patch firmware?
	patches := logger.AuditLog().Query("firmware_agent_01", AuditFirmwarePatch)
	t.Log("  Truy vết: firmware patches bởi firmware_agent_01:")
	for _, e := range patches {
		t.Logf("    seq=%d %s action=%s subject=%s result=%s",
			e.Seq, e.Timestamp.Format("15:04:05"),
			e.Action, e.Subject, e.Result)
	}

	// Truy vết: bị từ chối quyền gì?
	denied := logger.AuditLog().Query("firmware_agent_01", AuditPermDenied)
	t.Log("  Truy vết: quyền bị từ chối:")
	for _, e := range denied {
		t.Logf("    seq=%d scope=%s → %s", e.Seq, e.Subject, e.Result)
	}

	t.Log("  → Không xóa được. Không sửa được. QT8: lịch sử bất biến.")
	t.Log()

	// ── TẦNG 3: Knowledge — tri thức đã chứng minh ───────────
	t.Log("[ TẦNG 3 ] KnowledgeLog → DreamSkill → Silk Tree QR")
	t.Log()

	// Quan sát nhiều lần → confidence tăng
	for day := 1; day <= 7; day++ {
		conf := 0.6 + float64(day)*0.05
		logger.Learn("device.capability", "Philips Hue tại HAb1 hỗ trợ on_off + brightness",
			[]string{"endpoint:PUT:/state/on_off", "endpoint:PUT:/state/brightness"}, conf)
		logger.Learn("behavior.pattern", "18h-19h phòng bếp luôn cần đèn 90%",
			[]string{"7 ngày quan sát"}, conf)
	}

	// Thêm 1 quan sát chỉ 1 lần — chưa đủ
	logger.Learn("firmware.info", "model Hue Bridge v2",
		[]string{"firmware:read"}, 0.95)

	ready := logger.KnowledgeLog().ReadyForQR(5, 0.80)
	notReady := logger.KnowledgeLog().ReadyForQR(1, 0.0)

	t.Logf("  Tổng observations: %d", len(notReady))
	t.Logf("  Đủ điều kiện vào QR (seen≥5, conf≥0.8): %d", len(ready))
	t.Log()

	for _, e := range ready {
		t.Logf("  ✓ READY: '%s'", e.Content)
		t.Logf("    seen=%d conf=%.2f evidence=%v",
			e.SeenCount, e.Conf, e.Evidence)
		t.Log("    → DreamSkill promote → AAM approve → Silk Tree QR (bất biến)")
	}

	notReadyEntries := logger.KnowledgeLog().ReadyForQR(1, 0.0)
	for _, e := range notReadyEntries {
		if e.SeenCount < 5 || e.Conf < 0.80 {
			t.Logf("  ✗ NOT READY: '%s' (seen=%d conf=%.2f)",
				e.Content, e.SeenCount, e.Conf)
			t.Log("    → Ở lại KnowledgeLog, chờ thêm bằng chứng")
		}
	}

	t.Log()
	t.Log("[ TỔNG KẾT — QUY TẮC LƯU LOG ]")
	t.Log()
	t.Log("  Câu hỏi: 'đèn đang bật'          → Ephemeral (debug)")
	t.Log("  Câu hỏi: 'ai tắt đèn lúc mấy giờ'→ Audit Ledger (truy vết)")
	t.Log("  Câu hỏi: 'thói quen dùng đèn'     → Knowledge QR (tri thức)")
	t.Log()
	t.Log("  log có semantic?   → Silk Tree QR  (phải qua Dream+approve)")
	t.Log("  log cần truy vết?  → ISL Ledger    (append-only, signed)")
	t.Log("  log chỉ debug?     → RAM buffer     (ephemeral, mất khi tắt)")
	t.Log()
	t.Log("  KHÔNG bao giờ: lưu tất cả vào Tree (QT2: ∞ không tồn tại)")
	t.Log("  KHÔNG bao giờ: xóa Ledger hoặc QR  (QT8: lịch sử bất biến)")

	t.Log()
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("  PASS")

	// Assertions
	if logger.AuditLog().Count() != 7 { t.Errorf("✗ audit count = %d", logger.AuditLog().Count()) }
	if len(ready) == 0 { t.Error("✗ không có knowledge nào ready") }
	if logger.EphemeralLog().Count() == 0 { t.Error("✗ ephemeral trống") }

	// Verify: thêm entry vào audit sau khi đã có entry cũ → seq tăng
	before := logger.AuditLog().Count()
	logger.Audit(AuditKnowledgeCommit, "behavior.pattern", "ok", "", "")
	after := logger.AuditLog().Count()
	if after != before+1 {
		t.Errorf("✗ audit append-only failed: %d → %d", before, after)
	}

	// Verify: EphemeralLog ring buffer — thêm 2000 entries, count vẫn = 1000
	for i := 0; i < 2000; i++ {
		logger.Debug("overflow test")
	}
	if logger.EphemeralLog().Count() != 1000 {
		t.Errorf("✗ ring buffer không đúng: %d", logger.EphemeralLog().Count())
	}
	t.Logf("  Ring buffer: 2000 writes → count=%d (capacity=1000) ✓",
		logger.EphemeralLog().Count())

	// TTL test: expired ephemeral không ảnh hưởng audit
	_ = time.Now()
}

func TestAuditLog_PersistToDisk(t *testing.T) {
	dir := t.TempDir()
	path := dir + "/homeos.audit.log"

	// Lần 1: tạo + write
	log1 := NewAuditLog(nil).WithPath(path)
	log1.Write("aam", AuditPermGranted, "light_living", "ok", "sess1", "home")
	log1.Write("aam", AuditSecurityBlock, "override_gate", "denied", "sess1", "")
	log1.Write("home_chief", AuditAgentCreated, "light_bed", "ok", "sess1", "home")
	if log1.Count() != 3 {
		t.Fatalf("want 3 entries, got %d", log1.Count())
	}
	log1.Close()

	// Lần 2: load lại — phải thấy đủ 3 entries (QT8: replay lịch sử)
	log2 := NewAuditLog(nil)
	if err := log2.LoadFromDisk(path); err != nil {
		t.Fatalf("LoadFromDisk: %v", err)
	}
	if log2.Count() != 3 {
		t.Errorf("after reload: want 3, got %d", log2.Count())
	}

	// Tiếp tục append — không mất gì
	log2.WithPath(path)
	log2.Write("leoai", AuditKnowledgeCommit, "math.topology", "ok", "sess2", "")
	log2.Close()

	// Lần 3: load lại phải có 4
	log3 := NewAuditLog(nil)
	log3.LoadFromDisk(path)
	if log3.Count() != 4 {
		t.Errorf("after 2nd reload: want 4, got %d", log3.Count())
	}
	t.Logf("✓ AuditLog persist: 3→append 1→reload=4, file=%s", path)

	// WithAuditPath trên LoggerSkill
	logger := NewLoggerSkill("test_agent", nil).WithAuditPath(path)
	before := logger.AuditLog().Count()
	logger.Audit(AuditSkillAdded, "HonestySkill", "ok", "", "")
	if logger.AuditLog().Count() != before+1 {
		t.Errorf("LoggerSkill.WithAuditPath append failed")
	}
	t.Logf("✓ LoggerSkill.WithAuditPath: loaded %d + appended 1", before)
}
