// internal/agents/emotion_query.go
// EmotionEdge + EmotionHistory — lưu và query lịch sử cảm xúc qua Silk edges
//
// Append-only: mỗi cảm xúc được ghi vào Silk edge như DNA.
// Query: tổng hợp lịch sử → profile cảm xúc của người dùng/agent.

package agents

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"time"
)

// EmotionEdge — một sự kiện cảm xúc, lưu trong Silk edge
type EmotionEdge struct {
	T       int64          // unix timestamp
	Tag     EmotionTag     // VAD-I
	Context EmotionContext // điều kiện biên
	Text    string         // đoạn text nguồn (tóm tắt)
}

// DNA — lưu vào Silk edge (append-only)
func (e EmotionEdge) DNA() string {
	return fmt.Sprintf("emo_edge:t=%d:v=%.2f:a=%.2f:d=%.2f:i=%.2f:label=%s:role=%s:src=%s",
		e.T,
		e.Tag.Valence, e.Tag.Arousal, e.Tag.Dominance, e.Tag.Intensity,
		e.Tag.Label(), e.Context.Role.String(), e.Context.Source.String())
}

// ─── EmotionHistory ──────────────────────────────────────────────────────

// EmotionHistory giữ chuỗi sự kiện cảm xúc theo thời gian
// Append-only — không xóa, không sửa (QT2 bất biến)
type EmotionHistory struct {
	Edges []EmotionEdge
}

// maxEmotionEdges — giới hạn để tránh unbounded growth (BUG3 FIX)
const maxEmotionEdges = 500

// Add ghi thêm một sự kiện cảm xúc mới
func (h *EmotionHistory) Add(tag EmotionTag, ctx EmotionContext, text string) {
	h.Edges = append(h.Edges, EmotionEdge{
		T: time.Now().Unix(), Tag: tag, Context: ctx,
		Text: truncateStr(text, 60),
	})
	// BUG3 FIX: prune khi vượt quá giới hạn (giữ 500 entry mới nhất)
	if len(h.Edges) > maxEmotionEdges {
		h.Edges = h.Edges[len(h.Edges)-maxEmotionEdges:]
	}
}

// ─── Query methods ────────────────────────────────────────────────────────

// DominantEmotion trả về cảm xúc xuất hiện nhiều nhất
func (h *EmotionHistory) DominantEmotion() string {
	if len(h.Edges) == 0 { return "unknown" }
	count := map[string]int{}
	for _, e := range h.Edges { count[e.Tag.Label()]++ }
	best, max := "neutral", 0
	for label, n := range count {
		if n > max { best, max = label, n }
	}
	return best
}

// AverageVAD trả về trung bình VAD-I của toàn lịch sử
func (h *EmotionHistory) AverageVAD() EmotionTag {
	if len(h.Edges) == 0 { return EmotionTag{} }
	var v, a, d, i float64
	for _, e := range h.Edges {
		v += e.Tag.Valence
		a += e.Tag.Arousal
		d += e.Tag.Dominance
		i += e.Tag.Intensity
	}
	n := float64(len(h.Edges))
	return EmotionTag{v/n, a/n, d/n, i/n}
}

// RecentTrend so sánh nửa đầu và nửa sau lịch sử
// Trả về: "improving" / "declining" / "stable"
func (h *EmotionHistory) RecentTrend() string {
	if len(h.Edges) < 4 { return "stable" }
	mid := len(h.Edges) / 2
	var v1, v2 float64
	for _, e := range h.Edges[:mid]  { v1 += e.Tag.Valence }
	for _, e := range h.Edges[mid:]  { v2 += e.Tag.Valence }
	v1 /= float64(mid)
	v2 /= float64(len(h.Edges) - mid)
	diff := v2 - v1
	if diff >  0.1 { return "improving" }
	if diff < -0.1 { return "declining" }
	return "stable"
}

// BySource tổng hợp cảm xúc theo từng loại Source
func (h *EmotionHistory) BySource() map[string]EmotionTag {
	buckets := map[string][]EmotionTag{}
	for _, e := range h.Edges {
		k := e.Context.Source.String()
		buckets[k] = append(buckets[k], e.Tag)
	}
	result := map[string]EmotionTag{}
	for src, tags := range buckets {
		var v, a, d, i float64
		for _, t := range tags { v+=t.Valence; a+=t.Arousal; d+=t.Dominance; i+=t.Intensity }
		n := float64(len(tags))
		result[src] = EmotionTag{v/n, a/n, d/n, i/n}
	}
	return result
}

// TopLabels trả về top N label theo tần suất
func (h *EmotionHistory) TopLabels(n int) []string {
	count := map[string]int{}
	for _, e := range h.Edges { count[e.Tag.Label()]++ }
	type kv struct{ k string; v int }
	var sorted []kv
	for k, v := range count { sorted = append(sorted, kv{k, v}) }
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].v > sorted[j].v })
	result := []string{}
	for i, kv := range sorted {
		if i >= n { break }
		result = append(result, fmt.Sprintf("%s×%d", kv.k, kv.v))
	}
	return result
}

// Profile trả về mô tả tổng quát về profile cảm xúc
func (h *EmotionHistory) Profile() string {
	if len(h.Edges) == 0 {
		return "Chưa có dữ liệu cảm xúc."
	}
	avg   := h.AverageVAD()
	dom   := h.DominantEmotion()
	trend := h.RecentTrend()
	top   := h.TopLabels(3)
	src   := h.BySource()

	// Tính emotional volatility = std(Valence)
	var variance float64
	for _, e := range h.Edges {
		d := e.Tag.Valence - avg.Valence
		variance += d * d
	}
	volatility := math.Sqrt(variance / float64(len(h.Edges)))
	volDesc := "ổn định"
	if volatility > 0.4 { volDesc = "dao động mạnh" } else if volatility > 0.2 { volDesc = "dao động vừa" }

	// Source summary
	srcLines := []string{}
	for src, tag := range src {
		srcLines = append(srcLines, fmt.Sprintf("    %-12s V=%+.2f I=%.2f [%s]",
			src, tag.Valence, tag.Intensity, tag.Label()))
	}
	sort.Strings(srcLines)

	return fmt.Sprintf(
		"Profile cảm xúc (%d sự kiện):\n"+
		"  Dominant:    %s\n"+
		"  Top labels:  %s\n"+
		"  Avg VAD:     V=%+.2f A=%.2f D=%.2f I=%.2f\n"+
		"  Volatility:  %.2f (%s)\n"+
		"  Trend:       %s\n"+
		"  Theo nguồn:\n%s",
		len(h.Edges), dom,
		strings.Join(top, " / "),
		avg.Valence, avg.Arousal, avg.Dominance, avg.Intensity,
		volatility, volDesc,
		trend,
		strings.Join(srcLines, "\n"),
	)
}

func truncateStr(s string, n int) string {
	r := []rune(s)
	if len(r) <= n { return s }
	return string(r[:n-1]) + "…"
}
