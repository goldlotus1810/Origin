package agents

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestPerceptLayerHot(t *testing.T) {
	t.Log("=== PerceptLayerHot: HotReloadRouter + AddrLabelIndex ===")

	ws      := gene.NewWorldScene()
	bus     := NewMessageBus()
	addrMap := NewAddrAgentMap()

	// Đăng ký VisionChief
	vc := NewVisionChief("vc_hot", 512)
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun),   vc.ID)

	// Tạo PerceptLayerHot (không có graph olang)
	pl := NewPerceptLayerHot(ws, addrMap, bus, nil)

	t.Logf("Initial: nodes=%d version=%d", pl.Router.Len(), pl.Router.Version())

	// Thêm sensor tại trung tâm Earth
	pl.AddSensor(SensorPoint{
		ID: "center", Pos: gene.Vec3{X: 0, Y: 5, Z: 0},
		Radius: 3.0, NSamples: 8,
	})

	// Tick 1: trước khi thêm creature
	r1 := pl.Tick(0.016)
	t.Logf("Tick 1: msgs=%d routerV=%d nodesAdded=%d",
		r1.TotalMsgs, r1.RouterVersion, r1.NodesAdded)

	// AddCreature — từ goroutine bên ngoài (giả lập)
	done := make(chan struct{})
	go func() {
		pl.AddCreature(gene.NewCreatureGene(gene.SpeciesHuman))
		close(done)
	}()
	<-done

	t.Logf("After AddCreature: nodes=%d version=%d",
		pl.Router.Len(), pl.Router.Version())
	if pl.Router.Len() <= 3 {
		t.Error("nodes phải tăng sau AddCreature")
	}

	// Tick 2: sau khi thêm creature
	r2 := pl.Tick(0.016)
	t.Logf("Tick 2: msgs=%d routerV=%d nodesAdded=%d",
		r2.TotalMsgs, r2.RouterVersion, r2.NodesAdded)

	// LabeledDominant
	label, count := pl.LabeledDominant(pl.Sensors)
	t.Logf("Dominant: %q × %d", label, count)
	if label == "none" && count == 0 {
		t.Log("  (không có inside hit — sensor nằm ngoài SDF, bình thường)")
	}

	// Labels hoạt động
	earthAddr := isl.Address{
		Layer: byte(gene.ISL_Earth >> 56),
		Group: byte(gene.ISL_Earth >> 48),
		Type:  byte(gene.ISL_Earth >> 40),
		ID:    byte(gene.ISL_Earth >> 32),
	}
	lbl := pl.Labels.Label(earthAddr)
	t.Logf("Labels.Label(ISL_Earth) = %q ✓", lbl)
	if lbl == "" { t.Error("earth phải có label") }

	// Stats
	ticks, nodes, version := pl.Stats()
	t.Logf("Stats: ticks=%d nodes=%d version=%d", ticks, nodes, version)
	if ticks != 2 { t.Errorf("phải có 2 ticks, got %d", ticks) }

	// Race test: Tick + AddCreature đồng thời
	stop := make(chan struct{})
	go pl.Run(stop, 0.016)
	for i := 0; i < 3; i++ {
		pl.AddCreature(gene.NewCreatureGene(gene.SpeciesDog))
	}
	close(stop)

	finalTicks, finalNodes, finalV := pl.Stats()
	t.Logf("After race: ticks=%d nodes=%d version=%d — no panic ✓",
		finalTicks, finalNodes, finalV)

	t.Log("\n✓ PerceptLayerHot:")
	t.Log("  WorldScene.Tick → HotReloadRouter.Reload → SpatialDispatcherHot")
	t.Log("  AddCreature từ goroutine → Reload ngay → router thấy node mới")
	t.Log("  Labels.Invalidate() tự động khi có node mới")
	t.Log("  LabeledDominant: 'earth × N' thay vì hex address")
}
