// internal/agents/skill_prosody.go
// ProsodySkill — phân tích ngữ điệu lời nói → cảm xúc
//
// Nguyên lý (ghi nhớ 2026-03-09):
//   Câu nói = Spline(t) qua các node ISL
//   f'(t)  = tốc độ thay đổi pitch/energy → nhịp, nhấn
//   f''(t) = gia tốc → cảm xúc đột ngột hay trơn
//   EmotionTag lưu vào Silk edge → lịch sử cảm xúc bất biến
//
// VAD model (Russell Circumplex 1980):
//   Valence   -1(buồn/tức) → +1(vui)
//   Arousal    0(mệt/bình) →  1(hưng phấn)
//   Dominance  0(yếu)      →  1(quyết đoán)

package agents

import (
	"fmt"
	"math"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ── Emotion Tag ───────────────────────────────────────────────────────────────

// EmotionTag — 3D VAD model
type EmotionTag struct {
	Valence   float64 // -1.0(buồn/tức) → +1.0(vui/hạnh phúc)
	Arousal   float64 //  0.0(mệt/bình) →  1.0(hưng phấn/tức giận)
	Dominance float64 //  0.0(yếu đuối) →  1.0(quyết đoán/tự tin)
	Intensity float64 //  0.0(mờ nhạt) →  1.0(mạnh mẽ, rõ ràng)
}

// Label trả về tên cảm xúc với cấp bậc qua Intensity
//
// Mỗi nhóm cảm xúc có 3 cấp (thấp/trung/cao) dựa trên Intensity:
//   vui:  calm → happy → euphoric
//   buồn: melancholy → sad → devastated
//   lo:   uneasy → anxious → panic
//   tức:  irritated → angry → furious
//   trung: tired → neutral → excited
//
// Dominance thấp + Arousal trung = confused (hoang mang)
func (e EmotionTag) Label() string {
	// Hoang mang: không kiểm soát được, không rõ hướng
	if math.Abs(e.Valence) < 0.25 && e.Dominance < 0.3 && e.Arousal > 0.3 {
		if e.Intensity > 0.6 { return "overwhelmed" } // ngợp
		return "confused"                              // hoang mang
	}
	switch {
	case e.Valence > 0.15 && e.Arousal > 0.4:
		// Vui + hưng phấn — 3 cấp
		if e.Intensity > 0.75 { return "euphoric" }  // vui-cao
		if e.Intensity > 0.4  { return "happy" }     // vui-trung
		return "pleased"                              // vui-thấp
	case e.Valence > 0.15 && e.Arousal <= 0.4:
		// Vui + bình tĩnh — 3 cấp
		if e.Intensity > 0.6 { return "content" }    // hài lòng sâu
		return "calm"                                 // bình thản
	case e.Valence < -0.15 && e.Arousal > 0.5:
		if e.Dominance > 0.5 {
			// Tức — 3 cấp
			if e.Intensity > 0.75 { return "furious" }   // tức-cao
			if e.Intensity > 0.4  { return "angry" }     // tức-trung
			return "irritated"                            // tức-thấp
		}
		// Lo âu — 3 cấp
		if e.Intensity > 0.75 { return "panic" }     // lo-cao
		if e.Intensity > 0.4  { return "anxious" }   // lo-trung
		return "uneasy"                               // lo-thấp
	case e.Valence < -0.15 && e.Arousal <= 0.5:
		// Buồn — 3 cấp
		if e.Intensity > 0.75 { return "devastated" } // buồn-cao
		if e.Intensity > 0.4  { return "sad" }        // buồn-trung
		return "melancholy"                            // buồn-thấp
	case e.Arousal < 0.15:
		return "tired"
	case math.Abs(e.Valence) < 0.1 && e.Arousal > 0.5:
		if e.Intensity > 0.6 { return "excited" }
		return "alert"
	default:
		return "neutral"
	}
}

// DNA trả về chuỗi lưu vào Silk edge (append-only)
func (e EmotionTag) DNA(timestampUnix int64) string {
	return fmt.Sprintf("emotion:v=%.2f:a=%.2f:d=%.2f:label=%s:t=%d",
		e.Valence, e.Arousal, e.Dominance, e.Label(), timestampUnix)
}

// Flags encode EmotionTag thành 1 byte cho ISLMessage.Flags
// bit[7:6] = valence quadrant (00=neutral, 01=happy, 10=sad, 11=angry)
// bit[5:4] = arousal level   (00=low, 01=mid, 10=high, 11=very high)
// bit[3]   = dominant flag
func (e EmotionTag) Flags() byte {
	var f byte
	switch {
	case e.Valence > 0.3:  f |= 0x40
	case e.Valence < -0.3 && e.Arousal > 0.5: f |= 0xC0
	case e.Valence < -0.3: f |= 0x80
	}
	switch {
	case e.Arousal > 0.75: f |= 0x30
	case e.Arousal > 0.5:  f |= 0x20
	case e.Arousal > 0.25: f |= 0x10
	}
	if e.Dominance > 0.5 { f |= 0x08 }
	return f
}

// ── Prosody Spline ─────────────────────────────────────────────────────────

// ProsodyFrame — một điểm trong Spline lời nói
type ProsodyFrame struct {
	T      float64 // thời gian (giây)
	Pitch  float64 // F0 Hz (0 = unvoiced)
	Energy float64 // RMS amplitude 0..1
	Rate   float64 // speaking rate (syllables/sec, ước tính)
}

// ProsodySpline — đường cong pitch+energy theo thời gian
// Đây là "câu nói" được biểu diễn bằng Spline
type ProsodySpline struct {
	Frames   []ProsodyFrame
	Duration float64 // tổng thời gian (giây)
}

// NewProsodySpline từ raw PCM float32 (16kHz mono)
// Đây là implementation đơn giản hóa — không dùng FFT thật
// Production: thay bằng WebRTC VAD + CREPE pitch tracker
func NewProsodySpline(pcm []float32, sampleRate int) ProsodySpline {
	if len(pcm) == 0 || sampleRate == 0 {
		return ProsodySpline{}
	}
	frameSize := sampleRate / 100 // 10ms frames
	if frameSize == 0 { frameSize = 160 }

	var frames []ProsodyFrame
	for i := 0; i+frameSize <= len(pcm); i += frameSize {
		frame := pcm[i : i+frameSize]
		t := float64(i) / float64(sampleRate)

		// Energy = RMS
		var sum float64
		for _, s := range frame {
			sum += float64(s) * float64(s)
		}
		energy := math.Sqrt(sum / float64(len(frame)))

		// Pitch: ước tính đơn giản từ zero-crossing rate
		// F0 ≈ ZCR × sampleRate / 2 (rough approximation)
		zc := 0
		for j := 1; j < len(frame); j++ {
			if (frame[j] >= 0) != (frame[j-1] >= 0) { zc++ }
		}
		pitch := float64(zc) * float64(sampleRate) / float64(2*frameSize)
		// Clamp to voiced range 80-400Hz, else 0 (unvoiced)
		if pitch < 80 || pitch > 400 { pitch = 0 }

		frames = append(frames, ProsodyFrame{
			T:      t,
			Pitch:  pitch,
			Energy: math.Min(energy*10, 1.0), // normalize
		})
	}
	duration := float64(len(pcm)) / float64(sampleRate)
	return ProsodySpline{Frames: frames, Duration: duration}
}

// NewProsodySplineFromFeatures tạo từ features đã trích xuất
// Dùng khi có pipeline riêng (WebRTC, python, etc.)
func NewProsodySplineFromFeatures(pitches, energies []float64, frameStepSec float64) ProsodySpline {
	n := len(pitches)
	if len(energies) < n { n = len(energies) }
	frames := make([]ProsodyFrame, n)
	for i := 0; i < n; i++ {
		frames[i] = ProsodyFrame{
			T:      float64(i) * frameStepSec,
			Pitch:  pitches[i],
			Energy: energies[i],
		}
	}
	duration := float64(n) * frameStepSec
	return ProsodySpline{Frames: frames, Duration: duration}
}

// ── Derivatives ──────────────────────────────────────────────────────────────

// Derivative tính f'(t) tại mỗi frame (finite difference)
// Trả về slice cùng độ dài với Frames
func (s ProsodySpline) Derivative() []float64 {
	n := len(s.Frames)
	d := make([]float64, n)
	if n < 2 { return d }
	for i := 1; i < n-1; i++ {
		dt := s.Frames[i+1].T - s.Frames[i-1].T
		if dt == 0 { continue }
		// Central difference trên pitch (nếu voiced)
		p_next := s.Frames[i+1].Pitch
		p_prev := s.Frames[i-1].Pitch
		if p_next == 0 || p_prev == 0 {
			// Unvoiced → dùng energy thay thế
			p_next = s.Frames[i+1].Energy * 300
			p_prev = s.Frames[i-1].Energy * 300
		}
		d[i] = (p_next - p_prev) / dt
	}
	// Boundary
	if n >= 2 {
		d[0]   = d[1]
		d[n-1] = d[n-2]
	}
	return d
}

// SecondDerivative tính f''(t) từ f'(t)
func (s ProsodySpline) SecondDerivative() []float64 {
	d1 := s.Derivative()
	n  := len(d1)
	d2 := make([]float64, n)
	if n < 2 { return d2 }
	for i := 1; i < n-1; i++ {
		dt := s.Frames[i+1].T - s.Frames[i-1].T
		if dt == 0 { continue }
		d2[i] = (d1[i+1] - d1[i-1]) / dt
	}
	if n >= 2 { d2[0] = d2[1]; d2[n-1] = d2[n-2] }
	return d2
}

// ── Emotion Detector ─────────────────────────────────────────────────────────

// DetectEmotion phân tích Spline → EmotionTag (VAD model)
//
// Nguyên lý (2026-03-09):
//   f(t)   = pitch/energy curve
//   f'(t)  normalized = hướng thay đổi → vui (+) / buồn (-)
//   f''(t) normalized = đột ngột → lo lắng / tức giận
//
// Normalize theo dt và pitchScale để tránh unit problem:
//   d1_norm = d1[i] * dt / pitchScale  → range ~[-1, 1]
//   d2_norm = d2[i] * dt² / pitchScale → range ~[-1, 1]
func DetectEmotion(s ProsodySpline) EmotionTag {
	if len(s.Frames) == 0 { return EmotionTag{} }

	d1 := s.Derivative()
	d2 := s.SecondDerivative()

	var sumPitch, sumEnergy, sumD1norm, sumAbsD1norm, sumAbsD2norm float64
	var voicedCount int
	pitchMin, pitchMax := math.MaxFloat64, 0.0

	// frame step dt (giây)
	dt := 0.01
	if len(s.Frames) >= 2 { dt = s.Frames[1].T - s.Frames[0].T }
	if dt <= 0 { dt = 0.01 }

	// pitch scale: dùng để normalize derivative (Hz/s → dimensionless)
	// Typical voiced pitch = 150 Hz, range ~100Hz → scale = 100
	pitchScale := 100.0

	for i, fr := range s.Frames {
		sumEnergy += fr.Energy
		// Normalize derivatives
		d1n := d1[i] * dt / pitchScale
		d2n := d2[i] * dt * dt / pitchScale
		sumD1norm    += d1n
		sumAbsD1norm += math.Abs(d1n)
		sumAbsD2norm += math.Abs(d2n)
		if fr.Pitch > 0 {
			sumPitch += fr.Pitch
			voicedCount++
			if fr.Pitch < pitchMin { pitchMin = fr.Pitch }
			if fr.Pitch > pitchMax { pitchMax = fr.Pitch }
		}
	}
	n := float64(len(s.Frames))
	meanEnergy   := sumEnergy / n
	meanD1norm   := sumD1norm / n       // signed: + = tăng, - = giảm
	meanAbsD1    := sumAbsD1norm / n    // biến đổi trung bình
	meanAbsD2    := sumAbsD2norm / n    // curvature trung bình
	pitchRange   := 0.0
	if voicedCount > 0 && pitchMin < math.MaxFloat64 {
		pitchRange = (pitchMax - pitchMin) / math.Max(pitchMin, 1)
	}

	// ── Arousal = energy + biến đổi pitch ───────────────────────────
	// Clamp meanAbsD1 tới 0.5 (đã normalize, thường < 0.3)
	arousal := meanEnergy*0.5 + math.Min(meanAbsD1*2, 0.5)

	// ── Valence = hướng + pitch level - curvature ────────────────────
	valence := math.Tanh(meanD1norm * 5) * 0.5  // normalized d1 → ±0.5
	if voicedCount > 0 {
		meanPitch := sumPitch / float64(voicedCount)
		valence += math.Tanh((meanPitch-150)/80) * 0.3
	}
	// curvature lớn → âm tính (lo lắng / tức giận)
	valence -= math.Min(meanAbsD2*5, 0.4)

	// ── Dominance = energy + pitch range + stability ─────────────────
	dominance := meanEnergy*0.4 + math.Min(pitchRange*0.3, 0.4)
	dominance += math.Max(0, 0.2 - meanAbsD2*3) // stable → dominant

	clamp := func(v, lo, hi float64) float64 {
		if v < lo { return lo }
		if v > hi { return hi }
		return v
	}

	// Intensity = cường độ tổng thể của cảm xúc
	// = khoảng cách từ điểm VAD đến trung tâm (neutral)
	// Neutral = V=0, A=0.5, D=0.5
	dv := valence
	da := arousal - 0.5
	dd := dominance - 0.5
	intensity := math.Sqrt(dv*dv + da*da + dd*dd) / math.Sqrt(1+0.25+0.25)
	// normalize về [0,1]: max distance = sqrt(1.5) ≈ 1.22

	return EmotionTag{
		Valence:   clamp(valence,   -1, 1),
		Arousal:   clamp(arousal,    0, 1),
		Dominance: clamp(dominance,  0, 1),
		Intensity: clamp(intensity,  0, 1),
	}
}

// ── ProsodySkill ─────────────────────────────────────────────────────────────

// ProsodySkill — Skill xử lý MsgAudio → EmotionTag → ISLMessage.Flags
//
// Pipeline:
//   MsgAudio (PCM float32) 
//     → NewProsodySpline
//     → DetectEmotion → EmotionTag
//     → gắn vào ISLMessage.Flags
//     → lưu emotion DNA vào Silk edge (append-only)
//
// Downstream:
//   SecurityGate đọc Flags byte → điều chỉnh threshold
//   MessageBus   đọc priority   → arousal cao → priority cao hơn
//   LeoAI        đọc EmotionTag → điều chỉnh tone phản hồi
type ProsodySkill struct {
	SampleRate int // default 16000 Hz
	processed  int
	lastEmotion EmotionTag
}

func NewProsodySkill(sampleRate int) *ProsodySkill {
	if sampleRate == 0 { sampleRate = 16000 }
	return &ProsodySkill{SampleRate: sampleRate}
}

func (s *ProsodySkill) Name() string { return "perception.prosody" }

// CanHandle nhận MsgAudio
func (s *ProsodySkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgAudio
}

// Execute phân tích audio → EmotionTag → trả kết quả
func (s *ProsodySkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	s.processed++

	// Decode PCM từ message payload
	pcm := decodePCM(msg.Payload)
	spline := NewProsodySpline(pcm, s.SampleRate)

	if len(spline.Frames) == 0 {
		return SkillResult{}
	}

	emotion := DetectEmotion(spline)
	s.lastEmotion = emotion

	// Tạo new message với EmotionTag gắn vào
	enriched := &isl.ISLMessage{
		MsgType:     isl.MsgKnowledge,
		PrimaryAddr: msg.PrimaryAddr, // giữ địa chỉ nguồn
		Confidence:  uint32(math.Abs(emotion.Valence) * 100),
		Flags:       emotion.Flags(),
	}

	// Priority dựa trên arousal
	// arousal > 0.7 → priority cao (người nói đang excited/angry)
	priority := 1
	if emotion.Arousal > 0.7 { priority = 3 }
	if emotion.Arousal > 0.9 { priority = 5 }

	return SkillResult{
		Message: enriched,
		Data: map[string]interface{}{
			"emotion":   emotion.Label(),
			"valence":   emotion.Valence,
			"arousal":   emotion.Arousal,
			"dominance": emotion.Dominance,
			"flags":     emotion.Flags(),
			"priority":  priority,
			"duration":  spline.Duration,
			"dna":       emotion.DNA(0), // caller điền timestamp
		},
	}
}

// Last trả về EmotionTag của lần xử lý gần nhất
func (s *ProsodySkill) Last() EmotionTag { return s.lastEmotion }

// Stats trả về số lượt đã xử lý
func (s *ProsodySkill) Stats() int { return s.processed }

// AnalyzeFeatures — entry point không qua message (dùng cho test/pipeline)
func (s *ProsodySkill) AnalyzeFeatures(pitches, energies []float64, frameStep float64) EmotionTag {
	spline := NewProsodySplineFromFeatures(pitches, energies, frameStep)
	return DetectEmotion(spline)
}

// decodePCM giải mã []byte payload → []float32
// Định dạng: little-endian float32
func decodePCM(payload []byte) []float32 {
	if len(payload) < 4 { return nil }
	n := len(payload) / 4
	out := make([]float32, n)
	for i := range out {
		b := payload[i*4 : i*4+4]
		bits := uint32(b[0]) | uint32(b[1])<<8 | uint32(b[2])<<16 | uint32(b[3])<<24
		out[i] = math.Float32frombits(bits)
	}
	return out
}

// SilkEmotionEdge lưu EmotionTag vào Silk edge DNA
// Gọi sau Execute — append-only, không bao giờ xóa
// Cấu trúc: "emotion:v=0.80:a=0.30:d=0.50:label=happy:t=1741500000"
func SilkEmotionEdge(emotion EmotionTag, timestampUnix int64) string {
	return emotion.DNA(timestampUnix)
}

// EmotionHistory tính average EmotionTag từ nhiều DNA strings
// Dùng khi LeoAI query: "người này thường nói chuyện như thế nào?"
func AverageFromDNA(dnaSlice []string) EmotionTag {
	if len(dnaSlice) == 0 { return EmotionTag{} }
	var sumV, sumA, sumD float64
	count := 0
	for _, dna := range dnaSlice {
		var v, a, d float64
		// Parse "emotion:v=X:a=Y:d=Z:..."
		fmt.Sscanf(
			extractField(dna, "v="), "%f", &v)
		fmt.Sscanf(
			extractField(dna, "a="), "%f", &a)
		fmt.Sscanf(
			extractField(dna, "d="), "%f", &d)
		sumV += v; sumA += a; sumD += d
		count++
	}
	f := float64(count)
	return EmotionTag{Valence: sumV/f, Arousal: sumA/f, Dominance: sumD/f}
}

func extractField(s, key string) string {
	idx := 0
	for i := 0; i < len(s)-len(key); i++ {
		if s[i:i+len(key)] == key {
			idx = i + len(key)
			end := idx
			for end < len(s) && s[end] != ':' { end++ }
			return s[idx:end]
		}
	}
	return "0"
}

// Đảm bảo gene package được tham chiếu (dùng Vec3 trong tương lai)
var _ = gene.Vec3{}
