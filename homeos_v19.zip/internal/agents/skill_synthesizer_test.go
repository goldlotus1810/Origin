package agents

import (
	"testing"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestSkillSynthesizer(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  SKILL SYNTHESIZER — Skill từ tập hợp các Skill nhỏ hơn    ║")
	t.Log("║  Thiếu primitive → tạo mới → compose → approve → registry  ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	graph    := NewSkillGraph()
	registry := NewSkillRegistry()
	synth    := NewSkillSynthesizerSkill(graph, registry)
	ctx      := &ExecContext{State: make(map[string]interface{})}

	// ── Scenario 1: "tổng hợp các file trong hệ thống" ───────
	t.Log("[ SCENARIO 1 ] User: 'tổng hợp các file trong hệ thống'")
	t.Log()

	msg1 := &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: []byte("tổng hợp các file trong hệ thống"),
	}
	r1 := synth.Execute(ctx, msg1)
	t.Logf("  Goal:   %s", ctx.State["synthesis.goal"])
	t.Logf("  Status: %s", r1.Data["synthesis.status"])
	t.Logf("  Missing: %v", r1.Data["synthesis.missing"])
	t.Log()
	t.Log("  Kế hoạch được đề xuất:")
	t.Log(string(r1.Message.Payload))
	t.Log()

	// User xác nhận
	t.Log("  User: 'approve ListFilesSkill'")
	created := synth.Approve("ListFilesSkill", "user")
	t.Logf("  Skills được tạo: %v", created)
	t.Log()

	// Kiểm tra registry
	_, hasReadStorage := registry.Get("ReadStorageSkill")
	_, hasListFiles   := registry.Get("ListFilesSkill")
	t.Logf("  registry[ReadStorageSkill] = %v", hasReadStorage)
	t.Logf("  registry[ListFilesSkill]   = %v", hasListFiles)
	t.Logf("  graph[ReadStorageSkill]    = %v", graph.Has("ReadStorageSkill"))
	t.Logf("  graph[ListFilesSkill]      = %v", graph.Has("ListFilesSkill"))
	t.Log()

	// ── Scenario 2: "quản lý hệ thống" ───────────────────────
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("[ SCENARIO 2 ] User: 'quản lý hệ thống'")
	t.Log()

	ctx2 := &ExecContext{State: make(map[string]interface{})}
	msg2 := &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: []byte("quản lý hệ thống"),
	}
	r2 := synth.Execute(ctx2, msg2)
	t.Logf("  Goal:   %s", ctx2.State["synthesis.goal"])
	t.Logf("  Status: %s", r2.Data["synthesis.status"])
	t.Log()
	t.Log("  Kế hoạch (thấy ReadStorageSkill đã có từ Scenario 1):")
	t.Log(string(r2.Message.Payload))
	t.Log()
	t.Log("  → ReadStorageSkill: dùng lại (đã có)")
	t.Log("  → ListFilesSkill:   dùng lại (đã có)")
	t.Log("  → OSProfileSkill:   tạo mới (primitive)")
	t.Log("  → ProcessWatchSkill:tạo mới (composed = OSProfile + Watch)")
	t.Log("  → SystemManageSkill:compose tất cả")
	t.Log()

	synth.Approve("SystemManageSkill", "user")
	_, hasSysMgr := registry.Get("SystemManageSkill")
	t.Logf("  registry[SystemManageSkill] = %v", hasSysMgr)
	t.Log()

	// ── Scenario 3: "đọc bài viết trên web" ──────────────────
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("[ SCENARIO 3 ] User: 'đọc bài viết trên trang web'")
	t.Log()

	ctx3 := &ExecContext{State: make(map[string]interface{})}
	msg3 := &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: []byte("đọc bài viết trên trang web"),
	}
	r3 := synth.Execute(ctx3, msg3)
	t.Log("  Kế hoạch:")
	t.Log(string(r3.Message.Payload))
	t.Log()
	t.Log("  WebFetchSkill:   primitive (đọc HTML, không tải file)")
	t.Log("  ContentParseSkill: composed (WebFetch → strip ads → text)")
	t.Log("  WebQASkill:      composed (Fetch + Parse → trả lời user)")
	t.Log()

	// ── Scenario 4: skill đã có → không tạo lại ──────────────
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("[ SCENARIO 4 ] User hỏi lần 2: 'tổng hợp các file' → dùng lại")

	ctx4 := &ExecContext{State: make(map[string]interface{})}
	msg4 := &isl.ISLMessage{
		MsgType: isl.MsgQuery,
		Payload: []byte("tổng hợp các file trong hệ thống"),
	}
	r4 := synth.Execute(ctx4, msg4)
	t.Logf("  Status: %s (không tạo lại)", r4.Data["synthesis.status"])
	t.Logf("  Skill:  %s", r4.Data["synthesis.skill"])
	t.Log("  → Không hỏi user, không tạo mới, compose ngay")
	t.Log()

	// ── Tổng kết ─────────────────────────────────────────────
	t.Log("[ TỔNG KẾT — QUY TRÌNH ]")
	t.Log()
	t.Log("  User yêu cầu")
	t.Log("    ↓")
	t.Log("  LeoAI.SkillSynthesizerSkill")
	t.Log("    analyzeIntent → NeedChain [ReadStorage → ListFiles]")
	t.Log("    ↓")
	t.Log("  Kiểm tra graph: thiếu gì?")
	t.Log("    ReadStorageSkill → MISSING → primitiveLibrary có template")
	t.Log("    ListFilesSkill   → MISSING → template: deps=[ReadStorage]")
	t.Log("    ↓")
	t.Log("  Tạo SynthesisResult → NeedApproval=[ReadStorage, ListFiles]")
	t.Log("    ↓")
	t.Log("  AAM → User: 'cần tạo 2 Skill mới, xác nhận?'")
	t.Log("    ↓")
	t.Log("  User approve → graph.Add + registry.Register")
	t.Log("    ↓")
	t.Log("  Lần sau cùng yêu cầu → use_existing → không hỏi nữa")
	t.Log()
	t.Log("  QT7 cho Skill:")
	t.Log("  ĐN (yêu cầu lặp) → primitive → compose → QR (bất biến)")

	t.Log()
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

	// Assertions
	if !graph.Has("ReadStorageSkill") { t.Error("✗ ReadStorageSkill chưa được tạo") }
	if !graph.Has("ListFilesSkill")   { t.Error("✗ ListFilesSkill chưa được tạo") }
	if r4.Data["synthesis.status"] != "composed" {
		t.Errorf("✗ Lần 2 phải reuse: %v", r4.Data["synthesis.status"])
	}
}
