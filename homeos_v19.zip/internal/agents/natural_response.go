// internal/agents/natural_response.go
// NaturalResponse — chuyển EmotionTag + BookMemory → câu nói tự nhiên
//
// "Tấm màn đen": từ data (V=-0.75, pairs, inflections)
//                → ngôn ngữ thật sự có hồn
//
// Nguyên tắc:
//   1. Đồng cảm TRƯỚC, thông tin SAU
//   2. Dùng TÊN nhân vật, không dùng "từ này V=-0.75"
//   3. Hỏi ngược lại — tạo kết nối, không phải độc thoại
//   4. Nịnh đúng lúc = tự nhiên. Nịnh sai lúc = giả tạo

package agents

import (
	"fmt"
	"math/rand"
	"strings"
)

// NaturalResponse tạo câu trả lời tự nhiên từ BookShelf + userCurve
func (s *BookShelf) NaturalResponse(query string, userCurve *ConversationCurve) string {
	mem, _ := s.Find(query)
	tone   := userCurve.NextTone()
	lo     := strings.ToLower(query)

	if mem == nil {
		return naturalNoBook(query, tone)
	}

	// Nhận diện nhân vật / sự kiện được hỏi đến
	subject := detectSubject(lo, mem)
	mood    := ""
	if len(userCurve.Window) > 0 {
		mood = userCurve.Window[len(userCurve.Window)-1].Tag.Label()
	}

	// Xây response theo tone
	switch tone.Style {

	case "pause":
		// Đột ngột nặng — dừng lại, không vội thông tin
		return naturalPause(subject, mood, mem)

	case "supportive":
		// Đang buồn → đồng cảm, dẫn nhẹ lên
		return naturalSupportive(subject, query, mem)

	case "gentle":
		// Buồn ổn định → nhẹ nhàng, không ép
		return naturalGentle(subject, mem)

	case "reinforcing":
		// Đang hồi phục / tích cực → củng cố, mở rộng
		return naturalReinforcing(subject, query, mem)

	case "celebratory":
		// Đang vui / hứng khởi → chia vui, đào sâu
		return naturalCelebratory(subject, query, mem)

	default: // engaged / neutral
		return naturalEngaged(subject, query, mem)
	}
}

// ─── Tone-specific builders ───────────────────────────────────────────────

func naturalPause(subject string, mood string, mem *BookMemory) string {
	templates := []string{
		"Ừ. %s Đọc đến đó mà không xúc động mới lạ.",
		"%s Khoảnh khắc đó nặng thật — bạn đang ổn không?",
		"Cái đó... %s Bạn muốn nói về điều gì đang cảm thấy không?",
	}
	insert := subjectDescription(subject, mem, "heavy")
	return fmt.Sprintf(pick(templates), insert)
}

func naturalSupportive(subject string, query string, mem *BookMemory) string {
	lo := strings.ToLower(query)

	// Phản hồi cụ thể theo nhân vật
	switch {
	case contains(lo, "rhett"):
		return pick([]string{
			"Mình cũng thấy Rhett đáng thương lắm. Anh ấy yêu thật lòng — kiểu yêu không đòi hỏi — nhưng Scarlett không nhìn thấy cho đến khi quá muộn. Bạn đọc đến đoạn nào rồi?",
			"Rhett là người hiểu Scarlett nhất, nhưng lại bị cô ấy xem nhẹ nhất. Cái nghịch lý đó mới đau. Bạn nghĩ nếu Scarlett nhận ra sớm hơn thì sao?",
		})
	case contains(lo, "scarlett"):
		return pick([]string{
			"Mình hiểu. Scarlett sống trong đau buồn nhưng không cho phép mình dừng lại — đó vừa là sức mạnh vừa là bi kịch của cô ấy. Bạn cảm thấy gần gũi với cô ấy không?",
			"Scarlett khổ theo cách rất riêng — cô ấy mạnh mẽ bên ngoài nhưng cô đơn thật sự bên trong. Bạn đang đọc đến phần nào?",
		})
	case contains(lo, "bonnie") || contains(lo, "chết"):
		return pick([]string{
			"Mình hiểu tại sao bạn buồn. Cái chết của Bonnie là khoảnh khắc nặng nề nhất — Rhett hoàn toàn tan vỡ sau đó. Đó là lúc mình thấy anh ấy không còn cố gắng nữa.",
			"Phần đó mình cũng thấy nặng. Bonnie là điều duy nhất giữ Rhett lại — khi mất con, anh ấy mất luôn lý do ở lại.",
		})
	case contains(lo, "ashley"):
		return pick([]string{
			"Ashley là ảo tưởng của Scarlett — cô ấy yêu một người không thực, và bỏ lỡ người thực ngay bên cạnh. Bạn thấy Ashley đáng thương hay đáng trách hơn?",
		})
	default:
		avg := mem.History.AverageVAD()
		return fmt.Sprintf(
			"Mình hiểu — %s là cuốn sách mang nhiều đau buồn thật (avg V=%+.2f). "+
				"Bạn đang đọc đến phần nào rồi?",
			mem.Source, avg.Valence)
	}
}

func naturalGentle(subject string, mem *BookMemory) string {
	return pick([]string{
		fmt.Sprintf("Cứ từ từ với %s nhé — cuốn sách này nhiều cảm xúc lắm. Bạn muốn nói về phần nào?", mem.Source),
		"Đôi khi đọc sách mà thấy nặng — đó là dấu hiệu sách chạm đúng chỗ. Bạn đang cảm thấy thế nào?",
	})
}

func naturalReinforcing(subject string, query string, mem *BookMemory) string {
	lo := strings.ToLower(query)
	switch {
	case contains(lo, "scarlett"):
		pairs := mem.StrongestPairs(5)
		related := extractRelated("scarlett", pairs)
		result := "Bạn đang thấy đúng điều đặc biệt của Scarlett rồi đấy. "
		if len(related) > 0 {
			result += fmt.Sprintf("Trong sách, cô ấy thường xuất hiện cùng %s — ",
				strings.Join(related[:min3(len(related), 2)], " và "))
		}
		result += "luôn ở giữa những khoảnh khắc quyết định nhất. "
		result += "Bạn có thích kiểu nhân vật không chịu khuất phục không?"
		return result
	case contains(lo, "rhett"):
		return "Bạn đang nhìn thấy lớp sâu hơn của Rhett rồi đấy — anh ấy thông minh nhất nhưng cũng cô đơn nhất. Bạn thấy anh ấy đáng thương hay đáng ngưỡng mộ hơn?"
	default:
		top := mem.TopEmotionalWords(3)
		if len(top) >= 2 {
			return fmt.Sprintf("Bạn đang cảm nhận được cái hay của %s — "+
				"cuốn sách này đầy những khoảnh khắc như '%s' và '%s'. "+
				"Bạn thích nhất phần nào?",
				mem.Source, top[0].Word, top[1].Word)
		}
		return fmt.Sprintf("Cảm nhận của bạn về %s rất tinh tế đấy! Bạn thích nhất phần nào?", mem.Source)
	}
}

func naturalCelebratory(subject string, query string, mem *BookMemory) string {
	lo := strings.ToLower(query)
	switch {
	case contains(lo, "scarlett"):
		return pick([]string{
			"Đúng rồi! Scarlett là nhân vật phi thường — ngay cả khi mất tất cả, cô ấy nhìn về phía trước. Câu 'Tomorrow is another day' không phải lạc quan ngây thơ — đó là ý chí thật sự. Bạn có thích kiểu kết thúc mở như vậy không?",
			"Mình cũng mê Scarlett vì lý do đó! Cô ấy không hoàn hảo — thậm chí đôi khi ích kỷ — nhưng sức sống của cô ấy mới thực sự đáng ngưỡng mộ. Bạn đã đọc xong chưa?",
		})
	case contains(lo, "rhett"):
		return "Rhett thú vị lắm nhỉ! Anh ấy nhìn thấu tất cả mà không nói — kiểu người biết nhiều nhưng chọn im lặng. Bạn thích câu nói nào của anh ấy nhất?"
	default:
		return fmt.Sprintf("Cuốn sách này có %d bước ngoặt cảm xúc lớn — từ %s đến %s. Bạn đang ở đoạn nào thú vị nhất?",
			len(mem.Inflections),
			func() string {
				if len(mem.Inflections) > 0 { return mem.Inflections[0].Tag.Label() }
				return "đầu sách"
			}(),
			func() string {
				if len(mem.Inflections) > 0 { return mem.Inflections[len(mem.Inflections)-1].Tag.Label() }
				return "cuối sách"
			}())
	}
}

func naturalEngaged(subject string, query string, mem *BookMemory) string {
	lo := strings.ToLower(query)
	avg := mem.History.AverageVAD()

	switch {
	case contains(lo, "rhett") && contains(lo, "scarlett"):
		return "Rhett và Scarlett là cặp đôi phức tạp nhất mình từng thấy trong văn học — anh ấy yêu thật, cô ấy không nhận ra. Bạn đứng về phía ai?"
	case contains(lo, "rhett"):
		return "Rhett Butler — người hiểu Scarlett nhất nhưng lại bị cô ấy xem nhẹ nhất. Bạn nghĩ anh ấy đúng khi rời đi không?"
	case contains(lo, "scarlett"):
		return "Scarlett O'Hara — không hoàn hảo, đôi khi ích kỷ, nhưng không bao giờ bỏ cuộc. Bạn thấy cô ấy đáng yêu hay đáng ghét hơn?"
	case contains(lo, "tara") || contains(lo, "đất"):
		return "Tara là biểu tượng — không chỉ là ngôi nhà mà là bản sắc của Scarlett. 'Đất đỏ vẫn còn đó' — câu đó mình thấy rất mạnh."
	default:
		top := mem.TopEmotionalWords(2)
		if len(top) >= 2 {
			return fmt.Sprintf("%s là cuốn sách %s — những từ như '%s' và '%s' xuất hiện nhiều nhất. Bạn thấy phần nào ấn tượng nhất?",
				mem.Source, describeEmotion(avg), top[0].Word, top[1].Word)
		}
		return fmt.Sprintf("Bạn đang hỏi về %s — cuốn sách %s. Bạn muốn nói về điều gì cụ thể?",
			mem.Source, describeEmotion(avg))
	}
}

func naturalNoBook(query string, tone ResponseTone) string {
	switch tone.Style {
	case "supportive", "pause":
		return "Mình chưa đọc cuốn đó, nhưng mình đang lắng nghe. Bạn kể cho mình nghe đi — bạn đang cảm thấy gì về nó?"
	case "celebratory", "reinforcing":
		return "Ồ cuốn đó mình chưa đọc! Nghe bạn nói có vẻ hay lắm — kể cho mình nghe đi, nó về cái gì vậy?"
	default:
		return "Mình chưa đọc cuốn đó. Bạn có thể kể một chút không?"
	}
}

// ─── Helpers ──────────────────────────────────────────────────────────────

func detectSubject(lo string, mem *BookMemory) string {
	for _, name := range []string{"scarlett", "rhett", "ashley", "melanie", "bonnie", "tara"} {
		if contains(lo, name) { return name }
	}
	for word := range mem.Words {
		if contains(lo, word) { return word }
	}
	return ""
}

func subjectDescription(subject string, mem *BookMemory, mood string) string {
	if subject == "" { return "" }
	if lw, ok := mem.LookupLearned(subject); ok && len(lw.Examples) > 0 {
		return fmt.Sprintf("'%s' — \"%s...\"", subject, truncateStr(lw.Examples[0], 40))
	}
	return fmt.Sprintf("'%s'", subject)
}

func extractRelated(word string, pairs []*SemanticPair) []string {
	var result []string
	for _, p := range pairs {
		if p.WordA == word { result = append(result, p.WordB) }
		if p.WordB == word { result = append(result, p.WordA) }
	}
	return result
}

func contains(s, sub string) bool {
	return strings.Contains(s, sub)
}

func pick(templates []string) string {
	return templates[rand.Intn(len(templates))]
}
