// internal/agents/percept_layer.go
// PerceptLayer — vòng lặp nhận thức không gian theo thời gian
//
// Mỗi tick:
//   1. WorldScene.Tick(dt) — cập nhật vật lý
//   2. WorldScene.SpatialNodes() — lấy thực thể hiện tại
//   3. ScanPoints — probe points quanh mỗi sensor
//   4. SpatialDispatcher.DispatchBatch → ISLMessage → Bus
//
// Nguyên tắc:
//   PerceptLayer không biết agent là ai — chỉ dispatch theo SDF
//   Agent nhận message, tự quyết định làm gì
//   Tick interval tối thiểu = MinTickMs để tránh busy loop

package agents

import (
	"sync/atomic"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// SensorPoint — 1 điểm cảm biến trong không gian
type SensorPoint struct {
	ID       string    // tên sensor (debug)
	Pos      gene.Vec3 // vị trí hiện tại
	Radius   float64   // bán kính scan
	NSamples int       // số probe points
}

// PerceptLayer quản lý vòng nhận thức
type PerceptLayer struct {
	World      *gene.WorldScene
	Dispatcher *SpatialDispatcher
	Sensors    []SensorPoint
	MinTickMs  int64

	tickCount  atomic.Uint64
	lastTick   time.Time
}

// NewPerceptLayer tạo PerceptLayer
func NewPerceptLayer(world *gene.WorldScene, disp *SpatialDispatcher) *PerceptLayer {
	return &PerceptLayer{
		World:      world,
		Dispatcher: disp,
		MinTickMs:  50, // 20Hz max
	}
}

// AddSensor thêm sensor point
func (pl *PerceptLayer) AddSensor(s SensorPoint) {
	if s.NSamples == 0 { s.NSamples = 8 }
	if s.Radius == 0   { s.Radius   = 2.0 }
	pl.Sensors = append(pl.Sensors, s)
}

// TickResult kết quả 1 tick
type TickResult struct {
	TickN    uint64
	Dt       float64
	Dispatched map[string]int // agentID → số message
	TotalMsgs  int
}

// Tick thực hiện 1 chu kỳ nhận thức
// dt: thời gian (giây) từ tick trước
func (pl *PerceptLayer) Tick(dt float64) TickResult {
	tick := pl.tickCount.Add(1)
	pl.World.Tick(dt)

	// Cập nhật SpatialNodes từ WorldScene mới nhất
	nodes := pl.World.SpatialNodes()
	pl.Dispatcher.Router.Nodes = nodes

	res := TickResult{
		TickN:      tick,
		Dt:         dt,
		Dispatched: make(map[string]int),
	}

	// Mỗi sensor → probe ring quanh vị trí → dispatch
	for _, sensor := range pl.Sensors {
		probes := gene.ProbeRing(sensor.Pos, sensor.Radius, sensor.NSamples)
		counts := pl.Dispatcher.DispatchBatch(probes, isl.MsgQuery)
		for agentID, n := range counts {
			res.Dispatched[agentID] += n
			res.TotalMsgs += n
		}
	}

	pl.lastTick = time.Now()
	return res
}

// Run vòng lặp liên tục với ticker
// Gọi trong goroutine riêng
// Dừng khi <-stop nhận được
func (pl *PerceptLayer) Run(stop <-chan struct{}, tickDt float64) {
	interval := time.Duration(pl.MinTickMs) * time.Millisecond
	ticker   := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-stop:
			return
		case <-ticker.C:
			pl.Tick(tickDt)
		}
	}
}

// Stats thống kê nhanh
func (pl *PerceptLayer) Stats() (ticks uint64, sensors int) {
	return pl.tickCount.Load(), len(pl.Sensors)
}

// HotReload cập nhật ISLRouter nodes từ WorldScene — không restart
// Gọi sau khi ws.AddCreature() hoặc ws.RemoveCreature()
// Thread-safe với Tick() vì cả hai đều single-threaded trong goroutine Run()
func (pl *PerceptLayer) HotReload() int {
	newNodes := pl.World.SpatialNodes()
	pl.Dispatcher.Router.Nodes = newNodes
	return len(newNodes)
}

