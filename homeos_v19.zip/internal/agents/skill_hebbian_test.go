// internal/agents/skill_hebbian_test.go

package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestHebbianBoostExistingEdge(t *testing.T) {
	dn := memory.NewShortTerm(64)
	graph := silk.NewSilkGraph()

	// Thêm 2 nodes vào graph
	addrA := isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 1}
	addrB := isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 2}
	graph.AddNode(&silk.OlangNode{Addr: addrA, Name: "quang_hop", Status: silk.StatusQR})
	graph.AddNode(&silk.OlangNode{Addr: addrB, Name: "anh_sang",  Status: silk.StatusQR})
	graph.AddEdge(addrA, addrB, silk.OpSimilar)

	// Seed 2 observations gần đây — co-activate
	now := time.Now()
	dn.ForceInsert(memory.Observation{
		ISL: addrA, Label: "quang_hop", Confidence: 0.8,
		FireCount: 3, UpdatedAt: now.Add(-5 * time.Second),
		NodeHash: isl.NodeHash(0x0001),
	})
	dn.ForceInsert(memory.Observation{
		ISL: addrB, Label: "anh_sang", Confidence: 0.75,
		FireCount: 2, UpdatedAt: now.Add(-10 * time.Second),
		NodeHash: isl.NodeHash(0x0002),
	})

	skill := NewHebbianSkill(dn, graph)
	result := skill.Execute(&ExecContext{}, &isl.ISLMessage{MsgType: isl.MsgTick})

	boosted := result.Data["hebbian.boosted"].(int)
	if boosted < 1 {
		t.Errorf("expected edge boost >= 1, got %d", boosted)
	}
	t.Logf("✅ Hebbian: boosted %d existing edges", boosted)

	// Kiểm tra weight tăng
	nodeA, ok := graph.Get(addrA)
	if !ok {
		t.Fatal("node A not found")
	}
	for _, e := range nodeA.Edges {
		if e.To.Uint64() == addrB.Uint64() {
			t.Logf("✅ edge A→B weight = %d (expected >= 1)", e.Weight)
			if e.Weight < 1 {
				t.Errorf("weight should be >= 1 after boost")
			}
			return
		}
	}
	t.Error("edge A→B not found")
}

func TestHebbianTrackCoActivation(t *testing.T) {
	dn := memory.NewShortTerm(64)
	graph := silk.NewSilkGraph()

	addrA := isl.Address{Layer: 3, Group: 'B', Type: 'b', ID: 1}
	addrB := isl.Address{Layer: 3, Group: 'B', Type: 'b', ID: 2}
	graph.AddNode(&silk.OlangNode{Addr: addrA, Name: "node_a", Status: silk.StatusQR})
	graph.AddNode(&silk.OlangNode{Addr: addrB, Name: "node_b", Status: silk.StatusQR})
	// Không có edge giữa A và B

	skill := NewHebbianSkill(dn, graph)
	now := time.Now()

	// Chạy hebbMinCoFires lần với co-activation
	for i := 0; i < hebbMinCoFires; i++ {
		dn.ForceInsert(memory.Observation{
			ISL: addrA, Label: "node_a", Confidence: 0.8, FireCount: i + 1,
			UpdatedAt: now.Add(-time.Duration(i) * time.Second),
			NodeHash:  isl.NodeHash(uint64(0xA000 + i)),
		})
		dn.ForceInsert(memory.Observation{
			ISL: addrB, Label: "node_b", Confidence: 0.75, FireCount: i + 1,
			UpdatedAt: now.Add(-time.Duration(i) * time.Second),
			NodeHash:  isl.NodeHash(uint64(0xB000 + i)),
		})
		skill.Execute(&ExecContext{}, &isl.ISLMessage{MsgType: isl.MsgTick})
	}

	// Sau hebbMinCoFires lần, co-activation counter được reset
	key := coKey(addrA, addrB)
	if skill.coCount[key] != 0 {
		t.Logf("⚠️  coCount[%v]=%d (expected 0 after reset)", key, skill.coCount[key])
	}
	t.Logf("✅ Hebbian: co-activation tracked and reset after %d fires", hebbMinCoFires)
}

func TestHebbianNoInterLayerBoost(t *testing.T) {
	dn := memory.NewShortTerm(64)
	graph := silk.NewSilkGraph()

	// 2 nodes ở layers khác nhau → không co-activate
	addrA := isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 1}
	addrC := isl.Address{Layer: 5, Group: 'A', Type: 'a', ID: 1}
	graph.AddNode(&silk.OlangNode{Addr: addrA, Status: silk.StatusQR})
	graph.AddNode(&silk.OlangNode{Addr: addrC, Status: silk.StatusQR})
	graph.AddEdge(addrA, addrC, silk.OpSimilar)

	now := time.Now()
	dn.ForceInsert(memory.Observation{ISL: addrA, FireCount: 2, UpdatedAt: now.Add(-5*time.Second), NodeHash: isl.NodeHash(0x1)})
	dn.ForceInsert(memory.Observation{ISL: addrC, FireCount: 2, UpdatedAt: now.Add(-5*time.Second), NodeHash: isl.NodeHash(0x2)})

	result := NewHebbianSkill(dn, graph).Execute(&ExecContext{}, &isl.ISLMessage{MsgType: isl.MsgTick})
	boosted := result.Data["hebbian.boosted"].(int)
	if boosted > 0 {
		t.Errorf("inter-layer edges không được boost, got %d", boosted)
	}
	t.Logf("✅ Hebbian: inter-layer không bị boost (đúng)")
}
func TestHebbianDecay(t *testing.T) {
	graph := silk.NewSilkGraph()
	addrA := isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 1}
	addrB := isl.Address{Layer: 3, Group: 'A', Type: 'a', ID: 2}
	graph.AddNode(&silk.OlangNode{Addr: addrA, Name: "node_a", Status: silk.StatusQR})
	graph.AddNode(&silk.OlangNode{Addr: addrB, Name: "node_b", Status: silk.StatusQR})
	graph.AddEdge(addrA, addrB, silk.OpSimilar)

	// Boost weight lên 3
	graph.BoostEdge(addrA, addrB, silk.OpSimilar)
	graph.BoostEdge(addrA, addrB, silk.OpSimilar)
	graph.BoostEdge(addrA, addrB, silk.OpSimilar)
	if w := graph.EdgeWeight(addrA.Uint64(), addrB.Uint64()); w != 3 {
		t.Fatalf("weight sau boost phải là 3, got %d", w)
	}

	// Decay trực tiếp
	decayed := graph.DecayAllEdges(0)
	if decayed == 0 {
		t.Error("DecayAllEdges phải decay ít nhất 1 edge")
	}
	w := graph.EdgeWeight(addrA.Uint64(), addrB.Uint64())
	if w != 2 {
		t.Errorf("weight sau 1 decay phải là 2, got %d", w)
	}
	t.Logf("  Decay: decayed=%d, weight sau decay=%d", decayed, w)

	// Decay xuống 0 không âm
	graph.DecayAllEdges(0)
	graph.DecayAllEdges(0)
	w = graph.EdgeWeight(addrA.Uint64(), addrB.Uint64())
	if w != 0 {
		t.Errorf("weight phải là 0 sau 3 lần decay, got %d", w)
	}
	// Decay thêm — không âm
	graph.DecayAllEdges(0)
	w = graph.EdgeWeight(addrA.Uint64(), addrB.Uint64())
	if w != 0 {
		t.Errorf("weight không được âm, got %d", w)
	}
	t.Logf("  Decay không âm: weight=%d ✓", w)
}
