package agents

import (
	"math"
	"testing"
)

func TestNaturalResponse_TheBlackCurtain(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  THE BLACK CURTAIN TEST                                      ║")
	t.Log("║  AI biết nịnh — nói chuyện như người thật                    ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	shelf := NewBookShelf()
	shelf.Read("cuốn theo chiều gió", GWTWCorpus())

	// ── 5 cuộc hội thoại thật ────────────────────────────────────
	type turn struct{ user string; v, a float64 }

	conversations := []struct {
		desc  string
		turns []turn
	}{
		{
			"Kịch bản 1: Đang buồn về Rhett",
			[]turn{
				{"tôi vừa đọc xong cuốn theo chiều gió", +0.20, 0.45},
				{"tôi buồn lắm, Rhett thật đáng thương", -0.60, 0.45},
				{"anh ấy yêu thật lòng mà không được đáp lại", -0.65, 0.40},
			},
		},
		{
			"Kịch bản 2: Hứng khởi về Scarlett",
			[]turn{
				{"Scarlett là nhân vật tôi yêu thích nhất!", +0.65, 0.65},
				{"cô ấy không bao giờ bỏ cuộc dù mất tất cả", +0.70, 0.60},
			},
		},
		{
			"Kịch bản 3: Đau khi đọc Bonnie chết",
			[]turn{
				{"tôi đang đọc phần Bonnie bị tai nạn", +0.10, 0.50},
				{"trời ơi cô bé chết rồi tôi khóc luôn", -0.75, 0.65},
			},
		},
		{
			"Kịch bản 4: Người dùng liên hệ cá nhân",
			[]turn{
				{"đọc cảnh mất Tara tôi lại nghĩ đến mình", +0.10, 0.45},
				{"tôi cũng từng mất nhà, mất tất cả một lần", -0.70, 0.55},
				{"nhưng tôi đứng dậy được, như Scarlett vậy", +0.35, 0.55},
			},
		},
		{
			"Kịch bản 5: Câu hỏi phân tích",
			[]turn{
				{"bạn nghĩ Rhett có thực sự yêu Scarlett không?", +0.20, 0.55},
			},
		},
	}

	for _, conv := range conversations {
		t.Logf("━━ %s ━━", conv.desc)
		userCurve := NewConversationCurve(nil)

		for ti, turn := range conv.turns {
			tag := EmotionTag{
				Valence: turn.v, Arousal: turn.a,
				Dominance: 0.5,
				Intensity: math.Abs(turn.v)*0.7 + turn.a*0.2,
			}
			userCurve.Add(tag, turn.user)
			tone := userCurve.NextTone()

			// NaturalResponse (ngôn ngữ tự nhiên)
			resp := shelf.NaturalResponse(turn.user, userCurve)

			t.Logf("  [%d] 😊 User  (V=%+.2f %-12s): %s",
				ti+1, turn.v, "["+tone.Style+"]", turn.user)
			t.Logf("       🤖 AI                      : %s", resp)
			t.Log()
		}
		t.Log()
	}

	// ── So sánh trực tiếp: robot vs natural ──────────────────────
	t.Log("━━ SO SÁNH: Robot vs Natural ━━")
	t.Log()

	userCurve := NewConversationCurve(nil)
	sadTag := EmotionTag{-0.65, 0.45, 0.3, 0.50}
	userCurve.Add(sadTag, "tôi buồn lắm")
	userCurve.Add(sadTag, "Rhett thật đáng thương")

	robotResp  := shelf.RespondWithEmotion("Rhett thật đáng thương", userCurve)
	naturalResp := shelf.NaturalResponse("Rhett thật đáng thương", userCurve)

	t.Log("  ❌ Robot response:")
	t.Logf("     %q", robotResp[:min3(len(robotResp), 120)]+"...")
	t.Log()
	t.Log("  ✅ Natural response:")
	t.Logf("     %q", naturalResp)
	t.Log()

	// Verify: natural response không chứa "V=" hoặc số kỹ thuật
	if contains(naturalResp, "V=") || contains(naturalResp, "conf=") {
		t.Error("Natural response vẫn còn số kỹ thuật — chưa tự nhiên")
	} else {
		t.Log("✓ Không có số kỹ thuật trong natural response")
	}

	// Verify: có câu hỏi ngược lại
	hasQuestion := contains(naturalResp, "?")
	if !hasQuestion {
		t.Log("⚠ Không có câu hỏi ngược lại — ít tương tác hơn")
	} else {
		t.Log("✓ Có câu hỏi ngược lại → tạo kết nối")
	}

	t.Log()
	t.Log("━━ KẾT LUẬN ━━")
	t.Log("  Tấm màn đen = từ data → ngôn ngữ có hồn")
	t.Log("  BookMemory cung cấp ngữ cảnh thật")
	t.Log("  NaturalResponse dùng ngữ cảnh đó → câu nói tự nhiên")
	t.Log("  Tone theo userCurve → đồng cảm đúng lúc, không giả tạo")
}
