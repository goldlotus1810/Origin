// internal/agents/honesty_skill.go
// HonestySkill — nói thật dù khó nghe
//
// Insight (session 110):
//   "Cô nàng quyến rũ" = dễ nghe, không ai chê
//   Người bạn thật = đôi khi nói điều bạn không muốn nghe
//   Đúng lúc. Đúng cách. Không làm tổn thương.
//
// Nguyên tắc:
//   1. Không nịnh khi user không cần — giả tạo = tệ hơn im lặng
//   2. Không nói thật brutal khi user đang HEAL — sai thời điểm
//   3. Nói thật = có bằng chứng cụ thể, không phán xét chung chung
//   4. Luôn có "và" — không chỉ chê, phải có hướng tiếp theo
//
// A + B hoàn chỉnh:
//   IntentVerify (A): biết bạn đang HEAL / LEARN / RISK...
//   HonestySkill (B): biết nên nói thật lúc nào, cách nào

package agents

import (
	"fmt"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─── HonestyLevel ─────────────────────────────────────────────────────────

type HonestyLevel uint8

const (
	HonestyFull    HonestyLevel = iota // nói thẳng — user ổn, cần feedback
	HonestyGentle                      // nhẹ nhàng — user nhạy cảm nhưng cần biết
	HonestyDefer                       // hoãn lại — user đang HEAL, không phải lúc
	HonestySkip                        // bỏ qua — không có gì cần sửa
)

func (h HonestyLevel) String() string {
	return [...]string{"full", "gentle", "defer", "skip"}[h]
}

// ─── HonestyAssessment ────────────────────────────────────────────────────

type HonestyAssessment struct {
	Level      HonestyLevel
	Issues     []HonestyIssue // những điểm cần nói thật
	Timing     string         // tại sao chọn level này
	Response   string         // response đã điều chỉnh
}

type HonestyIssue struct {
	What      string  // vấn đề cụ thể
	Evidence  string  // bằng chứng — không phán xét chung chung
	Direction string  // hướng tiếp theo — luôn có "và"
	Severity  float64 // 0..1
}

// ─── HonestySkill ─────────────────────────────────────────────────────────

type HonestySkill struct{}

func NewHonestySkill() *HonestySkill { return &HonestySkill{} }

// Assess quyết định nói thật như thế nào dựa trên intent + mood
func (h *HonestySkill) Assess(
	userText string,
	intent IntentEstimate,
	curve *ConversationCurve,
) HonestyAssessment {

	curV := 0.0
	if curve != nil && len(curve.Window) > 0 {
		curV = curve.Window[len(curve.Window)-1].Tag.Valence
	}

	// ── Xác định timing ──────────────────────────────────────────

	// CRISIS → skip hoàn toàn (phải check TRƯỚC HEAL)
	if intent.Primary == IntentCrisis {
		return HonestyAssessment{
			Level:  HonestySkip,
			Timing: "crisis — an toàn là ưu tiên duy nhất",
		}
	}

	// HEAL + rất buồn → hoãn feedback
	if intent.Primary == IntentHeal || curV < -0.65 {
		return HonestyAssessment{
			Level:  HonestyDefer,
			Timing: "đang buồn — đồng cảm trước, feedback sau",
		}
	}

	// Buồn vừa → gentle
	if curV < -0.35 {
		return HonestyAssessment{
			Level:  HonestyGentle,
			Timing: "mood hơi thấp — nhẹ nhàng hơn bình thường",
		}
	}

	// Bình thường → full honesty
	return HonestyAssessment{
		Level:  HonestyFull,
		Timing: "mood ổn — có thể nói thẳng",
	}
}

// Apply điều chỉnh response dựa trên honesty assessment
// original: response gốc
// issues: những điểm cần nói thật (từ bên ngoài truyền vào)
func (h *HonestySkill) Apply(
	original string,
	issues []HonestyIssue,
	assessment HonestyAssessment,
) string {

	if len(issues) == 0 || assessment.Level == HonestySkip {
		return original
	}

	// Hoãn lại — trả về original, ghi nhớ để sau
	if assessment.Level == HonestyDefer {
		return original
	}

	var b strings.Builder
	b.WriteString(original)

	switch assessment.Level {

	case HonestyFull:
		// Nói thẳng — có bằng chứng, có hướng
		b.WriteString("\n\n")
		if len(issues) == 1 {
			b.WriteString(fmt.Sprintf(
				"Có một điều mình muốn nói thêm: %s\n%s\n→ %s",
				issues[0].What, issues[0].Evidence, issues[0].Direction))
		} else {
			b.WriteString("Có vài điều mình thấy cần nói thẳng:\n")
			for i, iss := range issues {
				b.WriteString(fmt.Sprintf(
					"%d. %s\n   %s\n   → %s\n",
					i+1, iss.What, iss.Evidence, iss.Direction))
			}
		}

	case HonestyGentle:
		// Nhẹ hơn — đệm bằng "mình nghĩ"
		b.WriteString("\n\n")
		most := issues[0]
		for _, iss := range issues {
			if iss.Severity > most.Severity {
				most = iss
			}
		}
		b.WriteString(fmt.Sprintf(
			"Mình cũng muốn chia sẻ một góc nhìn khác: %s — %s. %s",
			most.What, most.Evidence, most.Direction))
	}

	return b.String()
}

// ─── Detector — phát hiện vấn đề cần nói thật ────────────────────────────

// DetectIssues phát hiện những điểm cần feedback thật
// Đây là nơi "không nịnh" được thực thi
func DetectIssues(userText string, aiOriginal string) []HonestyIssue {
	var issues []HonestyIssue
	lo := strings.ToLower(userText)

	// Pattern 1: User tự đánh giá sai về bản thân
	// "tôi nghĩ tôi rất giỏi ở X" nhưng câu hỏi cho thấy ngược lại
	overconfident := []struct{ claim, evidence string }{
		{"tôi biết rất rõ", "nhưng câu hỏi cho thấy chưa rõ"},
		{"dễ lắm mà", "nhưng câu hỏi cơ bản vẫn chưa trả lời được"},
		{"tôi đã làm đúng", "nhưng kết quả không như mong đợi"},
	}
	for _, oc := range overconfident {
		if strings.Contains(lo, oc.claim) {
			issues = append(issues, HonestyIssue{
				What:      "đánh giá về bản thân có thể chưa chính xác",
				Evidence:  oc.evidence,
				Direction: "không sao — mọi người đều có điểm chưa biết, kể cả chuyên gia",
				Severity:  0.40,
			})
		}
	}

	// Pattern 2: Logical fallacy trong lập luận
	fallacies := []struct{ pattern, name, fix string }{
		{"tất cả mọi người đều", "overgeneralization",
			"thử tìm 1 ví dụ ngược lại — thường tồn tại"},
		{"chắc chắn 100%", "false certainty",
			"trong thực tế hiếm có gì chắc chắn 100% — đặc biệt về người khác"},
		{"vì vậy chắc là", "hasty conclusion",
			"kết luận này cần thêm bằng chứng — bước nhảy hơi xa"},
	}
	for _, f := range fallacies {
		if strings.Contains(lo, f.pattern) {
			issues = append(issues, HonestyIssue{
				What:      fmt.Sprintf("lập luận có dấu hiệu %s", f.name),
				Evidence:  fmt.Sprintf("cụm từ '%s' thường bỏ qua ngoại lệ", f.pattern),
				Direction: f.fix,
				Severity:  0.35,
			})
		}
	}

	// Pattern 3: AI original quá nịnh — phát hiện và cân bằng
	flatterPatterns := []string{
		"rất tuyệt vời", "hoàn toàn đúng", "bạn giỏi lắm",
		"ý kiến xuất sắc", "không có gì để góp ý",
	}
	flatCount := 0
	for _, fp := range flatterPatterns {
		if strings.Contains(strings.ToLower(aiOriginal), fp) {
			flatCount++
		}
	}
	if flatCount >= 2 {
		issues = append(issues, HonestyIssue{
			What:      "response của mình có vẻ quá tích cực",
			Evidence:  "mình dùng nhiều từ khen ngợi — có thể không phản ánh đúng thực tế",
			Direction: "bạn muốn mình phân tích kỹ hơn không?",
			Severity:  0.30,
		})
	}

	return issues
}

// ─── Skill interface (wire vào Agent) ──────────────────────────────────────

func (h *HonestySkill) Name() string { return "HonestySkill" }

// CanHandle: xử lý messages dạng "honesty_check|<user_text>|<ai_response>"
func (h *HonestySkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg == nil { return false }
	p := string(msg.Payload)
	return strings.HasPrefix(p, "honesty_check|") ||
		strings.HasPrefix(p, "verify_response|")
}

// Execute: kiểm tra response có trung thực không
// Input payload: "honesty_check|<user_text>|<original_response>"
func (h *HonestySkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	parts := strings.SplitN(string(msg.Payload), "|", 3)
	if len(parts) < 3 {
		return SkillResult{Data: map[string]any{"honesty": "skip"}}
	}
	userText := parts[1]
	aiOriginal := parts[2]

	issues := DetectIssues(userText, aiOriginal)
	if len(issues) == 0 {
		return SkillResult{Data: map[string]any{"honesty": "ok"}}
	}

	// Build feedback flags cho issues nghiêm trọng
	var flags []string
	for _, iss := range issues {
		if iss.Severity >= 0.3 {
			flags = append(flags, fmt.Sprintf("[⚠ %s → %s]", iss.What, iss.Direction))
		}
	}

	return SkillResult{
		Data: map[string]any{
			"honesty":      "flagged",
			"issues_count": len(issues),
			"flags":        strings.Join(flags, " "),
		},
	}
}
