// internal/agents/skill_watch.go
//
// SKILL: UserInputWatch — LeoAI lắng nghe mọi user input
//
// Nhiệm vụ duy nhất (QT4 — 1 Skill = 1 trách nhiệm):
//   Nhận MsgUserInput → kiểm tra có concept mới không
//   → Có: tạo ĐN node → gửi MsgKnowledge về Bus → AAM
//   → Không: bỏ qua (silent)
//
// LeoAI không trả lời người dùng — đó là việc của AAM.
// LeoAI chỉ học và gửi kiến thức mới cho AAM.
//
// Vòng đời tri thức (QT7):
//   MsgUserInput (ĐN zone) → CanHandle → Execute → học
//   → MsgKnowledge (nếu mới) → AAM xác nhận → QR

package agents

import (
	"log"
	"sync"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/nca"
)

// SkillUserInputWatch — LeoAI luôn lắng nghe, luôn học
type SkillUserInputWatch struct {
	bus        *MessageBus
	seen       map[uint64]bool          // các ISL address đã biết → không học lại
	mu         sync.Mutex
	learnOut   chan<- *isl.ISLMessage   // → bus.LearnOutput()
	activityCh nca.ActivityChan        // poke NxT khi có input mới
}

func NewSkillUserInputWatch(bus *MessageBus, actCh ...nca.ActivityChan) *SkillUserInputWatch {
	s := &SkillUserInputWatch{
		bus:      bus,
		seen:     make(map[uint64]bool),
		learnOut: bus.LearnOutput(),
	}
	if len(actCh) > 0 { s.activityCh = actCh[0] }
	return s
}

func (s *SkillUserInputWatch) Name() string { return "user_input_watch" }

// CanHandle — chỉ xử lý MsgUserInput
func (s *SkillUserInputWatch) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgUserInput
}

// Execute — phân tích input, học nếu có điều mới
func (s *SkillUserInputWatch) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Lấy ISL address từ message
	primary := msg.PrimaryAddr
	if primary.Uint64() == 0 {
		// Chưa encode được ISL → bỏ qua
		return SkillResult{}
	}

	// Kiểm tra đã biết chưa
	s.mu.Lock()
	alreadyKnown := s.seen[primary.Uint64()]
	if !alreadyKnown {
		s.seen[primary.Uint64()] = true
	}
	s.mu.Unlock()

	if alreadyKnown {
		// Đã biết rồi — không cần học lại, silent
		return SkillResult{}
	}

	// Poke NxT activity — reset idle timer
	nca.Poke(s.activityCh)

	// ĐÂY LÀ ĐIỀU MỚI — học vào ĐN zone
	log.Printf("LeoAI[watch]: mới → ISL[%s] confidence=%d%%",
		primary.String(), msg.Confidence)

	// Tạo MsgKnowledge gửi về Bus → AAM
	knowledge := &isl.ISLMessage{
		Version:       1,
		MsgType:       isl.MsgKnowledge,
		PrimaryAddr:   primary,
		SecondaryAddr: msg.SecondaryAddr,  // intent
		ContextAddr:   msg.ContextAddr,    // context
		Confidence:    msg.Confidence,
		Payload:       msg.Payload,        // text gốc để AAM có thể log
	}

	// Gửi vào learnOut → bus.RunKnowledgePipeline() → AAM
	select {
	case s.learnOut <- knowledge:
	default:
		log.Printf("LeoAI[watch]: learnOut full — drop")
	}

	// Ghi vào State để DreamSkill xử lý sau (QT7: ĐN → dream → QR)
	return SkillResult{
		Data: map[string]interface{}{
			"dn_latest_isl":  primary.Uint64(),
			"dn_latest_conf": msg.Confidence,
		},
	}
}

// ─── SkillKnowledgeForward — AAM nhận knowledge từ LeoAI ──────

// SkillKnowledgeForward — AAM xử lý MsgKnowledge từ LeoAI
// Nhiệm vụ: nhận kiến thức mới → forward đến Chief liên quan
type SkillKnowledgeForward struct {
	bus *MessageBus
}

func NewSkillKnowledgeForward(bus *MessageBus) *SkillKnowledgeForward {
	return &SkillKnowledgeForward{bus: bus}
}

func (s *SkillKnowledgeForward) Name() string { return "knowledge_forward" }

func (s *SkillKnowledgeForward) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgKnowledge
}

func (s *SkillKnowledgeForward) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	primary := msg.PrimaryAddr

	log.Printf("AAM[knowledge]: nhận từ LeoAI → ISL[%s] conf=%d%%",
		primary.String(), msg.Confidence)

	// Xác định Chief nào cần biết dựa trên Layer của ISL address
	// Layer byte → domain → Chief tương ứng
	targetChief := chiefForLayer(primary.Layer)

	if targetChief != "" {
		// Forward đến Chief đúng
		forwarded := &isl.ISLMessage{
			Version:       1,
			MsgType:       isl.MsgKnowledge,
			PrimaryAddr:   msg.PrimaryAddr,
			SecondaryAddr: msg.SecondaryAddr,
			ContextAddr:   msg.ContextAddr,
			Confidence:    msg.Confidence,
			Payload:       msg.Payload,
		}
		sent := s.bus.Send(targetChief, forwarded)
		if sent {
			log.Printf("AAM[knowledge]: → %s", targetChief)
		}
	} else {
		// Không xác định được Chief → broadcast đến tất cả Chief
		s.bus.SendToRole(RoleChief, msg)
		log.Printf("AAM[knowledge]: → all chiefs (layer 0x%02x unknown)",
			primary.Layer)
	}

	return SkillResult{
		Data: map[string]interface{}{
			"last_knowledge_layer": primary.Layer,
			"last_knowledge_isl":   primary.Uint64(),
		},
	}
}

// chiefForLayer — ISL Layer byte → Chief ID
// Dựa trên OLANG.md layer definitions
func chiefForLayer(layer byte) string {
	switch layer {
	case 'H': return "home_chief"   // H=Home → HomeChief
	case 'N': return "home_chief"   // N=Nature → HomeChief (environment)
	case 'L': return "home_chief"   // L=Life → HomeChief
	case 'P': return "home_chief"   // P=Perception → HomeChief
	default:  return ""             // unknown → broadcast
	}
}
