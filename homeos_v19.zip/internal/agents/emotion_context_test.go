package agents

import (
	"fmt"
	"testing"
)

func TestSolveEmotion(t *testing.T) {
	t.Log("=== SolveEmotion — cùng Spline, ngữ cảnh khác → cảm xúc khác ===\n")

	// Một câu chuyện buồn: pitch giảm mạnh, energy thấp
	frames := []ProsodyFrame{}
	for i := 0; i < 20; i++ {
		frames = append(frames, ProsodyFrame{
			T: float64(i) * 0.01, Pitch: 200 - float64(i)*7,
			Energy: 0.15, Rate: 2.5,
		})
	}
	sp := ProsodySpline{Frames: frames, Duration: 0.2}
	raw := DetectEmotion(sp)

	t.Logf("RAW (chưa có context): V=%+.2f A=%.2f D=%.2f I=%.2f → %q\n",
		raw.Valence, raw.Arousal, raw.Dominance, raw.Intensity, raw.Label())

	// 4 ngữ cảnh khác nhau cho cùng 1 Spline
	cases := []struct {
		name string
		ctx  EmotionContext
	}{
		{
			"Bạn đang sống nó (vừa xảy ra)",
			EmotionContext{Role: RoleFirstPerson, Source: SourceRealNow, Recency: 1.0},
		},
		{
			"Bạn nhớ lại (đã lâu)",
			EmotionContext{Role: RoleFirstPerson, Source: SourceRealPast, Recency: 0.2},
		},
		{
			"Người khác kể cho bạn nghe",
			EmotionContext{Role: RoleThirdPerson, Source: SourceRealOther, Recency: 0.7},
		},
		{
			"Xem phim (biết là hư cấu)",
			FictionContext,
		},
		{
			"Nghe nhạc buồn",
			MusicContext,
		},
		{
			"Chia sẻ cùng bạn bè (cộng hưởng)",
			EmotionContext{Role: RoleSecondPerson, Source: SourceRealOther, Recency: 0.8, Shared: true},
		},
		{
			"Biết trước sẽ buồn (đã chuẩn bị)",
			EmotionContext{Role: RoleFirstPerson, Source: SourceRealNow, Recency: 1.0, Expected: true},
		},
	}

	t.Log("Ngữ cảnh                              S      Label          V      A      I")
	t.Log("─────────────────────────────────────────────────────────────────────────")
	for _, c := range cases {
		ce := SolveEmotion(sp, c.ctx)
		s  := c.ctx.S()
		t.Logf("%-38s %.2f   %-14s V=%+.2f A=%.2f I=%.2f",
			c.name, s, ce.Final.Label(),
			ce.Final.Valence, ce.Final.Arousal, ce.Final.Intensity)
	}

	t.Log("\n─────────────────────────────────────────────────────────────────────────")
	t.Log("Cùng Spline → cùng RAW → S khác → EmotionTag khác ✓")

	// Verify: FirstPerson/RealNow phải mạnh hơn FictionContext
	ceReal    := SolveEmotion(sp, EmotionContext{Role: RoleFirstPerson, Source: SourceRealNow, Recency: 1.0})
	ceFiction := SolveEmotion(sp, FictionContext)
	if ceReal.Final.Intensity <= ceFiction.Final.Intensity {
		t.Error("FirstPerson/RealNow phải có Intensity > Fiction")
	}
	t.Logf("\nReal(I=%.2f) > Fiction(I=%.2f) ✓", ceReal.Final.Intensity, ceFiction.Final.Intensity)

	// DNA format
	ce := SolveEmotion(sp, DefaultContext)
	t.Logf("DNA: %s", ce.DNA(1741500000))

	// Đa cảm xúc demo
	t.Log("\n─── Đa cảm xúc — 'vừa vui vừa lo' ───")
	mixFrames := []ProsodyFrame{}
	for i := 0; i < 16; i++ {
		// pitch dao động (lo) nhưng tăng nhẹ (vui) — energy trung
		p := 150.0 + float64(i)*3 + 20*float64(i%3-1)
		mixFrames = append(mixFrames, ProsodyFrame{
			T: float64(i)*0.01, Pitch: p, Energy: 0.55, Rate: 4.0,
		})
	}
	mixSp  := ProsodySpline{Frames: mixFrames, Duration: 0.16}
	mixRaw := DetectEmotion(mixSp)
	t.Logf("Đa cảm xúc: V=%+.2f A=%.2f D=%.2f I=%.2f → %q",
		mixRaw.Valence, mixRaw.Arousal, mixRaw.Dominance, mixRaw.Intensity, mixRaw.Label())
	t.Log("  → Valence>0 nhưng Arousal cao → 'vừa vui vừa kích động'")
	t.Log("  → Một điểm trong R⁴, không phải category rời rạc ✓")

	// Summary
	t.Log(fmt.Sprintf("\n✓ SolveEmotion(Spline, Context) — phương trình trong khoảng:"))
	t.Log("  Cùng sự việc, bạn trải qua   → S=1.00 → cảm xúc nguyên vẹn")
	t.Log("  Cùng sự việc, nghe lại       → S=0.33 → cảm xúc giảm 2/3")
	t.Log("  Xem phim                     → S=0.05 → xúc động nhẹ (aesthetic)")
	t.Log("  Nghe nhạc                    → S=0.04 → cảm nhận nghệ thuật")
}
