package agents

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestFirmwareAgent(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  FIRMWARE AGENT — tự đọc, kiểm tra, vá, cấu hình            ║")
	t.Log("║  Agent = clone(olang) + 4 Firmware Skills                   ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── Tạo Agent với 4 Firmware Skills ──────────────────────
	// Trong thực tế: Chief tạo agent này khi onboard thiết bị mới
	// Sau khi CapabilityMapSkill chạy xong → Chief gắn thêm Skill đúng loại

	ctx := &ExecContext{State: make(map[string]interface{})}

	reader  := NewFirmwareReaderSkill()
	auditor := NewSecurityAuditSkill()
	patcher := NewFirmwarePatchSkill()
	mapper  := NewCapabilityMapSkill()

	activateMsg := &isl.ISLMessage{
		MsgType: isl.MsgActivate,
		Payload: encodePayload(map[string]string{
			"ip":   "192.168.1.105",
			"auth": "hue-bridge-token",
		}),
	}

	// ── Step 1: Đọc firmware ──────────────────────────────────
	t.Log("[ STEP 1 ] FirmwareReaderSkill — parse API của Philips Hue")
	r1 := reader.Execute(ctx, activateMsg)
	t.Logf("  %s", r1.Data["firmware.summary"])
	t.Logf("  Endpoints: %d", r1.Data["firmware.endpoints"])

	info := ctx.State["firmware.info"].(FirmwareInfo)
	for _, ep := range info.Endpoints {
		t.Logf("    %-8s %-40s → %s (%s)",
			ep.Method, ep.Path, ep.Capability, ep.DataType)
	}
	t.Log()

	// ── Step 2: Kiểm tra bảo mật ─────────────────────────────
	t.Log("[ STEP 2 ] SecurityAuditSkill — quét lỗ hổng")
	r2 := auditor.Execute(ctx, activateMsg)
	t.Logf("  Findings: %d  |  Critical/High: %d  |  Safe: %v",
		r2.Data["security.findings"],
		r2.Data["security.critical"],
		r2.Data["security.safe"])

	findings := ctx.State["security.findings"].([]SecurityFinding)
	for _, f := range findings {
		fixable := "không vá được"
		if f.Fixable { fixable = "→ " + f.FixAction }
		t.Logf("  [%-8s] %s %s", f.Severity, f.Description, fixable)
	}
	t.Log()

	// ── Step 3: Vá lỗi ───────────────────────────────────────
	t.Log("[ STEP 3 ] FirmwarePatchSkill — áp dụng fix")
	syncMsg := &isl.ISLMessage{MsgType: isl.MsgSync, Payload: []byte{}}
	r3 := patcher.Execute(ctx, syncMsg)
	t.Logf("  Applied: %d  |  Failed: %d  |  Total history: %d",
		r3.Data["patch.applied"],
		r3.Data["patch.failed"],
		r3.Data["patch.total"])

	if patches, ok := ctx.State["patch.history"].([]FirmwarePatch); ok {
		for _, p := range patches {
			t.Logf("  ✓ [%s] %s: %s → %s  (reason: %s)",
				p.Type, p.Target, p.OldValue, p.NewValue, p.Reason)
		}
	}
	t.Log()

	// ── Step 4: Map capabilities → đề xuất Skills ────────────
	t.Log("[ STEP 4 ] CapabilityMapSkill — tự biết cần những Skill nào")
	r4 := mapper.Execute(ctx, activateMsg)
	t.Logf("  Device type: %s", func() string {
		var m map[string]interface{}
		decodePayload(r4.Message.Payload, &m)
		if dt, ok := m["device_type"].(string); ok { return dt }
		return "?"
	}())
	t.Logf("  Skills cần gắn: %v", ctx.State["capabilities.skills"])
	t.Log()
	t.Log("  → Chief nhận MsgPropose → gắn thêm Skill vào Agent")
	t.Log("  → Agent giờ có thể điều khiển đèn đầy đủ")
	t.Log()

	// ── Xiaomi scenario ───────────────────────────────────────
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("[ XIAOMI SCENARIO ] Bóng đèn Xiaomi — protocol khác")

	ctx2 := &ExecContext{State: make(map[string]interface{})}
	msg2 := &isl.ISLMessage{
		MsgType: isl.MsgActivate,
		Payload: encodePayload(map[string]string{
			"ip":   "192.168.1.120",
			"auth": "xiaomi-local-token",
		}),
	}

	r2_1 := reader.Execute(ctx2, msg2)
	t.Logf("  Firmware: %s", r2_1.Data["firmware.summary"])

	auditor.Execute(ctx2, msg2)
	findings2 := ctx2.State["security.findings"].([]SecurityFinding)
	for _, f := range findings2 {
		t.Logf("  [%-8s] %s", f.Severity, f.Description)
	}

	mapper.Execute(ctx2, msg2)
	t.Logf("  Skills cần: %v", ctx2.State["capabilities.skills"])
	t.Log()

	// ── Rollback test ─────────────────────────────────────────
	t.Log("[ ROLLBACK ] Patch làm lỗi → rollback")
	rollback := patcher.Rollback("firmware_version")
	if rollback != nil {
		t.Logf("  Rollback: %s → %s", rollback.OldValue, rollback.NewValue)
		t.Log("  ✓ Thiết bị khôi phục về trạng thái cũ")
	} else {
		t.Log("  (không có patch firmware_version để rollback)")
	}
	t.Log()

	t.Log("[ TỔNG KẾT — QT4 ]")
	t.Log("  FirmwareReaderSkill  = 1 trách nhiệm: đọc + parse")
	t.Log("  SecurityAuditSkill   = 1 trách nhiệm: kiểm tra CVE")
	t.Log("  FirmwarePatchSkill   = 1 trách nhiệm: vá + rollback")
	t.Log("  CapabilityMapSkill   = 1 trách nhiệm: endpoint → Skill")
	t.Log()
	t.Log("  Kết quả: Agent tự hiểu bất kỳ thiết bị nào")
	t.Log("  Không cần code riêng cho từng hãng")
	t.Log("  Gắn 4 Skill này → Agent universal device agent")
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

	// Assertions
	if r1.Data["firmware.endpoints"].(int) == 0 {
		t.Error("✗ Không parse được endpoints")
	}
	skills := ctx.State["capabilities.skills"].([]string)
	found := false
	for _, s := range skills {
		if s == "actuator_light" { found = true; break }
	}
	if !found {
		t.Errorf("✗ Không nhận ra actuator_light: %v", skills)
	}
}
