// DataLeakDetectSkill — phát hiện data đang rò rỉ ra ngoài
// Kết hợp NetworkMonitor + ProcessWatch để tìm pattern nguy hiểm
// Anchor: SYS_SECURITY (🛡 U+1F6E1)
package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

type LeakEvent struct {
	At          time.Time
	ProcessName string
	PID         int
	RemoteAddr  string
	DataType    string // "credential", "keylog", "bulk_upload", "dns_tunnel"
	Confidence  string // "low" | "medium" | "high"
	Evidence    string
}

type DataLeakDetectSkill struct {
	events []LeakEvent
}

func NewDataLeakDetectSkill() *DataLeakDetectSkill {
	return &DataLeakDetectSkill{}
}

func (s *DataLeakDetectSkill) Name() string { return "data_leak_detect" }

func (s *DataLeakDetectSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgSync
}

func (s *DataLeakDetectSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Đọc snapshot từ skills trước đã chạy
	netSnap, hasNet := ctx.State["network.snapshot"].(*NetworkSnapshot)
	procSnap, hasProc := ctx.State["processes.snapshot"].(*ProcessSnapshot)

	if !hasNet || !hasProc {
		return SkillResult{Data: map[string]interface{}{
			"leak.status": "waiting_for_data",
		}}
	}

	events := s.analyze(netSnap, procSnap)
	s.events = append(s.events, events...)

	high := 0
	for _, e := range events {
		if e.Confidence == "high" {
			high++
		}
	}

	ctx.State["leak.events"]     = events
	ctx.State["leak.total"]      = len(events)
	ctx.State["leak.high"]       = high

	var notifyMsg *isl.ISLMessage
	if high > 0 {
		alert := s.buildAlert(events)
		notifyMsg = &isl.ISLMessage{
			MsgType: isl.MsgKnowledge,
			Payload: []byte(alert),
		}
	}

	return SkillResult{
		Data: map[string]interface{}{
			"leak.total": len(events),
			"leak.high":  high,
		},
		Message: notifyMsg,
	}
}

func (s *DataLeakDetectSkill) analyze(net *NetworkSnapshot, proc *ProcessSnapshot) []LeakEvent {
	var events []LeakEvent

	// Cross-reference: process suspicious + có network connection
	suspMap := map[string]ProcessInfo{}
	for _, p := range proc.Suspicious {
		suspMap[p.Name] = p
	}

	for _, conn := range net.Conns {
		if conn.State != "ESTABLISHED" {
			continue
		}
		// Process suspicious đang có kết nối external
		if p, ok := suspMap[conn.ProcessName]; ok {
			events = append(events, LeakEvent{
				At:          time.Now(),
				ProcessName: p.Name,
				PID:         p.PID,
				RemoteAddr:  conn.RemoteAddr,
				DataType:    "suspicious_exfil",
				Confidence:  "high",
				Evidence:    fmt.Sprintf("suspicious process '%s' connected to %s", p.Name, conn.RemoteAddr),
			})
		}
	}

	// DNS tunneling: quá nhiều DNS queries (port 53)
	dns53 := 0
	for _, conn := range net.Conns {
		if strings.HasSuffix(conn.RemoteAddr, ":53") {
			dns53++
		}
	}
	if dns53 > 20 {
		events = append(events, LeakEvent{
			At:         time.Now(),
			DataType:   "dns_tunnel",
			Confidence: "medium",
			Evidence:   fmt.Sprintf("%d concurrent DNS connections — possible tunnel", dns53),
		})
	}

	// Bulk upload: nhiều kết nối cùng remote IP
	remoteCount := map[string]int{}
	for _, conn := range net.Conns {
		if conn.State == "ESTABLISHED" {
			remoteCount[conn.RemoteAddr]++
		}
	}
	for addr, cnt := range remoteCount {
		if cnt > 5 {
			events = append(events, LeakEvent{
				At:         time.Now(),
				RemoteAddr: addr,
				DataType:   "bulk_upload",
				Confidence: "low",
				Evidence:   fmt.Sprintf("%d connections to %s", cnt, addr),
			})
		}
	}

	return events
}

func (s *DataLeakDetectSkill) buildAlert(events []LeakEvent) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("🛡 DataLeakDetect: %d events\n", len(events)))
	for _, e := range events {
		sb.WriteString(fmt.Sprintf("  [%s/%s] %s — %s\n",
			e.Confidence, e.DataType, e.ProcessName, e.Evidence))
	}
	return sb.String()
}
