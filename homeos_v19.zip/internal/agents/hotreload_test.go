package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestHotReloadISLRouter(t *testing.T) {
	ws  := gene.NewWorldScene()
	bus := NewMessageBus()
	dn  := memory.NewShortTerm(256)
	lt  := memory.NewLongTerm(silk.NewSilkGraph(), nil)

	nodes0  := ws.SpatialNodes()
	router  := gene.NewISLRouter(nodes0, 8.0)
	addrMap := NewAddrAgentMap()

	vc := NewVisionChief("vc_hot", 512)
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun),   vc.ID)

	disp := NewSpatialDispatcher(router, addrMap, bus)
	pl   := NewPerceptLayer(ws, disp)
	pl.AddSensor(SensorPoint{ID: "s1", Pos: gene.Vec3{X: 0, Y: 5, Z: 0}, Radius: 3, NSamples: 6})

	learnSkill := NewSpatialLearnSkill(dn, lt)
	leoInbox   := make(chan *isl.ISLMessage, 256)
	bus.Register("leoai", leoInbox, 2, RoleChief)

	stop := make(chan struct{})
	go vc.Run(stop)
	go func() {
		for {
			select {
			case <-stop: return
			case msg := <-leoInbox: learnSkill.Execute(nil, msg)
			}
		}
	}()
	defer close(stop)

	// Phase 1: trước hot-reload
	nInit := len(ws.SpatialNodes())
	t.Logf("Phase 1: %d nodes ban đầu", nInit)
	r0 := pl.Tick(0.1)
	t.Logf("  Tick 1: %d msgs", r0.TotalMsgs)

	// Phase 2: AddCreature → HotReload
	t.Log("\nPhase 2: AddCreature(dog) → HotReload")
	dog := gene.NewCreatureGene(gene.SpeciesDog)
	ws.AddCreature(dog)
	addrMap.Register(uint64(dog.Addr), vc.ID)

	nBefore := len(router.Nodes)
	nAfter  := pl.HotReload()
	t.Logf("  Nodes: %d → %d", nBefore, nAfter)
	if nAfter != nBefore+1 {
		t.Errorf("phải tăng 1: got %d want %d", nAfter, nBefore+1)
	}
	if nAfter != len(ws.SpatialNodes()) {
		t.Errorf("mismatch WorldScene: got %d want %d", nAfter, len(ws.SpatialNodes()))
	}

	r1 := pl.Tick(0.1)
	t.Logf("  Tick sau add: %d msgs", r1.TotalMsgs)

	// Phase 3: AddCreature × 3 → HotReload
	t.Log("\nPhase 3: AddCreature × 3 → HotReload")
	for i := 0; i < 3; i++ {
		c := gene.NewCreatureGene(gene.SpeciesDog)
		ws.AddCreature(c)
		addrMap.Register(uint64(c.Addr), vc.ID)
	}
	n3 := pl.HotReload()
	t.Logf("  Nodes sau 3 thêm: %d", n3)
	if n3 != nAfter+3 {
		t.Errorf("phải là %d got %d", nAfter+3, n3)
	}
	r2 := pl.Tick(0.1)
	t.Logf("  Tick: %d msgs", r2.TotalMsgs)

	// Phase 4: RemoveCreature → HotReload
	t.Log("\nPhase 4: RemoveCreature(dog) → HotReload")
	removed := ws.RemoveCreature(uint64(dog.Addr))
	if !removed { t.Error("RemoveCreature phải thành công") }
	n4 := pl.HotReload()
	t.Logf("  Nodes sau remove: %d (giảm 1 từ %d)", n4, n3)
	if n4 != n3-1 {
		t.Errorf("phải giảm 1: got %d want %d", n4, n3-1)
	}

	time.Sleep(20 * time.Millisecond)

	ticks, sensors := pl.Stats()
	t.Logf("\n── Stats ──")
	t.Logf("  PerceptLayer: %d ticks, %d sensors", ticks, sensors)
	t.Logf("  WorldScene creatures: %d", ws.CreatureCount())
	t.Logf("  ISLRouter.Nodes: %d", len(router.Nodes))
	t.Logf("  ShortTerm(ĐN): %d active", dn.CountActive())

	t.Log("\n✓ Hot-reload ISLRouter:")
	t.Log("  AddCreature → HotReload → tăng ngay ✓")
	t.Log("  RemoveCreature → HotReload → giảm ngay ✓")
	t.Log("  Không restart PerceptLayer ✓")
}
