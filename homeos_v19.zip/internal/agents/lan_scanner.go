// internal/agents/lan_scanner.go
// RealLANScanner — ARP sweep + mDNS discovery → DiscoveredDevice[]
//
// Pipeline:
//   1. ARPSweep: ping /24 subnet → populate kernel ARP cache
//   2. ReadARPTable: đọc /proc/net/arp → (IP, MAC) pairs
//   3. MDNSQuery: multicast DNS-SD → service type + hostname
//   4. Classify: MAC vendor prefix → DeviceType + Vendor
//   5. Merge: ARP + mDNS → DiscoveredDevice[]
//
// Quy tắc (QT2 ∞-1):
//   - Timeout mỗi host: 50ms (không block)
//   - Max scan: /24 = 254 hosts
//   - mDNS listen: 1 giây
//   - Không panic khi không có quyền raw socket

package agents

import (
	"bufio"
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
)

// ─── RealLANScanner ────────────────────────────────────────────

// RealLANScanner implement LANScanner interface
type RealLANScanner struct {
	Timeout    time.Duration // per-host timeout (default 50ms)
	MaxHosts   int           // max hosts to ping (default 254)
	MDNSWait   time.Duration // mDNS listen window (default 1s)
	Iface      string        // network interface (empty = auto)
}

func NewRealLANScanner() *RealLANScanner {
	return &RealLANScanner{
		Timeout:  50 * time.Millisecond,
		MaxHosts: 254,
		MDNSWait: time.Second,
	}
}

// Scan implements LANScanner
func (s *RealLANScanner) Scan() []DiscoveredDevice {
	// 1. Lấy subnet từ interface
	subnet := s.detectSubnet()
	if subnet == nil {
		return nil
	}

	// 2. Ping sweep → populate ARP cache
	s.arpSweep(subnet)

	// 3. Đọc ARP table
	arpEntries := readARPTable()

	// 4. mDNS discovery (chạy song song với ARP)
	mdnsMap := s.mdnsDiscover()

	// 5. Merge → DiscoveredDevice
	return s.buildDevices(arpEntries, mdnsMap)
}

// ─── ARP ───────────────────────────────────────────────────────

type arpEntry struct {
	IP  string
	MAC string
}

// arpSweep gửi TCP SYN đến port 80/443/8080 của từng host
// → kernel tự động gửi ARP → populate /proc/net/arp
func (s *RealLANScanner) arpSweep(subnet *net.IPNet) {
	base := subnet.IP.Mask(subnet.Mask)
	ones, bits := subnet.Mask.Size()
	size := 1 << (bits - ones)
	if size > s.MaxHosts+2 { size = s.MaxHosts + 2 }

	var wg sync.WaitGroup
	sem := make(chan struct{}, 50) // 50 concurrent

	for i := 1; i < size-1; i++ {
		ip := incrementIP(base, i)
		if ip == nil { continue }
		ipStr := ip.String()

		wg.Add(1)
		sem <- struct{}{}
		go func(addr string) {
			defer wg.Done()
			defer func() { <-sem }()
			// Thử TCP connect nhanh — không cần thành công
			// Chỉ cần gửi packet để kernel ARP
			for _, port := range []string{":80", ":443", ":8080", ":22"} {
				conn, err := net.DialTimeout("tcp", addr+port, s.Timeout)
				if err == nil {
					conn.Close()
					return
				}
				// "connection refused" vẫn ok — nghĩa là host alive
				if isConnRefused(err) { return }
			}
			// ICMP ping fallback — dùng UDP unreachable trick
			udpConn, err := net.DialTimeout("udp", addr+":53", s.Timeout)
			if err == nil { udpConn.Close() }
		}(ipStr)
	}
	wg.Wait()
}

// readARPTable đọc /proc/net/arp
func readARPTable() []arpEntry {
	f, err := os.Open("/proc/net/arp")
	if err != nil { return nil }
	defer f.Close()

	var entries []arpEntry
	scanner := bufio.NewScanner(f)
	scanner.Scan() // skip header line
	for scanner.Scan() {
		fields := strings.Fields(scanner.Text())
		if len(fields) < 4 { continue }
		ip    := fields[0]
		flags := fields[2]
		mac   := fields[3]
		// 0x2 = ATF_COM (completed, reachable)
		if flags == "0x2" && mac != "00:00:00:00:00:00" {
			entries = append(entries, arpEntry{IP: ip, MAC: mac})
		}
	}
	return entries
}

// ─── mDNS ──────────────────────────────────────────────────────

type mdnsRecord struct {
	IP          string
	Hostname    string
	ServiceType string // "_hap._tcp", "_googlecast._tcp", ...
}

// mdnsDiscover gửi DNS-SD query và listen 1 giây
func (s *RealLANScanner) mdnsDiscover() map[string]*mdnsRecord {
	result := make(map[string]*mdnsRecord)
	mu := sync.Mutex{}

	ctx, cancel := context.WithTimeout(context.Background(), s.MDNSWait)
	defer cancel()

	// Listen trên mDNS multicast
	conn, err := net.ListenMulticastUDP("udp4", nil,
		&net.UDPAddr{IP: net.ParseIP("224.0.0.251"), Port: 5353})
	if err != nil {
		// Không có quyền → skip mDNS, chỉ dùng ARP
		return result
	}
	defer conn.Close()

	// Gửi DNS-SD query cho các service types phổ biến
	queryConn, err := net.ListenPacket("udp4", "0.0.0.0:0")
	if err == nil {
		defer queryConn.Close()
		mDNSAddr := &net.UDPAddr{IP: net.ParseIP("224.0.0.251"), Port: 5353}
		for _, svc := range mdnsServices {
			pkt := buildMDNSQuery(svc)
			queryConn.WriteTo(pkt, mDNSAddr)
		}
	}

	// Đọc responses
	buf := make([]byte, 4096)
	go func() {
		for {
			select {
			case <-ctx.Done():
				return
			default:
				conn.SetReadDeadline(time.Now().Add(100 * time.Millisecond))
				n, addr, err := conn.ReadFrom(buf)
				if err != nil { continue }
				if n < 12 { continue }

				rec := parseMDNSResponse(buf[:n], addr)
				if rec == nil { continue }

				mu.Lock()
				if existing, ok := result[rec.IP]; ok {
					// Merge
					if rec.Hostname != "" { existing.Hostname = rec.Hostname }
					if rec.ServiceType != "" { existing.ServiceType = rec.ServiceType }
				} else {
					result[rec.IP] = rec
				}
				mu.Unlock()
			}
		}
	}()

	<-ctx.Done()
	return result
}

// mdnsServices — service types cần discover
var mdnsServices = []string{
	"_hap._tcp.local.",        // HomeKit
	"_http._tcp.local.",       // generic HTTP devices
	"_googlecast._tcp.local.", // Chromecast / Google Home
	"_airplay._tcp.local.",    // Apple TV / AirPlay
	"_ipp._tcp.local.",        // printers
	"_ssh._tcp.local.",        // SSH servers
	"_services._dns-sd._udp.local.", // service discovery
}

// buildMDNSQuery tạo DNS query packet tối giản
// Format: header(12B) + question
func buildMDNSQuery(name string) []byte {
	buf := make([]byte, 0, 64)

	// Header: ID=0, QR=0 (query), QDCOUNT=1
	buf = append(buf, 0x00, 0x00) // ID
	buf = append(buf, 0x00, 0x00) // Flags: standard query
	buf = append(buf, 0x00, 0x01) // QDCOUNT=1
	buf = append(buf, 0x00, 0x00) // ANCOUNT=0
	buf = append(buf, 0x00, 0x00) // NSCOUNT=0
	buf = append(buf, 0x00, 0x00) // ARCOUNT=0

	// Question: name
	for _, label := range strings.Split(strings.TrimSuffix(name, "."), ".") {
		buf = append(buf, byte(len(label)))
		buf = append(buf, []byte(label)...)
	}
	buf = append(buf, 0x00)       // root label
	buf = append(buf, 0x00, 0x0C) // QTYPE=PTR
	buf = append(buf, 0x00, 0x01) // QCLASS=IN (unicast bit clear)
	return buf
}

// parseMDNSResponse parse tối giản — lấy hostname + service type
func parseMDNSResponse(data []byte, addr net.Addr) *mdnsRecord {
	if len(data) < 12 { return nil }

	// Lấy IP từ addr
	ip := ""
	if udpAddr, ok := addr.(*net.UDPAddr); ok {
		ip = udpAddr.IP.String()
		// Bỏ qua địa chỉ link-local của chính mình
		if ip == "127.0.0.1" { return nil }
	}
	if ip == "" { return nil }

	// Parse DNS response headers
	flags := binary.BigEndian.Uint16(data[2:4])
	if flags&0x8000 == 0 { return nil } // bỏ queries, chỉ lấy responses
	ancount := int(binary.BigEndian.Uint16(data[6:8]))
	if ancount == 0 { return nil }

	// Parse answer section để lấy hostname/service
	rec := &mdnsRecord{IP: ip}
	pos := 12
	// Skip questions
	qdcount := int(binary.BigEndian.Uint16(data[4:6]))
	for i := 0; i < qdcount && pos < len(data); i++ {
		pos = skipDNSName(data, pos)
		pos += 4 // QTYPE + QCLASS
	}
	// Parse first answer
	for i := 0; i < ancount && pos < len(data); i++ {
		nameStr, newPos := readDNSName(data, pos)
		if newPos+10 > len(data) { break }
		rtype  := binary.BigEndian.Uint16(data[newPos : newPos+2])
		rdlen  := int(binary.BigEndian.Uint16(data[newPos+8 : newPos+10]))
		rdPos  := newPos + 10
		if rdPos+rdlen > len(data) { break }

		switch rtype {
		case 0x000C: // PTR — service instance
			ptrName, _ := readDNSName(data, rdPos)
			// ptrName = "instance._service._tcp.local"
			if strings.Contains(ptrName, "._tcp.") || strings.Contains(ptrName, "._udp.") {
				// Lấy service type
				parts := strings.SplitN(ptrName, ".", 2)
				if len(parts) == 2 {
					rec.ServiceType = "_" + strings.TrimPrefix(parts[1], "_")
				}
			}
		case 0x0021: // SRV — hostname
			if rdPos+6 <= rdPos+rdlen {
				hostname, _ := readDNSName(data, rdPos+6)
				if hostname != "" { rec.Hostname = hostname }
			}
		case 0x0001: // A record — không cần, đã có IP từ UDP src
			_ = nameStr
		}
		pos = rdPos + rdlen
	}

	return rec
}

// ─── Device Classification ─────────────────────────────────────

// macVendors — MAC OUI prefix → (vendor, device type)
// Danh sách phổ biến, không đầy đủ
var macVendors = []struct {
	prefix     string
	vendor     string
	deviceType string
}{
	// Philips Hue
	{"00:17:88", "Philips", "smart_light"},
	{"ec:b5:fa", "Philips", "smart_light"},
	// Xiaomi
	{"64:09:80", "Xiaomi", "smart_light"},
	{"28:6c:07", "Xiaomi", "hvac"},
	{"f4:f0:6d", "Xiaomi", "sensor"},
	// TP-Link / Kasa
	{"50:c7:bf", "TP-Link", "smart_plug"},
	{"b0:95:75", "TP-Link", "smart_plug"},
	// Sonos
	{"00:0e:58", "Sonos", "speaker"},
	{"94:9f:3e", "Sonos", "speaker"},
	// Google
	{"f4:f5:d8", "Google", "smart_speaker"},
	{"48:d6:d5", "Google", "smart_speaker"},
	// Amazon
	{"f0:81:73", "Amazon", "smart_speaker"},
	{"44:65:0d", "Amazon", "smart_speaker"},
	// Apple
	{"a8:66:7f", "Apple", "appliance"},
	{"3c:22:fb", "Apple", "appliance"},
	// Samsung SmartThings
	{"00:12:fb", "Samsung", "sensor"},
	{"b4:7c:9c", "Samsung", "appliance"},
	// Generic cameras
	{"d4:81:d7", "Hikvision", "camera"},
	{"c0:56:e3", "Dahua", "camera"},
	// Raspberry Pi
	{"b8:27:eb", "RaspberryPi", "controller"},
	{"dc:a6:32", "RaspberryPi", "controller"},
	{"e4:5f:01", "RaspberryPi", "controller"},
}

// classifyDevice lấy DeviceType + Vendor từ MAC hoặc mDNS service type
func classifyDevice(mac, serviceType string) (vendor, deviceType string) {
	// Thử mDNS service type trước
	switch {
	case strings.Contains(serviceType, "_hap"):
		deviceType = "smart_light" // HomeKit device
	case strings.Contains(serviceType, "_googlecast"):
		vendor, deviceType = "Google", "smart_speaker"
	case strings.Contains(serviceType, "_airplay"):
		vendor, deviceType = "Apple", "appliance"
	case strings.Contains(serviceType, "_ipp"):
		deviceType = "printer"
	}

	// Fallback: MAC vendor lookup
	macNorm := strings.ToLower(mac)
	for _, v := range macVendors {
		if strings.HasPrefix(macNorm, v.prefix) {
			if vendor == "" { vendor = v.vendor }
			if deviceType == "" { deviceType = v.deviceType }
			return
		}
	}

	// Default
	if vendor == ""     { vendor = "Unknown" }
	if deviceType == "" { deviceType = "smart_device" }
	return
}

// ─── Merge ─────────────────────────────────────────────────────

func (s *RealLANScanner) buildDevices(arpEntries []arpEntry, mdnsMap map[string]*mdnsRecord) []DiscoveredDevice {
	var devices []DiscoveredDevice

	for _, arp := range arpEntries {
		mdns := mdnsMap[arp.IP]

		serviceType := ""
		if mdns != nil { serviceType = mdns.ServiceType }

		vendor, deviceType := classifyDevice(arp.MAC, serviceType)

		dev := DiscoveredDevice{
			IP:           arp.IP,
			MAC:          arp.MAC,
			DeviceType:   deviceType,
			Vendor:       vendor,
			Location:     gene.SpaceLivingRoom, // default — user bổ sung sau
			DiscoveredAt: time.Now(),
			NeedsAuth:    deviceType == "camera" || deviceType == "lock",
		}

		// Thêm hostname từ mDNS
		if mdns != nil && mdns.Hostname != "" {
			// hostname là extra, không replace IP
		}

		devices = append(devices, dev)
	}

	// Thêm devices phát hiện qua mDNS nhưng không có trong ARP
	for ip, mdns := range mdnsMap {
		found := false
		for _, d := range devices {
			if d.IP == ip { found = true; break }
		}
		if !found {
			vendor, deviceType := classifyDevice("", mdns.ServiceType)
			devices = append(devices, DiscoveredDevice{
				IP:           ip,
				MAC:          "", // không biết
				DeviceType:   deviceType,
				Vendor:       vendor,
				Location:     gene.SpaceLivingRoom,
				DiscoveredAt: time.Now(),
			})
		}
	}

	return devices
}

// ─── Helpers ───────────────────────────────────────────────────

// detectSubnet lấy subnet đầu tiên không phải loopback
func (s *RealLANScanner) detectSubnet() *net.IPNet {
	ifaces, err := net.Interfaces()
	if err != nil { return nil }

	for _, iface := range ifaces {
		if iface.Flags&net.FlagLoopback != 0 { continue }
		if iface.Flags&net.FlagUp == 0 { continue }
		if s.Iface != "" && iface.Name != s.Iface { continue }

		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			if ipnet, ok := addr.(*net.IPNet); ok {
				if ipnet.IP.To4() != nil {
					return ipnet
				}
			}
		}
	}
	return nil
}

// incrementIP tăng IP lên n
func incrementIP(base net.IP, n int) net.IP {
	ip := make(net.IP, len(base))
	copy(ip, base)
	// Tăng từ byte cuối
	val := binary.BigEndian.Uint32(ip.To4()) + uint32(n)
	result := make(net.IP, 4)
	binary.BigEndian.PutUint32(result, val)
	return result
}

// isConnRefused kiểm tra lỗi "connection refused" — host alive
func isConnRefused(err error) bool {
	return err != nil && strings.Contains(err.Error(), "connection refused")
}

// skipDNSName bỏ qua DNS name trong packet, trả về vị trí sau name
func skipDNSName(data []byte, pos int) int {
	for pos < len(data) {
		length := int(data[pos])
		if length == 0 { return pos + 1 }
		if length&0xC0 == 0xC0 { return pos + 2 } // pointer
		pos += 1 + length
	}
	return pos
}

// readDNSName đọc DNS name (hỗ trợ compression pointer)
func readDNSName(data []byte, pos int) (string, int) {
	var parts []string
	origPos := -1
	for pos < len(data) {
		length := int(data[pos])
		if length == 0 { pos++; break }
		if length&0xC0 == 0xC0 {
			// Compression pointer
			if pos+1 >= len(data) { break }
			if origPos < 0 { origPos = pos + 2 }
			pos = int(binary.BigEndian.Uint16(data[pos:pos+2]) & 0x3FFF)
			continue
		}
		pos++
		if pos+length > len(data) { break }
		parts = append(parts, string(data[pos:pos+length]))
		pos += length
	}
	if origPos > 0 { pos = origPos }
	return strings.Join(parts, "."), pos
}

// ─── Mock Scanner (dùng cho test) ─────────────────────────────

// MockLANScanner trả về danh sách thiết bị giả lập
type MockLANScanner struct {
	Devices []DiscoveredDevice
}

func NewMockLANScanner(devices ...DiscoveredDevice) *MockLANScanner {
	return &MockLANScanner{Devices: devices}
}

func (m *MockLANScanner) Scan() []DiscoveredDevice {
	return m.Devices
}

// DefaultMockDevices — thiết bị mẫu để demo
func DefaultMockDevices() []DiscoveredDevice {
	return []DiscoveredDevice{
		{
			IP: "192.168.1.100", MAC: "00:17:88:aa:bb:cc",
			DeviceType: "smart_light", Vendor: "Philips",
			Location: gene.SpaceLivingRoom, DiscoveredAt: time.Now(),
		},
		{
			IP: "192.168.1.101", MAC: "64:09:80:11:22:33",
			DeviceType: "smart_light", Vendor: "Xiaomi",
			Location: gene.SpaceBedroom, DiscoveredAt: time.Now(),
		},
		{
			IP: "192.168.1.102", MAC: "f4:f5:d8:44:55:66",
			DeviceType: "smart_speaker", Vendor: "Google",
			Location: gene.SpaceLivingRoom, DiscoveredAt: time.Now(),
		},
	}
}

// Summary tóm tắt kết quả scan
func ScanSummary(devices []DiscoveredDevice) string {
	if len(devices) == 0 {
		return "Không tìm thấy thiết bị nào trên mạng LAN."
	}
	counts := map[string]int{}
	for _, d := range devices {
		counts[d.DeviceType]++
	}
	var parts []string
	for t, n := range counts {
		parts = append(parts, fmt.Sprintf("%d %s", n, t))
	}
	return fmt.Sprintf("Phát hiện %d thiết bị: %s", len(devices), strings.Join(parts, ", "))
}
