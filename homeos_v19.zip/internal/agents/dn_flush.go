// internal/agents/dn_flush.go
// DNFlusher — VisionChief.Dominant() → ĐN flush → KnowledgeProposal
//
// QT7: "ĐN (pattern lặp lại) → QR (ComposedSkill bất biến)"
// Áp dụng cho spatial perception:
//   Khi dominant ISLAddr xuất hiện ≥ FlushThreshold lần liên tiếp
//   → pattern đã ổn định → tạo KnowledgeProposal
//   → gửi lên LeoAI qua Bus (MsgKnowledge)
//   → LeoAI đánh giá → QR (longterm memory)
//
// ĐN = Dendrites = shortterm = chưa chắc
// QR = Axon     = longterm  = đã chứng minh

package agents

import (
	"fmt"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// KnowledgeProposal — đề xuất tri thức mới từ pattern quan sát
type KnowledgeProposal struct {
	// Địa chỉ ISL của khái niệm được quan sát
	Addr       uint64
	// Số lần quan sát xác nhận pattern này
	Evidence   int
	// Tỉ lệ inside/total (0.0-1.0)
	InsideRatio float64
	// Thời điểm tạo
	CreatedAt  time.Time
	// Source agent
	SourceID   string
	// Human readable summary
	Summary    string
}

// DNFlusher theo dõi VisionChief và flush khi đủ evidence
type DNFlusher struct {
	Chief          *VisionChief
	Bus            *MessageBus
	LeoAIID        string   // agent ID của LeoAI trên Bus

	// Ngưỡng flush: dominant phải xuất hiện ≥ FlushThreshold lần
	FlushThreshold int
	// Khoảng thời gian check (giây)
	CheckInterval  float64

	// State nội bộ
	lastFlushAddr  uint64
	lastFlushCount int
	totalFlushes   int
	proposals      []KnowledgeProposal
}

// NewDNFlusher tạo flusher
func NewDNFlusher(chief *VisionChief, bus *MessageBus, leoAIID string) *DNFlusher {
	return &DNFlusher{
		Chief:          chief,
		Bus:            bus,
		LeoAIID:        leoAIID,
		FlushThreshold: 10, // 10 observations liên tiếp
		CheckInterval:  1.0,
	}
}

// CheckAndFlush kiểm tra VisionChief và flush nếu đủ điều kiện
// Trả về proposal nếu flush, nil nếu chưa đủ điều kiện
func (f *DNFlusher) CheckAndFlush() *KnowledgeProposal {
	dom, cnt := f.Chief.Dominant()
	if cnt < f.FlushThreshold {
		return nil // chưa đủ evidence
	}

	// Tránh flush cùng 1 addr liên tiếp quá nhiều
	// (chỉ flush khi count tăng đáng kể)
	if dom == f.lastFlushAddr && cnt < f.lastFlushCount+f.FlushThreshold {
		return nil
	}

	// Tính InsideRatio
	insideCnt := f.Chief.InsideCount(dom)
	total     := cnt
	ratio     := 0.0
	if total > 0 { ratio = float64(insideCnt) / float64(total) }

	proposal := &KnowledgeProposal{
		Addr:        dom,
		Evidence:    cnt,
		InsideRatio: ratio,
		CreatedAt:   time.Now(),
		SourceID:    f.Chief.ID,
		Summary:     f.buildSummary(dom, cnt, ratio),
	}

	// Gửi lên LeoAI qua Bus
	f.sendToLeoAI(proposal)

	// Update state
	f.lastFlushAddr  = dom
	f.lastFlushCount = cnt
	f.totalFlushes++
	f.proposals = append(f.proposals, *proposal)

	return proposal
}

// sendToLeoAI encode proposal thành ISLMessage và gửi
func (f *DNFlusher) sendToLeoAI(p *KnowledgeProposal) {
	msg := &isl.ISLMessage{
		Version:  1,
		MsgType:  isl.MsgKnowledge,
		SenderID: 0x0099,
		// PrimaryAddr = addr của khái niệm được học
		PrimaryAddr: isl.Address{
			Layer: byte(p.Addr >> 56),
			Group: byte(p.Addr >> 48),
			Type:  byte(p.Addr >> 40),
			ID:    byte(p.Addr >> 32),
		},
		// Confidence = evidence count (capped 100)
		Confidence: uint32(min100(p.Evidence)),
		// Flags: bit0=inside dominant
		Flags: insideFlag(p.InsideRatio),
	}
	f.Bus.Send(f.LeoAIID, msg)
}

// Run vòng lặp tự động check và flush
// Gọi trong goroutine riêng
func (f *DNFlusher) Run(stop <-chan struct{}) {
	ticker := time.NewTicker(time.Duration(f.CheckInterval*1000) * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-stop:
			return
		case <-ticker.C:
			f.CheckAndFlush()
		}
	}
}

// Stats thống kê
func (f *DNFlusher) Stats() (flushes int, proposals []KnowledgeProposal) {
	return f.totalFlushes, append([]KnowledgeProposal(nil), f.proposals...)
}

// buildSummary tạo mô tả human-readable
func (f *DNFlusher) buildSummary(addr uint64, cnt int, ratio float64) string {
	loc := "near"
	if ratio > 0.6 { loc = "inside" }
	return fmt.Sprintf("observed addr=%016x %s (evidence=%d insideRatio=%.2f)",
		addr, loc, cnt, ratio)
}

func min100(n int) int { if n > 100 { return 100 }; return n }
func insideFlag(r float64) byte { if r > 0.5 { return 0x01 }; return 0x00 }
