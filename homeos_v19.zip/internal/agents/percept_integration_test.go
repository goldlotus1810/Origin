package agents

import (
	"testing"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestPerceptLayerVisionChief(t *testing.T) {
	// Setup
	ws := gene.NewWorldScene()
	ws.Clock.HourOfDay = 12.0

	nodes   := ws.SpatialNodes()
	router  := gene.NewISLRouter(nodes, 8.0)
	addrMap := NewAddrAgentMap()
	bus     := NewMessageBus()

	// VisionChief đăng ký
	vc := NewVisionChief("vision_chief_01", 256)
	bus.Register(vc.ID, vc.Inbox, 1, RoleChief)

	// Map ISLAddr → agentID
	addrMap.Register(uint64(gene.ISL_Earth), vc.ID)
	addrMap.Register(uint64(gene.ISL_Sun),   vc.ID)

	// SpatialDispatcher
	disp := NewSpatialDispatcher(router, addrMap, bus)

	// PerceptLayer
	pl := NewPerceptLayer(ws, disp)

	// Sensor bên trong Earth (r=12), probe ring r=5
	pl.AddSensor(SensorPoint{
		ID:       "sensor_earth_surface",
		Pos:      gene.Vec3{X: 0, Y: 8, Z: 0}, // trong Earth
		Radius:   4.0,
		NSamples: 8,
	})
	// Sensor bên ngoài Earth nhưng gần
	pl.AddSensor(SensorPoint{
		ID:       "sensor_near_surface",
		Pos:      gene.Vec3{X: 0, Y: 14, Z: 0}, // ngoài Earth dist=2
		Radius:   2.0,
		NSamples: 4,
	})

	t.Log("=== PerceptLayer + VisionChief integration ===")

	// Start VisionChief goroutine
	stop := make(chan struct{})
	go vc.Run(stop)
	defer close(stop)

	// Chạy 5 ticks thủ công
	for i := 0; i < 5; i++ {
		result := pl.Tick(0.1) // dt=0.1s
		t.Logf("Tick %d: %d msgs dispatched %v",
			result.TickN, result.TotalMsgs, result.Dispatched)
		if result.TotalMsgs == 0 {
			t.Errorf("tick %d: không có message nào được dispatch", result.TickN)
		}
	}

	// Đợi VisionChief xử lý
	time.Sleep(20 * time.Millisecond)

	// Kiểm tra VisionChief đã lưu observations
	recent := vc.Recent(20)
	t.Logf("\nVisionChief recent observations: %d", len(recent))
	if len(recent) == 0 {
		t.Error("VisionChief phải có ít nhất 1 observation")
	}

	// Phần lớn observations phải là ISL_Earth
	tally := vc.Tally()
	t.Log("Tally:")
	for addr, cnt := range tally {
		label := "?"
		if addr == uint64(gene.ISL_Earth) { label = "ISL_Earth" }
		if addr == uint64(gene.ISL_Sun)   { label = "ISL_Sun"   }
		t.Logf("  %016x %-10s × %d", addr, label, cnt)
	}

	dom, domCnt := vc.Dominant()
	t.Logf("\nDominant: %016x × %d", dom, domCnt)
	if dom != uint64(gene.ISL_Earth) {
		t.Errorf("dominant phải là ISL_Earth, got %016x", dom)
	}

	// InsideCount
	insideCnt := vc.InsideCount(uint64(gene.ISL_Earth))
	t.Logf("InsideCount(Earth): %d", insideCnt)
	if insideCnt == 0 {
		t.Error("phải có ít nhất 1 inside observation cho Earth")
	}

	t.Log("\n" + vc.Summary())

	// Test Run với real ticker (ngắn)
	stopRun := make(chan struct{})
	vc2 := NewVisionChief("vision_chief_02", 256)
	bus.Register(vc2.ID, vc2.Inbox, 1, RoleChief)
	addrMap.Register(uint64(gene.ISL_Earth)^0xF, vc2.ID) // addr khác để không conflict

	pl2 := NewPerceptLayer(ws, disp)
	pl2.MinTickMs = 20
	pl2.AddSensor(SensorPoint{Pos: gene.Vec3{X: 0, Y: 6, Z: 0}, Radius: 3, NSamples: 6})

	go vc2.Run(stopRun)
	go pl2.Run(stopRun, 0.02)

	time.Sleep(150 * time.Millisecond) // ~7 ticks at 20ms
	close(stopRun)
	time.Sleep(10 * time.Millisecond)

	ticks, sensors := pl2.Stats()
	t.Logf("\npl2.Run: %d ticks, %d sensors", ticks, sensors)
	if ticks < 3 {
		t.Errorf("pl2 phải có ít nhất 3 ticks, got %d", ticks)
	}

	// Drain vc2 inbox
	drained := 0
	for len(vc2.Inbox) > 0 {
		<-vc2.Inbox
		drained++
	}

	t.Logf("\n✓ PerceptLayer.Tick → SDF → ISLAddr → Bus → VisionChief.mem")
	_ = drained
	_ = isl.MsgQuery
}
