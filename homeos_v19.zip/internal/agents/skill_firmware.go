// internal/agents/skill_firmware.go
//
// 4 Skill để Agent "hiểu" thiết bị:
//
//   FirmwareReaderSkill  — đọc + parse firmware, tìm API endpoints
//   SecurityAuditSkill   — quét lỗ hổng, kiểm tra CVE
//   FirmwarePatchSkill   — vá lỗi, cập nhật, rollback
//   CapabilityMapSkill   — ánh xạ chức năng firmware → Skill cần gắn
//
// QT4: mỗi Skill = 1 trách nhiệm duy nhất
// Skill không biết nhau — giao tiếp qua ExecContext.State
//
// Ví dụ flow:
//   Agent gắn 4 skill này → tự hiểu bất kỳ thiết bị nào
//   CapabilityMapSkill nhận xét quả của 3 skill kia
//   → đề xuất: "thiết bị này cần ActuatorLight + TempSensor"
//   → Chief gắn thêm 2 skill đó → Agent hoạt động đầy đủ

package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─────────────────────────────────────────────────────────────
// FIRMWARE STRUCTURES
// ─────────────────────────────────────────────────────────────

type FirmwareInfo struct {
	Vendor      string
	Model       string
	Version     string
	Protocol    string   // "zigbee", "zwave", "wifi", "matter", "ble"
	APIType     string   // "rest", "mqtt", "coap", "proprietary"
	Endpoints   []APIEndpoint
	ParsedAt    time.Time
}

type APIEndpoint struct {
	Path       string   // "/api/v1/lights/1/state"
	Method     string   // "GET", "PUT", "POST"
	Capability string   // "on_off", "brightness", "color", "temp"
	ReadOnly   bool
	DataType   string   // "bool", "int0-254", "rgb", "kelvin"
}

type SecurityFinding struct {
	Severity    string   // "critical", "high", "medium", "low", "info"
	CVE         string   // "CVE-2024-xxxx" nếu có
	Description string
	Fixable     bool
	FixAction   string   // lệnh để vá
}

type FirmwarePatch struct {
	Type        string   // "config", "update", "credential_rotate"
	Target      string   // endpoint hoặc setting bị vá
	OldValue    string
	NewValue    string
	Reason      string
	AppliedAt   time.Time
}

// ─────────────────────────────────────────────────────────────
// SKILL 1: FirmwareReaderSkill
// Trách nhiệm: đọc firmware, parse API, lưu vào state
// ─────────────────────────────────────────────────────────────

type FirmwareReaderSkill struct{}

func NewFirmwareReaderSkill() *FirmwareReaderSkill { return &FirmwareReaderSkill{} }
func (s *FirmwareReaderSkill) Name() string        { return "firmware_reader" }

func (s *FirmwareReaderSkill) CanHandle(msg *isl.ISLMessage) bool {
	return MatchIntent(msg, IntentReadFirmware)
}

func (s *FirmwareReaderSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var req struct {
		IP        string `json:"ip"`
		AuthToken string `json:"auth"`
	}
	decodePayload(msg.Payload, &req)

	// Parse firmware info từ thiết bị
	// Thực tế: HTTP GET /api/info, /description.xml (UPnP), v.v.
	// Ở đây: parse từ mock response trong payload
	info := s.parseFirmware(req.IP, req.AuthToken)

	// Lưu vào state để Skill khác dùng
	ctx.State["firmware.info"] = info
	ctx.State["firmware.ip"]   = req.IP

	summary := fmt.Sprintf("%s %s (%s) — %s/%s — %d endpoints",
		info.Vendor, info.Model, info.Version,
		info.Protocol, info.APIType, len(info.Endpoints))

	return SkillResult{
		Data: map[string]interface{}{
			"firmware.parsed": true,
			"firmware.summary": summary,
			"firmware.endpoints": len(info.Endpoints),
		},
	}
}

func (s *FirmwareReaderSkill) parseFirmware(ip, auth string) FirmwareInfo {
	// Nhận dạng vendor từ IP range / mDNS / UPnP
	// Thực tế sẽ gọi HTTP, parse XML/JSON
	// Mock: nhận dạng từ auth pattern
	info := FirmwareInfo{
		ParsedAt: time.Now(),
	}

	if strings.Contains(auth, "hue") || strings.Contains(ip, "192.168.1.10") {
		info.Vendor   = "Philips"
		info.Model    = "Hue Bridge v2"
		info.Version  = "1.60.1.60.1.60"
		info.Protocol = "wifi"
		info.APIType  = "rest"
		info.Endpoints = []APIEndpoint{
			{"/api/{user}/lights",       "GET", "list_lights",  false, "array"},
			{"/api/{user}/lights/{id}",  "GET", "light_info",   false, "object"},
			{"/api/{user}/lights/{id}/state", "PUT", "on_off",  false, "bool"},
			{"/api/{user}/lights/{id}/state", "PUT", "brightness", false, "int0-254"},
			{"/api/{user}/lights/{id}/state", "PUT", "color_temp", false, "kelvin"},
		}
	} else if strings.Contains(auth, "xiaomi") {
		info.Vendor   = "Xiaomi"
		info.Model    = "Mi Smart Bulb"
		info.Version  = "2.1.3"
		info.Protocol = "wifi"
		info.APIType  = "mqtt"
		info.Endpoints = []APIEndpoint{
			{"miio/info",        "GET",     "device_info",  true, "object"},
			{"set_power",        "PUBLISH", "on_off",       false, "on/off"},
			{"set_bright",       "PUBLISH", "brightness",   false, "int1-100"},
			{"set_color_temp",   "PUBLISH", "color_temp",   false, "int2700-6500"},
		}
	} else {
		// Generic device: thử common endpoints
		info.Vendor   = "Unknown"
		info.Model    = "Smart Device"
		info.Version  = "?.?.?"
		info.Protocol = "wifi"
		info.APIType  = "rest"
		info.Endpoints = []APIEndpoint{
			{"/status",  "GET", "device_info", true,  "object"},
			{"/control", "POST","on_off",       false, "bool"},
		}
	}
	return info
}

// ─────────────────────────────────────────────────────────────
// SKILL 2: SecurityAuditSkill
// Trách nhiệm: kiểm tra lỗ hổng, default password, CVE
// ─────────────────────────────────────────────────────────────

type SecurityAuditSkill struct{}

func NewSecurityAuditSkill() *SecurityAuditSkill { return &SecurityAuditSkill{} }
func (s *SecurityAuditSkill) Name() string        { return "security_audit" }

func (s *SecurityAuditSkill) CanHandle(msg *isl.ISLMessage) bool {
	return MatchIntent(msg, IntentSecurityAudit)
}

func (s *SecurityAuditSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	info, ok := ctx.State["firmware.info"].(FirmwareInfo)
	if !ok { return SkillResult{} }
	ip, _ := ctx.State["firmware.ip"].(string)

	findings := s.audit(info, ip)

	critical := 0
	for _, f := range findings {
		if f.Severity == "critical" || f.Severity == "high" { critical++ }
	}

	ctx.State["security.findings"] = findings
	ctx.State["security.critical"] = critical

	return SkillResult{
		Data: map[string]interface{}{
			"security.findings": len(findings),
			"security.critical": critical,
			"security.safe":     critical == 0,
		},
	}
}

func (s *SecurityAuditSkill) audit(info FirmwareInfo, ip string) []SecurityFinding {
	var findings []SecurityFinding

	// Kiểm tra default credentials
	if strings.Contains(strings.ToLower(info.Vendor), "unknown") {
		findings = append(findings, SecurityFinding{
			Severity:    "high",
			Description: "Vendor không xác định — không thể verify firmware integrity",
			Fixable:     false,
		})
	}

	// Kiểm tra version cũ
	if info.Vendor == "Philips" && info.Version < "1.59" {
		findings = append(findings, SecurityFinding{
			Severity:    "critical",
			CVE:         "CVE-2023-38913",
			Description: "Hue Bridge < 1.59: Remote Code Execution qua mDNS",
			Fixable:     true,
			FixAction:   "firmware_update",
		})
	}

	// Kiểm tra HTTP (không có TLS)
	if info.APIType == "rest" && !strings.HasPrefix(ip, "192.168") {
		findings = append(findings, SecurityFinding{
			Severity:    "medium",
			Description: "REST API không có TLS — chỉ an toàn trong LAN",
			Fixable:     false, // đây là thiết kế của thiết bị
		})
	}

	// Kiểm tra MQTT không auth
	if info.APIType == "mqtt" {
		findings = append(findings, SecurityFinding{
			Severity:    "medium",
			Description: "MQTT: kiểm tra xem có require auth không",
			Fixable:     true,
			FixAction:   "mqtt_set_auth",
		})
	}

	// Endpoint có write access mà không cần auth?
	for _, ep := range info.Endpoints {
		if !ep.ReadOnly && ep.Method != "GET" {
			// OK nếu đã có auth token
			findings = append(findings, SecurityFinding{
				Severity:    "info",
				Description: fmt.Sprintf("Write endpoint %s %s — đảm bảo auth token hợp lệ", ep.Method, ep.Path),
				Fixable:     false,
			})
			break // chỉ báo 1 lần
		}
	}

	return findings
}

// ─────────────────────────────────────────────────────────────
// SKILL 3: FirmwarePatchSkill
// Trách nhiệm: vá lỗi, cập nhật firmware, rollback nếu lỗi
// ─────────────────────────────────────────────────────────────

type FirmwarePatchSkill struct {
	history []FirmwarePatch // QT8: lưu lịch sử vá
}

func NewFirmwarePatchSkill() *FirmwarePatchSkill { return &FirmwarePatchSkill{} }
func (s *FirmwarePatchSkill) Name() string        { return "firmware_patch" }

func (s *FirmwarePatchSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgSync // "vá lỗi này"
}

func (s *FirmwarePatchSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	findings, ok := ctx.State["security.findings"].([]SecurityFinding)
	if !ok || len(findings) == 0 {
		return SkillResult{
			Data: map[string]interface{}{"patch.applied": 0},
		}
	}

	var applied []FirmwarePatch
	var failed  []string

	for _, f := range findings {
		if !f.Fixable { continue }

		patch := s.applyPatch(f, ctx)
		if patch != nil {
			applied = append(applied, *patch)
			s.history = append(s.history, *patch)
		} else {
			failed = append(failed, f.Description)
		}
	}

	ctx.State["patch.applied"] = len(applied)
	ctx.State["patch.history"] = s.history

	return SkillResult{
		Data: map[string]interface{}{
			"patch.applied": len(applied),
			"patch.failed":  len(failed),
			"patch.total":   len(s.history),
		},
	}
}

func (s *FirmwarePatchSkill) applyPatch(f SecurityFinding, ctx *ExecContext) *FirmwarePatch {
	info, _ := ctx.State["firmware.info"].(FirmwareInfo)

	switch f.FixAction {
	case "firmware_update":
		return &FirmwarePatch{
			Type: "update", Target: "firmware_version",
			OldValue: info.Version, NewValue: "latest",
			Reason: f.CVE, AppliedAt: time.Now(),
		}
	case "mqtt_set_auth":
		return &FirmwarePatch{
			Type: "config", Target: "mqtt.require_auth",
			OldValue: "false", NewValue: "true",
			Reason: "security hardening", AppliedAt: time.Now(),
		}
	}
	return nil
}

// Rollback: nếu patch làm thiết bị hỏng → khôi phục
func (s *FirmwarePatchSkill) Rollback(target string) *FirmwarePatch {
	for i := len(s.history) - 1; i >= 0; i-- {
		p := s.history[i]
		if p.Target == target {
			return &FirmwarePatch{
				Type: p.Type, Target: p.Target,
				OldValue: p.NewValue, NewValue: p.OldValue, // đảo ngược
				Reason: "rollback: " + p.Reason,
				AppliedAt: time.Now(),
			}
		}
	}
	return nil
}

// ─────────────────────────────────────────────────────────────
// SKILL 4: CapabilityMapSkill
// Trách nhiệm: đọc kết quả 3 skill trên → đề xuất Skill cần gắn
// Đây là skill "tự cấu hình" — Agent tự biết nó cần gì
// ─────────────────────────────────────────────────────────────

type CapabilityMapSkill struct{}

func NewCapabilityMapSkill() *CapabilityMapSkill { return &CapabilityMapSkill{} }
func (s *CapabilityMapSkill) Name() string        { return "capability_map" }

func (s *CapabilityMapSkill) CanHandle(msg *isl.ISLMessage) bool {
	return MatchIntent(msg, IntentMapCaps)
}

func (s *CapabilityMapSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	info, ok := ctx.State["firmware.info"].(FirmwareInfo)
	if !ok { return SkillResult{} }

	needed := s.mapCapabilities(info)
	ctx.State["capabilities.skills"] = needed

	return SkillResult{
		Data: map[string]interface{}{
			"capabilities.skills":  needed,
			"capabilities.count":   len(needed),
		},
		// Đề xuất lên Chief: "gắn thêm những skill này"
		Message: &isl.ISLMessage{
			MsgType: isl.MsgPropose,
			Payload: encodePayload(map[string]interface{}{
				"agent_needs_skills": needed,
				"device_type":        s.deviceType(info),
			}),
		},
	}
}

// mapCapabilities: endpoint → Skill tương ứng
func (s *CapabilityMapSkill) mapCapabilities(info FirmwareInfo) []string {
	capSet := make(map[string]bool)

	for _, ep := range info.Endpoints {
		switch ep.Capability {
		case "on_off", "brightness", "color", "color_temp":
			capSet["actuator_light"] = true
		case "temp", "temperature":
			capSet["actuator_hvac"] = true
			capSet["temp_sensor"] = true
		case "lock", "unlock":
			capSet["actuator_lock"] = true
		case "list_lights", "light_info":
			capSet["actuator_light"] = true
		case "device_info":
			// monitoring only
		}
	}

	var skills []string
	for k := range capSet { skills = append(skills, k) }
	return skills
}

func (s *CapabilityMapSkill) deviceType(info FirmwareInfo) string {
	caps := make(map[string]bool)
	for _, ep := range info.Endpoints { caps[ep.Capability] = true }

	switch {
	case caps["on_off"] && caps["brightness"]:  return "smart_light"
	case caps["temp"]:                           return "hvac"
	case caps["lock"]:                           return "smart_lock"
	default:                                     return "unknown_device"
	}
}
