// internal/agents/book_flush.go
// BookMemory.FlushToLongTerm — ghi thật vào Silk + Ledger
//
// ĐÂY LÀ BỨC TƯỜNG QUAN TRỌNG NHẤT:
//   BookMemory (RAM, ĐN) → LongTerm (Silk graph + Ledger, QR)
//
// QT7: ĐN đủ confidence → QR (append-only, ED25519 signed)
//
// Mapping:
//   LearnedWord  → memory.Observation → LongTerm.Commit()
//                  → silk.OlangNode{DNA: "emo:v=...:a=...:i=..."}
//                  → SilkGraph.AddNode() + Ledger.Append()
//
//   SemanticPair → SilkGraph.AddEdge(addrA, addrB, OpSemantic)
//                  (không cần ledger — edge học được từ ĐN)

package agents

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"strings"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

// FlushResult kết quả flush
type FlushResult struct {
	WordsCommitted int // node ghi vào QR
	WordsSkipped   int // chưa đủ confidence
	EdgesAdded     int // semantic edges
	Errors         []string
}

// FlushToLongTerm ghi LearnedWords + SemanticPairs vào Silk thật
//
// Ngưỡng QT7:
//   confidence >= 0.30 (≥3 lần) → ĐN thành QR
//   confidence >= 0.80 (≥8 lần) → QR có Ledger signature
func (m *BookMemory) FlushToSilk(graph *silk.SilkGraph) FlushResult {
	result := FlushResult{}

	// ── Bước 1: Commit LearnedWords → OlangNode ──────────────────
	addrMap := make(map[string]isl.Address) // word → ISL addr (dùng cho edge)

	for word, lw := range m.Words {
		if lw.Confidence < 0.10 { // ĐN: 1+ lần là vào graph
			result.WordsSkipped++
			continue
		}

		// Tạo ISL address từ hash của từ
		// Layer E (Emotion) = 0x05, group từ first byte của word
		addr := emotionAddr(word)
		addrMap[word] = addr

		// DNA: lưu EmotionTag vào DNA field của OlangNode
		dna := fmt.Sprintf("emo:src=%s:v=%.3f:a=%.3f:d=%.3f:i=%.3f:n=%d:conf=%.2f",
			m.Source,
			lw.Tag.Valence, lw.Tag.Arousal, lw.Tag.Dominance, lw.Tag.Intensity,
			lw.Count, lw.Confidence)

		node := &silk.OlangNode{
			Addr:   addr,
			Name:   word,
			DNA:    dna,
			Cat:    "emotion_learned",
			Layer:  3, // leaf
			Weight: lw.Count,
			Status: func() silk.NodeStatus {
				if lw.Confidence >= 0.80 {
					return silk.StatusQR // đủ chắc → QR
				}
				return silk.StatusDN // chưa chắc → ĐN
			}(),
		}

		// Ghi vào SilkGraph (ĐN — ngắn hạn, có thể xóa)
		// QT7: KHÔNG tự commit QR — phải qua DreamSkill → AAM → user approve
		graph.AddNode(node)
		result.WordsCommitted++
	}

	// ── Bước 2: AddEdge cho SemanticPairs ────────────────────────
	for _, pair := range m.Pairs {
		if pair.CoOccur < 2 {
			continue
		}
		addrA, okA := addrMap[pair.WordA]
		addrB, okB := addrMap[pair.WordB]
		if !okA || !okB {
			continue
		}

		// Thêm semantic edge (bidirectional)
		graph.AddEdge(addrA, addrB, silk.OpSimilar)
		graph.AddEdge(addrB, addrA, silk.OpSimilar)
		result.EdgesAdded += 2
	}

	// ── Bước 3: Flush inflection points → Silk edge "infl:" ──────
	for _, pt := range m.Inflections {
		dna := fmt.Sprintf("infl:src=%s:turn=%d:v=%.3f:a=%.3f:label=%s:text=%s",
			m.Source, pt.Turn,
			pt.Tag.Valence, pt.Tag.Arousal,
			pt.Tag.Label(),
			truncateStr(pt.Text, 40))

		addr := inflectionAddr(m.Source, pt.Turn)
		node := &silk.OlangNode{
			Addr:   addr,
			Name:   fmt.Sprintf("infl_%s_%d", strings.ReplaceAll(m.Source, " ", "_"), pt.Turn),
			DNA:    dna,
			Cat:    "inflection",
			Layer:  3,
			Weight: 1,
			Status: silk.StatusDN,
		}
		graph.AddNode(node)
	}

	return result
}

// ─── ISL Address helpers ──────────────────────────────────────────────────

// emotionAddr tạo ISL address cho một từ cảm xúc
// Layer 5 = Emotion (không có sẵn trong ISL spec → dùng ISL4 với layer=5)
func emotionAddr(word string) isl.Address {
	h := sha256.Sum256([]byte("emo:" + word))
	return isl.Address{
		Layer: byte('E'),        // E = Emotion layer
		Group: h[0]%26 + byte('A'),
		Type:  byte('e'),
		ID:    h[1],
		Attributes: isl.AttrOf(h[2], h[3], h[4], h[5]),
	}
}

// inflectionAddr tạo ISL address cho inflection point
func inflectionAddr(source string, turn int) isl.Address {
	h := sha256.Sum256([]byte(fmt.Sprintf("infl:%s:%d", source, turn)))
	return isl.Address{
		Layer: byte('E'),
		Group: h[0]%26 + byte('A'),
		Type:  byte('i'),          // i = inflection
		ID:    byte(turn % 256),
		Attributes: isl.AttrOf(h[2], h[3], h[4], h[5]),
	}
}

// nodeHashFromWord tạo NodeHash từ tên từ
func nodeHashFromWord(word string) isl.NodeHash {
	h := sha256.Sum256([]byte("word:" + word))
	return isl.NodeHash(binary.BigEndian.Uint64(h[:8]))
}
