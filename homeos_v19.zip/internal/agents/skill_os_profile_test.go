package agents

import (
	"testing"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestOSProfileSkill(t *testing.T) {
	t.Log("═══════════════════════════════")
	t.Log("OSProfileSkill — đọc hệ thống")
	t.Log("═══════════════════════════════")

	sk := NewOSProfileSkill()
	ctx := &ExecContext{State: make(map[string]interface{})}
	msg := &isl.ISLMessage{MsgType: isl.MsgQuery}

	r := sk.Execute(ctx, msg)

	// Lấy profile để print summary
	profile := sk.lastProfile
	if profile != nil {
		t.Log("\n" + profile.Summary())
	}

	t.Logf("State keys written: %d", len(r.Data))
	for k, v := range r.Data {
		t.Logf("  %-22s = %v", k, v)
	}

	// Kiểm tra cache hoạt động
	r2 := sk.Execute(ctx, msg)
	t.Logf("\nCache hit: %v (same data)", r2.Data["os.distro"] == r.Data["os.distro"])

	// Validate
	if r.Data["os.cpu_cores"] == nil {
		t.Error("os.cpu_cores missing")
	}
	t.Log("\n✓ OSProfileSkill PASS")
}
