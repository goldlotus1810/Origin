// internal/agents/skill_hebbian.go
//
// HebbianSkill — LeoAI học bằng cách tăng weight của edges giữa
// các QR nodes được co-activate cùng nhau.
//
// "Neurons that fire together, wire together" — Hebb, 1949
//
// Cơ chế:
//   1. Theo dõi activation history trong ShortTerm (recent window)
//   2. Tìm cặp nodes kích hoạt trong cùng time window (≤ coWindow)
//   3. Nếu cặp nodes đã có edge trong SilkGraph → BoostEdge(weight++)
//   4. Nếu cặp nodes chưa có edge nhưng co-activate nhiều lần → đề xuất edge mới
//
// Không vi phạm QT7:
//   BoostEdge chỉ tăng weight của QR edges hiện có — không tạo QR mới
//   Đề xuất edge mới → MsgPropose → AAM approve

package agents

import (
	"fmt"
	"log"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

const (
	hebbCoWindow    = 30 * time.Second // 2 activations trong window này → co-activate
	hebbMinCoFires  = 3               // số lần co-activate tối thiểu để propose edge
	hebbMaxPairs    = 50              // giới hạn số cặp xử lý mỗi cycle (QT2: no ∞)
	hebbDecayEvery  = 24 * time.Hour  // decay 1 weight mỗi ngày không dùng
	hebbMinWeight   = 0               // weight tối thiểu (không âm)
)

// HebbianSkill theo dõi co-activation và tăng Silk edge weights
type HebbianSkill struct {
	dn           *memory.ShortTerm
	graph        *silk.SilkGraph
	weightStore  *silk.EdgeWeightStore // persist weights (nil = in-memory only)
	coCount      map[string]int        // co-activation counter
	lastDecay    time.Time             // lần cuối chạy decay
}

func NewHebbianSkill(dn *memory.ShortTerm, graph *silk.SilkGraph) *HebbianSkill {
	return &HebbianSkill{
		dn:        dn,
		graph:     graph,
		coCount:   make(map[string]int),
		lastDecay: time.Now(), // bắt đầu từ now → decay sau hebbDecayEvery
	}
}

// WithWeightStore wire EdgeWeightStore để persist Hebbian weights
func (s *HebbianSkill) WithWeightStore(ws *silk.EdgeWeightStore) *HebbianSkill {
	s.weightStore = ws
	return s
}

func (s *HebbianSkill) Name() string { return "learn.hebbian" }

func (s *HebbianSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgLearn
}

func (s *HebbianSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.dn == nil || s.graph == nil {
		return SkillResult{}
	}

	// Lấy recent observations trong coWindow
	all := s.dn.All()
	now := time.Now()
	var recent []memory.Observation
	for _, obs := range all {
		if now.Sub(obs.UpdatedAt) <= hebbCoWindow && obs.FireCount > 0 {
			recent = append(recent, obs)
		}
	}

	if len(recent) < 2 {
		return SkillResult{}
	}

	boosted := 0
	proposed := 0
	pairsChecked := 0
	var propPayloads []string

	// Tìm cặp co-activate (O(n²) nhưng giới hạn hebbMaxPairs)
	for i := 0; i < len(recent) && pairsChecked < hebbMaxPairs; i++ {
		for j := i + 1; j < len(recent) && pairsChecked < hebbMaxPairs; j++ {
			pairsChecked++
			a, b := recent[i], recent[j]

			// Cùng layer → khả năng liên quan cao
			if a.ISL.Layer != b.ISL.Layer {
				continue
			}

			// Boost edge nếu đã tồn tại trong SilkGraph (kiểm tra cả 2 chiều)
			if s.graph.HasEdge(a.ISL, b.ISL) {
				s.graph.BoostEdge(a.ISL, b.ISL, silk.OpSimilar)
				s.persistWeight(a.ISL.Uint64(), b.ISL.Uint64())
				boosted++
				continue
			} else if s.graph.HasEdge(b.ISL, a.ISL) {
				s.graph.BoostEdge(b.ISL, a.ISL, silk.OpSimilar)
				s.persistWeight(b.ISL.Uint64(), a.ISL.Uint64())
				boosted++
				continue
			}

			// Track co-activation count
			key := coKey(a.ISL, b.ISL)
			s.coCount[key]++

			// Đủ lần co-activate → propose edge mới (qua AAM)
			if s.coCount[key] >= hebbMinCoFires {
				proposed++
				s.coCount[key] = 0 // reset để tránh spam
				// Encode proposal: "edge|fromAddr|toAddr"
				propPayloads = append(propPayloads,
					fmt.Sprintf("edge|%016x|%016x", a.ISL.Uint64(), b.ISL.Uint64()))
			}
		}
	}

	// Decay: giảm weight của edges không được activate gần đây
	decayed := s.decayWeights(now)

	if boosted > 0 || proposed > 0 || decayed > 0 {
		log.Printf("Hebbian: boosted=%d proposed=%d decayed=%d (recent=%d, pairs=%d)",
			boosted, proposed, decayed, len(recent), pairsChecked)
	}

	// Gửi MsgPropose cho tất cả edge proposals
	var outMsgs []*isl.ISLMessage
	for _, p := range propPayloads {
		outMsgs = append(outMsgs, &isl.ISLMessage{
			MsgType: isl.MsgPropose,
			Payload: []byte(p),
		})
	}

	return SkillResult{
		Messages: outMsgs,
		Data: map[string]interface{}{
			"hebbian.boosted":  boosted,
			"hebbian.proposed": proposed,
			"hebbian.decayed":  decayed,
			"hebbian.recent":   len(recent),
		},
	}
}

// coKey tạo key cho cặp nodes (sorted để đảm bảo A↔B == B↔A)
func coKey(a, b isl.Address) string {
	ua, ub := a.Uint64(), b.Uint64()
	if ua > ub {
		ua, ub = ub, ua
	}
	// fmt.Sprintf tránh invalid UTF-8 khi cast uint64 → rune
	return fmt.Sprintf("%016x_%016x", ua, ub)
}


// decayWeights giảm weight của tất cả edges mỗi hebbDecayEvery
// "Neurons that stop firing together, unwire" — nguyên lý đối xứng Hebb
func (s *HebbianSkill) decayWeights(now time.Time) int {
	if now.Sub(s.lastDecay) < hebbDecayEvery {
		return 0
	}
	s.lastDecay = now

	if s.graph == nil {
		return 0
	}

	decayed := s.graph.DecayAllEdges(hebbMinWeight)

	// Persist sau decay
	if s.weightStore != nil && decayed > 0 {
		go func() {
			if err := s.weightStore.Save(); err != nil {
				log.Printf("HebbianSkill: weight save after decay failed: %v", err)
			}
		}()
	}
	return decayed
}

// persistWeight lưu weight hiện tại của edge vào store
func (s *HebbianSkill) persistWeight(fromU, toU uint64) {
	if s.weightStore == nil {
		return
	}
	w := s.graph.EdgeWeight(fromU, toU)
	s.weightStore.Set(fromU, toU, w)
	// Save async để không block Execute
	go func() {
		if err := s.weightStore.Save(); err != nil {
			log.Printf("HebbianSkill: weight save failed: %v", err)
		}
	}()
}
