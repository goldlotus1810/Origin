//go:build !linux

package agents

import "errors"

type StatVFS struct {
	Bsize  uint64
	Blocks uint64
	Bfree  uint64
	Bavail uint64
}

func statVFS(path string, s *StatVFS) error {
	return errors.New("not linux")
}
