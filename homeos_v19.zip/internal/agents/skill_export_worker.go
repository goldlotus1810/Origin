// internal/agents/skill_export_worker.go
//
// ExportWorkerSkill — Chief trích xuất worker.olang và ship đến thiết bị
//
// Nguyên tắc:
//   Chief là người duy nhất có thể tạo/ship Worker
//   Worker KHÔNG tự nhân bản (QT Agent rule #10)
//   homeos.olang → subtree → worker_X.olang → ship qua LAN
//
// Flow:
//   1. Nhận MsgActuatorCmd với action="spawn_worker"
//      hoặc khi OnboardSkill phát hiện thiết bị mới
//   2. Chief chọn WorkerSpec phù hợp với DeviceType
//   3. Exporter trích xuất subtree → worker_X.olang (~64KB)
//   4. Ship file qua HTTP PUT đến thiết bị
//   5. Thiết bị chạy: olang run worker_X.olang
//   6. Ghi ExportInfo vào State → LeoAI có thể track

package agents

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/olang"
)

// ExportWorkerSkill — 1 trách nhiệm: export worker.olang và ship
type ExportWorkerSkill struct {
	sourcePath string          // homeos.olang
	outputDir  string          // thư mục lưu worker files
	exporter   *olang.Exporter // lazy init

	// Track workers đã export
	exported map[string]*olang.ExportInfo
}

func NewExportWorkerSkill(sourcePath, outputDir string) *ExportWorkerSkill {
	return &ExportWorkerSkill{
		sourcePath: sourcePath,
		outputDir:  outputDir,
		exported:   make(map[string]*olang.ExportInfo),
	}
}

func (s *ExportWorkerSkill) Name() string { return "export_worker" }

func (s *ExportWorkerSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg.MsgType != isl.MsgActuatorCmd {
		return false
	}
	var cmd map[string]string
	if err := json.Unmarshal(msg.Payload, &cmd); err != nil {
		return false
	}
	return cmd["action"] == "spawn_worker" || cmd["action"] == "export_worker"
}

func (s *ExportWorkerSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var cmd map[string]string
	if err := json.Unmarshal(msg.Payload, &cmd); err != nil {
		return SkillResult{}
	}

	workerID   := cmd["worker_id"]
	deviceType := cmd["device_type"]
	deviceIP   := cmd["device_ip"]

	if workerID == "" || deviceType == "" {
		return SkillResult{Data: map[string]interface{}{
			"error": "worker_id and device_type required",
		}}
	}

	// Lazy init exporter
	if s.exporter == nil {
		exp, err := olang.NewExporter(s.sourcePath)
		if err != nil {
			log.Printf("ExportWorker: cannot load %q: %v", s.sourcePath, err)
			return SkillResult{Data: map[string]interface{}{
				"error": fmt.Sprintf("load source: %v", err),
			}}
		}
		s.exporter = exp
		log.Printf("✅ ExportWorker: loaded %q", s.sourcePath)
	}

	// Chọn spec theo device type
	spec := s.buildSpec(workerID, deviceType, deviceIP)

	// Tạo output dir nếu chưa có
	if err := os.MkdirAll(s.outputDir, 0755); err != nil {
		return SkillResult{Data: map[string]interface{}{
			"error": fmt.Sprintf("mkdir %q: %v", s.outputDir, err),
		}}
	}

	// Export
	result, err := s.exporter.Export(spec, s.outputDir)
	if err != nil {
		log.Printf("ExportWorker [%s]: export failed: %v", workerID, err)
		return SkillResult{Data: map[string]interface{}{
			"error": err.Error(),
		}}
	}

	log.Printf("✅ ExportWorker [%s]: %s", workerID, result)

	info := &olang.ExportInfo{
		WorkerID:   workerID,
		OutputPath: result.OutputPath,
		SizeKB:     result.SizeBytes / 1024,
		NodeCount:  result.NodeCount,
		EdgeCount:  result.EdgeCount,
		ExportedAt: time.Now(),
	}
	s.exported[workerID] = info

	// Ship đến thiết bị nếu có IP
	if deviceIP != "" {
		go s.shipToDevice(result.OutputPath, deviceIP, workerID)
	}

	return SkillResult{
		Data: map[string]interface{}{
			"exported":   workerID,
			"size_kb":    result.SizeBytes / 1024,
			"nodes":      result.NodeCount,
			"edges":      result.EdgeCount,
			"output":     result.OutputPath,
			"shipped_to": deviceIP,
		},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgSync,
			Payload: encodePayload(info),
		},
	}
}

// buildSpec chọn WorkerSpec đúng theo device type
func (s *ExportWorkerSkill) buildSpec(workerID, deviceType, deviceIP string) olang.WorkerSpec {
	switch deviceType {
	case "light":
		return olang.SpecForLight(workerID, deviceIP)
	case "hvac":
		return olang.SpecForHVAC(workerID, deviceIP)
	case "camera":
		return olang.SpecForCamera(workerID, deviceIP)
	case "lock":
		return olang.SpecForLock(workerID, deviceIP)
	default:
		// Generic: L0 + L4 + L7
		return olang.WorkerSpec{
			WorkerID:     workerID,
			DeviceType:   deviceType,
			DeviceIP:     deviceIP,
			Layers:       []uint8{olang.LayerPrimitives, olang.LayerObjects, olang.LayerPrograms},
			IncludeAllQR: true,
			CreatedAt:    time.Now(),
		}
	}
}

// shipToDevice gửi worker.olang đến thiết bị qua HTTP PUT
// Thiết bị chạy: $ olang run worker_X.olang (sau khi nhận)
func (s *ExportWorkerSkill) shipToDevice(filePath, deviceIP, workerID string) {
	url := fmt.Sprintf("http://%s:7777/deploy", deviceIP)

	f, err := os.Open(filePath)
	if err != nil {
		log.Printf("ExportWorker [%s]: ship open file: %v", workerID, err)
		return
	}
	defer f.Close()

	// HTTP PUT với Content-Type: application/octet-stream
	req, err := http.NewRequest(http.MethodPut, url, f)
	if err != nil {
		log.Printf("ExportWorker [%s]: ship create request: %v", workerID, err)
		return
	}
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("X-HomeOS-Worker-ID", workerID)
	req.Header.Set("X-HomeOS-Version", "1.0")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		log.Printf("ExportWorker [%s]: ship to %s failed: %v", workerID, deviceIP, err)
		return
	}
	defer resp.Body.Close()
	io.ReadAll(resp.Body) // drain

	if resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusNoContent {
		log.Printf("✅ ExportWorker [%s]: shipped to %s (HTTP %d)", workerID, deviceIP, resp.StatusCode)
	} else {
		log.Printf("⚠️  ExportWorker [%s]: ship to %s returned HTTP %d", workerID, deviceIP, resp.StatusCode)
	}
}

// ListExported trả về tất cả workers đã export
func (s *ExportWorkerSkill) ListExported() map[string]*olang.ExportInfo {
	result := make(map[string]*olang.ExportInfo, len(s.exported))
	for k, v := range s.exported {
		result[k] = v
	}
	return result
}

// ═══════════════════════════════════════════════════════════════
// WorkerDeployServer — HTTP server chạy tại thiết bị
// Nhận worker.olang từ Chief và chạy ngay
// ═══════════════════════════════════════════════════════════════

// WorkerDeployServer nhận file từ Chief và chạy olang runtime
// Chạy trên thiết bị tại port 7777
type WorkerDeployServer struct {
	deployDir string
	port      int

	// Callback sau khi deploy thành công
	onDeploy func(workerID, filePath string)
}

func NewWorkerDeployServer(deployDir string, port int) *WorkerDeployServer {
	return &WorkerDeployServer{
		deployDir: deployDir,
		port:      port,
	}
}

func (srv *WorkerDeployServer) WithDeployCallback(fn func(workerID, filePath string)) *WorkerDeployServer {
	srv.onDeploy = fn
	return srv
}

// Start khởi động HTTP server nhận worker.olang
func (srv *WorkerDeployServer) Start() error {
	if err := os.MkdirAll(srv.deployDir, 0755); err != nil {
		return fmt.Errorf("deploy server: mkdir: %w", err)
	}

	mux := http.NewServeMux()

	// PUT /deploy — nhận worker.olang từ Chief
	mux.HandleFunc("/deploy", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPut {
			http.Error(w, "PUT only", http.StatusMethodNotAllowed)
			return
		}

		workerID := r.Header.Get("X-HomeOS-Worker-ID")
		if workerID == "" {
			http.Error(w, "X-HomeOS-Worker-ID required", http.StatusBadRequest)
			return
		}

		// Ghi file
		filename := fmt.Sprintf("worker_%s.olang", workerID)
		destPath := filepath.Join(srv.deployDir, filename)

		data, err := io.ReadAll(io.LimitReader(r.Body, 10*1024*1024)) // max 10MB
		if err != nil {
			log.Printf("DeployServer: read body: %v", err)
			http.Error(w, "read error", http.StatusInternalServerError)
			return
		}

		// Validate: phải bắt đầu bằng OLNG
		if len(data) < 4 || string(data[:4]) != "OLNG" {
			http.Error(w, "invalid olang file (bad magic)", http.StatusBadRequest)
			return
		}

		if err := os.WriteFile(destPath, data, 0644); err != nil {
			log.Printf("DeployServer: write %q: %v", destPath, err)
			http.Error(w, "write error", http.StatusInternalServerError)
			return
		}

		log.Printf("✅ DeployServer [%s]: received %d bytes → %s", workerID, len(data), destPath)

		// Trigger callback — caller quyết định có run không
		if srv.onDeploy != nil {
			go srv.onDeploy(workerID, destPath)
		}

		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"ok","worker_id":%q,"size":%d}`, workerID, len(data))
	})

	// GET /status — health check
	mux.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status":"ok","deploy_dir":%q}`, srv.deployDir)
	})

	addr := fmt.Sprintf(":%d", srv.port)
	log.Printf("○ DeployServer listening on %s", addr)
	return http.ListenAndServe(addr, mux)
}
