// internal/agents/skill_perception.go
//
// PerceptionSkill — SensorAgent (Worker, tier=2)
// AggregateSkill — HomeChief (tier=1)
// DecideSkill    — AAM (tier=0)
//
// Luồng đúng (bottom-up):
//   Worker → Chief → AAM → Chief → Worker
//
// KHÔNG lưu frame — chỉ features, bỏ ngay

package agents

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// encode/decode helpers dùng JSON trong Payload []byte
func encodePayload(v interface{}) []byte {
	b, _ := json.Marshal(v)
	return b
}
func decodePayload(b []byte, v interface{}) error {
	return json.Unmarshal(b, v)
}

// ─── Payload types ─────────────────────────────────────────────

type PerceptPayload struct {
	SensorID   string          `json:"sid"`
	SpaceISL   string          `json:"isl"`
	SpaceType  gene.SpaceType  `json:"space"`
	Action     gene.ActionVerb `json:"action"`
	ActionConf float64         `json:"conf"`
	Species    string          `json:"species"`
	AudioCues  []gene.AudioCue `json:"audio"`
}

type ContextUpdatePayload struct {
	SpaceISL    string          `json:"isl"`
	SpaceType   gene.SpaceType  `json:"space"`
	Action      gene.ActionVerb `json:"action"`
	ActionConf  float64         `json:"conf"`
	Species     string          `json:"species"`
	LightLevel  float64         `json:"light"`
	Temperature float64         `json:"temp"`
	FanSpeed    float64         `json:"fan"`
	SoundLevel  float64         `json:"sound"`
	Changes     []string        `json:"changes"`
}

type ActuateCommand struct {
	SpaceISL    string         `json:"isl"`
	SpaceType   gene.SpaceType `json:"space"`
	LightLevel  float64        `json:"light"`
	Temperature float64        `json:"temp"`
	FanSpeed    float64        `json:"fan"`
	SoundLevel  float64        `json:"sound"`
	Reason      string         `json:"reason"`
}

// ── PerceptionSkill (Worker tier=2) ──────────────────────────
// 1 trách nhiệm: frame → extract → emit MsgLearn lên Chief

type PerceptionSkill struct {
	sensorID   string
	recognizer *gene.ActionRecognizer
	tracker    *gene.MotionTracker
	species    string
	frameCount int
}

func NewPerceptionSkill(sensorID, defaultSpecies string) *PerceptionSkill {
	return &PerceptionSkill{
		sensorID:   sensorID,
		recognizer: gene.NewActionRecognizer(),
		tracker:    gene.NewMotionTracker("live_"+sensorID, 30),
		species:    defaultSpecies,
	}
}

func (s *PerceptionSkill) Name() string { return "perception:" + s.sensorID }

func (s *PerceptionSkill) CanHandle(msg *isl.ISLMessage) bool {
	// Nhận MsgTick (sensor heartbeat) hoặc MsgSync (frame ready)
	return msg.MsgType == isl.MsgTick || msg.MsgType == isl.MsgSync
}

func (s *PerceptionSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// Đọc skeleton từ state (do FovealSkill populate, không lưu frame)
	if sk, ok := ctx.State["skeleton_"+s.sensorID]; ok {
		if skeleton, ok2 := sk.(*gene.SDFSkeleton); ok2 && skeleton != nil {
			s.tracker.AddSkeleton(skeleton)
		}
	}
	s.frameCount++

	// Emit sau 30 frames = 1 giây
	if s.frameCount < 30 {
		return SkillResult{}
	}

	clip := s.tracker.Finish()
	// Reset ngay — không giữ history
	s.tracker = gene.NewMotionTracker("live_"+s.sensorID, 30)
	s.frameCount = 0

	var audio []gene.AudioCue
	if a, ok := ctx.State["audio_"+s.sensorID]; ok {
		if cues, ok2 := a.([]gene.AudioCue); ok2 {
			audio = cues
		}
	}

	scene := s.recognizer.Recognize(clip, audio)

	payload := PerceptPayload{
		SensorID:   s.sensorID,
		SpaceISL:   scene.ISLAddr,
		SpaceType:  scene.Space,
		Action:     scene.Action,
		ActionConf: scene.ActionConf,
		Species:    s.species,
		AudioCues:  audio,
	}

	return SkillResult{
		Data: map[string]interface{}{"last_percept_" + s.sensorID: payload},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgLearn, // Worker → Chief: "đã học được điều này"
			Payload: encodePayload(payload),
		},
	}
}

// ── AggregateSkill (HomeChief tier=1) ────────────────────────
// 1 trách nhiệm: nhiều PERCEPT → ContextState → report AAM

type AggregateSkill struct {
	ctx        *gene.ContextState
	lastAction map[string]gene.ActionVerb // sensorID → last action
}

func NewAggregateSkill() *AggregateSkill {
	return &AggregateSkill{
		ctx:        gene.NewContextState(),
		lastAction: make(map[string]gene.ActionVerb),
	}
}

func (s *AggregateSkill) Name() string { return "aggregate" }

func (s *AggregateSkill) CanHandle(msg *isl.ISLMessage) bool {
	// Nhận MsgLearn từ Workers
	if msg.MsgType != isl.MsgLearn {
		return false
	}
	var p PerceptPayload
	return decodePayload(msg.Payload, &p) == nil && p.SensorID != ""
}

func (s *AggregateSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var payload PerceptPayload
	if err := decodePayload(msg.Payload, &payload); err != nil {
		return SkillResult{}
	}

	scene := &gene.SceneUnderstanding{
		Action:     payload.Action,
		ActionConf: payload.ActionConf,
		Space:      payload.SpaceType,
		ISLAddr:    payload.SpaceISL,
	}

	now := time.Now()
	if t, ok := ctx.State["now"]; ok {
		if tt, ok2 := t.(time.Time); ok2 {
			now = tt
		}
	}

	events := s.ctx.Update(scene, payload.Species, now)

	// Chỉ report khi action đổi hoặc env thay đổi
	hasChange := s.lastAction[payload.SensorID] != payload.Action
	if !hasChange && len(events) > 0 {
		hasChange = len(events[0].Changes) > 0
	}
	s.lastAction[payload.SensorID] = payload.Action

	if !hasChange {
		return SkillResult{Data: map[string]interface{}{"ctx": s.ctx}}
	}

	sp := s.ctx.Spaces[payload.SpaceType]
	var changes []string
	for _, e := range events {
		changes = append(changes, e.Changes...)
	}

	update := ContextUpdatePayload{
		SpaceISL:    payload.SpaceISL,
		SpaceType:   payload.SpaceType,
		Action:      payload.Action,
		ActionConf:  payload.ActionConf,
		Species:     payload.Species,
		LightLevel:  sp.LightLevel,
		Temperature: sp.Temperature,
		FanSpeed:    sp.FanSpeed,
		SoundLevel:  sp.SoundLevel,
		Changes:     changes,
	}

	return SkillResult{
		Data: map[string]interface{}{"ctx": s.ctx},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgKnowledge, // Chief → AAM: "trạng thái mới"
			Payload: encodePayload(update),
		},
	}
}

// ── DecideSkill (AAM tier=0) ──────────────────────────────────
// 1 trách nhiệm: MsgKnowledge → emit MsgActuatorCmd nếu cần

type envSnap struct{ Light, Temp, Fan, Sound float64 }

type DecideSkill struct {
	lastEnv map[gene.SpaceType]envSnap
}

func NewDecideSkill() *DecideSkill {
	return &DecideSkill{lastEnv: make(map[gene.SpaceType]envSnap)}
}

func (s *DecideSkill) Name() string { return "decide" }

func (s *DecideSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg.MsgType != isl.MsgKnowledge {
		return false
	}
	var u ContextUpdatePayload
	return decodePayload(msg.Payload, &u) == nil && u.SpaceISL != ""
}

func (s *DecideSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	var u ContextUpdatePayload
	if err := decodePayload(msg.Payload, &u); err != nil {
		return SkillResult{}
	}

	curr := envSnap{u.LightLevel, u.Temperature, u.FanSpeed, u.SoundLevel}
	if s.lastEnv[u.SpaceType] == curr {
		return SkillResult{} // không thay đổi
	}
	s.lastEnv[u.SpaceType] = curr

	cmd := ActuateCommand{
		SpaceISL:    u.SpaceISL,
		SpaceType:   u.SpaceType,
		LightLevel:  u.LightLevel,
		Temperature: u.Temperature,
		FanSpeed:    u.FanSpeed,
		SoundLevel:  u.SoundLevel,
		Reason: fmt.Sprintf("%s %s(%.0f%%)→%s",
			u.Species, u.Action, u.ActionConf*100, u.SpaceType),
	}

	return SkillResult{
		Data: map[string]interface{}{"last_cmd": cmd},
		Message: &isl.ISLMessage{
			MsgType: isl.MsgActuatorCmd, // AAM → Chief → Worker
			Payload: encodePayload(cmd),
		},
	}
}
