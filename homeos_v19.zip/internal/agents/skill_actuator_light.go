// internal/agents/skill_actuator_light.go
//
// ActuatorLightSkill — sống tại bóng đèn/công tắc (Edge)
//
// RAM: ~64KB
// Nhận: MsgActuatorCmd (từ HomeChief)
// Thực thi: bật/tắt/điều chỉnh độ sáng
// Offline: chạy theo Schedule đã học
//
// Schedule: LeoAI gửi PacketSchedule xuống
//   [{"hour":7,"level":0.8},{"hour":22,"level":0.0}]

package agents

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ScheduleEntry — 1 mục trong lịch đèn
type ScheduleEntry struct {
	Hour  int     `json:"hour"`
	Level float64 `json:"level"` // 0=tắt, 1=sáng tối đa
}

// LightState — trạng thái hiện tại của đèn
type LightState struct {
	Level    float64   // 0.0 - 1.0
	UpdatedAt time.Time
	Reason   string
}

// ActuatorLightSkill — 1 trách nhiệm: điều khiển đèn
type ActuatorLightSkill struct {
	deviceID    string
	locationISL string
	location    gene.SpaceType

	state    LightState
	schedule []ScheduleEntry // học từ LeoAI

	// sender — gửi lệnh đến thiết bị vật lý (nil = stub/test)
	sender *DeviceSender
}

func NewActuatorLightSkill(deviceID string, location gene.SpaceType) *ActuatorLightSkill {
	return &ActuatorLightSkill{
		deviceID:    deviceID,
		locationISL: location.ISLAddr(),
		location:    location,
		state:       LightState{Level: 0, Reason: "init"},
	}
}

// WithDevice gắn DeviceConfig thật — chain method
// Gọi sau NewActuatorLightSkill khi OnboardSkill đã biết IP/protocol
func (s *ActuatorLightSkill) WithDevice(cfg DeviceConfig) *ActuatorLightSkill {
	s.sender = NewDeviceSender(cfg)
	return s
}

func (s *ActuatorLightSkill) Name() string { return "actuator_light:" + s.deviceID }

func (s *ActuatorLightSkill) CanHandle(msg *isl.ISLMessage) bool {
	switch msg.MsgType {
	case isl.MsgActuatorCmd:
		// Chỉ xử lý nếu đúng location
		var cmd ActuateCommand
		if err := decodePayload(msg.Payload, &cmd); err != nil { return false }
		return cmd.SpaceISL == s.locationISL || cmd.SpaceISL == ""
	case isl.MsgSync:
		// MsgSync = LearnPacket schedule từ LeoAI
		var pkt LearnPacket
		if err := decodePayload(msg.Payload, &pkt); err != nil { return false }
		return pkt.Type == PacketSchedule &&
			(pkt.TargetISL == s.locationISL || pkt.TargetISL == "")
	case isl.MsgTick:
		return true // heartbeat → check schedule
	}
	return false
}

func (s *ActuatorLightSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	switch msg.MsgType {

	case isl.MsgActuatorCmd:
		return s.handleCmd(msg)

	case isl.MsgSync:
		return s.handleScheduleUpdate(msg)

	case isl.MsgTick:
		return s.handleTick()
	}
	return SkillResult{}
}

// handleCmd: nhận lệnh từ HomeChief
func (s *ActuatorLightSkill) handleCmd(msg *isl.ISLMessage) SkillResult {
	var cmd ActuateCommand
	if err := decodePayload(msg.Payload, &cmd); err != nil {
		return SkillResult{}
	}

	old := s.state.Level
	s.state = LightState{
		Level:     cmd.LightLevel,
		UpdatedAt: time.Now(),
		Reason:    cmd.Reason,
	}

	action := "no change"
	if cmd.LightLevel == 0 && old > 0 {
		action = "OFF"
	} else if cmd.LightLevel > 0 && old == 0 {
		action = fmt.Sprintf("ON %.0f%%", cmd.LightLevel*100)
	} else if cmd.LightLevel != old {
		action = fmt.Sprintf("%.0f%%→%.0f%%", old*100, cmd.LightLevel*100)
	}

	// Gửi lệnh đến thiết bị vật lý
	sendErr := ""
	if s.sender != nil {
		devCmd := DeviceCmd{
			On:    cmd.LightLevel > 0,
			Level: cmd.LightLevel,
		}
		if err := s.sender.Send(devCmd); err != nil {
			sendErr = err.Error()
			log.Printf("ActuatorLight [%s] send error: %v", s.deviceID, err)
		}
	}

	return SkillResult{
		Data: map[string]interface{}{
			"light_level":  s.state.Level,
			"light_action": action,
			"send_error":   sendErr,
		},
		// Báo lên Hub: đã thực thi
		Message: &isl.ISLMessage{
			MsgType: isl.MsgHeartbeat,
			Payload: encodePayload(map[string]interface{}{
				"device": s.deviceID,
				"isl":    s.locationISL,
				"level":  s.state.Level,
				"action": action,
				"reason": cmd.Reason,
			}),
		},
	}
}

// handleScheduleUpdate: nhận lịch mới từ LeoAI
func (s *ActuatorLightSkill) handleScheduleUpdate(msg *isl.ISLMessage) SkillResult {
	var pkt LearnPacket
	if err := decodePayload(msg.Payload, &pkt); err != nil {
		return SkillResult{}
	}
	var sched []ScheduleEntry
	if err := json.Unmarshal(pkt.Payload, &sched); err != nil {
		return SkillResult{}
	}
	s.schedule = sched
	return SkillResult{
		Data: map[string]interface{}{
			"schedule_entries": len(sched),
		},
	}
}

// handleTick: offline mode — tự chạy theo lịch
func (s *ActuatorLightSkill) handleTick() SkillResult {
	if len(s.schedule) == 0 {
		return SkillResult{} // không có lịch → không làm gì
	}
	hour := time.Now().Hour()
	target := s.scheduleLevel(hour)

	if target == s.state.Level {
		return SkillResult{} // đúng rồi → không làm gì
	}

	s.state.Level = target
	s.state.UpdatedAt = time.Now()
	s.state.Reason = fmt.Sprintf("schedule h%d", hour)

	return SkillResult{
		Data: map[string]interface{}{
			"light_level":  s.state.Level,
			"light_source": "schedule_offline",
		},
	}
}

// scheduleLevel: tìm level phù hợp với giờ hiện tại
func (s *ActuatorLightSkill) scheduleLevel(hour int) float64 {
	best := 0.0
	bestHour := -1
	for _, e := range s.schedule {
		if e.Hour <= hour && e.Hour > bestHour {
			best = e.Level
			bestHour = e.Hour
		}
	}
	return best
}

func (s *ActuatorLightSkill) State() LightState { return s.state }

// NewActuatorLight — wrapper tương thích với loader cũ
// location: "living_room", "bedroom", "kitchen"...
func NewActuatorLight(location string) *ActuatorLightSkill {
	sp := gene.SpaceLivingRoom
	switch location {
	case "kitchen":    sp = gene.SpaceKitchen
	case "bedroom":    sp = gene.SpaceBedroom
	case "office":     sp = gene.SpaceOffice
	case "bathroom":   sp = gene.SpaceBathroom
	case "gym":        sp = gene.SpaceGym
	}
	return NewActuatorLightSkill("light_"+location, sp)
}
