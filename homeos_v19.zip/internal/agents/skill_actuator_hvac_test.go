package agents

import (
	"encoding/json"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestActuatorHvacSkill(t *testing.T) {
	t.Log("═══════════════════════════════════════")
	t.Log("ActuatorHvacSkill — điều hòa nhiệt độ")
	t.Log("═══════════════════════════════════════")

	hvac := NewActuatorHvacSkill("hvac_living", gene.SpaceLivingRoom)
	ctx  := &ExecContext{State: make(map[string]interface{})}

	// 1. Bật cool 24°C
	msg := &isl.ISLMessage{
		MsgType: isl.MsgActuatorCmd,
		Payload: []byte("hvac:cool:24"),
	}
	r := hvac.Execute(ctx, msg)
	t.Logf("  cmd cool:24 → mode=%v setpoint=%v on=%v",
		r.Data["hvac.mode"], r.Data["hvac.setpoint"], r.Data["hvac.on"])
	if r.Data["hvac.mode"] != "cool" { t.Error("mode should be cool") }
	if r.Data["hvac.on"] != true     { t.Error("should be on") }

	// 2. Tick — nhiệt độ tiến về setpoint
	tickMsg := &isl.ISLMessage{MsgType: isl.MsgTick}
	hvac.Execute(ctx, tickMsg)
	hvac.Execute(ctx, tickMsg)
	hvac.Execute(ctx, tickMsg)
	t.Logf("  after 3 ticks → current=%.1f°C (setpoint=24.0)", ctx.State["hvac.current_c"])

	// 3. LearnPacket từ LeoAI
	pkts := []LearnPacket{{
		Type:       PacketTempProfile,
		TargetRole: RoleActuator,
		Payload: encodePayload(map[string]interface{}{
			"hour": 22.0, "temp_c": 22.0, "action": "sleeping",
		}),
	}}
	payload, _ := json.Marshal(pkts)
	learnMsg := &isl.ISLMessage{MsgType: isl.MsgSync, Payload: payload}
	r2 := hvac.Execute(ctx, learnMsg)
	t.Logf("  LearnPacket → profile_len=%v", r2.Data["hvac.profile_len"])
	if v, ok := r2.Data["hvac.profile_len"].(int); !ok || v == 0 {
		t.Error("profile should not be empty")
	}

	// 4. Off
	r3 := hvac.Execute(ctx, &isl.ISLMessage{
		MsgType: isl.MsgActuatorCmd, Payload: []byte("hvac:off"),
	})
	t.Logf("  cmd off → on=%v mode=%v", r3.Data["hvac.on"], r3.Data["hvac.mode"])
	if r3.Data["hvac.on"] != false { t.Error("should be off") }

	t.Logf("  Status: %s", hvac.Status())
	t.Log("\n✓ HvacSkill PASS")
}
