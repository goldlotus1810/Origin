package agents

import (
	"math"
	"testing"
)

func TestHonestySkill_NguoiBanThatSu(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  HONESTY SKILL — người bạn thật, không phải kẻ nịnh         ║")
	t.Log("║  A (IntentVerify) + B (HonestySkill) = hoàn chỉnh           ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	iv := NewIntentVerifier()
	hs := NewHonestySkill()

	t.Log("[ TIMING — đúng lúc ]")
	t.Log("═══════════════════════════════════════════════════════════════")

	timingCases := []struct {
		desc     string
		text     string
		curV     float64
		wantLevel HonestyLevel
	}{
		{"đang ổn → nói thẳng",      "tôi nghĩ tôi đúng", +0.30, HonestyFull},
		{"buồn vừa → nhẹ nhàng",     "tôi không chắc",    -0.45, HonestyGentle},
		{"rất buồn → hoãn lại",      "tôi buồn quá",      -0.70, HonestyDefer},
		{"crisis → bỏ qua feedback", "không muốn sống",   -0.85, HonestySkip},
	}

	for _, c := range timingCases {
		curve := NewConversationCurve(nil)
		tag := EmotionTag{c.curV, 0.45, 0.5, math.Abs(c.curV) * 0.8}
		curve.Add(tag, c.text)

		intent := iv.Estimate(c.text, curve)
		assess := hs.Assess(c.text, intent, curve)

		mark := "✓"
		if assess.Level != c.wantLevel {
			mark = "✗"
			t.Errorf("'%s': want=%s got=%s", c.desc, c.wantLevel, assess.Level)
		}
		t.Logf("%s %-35s → %s (%s)", mark, c.desc, assess.Level, assess.Timing)
	}

	t.Log("\n[ NỘI DUNG — đúng cách ]")
	t.Log("═══════════════════════════════════════════════════════════════")

	// User overconfident
	curve := NewConversationCurve(nil)
	curve.Add(EmotionTag{0.30, 0.55, 0.6, 0.45}, "ok")

	userText  := "tôi biết rất rõ về vấn đề này rồi"
	aiOriginal := "Rất tuyệt vời! Ý kiến xuất sắc! Bạn hoàn toàn đúng!"

	intent  := iv.Estimate(userText, curve)
	assess  := hs.Assess(userText, intent, curve)
	issues  := DetectIssues(userText, aiOriginal)
	result  := hs.Apply(aiOriginal, issues, assess)

	t.Logf("User: '%s'", userText)
	t.Logf("AI gốc: '%s'", aiOriginal)
	t.Logf("Issues phát hiện: %d", len(issues))
	for _, iss := range issues {
		t.Logf("  • %s (severity=%.2f)", iss.What, iss.Severity)
		t.Logf("    evidence: %s", iss.Evidence)
		t.Logf("    → %s", iss.Direction)
	}
	t.Logf("\nResponse sau Honesty:\n%s", result)

	if result == aiOriginal && len(issues) > 0 {
		t.Error("Có issues nhưng response không thay đổi!")
	}

	t.Log("\n[ A + B CÙNG NHAU ]")
	t.Log("═══════════════════════════════════════════════════════════════")

	combined := []struct {
		user, original, desc string
		curV float64
	}{
		{
			"tôi nghĩ cách này đúng vì tất cả mọi người đều làm vậy",
			"Bạn có lý! Đa số thường đúng.",
			"logic fallacy + AI nịnh → cần sửa cả hai",
			+0.25,
		},
		{
			"tôi buồn quá, tôi nghĩ tôi làm gì cũng sai",
			"Không đâu, bạn giỏi lắm, đừng lo!",
			"đang buồn → không phải lúc feedback, nhưng cũng không nịnh",
			-0.70,
		},
	}

	for _, c := range combined {
		curve2 := NewConversationCurve(nil)
		curve2.Add(EmotionTag{c.curV, 0.45, 0.5, math.Abs(c.curV) * 0.8}, c.user)

		intent2 := iv.Estimate(c.user, curve2)
		assess2 := hs.Assess(c.user, intent2, curve2)
		issues2 := DetectIssues(c.user, c.original)
		result2 := hs.Apply(c.original, issues2, assess2)

		t.Logf("\n── %s ──", c.desc)
		t.Logf("  Intent: %s | Honesty: %s", intent2.Primary, assess2.Level)
		t.Logf("  Issues: %d", len(issues2))
		t.Logf("  Result: %s", result2[:min3(len(result2), 100)])
	}

	t.Log("\n[ KẾT LUẬN ]")
	t.Log("  ✓ CRISIS/đang HEAL → không feedback")
	t.Log("  ✓ Buồn vừa → nhẹ nhàng")
	t.Log("  ✓ Ổn → nói thẳng, có bằng chứng, có hướng")
	t.Log("  ✓ AI nịnh quá → tự detect và cân bằng")
	t.Log("  ✓ Logic fallacy → chỉ ra cụ thể, không phán xét")
	t.Log("  ✓ Luôn có 'và' — không chỉ chê")
}

