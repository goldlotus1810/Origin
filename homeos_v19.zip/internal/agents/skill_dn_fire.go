// internal/agents/skill_dn_fire.go
//
// DNFireSkill  — nhận MsgLearn → Push vào ShortTerm (ĐN)
// TeachSkill   — nhận MsgLearn → fire count, threshold=3 → promote QR
// IndexSkill   — nhận MsgNodeAdded → trigger SilkGraph re-index
//
// MASTER.md §5.2 "Vòng đời tri thức":
//   quan sát → ĐN(+/-) → chứng minh → QR(==)
//
// QT7: ĐN = chưa chứng minh · tự do thay đổi
//      QR = đã chứng minh · append-only · bất biến

package agents

import (
	"encoding/json"
	"log"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/memory"
)

// ─── DNFireSkill ──────────────────────────────────────────────
// Trigger: MsgLearn
// Action:  Parse payload → Push MemoryEntry vào ShortTerm
// Payload format: JSON {"key":"X","value":"Y","confidence":0.33}

type DNFireSkill struct {
	dn *memory.ShortTerm
	qr *memory.LongTerm
}

func NewDNFireSkill(dn *memory.ShortTerm, qr *memory.LongTerm) *DNFireSkill {
	return &DNFireSkill{dn: dn, qr: qr}
}

func (s *DNFireSkill) Name() string { return "learn.dn_fire" }

func (s *DNFireSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg != nil && msg.MsgType == isl.MsgLearn
}

func (s *DNFireSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.dn == nil || msg == nil || len(msg.Payload) == 0 {
		return SkillResult{}
	}

	// Parse payload
	var p struct {
		Key        string  `json:"key"`
		Value      string  `json:"value"`
		Confidence float64 `json:"confidence"`
		Confirmed  int     `json:"confirmed"`
	}
	if err := json.Unmarshal(msg.Payload, &p); err != nil {
		// Fallback: payload là text thô
		p.Key = string(msg.Payload)
		p.Confidence = 0.33
		p.Confirmed = 1
	}
	if p.Key == "" {
		return SkillResult{}
	}
	if p.Confidence == 0 {
		p.Confidence = 0.33
	}

	// Tạo ISL address từ key
	addr := keyToAddr(p.Key)

	// NodeHash deterministic từ key (cùng hash như TeachSkill dùng)
	var sdfKey [15]byte
	copy(sdfKey[:], []byte(p.Key))
	h := isl.HashSDF(sdfKey)

	// Push vào ShortTerm
	s.dn.Observe(memory.Observation{
		NodeHash:   h,
		ISL:        addr,
		Data:       msg.Payload,
		Confidence: p.Confidence,
		Confirmed:  p.Confirmed,
	}, s.qr)

	log.Printf("DNFire: key=%q conf=%.2f → ShortTerm (%d entries)",
		p.Key, p.Confidence, s.dn.Count())

	return SkillResult{
		Data: map[string]interface{}{
			"dn.key":        p.Key,
			"dn.confidence": p.Confidence,
			"dn.count":      s.dn.Count(),
		},
	}
}

// ─── TeachSkill ───────────────────────────────────────────────
// Trigger: MsgLearn
// Action:  Xác nhận entry trong ShortTerm (fire++, confidence++)
//          Nếu fire >= 3 → flag để DreamSkill promote

type TeachSkill struct {
	dn *memory.ShortTerm
	qr *memory.LongTerm
}

func NewTeachSkill(dn *memory.ShortTerm, qr *memory.LongTerm) *TeachSkill {
	return &TeachSkill{dn: dn, qr: qr}
}

func (s *TeachSkill) Name() string { return "learn.teach" }

func (s *TeachSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg != nil && msg.MsgType == isl.MsgLearn
}

func (s *TeachSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.dn == nil || msg == nil || len(msg.Payload) == 0 {
		return SkillResult{}
	}

	var p struct {
		Key string `json:"key"`
	}
	if err := json.Unmarshal(msg.Payload, &p); err != nil {
		p.Key = string(msg.Payload)
	}
	if p.Key == "" {
		return SkillResult{}
	}

	addr := keyToAddr(p.Key)
	_ = addr
	// NodeHash từ key — hash một SDF 15B tạo từ key
	var sdfKey [15]byte
	copy(sdfKey[:], []byte(p.Key))
	h := isl.HashSDF(sdfKey)
	s.dn.Confirm(h)
	obs, ok := s.dn.GetByHash(h)
	var conf float64
	if ok { conf = obs.Confidence }

	log.Printf("Teach: confirmed key=%q → conf=%.2f", p.Key, conf)

	// Nếu conf >= 0.8 → DreamSkill sẽ promote trong chu kỳ tiếp
	// (không promote trực tiếp ở đây — Dream có trách nhiệm đó)
	return SkillResult{
		Data: map[string]interface{}{
			"teach.key":        p.Key,
			"teach.confidence": conf,
		},
	}
}

// ─── ImmutableSkill ───────────────────────────────────────────
// Trigger: MsgImmutable (0x06)
// Action:  Người dùng nói "đây là Quy Tắc" → conf=1.0 → Commit QR ngay
//
// QT7: "QR == Định Nghĩa đã chứng minh · cần cấp phép"
// MsgImmutable là cơ chế "cấp phép" từ người dùng.
//
// Khác biệt với TeachSkill:
//   TeachSkill: MsgLearn → conf tăng dần → Dream promote
//   ImmutableSkill: MsgImmutable → conf=1.0 → Commit ngay (bypass Dream)
//
// Payload format: JSON {"key":"X","value":"Y"} hoặc text thô
// Header flag: msg.Flags bit 0 = immutable intent (từ parser ngôn ngữ)
//
// Keyword triggers (parser nhận ra và đặt MsgImmutable):
//   "đây là Quy Tắc: ..."
//   "ghi nhớ: ..."
//   "bất biến: ..."
//   "QT: ..."

type ImmutableSkill struct {
	dn *memory.ShortTerm
	qr *memory.LongTerm
}

func NewImmutableSkill(dn *memory.ShortTerm, qr *memory.LongTerm) *ImmutableSkill {
	return &ImmutableSkill{dn: dn, qr: qr}
}

func (s *ImmutableSkill) Name() string { return "learn.immutable" }

func (s *ImmutableSkill) CanHandle(msg *isl.ISLMessage) bool {
	if msg == nil { return false }
	// Trigger 1: MsgImmutable trực tiếp
	if msg.MsgType == isl.MsgImmutable { return true }
	// Trigger 2: MsgLearn với keyword trong payload
	if msg.MsgType == isl.MsgLearn {
		payload := string(msg.Payload)
		return containsQTKeyword(payload)
	}
	return false
}

func (s *ImmutableSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	if s.dn == nil || s.qr == nil || msg == nil { return SkillResult{} }

	// Parse payload
	var p struct {
		Key   string `json:"key"`
		Value string `json:"value"`
	}
	raw := msg.Payload
	if err := json.Unmarshal(raw, &p); err != nil {
		// Fallback: payload là text thô
		p.Key   = string(raw)
		p.Value = p.Key
	}
	if p.Key == "" { return SkillResult{} }
	if p.Value == "" { p.Value = p.Key }

	// Tạo địa chỉ ISL — QT nodes → L3 Concept group
	addr := qtKeyToAddr(p.Key)

	// NodeHash deterministic từ key
	var sdfKey [15]byte
	copy(sdfKey[:], []byte(p.Key))
	h := isl.HashSDF(sdfKey)

	obs := memory.Observation{
		NodeHash:   h,
		ISL:        addr,
		Data:       raw,
		Label:      p.Key,
		Confidence: 1.0, // FULL CONFIDENCE — người dùng đã xác nhận
		Confirmed:  3,   // tương đương 3 lần xác nhận
		SrcType:    1,   // SourceUser = real_now
	}

	// Bước 1: Vào ĐN trước (QT7: mọi thứ bắt đầu từ ĐN)
	s.dn.Observe(obs, s.qr)

	// Bước 2: Commit thẳng vào QR (bypass Dream — người dùng đã "chứng minh")
	if err := s.qr.Commit(obs); err != nil {
		log.Printf("ImmutableSkill: Commit error: %v", err)
	}

	log.Printf("ImmutableSkill: ✅ QR '%s' conf=1.0 → ĐN+QR+.olang", p.Key)

	return SkillResult{
		Data: map[string]interface{}{
			"immutable.key":      p.Key,
			"immutable.qr_count": s.qr.Count(),
			"immutable.dn_count": s.dn.Count(),
		},
	}
}

// qtKeyToAddr — ISL cho QT/QR knowledge nodes
// Layer 3 (L3 Concept), Group 'Q' (QR), Type 'R'
func qtKeyToAddr(key string) isl.Address {
	var h uint32 = 2166136261
	for _, b := range []byte(key) {
		h ^= uint32(b)
		h *= 16777619
	}
	return isl.Address{
		Layer: 0x03, // L3 Concept
		Group: 0x51, // 'Q' = QR group
		Type:  0x52, // 'R'
		ID:    uint8(h),
	}
}

// containsQTKeyword kiểm tra payload có chứa từ khóa "đây là Quy Tắc"
func containsQTKeyword(text string) bool {
	keywords := []string{
		"đây là Quy Tắc", "Đây là Quy Tắc",
		"ghi nhớ:", "Ghi nhớ:",
		"bất biến:", "Bất biến:",
		"\"QT", "QT1:", "QT2:", "QT3:", "QT4:",
		"QT5:", "QT6:", "QT7:", "QT8:", "QT9:",
	}
	for _, kw := range keywords {
		if len(text) >= len(kw) {
			// Simple substring search
			for i := 0; i <= len(text)-len(kw); i++ {
				if text[i:i+len(kw)] == kw {
					return true
				}
			}
		}
	}
	return false
}

// Trigger: MsgLearn (sau khi node mới được thêm)
// Action:  Không làm gì thêm — SilkGraph tự index khi AddNode()
//          Placeholder cho tương lai: rebuild search index

type IndexSkill struct{}

func (s *IndexSkill) Name() string { return "learn.index" }
func (s *IndexSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg != nil && msg.MsgType == isl.MsgLearn
}
func (s *IndexSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	// SilkGraph.AddNode() đã index tự động (O(1) map insert)
	// Không cần làm thêm gì ở đây
	return SkillResult{}
}

// ─── helpers ──────────────────────────────────────────────────

// keyToAddr tạo ISL address từ text key (deterministic)
func keyToAddr(key string) isl.Address {
	// Dùng FNV-like hash để stable
	var h uint32 = 2166136261
	for _, b := range []byte(key) {
		h ^= uint32(b)
		h *= 16777619
	}
	return isl.Address{
		Layer: 7,             // L7 Programs (learned)
		Group: uint8(h >> 24),
		Type:  uint8(h >> 16),
		ID:    uint8(h >> 8),
	}
}
