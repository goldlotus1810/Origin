package agents

import (
	"encoding/json"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

func TestMilestone1(t *testing.T) {
	t.Log("╔══════════════════════════════════════════════════════════════╗")
	t.Log("║  MILESTONE 1 — end-to-end: 'tắt đèn phòng khách'           ║")
	t.Log("║  User → AAM → HomeChief → LightAgent → thực thi            ║")
	t.Log("╚══════════════════════════════════════════════════════════════╝\n")

	// ── 3 tầng ───────────────────────────────────────────────
	decide  := NewDecideSkill()
	agg     := NewAggregateSkill()
	light   := NewActuatorLightSkill("light_living", gene.SpaceLivingRoom)

	decCtx := &ExecContext{State: make(map[string]interface{})}
	lightCtx := &ExecContext{State: make(map[string]interface{})}

	t.Log("[ SCENARIO 1: camera thấy người nằm ngủ → đèn tự tắt ]")
	t.Log()

	// Camera (Edge) gửi PERCEPT lên Hub
	percept := PerceptPayload{
		SensorID: "cam_living", SpaceISL: "HAb1",
		SpaceType: gene.SpaceLivingRoom,
		Action: gene.ActionSleeping, ActionConf: 0.85,
		Species: "human_adult_female",
	}
	learnMsg := &isl.ISLMessage{
		MsgType: isl.MsgLearn,
		Payload: encodePayload(percept),
	}

	// Hub aggregate → ContextUpdate
	aggResult := agg.Execute(&ExecContext{State: map[string]interface{}{}}, learnMsg)

	// AAM decide → ActuatorCmd
	if aggResult.Message == nil {
		t.Fatal("AggregateSkill không emit message")
	}
	decResult := decide.Execute(decCtx, aggResult.Message)
	if decResult.Message == nil {
		t.Fatal("DecideSkill không emit ActuatorCmd")
	}

	// LightAgent nhận lệnh
	if !light.CanHandle(decResult.Message) {
		t.Fatal("LightAgent không nhận được lệnh")
	}
	lightResult := light.Execute(lightCtx, decResult.Message)

	var action string
	if v, ok := lightResult.Data["light_action"]; ok {
		action = v.(string)
	}
	t.Logf("  cam_living → sleeping(85%%) → AggregateSkill → DecideSkill")
	t.Logf("  ActuatorCmd → light_living: %s", action)
	t.Logf("  Level: %.0f%%", light.State().Level*100)
	t.Logf("  Reason: %s", light.State().Reason)

	if light.State().Level != 0 {
		t.Errorf("✗ ngủ mà đèn không tắt: %.0f%%", light.State().Level*100)
	} else {
		t.Log("  ✓ đèn tắt đúng")
	}

	t.Log()
	t.Log("[ SCENARIO 2: user nói 'bật đèn phòng khách 80%' ]")
	t.Log()

	// AAM parse user intent → ActuatorCmd trực tiếp
	userCmd := ActuateCommand{
		SpaceISL:   "HAb1",
		SpaceType:  gene.SpaceLivingRoom,
		LightLevel: 0.80,
		Reason:     "user: bật đèn phòng khách",
	}
	cmdMsg := &isl.ISLMessage{
		MsgType: isl.MsgActuatorCmd,
		Payload: encodePayload(userCmd),
	}

	if !light.CanHandle(cmdMsg) {
		t.Fatal("LightAgent không nhận lệnh user")
	}
	r2 := light.Execute(lightCtx, cmdMsg)
	action2 := r2.Data["light_action"].(string)
	t.Logf("  user cmd → light_living: %s", action2)
	t.Logf("  Level: %.0f%%", light.State().Level*100)

	if light.State().Level != 0.80 {
		t.Errorf("✗ level sai: %.0f%%", light.State().Level*100)
	} else {
		t.Log("  ✓ bật đúng 80%")
	}

	t.Log()
	t.Log("[ SCENARIO 3: LeoAI gửi schedule xuống → offline mode ]")
	t.Log()

	// LeoAI học được: phòng khách bật lúc 7h, tắt lúc 23h
	sched := []ScheduleEntry{
		{Hour: 7,  Level: 0.80},
		{Hour: 12, Level: 0.60},
		{Hour: 18, Level: 0.90},
		{Hour: 23, Level: 0.0},
	}
	schedBytes, _ := json.Marshal(sched)
	schedPkt := LearnPacket{
		Type:      PacketSchedule,
		TargetRole: RoleActuator,
		TargetISL:  "HAb1",
		Payload:   schedBytes,
	}
	syncMsg := &isl.ISLMessage{
		MsgType: isl.MsgSync,
		Payload: encodePayload(schedPkt),
	}

	if !light.CanHandle(syncMsg) {
		t.Fatal("LightAgent không nhận schedule")
	}
	r3 := light.Execute(lightCtx, syncMsg)
	t.Logf("  LeoAI → schedule %d entries", r3.Data["schedule_entries"])
	t.Logf("  schedule: 07h=80%% 12h=60%% 18h=90%% 23h=off")
	t.Logf("  offline: scheduleLevel(h=19) = %.0f%%", light.scheduleLevel(19)*100)
	t.Logf("  offline: scheduleLevel(h=23) = %.0f%%", light.scheduleLevel(23)*100)
	t.Log("  ✓ có thể tự chạy khi mất mạng")

	t.Log()
	t.Log("[ ACK: LightAgent báo lại Hub ]")
	if r2.Message != nil {
		var ack map[string]interface{}
		json.Unmarshal(r2.Message.Payload, &ack)
		t.Logf("  MsgHeartbeat → Hub: device=%s level=%.0f%% action=%s",
			ack["device"], ack["level"].(float64)*100, ack["action"])
		t.Log("  ✓ Hub biết đèn đã thực thi")
	}

	t.Log()
	t.Log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	t.Log("  MILESTONE 1 PASS")
	t.Log("  Camera(Edge) → Hub → Server(AAM) → Hub → Light(Edge)")
	t.Log("  RAM footprint: light_living ~64KB")
	t.Log("  Offline: chạy theo schedule đã học từ LeoAI")
}
