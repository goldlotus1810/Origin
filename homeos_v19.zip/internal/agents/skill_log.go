// internal/agents/skill_log.go
//
// 3 tầng log — mỗi tầng có nơi lưu và vòng đời khác nhau
//
// TẦNG 1: EphemeralLog  — RAM buffer vòng, mất khi tắt
// TẦNG 2: AuditLog      — ISL Ledger append-only, ED25519
// TẦNG 3: KnowledgeLog  — Silk Tree QR, qua DreamSkill
//
// QT2: không lưu vô hạn → buffer vòng cho ephemeral
// QT8: lịch sử bất biến → audit ledger không xóa
// QT7: ĐN→QR → chỉ tri thức đã chứng minh vào Tree

package agents

import (
	"crypto/ed25519"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─────────────────────────────────────────────────────────────
// TẦNG 1: EphemeralLog — RAM buffer vòng
// ─────────────────────────────────────────────────────────────

type LogLevel uint8

const (
	LogDebug   LogLevel = iota
	LogInfo
	LogWarn
	LogError
)

func (l LogLevel) String() string {
	return [...]string{"DEBUG", "INFO", "WARN", "ERROR"}[l]
}

type EphemeralEntry struct {
	Seq       uint64
	AgentID   string
	Level     LogLevel
	Message   string
	Timestamp time.Time
}

// EphemeralLog: ring buffer, mất khi tắt máy
// QT2: size hữu hạn — overwrite oldest khi đầy
type EphemeralLog struct {
	mu      sync.Mutex
	buf     []EphemeralEntry
	head    int    // vị trí ghi tiếp theo
	size    int    // capacity
	seq     uint64 // monotonic counter
	full    bool
}

func NewEphemeralLog(size int) *EphemeralLog {
	return &EphemeralLog{buf: make([]EphemeralEntry, size), size: size}
}

func (l *EphemeralLog) Write(agentID string, level LogLevel, msg string) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.seq++
	l.buf[l.head] = EphemeralEntry{
		Seq: l.seq, AgentID: agentID,
		Level: level, Message: msg,
		Timestamp: time.Now(),
	}
	l.head = (l.head + 1) % l.size
	if l.head == 0 { l.full = true }
}

func (l *EphemeralLog) Recent(n int) []EphemeralEntry {
	l.mu.Lock()
	defer l.mu.Unlock()
	var out []EphemeralEntry
	total := l.size
	if !l.full { total = l.head }
	start := l.head - n
	if start < 0 { start = 0 }
	for i := start; i < total; i++ {
		idx := i % l.size
		out = append(out, l.buf[idx])
	}
	return out
}

func (l *EphemeralLog) Count() int {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.full { return l.size }
	return l.head
}

// ─────────────────────────────────────────────────────────────
// TẦNG 2: AuditLog — ISL Ledger append-only
// ─────────────────────────────────────────────────────────────

type AuditAction string

const (
	AuditAgentCreated    AuditAction = "agent.created"
	AuditAgentDestroyed  AuditAction = "agent.destroyed"
	AuditPermGranted     AuditAction = "perm.granted"
	AuditPermRevoked     AuditAction = "perm.revoked"
	AuditPermDenied      AuditAction = "perm.denied"
	AuditFirmwareRead    AuditAction = "firmware.read"
	AuditFirmwarePatch   AuditAction = "firmware.patch"
	AuditFirmwareUpdate  AuditAction = "firmware.update"
	AuditSkillAdded      AuditAction = "skill.added"
	AuditKnowledgeCommit AuditAction = "knowledge.commit"
	AuditSecurityBlock   AuditAction = "security.block"
)

type AuditEntry struct {
	Seq       uint64      `json:"seq"`
	Timestamp time.Time   `json:"ts"`
	AgentID   string      `json:"agent"`
	Action    AuditAction `json:"action"`
	Subject   string      `json:"subject"`  // đối tượng bị tác động
	Scope     string      `json:"scope,omitempty"`
	Result    string      `json:"result"`   // "ok", "denied", "error"
	SessionID string      `json:"session,omitempty"`
	Sig       []byte      `json:"sig,omitempty"` // ED25519
}

func (e *AuditEntry) Bytes() []byte {
	// Canonical encoding để ký
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, e.Seq)
	payload, _ := json.Marshal(struct {
		Seq    uint64 `json:"seq"`
		TS     int64  `json:"ts"`
		Agent  string `json:"agent"`
		Action string `json:"action"`
	}{e.Seq, e.Timestamp.UnixNano(), e.AgentID, string(e.Action)})
	return append(b, payload...)
}

// AuditLog: append-only, ED25519 signed
// QT8: không xóa, không sửa — đây là sự thật lịch sử
type AuditLog struct {
	mu      sync.Mutex
	entries []AuditEntry
	seq     uint64
	privKey ed25519.PrivateKey // nil = không ký (test mode)
	path    string             // "" = in-memory only
	file    *os.File           // nil nếu chưa mở
}

func NewAuditLog(privKey ed25519.PrivateKey) *AuditLog {
	return &AuditLog{privKey: privKey}
}

// WithPath gắn file path để persist — gọi ngay sau New
// Format: JSONL (1 JSON per line) — human readable, append-only
// QT8: chỉ append, không overwrite
func (l *AuditLog) WithPath(path string) *AuditLog {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.path = path
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err == nil {
		l.file = f
	}
	return l
}

func (l *AuditLog) Write(agentID string, action AuditAction,
	subject, result, sessionID, scope string) AuditEntry {

	l.mu.Lock()
	defer l.mu.Unlock()

	l.seq++
	e := AuditEntry{
		Seq: l.seq, Timestamp: time.Now(),
		AgentID: agentID, Action: action,
		Subject: subject, Result: result,
		SessionID: sessionID, Scope: scope,
	}

	// Ký nếu có private key
	if l.privKey != nil {
		e.Sig = ed25519.Sign(l.privKey, e.Bytes())
	}

	// APPEND ONLY — không bao giờ xóa
	l.entries = append(l.entries, e)

	// Persist to disk nếu có path (QT8: append-only JSONL)
	if l.file != nil {
		line, err := json.Marshal(e)
		if err == nil {
			l.file.Write(line)
			l.file.Write([]byte("\n"))
		}
	}

	return e
}

func (l *AuditLog) Verify(e AuditEntry, pubKey ed25519.PublicKey) bool {
	if e.Sig == nil { return true } // test mode
	return ed25519.Verify(pubKey, e.Bytes(), e.Sig)
}

// LoadFromDisk đọc lại entries từ JSONL file khi restart
// QT8: replay lịch sử — không bỏ sót gì
func (l *AuditLog) LoadFromDisk(path string) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) { return nil } // file chưa tồn tại — OK
		return err
	}
	lines := splitLines(data)
	for _, line := range lines {
		if len(line) == 0 { continue }
		var e AuditEntry
		if err := json.Unmarshal(line, &e); err != nil { continue }
		l.entries = append(l.entries, e)
		if e.Seq > l.seq { l.seq = e.Seq }
	}
	return nil
}

// Close đóng file handle khi shutdown
func (l *AuditLog) Close() {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.file != nil {
		l.file.Close()
		l.file = nil
	}
}

func (l *AuditLog) Query(agentID string, action AuditAction) []AuditEntry {
	l.mu.Lock()
	defer l.mu.Unlock()
	var out []AuditEntry
	for _, e := range l.entries {
		if (agentID == "" || e.AgentID == agentID) &&
			(action == "" || e.Action == action) {
			out = append(out, e)
		}
	}
	return out
}

func (l *AuditLog) Count() int {
	l.mu.Lock()
	defer l.mu.Unlock()
	return len(l.entries)
}

// ─────────────────────────────────────────────────────────────
// TẦNG 3: KnowledgeLog — qua DreamSkill → Silk Tree QR
// Không phải log truyền thống — đây là tri thức đã chứng minh
// ─────────────────────────────────────────────────────────────

type KnowledgeLogEntry struct {
	Topic     string    // "device.capability", "behavior.pattern"
	AgentID   string
	Content   string    // mô tả tri thức
	Evidence  []string  // bằng chứng
	Conf      float64   // phải >= 0.8 để vào QR
	SeenCount int
	FirstSeen time.Time
	LastSeen  time.Time
}

// KnowledgeLog: accumulator trước khi vào Silk Tree
// Khi SeenCount >= threshold → DreamSkill promote → QR
type KnowledgeLog struct {
	mu      sync.Mutex
	entries map[string]*KnowledgeLogEntry // topic:content → entry
}

func NewKnowledgeLog() *KnowledgeLog {
	return &KnowledgeLog{entries: make(map[string]*KnowledgeLogEntry)}
}

func (l *KnowledgeLog) Observe(topic, agentID, content string,
	evidence []string, conf float64) *KnowledgeLogEntry {

	l.mu.Lock()
	defer l.mu.Unlock()

	key := fmt.Sprintf("%s:%s", topic, content)
	e, exists := l.entries[key]
	if !exists {
		e = &KnowledgeLogEntry{
			Topic: topic, AgentID: agentID,
			Content: content, Evidence: evidence,
			FirstSeen: time.Now(),
		}
		l.entries[key] = e
	}

	// Cập nhật
	e.SeenCount++
	e.LastSeen = time.Now()
	e.Conf = conf
	if len(evidence) > len(e.Evidence) { e.Evidence = evidence }

	return e
}

// ReadyForQR: đủ điều kiện vào Silk Tree chưa?
func (l *KnowledgeLog) ReadyForQR(minSeen int, minConf float64) []*KnowledgeLogEntry {
	l.mu.Lock()
	defer l.mu.Unlock()
	var out []*KnowledgeLogEntry
	for _, e := range l.entries {
		if e.SeenCount >= minSeen && e.Conf >= minConf {
			out = append(out, e)
		}
	}
	return out
}

// ─────────────────────────────────────────────────────────────
// LoggerSkill — tích hợp 3 tầng vào 1 Skill
// ─────────────────────────────────────────────────────────────

type LoggerSkill struct {
	agentID  string
	ephemeral *EphemeralLog
	audit     *AuditLog
	knowledge *KnowledgeLog
}

func NewLoggerSkill(agentID string, auditKey ed25519.PrivateKey) *LoggerSkill {
	return &LoggerSkill{
		agentID:   agentID,
		ephemeral: NewEphemeralLog(1000), // 1000 entries vòng
		audit:     NewAuditLog(auditKey),
		knowledge: NewKnowledgeLog(),
	}
}

// WithAuditPath gắn persist path cho AuditLog — chain method
// Tự động LoadFromDisk (replay lịch sử QT8) + mở file để append tiếp
func (s *LoggerSkill) WithAuditPath(path string) *LoggerSkill {
	s.audit.LoadFromDisk(path) // replay: không bỏ sót lịch sử
	s.audit.WithPath(path)     // mở để append tiếp
	return s
}

func (s *LoggerSkill) Name() string { return "logger" }

func (s *LoggerSkill) CanHandle(msg *isl.ISLMessage) bool {
	return msg.MsgType == isl.MsgHeartbeat // log heartbeat
}

func (s *LoggerSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	s.ephemeral.Write(s.agentID, LogInfo, "heartbeat")
	return SkillResult{}
}

// Public API cho các Skill khác gọi qua ExecContext
func (s *LoggerSkill) Debug(msg string) {
	s.ephemeral.Write(s.agentID, LogDebug, msg)
}

func (s *LoggerSkill) Audit(action AuditAction, subject, result, session, scope string) {
	e := s.audit.Write(s.agentID, action, subject, result, session, scope)
	// Echo vào ephemeral để debug
	s.ephemeral.Write(s.agentID, LogInfo,
		fmt.Sprintf("AUDIT: %s %s → %s", action, subject, result))
	_ = e
}

func (s *LoggerSkill) Learn(topic, content string, evidence []string, conf float64) {
	entry := s.knowledge.Observe(topic, s.agentID, content, evidence, conf)
	s.ephemeral.Write(s.agentID, LogDebug,
		fmt.Sprintf("LEARN: %s (seen=%d conf=%.2f)", content, entry.SeenCount, conf))
}

func (s *LoggerSkill) EphemeralLog()  *EphemeralLog  { return s.ephemeral }
func (s *LoggerSkill) AuditLog()      *AuditLog      { return s.audit }
func (s *LoggerSkill) KnowledgeLog()  *KnowledgeLog  { return s.knowledge }

// splitLines tách []byte thành các dòng (không dùng bufio để tránh dependency)
func splitLines(data []byte) [][]byte {
	var lines [][]byte
	start := 0
	for i, b := range data {
		if b == '\n' {
			lines = append(lines, data[start:i])
			start = i + 1
		}
	}
	if start < len(data) {
		lines = append(lines, data[start:])
	}
	return lines
}
