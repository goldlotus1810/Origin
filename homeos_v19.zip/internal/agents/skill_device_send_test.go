package agents

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/gene"
)

func TestDetectProtocol(t *testing.T) {
	cases := []struct {
		vendor string
		want   DeviceProtocol
	}{
		{"Philips Hue", ProtoHueAPI},
		{"philips", ProtoHueAPI},
		{"Xiaomi", ProtoMiio},
		{"Tasmota", ProtoTasmota},
		{"Sonoff", ProtoTasmota},
		{"Shelly", ProtoShelly},
		{"Unknown vendor", ProtoStub},
	}
	for _, tc := range cases {
		got := detectProtocol(tc.vendor, "")
		if got != tc.want {
			t.Errorf("vendor=%q: got %s, want %s", tc.vendor, got, tc.want)
		}
	}
}

func TestDeviceSender_Stub(t *testing.T) {
	s := NewDeviceSender(DeviceConfig{
		IP: "192.168.1.100", Protocol: ProtoStub,
	})
	err := s.Send(DeviceCmd{On: true, Level: 0.8})
	if err != nil {
		t.Errorf("stub should not error: %v", err)
	}
}

func TestDeviceSender_Tasmota(t *testing.T) {
	// Mock HTTP server giả lập Tasmota
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Write([]byte(`{"POWER":"ON"}`))
	}))
	defer srv.Close()

	// Lấy IP:port từ mock server
	addr := strings.TrimPrefix(srv.URL, "http://")

	s := NewDeviceSender(DeviceConfig{
		IP:       addr,
		Protocol: ProtoTasmota,
	})
	err := s.Send(DeviceCmd{On: true, Level: 0.7})
	if err != nil {
		t.Errorf("tasmota send error: %v", err)
	}
	if !strings.Contains(gotURL, "Dimmer") {
		t.Errorf("Expected Dimmer in URL, got: %s", gotURL)
	}
	t.Logf("Tasmota URL: %s", gotURL)
}

func TestDeviceSender_Shelly(t *testing.T) {
	var gotURL string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotURL = r.URL.String()
		w.Write([]byte(`{"ison":true}`))
	}))
	defer srv.Close()

	addr := strings.TrimPrefix(srv.URL, "http://")
	s := NewDeviceSender(DeviceConfig{
		IP:       addr,
		Protocol: ProtoShelly,
	})
	err := s.Send(DeviceCmd{On: false, Level: 0})
	if err != nil {
		t.Errorf("shelly send error: %v", err)
	}
	if !strings.Contains(gotURL, "turn=off") {
		t.Errorf("Expected turn=off, got: %s", gotURL)
	}
}

func TestDeviceSender_Hue(t *testing.T) {
	var gotMethod, gotPath string
	var gotBody []byte
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotMethod = r.Method
		gotPath = r.URL.Path
		r.Body.Read(gotBody)
		w.Write([]byte(`[{"success":{"/lights/1/state/on":true}}]`))
	}))
	defer srv.Close()

	addr := strings.TrimPrefix(srv.URL, "http://")
	s := NewDeviceSender(DeviceConfig{
		IP:       addr,
		Protocol: ProtoHueAPI,
		Token:    "testtoken",
		DeviceID: "1",
	})
	err := s.Send(DeviceCmd{On: true, Level: 0.8})
	if err != nil {
		t.Errorf("hue send error: %v", err)
	}
	if gotMethod != "PUT" {
		t.Errorf("Expected PUT, got %s", gotMethod)
	}
	if !strings.Contains(gotPath, "testtoken") {
		t.Errorf("Expected token in path, got: %s", gotPath)
	}
	t.Logf("Hue PUT %s", gotPath)
}

func TestRgbToXY(t *testing.T) {
	// White light
	x, y := rgbToXY([3]byte{255, 255, 255})
	if x < 0.3 || x > 0.35 || y < 0.3 || y > 0.35 {
		t.Errorf("White XY wrong: %.4f, %.4f", x, y)
	}
	// Red
	x, y = rgbToXY([3]byte{255, 0, 0})
	if x < 0.6 {
		t.Errorf("Red X should be high, got %.4f", x)
	}
	t.Logf("White: (%.4f, %.4f), Red: (%.4f, %.4f)", x, y, x, y)
}

func TestActuatorLight_WithDevice(t *testing.T) {
	// Mock Tasmota server
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`{"POWER":"ON"}`))
	}))
	defer srv.Close()

	addr := strings.TrimPrefix(srv.URL, "http://")
	skill := NewActuatorLightSkill("test_light", gene.SpaceLivingRoom).
		WithDevice(DeviceConfig{
			IP:       addr,
			Protocol: ProtoTasmota,
		})

	if skill.sender == nil {
		t.Fatal("sender should not be nil after WithDevice")
	}

	// Gửi lệnh bật đèn
	err := skill.sender.Send(DeviceCmd{On: true, Level: 1.0})
	if err != nil {
		t.Errorf("send error: %v", err)
	}
	t.Log("✅ ActuatorLightSkill → WithDevice → Tasmota OK")
}
