// internal/agents/skill_context_aware.go
//
// ContextAwareSkill — nối ContextState vào Agent pipeline
//
// Session 117 insight:
//   Trước: user nói "tắt đèn" → AAM hỏi "phòng nào?"
//   Sau:   user nói "tắt đèn" → AAM biết context → tắt đúng phòng
//
// ContextState (gene package) chứa:
//   - Ai đang ở đâu (SpaceType)
//   - Đang làm gì (ActionVerb)
//   - Môi trường hiện tại (light/sound/temp/fan)
//
// ContextAwareSkill:
//   - Nhận lệnh ngắn từ user
//   - Tra ContextState → active space
//   - Resolve lệnh → ISL address đúng
//   - Gửi ActuatorCommand xuống Chief

package agents

import (
	"fmt"
	"strings"
	"time"

	"github.com/goldlotus1810/HomeOS/internal/gene"
	"github.com/goldlotus1810/HomeOS/internal/isl"
)

// ─── ContextAwareSkill ────────────────────────────────────────────────────

type ContextAwareSkill struct {
	ctx     *gene.ContextState
	whoAmI  string // species tracking this agent (e.g. "human_adult_female")
}

func NewContextAwareSkill(whoAmI string) *ContextAwareSkill {
	return &ContextAwareSkill{
		ctx:    gene.NewContextState(),
		whoAmI: whoAmI,
	}
}

func (s *ContextAwareSkill) Name() string { return "context_aware" }

func (s *ContextAwareSkill) CanHandle(msg *isl.ISLMessage) bool {
	lo := strings.ToLower(string(msg.Payload))
	// Các lệnh ngắn không cần địa chỉ cụ thể
	keywords := []string{
		"tắt đèn", "bật đèn", "sáng hơn", "tối hơn",
		"lạnh hơn", "ấm hơn", "im lặng", "yên tĩnh",
		"mát hơn", "quiet", "dim", "bright",
		// Scene perception updates
		"[scene]", "[context]",
	}
	for _, kw := range keywords {
		if strings.Contains(lo, kw) {
			return true
		}
	}
	return false
}

func (s *ContextAwareSkill) Execute(ctx *ExecContext, msg *isl.ISLMessage) SkillResult {
	payload := string(msg.Payload)
	lo := strings.ToLower(payload)

	// ── Case 1: Scene update từ perception pipeline ───────────
	if strings.HasPrefix(lo, "[scene]") {
		return s.handleSceneUpdate(ctx, payload)
	}

	// ── Case 2: Lệnh ambient từ user ─────────────────────────
	return s.handleAmbientCmd(ctx, lo)
}

// handleSceneUpdate: perception pipeline gửi scene mới
func (s *ContextAwareSkill) handleSceneUpdate(ctx *ExecContext, payload string) SkillResult {
	// Format: "[scene] action=cooking space=kitchen conf=80"
	scene := parseScenePayload(payload)
	if scene == nil {
		return SkillResult{Err: fmt.Errorf("invalid scene payload: %s", payload)}
	}

	events := s.ctx.Update(scene, s.whoAmI, time.Now())

	// Nếu có thay đổi → gửi actuator commands
	var outMsg *isl.ISLMessage
	if len(events) > 0 && len(events[0].Changes) > 0 {
		ev := events[0]
		state := s.ctx.Spaces[ev.Space]
		cmd := buildActuatorCmd(ev.Space, state)
		outMsg = &isl.ISLMessage{
			Payload: []byte(cmd),
		}
	}

	return SkillResult{
		Data: map[string]interface{}{
			"active_space": string(s.activeSpace()),
			"scene_action": string(scene.Action),
		},
		Message: outMsg,
	}
}

// handleAmbientCmd: lệnh ngắn của user → resolve theo context
func (s *ContextAwareSkill) handleAmbientCmd(ctx *ExecContext, cmd string) SkillResult {
	space := s.activeSpace()

	resp := s.ctx.AmbientCommand(cmd, space)
	state := s.ctx.Spaces[space]

	// Build ISL command
	actuatorCmd := buildActuatorCmd(space, state)

	// Human readable response
	response := fmt.Sprintf("✓ %s [%s]", resp.Result, resp.ISLAddr)
	if resp.Context != "" {
		response += fmt.Sprintf(" — %s", resp.Context)
	}

	return SkillResult{
		Data: map[string]interface{}{
			"cmd_result":   resp.Result,
			"active_space": string(space),
			"isl_addr":    resp.ISLAddr,
			"response":     response,
		},
		Message: &isl.ISLMessage{
			Payload: []byte(actuatorCmd),
		},
	}
}

// activeSpace tìm phòng đang active — ưu tiên LastSeen gần nhất
func (s *ContextAwareSkill) activeSpace() gene.SpaceType {
	best := gene.SpaceLivingRoom
	var bestTime time.Time

	for sp, state := range s.ctx.Spaces {
		if !state.IsActive { continue }
		if state.LastSeen.After(bestTime) {
			bestTime = state.LastSeen
			best = sp
		}
	}
	return best
}

// buildActuatorCmd tạo lệnh cho actuators
func buildActuatorCmd(space gene.SpaceType, state *gene.SpaceState) string {
	return fmt.Sprintf("ACTUATOR %s light=%.0f sound=%.0f temp=%.1f fan=%.0f",
		state.ISLAddr,
		state.LightLevel*100,
		state.SoundLevel*100,
		state.Temperature,
		state.FanSpeed*100,
	)
}

// parseScenePayload parse "[scene] action=X space=Y conf=Z"
func parseScenePayload(s string) *gene.SceneUnderstanding {
	// Trim prefix
	s = strings.TrimPrefix(strings.ToLower(s), "[scene] ")

	scene := &gene.SceneUnderstanding{}
	parts := strings.Fields(s)

	actionMap := map[string]gene.ActionVerb{
		"cooking": gene.ActionCooking, "dancing": gene.ActionDancing,
		"typing": gene.ActionTyping, "walking": gene.ActionWalking,
		"sleeping": gene.ActionSleeping, "sitting": gene.ActionSitting,
		"running": gene.ActionRunning, "exercising": gene.ActionExercising,
	}
	spaceMap := map[string]gene.SpaceType{
		"kitchen": gene.SpaceKitchen, "living_room": gene.SpaceLivingRoom,
		"bedroom": gene.SpaceBedroom, "office": gene.SpaceOffice,
		"gym": gene.SpaceGym, "bathroom": gene.SpaceBathroom,
	}

	for _, p := range parts {
		kv := strings.SplitN(p, "=", 2)
		if len(kv) != 2 {
			continue
		}
		switch kv[0] {
		case "action":
			if v, ok := actionMap[kv[1]]; ok {
				scene.Action = v
			}
		case "space":
			if v, ok := spaceMap[kv[1]]; ok {
				scene.Space = v
				scene.ISLAddr = v.ISLAddr()
			}
		case "conf":
			fmt.Sscanf(kv[1], "%f", &scene.ActionConf)
			scene.ActionConf /= 100
			scene.SpaceConf = scene.ActionConf
		}
	}
	if scene.Action == "" {
		return nil
	}
	return scene
}

// ─── ConversationContext — nối NaturalResponse với ContextState ──────────

// ContextualReply tạo câu trả lời biết hoàn cảnh
// "tắt đèn đi" → biết đang ở bếp → "Đã tắt đèn bếp rồi nhé"
// (không nói "Đã tắt đèn phòng bếp tại địa chỉ HAa1 với light=0%")
func ContextualReply(result SkillResult, userMsg string) string {
	data := result.Data
	space, _ := data["active_space"].(string)
	cmd, _ := data["cmd_result"].(string)

	spaceVI := map[string]string{
		"kitchen":     "bếp",
		"living_room": "phòng khách",
		"bedroom":     "phòng ngủ",
		"office":      "phòng làm việc",
		"gym":         "phòng tập",
		"bathroom":    "phòng tắm",
		"outdoor":     "ngoài trời",
	}

	spaceVN := spaceVI[space]
	if spaceVN == "" {
		spaceVN = space
	}

	lo := strings.ToLower(userMsg)
	switch {
	case strings.Contains(lo, "tắt đèn"):
		return fmt.Sprintf("Tắt đèn %s rồi nhé.", spaceVN)
	case strings.Contains(lo, "bật đèn"), strings.Contains(lo, "sáng hơn"):
		return fmt.Sprintf("Đèn %s sáng hơn rồi.", spaceVN)
	case strings.Contains(lo, "tối hơn"):
		return fmt.Sprintf("Đèn %s dịu hơn rồi.", spaceVN)
	case strings.Contains(lo, "lạnh hơn"), strings.Contains(lo, "mát hơn"):
		return fmt.Sprintf("Mát hơn rồi — %s.", cmd)
	case strings.Contains(lo, "ấm hơn"):
		return fmt.Sprintf("Ấm hơn rồi — %s.", cmd)
	case strings.Contains(lo, "im lặng"), strings.Contains(lo, "yên tĩnh"):
		return fmt.Sprintf("Yên tĩnh rồi.")
	default:
		return fmt.Sprintf("Xong: %s.", cmd)
	}
}
