package agents

import (
	"testing"

	"github.com/goldlotus1810/HomeOS/internal/isl"
	"github.com/goldlotus1810/HomeOS/internal/silk"
)

func TestSilkWalkSkill(t *testing.T) {
	t.Log("═══════════════════════════════════════════════")
	t.Log("SilkWalkSkill — LeoAI tự suy luận qua Silk Tree")
	t.Log("═══════════════════════════════════════════════")

	// Load graph từ homeos.olang
	graph := silk.NewSilkGraph()
	silk.SeedUnicodeTree(graph)
	silk.ApplyNameEdges(graph)

	n, _ := silk.LoadFromOlang(graph, "../../homeos.olang")
	t.Logf("  Silk Tree: %d nodes loaded", n)

	skill := NewSilkWalkSkill(graph)
	ctx   := &ExecContext{State: make(map[string]interface{})}

	// Test cases
	queries := []struct {
		query string
		want  bool // expect Found
	}{
		{"AI",              true},
		{"Algorithm",       true},
		{"algorithm",       true},
		{"Consciousness",   true},
		{"quantum physics", true},
		{"xyznotexist123",  false},
	}

	for _, tc := range queries {
		ctx.State = make(map[string]interface{})
		msg := &isl.ISLMessage{
			MsgType: isl.MsgQuery,
			Payload: []byte(tc.query),
		}
		r := skill.Execute(ctx, msg)
		found := ctx.State["silk_walk.found"].(bool)
		t.Logf("\n  Query: %q", tc.query)
		t.Logf("  Found: %v  (want %v)", found, tc.want)
		if found {
			t.Logf("  Root:  %v", ctx.State["silk_walk.root"])
			t.Logf("  Hops:  %v", ctx.State["silk_walk.hops"])
			if r.Message != nil {
				ans := string(r.Message.Payload)
				if len(ans) > 120 { ans = ans[:120] + "..." }
				t.Logf("  Answer: %s", ans)
			}
		}
		if found != tc.want {
			t.Errorf("  ✗ query %q: found=%v want=%v", tc.query, found, tc.want)
		} else {
			t.Logf("  ✓")
		}
	}

	t.Log("\n✓ SilkWalkSkill PASS — Silk Walk → Response pipeline hoạt động")
}
